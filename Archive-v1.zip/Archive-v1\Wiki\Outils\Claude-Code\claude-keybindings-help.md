---
galaxie: wiki
nom: keybindings-help
type: claude-code-skill
plateforme: claude-code
categorie: skill/dev-flow
sous_categories: [keybindings, shortcuts, productivity]
auteur: Anthropic
source: claude-code natif
source_url: https://docs.claude.com/en/docs/claude-code/keybindings
install_cmd: 
install_doc: https://docs.claude.com/en/docs/claude-code/keybindings
licence: 
licence_type: proprietary
domaines: []
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, productivity, keybindings]
---

# keybindings-help

## Pourquoi

Skill **bundled** pour configurer les **raccourcis clavier** de Claude Code via `~/.claude/keybindings.json`. Rebind une touche, ajoute un chord (séquence multi-touches), change la touche submit, etc.

Petit skill très ciblé — sert peu mais quand il sert, il fait gagner du temps.

## Quand l'utiliser

- "Je tape sans cesse `Ctrl+J` pour newline alors que je voudrais soumettre" → rebind
- Tu veux un chord pour invoquer un skill rapidement
- Tu passes de macOS à Windows et tes habitudes claviers cassent

## Quand NE PAS l'utiliser

- Tu veux changer un truc qui n'est pas un raccourci (settings.json est plus approprié)
- Tu veux des raccourcis Obsidian ou autre app → pas le bon skill

## Comment l'installer

Natif Claude Code, déclenchable via "rebind", "raccourci clavier", etc.

## Exemples d'usage

```
> rebind Ctrl+S pour qu'il submit la prompt au lieu d'inséirer un saut de ligne
> ajoute un chord Ctrl+K Ctrl+C pour invoquer le skill claude-api
```

## Pièges connus

- Les rebinds système (cmd+Q, alt+tab) ne sont pas modifiables — c'est l'OS
- Sur Windows, certaines combos sont déjà prises par PowerToys ou autre — vérifie avant

## Liens

- Doc : https://docs.claude.com/en/docs/claude-code/keybindings
