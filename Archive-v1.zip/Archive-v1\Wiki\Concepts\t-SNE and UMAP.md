---
galaxie: wiki
nom: t-SNE and UMAP
alias: [t-SNE, UMAP, manifold learning, non-linear dimensionality reduction]
type: concept
categorie: concept/ml
sous_categories: [dimensionality-reduction, visualization, non-linear, manifold, embedding]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [van der Maaten-Hinton 2008 (t-SNE), McInnes-Healy 2018 (UMAP)]
lecture_min: 9
created: 2026-05-19
modified: 2026-05-19
tags: [concept, ml, dimensionality-reduction, tsne, umap, visualization]
---

# t-SNE and UMAP — réduction de dimension non-linéaire pour visualisation

## TL;DR

[[PCA]] est linéaire et préserve la **variance globale** mais cache les structures locales. **t-SNE** et **UMAP** sont des méthodes **non-linéaires** qui préservent les **voisinages locaux** — idéales pour visualiser en 2D/3D des données complexes (embeddings, clusters cachés, manifolds). UMAP est plus rapide et préserve mieux la structure globale ; t-SNE est plus connu et plus stable historiquement.

## Le problème

Tu as des embeddings de dimension 768 (BERT), 1536 (OpenAI), ou des données features riches. Tu veux **visualiser en 2D** pour :
- Détecter des **clusters naturels**
- Identifier des **outliers**
- Comprendre la **structure** du dataset
- Présenter aux stakeholders

[[PCA]] échoue souvent ici : pour des manifolds courbes (visages, MNIST, embeddings), elle écrase la structure.

## L'idée — t-SNE (t-Distributed Stochastic Neighbor Embedding)

### Principe

1. Dans l'espace d'origine, calculer pour chaque paire $(i, j)$ une **probabilité de voisinage** $p_{ij}$ (gaussienne centrée sur $i$, échelle = perplexité)
2. Dans l'espace 2D, on cherche des positions $y_i$ telles que les probabilités $q_{ij}$ (distribution de Student-t à 1 ddl) matchent $p_{ij}$
3. Minimiser la **divergence KL** entre $p$ et $q$ via descente de gradient

$$ \mathcal{L} = \sum_i \sum_j p_{ij} \log \frac{p_{ij}}{q_{ij}} $$

### Caractéristiques

- **Perplexité** : hyperparam principal (5-50, défaut 30). Échelle de voisinage. Petit = focus local, grand = global
- **Stochastique** : 2 runs donnent des résultats différents (`random_state` pour reproductibilité)
- **Coût** : $O(n^2)$ en mémoire et temps. Pratique jusqu'à ~10k points, lourd au-delà
- **Distances globales non significatives** : 2 clusters proches dans la viz t-SNE ne sont **pas forcément** proches dans l'espace d'origine

### Pièges classiques

- **Lire les distances inter-cluster** comme métriques → faux
- **Tailles des clusters** dans la viz → pas représentatives de la densité réelle
- **Perplexité mal calibrée** : trop bas crée des micro-clusters artificiels ; trop haut écrase les structures fines

## L'idée — UMAP (Uniform Manifold Approximation and Projection)

### Principe

Mathématiquement ancré dans la **topologie algébrique** : on construit un graphe de voisinage flou dans l'espace haute-dim, puis on cherche son équivalent en 2D qui minimise une **cross-entropy**.

Plus simplement : comme t-SNE mais avec un loss différent qui préserve mieux la **structure globale** et tourne plus vite.

### Caractéristiques

- **n_neighbors** : analogue à la perplexité (5-100, défaut 15). Local vs global
- **min_dist** : minimum d'écartement entre points dans la viz (0.0-1.0, défaut 0.1). Plus bas = clusters plus serrés
- **Plus rapide** que t-SNE : $O(n \log n)$ approximé, scale jusqu'à 1M points
- **Plus stable** : 2 runs donnent des résultats proches
- **Distances globales partiellement préservées** : 2 clusters distants dans UMAP ≈ distants dans l'espace d'origine (mieux que t-SNE, mais pas garantie absolue)
- **Réutilisable** : tu peux `fit()` puis `transform()` sur de nouvelles données (pas natif t-SNE)

### Pièges classiques

- **min_dist trop bas** → tout est écrasé en clusters denses, perte d'info intra-cluster
- **n_neighbors trop bas** → fragmentation excessive
- **Supervised UMAP** : tu peux ajouter `y` comme info pour guider la projection — utile mais peut artificiellement séparer les classes

## Comparatif t-SNE vs UMAP

| Critère | t-SNE | UMAP |
|---|---|---|
| Vitesse | $O(n^2)$, lent | $O(n \log n)$, rapide |
| Scale max | ~10k points | ~1M+ points |
| Réutilisable | ❌ pas natif | ✅ fit + transform |
| Structure globale | Distordue | Partiellement préservée |
| Stabilité | Sensible au seed | Plus stable |
| Maturité | Très utilisé (2008+) | Standard depuis 2018-2020 |
| Communauté | Énorme | Grande et croissante |

**Choix pragmatique** : **UMAP par défaut**. t-SNE pour comparer, pour visualiser un petit dataset, ou si tu reproduis un paper existant.

## Quand c'est utile

- **Embeddings** (BERT, OpenAI ada, sentence-transformers) → visualisation des clusters
- **Single-cell RNA-seq** (génomique) → identifier des types cellulaires
- **MNIST / images** → vérifier que tes features capturent les classes
- **Topic modeling** → visualiser la distribution des documents
- **Anomaly detection visuelle** → outliers ressortent
- **Exploration de dataset** inconnue avant toute modélisation

## Quand ça ne marche pas / pièges

- **Quantifier la qualité d'une projection** : pas de métrique unanime. Utiliser trustworthiness, continuity (sklearn).
- **Choix d'hyperparams** : pas universel, tester plusieurs valeurs
- **3D viz** : t-SNE/UMAP marchent en 3D mais souvent pas plus informatif que 2D, et plus dur à interpréter
- **Garder t-SNE/UMAP pour la viz** : ne **PAS** l'utiliser comme feature engineering pour ML downstream (instable, non-réutilisable au sens propre, distances non-fiables) — sauf cas spécifiques (UMAP supervised + petit n_components)
- **Confusion avec PCA** : PCA = linéaire et interprétable ; t-SNE/UMAP = non-linéaire et opaque

## Code minimal

```python
from sklearn.manifold import TSNE
from umap import UMAP

# t-SNE
tsne = TSNE(n_components=2, perplexity=30, random_state=0, n_iter=1000)
X_tsne = tsne.fit_transform(X)  # X : matrice n × p

# UMAP
umap_model = UMAP(n_neighbors=15, min_dist=0.1, n_components=2, random_state=0)
X_umap = umap_model.fit_transform(X)

# Visualisation colorée par cluster
import matplotlib.pyplot as plt
plt.scatter(X_umap[:, 0], X_umap[:, 1], c=labels, cmap='tab10', s=2)
plt.show()
```

## Implémentations concrètes

- `sklearn.manifold.TSNE` — t-SNE classique
- [[umap-learn]] (`umap.UMAP`) — implémentation référence
- `openTSNE` — t-SNE optimisé, plus rapide
- `cuml.TSNE` / `cuml.UMAP` (RAPIDS) — GPU, scale énorme
- R : `Rtsne`, `umap`

## Pour aller plus loin

- van der Maaten & Hinton, *Visualizing Data using t-SNE* (2008)
- McInnes et al., *UMAP: Uniform Manifold Approximation and Projection* (2018)
- *How to Use t-SNE Effectively* — Wattenberg et al. (Distill 2016)
- **Liens internes** : [[PCA]] (linéaire), [[embeddings]] (les embeddings sont souvent visualisés en t-SNE/UMAP), [[K-means]], [[DBSCAN]]
