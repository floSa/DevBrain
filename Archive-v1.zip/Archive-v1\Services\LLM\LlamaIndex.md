---
galaxie: dev
nom: LlamaIndex
alias: [llama-index, llamaindex, gpt-index]
categorie: llm/framework
sous_categories: [rag, data, ingestion, indexing]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python (TS port disponible)
clients_officiels: [python, ts]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[LangChain]]", "[[Haystack]]", "[[LangGraph]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, framework, rag, indexing]
url_officiel: https://www.llamaindex.ai/
url_docs: https://docs.llamaindex.ai/
url_repo: https://github.com/run-llama/llama_index
---

# LlamaIndex

## Pourquoi
Framework spécialisé **RAG et data ingestion** pour LLMs : connecteurs (LlamaHub), parsers, chunking strategies, retrievers, query engines. Plus focalisé que [[LangChain]] sur le pipeline data → index → query.

## Quand l'utiliser
- RAG sérieux : ingestion de docs structurés + chunking intelligent + retrieval avancé
- Pipelines de connecteurs (Notion, Slack, Confluence, PDFs en masse) — voir LlamaHub
- Besoin de routing intelligent entre plusieurs index
- Quand tu veux "moins d'orchestration générale, plus de RAG"

## Quand NE PAS l'utiliser
- App agentique complexe avec tools/branches → [[LangGraph]]
- POC rapide chat simple → SDK natif suffit
- Si tu veux uniquement les utilitaires de retrieval → tu peux les utiliser sans le reste du framework

## Pièges connus
- **Versions 0.x** : breaking changes fréquents avant 0.10
- **`Settings` global** : configuration par singleton, peut surprendre dans les tests
- **Choix d'index** : VectorStoreIndex / SummaryIndex / KnowledgeGraphIndex / etc. — chacun avec ses gotchas
- **Chunking** : les defaults sont OK pour démarrer mais à tuner pour de vrais corpus
- **LlamaParse** (parsing PDF avancé) : produit séparé, payant au-delà du free tier

## Liens
- [[LangChain]] — alternative plus généraliste
- [[LangGraph]] — pour la couche agents
- LlamaHub (connecteurs) : https://llamahub.ai/
- LlamaParse : https://cloud.llamaindex.ai/
- Patterns RAG : https://docs.llamaindex.ai/en/stable/optimizing/production_rag/
