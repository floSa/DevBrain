---
galaxie: wiki
nom: Query transformations
alias: [HyDE, multi-query, query decomposition, query rewriting, RAG-Fusion]
type: concept
categorie: concept/rag
sous_categories: [query-transform, hyde, multi-query, rag]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Gao 2022 (HyDE)]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, rag, query, llm]
---

# Query transformations

## TL;DR

**Transformer la query** avant retrieval pour améliorer match. Techniques : **HyDE** (générer une hypothèse de réponse, embed-la), **Multi-Query** (génér N reformulations), **Query Decomposition** (splitter en sous-questions), **Step-back** (abstraire pour matcher), **RAG-Fusion** (multi-query + RRF). Gain typique : **+15-25% recall** sur queries vagues, complexes ou multi-step. Coût : 1 LLM call extra avant retrieval. Standard moderne : combiner query transform + [[Hybrid retrieval]] + [[Reranking]].

## Le problème

Queries utilisateurs sont :
- **Vagues** : "comment ça marche ?" — aucun contexte
- **Multi-aspects** : "comparer X et Y" — besoin d'info sur X ET Y
- **Mal formulées** : typos, langage informel
- **Différentes du doc style** : query courte vs doc formel

→ **Embedder telle quelle** peut rater des docs pourtant pertinents.

## L'idée

### HyDE (Hypothetical Document Embeddings, Gao 2022)

**Insight** : embedder une **réponse hypothétique** à la query plutôt que la query elle-même.

```
Query : "What's the capital of France?"
Hypothetical answer : "The capital of France is Paris, a major city in Europe..."
Embed THIS answer → match docs about Paris
```

**Pourquoi ça marche** : les docs sont stylistiquement plus proches d'une réponse que d'une question.

```python
hypothetical = llm(f"Generate a hypothetical answer to: {query}")
embedding = embed(hypothetical)
docs = vector_db.search(embedding)
```

- **Gain typique** : +5-15% recall sur queries vagues
- **Cost** : 1 LLM call extra
- Marche **mieux quand query courte / vague**

### Multi-Query / Query Expansion

Générer **N paraphrases** de la query, retrieve avec chacune :

```python
queries = llm(f"Generate 5 different ways to phrase: {query}")
all_results = [vector_db.search(q) for q in queries]
final = deduplicate_and_rank(all_results)
```

- Cover différents angles
- Combine via **RRF** (cf. [[Hybrid retrieval]])

### Query Decomposition

Pour queries **composées** ou **multi-step** :

```
Query : "Compare LangChain and LlamaIndex"
Sub-queries :
1. "What is LangChain?"
2. "What is LlamaIndex?"
3. "Differences between LangChain and LlamaIndex"
```

Retrieve chaque sub-query, combiner.

```python
sub_queries = llm(f"Decompose this query into sub-questions: {query}")
contexts = [retrieve(sq) for sq in sub_queries]
final_answer = llm(f"Using these contexts, answer: {query}\n{contexts}")
```

### Query Rewriting

Corriger / clarifier la query :
- Spell correction
- Acronym expansion
- Add context from conversation history
- Reformulate informal to formal

```python
rewritten = llm(f"Rewrite this query to be clearer and more specific: {query}")
```

### Step-back prompting (Zheng 2023)

**Abstraire** la query avant de retrieve :

```
Query : "What was the GDP of France in 2023?"
Step-back : "What are common GDP statistics for France?"
```

Retrieve sur le step-back → get general context → use for final answer.

Utile pour reasoning : trouver les **principes généraux** avant d'appliquer.

### RAG-Fusion (Rackauckas 2024)

Combo : Multi-Query + RRF.

```python
queries = generate_multi_queries(original_query, n=5)
result_sets = [retrieve(q, k=10) for q in queries]
fused = rrf(result_sets)  # Reciprocal Rank Fusion
```

Standard pratique. Bénéficie de [[Hybrid retrieval]] RRF.

### Routing

Si plusieurs indices / data sources, **router** la query vers la bonne :

```python
data_source = llm(f"Which database to search for: {query}\nOptions: [docs, code, customer_data]")
results = vector_dbs[data_source].search(query)
```

### Query classification

Classifier la query (factual / reasoning / generative) pour adapter le pipeline :
- Factual → small model + retrieve
- Reasoning → CoT + retrieve
- Casual → no retrieval

### Self-querying retriever (LangChain)

LLM extrait des **filters metadata** de la query :

```
Query : "Articles from 2023 about ML"
→ Filter : year=2023, tag=ML, query="ML articles"
```

### Conversational rewriting

Rewriter la query pour qu'elle soit **standalone** dans une conversation :

```
User : "What's the capital of France?"
AI   : "Paris"
User : "How big is it?"  ← ambiguous

Rewritten : "How big is Paris?"  ← standalone, retrievable
```

Critique pour chat-RAG.

### Hybrid : combine techniques

Pipeline production typique :

```
1. Query rewrite (clarifier, standalone)
2. Multi-query (generate 3-5 variants)
3. HyDE on each (generate hypothetical answer)
4. Hybrid retrieve (BM25 + dense) for each
5. RRF fusion
6. Rerank top-50 → top-10
7. Generate answer
```

### Quand quoi utiliser

| Query type | Best transform |
|---|---|
| Vague, court | HyDE |
| Multi-aspect | Decomposition |
| Mal écrite | Rewriting |
| Conversational follow-up | Standalone rewrite |
| Reasoning | Step-back |
| General | Multi-Query / RAG-Fusion |
| Sources multiples | Routing |
| Filters metadata | Self-querying |

### Best practices

1. **Mesurer recall@k avec et sans transform** : on tune
2. **HyDE default** pour queries vagues
3. **Multi-Query (3-5)** + RRF pour breadth
4. **Conversational rewrite** obligatoire en chat
5. **Pas combiner trop** : un transform suffit souvent
6. **Cost watch** : multi-query × hybrid × rerank = expensive
7. **Cache** transformations pour queries fréquentes
8. **A/B test** chaque addition

## Quand c'est utile

- **Chat with RAG** : standalone rewriting + HyDE
- **Search engine** : multi-query + RRF
- **Q&A complex** : decomposition + step-back
- **Multi-source** : routing
- **Faceted search** : self-querying retriever
- **Reasoning + retrieval** : step-back
- **Vague users queries** : HyDE
- **Multilingue** : translate query + retrieve

## Quand ça ne marche pas / pièges

- **Cost** : chaque transform = LLM call = $$$ et latency
- **HyDE hallucinate** : si la hypothèse contient erreurs, embedding pollué
- **Multi-query trop large** : trop de variations, perd focus
- **Decomposition over-split** : sub-queries pas atomiques
- **Step-back trop abstrait** : retrieve too general
- **Routing wrong** : query routée vers mauvais index
- **Eval bias** : test set crafted pour la transform → biais
- **Latency cumulée** : transform + retrieve + rerank → 2-5s
- **Conversational rewrite buggy** : LLM perd l'historique
- **Confuser query rewrite et expansion** : différents
- **Pas de fallback** : si transform fail, original query devrait passer

## Code minimal

```python
import anthropic
client = anthropic.Anthropic()

def call_llm(prompt, max_tokens=300):
    return client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=max_tokens,
        messages=[{"role": "user", "content": prompt}]
    ).content[0].text

# 1. HyDE
def hyde(query, embedder, vector_db, k=10):
    hypothesis = call_llm(f"Write a short passage that would answer this query:\n\n{query}\n\nPassage:")
    embedding = embedder.encode(hypothesis)
    return vector_db.search(embedding, k=k)

# 2. Multi-query
def multi_query(query, embedder, vector_db, n_variants=5):
    prompt = f"""Generate {n_variants} different ways to phrase this query, one per line:

Query: {query}

Variants:"""
    response = call_llm(prompt)
    queries = [line.strip() for line in response.split("\n") if line.strip()]
    queries = [query] + queries[:n_variants]
    
    all_results = []
    for q in queries:
        emb = embedder.encode(q)
        all_results.append(vector_db.search(emb, k=20))
    
    return rrf(all_results, k=60)

def rrf(rankings, k=60):
    """Reciprocal Rank Fusion."""
    scores = {}
    for ranking in rankings:
        for rank, doc in enumerate(ranking, 1):
            scores[doc.id] = scores.get(doc.id, 0) + 1 / (k + rank)
    return sorted(scores.items(), key=lambda x: -x[1])

# 3. Query decomposition
def decompose(query, embedder, vector_db):
    sub_queries_str = call_llm(f"""Decompose this query into 2-4 sub-questions, one per line:
{query}

Sub-questions:""")
    sub_queries = [s.strip() for s in sub_queries_str.split("\n") if s.strip()]
    
    contexts = []
    for sq in sub_queries:
        contexts.extend(vector_db.search(embedder.encode(sq), k=5))
    
    return contexts

# 4. Step-back prompting
def step_back(query, embedder, vector_db):
    abstract = call_llm(f"""Generate a more abstract/general version of this query:
Original: {query}
Abstract:""")
    
    abstract_context = vector_db.search(embedder.encode(abstract), k=5)
    specific_context = vector_db.search(embedder.encode(query), k=5)
    return abstract_context + specific_context

# 5. Conversational rewrite (standalone query)
def standalone_rewrite(query, history):
    history_str = "\n".join([f"{m['role']}: {m['content']}" for m in history])
    return call_llm(f"""Given this conversation:
{history_str}

The new query: "{query}"

Rewrite it as a standalone query that doesn't need conversation context:""")

# 6. Self-querying (extract metadata filters)
def self_query(query):
    response = call_llm(f"""Extract from this query:
1. The semantic search part (string)
2. Filters as JSON: {{tag, year, source}}

Query: {query}

Output JSON:""")
    import json
    return json.loads(response)

# 7. RAG-Fusion (Multi-Query + RRF)
def rag_fusion(query, embedder, vector_db, n_variants=5, k_per=20):
    variants = call_llm(f"Generate {n_variants} reformulations of: {query}").split("\n")
    all_rankings = []
    for v in variants + [query]:
        emb = embedder.encode(v)
        all_rankings.append(vector_db.search(emb, k=k_per))
    return rrf(all_rankings)

# 8. LangChain MultiQueryRetriever
# from langchain.retrievers.multi_query import MultiQueryRetriever
# from langchain_openai import ChatOpenAI
# retriever = MultiQueryRetriever.from_llm(
#     retriever=vector_db.as_retriever(),
#     llm=ChatOpenAI(temperature=0)
# )

# 9. Eval transforms
def eval_transform(eval_set, transform_fn, base_retriever):
    base_scores = []
    transform_scores = []
    for query, gold_docs in eval_set:
        base = base_retriever.search(query, k=10)
        transformed = transform_fn(query, base_retriever)
        base_scores.append(recall_at_k(base, gold_docs, k=10))
        transform_scores.append(recall_at_k(transformed, gold_docs, k=10))
    return sum(base_scores)/len(base_scores), sum(transform_scores)/len(transform_scores)
```

## Pour aller plus loin

- Gao et al., *Precise Zero-Shot Dense Retrieval without Relevance Labels* (HyDE, ACL 2023)
- Zheng et al., *Take a Step Back: Evoking Reasoning via Abstraction in Large Language Models* (ICLR 2024)
- Rackauckas, *RAG-Fusion: a New Take on Retrieval-Augmented Generation* (2024)
- *LangChain* MultiQueryRetriever, SelfQueryingRetriever docs
- *LlamaIndex* query transformations docs
- *Anthropic Contextual Retrieval* — combine avec query transforms
- **Liens internes** : [[RAG]], [[Advanced RAG]], [[Hybrid retrieval]], [[Reranking]], [[Chunking strategies]]
