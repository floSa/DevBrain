---
galaxie: wiki
nom: Synthetic data generation
alias: [Self-Instruct, Evol-Instruct, Magpie, Cosmopedia, model collapse, distillation]
type: concept
categorie: concept/llm-training
sous_categories: [synthetic-data, training, llm]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Wang 2022 (Self-Instruct), Xu 2023 (WizardLM), Shumailov 2023 (collapse)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, training, synthetic-data]
---

# Synthetic data generation

## TL;DR

**Générer du training data** via LLMs au lieu de l'annoter humainement. Techniques : **Self-Instruct** (Wang 2022, seed → generate variations), **Evol-Instruct** (WizardLM, complexify), **Persona-driven** (PersonaHub), **Magpie** (clever : tronquer chat template pour faire générer instruction par modèle), **Genstruct / Bonito** (generate from doc), **Constitutional AI critique**. Verification : math/code (verifiable), rejection sampling, Best-of-N. Datasets standards : **Cosmopedia** (HF, 25B tokens textbooks), **OpenMathInstruct** (NVIDIA), **Tulu 3** mixes. Risque #1 : **model collapse** (Shumailov 2023) — training recursif sur synthetic data dégrade. Best practice : mix real + synthetic.

## Le problème

Training data humain est :
- **Cher** (annotateurs $)
- **Lent**
- **Limité en quantité**
- **Couvre mal niches** (rare languages, specific domains)

→ **Generate avec LLMs** : massive quantity, low cost, customizable.

## L'idée

### Approches

#### Self-Instruct (Wang 2022)

Recipe original :

1. Start avec **seed** : 175 instructions humaines
2. **LLM generate** new instructions based on seed
3. **LLM generate** input/output for new instructions
4. Filter (quality, diversity)
5. Repeat

→ Alpaca dataset (52K) was created comme ça.

#### Evol-Instruct (Xu 2023 — WizardLM)

Take simple instructions, **complexify** via 5 operations :
- **In-depth Evolving** : add constraints
- **In-breadth Evolving** : generate new instruction same domain
- **Concretizing** : make specific
- **Increased Reasoning** : add reasoning steps
- **Complicate Input**

```
Original : "Write a story about a cat"
Evolved : "Write a 500-word story about a cat detective solving a mystery in Victorian London"
```

Produit harder examples → better model.

#### Self-Alignment (Sun 2023)

Modèle align lui-même via principles + AI critique.

#### Persona-driven (PersonaHub, Tu 2024)

Generate avec **personas** different :

```
Persona : "A 30-year-old software engineer from Tokyo"
→ generate instructions this persona would ask
```

Diversify le data.

#### Magpie (Xu 2024)

**Clever trick** : truncate chat template **before** user message → model auto-generates the instruction.

```
"<|start_header_id|>user<|end_header_id|>\n\n"
                                          ^ model continues here
                                          → outputs an instruction
```

Coût zéro de prompt engineering. Standard 2024+.

#### Genstruct / Bonito (Nayak 2024)

**Generate from documents** : given a paragraph, generate (instruction, response) about it.

Useful pour adapter à corpus spécifique.

#### Teacher-student distillation

Cf. [[Distillation]]. Use big model (GPT-4) → generate data → train small.

Standard chez Phi family.

#### Constitutional AI critique

LLM critique its own outputs → improvement.

```
1. LLM generate response
2. LLM critique : "Is this harmful?"
3. LLM revise based on critique
4. Use revised as training data
```

Standard Anthropic CAI.

### Verification

Pour data quality :

#### Math : verify answer

Run computation, check answer correct.

#### Code : run tests

Code completes → test exec. Pass → keep.

#### LLM-as-judge

Big LLM judges generated data quality. Filter low scores.

#### Self-consistency

Generate N times, keep only if majority consistent.

### Rejection sampling

Generate N candidates per prompt, keep best K (rated by judge or rule).

### Best-of-N

Sample N, take best by reward model.

### Considerations

#### Diversity

Naïve generation → mode collapse. Strategies :
- Variety in seeds
- Multiple personas
- Multiple models
- Temperature high
- Sub-sample

#### Model collapse (Shumailov 2023)

**Cancer théorique** : Recursive training on generated data → model **degrades** over time. Lost long tail.

**Mitigations** :
- Mix avec real data (humain)
- Don't iterate too many generations
- Diverse sources

#### Curation / filtering

Generate large → filter :
- Quality (LLM judge)
- Diversity (clustering, remove duplicates)
- Length
- Format
- Toxicity

#### Cost

Generate 1M examples avec GPT-4 = $10K+ easily. Plan budget.

#### Provider terms

Some providers prohibit using their outputs to train competing models. Check ToS.

### Datasets standards

#### Cosmopedia (HF)

25B tokens textbook-like synthétique. Used to train Cosmopedia, SmolLM.

#### OpenMathInstruct (NVIDIA)

Math instruction tuning data.

#### Tulu 3 mixes (AllenAI)

SFT mixture mêlant real + synthetic. State of the art open.

#### UltraChat, UltraFeedback

Synthetic chat / preference data.

#### Alpaca, Dolly, OpenAssistant

Older but standard.

#### WildChat

Real but anonymized GPT-3.5 conversations.

#### Magpie datasets

Auto-generated via Magpie trick. Open.

### Pipeline typique 2026

```
1. Seed : real data + curated examples
2. Generation :
   - GPT-4 / Claude teacher
   - Multiple techniques (Self-Instruct + Evol-Instruct + Magpie)
   - Multiple personas
3. Verification :
   - Verifiable tasks : math, code → automated check
   - Open-ended : LLM judge or human spot-check
4. Filtering :
   - Quality threshold
   - Diversity (clustering + sub-sample)
   - Decontamination (check vs eval sets)
5. Mix avec real data
6. Train (SFT or RLHF)
```

### Best practices

1. **Mix real + synthetic** : avoid model collapse
2. **Multiple teacher models** : diversity
3. **Verifiable tasks first** : math, code → auto-verify
4. **Quality > quantity** : LIMA showed 1K curated > 50K bruité
5. **Diversity engineering** : personas, seeds, parameters
6. **Decontaminate** : check vs benchmarks
7. **Iterate** : generate → train → eval → identify gaps → re-generate
8. **Open recipes** : Tulu 3, R1, Phi families published
9. **License check** : provider terms, training data sources
10. **Document** : data card, generation process

## Quand c'est utile

- **Domain adaptation** : medical, legal, niche
- **Multilingue** : génère in low-resource languages
- **Reasoning data** : math, CoT traces
- **Instruction tuning** : SFT data
- **DPO preferences** : pairwise from teacher
- **Safety training** : harmful + refusal pairs
- **Distillation** : teacher → student
- **Fine-tuning custom** : ton produit, ton ton
- **Bootstrap** : start projet without data
- **Adversarial training** : generate attack examples

## Quand ça ne marche pas / pièges

- **Model collapse** : iterative training degrades
- **Lack of diversity** : naive Self-Instruct → similar examples
- **Quality issues** : LLM hallucinate, propagate errors
- **Synthetic ≠ real** : distribution shift en production
- **Hallucinations propagate** : student inherit teacher's bugs
- **Cost** : $10K+ for 1M GPT-4 calls
- **License** : OpenAI ToS prohibits training competitors
- **Eval contamination** : synthetic resemble eval
- **Bias amplification** : LLM biases inherited
- **Open-ended tasks no verify** : hard to filter quality
- **Distillation gap** : student never matches teacher fully
- **Cherry-picking** : you select what fits, biased data

## Code minimal

```python
import anthropic
from openai import OpenAI

# 1. Self-Instruct (basic)
def self_instruct(seed_instructions, llm, n=100):
    new_instructions = []
    for _ in range(n):
        sample_seeds = random.sample(seed_instructions, 5)
        prompt = "Generate a new instruction similar to these examples:\n"
        for s in sample_seeds:
            prompt += f"- {s}\n"
        prompt += "\nNew instruction:"
        
        new_inst = llm(prompt)
        new_instructions.append(new_inst)
    return new_instructions

# 2. Evol-Instruct (complexify)
EVOL_OPERATIONS = [
    "Make this instruction more complex by adding constraints",
    "Rewrite to require step-by-step reasoning",
    "Add specific details and a unique scenario",
    "Increase difficulty for a graduate student",
]

def evol_instruct(instruction, llm):
    op = random.choice(EVOL_OPERATIONS)
    prompt = f"Instruction: {instruction}\nTask: {op}\nNew instruction:"
    return llm(prompt)

# 3. Magpie (clever trick)
# Truncate Llama-3 template before user message
from transformers import AutoTokenizer
tokenizer = AutoTokenizer.from_pretrained("meta-llama/Meta-Llama-3-8B-Instruct")

# Apply template but stop before any user content
template = tokenizer.apply_chat_template([], tokenize=False, add_generation_prompt=False)
# Add user turn header but no content
template += "<|start_header_id|>user<|end_header_id|>\n\n"

# Let model continue (it will generate a user instruction)
# Use vLLM or transformers
# model_outputs = model.generate(template)
# This is the user instruction !
# Then generate the assistant response too

# 4. Persona-driven
PERSONAS = [
    "A retired teacher in Florida",
    "A software engineer at Google",
    "A high school student in Nigeria",
    "A medical doctor in Mumbai",
]

def persona_gen(persona, llm):
    return llm(f"As {persona}, ask a question you might have:")

# 5. Generate (input, output) pair from doc (Genstruct-style)
def doc_to_instruction(doc, llm):
    prompt = f"""Given this document, generate a (question, answer) pair:
Document: {doc[:1000]}

Question:
"""
    question = llm(prompt)
    answer = llm(f"Question: {question}\nAnswer based on document:")
    return {"input": question, "output": answer}

# 6. Verifiable math : check answers
def gen_math_verifiable(llm, n=100):
    examples = []
    for _ in range(n):
        problem = llm("Generate a math problem with a numeric answer.")
        solution = llm(f"Solve step by step: {problem}")
        answer = extract_number(solution)
        verified_answer = verify_with_sympy_or_exec(problem)  # ground truth
        if answer == verified_answer:
            examples.append({"problem": problem, "solution": solution, "answer": answer})
    return examples

# 7. Code verifiable : run tests
def gen_code_verifiable(llm, problems):
    examples = []
    for problem in problems:
        code = llm(f"Write Python code: {problem['description']}")
        if run_tests(code, problem['tests']):
            examples.append({"problem": problem, "code": code})
    return examples

# 8. Best-of-N + reward model
def best_of_n(prompt, llm, reward_model, n=10):
    candidates = [llm(prompt, temperature=0.8) for _ in range(n)]
    scores = [reward_model.score(prompt, c) for c in candidates]
    return candidates[scores.index(max(scores))]

# 9. Diversity filtering (cluster + sub-sample)
from sentence_transformers import SentenceTransformer
from sklearn.cluster import KMeans

embedder = SentenceTransformer("all-MiniLM-L6-v2")

def diversity_filter(examples, n_clusters=50):
    embeddings = embedder.encode([ex["instruction"] for ex in examples])
    kmeans = KMeans(n_clusters=n_clusters).fit(embeddings)
    
    # Take 1 sample per cluster
    selected = []
    for c in range(n_clusters):
        in_cluster = [i for i, l in enumerate(kmeans.labels_) if l == c]
        if in_cluster:
            selected.append(examples[in_cluster[0]])
    return selected

# 10. Decontamination check
def decontamination(synthetic, eval_set, threshold=0.95):
    eval_embs = embedder.encode([ex["question"] for ex in eval_set])
    clean = []
    for s in synthetic:
        s_emb = embedder.encode(s["instruction"])
        scores = np.dot(eval_embs, s_emb)
        if scores.max() < threshold:
            clean.append(s)
    return clean

# 11. Use Magpie pre-built datasets
# from datasets import load_dataset
# ds = load_dataset("Magpie-Align/Magpie-Pro-300K-Filtered")
```

## Pour aller plus loin

- Wang et al., *Self-Instruct: Aligning Language Models with Self-Generated Instructions* (ACL 2023)
- Xu et al., *WizardLM: Empowering Large Language Models to Follow Complex Instructions* (Evol-Instruct, 2023)
- Xu et al., *Magpie: Alignment Data Synthesis from Scratch by Prompting Aligned LLMs with Nothing* (2024)
- Tu et al., *Scaling Synthetic Data Creation with 1,000,000,000 Personas* (PersonaHub, 2024)
- Shumailov et al., *The Curse of Recursion: Training on Generated Data Makes Models Forget* (2023) — model collapse
- *Cosmopedia* dataset HF blog
- AllenAI *Tulu 3* paper
- Anthropic *Constitutional AI* paper
- **Liens internes** : [[SFT]], [[Distillation]], [[Scaling laws]], [[RLHF and DPO]]
