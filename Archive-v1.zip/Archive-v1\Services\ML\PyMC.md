---
galaxie: dev
nom: PyMC
alias: [pymc3, PyMC4, PyMC5, probabilistic programming Python]
categorie: ml/framework
sous_categories: [bayesian, probabilistic-programming, mcmc, inference, pymc]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: [Stan, NumPyro, Pyro, TFP, Edward2]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, ml, bayesian, probabilistic-programming]
url_officiel: https://www.pymc.io/
url_docs: https://www.pymc.io/projects/docs/
url_repo: https://github.com/pymc-devs/pymc
---

# PyMC

## Pourquoi

Framework Python de **programmation probabiliste** : tu décris un modèle bayésien en code Python (priors, vraisemblance) et PyMC calcule la **distribution a posteriori** via MCMC (NUTS, HMC) ou inférence variationnelle (VI). Backend PyTensor (compile à GPU/CPU).

C'est l'outil de référence pour l'**inférence bayésienne** quand on veut quantifier l'incertitude sur des paramètres, mélanger priors et données, ou modéliser des structures hiérarchiques.

## Quand l'utiliser

- Petits échantillons où la quantification d'incertitude prime
- Modèles hiérarchiques (effets aléatoires, partial pooling)
- Combiner connaissance experte (priors informatifs) et données
- A/B testing bayésien (alternative aux tests fréquentistes)
- Modèles linéaires généralisés bayésiens
- Modèles temporels (Bayesian structural time series)
- Quand tu veux des intervalles de crédibilité plutôt que des [[Confidence intervals|IC fréquentistes]]

## Quand NE PAS l'utiliser

- Prédiction pure sans besoin d'incertitude → [[XGBoost]], [[LightGBM]], [[CatBoost]]
- Très gros datasets (≥ 1M lignes) → MCMC trop coûteux. Considérer VI ou modèles approchés
- Tu n'as pas envie d'apprendre les concepts bayésiens (priors, MCMC convergence, etc.)
- Production avec contraintes latence < 100ms → MCMC ne tient pas. VI possible mais limité.

## Pièges connus

- **Convergence MCMC** : toujours vérifier $\hat R$ (Gelman-Rubin) et trace plots. $\hat R$ > 1.01 = non-convergé.
- **Priors trop informatifs** → tu retrouves ton prior, pas une découverte
- **Priors trop vagues** → divergences MCMC. Utiliser des **weakly informative priors** (Gelman).
- **PyMC v3 → v4 → v5** : changements d'API importants. Vérifier la version dans la doc.
- **Reparameterization** sur hiérarchique : utilisable `centered` vs `non-centered` selon le contexte (divergences fréquentes en hiérarchique sans non-centered)
- **Sampling lent** : `nuts_sampler='numpyro'` ou `nuts_sampler='blackjax'` peut accélérer ×10
- **Visualisation** : utiliser [[ArviZ]] (compagnon natif) pour les diagnostics

## Liens

- Doc officielle : https://www.pymc.io/
- Repo : https://github.com/pymc-devs/pymc
- *Statistical Rethinking* (McElreath) — référence pédagogique
- *Bayesian Methods for Hackers* (Davidson-Pilon) — gratuit
- Concepts liés : [[Hypothesis testing]], [[Confidence intervals]], [[Bootstrap]] (alternative non-bayésienne)
- Alternatives : Stan (cmdstanpy), NumPyro (JAX), Pyro (PyTorch), TensorFlow Probability
