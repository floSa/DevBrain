---
name: update-wiki-outil
description: |
  Use this skill to patch an existing outil fiche in Wiki/Outils/.
  Triggers: "modifie l'outil", "patch <nom outil>", "mets à jour la fiche
  <outil>", "j'ai testé <outil>, score X", "<outil> a une nouvelle version",
  "transition status sur <outil>". Preserves the fiche, updates 'modified:'
  date, optionally transitions status (discovered → tested → used → abandoned).
---

# Skill — update-wiki-outil

## Quand l'utiliser

L'utilisateur veut **mettre à jour une fiche d'outil** déjà présente dans `Wiki/Outils/`. Cas typiques :
- Transition de statut : "j'ai testé [[anthropic-xlsx]], score 4" → `status: discovered → tested`, `score: 4`
- Mise à jour d'install : "la nouvelle commande pour `uv` c'est..." → patch `install_cmd:`
- Découverte d'un piège : append à "Pièges connus"
- Ajout d'un projet où on l'a utilisé : append à `mes_projets:`

## Pré-requis vault

Mode wiki. Périmètre `Wiki/Outils/`.

## Procédure

1. **Localiser** la fiche. Si nom ambigu, lister les outils existants.
2. **Lire** frontmatter + corps.
3. **Identifier le type de patch** :
   - **Transition status** (`discovered → tested`, etc.) → toujours demander confirmation
   - **Score** : seulement si testé (status ≥ tested), demander si pas évident
   - **Install cmd / source URL** : vérifier que le nouveau lien marche
   - **Mes projets** : append `[[<NomProjet>]]` à la liste
   - **Pièges** : append section avec contexte
   - **Section libre** : patch ciblé
4. **Préserver la voix** de la fiche existante (ton, structure).
5. **Mettre à jour `modified:`**.
6. **Si transition de status vers `abandoned`** : demander une raison ("pourquoi tu l'abandonnes ?"), append en section "Pièges connus" ou en commentaire HTML `<!-- abandonné le YYYY-MM-DD : <raison> -->`.
7. **Montrer le diff** avant écriture.

## Transition de status — workflow

```
discovered  → "découvert mais jamais testé"
   ↓
tested      → "essayé au moins une fois, je sais l'utiliser"
   ↓
used        → "utilisé en routine, score obligatoire"
   ↓
abandoned   → "testé puis rejeté, raison à documenter"
```

Une transition ne se fait que **en avant** dans ce workflow. Exception : `abandoned → discovered` si on veut le re-tester un jour, mais préfère créer une note dans la fiche.

## Anti-patterns à éviter

- **Modifier `status: used` sans score** — le score devient obligatoire à ce stade
- **Effacer le contenu existant** lors d'un patch frontmatter — patch ciblé
- **Skip la transition** : sauter directement de `discovered` à `used` sans `tested` est suspect, demander confirmation
- **Oublier le frontmatter `modified:`**

## Voir aussi

- `add-wiki-outil` (création)
- `audit-skills` (hygiène globale, suggère les transitions à faire)
- `expand-stub` (étoffer une fiche encore stub)
