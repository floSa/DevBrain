---
galaxie: wiki
nom: Bellman equations
alias: [Bellman, équations de Bellman, Bellman optimality, value iteration, policy iteration]
type: concept
categorie: concept/ml
sous_categories: [rl, bellman, dynamic-programming, fixed-point]
domaines: [ml-eng, ai-eng]
maturite: established
auteurs_cles: [Bellman 1957, Howard 1960, Sutton & Barto]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, rl, bellman, dynamic-programming]
---

# Bellman equations

## TL;DR

Récursions qui relient la valeur d'un état à celle de ses successeurs. Deux familles : **Bellman expectation** (évaluation d'une politique fixée), **Bellman optimality** (politique optimale). Elles définissent un **point fixe** sur lequel s'appuient quasiment tous les algos de RL — Q-learning est juste une mise à jour stochastique de Bellman optimality, value iteration une itération directe. Comprendre Bellman = comprendre pourquoi le RL marche.

## Le problème

On veut calculer $V^\pi(s)$ (retour espéré en partant de $s$ et suivant $\pi$). Définition brute :

$$ V^\pi(s) = \mathbb{E}_\pi \left[\sum_{t=0}^{\infty} \gamma^t r_{t+1} \,\Big|\, s_0 = s \right] $$

Ça implique de sommer sur toutes les trajectoires possibles → impraticable. **Bellman** : utiliser la propriété de Markov pour exprimer $V^\pi(s)$ en fonction de $V^\pi(s')$ pour les successeurs.

## L'idée

### Bellman expectation equation (politique fixée)

Pour une politique $\pi$ donnée :

$$ V^\pi(s) = \sum_a \pi(a|s) \sum_{s'} P(s'|s,a) \big[ R(s,a,s') + \gamma V^\pi(s') \big] $$

En forme compacte vectorielle (MDP fini) :

$$ \mathbf{V}^\pi = \mathbf{R}^\pi + \gamma \mathbf{P}^\pi \mathbf{V}^\pi $$

$\Rightarrow \mathbf{V}^\pi = (I - \gamma \mathbf{P}^\pi)^{-1} \mathbf{R}^\pi$ (résolvable directement si $|\mathcal{S}|$ petit).

De même pour $Q^\pi$ :

$$ Q^\pi(s, a) = \sum_{s'} P(s'|s,a) \big[ R(s,a,s') + \gamma \sum_{a'} \pi(a'|s') Q^\pi(s', a') \big] $$

### Bellman optimality equation

Pour la **politique optimale** $\pi^*$ :

$$ V^*(s) = \max_a \sum_{s'} P(s'|s,a) \big[ R(s,a,s') + \gamma V^*(s') \big] $$

$$ Q^*(s, a) = \sum_{s'} P(s'|s,a) \big[ R(s,a,s') + \gamma \max_{a'} Q^*(s', a') \big] $$

Le $\max$ remplace l'espérance sur la politique. Si on connaît $Q^*$, la politique optimale est gloutonne :

$$ \pi^*(s) = \arg\max_a Q^*(s, a) $$

### L'opérateur de Bellman et le point fixe

Définissons l'**opérateur de Bellman optimality** $\mathcal{T}^* : \mathbb{R}^{|\mathcal{S}|} \to \mathbb{R}^{|\mathcal{S}|}$ :

$$ (\mathcal{T}^* V)(s) = \max_a \sum_{s'} P(s'|s,a) \big[ R(s,a,s') + \gamma V(s') \big] $$

**Propriété clé** : $\mathcal{T}^*$ est une **contraction** au sens $\|.\|_\infty$ de coefficient $\gamma$ :

$$ \|\mathcal{T}^* V_1 - \mathcal{T}^* V_2\|_\infty \le \gamma \|V_1 - V_2\|_\infty $$

Par le théorème du point fixe de Banach : il existe un **unique** $V^*$ tel que $V^* = \mathcal{T}^* V^*$, et **n'importe quelle initialisation** $V_0$ converge vers $V^*$ en itérant.

C'est **value iteration**. C'est aussi la base de Q-learning et DQN.

### Value iteration

Algo direct quand le MDP est connu :

```
V ← 0 (arbitraire)
répéter jusqu'à convergence :
    pour chaque s :
        V(s) ← max_a Σ_s' P(s'|s,a) [R(s,a,s') + γ V(s')]
```

Convergence en $O(\log(1/\epsilon) / (1-\gamma))$ itérations pour précision $\epsilon$.

### Policy iteration

Alterne :
1. **Évaluation** : calculer $V^\pi$ pour $\pi$ courante (résoudre Bellman expectation, exact ou itératif)
2. **Amélioration** : $\pi'(s) = \arg\max_a Q^\pi(s, a)$
3. Si $\pi' = \pi$ : stop, sinon $\pi \leftarrow \pi'$

Converge en **nombre fini d'étapes** sur MDP fini (mais chaque évaluation peut être chère).

### Lien avec Q-learning

Q-learning n'a pas $P$, donc utilise une **estimation stochastique** de Bellman optimality :

$$ Q(s, a) \leftarrow Q(s, a) + \alpha \big[ \underbrace{r + \gamma \max_{a'} Q(s', a')}_{\text{cible Bellman}} - Q(s, a) \big] $$

C'est une **descente stochastique** sur le résidu de Bellman. La cible $r + \gamma \max_{a'} Q(s', a')$ est un échantillon non biaisé (sous hypothèses) de $\mathcal{T}^* Q$.

**DQN** = Q-learning + réseau de neurones + replay buffer + target network (pour stabiliser la cible $\mathcal{T}^* Q$).

### Equation d'optimalité de Bellman et programmation dynamique

Bellman a introduit ces équations en 1957 dans *Dynamic Programming*. Tout problème de décision optimale séquentielle qui satisfait la **principle of optimality** ("toute sous-politique d'une politique optimale est optimale sur le sous-problème restant") admet une équation de Bellman.

Application au-delà du RL : algorithmes du plus court chemin (Dijkstra, Bellman-Ford), shortest edit distance, gestion d'inventaire, options pricing.

### Cas particuliers et nuances

#### γ = 1 (récompense non actualisée)

Risque de divergence si épisodes infinis. Utilisé pour **épisodes finis** avec terminal states absorbants. Sinon, normaliser ou prendre $\gamma < 1$.

#### Récompense moyenne (average reward MDP)

Pour processus stationnaires sans γ : objectif $\rho = \lim_{T \to \infty} \frac{1}{T} \mathbb{E}[\sum r_t]$. Équations de Bellman modifiées (poisson équations).

#### Soft Bellman (max-entropy RL)

Remplace $\max_a$ par log-sum-exp :

$$ V^*(s) = \tau \log \sum_a \exp(Q^*(s,a) / \tau) $$

C'est la base de SAC. Encourage l'exploration, lisse la politique.

#### Bellman residual

Différence $\mathcal{T}^* V - V$. Minimiser le résidu = autre formulation, parfois utilisée en deep RL (mais biais asymptotique).

## Quand c'est utile

- **Comprendre pourquoi Q-learning converge** : Bellman optimality contraction
- **Implémenter un solveur MDP exact** : value iteration / policy iteration sur MDP fini
- **Diagnostic deep RL** : la cible TD ($r + \gamma \max Q(s', \cdot)$) c'est Bellman, savoir lire ça change tout
- **Choisir $\gamma$ informément** : impact direct sur le rayon de contraction
- **Justifier des bornes** : tous les bounds RL passent par les Bellman residuals
- **Algorithmes hors RL** : shortest path, decision-tree pricing, scheduling

## Quand ça ne marche pas / pièges

- **MDP infini / continu** : $\mathcal{T}^*$ reste contractant mais la résolution exacte est impossible → function approximation
- **$P$ inconnu** : on ne peut pas calculer la moyenne sur $s'$ → estimation par échantillonnage (Monte Carlo / TD)
- **Function approximation + bootstrapping + off-policy = deadly triad** (Sutton) : la contraction se perd, divergence possible (e.g. Baird's counterexample)
- **Max optimiste** : en présence de bruit, $\max_a Q(s', a)$ est biaisé vers le haut → Double Q-learning, target networks
- **γ proche de 1** : rayon de contraction $\gamma$ proche de 1 → convergence lente, propagation lente
- **Non-stationnarité** : $\mathcal{T}^*$ change si l'environnement bouge → théorèmes invalides
- **Récompenses très éparses** : V reste à 0 partout sauf près du goal → propagation très lente, motive reward shaping et exploration smart

## Code minimal

```python
# Value iteration sur MDP fini connu
import numpy as np

def value_iteration(P, R, gamma=0.99, eps=1e-6, max_iter=1000):
    """
    P : array (S, A, S) — probas de transition
    R : array (S, A)    — récompense espérée
    """
    n_states = P.shape[0]
    V = np.zeros(n_states)
    for it in range(max_iter):
        # Q(s,a) = R(s,a) + γ Σ_s' P(s'|s,a) V(s')
        Q = R + gamma * (P * V[np.newaxis, np.newaxis, :]).sum(axis=2)
        V_new = Q.max(axis=1)
        if np.max(np.abs(V_new - V)) < eps:
            print(f"Convergé en {it+1} itérations")
            break
        V = V_new
    policy = Q.argmax(axis=1)
    return V, policy
```

```python
# Policy iteration
def policy_evaluation(P, R, policy, gamma=0.99, eps=1e-6, max_iter=500):
    n_states = P.shape[0]
    V = np.zeros(n_states)
    P_pi = P[np.arange(n_states), policy]          # (S, S)
    R_pi = R[np.arange(n_states), policy]          # (S,)
    for _ in range(max_iter):
        V_new = R_pi + gamma * P_pi @ V
        if np.max(np.abs(V_new - V)) < eps:
            break
        V = V_new
    return V

def policy_iteration(P, R, gamma=0.99):
    n_states, n_actions = P.shape[0], P.shape[1]
    policy = np.zeros(n_states, dtype=int)
    while True:
        V = policy_evaluation(P, R, policy, gamma)
        Q = R + gamma * (P * V[np.newaxis, np.newaxis, :]).sum(axis=2)
        new_policy = Q.argmax(axis=1)
        if np.array_equal(new_policy, policy):
            return V, policy
        policy = new_policy
```

```python
# Mise à jour Q-learning : Bellman optimality stochastique
def q_learning_update(Q, s, a, r, s_next, done, alpha=0.1, gamma=0.99):
    target = r if done else r + gamma * Q[s_next].max()
    Q[s, a] += alpha * (target - Q[s, a])
    return Q
```

```python
# Cible TD pour DQN (PyTorch)
import torch

def td_target(rewards, next_states, dones, q_target_net, gamma=0.99):
    with torch.no_grad():
        next_q = q_target_net(next_states).max(dim=1).values
        target = rewards + gamma * next_q * (1.0 - dones.float())
    return target
# Loss = MSE(q_net(states).gather(1, actions), target)
```

## Pour aller plus loin

- Sutton & Barto, ch. 3 (Bellman equations) et ch. 4 (Dynamic Programming) — http://incompleteideas.net/book/the-book.html
- Bellman, *Dynamic Programming* (1957) — l'original
- Bertsekas, *Dynamic Programming and Optimal Control* (4e éd.) — version musclée
- Tsitsiklis & Van Roy, *An Analysis of Temporal-Difference Learning with Function Approximation* (1997) — la deadly triad
- **Liens internes** : [[Markov Decision Process]], [[Value functions]], [[Reinforcement learning]], [[Convexity]] (pour la contraction), [[Policy gradient]]
