---
galaxie: wiki
nom: LLM caching
alias: [semantic cache, exact cache, GPTCache, prompt caching, KV cache reuse]
type: concept
categorie: concept/llm-production
sous_categories: [caching, optimization, llm-ops, cost]
domaines: [ai-eng]
maturite: established
auteurs_cles: []
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, caching, production, cost]
---

# LLM caching

## TL;DR

Plusieurs niveaux de cache pour économiser cost / latency LLM apps : **exact match cache** (Redis hash key, simple), **semantic cache** (embedding similarity, GPTCache), **prompt caching provider** (Anthropic/OpenAI/Gemini — 50-90% discount sur cache hits), **KV cache reuse server** (vLLM, SGLang RadixAttention). En production : combiner exact + semantic + provider prompt cache → **50-90% économies**. Standard chez chatbots haute QPS, RAG, voice agents. Trade-off : staleness, cache invalidation, infra complexité.

## Le problème

LLM calls = $$$. Beaucoup de queries similaires en production :
- "How do I reset my password?" demandé 10000x/jour
- Same system prompt sur toutes les requests
- RAG sur même chunks souvent

→ **Cacher** ce qui peut l'être.

## L'idée

### Niveaux de cache

```
[User query]
    │
    ▼
[Exact match cache]  ──hit──→ Return cached
    │ miss
    ▼
[Semantic cache]      ──hit──→ Return cached
    │ miss
    ▼
[LLM call avec prompt caching]
    │
    ▼
[Cache response]
```

### Exact match cache

Hash de la query (or query + context). Si match exact → cached response.

```python
import hashlib
import redis

r = redis.Redis()

def cached_llm_call(query):
    key = "llm:" + hashlib.sha256(query.encode()).hexdigest()
    cached = r.get(key)
    if cached:
        return cached.decode()
    
    response = llm_call(query)
    r.setex(key, 3600, response)  # 1h TTL
    return response
```

- Trivial à implémenter
- Hit rate **bas** (queries varient légèrement)
- Use case : FAQ, exact same queries

### Semantic cache

Embedder query, vector DB lookup, si **similarité haute** → cached.

```
Query "How reset password?" → embed → search vector DB
If top match similarity > 0.95 → return cached answer
```

#### GPTCache

Library standard :
- Embedding + vector DB intégré
- TTL, eviction policies
- Multi-store backends

```python
from gptcache import cache
from gptcache.adapter import openai
cache.init()
cache.set_openai_key()
# Now openai calls auto-cached semantically
```

#### LangChain CacheManager

Built-in semantic cache.

#### Custom

```python
embedder = SentenceTransformer("all-MiniLM-L6-v2")
vector_db = FAISS(dim=384)

def semantic_cache_call(query, threshold=0.95):
    query_emb = embedder.encode(query)
    score, cached_response = vector_db.search(query_emb, k=1)
    if score > threshold:
        return cached_response
    
    response = llm_call(query)
    vector_db.add(query_emb, response)
    return response
```

**Trade-off** :
- Higher threshold → fewer false hits, lower hit rate
- Lower threshold → more hits, but wrong responses possible

### Prompt caching (provider-side)

Voir [[Context engineering]] pour détails.

Anthropic, OpenAI, Gemini : cacher prefix réutilisé (system prompt, few-shot, RAG context).

```python
response = anthropic.messages.create(
    system=[{"type": "text", "text": "Long system prompt...", "cache_control": {"type": "ephemeral"}}],
    messages=[...]
)
```

**Économies massives** sur input cost (50-90% discount sur cache hits).

### KV cache reuse (server-side)

vLLM, SGLang, TGI : reuse KV cache when prefixes match across requests.

- **vLLM prefix caching** : automatic
- **SGLang RadixAttention** : radix tree pour shared prefixes
- **TGI** : similar

Standard pour high-throughput serving avec system prompts partagés.

### Multi-level cache

```python
def smart_cache(query):
    # 1. Exact
    if exact_cached := exact_cache.get(query):
        return exact_cached
    
    # 2. Semantic
    if sem_cached := semantic_cache.get(query, threshold=0.95):
        return sem_cached
    
    # 3. LLM call (with prompt caching provider-side)
    response = anthropic.messages.create(
        system=[{"type": "text", "text": SYSTEM_PROMPT,
                 "cache_control": {"type": "ephemeral"}}],
        messages=[{"role": "user", "content": query}]
    )
    
    # Update caches
    exact_cache.set(query, response)
    semantic_cache.add(query, response)
    
    return response
```

### Cache invalidation

#### TTL

Time-To-Live : response expires after X (5 min, 1 hour, 1 day).

#### Versioning

Cache key includes version. Bump version → invalidate all.

```python
key = f"llm:v{PROMPT_VERSION}:{hash(query)}"
```

#### Tag-based

Tag queries with feature/version, invalidate by tag.

#### LRU eviction

Quand cache full, evict least-recently-used.

### Quand cacher quoi

| Type | Cache ? | Lifetime |
|---|:-:|---|
| FAQ answers | ✓ | long (days) |
| Personalized answers | × | n/a |
| Time-sensitive (news) | ~ | short (minutes) |
| Static info (capital cities) | ✓ | very long |
| RAG retrieved chunks | ~ | medium |
| User-specific context | × | n/a |
| Tool results | ~ | varies |
| Code completion | ~ | short |
| Streaming partial | × | n/a |

### Hit rate optimization

Pour boost hit rate :
- **Normalize queries** : lowercase, strip whitespace
- **Strip filler words** ("please", "could you")
- **Templated queries** : extract variables, cache template

### Cost analysis

Si call non-cached = $0.01, et hit rate semantic = 30% :
- 1M queries → 700K calls × $0.01 = $7K (au lieu de $10K)
- + 300K semantic lookups × $0.0001 = $30

Économies = $3K / month sur 1M queries. Compound rapidement.

### Best practices

1. **Toujours prompt caching** (provider) : free easy gain
2. **Multi-level** : exact → semantic → LLM
3. **TTL adapté** au use case
4. **Monitor hit rate** : optimize threshold
5. **Versioning prompts** : invalidate on update
6. **Skip cache for** : personalized, time-sensitive, low-trust
7. **Separate caches** par user / tenant (privacy)
8. **Audit log** : track cache hits / misses
9. **A/B test** thresholds
10. **Cache eviction strategy** clear

## Quand c'est utile

- **Chatbot FAQ** : repetitive queries
- **High QPS** : amortize cost
- **RAG sur small corpus** : same docs retrieved often
- **Multi-tenant SaaS** : shared prompts
- **Voice agents** : real-time, latency-sensitive
- **Cost-sensitive** : startup, free tier
- **Repeated tool calls** : same args same result
- **Public APIs** : open use cases

## Quand ça ne marche pas / pièges

- **Personalized responses** : cache pollutes across users
- **Stale responses** : real-time data wrong from cache
- **Semantic false positives** : "Reset password" matches "Reset modem" → wrong cached
- **Privacy** : cached PII leaks to next user
- **Cache invalidation** : "the hardest thing in computer science"
- **High variance queries** : never hits cache
- **Hit rate low** : overhead pour rien
- **Inconsistent behavior** : cached vs fresh different
- **Cache cost** : Redis / vector DB infra
- **Memory growth** : cache grows unbounded sans eviction
- **Streaming + cache** : tricky to combine
- **A/B test pollution** : cache hits user wrong variant

## Code minimal

```python
import hashlib
import redis
import json
from sentence_transformers import SentenceTransformer
import numpy as np

# 1. Exact cache
class ExactCache:
    def __init__(self, ttl=3600):
        self.r = redis.Redis()
        self.ttl = ttl
    
    def key(self, query, **kwargs):
        full = json.dumps({"query": query, **kwargs}, sort_keys=True)
        return "llm:exact:" + hashlib.sha256(full.encode()).hexdigest()
    
    def get(self, query, **kwargs):
        v = self.r.get(self.key(query, **kwargs))
        return json.loads(v) if v else None
    
    def set(self, query, response, **kwargs):
        self.r.setex(self.key(query, **kwargs), self.ttl, json.dumps(response))

# 2. Semantic cache (custom simple)
class SemanticCache:
    def __init__(self, threshold=0.95):
        self.embedder = SentenceTransformer("all-MiniLM-L6-v2")
        self.embeddings = []
        self.responses = []
        self.threshold = threshold
    
    def get(self, query):
        if not self.embeddings:
            return None
        q_emb = self.embedder.encode(query)
        scores = np.dot(np.array(self.embeddings), q_emb)
        max_score = scores.max()
        if max_score > self.threshold:
            return self.responses[scores.argmax()]
        return None
    
    def set(self, query, response):
        q_emb = self.embedder.encode(query)
        self.embeddings.append(q_emb)
        self.responses.append(response)

# 3. GPTCache
from gptcache import cache
from gptcache.adapter import openai
from gptcache.embedding import OpenAI as GPTCacheOpenAI
from gptcache.manager import CacheBase, VectorBase, get_data_manager
from gptcache.similarity_evaluation.distance import SearchDistanceEvaluation

cache.init(
    embedding_func=GPTCacheOpenAI().to_embeddings,
    data_manager=get_data_manager(
        CacheBase("sqlite"),
        VectorBase("faiss", dimension=1536),
    ),
    similarity_evaluation=SearchDistanceEvaluation(),
)
# Then OpenAI calls auto-cached
response = openai.ChatCompletion.create(...)

# 4. Anthropic prompt caching
import anthropic
client = anthropic.Anthropic()

response = client.messages.create(
    model="claude-3-7-sonnet-latest",
    max_tokens=1024,
    system=[
        {"type": "text", "text": SYSTEM_PROMPT, "cache_control": {"type": "ephemeral"}}
    ],
    messages=[{"role": "user", "content": user_query}]
)

# 5. Combined multi-level
class MultiLevelCache:
    def __init__(self):
        self.exact = ExactCache()
        self.semantic = SemanticCache()
    
    def call(self, query, llm_fn):
        # 1. Exact
        if cached := self.exact.get(query):
            return {"response": cached, "source": "exact"}
        
        # 2. Semantic
        if cached := self.semantic.get(query):
            return {"response": cached, "source": "semantic"}
        
        # 3. LLM
        response = llm_fn(query)
        self.exact.set(query, response)
        self.semantic.set(query, response)
        return {"response": response, "source": "llm"}

# 6. Cache key avec versioning
PROMPT_VERSION = "v3"
def versioned_key(query):
    return f"llm:{PROMPT_VERSION}:{hashlib.sha256(query.encode()).hexdigest()}"

# 7. Per-user cache
def user_cache_key(user_id, query):
    return f"llm:user:{user_id}:{hashlib.sha256(query.encode()).hexdigest()}"

# 8. Monitor hit rate
class CachedLLM:
    def __init__(self):
        self.hits = 0
        self.misses = 0
        self.cache = MultiLevelCache()
    
    def call(self, query):
        result = self.cache.call(query, llm_fn=actual_llm_call)
        if result["source"] in ("exact", "semantic"):
            self.hits += 1
        else:
            self.misses += 1
        return result["response"]
    
    @property
    def hit_rate(self):
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0
```

## Pour aller plus loin

- *GPTCache* documentation (Zilliz)
- Anthropic, *Prompt Caching* docs
- OpenAI, *Prompt Caching in the API* (Oct 2024)
- Google, *Context Caching* in Gemini docs
- *vLLM*, *SGLang* prefix caching docs
- LangChain CacheManager
- **Liens internes** : [[Context engineering]], [[Inference optimization]], [[LLM observability]], [[Routing and cascading]]
