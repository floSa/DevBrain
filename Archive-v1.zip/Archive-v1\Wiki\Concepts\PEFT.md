---
galaxie: wiki
nom: PEFT (LoRA, QLoRA, DoRA)
alias: [PEFT, LoRA, QLoRA, DoRA, adapters, parameter-efficient]
type: concept
categorie: concept/llm-training
sous_categories: [peft, lora, qlora, fine-tuning, llm]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Hu 2021 (LoRA), Dettmers 2023 (QLoRA), Liu 2024 (DoRA)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, fine-tuning, peft, lora]
---

# PEFT — Parameter-Efficient Fine-Tuning

## TL;DR

Fine-tuner un LLM **sans modifier tous les params** : on apprend seulement de **petits adaptateurs** (1% des params) qui modifient le comportement. Standard : **LoRA** (Low-Rank Adaptation, Hu 2021) — ajoute matrices low-rank aux linears. **QLoRA** (Dettmers 2023) : LoRA + base model en **4-bit** → fine-tune un 70B sur 1 GPU 48GB. **DoRA** : décomposition magnitude/direction, meilleur que LoRA. Permet à un dev seul de fine-tuner un Llama 70B chez soi. Inference : merge LoRA dans base ou serve plusieurs LoRA en parallèle (S-LoRA, LoRAX). **Standard de facto** pour fine-tuning custom 2024-2026.

## Le problème

Fine-tuning full d'un LLM 70B :
- **VRAM** : ~280GB (weights bf16) + activations + optimizer states → 1000+ GB
- **Compute** : énorme, des jours sur 8xH100
- **Stockage** : une copie complète par task spécialisée
- **Inférence** : impossible de swap entre modèles fine-tunés rapidement

→ Approche standard : ne fine-tuner qu'un **petit sous-ensemble** des params (0.1 - 5%).

## L'idée

### LoRA — Low-Rank Adaptation (Hu 2021)

**Insight** : les updates lors du fine-tuning ont **rang faible** intrinsèque. Au lieu d'updater $W \in \mathbb{R}^{d \times k}$ :

$$ W' = W + \Delta W $$

décomposer $\Delta W = B A$ avec $A \in \mathbb{R}^{r \times k}$, $B \in \mathbb{R}^{d \times r}$, $r \ll \min(d, k)$.

```
        Input
          │
   ┌──────┴──────┐
   │             │
   ▼             ▼
[W frozen]     [A] (r × k)
   │             │
   │             ▼
   │           [B] (d × r)
   │             │
   ▼             │
   └──────┬──────┘
          ▼
        Output
```

**Hyperparams** :
- **$r$** : rank (typ. 4, 8, 16, 32, 64). Plus haut = plus de capacité.
- **$\alpha$** : scaling factor. $\Delta W = (\alpha/r) BA$. Typ. $\alpha = 2r$ ou $\alpha = 16$.
- **target_modules** : sur quelles linears appliquer (q_proj, k_proj, v_proj, o_proj, FFN gates). Llama : "all-linear" courant.
- **dropout** : 0.05-0.1 sur LoRA.

**Économie** : LoRA(r=16) sur Llama 7B = ~40M params (vs 7B full). 1-2% du modèle.

#### Init

- $A$ : initialisé gaussien
- $B$ : initialisé zéro → $\Delta W = 0$ au départ (modèle = base)

### QLoRA (Dettmers 2023)

**Combo** : LoRA sur top d'un base model **quantifié 4-bit (NF4)**.

```
[Base model in 4-bit NF4]  ← frozen, en mémoire 4-bit
        +
[LoRA adapters en BF16]    ← trainable
        =
Fine-tunable in 1/4 mémoire
```

**Innovations** :
- **NF4** (NormalFloat 4-bit) : meilleur que int4 pour weights gaussiens
- **Double quantization** : quantifier les quantization constants → encore moins
- **Paged optimizers** : offload sur CPU à la volée

**Résultat** : Llama 70B fine-tune sur **single A100 80GB** ou même **24GB consumer GPU**. Démocratisation totale.

### DoRA — Weight-Decomposed Low-Rank Adaptation (Liu 2024)

Décompose chaque weight en **magnitude** $m$ et **direction** $V$ :

$$ W = m \frac{V}{\|V\|} $$

LoRA modifie direction, $m$ aussi fine-tuned. Meilleur que LoRA simple pour même nb params.

### Autres variantes PEFT

#### LoRA+

LR différentielle entre $A$ et $B$ (Hayou 2024).

#### AdaLoRA

Rank dynamic par layer, alloue plus là où c'est utile.

#### rsLoRA (rank-stabilized)

$\alpha = \alpha_0 / \sqrt{r}$ au lieu de $\alpha_0 / r$. Permet rank plus haut.

#### PiSSA

Init $A, B$ par SVD du weight original au lieu de random. Convergence plus rapide.

#### VeRA

Matrices random shared entre layers, on apprend que des vecteurs de scaling. Encore moins de params.

#### Adapters (Houlsby 2019)

Original : insérer des **MLP bottleneck** dans le modèle. Précurseur de LoRA.

#### Prefix tuning, Prompt tuning, P-tuning

Apprendre des **virtual tokens** prepended au prompt. Très peu de params, mais souvent moins performant que LoRA.

#### IA³

Apprendre des **vecteurs de scaling** (no add). Extrêmement compact.

#### BitFit

Fine-tuner uniquement les **biases**. Trivial mais surprenamment OK.

### LoRA en pratique

#### Merging

Après training, merger : $W' = W + BA$. **Pas d'overhead** en inference.

```python
model = peft_model.merge_and_unload()
```

#### Switching adapters

Garder LoRA séparés, switcher à l'inférence. Permet **multi-task** sur 1 base model.

#### Stacking / composition

Plusieurs LoRAs combinés (additif ou via routing). Recherche active (X-LoRA, LoRA Hub).

#### Multi-LoRA serving

- **S-LoRA** (2023) : serving milliers de LoRA en parallèle, batching dynamique
- **LoRAX** : production serving
- **vLLM** : multi-LoRA natif

### Choix de hyperparams

| Paramètre | Valeur typique | Notes |
|---|---|---|
| `r` (rank) | 8-32 | 16 default solid. Tâche complexe → 32-64. |
| `alpha` | $2r$ ou 16 | Plus haut = updates plus forts |
| `target_modules` | q,k,v,o + gate,up,down | "all-linear" simple, marche |
| `dropout` | 0.05 | Évite overfit |
| `learning rate` | 1e-4 à 5e-4 | 10x supérieur à full SFT |
| `batch size` | 4-32 | Limited by VRAM |
| `epochs` | 1-5 | Peu d'epochs suffisent |

### Quand LoRA suffit, quand full FT nécessaire

**LoRA OK** :
- Style adjustment
- Domain adaptation modérée
- Instruction tuning
- Petite quantité de data
- Fast experimentation

**Full FT (ou très high rank LoRA)** :
- Add new capability totally absent (e.g. nouvelle langue)
- Large data, gros budget
- Compete state-of-the-art benchmarks
- Vocab extension

### Best practices

1. **Commencer LoRA** avant full FT — 100x moins cher
2. **QLoRA pour gros modèles** (>13B) en GPU limité
3. **Target all-linear** ou au moins q,k,v,o + FFN gates
4. **rank 16 default**, monter à 64 si pas converge
5. **alpha = 2*r** start point
6. **Merge pour inference simple**, garder séparé pour multi-task
7. **Eval LoRA vs full FT** pour validation
8. **Library** : `peft` (HF) standard
9. **Save adapters seulement** (40 MB) au lieu du modèle full
10. **Online iterative** : DPO → LoRA refresh

## Quand c'est utile

- **Fine-tune sur consumer GPU** : QLoRA Llama 70B sur RTX 4090
- **Multi-task serving** : 1 base model + N adapters
- **Rapid iteration** : 1h training au lieu de 1 jour
- **Compute-limited research** : explorer hyperparams
- **Domain customization** : médical, légal, customer-specific
- **A/B testing prompts** : 2 LoRAs vs prompts
- **Edge / on-device** : adapters < 50 MB
- **Continuous learning** : nouvelle LoRA par client

## Quand ça ne marche pas / pièges

- **Rank trop bas** : pas capturer changement → modèle pas adapté
- **Mauvais target_modules** : si on n'inclut que q,v alors qu'il fallait FFN → suboptimal
- **LR trop bas** (comme full FT) : LoRA needs higher LR (~10x)
- **QLoRA + merge** : merger un 4-bit LoRA back peut perdre precision. Garder séparé.
- **Catastrophic forgetting** sur LoRA aggressive : meme effet que full FT
- **LoRA stacking conflicts** : combiner 2 LoRAs qui modifient même direction = conflit
- **Eval sur train** : voir LoRA convergent sur train ne dit rien sur generalization
- **DoRA implem buggy** : nouvelle méthode, vérifier la stabilité
- **Activation checkpointing requis** : pour gros models, mettre `gradient_checkpointing=True`
- **Tokenizer mismatch** : LoRA trained sur tokenizer v1, inference avec v2 → mort
- **Embedding LoRA** : ne pas appliquer à embeddings (overkill, ou alors via rsLoRA)

## Code minimal

```python
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, TaskType
import torch

model_id = "meta-llama/Meta-Llama-3-8B"

# QLoRA setup : base model en 4-bit
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",        # NormalFloat 4-bit
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_use_double_quant=True,   # Quantize the quantization constants
)

model = AutoModelForCausalLM.from_pretrained(
    model_id,
    quantization_config=bnb_config,
    device_map="auto"
)
model = prepare_model_for_kbit_training(model)
tokenizer = AutoTokenizer.from_pretrained(model_id)

# LoRA config
lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                    "gate_proj", "up_proj", "down_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type=TaskType.CAUSAL_LM,
)

model = get_peft_model(model, lora_config)
model.print_trainable_parameters()
# trainable params: 41,943,040 || all params: 8,072,204,288 || trainable: 0.52%

# Train
from trl import SFTTrainer, SFTConfig
# ... use SFTTrainer with model=peft_model

# Save adapter only (40 MB)
model.save_pretrained("./my-lora-adapter")

# Load and use
from peft import PeftModel
base = AutoModelForCausalLM.from_pretrained(model_id, device_map="auto")
model_with_lora = PeftModel.from_pretrained(base, "./my-lora-adapter")

# Merge pour inference simple
merged_model = model_with_lora.merge_and_unload()
merged_model.save_pretrained("./merged-model")

# Switch entre plusieurs LoRAs
model_with_lora.load_adapter("./lora-task-A", adapter_name="task_a")
model_with_lora.load_adapter("./lora-task-B", adapter_name="task_b")
model_with_lora.set_adapter("task_a")
# generate ...
model_with_lora.set_adapter("task_b")

# DoRA (newer)
lora_config_dora = LoraConfig(
    r=16, lora_alpha=32,
    target_modules="all-linear",
    use_dora=True,  # Enable DoRA
    task_type=TaskType.CAUSAL_LM,
)

# vLLM multi-LoRA serving
# vllm serve meta-llama/Meta-Llama-3-8B \
#       --enable-lora \
#       --lora-modules my-lora=./my-lora-adapter
```

## Pour aller plus loin

- Hu et al., *LoRA: Low-Rank Adaptation of Large Language Models* (ICLR 2022)
- Dettmers et al., *QLoRA: Efficient Finetuning of Quantized LLMs* (NeurIPS 2023)
- Liu et al., *DoRA: Weight-Decomposed Low-Rank Adaptation* (ICML 2024)
- Hayou et al., *LoRA+: Efficient Low-Rank Adaptation of Large Models* (2024)
- *PEFT* (Hugging Face) — library standard
- Mangrulkar et al., *PEFT: Parameter-Efficient Fine-Tuning of Billion-Scale Models on Low-Resource Hardware*
- **Liens internes** : [[SFT]], [[RLHF and DPO]], [[Quantization]], [[SVD]] (low-rank connection)
