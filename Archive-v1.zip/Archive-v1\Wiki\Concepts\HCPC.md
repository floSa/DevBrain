---
galaxie: wiki
nom: Hierarchical Clustering on Principal Components (HCPC)
alias: [HCPC, Classification Hiérarchique sur Composantes Principales]
type: concept
categorie: concept/stats
sous_categories: [clustering, factor-analysis, hierarchical, k-means, factominer]
domaines: [data-science]
maturite: established
auteurs_cles: [Husson Lê Pagès (école française), FactoMineR]
lecture_min: 9
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, clustering, hcpc, factor-analysis]
---

# Hierarchical Clustering on Principal Components (HCPC)

## TL;DR

Procédure en 3 étapes pour identifier des groupes d'individus à partir d'un dataset multidimensionnel : **(1) analyse factorielle** ([[PCA]] / [[MCA]] / [[FAMD]]) pour réduire le bruit, **(2) classification hiérarchique** ascendante sur les composantes retenues, **(3) consolidation** par k-means autour des centroïdes des classes. Méthode signature de l'école française (FactoMineR).

## Le problème

Faire un clustering direct (k-means, hiérarchique) sur des données brutes en haute dimension a plusieurs limites :
- **Bruit** des dimensions non-informatives qui dégrade les distances euclidiennes
- **Pas de hiérarchie** des classes obtenues (k-means donne un partitionnement plat)
- **Choix du nombre de classes** difficile sans visualisation
- **Variables catégorielles** mal traitées par k-means brut

HCPC répond en pré-traitant les données via une analyse factorielle et en combinant deux approches de clustering.

## L'idée

### Étape 1 — Analyse factorielle

Selon le type de données :
- Continu seulement → [[PCA]]
- Catégoriel seulement → [[MCA]]
- Mixte → [[FAMD]]

Garder les $K$ premières composantes (typiquement celles expliquant 80-95% de l'inertie). Cela débruite : les dimensions résiduelles sont supposées du bruit.

### Étape 2 — Classification hiérarchique ascendante (CAH)

Sur les coordonnées factorielles $F \in \mathbb{R}^{n \times K}$, appliquer une **CAH avec critère de Ward** :

$$ \text{Inertie inter-classes après fusion} = \min $$

À chaque étape, fusionner les deux classes dont la fusion minimise l'augmentation de l'inertie intra-classes. Cela produit un **dendrogramme**.

Le critère de Ward est cohérent avec la PCA (tous deux basés sur la variance euclidienne), d'où la complémentarité.

### Étape 3 — Choix du nombre de classes et consolidation

À partir du dendrogramme :
- **Coupure automatique** : l'algorithme propose une coupure en cherchant le **saut d'inertie** maximal (où le gain par division supplémentaire devient marginal)
- **Coupure manuelle** : tu coupes à $k$ classes selon ton intuition

Ensuite : **consolidation par k-means**. On lance un k-means initialisé sur les centroïdes des classes obtenues. Cela "stabilise" la partition en déplaçant les points-frontière vers la classe la plus proche.

### Caractérisation des classes

HCPC fournit pour chaque classe :
- **Individus typiques** (parangons, les + proches du centroïde)
- **Variables qui caractérisent la classe** (catégories sur-représentées, valeurs continues hors-moyenne) via des **valeurs-test** ($v.test$)
- **Plan factoriel coloré** par classe

C'est l'aspect le plus utile : tu sais *pourquoi* une classe est ce qu'elle est, pas juste qu'elle existe.

## Quand c'est utile

- Segmentation marketing / typologie (utilisateurs, patients, produits)
- Exploration data avant supervision (classes comme features ?)
- Détection de profils dans des enquêtes (HCPC après MCA)
- Quand tu veux du clustering **interprétable** et **hiérarchique**

## Quand ça ne marche pas / pièges

- **Pas adapté au big data** : la CAH est en $O(n^2)$ ou $O(n^3)$ — au-delà de ~10 000 individus, lent
- **Sensibilité au nombre de composantes retenues** : trop peu = sous-fitting des classes ; trop = bruit conservé
- **Pas de classification supervisée** : c'est de l'exploration. Ne remplace pas un modèle prédictif.
- **Toujours valider** les classes avec un domaine expert — l'algo trouve des groupes statistiques, pas forcément "métier"

## Code minimal

```python
from prince import FAMD
from scipy.cluster.hierarchy import linkage, fcluster
from sklearn.cluster import KMeans
import numpy as np

# 1. Analyse factorielle
famd = FAMD(n_components=5).fit(df)
F = famd.row_coordinates(df).values  # n × 5

# 2. CAH avec Ward
Z = linkage(F, method='ward')

# 3. Coupure (ex : 4 classes)
labels = fcluster(Z, t=4, criterion='maxclust')

# 4. Consolidation k-means
centers = np.array([F[labels == c].mean(axis=0) for c in np.unique(labels)])
km = KMeans(n_clusters=4, init=centers, n_init=1).fit(F)
labels_final = km.labels_
```

Avec [[prince]] (plus haut niveau) :

```python
from prince import FAMD
# prince ne fait pas HCPC nativement, mais expose F.row_coordinates pour
# enchaîner avec scipy/sklearn
```

R/FactoMineR fait tout d'un coup :
```r
res.famd <- FAMD(df, ncp=5)
res.hcpc <- HCPC(res.famd, nb.clust=-1)  # -1 = auto
plot(res.hcpc, choice="tree")     # dendrogramme
res.hcpc$desc.var               # variables qui caractérisent les classes
```

## Implémentations concrètes

- R : `FactoMineR::HCPC` (référence académique, sortie ultra-riche)
- Python : composition `prince` + `scipy.cluster.hierarchy` + `sklearn.cluster.KMeans` (pas d'API unifiée)
- Le package `pyFamd-Cluster` (PyPI) tente l'unification mais peu maintenu

## Pour aller plus loin

- Husson, Lê, Pagès — *Analyse de données avec R*, chap. HCPC
- Lebart, Morineau, Piron — *Statistique exploratoire multidimensionnelle*
- **Liens internes** : [[PCA]], [[MCA]], [[FAMD]], [[embeddings]] (alternative moderne pour le pré-traitement)
