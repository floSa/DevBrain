---
galaxie: dev
nom: Ragas
alias: [ragas]
categorie: llm/eval
sous_categories: [rag-eval, faithfulness, context-precision, llm-as-judge]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[DeepEval]]", "[[Phoenix Arize]]", "[[TruLens]]", "[[LangSmith]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, eval, rag, llm-as-judge]
url_officiel: https://docs.ragas.io/
url_docs: https://docs.ragas.io/
url_repo: https://github.com/explodinggradients/ragas
---

# Ragas

## Pourquoi
Framework d'éval **dédié RAG**. Métriques spécialisées : faithfulness (la réponse est-elle fidèle au contexte), context_precision/recall, answer_relevancy, answer_correctness. Approche LLM-as-judge avec référence + custom metrics. Le défaut quand "RAG" est dans ton stack.

## Quand l'utiliser
- Évaluer un pipeline RAG en boucle CI
- Comparer plusieurs configurations (chunking, retriever, prompt)
- Métriques quantifiables (vs eyeball par humain)
- Génération de testset synthétique à partir de docs (`TestsetGenerator`)
- Intégration [[LangChain]], [[LlamaIndex]], [[Haystack]]

## Quand NE PAS l'utiliser
- Eval LLM générale (pas RAG) → [[DeepEval]]
- Observability prod tracing → [[Phoenix Arize]] / [[LangSmith]] / [[Langfuse]]
- Tu veux des metrics ML classiques (BLEU, ROUGE) → métriques custom à coder

## Pièges connus
- **Coût LLM-as-judge** : chaque metric appelle un LLM, peut chiffrer vite
- **Reproductibilité** : `temperature=0` du judge + cache, sinon variance entre runs
- **Choix du judge** : modèle puissant (Claude Opus / GPT-4) requis pour metrics fines
- **Versions** : API évolue, pinner
- **Testset synthétique** : utile mais à valider à la main (qualité variable)
- **Faithfulness ≠ correctness** : faithfulness mesure "fidèle au contexte", pas "vrai dans l'absolu"

## Métriques principales

| Métrique | Mesure |
|----------|--------|
| `faithfulness` | Réponse cohérente avec le contexte fourni |
| `answer_relevancy` | Réponse pertinente vs question |
| `context_precision` | Bons chunks classés en haut |
| `context_recall` | Tous les chunks utiles récupérés (besoin du ground truth) |
| `answer_correctness` | Réponse correcte vs ground truth |

## Liens
- [[DeepEval]], [[Phoenix Arize]] — alternatives
- [[LangChain]] / [[LlamaIndex]] — bien intégrés
- [[Anthropic Claude API]] / [[OpenAI API]] — pour le judge
- Quickstart : https://docs.ragas.io/en/stable/getstarted/index.html
