---
galaxie: dev
nom: hnswlib
alias: [hnswlib]
categorie: vectordb/ann
sous_categories: [ann, hnsw, approximate, library, embedded]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: C++ / Python
clients_officiels: [python, c++, java]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Faiss]]", "[[Qdrant]]", "[[Weaviate]]", "[[Milvus]]", "Annoy", "ScaNN"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, vectordb, ann, hnsw]
url_officiel: https://github.com/nmslib/hnswlib
url_docs: https://github.com/nmslib/hnswlib#readme
url_repo: https://github.com/nmslib/hnswlib
---

# hnswlib

## Pourquoi

**Implémentation de référence** de l'algorithme **HNSW** (Hierarchical Navigable Small World, Malkov & Yashunin 2016). C++ + bindings Python. Très rapide, mature, **sous-jacent à la plupart des vector DBs modernes** : Qdrant, Weaviate, **pgvector v0.5+**, Elasticsearch, OpenSearch.

HNSW domine en 2026 la courbe **recall vs latency** sur la plupart des benchmarks ANN (devant IVF-PQ Faiss, Annoy, ScaNN sur les use cases généralistes). hnswlib expose HNSW pur en **embedded** : pas de serveur, juste une lib qui tourne dans ton process Python. Idéal pour : (1) recherche similarité simple dans une app Python, (2) backend custom de vector DB perso, (3) benchmarking ANN.

## Quand l'utiliser

- **HNSW pur embedded dans ton process Python** : zero infra
- **Combo numpy → recherche rapide** : 1M vecteurs en RAM, query < 1ms
- **Update + query** : HNSW supporte add incrémental (contrairement à Annoy)
- **Backend custom** : tu construis ta propre vector DB / RAG en Python
- **Très haute dimensionnalité** (jusqu'à 4096+) : HNSW scale bien
- **Multi-metric** : cosine, L2, inner product
- **Multi-thread search** : threadsafe en read
- **Recall élevé requis** : tunings ef pour atteindre 99%+ recall

## Quand NE PAS l'utiliser

- **Filtering / metadata structuré** → [[Qdrant]] / [[Weaviate]] / pgvector (HNSW + WHERE)
- **Multi-tenant** : vector DB managed mieux (RBAC, namespaces)
- **Distributed scale-out** → [[Milvus]] / [[Qdrant]] Cloud
- **Persistance gérée + replication** : il faut un service, pas une lib
- **GPU search** → [[Faiss]] GPU
- **Catalogues > RAM** : hnswlib charge tout en RAM, pas de mmap natif

## Pièges connus

- **Memory full RAM** : pas de disk-based / mmap → 1M × 768 dim float32 = ~3 Go RAM
- **Params M, ef_construction, ef à tuner** : trade-off recall/latency/memory pas trivial
  - M typique : 16-64 (plus grand = meilleur recall, plus de RAM)
  - ef_construction : 100-500 (build time)
  - ef (search) : 50-500 (query time)
- **Pas de filtering structuré natif** : tu peux passer un `filter` callable mais lent sur gros catalogues
- **Sauvegarde / load manuel** : `index.save_index("path")` + `index.load_index("path", max_elements=N)`
- **max_elements pré-déclaré** : `init_index(max_elements=N)` à choisir à l'avance, ou `resize_index`
- **Delete = mark-as-deleted** : pas de vraie suppression, place réservée → fragmentation
- **Single-writer** : threadsafe en read, mais add concurrent → race conditions
- **Pas de quantization native** : pour gros catalogues mémoire-contraints → Faiss IVF-PQ
- **Pas de retour metadata** : seulement IDs + distances → garder un mapping ID → metadata à côté
- **Cosine ≠ inner product** : normaliser les vecteurs si cosine
- **Maintenance modeste** : releases rares, projet stable mais pas super actif

## Code minimal

```bash
pip install hnswlib numpy
```

```python
import hnswlib
import numpy as np

dim = 768
num_elements = 100_000

# Init
p = hnswlib.Index(space="cosine", dim=dim)        # cosine | l2 | ip
p.init_index(max_elements=num_elements, ef_construction=200, M=32)
p.set_num_threads(8)                               # parallelise le build

# Donnees synthetiques (typiquement : embeddings d'un encoder)
np.random.seed(42)
data = np.random.normal(size=(num_elements, dim)).astype("float32")
ids = np.arange(num_elements)

# Add
p.add_items(data, ids)
print(f"{p.get_current_count()} elements indexes")

# Save
p.save_index("index.bin")
```

```python
# Loading + query
p = hnswlib.Index(space="cosine", dim=dim)
p.load_index("index.bin", max_elements=num_elements)
p.set_ef(100)                                       # search-time recall/latency trade-off

# KNN
query = np.random.normal(size=(5, dim)).astype("float32")
labels, distances = p.knn_query(query, k=10)
print(labels)        # shape (5, 10)
print(distances)
```

```python
# Add incremental + resize
new_data = np.random.normal(size=(10_000, dim)).astype("float32")
new_ids = np.arange(num_elements, num_elements + 10_000)

p.resize_index(num_elements + 10_000)
p.add_items(new_data, new_ids)

# Mark-as-deleted
p.mark_deleted(42)
```

```python
# Filter callable (lent sur gros catalogue, mais flexible)
allowed_ids = set(range(0, 1000))
def filter_fn(label):
    return label in allowed_ids

labels, distances = p.knn_query(query, k=10, filter=filter_fn)
```

```python
# Combo avec une app RAG simple
from sentence_transformers import SentenceTransformer

encoder = SentenceTransformer("BAAI/bge-small-en-v1.5")
docs = ["Paris est la capitale de la France",
        "Madrid est la capitale de l'Espagne",
        "Lisbonne est la capitale du Portugal"]
embs = encoder.encode(docs, normalize_embeddings=True).astype("float32")

p = hnswlib.Index(space="cosine", dim=embs.shape[1])
p.init_index(max_elements=len(docs), ef_construction=100, M=16)
p.add_items(embs, np.arange(len(docs)))
p.set_ef(50)

q = encoder.encode(["Quelle est la capitale du Portugal ?"], normalize_embeddings=True).astype("float32")
labels, _ = p.knn_query(q, k=1)
print(docs[labels[0][0]])
```

## Liens

- [[Faiss]] — alternative multi-algo (IVF-PQ, GPU)
- [[Qdrant]] / [[Weaviate]] / [[Milvus]] — vector DBs full-featured
- Annoy — alternative arbres (read-only)
- ScaNN — alternative Google (anisotropic quantization)
- pgvector — utilise HNSW depuis v0.5
- Paper HNSW : https://arxiv.org/abs/1603.09320
- Benchmarks : https://ann-benchmarks.com/
- GitHub : https://github.com/nmslib/hnswlib
