---
galaxie: wiki
nom: Prompt Caching
type: concept
categorie: concept/llm
sous_categories: [cache, optimization, cost, latency]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Anthropic, OpenAI]
lecture_min: 7
created: 2026-05-19
modified: 2026-05-20
tags: [concept, llm, cache, optimization]
---

# Prompt Caching

## TL;DR

Le LLM met en **cache la partie statique** d'un prompt (système + few-shot examples + contexte fixe) pendant 5 min (Anthropic) à plusieurs heures (extended cache). Sur les requêtes suivantes qui réutilisent ce préfixe, **tu paies ~10× moins cher et c'est ~2× plus rapide**. C'est l'optimisation 80/20 de toute app LLM.

## Le problème

Chaque appel LLM est tarifé en input tokens + output tokens. Sur une app type :
- Système prompt : 500 tokens (fixe)
- Contexte / docs / few-shot : 5000-50000 tokens (fixe)
- Question utilisateur : 100 tokens (variable)

Tu paies le préfixe (5500+) à **chaque** requête, alors qu'il ne change jamais. Sur un agent multi-tours ou une app B2B, ça représente 90% de la facture pour 0% de valeur.

## L'idée

Le LLM identifie un **point de coupure** dans le prompt (souvent : fin du système, fin du contexte fixe). Tout ce qui est avant est **mis en cache sur ses serveurs** pour 5 min après le premier appel. Les appels suivants avec le même préfixe :
- ne sont **pas refacturés** au prix plein sur cette portion (Anthropic : 0.1× du prix input pour les cache hits)
- sont **plus rapides** (le modèle n'a pas à re-encoder le préfixe)

```
Premier appel :
[système + contexte fixe] [question]   → coût plein, cache écrit
        ▼
Appels suivants (dans les 5 min) :
[système + contexte fixe] [question 2] → cache hit, ~10× moins cher
[système + contexte fixe] [question 3] → cache hit
...
```

Côté Anthropic : tu marques explicitement le point de coupure via `cache_control` dans l'API. Côté OpenAI : c'est automatique sur les longs préfixes répétés.

## Quand c'est utile

- **Agent multi-tours** — chaque tour reprend le même contexte/historique au début
- **Chat avec docs longs** — le doc reste, la question change
- **App B2B avec un gros system prompt** — appelé des milliers de fois par jour
- **RAG** — le contexte récupéré est souvent stable sur plusieurs sub-questions
- **Batch processing** sur un même domaine — bouts de prompts en commun

## Quand ça ne marche pas / pièges

- **Le préfixe doit être strictement identique** — un caractère qui change invalide le cache
- **5 min de TTL chez Anthropic standard** — pas adapté à des appels trop espacés (extended cache solutions disponibles)
- **Sur du contenu très dynamique** (chat en temps réel sans contexte stable) → pas d'optimisation possible
- **Coût d'écriture du cache** : le premier appel est légèrement plus cher (~1.25× input chez Anthropic) — donc rentable seulement si le préfixe est ré-utilisé 2-3× minimum

## Implémentations concrètes

- [[Anthropic Claude API]] — `cache_control: {type: "ephemeral"}` sur un block du prompt
- [[LiteLLM]] — abstraction multi-provider, gère le cache transparent quand supporté
- [[claude-api]] — le skill applique automatiquement les bonnes pratiques caching

## Code minimal

```python
# 1. Anthropic prompt caching (explicit cache_control)
import anthropic
client = anthropic.Anthropic()

# Le system prompt + les tools sont longs et stables → cacher
LONG_SYSTEM = "Tu es un assistant expert en droit français. Voici 50 pages de référence : " + "..." * 5000

response = client.messages.create(
    model="claude-3-7-sonnet-latest",
    max_tokens=1024,
    system=[
        {
            "type": "text",
            "text": LONG_SYSTEM,
            "cache_control": {"type": "ephemeral"}  # ← TTL 5 min par défaut
        }
    ],
    messages=[{"role": "user", "content": "Question variable de l'utilisateur"}]
)

# Métriques cache
usage = response.usage
print(f"Cache CREATION : {usage.cache_creation_input_tokens} tokens (1.25× prix)")
print(f"Cache READ     : {usage.cache_read_input_tokens} tokens (0.1× prix)")
print(f"Input frais    : {usage.input_tokens} tokens (prix plein)")
print(f"Output         : {usage.output_tokens} tokens")

# 2. Cacher plusieurs sections (jusqu'à 4 break points)
response = client.messages.create(
    model="claude-3-7-sonnet-latest",
    max_tokens=1024,
    system=[
        {"type": "text", "text": "Tu es un assistant expert."},  # pas cachée (court)
        {"type": "text", "text": LONG_DOC_1, "cache_control": {"type": "ephemeral"}},
        {"type": "text", "text": LONG_DOC_2, "cache_control": {"type": "ephemeral"}},
    ],
    messages=[{"role": "user", "content": "..."}]
)

# 3. Extended cache (TTL 1h, plus cher mais plus persistant)
{"type": "text", "text": "...", "cache_control": {"type": "ephemeral", "ttl": "1h"}}

# 4. OpenAI : prompt caching AUTOMATIQUE depuis Oct 2024
from openai import OpenAI
client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {"role": "system", "content": LONG_SYSTEM},  # auto-cached si > 1024 tokens
        {"role": "user", "content": "..."}
    ]
)
# Vérifier le hit
print(response.usage.prompt_tokens_details.cached_tokens)

# 5. Gemini : context caching explicite
import google.generativeai as genai
cache = genai.caching.CachedContent.create(
    model="gemini-1.5-flash",
    contents=[LONG_DOC],
    ttl="3600s"  # 1h
)
model = genai.GenerativeModel.from_cached_content(cache)
response = model.generate_content("Question")

# 6. Mesurer le ROI
def cost_with_cache(input_tokens, cache_pct, model="claude-3-7-sonnet"):
    # Anthropic Sonnet pricing (per 1M tokens)
    PRICE_INPUT = 3.00
    PRICE_CACHE_WRITE = 3.75  # 1.25× input
    PRICE_CACHE_READ = 0.30   # 0.1× input
    
    cached = input_tokens * cache_pct
    fresh = input_tokens * (1 - cache_pct)
    
    # Premier appel : write all cached
    first = (cached * PRICE_CACHE_WRITE + fresh * PRICE_INPUT) / 1e6
    # Appels suivants : read cache
    subsequent = (cached * PRICE_CACHE_READ + fresh * PRICE_INPUT) / 1e6
    
    return first, subsequent

# Break-even : si tu réutilises le prefix > 2-3 fois, c'est rentable
```

## Pour aller plus loin

- Doc Anthropic : https://docs.claude.com/en/docs/build-with-claude/prompt-caching
- Article perf : viser un cache hit rate >80% pour amortir l'overhead d'écriture
- Stratégie clé : **mets les choses stables au début du prompt** (système, contexte), variables à la fin (question utilisateur)
- Voir aussi [[Context engineering]] et [[LLM caching]] pour le panorama complet (semantic cache, KV cache reuse, etc.)
