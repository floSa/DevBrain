---
galaxie: wiki
nom: Speculative decoding
alias: [speculative decoding, draft model, Medusa, EAGLE, lookahead decoding]
type: concept
categorie: concept/llm-inference
sous_categories: [speculative-decoding, inference, llm, optimization]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Leviathan 2023, Chen 2023]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, inference, decoding, optimization]
---

# Speculative decoding

## TL;DR

Accélérer la **génération autoregressive** d'un gros LLM en utilisant un **petit "draft" model** qui propose plusieurs tokens à l'avance, vérifiés en **parallèle** par le gros modèle. Speedup **2-3x** sans perte de qualité. Variants : **vanilla speculative** (small draft model), **Medusa** (multiple heads), **EAGLE** (draft via feature extrapolation), **lookahead decoding** (sans draft model), **prompt lookup decoding** (PLD). Standard chez Anthropic, OpenAI, vLLM, TGI. Trade-off : pas de gain sur petit batch, mémoire additional pour draft model.

## Le problème

LLM génération = **autoregressive** : 1 token à la fois. Pour un gros modèle (70B), chaque token = 1 forward pass complet = lent (TTFT et TPOT élevés).

**Observation** : la plupart des tokens sont **"évidents"** — un modèle plus petit pourrait les deviner. Pourquoi mobiliser le gros modèle pour eux ?

## L'idée

### Algorithme vanilla speculative

```
Draft model D (small, fast) — e.g. 1B params
Target model M (big, accurate) — e.g. 70B params

Repeat:
    1. D génère γ tokens (e.g. 5 tokens) en autoregressive
       → "draft tokens" d_1, d_2, ..., d_γ
    2. M fait UN SEUL forward pass sur prefix + draft tokens
       → produces logits pour positions [d_1, d_2, ..., d_γ, next]
    3. Pour chaque draft token d_i :
       - Si proba M(d_i) >= proba D(d_i) → accept
       - Sinon : reject avec proba 1 - M(d_i)/D(d_i)
    4. À la première rejection : sample un token "corrigé" de M
    5. Tokens acceptés + corrected → output
```

**Astuce** : si tous acceptés, on a "gagné" γ tokens en 1 forward de M. Si 0 acceptés, on a perdu 1 step (mais corrected token = équivalent à M seul).

### Garantie d'exactitude

**Important** : la distribution finale est **mathematiquement identique** à celle de M seul (rejection sampling). Pas d'approximation.

### Acceptance rate

Dépend de :
- **Similarité D vs M** : draft distillé de M → acceptance rate haut (~70-80%)
- **Tokens "faciles"** : punctuation, common words → haut
- **Tokens "difficiles"** : rare words, facts → bas
- **γ trop grand** : exponentiellement moins probable que TOUS acceptés

Typique : γ = 4-8, acceptance 50-70%, **speedup 2-3x**.

### Variants moderne

#### Medusa (Cai 2024)

Pas de draft model séparé. Ajouter **plusieurs "heads"** au model M, chacune prédit token $t+1, t+2, ..., t+k$ en parallèle.

- Pas besoin de gros draft model en mémoire
- Mais demande **fine-tuning** de M pour ajouter heads
- 2-3x speedup

#### EAGLE (Li 2024)

Améliore Medusa : draft via **feature extrapolation** des hidden states. Speedup 3x.

#### EAGLE-2 (2024)

Dynamic draft tree → speedup 4x.

#### ReDrafter (Apple 2024)

Recurrent drafting. Pour Apple Silicon serving.

#### Lookahead decoding (Fu 2024)

**Sans draft model**. Utilise les jacobiens du model itself pour proposer futurs tokens. **Aucun overhead** mémoire.

#### Prompt Lookup Decoding (PLD)

**Trivial mais efficace** : si génération actuelle contient des n-grams identiques à des n-grams du prompt → proposer la continuation. Standard pour code generation, summarization.

Pas de model entraîné, gain de speedup quand suffix matches.

#### Self-speculative

Le gros modèle predict avec **early-exit** (sortir au layer L < total) pour drafter, full forward pour vérifier. Pas de draft model séparé.

#### Tree-based speculative

Au lieu d'une séquence linéaire de drafts, **arbre** de drafts possibles (e.g. top-2 à chaque position). Plus de candidats → plus de chance de match.

### Trade-offs

| Aspect | Vanilla speculative | Medusa | EAGLE | PLD | Lookahead |
|---|---|---|---|---|---|
| Speedup | 2-3x | 2-3x | 3x | varies | 2x |
| Extra params | small model | heads | heads | none | none |
| Training needed | distill draft | finetune heads | finetune heads | none | none |
| Memory | + draft model | + heads | + heads | 0 | 0 |
| Best for | general | general | general | repeat-heavy | universal |

### Implémentations

- **vLLM** : speculative decoding native via `--speculative-model`
- **TGI** : Medusa, speculation natifs
- **llama.cpp** : `--draft` flag
- **TensorRT-LLM** : Medusa, ReDrafter
- **HF transformers** : `assistant_model` parameter

### Choix du draft model

- **Same family** : Llama 3 8B drafter pour Llama 3 70B target (acceptance ~70%)
- **Distilled drafter** : meilleur que small random
- **Vocabulary match** : critique — tokenizer doit être identique
- **Size ratio** : ~7x différence size = standard

### Performance numbers

Llama 3 70B + Llama 3 8B drafter :
- Without : ~30 tokens/sec
- With speculative : ~75 tokens/sec
- Acceptance rate ~65%

Llama 3 70B + Medusa heads :
- ~60 tokens/sec
- No drafter model needed

### Best practices

1. **Use vLLM / TGI** : implem solides, peu de tweaks
2. **Drafter same family** : tokenizer match, acceptance high
3. **γ = 4-7** : optimum pratique
4. **Mesurer acceptance rate** par task — varies énormément
5. **Combine avec PagedAttention** : compound speedup
6. **Pas en small batch** : overhead > gain
7. **Distill drafter on target data** : best acceptance
8. **Streaming** + speculative : conserve UX latence perçue

## Quand c'est utile

- **Large batch serving** : 2-3x throughput gratuit
- **Latency-sensitive** : TTFT et TPOT améliorés
- **Code completion** : tokens "prévisibles" → high acceptance
- **Translation** : routine, high acceptance
- **Long generation** : amortit l'overhead
- **Same-family drafter dispo** : Llama 70B + Llama 8B gratuits
- **Streaming chat** : meilleure UX perçue

## Quand ça ne marche pas / pièges

- **Single user, small batch** : speedup minimal (gros modèle pas bottleneck)
- **Drafter trop différent** : acceptance < 30% → overhead > gain
- **γ trop grand** : tail-end acceptance probability tombe → waste compute
- **Tokenizer mismatch** : impossible à utiliser ensemble
- **Creative / diverse output** : haute température → acceptance baisse
- **Reasoning sur tokens rares** : drafter inutile sur ces tokens
- **Memory budget tight** : drafter prend 5-15% extra
- **OOD prompts** : drafter pas entraîné sur ce data → acceptance crash
- **EAGLE/Medusa heads** : fine-tune required, peut détériorer base model
- **Lookahead pas universellement supported** : implém complexes

## Code minimal

```python
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

# Setup target + draft
target_id = "meta-llama/Meta-Llama-3-70B-Instruct"
draft_id = "meta-llama/Meta-Llama-3-8B-Instruct"

target_model = AutoModelForCausalLM.from_pretrained(target_id, torch_dtype=torch.bfloat16, device_map="auto")
draft_model = AutoModelForCausalLM.from_pretrained(draft_id, torch_dtype=torch.bfloat16, device_map="auto")
tokenizer = AutoTokenizer.from_pretrained(target_id)

# HF transformers: assistant_model
inputs = tokenizer("Once upon a time", return_tensors="pt").to("cuda")
outputs = target_model.generate(
    **inputs,
    max_new_tokens=200,
    assistant_model=draft_model,  # Speculative
    do_sample=True,
    temperature=0.7,
)

# vLLM speculative
# vllm serve meta-llama/Meta-Llama-3-70B-Instruct \
#       --speculative-model meta-llama/Meta-Llama-3-8B-Instruct \
#       --num-speculative-tokens 5 \
#       --use-v2-block-manager

# Or with Medusa
# vllm serve meta-llama/Meta-Llama-3-70B-Instruct \
#       --speculative-model meta-llama/Meta-Llama-3-70B-Medusa-heads

# Toy implementation
def speculative_decoding_step(target, draft, prefix, gamma=5):
    # 1. Draft generates γ tokens
    draft_ids = prefix.clone()
    draft_logits_list = []
    for _ in range(gamma):
        draft_out = draft(draft_ids)
        draft_logits_list.append(draft_out.logits[:, -1])
        next_token = draft_out.logits[:, -1].argmax(-1, keepdim=True)
        draft_ids = torch.cat([draft_ids, next_token], dim=-1)
    
    # 2. Target verifies in parallel (single forward)
    target_out = target(draft_ids)
    target_logits = target_out.logits[:, -gamma-1:, :]
    
    # 3. Compare and accept/reject
    accepted = 0
    for i in range(gamma):
        draft_token = draft_ids[:, prefix.size(1) + i]
        p_target = torch.softmax(target_logits[:, i], -1)[0, draft_token]
        p_draft = torch.softmax(draft_logits_list[i], -1)[0, draft_token]
        
        if torch.rand(1) < min(1.0, p_target / p_draft):
            accepted += 1
        else:
            # Reject : sample corrected token
            corrected_logits = torch.clamp(target_logits[:, i] - draft_logits_list[i], min=0)
            corrected_logits = corrected_logits / corrected_logits.sum(-1, keepdim=True)
            # corrected_token = sample from corrected_logits
            break
    
    return draft_ids[:, :prefix.size(1) + accepted], accepted

# Lookahead decoding (no draft model needed)
# Implementation in lookahead-decoding library
# from lookahead_decoding import LookaheadGenerator

# Prompt Lookup Decoding (PLD)
def pld_match(history_ids, prompt_ids, n=5):
    """Find n-gram match in prompt to propose continuation."""
    last_n = history_ids[-n:]
    for i in range(len(prompt_ids) - n):
        if (prompt_ids[i:i+n] == last_n).all():
            return prompt_ids[i+n:i+n+5]  # Return next 5 tokens
    return None
```

## Pour aller plus loin

- Leviathan et al., *Fast Inference from Transformers via Speculative Decoding* (ICML 2023)
- Chen et al., *Accelerating Large Language Model Decoding with Speculative Sampling* (DeepMind 2023)
- Cai et al., *Medusa: Simple LLM Inference Acceleration Framework with Multiple Decoding Heads* (2024)
- Li et al., *EAGLE: Speculative Sampling Requires Rethinking Feature Uncertainty* (ICML 2024)
- Fu et al., *Breaking the Sequential Dependency of LLM Inference Using Lookahead Decoding* (2024)
- Apple, *Recurrent Drafter for Fast Speculative Decoding* (ReDrafter, 2024)
- *vLLM* and *TGI* documentation on speculative decoding
- **Liens internes** : [[Decoding strategies]], [[Distillation]], [[Flash Attention and efficient attention]], [[Inference optimization]]
