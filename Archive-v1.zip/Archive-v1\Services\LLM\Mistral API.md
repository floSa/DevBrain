---
galaxie: dev
nom: Mistral API
alias: [mistral, mistral-ai, la plateforme]
categorie: llm/api
sous_categories: [api, llm, french, embedding, codestral]
licence: Proprietaire (API) / Open weights (modèles)
licence_type: proprietary
hosted: managed
maturite: production
langage: 
clients_officiels: [python, ts, go, java]
plateforme: [cloud]
score: 4
mes_projets: []
alternatives: ["[[Anthropic Claude API]]", "[[OpenAI API]]", "[[Cohere API]]", "[[Google Gemini API]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, api, mistral, french]
url_officiel: https://mistral.ai/
url_docs: https://docs.mistral.ai/
url_repo: 
---

# Mistral API

## Pourquoi
LLM API **français** (Paris). Modèles open-weights (Mistral 7B, Mixtral, Pixtral) ET API premium (Large, Medium, Small, Codestral). Souveraineté EU, GDPR-friendly, datacenters européens. Bons rapports qualité/prix, Codestral excellent pour code.

## Quand l'utiliser
- Compliance UE / résidence data Europe
- Code generation → **Codestral** (compétitif avec GPT-4 / Claude code)
- Multilingue (fort en français)
- Self-host avec modèles open-weights (Mistral 7B, Mixtral 8x7B/8x22B)
- Pixtral pour multimodal open
- Mistral Small = bon ratio prix/perf vs Haiku/GPT-4o-mini

## Quand NE PAS l'utiliser
- Reasoning très complexe → [[Anthropic Claude API]] (Sonnet/Opus mieux)
- Vision native production → GPT-4o / Claude 3.5+ (Pixtral encore jeune)
- Embeddings → Voyage / Cohere / OpenAI plus matures
- Coding agent ultra → Claude Code reste référent

## Pièges connus
- **API "La Plateforme"** vs open-weights : différents modèles, vérifier
- **Mistral Medium / Saba / Devstral** : roadmap évolue, modèles renommés
- **Tool use / function calling** : supporté mais format légèrement différent OpenAI
- **Context window** : Mistral Large = 128K, Small = 32K — varier selon modèle
- **Rate limits** : tier gratuit limité, monter en payant pour prod
- **Versions** : `mistral-large-latest` vs versions pinnées — toujours pin en prod

## Liens
- [[Anthropic Claude API]] / [[OpenAI API]] / [[Google Gemini API]] — alternatives
- Codestral repo / weights : https://mistral.ai/news/codestral/
- Pixtral (multimodal open) : https://mistral.ai/news/pixtral-12b/
- Docs : https://docs.mistral.ai/
- Pricing : https://mistral.ai/news/announcing-mistral-the-platform/
