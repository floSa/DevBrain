---
galaxie: dev
nom: Comparatif - Bases vectorielles
type: comparatif
created: 2026-05-20
modified: 2026-05-20
tags: [comparatif, vectordb, embeddings, rag]
---

# Comparatif — Bases vectorielles

> Quand choisir quelle vector DB selon scale, ops, prix, intégration.

## Synthèse rapide

| Option | Quand l'utiliser | Cons |
|---|---|---|
| **[[Postgres]] + pgvector** | <10M vecteurs, déjà sur Postgres, simplicité | scaling au-delà |
| **[[Qdrant]]** | self-host moderne, filtering riche, payload | infra à gérer |
| **[[Weaviate]]** | hybrid search natif, modules ML, GraphQL | complexité |
| **[[Milvus]]** | très grande échelle (100M+), GPU acceleration | ops lourdes |
| **[[Chroma]]** | proto rapide, dev/embedded | pas production scale |
| **[[Faiss]]** | in-process Python, performance brute, pas serveur | pas persisté natif |
| **Pinecone** | managed serverless, zéro ops | propriétaire, $ |
| **LanceDB** | columnar, single-file, serverless | jeune écosystème |
| **Vespa** | search engine + vector, Yahoo-grade | complexité Java |

## Critères de choix

### Volume
- **<1M vecteurs** : pgvector, Chroma, Faiss in-process suffisent
- **1-10M** : Qdrant, Weaviate, pgvector tuné
- **10-100M** : Qdrant, Weaviate, Milvus
- **>100M** : Milvus, Vespa, Pinecone Pod

### Filtering / hybrid search
- **Filtering structuré (where x=...)** : Qdrant, Weaviate, pgvector excellent
- **Hybrid (BM25 + dense)** : Weaviate natif, Qdrant via sparse vectors, Elasticsearch
- **Multi-vector (ColBERT)** : Qdrant, Vespa
- **Re-ranking integration** : tous, voir [[Reranking]]

### Ops
- **Self-host facile** : Qdrant (1 binaire Rust), Weaviate (Docker), Postgres + pgvector (existant)
- **Managed** : Pinecone (premium), Qdrant Cloud, Weaviate Cloud, Zilliz (Milvus)
- **Embedded** : Chroma, LanceDB, Faiss in-process

### Coût
- **Self-host gratuit** : Qdrant, Weaviate, Milvus, pgvector
- **Managed cheap** : Qdrant Cloud, LanceDB Cloud
- **Premium** : Pinecone, Zilliz

### Intégrations LLM
- **Tous** sont compatibles LangChain / LlamaIndex
- **pgvector** : combo naturel si tu as déjà Postgres
- **Qdrant** : Rust solide, intégration RAGAS, observability

## Recommandation par cas

| Cas | Recommandation |
|---|---|
| Proto RAG / FAQ entreprise | pgvector (déjà Postgres) ou Chroma |
| App prod < 10M vecteurs | Qdrant self-host ou pgvector |
| Recherche hybrid multilingue | Weaviate ou Qdrant + sparse |
| Edge / embedded | LanceDB ou Chroma |
| Mega scale (100M+) | Milvus ou Pinecone (selon budget ops) |
| Search engine "Google-like" | Vespa |

## Voir aussi

- [[RAG]] / [[Advanced RAG]] / [[Hybrid retrieval]] / [[Reranking]]
- [[embeddings]] (concept)
- [[Postgres]] / [[Qdrant]] / [[Weaviate]] / [[Milvus]] / [[Chroma]] / [[Faiss]] / [[pgvector]]
