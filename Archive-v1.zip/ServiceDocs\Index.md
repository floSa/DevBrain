---
galaxie: dev
type: moc
created: 2026-05-01
modified: 2026-05-01
tags: [moc, templates, servicedocs]
---

# Index — Templates/ServiceDocs/

> Templates de `services/<nom>/README.md` à copier dans tes projets de dev quand tu intègres un service. Chaque template implémente la règle correspondante dans `Rules/Documentation/`.

## Templates disponibles

| Template | Pour service de type | Règle |
|----------|----------------------|-------|
| `README - database-relational.md` | Postgres, MySQL, SQLite, CockroachDB | [[Database-Relational]] |
| `README - database-vector.md` | Qdrant, Weaviate, Milvus, Chroma, pgvector, Faiss | [[Database-Vector]] |
| `README - database-graph.md` | Neo4j, Nebula Graph | [[Database-Graph]] |
| `README - storage-object.md` | MinIO, S3, R2, B2 | [[Storage-Object]] |
| `README - orchestration-data.md` | Dagster, Airflow, Prefect, Flyte, Metaflow, ZenML, Kubeflow | [[Orchestration-Data]] |
| `README - llm-orchestration.md` | LangChain, LangGraph, LlamaIndex | [[LLM-Orchestration]] |
| `README - document-processing.md` | Docling, Unstructured, OCR (Tesseract) | [[Document-Processing]] |
| `README - generic.md` | Tout autre type de service | [[README - Service]] |

## Comment utiliser

### Manuellement
```bash
cp ~/DevBrain/Templates/ServiceDocs/README\ -\ database-vector.md \
   ~/projets/mon-projet/services/qdrant/README.md
# puis remplir les <À REMPLIR>
```

### Via le skill `doc-service` (recommandé)
Dans ton projet :
```
> doc-service : ajoute la doc pour mon service Qdrant
```
Le skill identifie le type, copie le bon template, pré-remplit ce qu'il sait depuis la fiche `Services/VectorDB/Qdrant.md`.

## Format

Tous les templates sont :
- **Markdown statique** : utilisables hors Obsidian, lisibles tels quels par les développeurs
- **Annotations Templater optionnelles** : pour usage Templater dans Obsidian si tu utilises ces templates pour autre chose
- **Placeholders `<À REMPLIR>`** : explicite ce qui doit être complété
- **Wikilinks vers le DevBrain** : conservent les liens vers les fiches Services + règles + REX

## Voir aussi

- [[Rules/Documentation/Index]] — règles correspondantes
- `AI/skills/doc-service/SKILL.md` — skill qui automatise l'usage
