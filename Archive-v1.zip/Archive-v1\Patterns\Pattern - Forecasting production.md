---
galaxie: dev
type: pattern
contexte: système de forecasting en production (ventes, demande, capacité), avec ré-entraînement périodique et monitoring de drift
created: 2026-05-19
modified: 2026-05-19
services_cles: ["[[statsforecast]]", "[[neuralforecast]]", "[[Airflow]]", "[[MLflow]]", "[[Postgres]]"]
projets_appliques: []
tags: [pattern, forecasting, mlops, production, time-series]
---

# Pattern — Forecasting production

## Contexte

Tu déploies un système de forecasting en production : prévisions de ventes/demande/capacité par produit ou région, mises à jour quotidiennement ou hebdomadairement. Volumétrie : 100 à 100 000 séries. Horizon : 7 à 90 jours.

Différent d'un notebook one-shot : il faut **ré-entraîner périodiquement**, **monitorer le drift**, **servir les prédictions** à une API ou un dashboard, et **alerter** quand le modèle se dégrade.

Pour la méthodologie d'éval, voir [[Evaluer un modele forecast]]. Pour le bootstrap initial, voir le workflow associé. Ce pattern décrit la stack **production-ready**.

## Stack

- **Modèles** : [[statsforecast]] (AutoARIMA, ETS, Theta) en baseline, [[neuralforecast]] (N-HiTS, TFT, PatchTST) si volume justifie GPU
- **Storage** : [[Postgres]] (history des prédictions + actuals) + [[Parquet]] sur S3 pour les features
- **Orchestration** : [[Airflow]] ou [[Dagster]] pour ré-entraînement + scoring quotidien
- **Tracking** : [[MLflow]] pour metrics + artifacts + versionning de modèles
- **Serving** : FastAPI lit Postgres, expose `/forecasts/{series_id}?horizon=...`
- **Monitoring drift** : Evidently AI ou implé custom sur MAE des prédictions vs actuals
- **Eval continue** : [[Walk-forward CV]] hebdomadaire + alertes si MASE > seuil

## Structure de projet

```
my-forecast/
├── pyproject.toml
├── README.md
├── docker-compose.yml         # Postgres + MLflow + Airflow
├── airflow/
│   └── dags/
│       ├── retrain_daily.py    # ré-entraîne + valide
│       ├── score_daily.py      # produit forecasts du jour
│       └── monitor_weekly.py   # mesure drift, alerte
├── src/
│   └── my_forecast/
│       ├── config.py
│       ├── api.py              # FastAPI /forecasts
│       ├── ingestion.py        # update features depuis sources
│       ├── train.py            # entraîne modèles, log MLflow
│       ├── score.py            # produit prédictions, écrit Postgres
│       ├── eval.py             # walk-forward CV, métriques
│       └── monitor.py          # détecte drift
├── notebooks/
│   ├── 01_exploration.ipynb    # analyse initiale
│   └── 02_baseline.ipynb       # baselines naïve
└── tests/
    └── test_*.py
```

## Décisions clés

### 1. Baselines obligatoires en parallèle du modèle

Toujours produire et logger en parallèle :
- **Naïve** : $\hat y_{t+h} = y_t$
- **Seasonal naïve** : $\hat y_{t+h} = y_{t+h-s}$
- **Moyenne historique** sur 28 derniers jours

Si ton modèle ne bat pas la seasonal naïve (MASE < 1.0), il y a un problème. Ces baselines coûtent ~rien et te donnent un **ancrage**.

### 2. Ré-entraînement périodique avec watermarks

Pas de ré-entraînement par requête (lent, instable). À la place :

- **Quotidien** : ré-entraîner sur les 365 derniers jours, produire forecasts pour les 30 prochains
- **Sauvegarder** le modèle (joblib, pickle, ONNX) dans MLflow avec `run_id`
- **Idempotence** : si Airflow re-trigger un DAG, n'écrase pas les données déjà produites (UPSERT avec watermark)
- **Versionner** : chaque modèle déployé = `model_version` dans la table prédictions

### 3. Schéma Postgres pour prédictions

```sql
CREATE TABLE forecasts (
    series_id      TEXT NOT NULL,
    forecast_date  DATE NOT NULL,         -- jour pour lequel on prédit
    forecast_ts    TIMESTAMPTZ NOT NULL,  -- moment où on a prédit
    horizon_days   INT NOT NULL,
    point_pred     DOUBLE PRECISION,
    lo_80          DOUBLE PRECISION,      -- IC
    hi_80          DOUBLE PRECISION,
    lo_95          DOUBLE PRECISION,
    hi_95          DOUBLE PRECISION,
    model_version  TEXT NOT NULL,         -- ref MLflow run
    PRIMARY KEY (series_id, forecast_date, model_version)
);

CREATE INDEX ON forecasts (forecast_date);
CREATE INDEX ON forecasts (series_id, forecast_date);
```

Toujours stocker **les intervalles de prédiction**, pas que la valeur point. Permet ensuite des décisions sous incertitude.

### 4. Eval continue via Walk-forward weekly

Tous les lundis, calculer pour chaque série :
- MASE sur les 4 dernières semaines (28 forecasts × 7 horizons)
- Comparer à MASE baseline naïve / seasonal naïve
- Logger dans une table `eval_history` (date, model_version, mase, rmse, count)

Alerte si :
- `mase_modèle / mase_naive` > 0.95 sur plus de 20% des séries → modèle pas mieux que baseline, urgence
- MASE moyen > 1.2× MASE baseline historique → dégradation, enquête

### 5. Monitoring drift

Drift de **distribution des features** :
- Population stability index (PSI) sur features clés (volume, saisonnalité moyenne, dispersion)
- Alerte si PSI > 0.2 (drift modéré) ou > 0.25 (drift fort)

Drift de **performance** :
- MAE / MASE par segment (region, produit, etc.) — détecter si certains segments dérivent même quand la moyenne reste OK
- Plot temporel MAE_day(t) — tendance haussière = problème

### 6. Serving via API simple

```python
@app.get("/forecasts/{series_id}")
async def get_forecast(
    series_id: str,
    horizon: int = 7,
    confidence: int = 95,
):
    # Lit Postgres, sert le forecast le plus récent
    forecast = await db.fetch_one("""
        SELECT * FROM forecasts
        WHERE series_id = $1
          AND horizon_days <= $2
          AND forecast_ts = (
              SELECT MAX(forecast_ts) FROM forecasts WHERE series_id = $1
          )
        ORDER BY forecast_date
    """, series_id, horizon)
    return forecast
```

Pas besoin de ré-entraîner à la requête : les forecasts sont pré-calculés. Latence sub-100ms.

### 7. Modèle champion / challenger

Toujours déployer en **shadow mode** :
- Champion : modèle servant en prod (statsforecast AutoARIMA)
- Challenger : nouveau modèle (neuralforecast NHITS) qui prédit en parallèle, ses prédictions sont loggées mais pas servies
- Après 4 semaines, comparer leurs MASE sur les actuals via Diebold-Mariano test
- Si challenger significativement meilleur → bascule (avec validation humaine)

## Pièges (vu en projets)

- **Ré-entraînement à chaque requête** → latence inadmissible. Toujours pré-calculer.
- **Pas de baselines** → impossible de savoir si le modèle vaut quelque chose
- **Stocker uniquement le point** → impossible de calibrer les intervalles a posteriori. Toujours stocker les quantiles.
- **MAPE en métrique sur séries avec zéros** → diverge. Utiliser MASE.
- **Concept drift silencieux** : modèle entraîné sur 2024, on est en 2026, les patterns ont changé. Monitoring obligatoire.
- **Pas de versioning de modèle** → impossible de comprendre pourquoi un forecast a foiré il y a 3 mois. MLflow ou équivalent.
- **Trop de modèles à servir** (100k séries × 5 frameworks) → coût compute explose. Hiérarchiser : seasonal naïve par défaut, modèles ML uniquement sur les séries "importantes" (chiffre d'affaires > seuil).
- **Tests d'intégration manqués** → un upgrade lib casse silencieusement les forecasts. Smoke tests obligatoires en CI.

## Voir aussi

- Concepts : [[Stationarity]], [[Autocorrelation]], [[Walk-forward CV]], [[Forecasting framing]], [[Confidence intervals]]
- Services : [[statsforecast]], [[neuralforecast]], [[darts]], [[Prophet]], [[Airflow]], [[Dagster]], [[MLflow]], [[Postgres]]
- Workflows : [[Evaluer un modele forecast]], [[Debug pipeline data]]
- Patterns liés : [[Pattern - Pipeline ELT moderne]] (features), [[Pattern - API REST FastAPI minimale]] (serving)
- Rules applicables : [[Rules/Types/ML-pipeline]]
