---
galaxie: dev
nom: Apache Flink
alias: [flink, apache-flink, pyflink]
categorie: data/streaming
sous_categories: [streaming, batch, processing, stateful, low-latency, cdc]
licence: Apache-2.0
licence_type: open-source
hosted: self ou cloud (Ververica, AWS KDA, Confluent)
maturite: production
langage: Java / Scala / Python (PyFlink)
clients_officiels: [java, scala, python, sql]
plateforme: [linux, macos, kubernetes]
score: 3
mes_projets: []
alternatives: ["[[Spark]] Structured Streaming", "Kafka Streams", "Apache Beam", "Materialize", "RisingWave"]
remplace: []
remplace_par: []
created: 2026-05-21
modified: 2026-05-21
status: actif
tags: [service, data, streaming, processing]
url_officiel: https://flink.apache.org/
url_docs: https://nightlies.apache.org/flink/flink-docs-stable/
url_repo: https://github.com/apache/flink
---

# Apache Flink

## Pourquoi

**Engine de processing streaming + batch unifié**, conçu **streaming-first** (vs Spark structured streaming qui est batch-first). Latence très basse (millisecondes), **stateful processing** avec checkpointing exactly-once, watermarking pour event-time, windowing riche.

Différenciateurs :
- **Vrai streaming low-latency** (ms) vs micro-batching Spark (~secondes)
- **Stateful natif** : RocksDB state backend, scalable à des téraoctets de state
- **Exactly-once** end-to-end avec Kafka / sinks compatibles
- **PyFlink** : SDK Python (mais Java reste plus performant)
- **Flink SQL** : SQL streaming sur Kafka avec tables continues
- **CDC natif** : Flink CDC connector pour Postgres, MySQL, MongoDB, etc.

Standard de fait en **gros streaming temps réel** : Alibaba, Uber, Netflix, AWS Kinesis Data Analytics, Confluent Cloud, Ververica. Pour stack Python solo, c'est trop lourd — préférer Spark Structured Streaming ou Kafka Streams.

## Quand l'utiliser

- **Streaming low-latency** (millisecondes) : alerting, fraud detection, real-time recommendations
- **Stateful streaming massif** : sessionization, joins streaming, aggregations à long horizon
- **Exactly-once strict** : transactions financières, billing
- **CDC pipelines** : Postgres → Flink → Kafka / warehouse en near-real-time
- **Flink SQL** : streaming declarative sans Java/Scala
- **Combo Kafka** : intégration profonde, exactly-once garanti
- **Très haut throughput** : millions d'events/s
- **Combo Iceberg / Paimon** : streaming vers lakehouse moderne

## Quand NE PAS l'utiliser

- **Batch pur** → [[Spark]] / [[Dask]] / DuckDB
- **Stack Python solo** → trop lourd, Kafka Streams ou Spark Structured Streaming plus simple
- **Pas d'équipe data eng dédiée** : Flink demande des compétences (JVM, state tuning, checkpointing)
- **Throughput modeste** (< 10k events/s) : alternative légère ([[Prefect]], cron + script) suffit
- **Stateless transformations simples** : Kafka Streams plus léger
- **Streaming SQL purement déclaratif** sans state lourd : Materialize / RisingWave (Postgres-compatible)
- **Apache Beam** existant : déjà portable Spark/Flink/Dataflow

## Pièges connus

- **JVM tuning** : heap, network buffers, RocksDB → expertise requise
- **Checkpointing config** : intervalle, mode (exactly-once vs at-least-once), storage → impacte perf + recovery
- **State explosion** : un join streaming mal scopé garde tout l'historique en state → OOM
- **Watermark mal compris** : late events filtrés silencieusement si watermark mal calibré
- **PyFlink overhead** : 2-10x plus lent que Java/Scala
- **DataStream API vs Table API vs SQL** : trois API différentes, choisir tôt
- **Backpressure debugging** : pas trivial, métriques Flink à connaître
- **Upgrade Flink** : breaking changes possibles, state migration parfois douloureux
- **Savepoints vs checkpoints** : confusion fréquente (savepoint = manuel, checkpoint = auto)
- **Sortie vers sinks non-transactionnels** : exactly-once perdu
- **K8s deployment** : Flink Operator existe mais setup non trivial
- **Cluster mode vs Application mode vs Session mode** : choix d'arch à comprendre dès le début
- **Petite équipe = sur-engineering** : Flink est conçu pour scale enterprise

## Code minimal

```bash
# Install PyFlink local (pour dev)
pip install apache-flink

# Cluster local
./bin/start-cluster.sh
# UI : http://localhost:8081
```

```python
# PyFlink Table API : streaming Kafka -> filtrage -> sink
from pyflink.table import EnvironmentSettings, TableEnvironment

env = EnvironmentSettings.in_streaming_mode()
t_env = TableEnvironment.create(env)

# Source Kafka
t_env.execute_sql("""
CREATE TABLE orders (
    order_id BIGINT,
    user_id BIGINT,
    amount DOUBLE,
    event_time TIMESTAMP(3),
    WATERMARK FOR event_time AS event_time - INTERVAL '5' SECOND
) WITH (
    'connector' = 'kafka',
    'topic' = 'orders',
    'properties.bootstrap.servers' = 'localhost:9092',
    'format' = 'json',
    'scan.startup.mode' = 'latest-offset'
)
""")

# Sink : large_orders
t_env.execute_sql("""
CREATE TABLE large_orders (
    order_id BIGINT, user_id BIGINT, amount DOUBLE
) WITH (
    'connector' = 'kafka',
    'topic' = 'large-orders',
    'properties.bootstrap.servers' = 'localhost:9092',
    'format' = 'json'
)
""")

# Pipeline streaming SQL
t_env.execute_sql("""
INSERT INTO large_orders
SELECT order_id, user_id, amount
FROM orders
WHERE amount > 1000
""")
```

```python
# Stateful : count par user en tumbling window 1 min
t_env.execute_sql("""
INSERT INTO order_counts
SELECT
    user_id,
    TUMBLE_START(event_time, INTERVAL '1' MINUTE) AS window_start,
    COUNT(*) AS n_orders,
    SUM(amount) AS total
FROM orders
GROUP BY user_id, TUMBLE(event_time, INTERVAL '1' MINUTE)
""")
```

```java
// DataStream API (Java) pour state custom
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
env.enableCheckpointing(60_000);   // checkpoint every 60s
env.setStateBackend(new EmbeddedRocksDBStateBackend());

DataStream<Order> orders = env
    .addSource(new FlinkKafkaConsumer<>("orders", new OrderDeserializer(), props));

DataStream<Alert> alerts = orders
    .keyBy(Order::getUserId)
    .process(new FraudDetector());   // stateful avec ValueState<Long>

alerts.addSink(new FlinkKafkaProducer<>("alerts", new AlertSerializer(), props));
env.execute();
```

```yaml
# Flink CDC : Postgres -> Kafka exactly-once
CREATE TABLE pg_users (
    id INT, email STRING, created_at TIMESTAMP,
    PRIMARY KEY (id) NOT ENFORCED
) WITH (
    'connector' = 'postgres-cdc',
    'hostname' = 'pg.host',
    'port' = '5432',
    'database-name' = 'mydb',
    'schema-name' = 'public',
    'table-name' = 'users',
    'username' = 'replication',
    'password' = '...'
);
```

## Liens

- [[Spark]] Structured Streaming — alternative batch-first, plus simple en Python
- Kafka Streams — alternative légère JVM
- Apache Beam — alternative portable (multi-runner)
- Materialize / RisingWave — alternatives Postgres-compatible streaming SQL
- [[Apache Iceberg]] / Paimon — combo sink lakehouse moderne
- Apache Kafka — source/sink standard
- Flink CDC : https://github.com/apache/flink-cdc
- Ververica (cloud managé) : https://www.ververica.com/
- AWS Kinesis Data Analytics — version managée AWS
- Docs : https://nightlies.apache.org/flink/flink-docs-stable/
- GitHub : https://github.com/apache/flink
