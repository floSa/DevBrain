---
galaxie: dev
nom: Comparatif - ML orchestration
type: comparatif
created: 2026-05-20
modified: 2026-05-20
tags: [comparatif, ml-ops, orchestration]
---

# Comparatif — ML Orchestration

> Outils pour orchestrer pipelines ML (train, eval, serve) — différents des orchestrateurs data généraux.

## Synthèse rapide

| Outil | Type | Standout | Cons |
|---|---|---|---|
| **[[ZenML]]** | OSS framework | abstraction stack swap, simplicité, pipelines Python natifs | écosystème modeste |
| **[[Kubeflow]]** | OSS Kubernetes | k8s natif, Notebooks + Pipelines + Serving combinés | complexité ops |
| **[[Metaflow]]** | OSS Netflix | UX clean, versioning natif, AWS Batch friendly | moins de features avancées |
| **[[Flyte]]** | OSS Linux Foundation | typed pipelines, k8s, multi-tenancy | learning curve |
| **[[MLflow]]** | OSS + cloud | tracking + registry + serving combo | orchestration weak |
| **[[Dagster]]** | OSS | asset-centric, types stricts, lineage natif | besoin ops Python |
| **SageMaker Pipelines** | AWS managed | intégré écosystème AWS | lock-in AWS |
| **Vertex AI Pipelines** | GCP managed | KFP-based, intégré GCP | lock-in GCP |
| **Databricks Workflows** | managed | natif Databricks/Spark | lock-in Databricks |

## Décision par cas

### Petite équipe / proto
- **[[Metaflow]]** : UX claire, Python décorateurs, deploy AWS Batch simple
- **[[ZenML]]** : swap dev/staging/prod stacks facilement
- **[[MLflow]] + script Python** : minimaliste

### Kubernetes-first
- **[[Kubeflow]] Pipelines** : standard k8s, KFP DSL
- **[[Flyte]]** : typed pipelines, mature en prod

### Data + ML combined
- **[[Dagster]]** : asset model = combine data + ML naturellement
- **[[Prefect]]** : workflows Python flexibles

### Cloud lock-in OK
- **SageMaker Pipelines** sur AWS, **Vertex AI** sur GCP, **Databricks Workflows** sinon

### Stack moderne autonome
- **[[ZenML]] + [[MLflow]] + [[Optuna]] + [[BentoML]]** = combo léger qui marche

## Composants typiques d'un pipeline ML

```
[Data ingestion] → [Validation Great Expectations / Pandera]
        ↓
[Feature engineering] → [Feature store Feast (optionnel)]
        ↓
[Training PyTorch / HuggingFace] → [HP tuning Optuna / Ray Tune]
        ↓
[Tracking MLflow / Weights & Biases]
        ↓
[Model registry MLflow]
        ↓
[Serving vLLM / BentoML / Ray Serve / SageMaker Endpoint]
        ↓
[Monitoring Phoenix Arize / Langfuse pour LLM]
```

## Voir aussi

- [[Comparatif - Orchestrateurs data]] (généralistes data)
- [[MLflow]], [[ZenML]], [[Kubeflow]], [[Metaflow]], [[Flyte]]
- [[Dagster]], [[Prefect]], [[Airflow]] (orchestrateurs généraux)
- [[Optuna]], [[Ray Tune]] (HP search)
