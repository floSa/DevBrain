---
galaxie: dev
nom: Prefect
alias: [prefect]
categorie: data/orchestrator
sous_categories: [orchestrator, workflow, scheduler, python-native]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Airflow]]", "[[Dagster]]", "[[Temporal]]", Kestra, Mage]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, orchestrator, workflow]
url_officiel: https://www.prefect.io/
url_docs: https://docs.prefect.io/
url_repo: https://github.com/PrefectHQ/prefect
---

# Prefect

## Pourquoi
**Orchestrateur Python-natif** moderne. Approche "negative engineering" : tu écris du Python normal avec `@flow` / `@task`, Prefect ajoute orchestration (retry, schedule, observability). Plus léger qu'Airflow, plus dynamique que Dagster. Prefect 2 (rewrite) puis 3 sont matures.

## Quand l'utiliser
- Pipelines ETL/ML modernes en Python pur
- Workflows dynamiques (DAGs qui changent à runtime)
- Migration depuis Airflow (DAGs trop rigides)
- Cloud-native (Prefect Cloud managed ou self-hosted)
- Équipe data/ML qui veut peu de boilerplate

## Quand NE PAS l'utiliser
- Stack Airflow déjà mature → migration coûteuse
- Asset-centric ML pipelines → [[Dagster]] (modèle asset/IO meilleur)
- Workflow non-data (CI, jobs génériques durables) → [[Temporal]]
- Très grosse scale (10k+ tasks/run) → vérifier perfs scheduler

## Pièges connus
- **v1 → v2** : breaking changes massifs (2022). v1 obsolète. v3 est le standard 2024+.
- **Worker pools** : nouveau modèle de déploiement, comprendre work pools vs agents (legacy)
- **Prefect Cloud** : tier gratuit limité (3 utilisateurs, ~400 task runs/min). Pricing peut surprendre.
- **State** : Prefect a un state graph riche (Pending/Running/Cached/Failed/...) — utile mais à comprendre
- **Auto-retry** : `@task(retries=3, retry_delay_seconds=60)` simple, mais attention idempotence
- **Caching** : `cache_key_fn` puissant mais piège si bug dans la key

## Liens
- [[Airflow]] / [[Dagster]] — alternatives
- [[Temporal]] — workflows durables non-data
- Docs : https://docs.prefect.io/
- Pricing : https://www.prefect.io/pricing
