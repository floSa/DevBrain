---
galaxie: dev
nom: Anthropic Claude API
alias: [anthropic, claude-api, claude]
categorie: llm/api
sous_categories: [api, frontier-model, tools, vision, computer-use]
licence: Proprietary
licence_type: proprietary
hosted: managed
maturite: production
langage: API REST
clients_officiels: [python, ts, java, go]
plateforme: [linux, macos, windows, web]
score: 
mes_projets: []
alternatives: ["[[OpenAI API]]", "[[Google Gemini API]]", "[[Mistral API]]", "[[Cohere API]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, api, anthropic, claude]
url_officiel: https://www.anthropic.com/
url_docs: https://docs.claude.com/
url_repo: https://github.com/anthropics/anthropic-sdk-python
---

# Anthropic Claude API

## Pourquoi
API LLM d'Anthropic. Modèles **Claude Opus** / **Sonnet** / **Haiku** : excellent en raisonnement, code, suivi d'instructions complexes, écriture longue. **Tool use** robuste, **prompt caching** (jusqu'à 90% de réduction coût), **extended thinking**, **computer use**, **batch API**, **files API**, **citations**, **memory tool**. Le défaut de beaucoup de stacks code-agentique (Claude Code en est un usage).

## Quand l'utiliser
- Code generation / agents code (Claude excelle ici)
- Raisonnement long et complexe (extended thinking)
- Suivi d'instructions strictes (system prompts longs et nuancés)
- Tool use chaîné multi-étapes
- Volumes importants de prompts répétés → prompt caching
- Batch processing async (50% moins cher)
- Quand tu veux des modèles "alignés" plus prudents (refus / honesty)

## Quand NE PAS l'utiliser
- Besoin offline / privacy stricte → [[Ollama]] / [[vLLM]] avec open-weight
- Modèles spécialisés (vision médicale, voice…) → providers spécialisés
- Prix critiques sur volume monstre → comparer avec [[OpenAI API]] / Gemini selon use case
- Multi-modal audio/voice natif → OpenAI / Gemini ont plus de modalités

## Modèles principaux (2026)

| Modèle | Usage |
|--------|-------|
| Claude Opus | Raisonnement profond, code complexe, recherche |
| Claude Sonnet | Workhorse — meilleur ratio perf/coût |
| Claude Haiku | Tâches volumineuses rapides (résumés, classif, extraction) |

## Pièges connus
- **`max_tokens` obligatoire** : pas de défaut, à définir explicitement
- **Prompt caching** : à structurer dans le prompt (ordre stable, breakpoints `cache_control`)
- **Tool use** : `tools` + boucle d'appels, à orchestrer
- **Extended thinking** : token budget séparé (`thinking.budget_tokens`)
- **Rate limits** : par tier, à monitorer en prod (429 retry avec backoff)
- **Prix** : input vs output différents, cache reads beaucoup moins cher
- **System vs user messages** : `system=` paramètre dédié (pas dans `messages[]`)
- **Streaming** : `stream=True` + parser événements (`message_start`, `content_block_delta`, etc.)

## Patterns clés

### Prompt caching (économie majeure)

```python
client.messages.create(
    model="claude-opus-4-7",
    max_tokens=1024,
    system=[
        {"type": "text", "text": "Tu es un assistant..."},
        {"type": "text", "text": LARGE_DOC, "cache_control": {"type": "ephemeral"}},
    ],
    messages=[{"role": "user", "content": "Question"}]
)
```

### Tool use minimal

```python
tools = [{
    "name": "get_weather",
    "description": "Get current weather",
    "input_schema": {"type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]}
}]
resp = client.messages.create(model=..., max_tokens=1024, tools=tools, messages=[...])
# parser resp.stop_reason == "tool_use", resp.content
```

## Liens
- [[OpenAI API]], [[Google Gemini API]] — alternatives
- Doc complète : https://docs.claude.com/
- Console : https://console.anthropic.com/
- SDK Python : https://github.com/anthropics/anthropic-sdk-python
- Cookbook : https://github.com/anthropics/anthropic-cookbook
- Pricing : https://www.anthropic.com/pricing
