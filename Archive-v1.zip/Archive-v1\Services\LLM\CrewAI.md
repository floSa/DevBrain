---
galaxie: dev
nom: CrewAI
alias: [crewai]
categorie: llm/framework
sous_categories: [multi-agent, agents, llm-orchestration, roles]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[AutoGen]]", "[[LangGraph]]", MetaGPT, Swarm]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, multi-agent, crewai]
url_officiel: https://www.crewai.com/
url_docs: https://docs.crewai.com/
url_repo: https://github.com/crewAIInc/crewAI
---

# CrewAI

## Pourquoi
Framework **multi-agent** Python, opinionated et didactique. Modèle "crew" : agents avec rôles + goal + backstory + tools, qui collaborent sur des tasks séquentielles ou hiérarchiques. Plus simple à apprendre que AutoGen, plus rigide. Excellent pour proto rapide.

## Quand l'utiliser
- Proto rapide multi-agent (research crew, content team, etc.)
- Pédagogie / démos : très readable
- Workflow séquentiel `tasks=[t1, t2, t3]` avec agents distincts
- Process hiérarchique (manager délègue)
- Tu veux moins de boilerplate qu'AutoGen v0.4

## Quand NE PAS l'utiliser
- Logique complexe / branching / loops → [[LangGraph]] (graphes flexibles)
- Architecture events / async natif → [[AutoGen]] v0.4
- Production hard avec SLAs strictes → ces frameworks restent jeunes
- Single-agent suffit → just utiliser SDK directement

## Pièges connus
- **Rôle / backstory** : prompts injectés → tester si ça améliore vraiment (souvent oui mais surcoût tokens)
- **Sequential vs Hierarchical** : choisir Process explicitement, défaut peut surprendre
- **Tool framework** : compatible LangChain tools, mais doc dit pas toujours
- **Memory** : optionnel via embedchain, ajoute deps
- **Cost** : multi-agent + LLM premium = $ vite. Monitor.
- **Versions** : évolue vite (breaking changes possibles entre minor versions)
- **vs LangGraph** : CrewAI = opinionated, LangGraph = explicite ; choisir selon préférence

## Liens
- [[AutoGen]] / [[LangGraph]] — alternatives
- [[Multi-agent systems]] / [[Agent patterns]] (concepts)
- Docs : https://docs.crewai.com/
- GitHub : https://github.com/crewAIInc/crewAI
- Examples : https://github.com/crewAIInc/crewAI-examples
