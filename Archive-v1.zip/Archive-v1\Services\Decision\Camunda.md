---
galaxie: dev
nom: Camunda
alias: [camunda, camunda-platform, camunda-8, zeebe]
categorie: decision/engine
sous_categories: [bpmn, dmn, workflow, decision-engine, orchestration, java]
licence: Apache-2.0 (Platform) / Commercial (Enterprise)
licence_type: open-source
hosted: self ou cloud (Camunda Cloud SaaS)
maturite: production
langage: Java / Go (Zeebe)
clients_officiels: [java, nodejs, python, csharp, go, rest, grpc]
plateforme: [linux, macos, windows, kubernetes]
score: 4
mes_projets: []
alternatives: ["[[Drools]]", "[[OpenL Tablets]]", "Flowable", "Activiti", "jBPM", "FICO Blaze Advisor", "IBM ODM"]
remplace: []
remplace_par: []
created: 2026-05-21
modified: 2026-05-21
status: actif
tags: [service, bpmn, dmn, decision-engine, orchestration]
url_officiel: https://camunda.com/
url_docs: https://docs.camunda.io/
url_repo: https://github.com/camunda/camunda
---

# Camunda

## Pourquoi

Plateforme de référence pour **process orchestration** (BPMN) et **décision automation** (DMN). Open-source (Apache 2.0) avec offre Enterprise. Deux générations en parallèle en 2026 :

- **Camunda 7** (legacy, Java embedded engine) : adoption massive historique, tourne dans des JVMs Spring Boot, supporte BPMN + DMN + CMMN (deprecated)
- **Camunda 8** (depuis 2022, cloud-native) : architecture event-sourcing autour de **Zeebe** (engine Go), API gRPC/REST, scalable horizontalement, **CMMN abandonné**, DMN intégré

Version courante : **Camunda 8.8** (2025) qui introduit l'**Orchestration Cluster** unifié (Zeebe + Operate + Tasklist + Identity en un seul artefact déployable). Côté DMN : autocomplétion FEEL (literal values true/false), notifications de déploiement avec liens Operate, et un **FEEL Copilot** assist IA. Pour stack DS/ML/AI : Camunda 8 ajoute des **agentic orchestration connectors** pour orchestrer des agents IA.

C'est l'engine de référence pour qui veut **DMN + BPMN production-grade open-source**.

## Quand l'utiliser

- **DMN production** : engine **L3 conforme** (100% TCK), maintenu, communauté large
- **Combo BPMN + DMN** : workflow + règles dans la même plateforme — voir [[BPMN DMN CMMN]]
- **Cloud-native** (Camunda 8) : Kubernetes-friendly, scalable horizontal
- **Migration depuis BRMS legacy** : Camunda 7 → 8 Data Migrator (élargi pour DMN en 2025)
- **Stack JVM** : intégration Spring Boot, Quarkus, microservices Java
- **Decision Automation as-a-Service** : exposer DMN via REST/gRPC
- **AI agents + workflows** : connectors agentic 2025
- **Auditabilité / conformité** : audit trail intégré, BPMN history
- **Enterprise** avec besoin de support : tier Enterprise mature

## Quand NE PAS l'utiliser

- **Stack Python pure** : Camunda est Java/Go, intégration Python via REST seulement (overhead). Pour DMN Python natif → [[pyDMNrules]]
- **DMN seul sans workflow** : Camunda est lourd si tu veux juste évaluer une decision table — préférer [[Drools]] embedded ou [[pyDMNrules]]
- **Pas d'équipe ops K8s** (Camunda 8) : déploiement non-trivial sans expertise cloud-native
- **Latence ultra-critique** (< 10ms) : moteur DMN ajoute une latence — préférer code natif compilé
- **Petite équipe / petit projet** : la complexité de Camunda 8 dépasse le besoin
- **CMMN obligatoire** : abandonné dans Camunda 8, choisir Flowable
- **Open-source strict** : Enterprise tier propose des features clés (Optimize, Cockpit avancé, support)

## Pièges connus

- **Camunda 7 vs 8** : architecturalement différents, **pas de compat directe**, projet migration non-trivial (mais le Data Migrator aide)
- **Camunda 8 quoi qu'on en pense, c'est lourd** : Zeebe + Elasticsearch + Operate + Tasklist + Identity = 5+ services Docker à orchestrer
- **Coût Enterprise élevé** : 5-6 chiffres / an typique
- **Licence Camunda Platform vs Self-Managed** : ambiguïté licence pour usage commercial intensif — vérifier
- **FEEL ≠ JUEL** : Camunda 7 BPMN expressions utilisent JUEL/Java EL, DMN utilise FEEL. Deux langages d'expression coexistent. Camunda 8 unifie sur FEEL
- **Decision history retention** : Operate stocke l'historique → ballonne, prévoir nettoyage automatique
- **DMN Modeler (Desktop)** : bonne UX mais separate de l'app Web, sync manuel
- **Cockpit / Optimize** Enterprise only : monitoring de base OK community, advanced = payant
- **Pas de support CMMN dans Camunda 8** : breaking change pour les utilisateurs CMMN historiques
- **Zeebe partition design** : compréhension scale horizontal non triviale au début
- **Connectors community vs Enterprise** : qualité variable, certains officiels deprecated
- **Updates breaking entre minor releases** : 8.5 → 8.6 a eu des breaking changes, lock la version
- **Documentation parfois en retard** vs releases alpha mensuelles

## Code minimal

### Lancer Camunda 8 self-managed (Docker Compose)

```bash
git clone https://github.com/camunda/camunda-platform.git
cd camunda-platform/docker-compose/camunda-8.x
docker compose up -d
# Operate : http://localhost:8081
# Tasklist : http://localhost:8082
# Identity : http://localhost:8084
```

### Évaluer une DMN décision via Camunda 8 REST API

```python
import requests

# 1. Déployer un fichier DMN
with open("credit_decision.dmn", "rb") as f:
    deploy_resp = requests.post(
        "http://localhost:26500/v2/deployments",
        files={"resources": ("credit_decision.dmn", f)},
    )
print(deploy_resp.json())

# 2. Évaluer
eval_resp = requests.post(
    "http://localhost:26500/v2/decision-definitions/eligibility/evaluation",
    json={
        "variables": {
            "age": 35,
            "income": 25000,
            "score_ml": 0.78,
        }
    },
)
print(eval_resp.json()["decisionOutput"])
# {"decision": "accepted_with_guarantor"}
```

### Camunda 7 — engine Java embedded (Spring Boot)

```java
// pom.xml dependency : org.camunda.bpm.springboot:camunda-bpm-spring-boot-starter
@SpringBootApplication
@EnableProcessApplication
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}

// Évaluer une DMN
@Autowired
private DecisionService decisionService;

DmnDecisionTableResult result = decisionService.evaluateDecisionTableByKey("eligibility",
    Variables.createVariables()
        .putValue("age", 35)
        .putValue("income", 25000)
);
System.out.println(result.getSingleResult().getSingleEntry());
```

### BPMN + DMN combo (Java, Camunda 7)

```java
// Démarrer un process BPMN qui invoque DMN à une étape
ProcessInstance pi = runtimeService.startProcessInstanceByKey(
    "loanApprovalProcess",
    Variables.createVariables()
        .putValue("customerId", "C-12345")
        .putValue("requestedAmount", 100000)
        .putValue("age", 35)
        .putValue("income", 80000)
);
// L'étape "Check eligibility" du BPMN invoque la DMN "eligibility"
// puis le gateway route selon le résultat
```

### Camunda Modeler — créer DMN visuellement

Téléchargement : [https://camunda.com/download/modeler/](https://camunda.com/download/modeler/). Application desktop (Electron) qui ouvre / crée des `.bpmn` et `.dmn`, drag-drop, deploy direct vers un cluster Camunda 7 ou 8.

### FEEL Copilot (2025)

Dans l'éditeur DMN Camunda Cloud / Modeler récent, suggestions IA pour FEEL :
```
Décrire : "le montant est entre 1000 et 50000 et le client est VIP"
Suggestion FEEL : [1000..50000] and customer.tier = "VIP"
```

## Liens

- [[Decision Model and Notation]] / [[Decision Tables]] / [[FEEL]] / [[BKM - Business Knowledge Model]] — concepts DMN
- [[BPMN DMN CMMN]] — combo standards OMG
- [[Decision Intelligence]] / [[DMN and ML hybrid]] — patterns architecturaux
- [[Drools]] — alternative open-source Java pur (sans le côté workflow Camunda 8)
- [[pyDMNrules]] — alternative Python pure
- [[OpenL Tablets]] — alternative Excel-driven
- Flowable, Activiti, jBPM — alternatives BPMN engines (avec moins de focus DMN)
- Camunda Cloud (SaaS) : https://camunda.com/products/cloud/
- Docs : https://docs.camunda.io/
- GitHub : https://github.com/camunda/camunda
- DMN Modeler : https://camunda.com/download/modeler/
