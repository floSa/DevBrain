---
galaxie: wiki
nom: Speech models (ASR/TTS)
alias: [Whisper, TTS, ASR, voice cloning, ElevenLabs, F5-TTS, voice agents]
type: concept
categorie: concept/multimodal
sous_categories: [speech, asr, tts, voice, multimodal]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Radford 2022 (Whisper)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, multimodal, speech, asr, tts]
---

# Speech models (ASR / TTS)

## TL;DR

Trois familles : **ASR** (Speech-to-Text — Whisper, Distil-Whisper, Faster-Whisper, Seamless), **TTS** (Text-to-Speech — ElevenLabs, F5-TTS, XTTS, Kokoro, OpenAI TTS), **Speech-to-Speech / voice agents** (OpenAI Realtime API, Gemini Live, Moshi, pipeline ASR→LLM→TTS classique). Use case majeur 2026 : **voice agents** (Vapi, Retell, LiveKit). Métriques : **WER** (Word Error Rate) ASR, **MOS** (Mean Opinion Score) TTS, **SECS** (speaker similarity) cloning. **Diarization** (pyannote, NeMo) pour multi-speaker. Latency P95 < 800ms = standard voice agents.

## Le problème

LLMs textual → besoin de :
- **Input voice** : parler à l'IA naturellement
- **Output voice** : IA parle naturellement
- **Cloning voice** : custom voices
- **Multi-speaker** : conversations, podcasts
- **Real-time** : voice agents

## L'idée

### ASR (Automatic Speech Recognition)

#### Whisper (Radford 2022, OpenAI)

Multi-language Transformer ASR. 96 langues. Open weights.

Versions :
- **Whisper Large v2, v3** : best quality
- **Whisper Large v3 turbo** : 8x faster, similar quality
- **Whisper Medium / Small / Tiny** : smaller

**Standard de fait** pour ASR open.

#### Distil-Whisper

Distilled Whisper. 6x faster, similar accuracy.

#### Faster-Whisper (CTranslate2)

C++ optimisé, 4x plus rapide que original.

#### WhisperX

Whisper + word-level alignment + diarization.

#### Seamless M4T (Meta)

ASR + traduction + TTS unified. Multi-modal.

#### Conformer (Google)

Architecture concurrence Whisper. Standard pour streaming.

#### Wav2Vec 2.0, HuBERT

Self-supervised speech encoders. Bases pour many ASR.

#### Canary (NVIDIA)

NeMo ASR competitive avec Whisper.

#### Moonshine

Edge-optimized ASR récent.

### TTS (Text-to-Speech)

#### Commercial

- **ElevenLabs** : industry leader, voice cloning, multi-language
- **OpenAI TTS / Realtime** : embedded GPT-4o
- **Google Cloud TTS** : standard cloud
- **Azure TTS** : Microsoft
- **Resemble.ai**, **Play.ht**, **Cartesia** : alternatives

#### Open-source

- **XTTS v2** (Coqui) : voice cloning, multi-language
- **F5-TTS** : récent, performant, voice cloning few-shot
- **Tortoise TTS** : classic, slow
- **Bark** : multilingual, sound effects
- **StyleTTS 2** : expressive
- **Fish Speech** : multi-language
- **Kokoro** : recent, light + fast
- **Parler-TTS** : ElevenLabs alternative open
- **OpenVoice** : voice cloning

### Voice cloning

À partir d'un échantillon court (3-30 sec), reproduire la voix.

- **ElevenLabs Voice Lab** : industry standard
- **XTTS v2** : open, multi-language
- **F5-TTS** : few-shot
- **OpenVoice** : open

Métrique : **SECS** (Speaker Encoder Cosine Similarity).

### Voice agents (real-time S2S)

#### Pipeline ASR → LLM → TTS

```
[Audio in] → [ASR (Whisper)] → [LLM] → [TTS] → [Audio out]
```

Standard. Latency cumulative.

#### Native voice-to-voice

- **OpenAI Realtime API (GPT-4o-realtime)** : native audio in/out, <500ms latency
- **Gemini Live** : Google
- **Anthropic voice** (Claude Sonnet voice)
- **Kyutai Moshi** : open, full-duplex

Native = pas de pipeline, model traite audio directement → low latency + emotion preservation.

#### Voice agent platforms

| Platform | Features |
|---|---|
| **Vapi** | Voice AI builder |
| **Retell** | Conversational AI |
| **Daily Bots** | WebRTC + agents |
| **Vocode** | Open-source voice |
| **LiveKit Agents** | WebRTC + LLM |
| **Pipecat** | Voice pipeline framework |

### Diarization

"Qui parle quand" en multi-speaker.

- **pyannote.audio** : standard open
- **NeMo Speaker Diarization** : NVIDIA
- **WhisperX** : integrated

### Music / sound

- **MusicGen** (Meta) : music from text
- **Stable Audio** : music + sound effects
- **Suno** : songs vocal
- **Udio** : songs alternative
- **AudioCLIP, CLAP** : audio embeddings
- **AudioLDM** : audio diffusion
- **Riffusion** : music via spectrogram diffusion
- **ElevenLabs SFX** : sound effects

### Métriques

#### ASR

- **WER** (Word Error Rate) : standard métrique
- **CER** (Character Error Rate) : pour langues sans whitespace
- **Real-time factor (RTF)** : speed (1.0 = real-time, < 1 = faster)

#### TTS

- **MOS** (Mean Opinion Score) : human eval 1-5
- **UTMOS** : automated MOS prediction
- **CER** between TTS output → ASR (round-trip)
- **SECS** : speaker similarity

#### Voice agents

- **Latency P95** : critical (< 800ms target)
- **TTFB** (Time To First audio Byte)
- **Conversational quality** : human eval

### Best practices

1. **Whisper Large v3 turbo** = default ASR
2. **ElevenLabs / OpenAI Realtime** pour quality TTS
3. **F5-TTS / XTTS** pour open voice cloning
4. **Vapi / Retell / LiveKit Agents** pour voice agents
5. **Latency budget** : ASR 200ms + LLM 300ms + TTS 200ms < 800ms
6. **Streaming partout** : ASR streaming, LLM streaming, TTS streaming
7. **Interruption handling** : user can interrupt, agent pauses
8. **VAD** (Voice Activity Detection) : detect when user finished
9. **Endpointing** : detect natural pause
10. **Echo cancellation** : critical sur device

## Quand c'est utile

- **Voice assistants** : Alexa-style
- **Customer support bots** : phone, web call
- **Accessibility** : screen readers, voice control
- **Education** : pronunciation, language learning
- **Transcription** : meetings, podcasts, calls
- **Subtitles** : video content
- **Audiobooks** : génération
- **Podcasts** : voice cloning, dubbing
- **Voice search** : on mobile
- **In-app voice command** : hands-free

## Quand ça ne marche pas / pièges

- **Accent / noise** : ASR struggles
- **Multi-language code-switch** : within sentence
- **Domain jargon** : medical, technical → ASR error rate up
- **Latency in pipeline** : ASR + LLM + TTS = 1s+
- **Interruption hard** : detect quand user veut interrompre
- **Voice cloning ethics** : deepfake, fraud risks
- **Multi-speaker overlap** : diarization hard
- **TTS prosody** : sounds robotic sometimes
- **Long sentences** : TTS may stumble
- **Low-resource languages** : open TTS / ASR weak
- **Real-time on edge** : Whisper tiny pour mobile, qualité réduite
- **Hallucinations ASR** : Whisper peut inventer mots sur audio silent / noisy

## Code minimal

```python
# 1. Whisper (open via HF)
from transformers import pipeline

asr = pipeline("automatic-speech-recognition",
               model="openai/whisper-large-v3-turbo",
               device="cuda")
result = asr("audio.mp3", chunk_length_s=30, batch_size=8)
print(result["text"])

# 2. Faster-Whisper (CTranslate2, plus rapide)
from faster_whisper import WhisperModel
model = WhisperModel("large-v3-turbo", device="cuda", compute_type="float16")
segments, info = model.transcribe("audio.mp3", language="fr")
for s in segments:
    print(f"[{s.start:.2f} → {s.end:.2f}] {s.text}")

# 3. WhisperX (avec diarization + word alignment)
import whisperx
model = whisperx.load_model("large-v3", "cuda")
audio = whisperx.load_audio("audio.mp3")
result = model.transcribe(audio)
# Align words
model_a, metadata = whisperx.load_align_model(language_code="fr", device="cuda")
result = whisperx.align(result["segments"], model_a, metadata, audio, "cuda")
# Diarization
diarize_model = whisperx.DiarizationPipeline(use_auth_token="...", device="cuda")
diarize_segments = diarize_model(audio)
result = whisperx.assign_word_speakers(diarize_segments, result)

# 4. OpenAI TTS
from openai import OpenAI
client = OpenAI()

with client.audio.speech.with_streaming_response.create(
    model="tts-1-hd",
    voice="alloy",  # alloy, echo, fable, onyx, nova, shimmer
    input="Hello, this is a test."
) as response:
    response.stream_to_file("output.mp3")

# 5. ElevenLabs
from elevenlabs.client import ElevenLabs
client = ElevenLabs(api_key="...")
audio = client.text_to_speech.convert(
    text="Bonjour, ça va ?",
    voice_id="...",
    model_id="eleven_multilingual_v2"
)

# 6. F5-TTS (open, voice cloning)
# pip install f5-tts
# from f5_tts.api import F5TTS
# f5 = F5TTS()
# wav, sr = f5.infer(ref_audio="speaker_sample.wav", ref_text="...",
#                     gen_text="Voici un nouveau texte")
# import soundfile as sf
# sf.write("output.wav", wav, sr)

# 7. XTTS v2 (open, multi-language voice cloning)
from TTS.api import TTS
tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to("cuda")
tts.tts_to_file(text="Hello, comment ça va ?",
                speaker_wav="reference.wav",
                language="fr",
                file_path="output.wav")

# 8. OpenAI Realtime API (S2S native)
import asyncio
from openai import AsyncOpenAI

async def realtime_chat():
    client = AsyncOpenAI()
    async with client.beta.realtime.connect(model="gpt-4o-realtime-preview") as conn:
        await conn.session.update(session={"modalities": ["audio", "text"]})
        await conn.conversation.item.create(item={
            "type": "message", "role": "user",
            "content": [{"type": "input_audio", "audio": audio_base64}]
        })
        await conn.response.create()
        async for event in conn:
            if event.type == "response.audio.delta":
                # Stream audio to client
                pass

# 9. Vapi (voice agent platform)
# Build a phone agent with LLM + tools + voice
# https://docs.vapi.ai

# 10. pyannote diarization (qui parle quand)
from pyannote.audio import Pipeline
pipeline = Pipeline.from_pretrained("pyannote/speaker-diarization-3.1", use_auth_token="...")
diarization = pipeline("audio.wav")
for turn, _, speaker in diarization.itertracks(yield_label=True):
    print(f"{turn.start:.1f}s → {turn.end:.1f}s : {speaker}")
```

## Pour aller plus loin

- Radford et al., *Robust Speech Recognition via Large-Scale Weak Supervision* (Whisper, OpenAI 2022)
- *Distil-Whisper* (HF 2023)
- Casanova et al., *XTTS v2* (Coqui 2024)
- Chen et al., *F5-TTS: A Fairytaler that Fakes Fluent and Faithful Speech with Flow Matching* (2024)
- *OpenAI Realtime API* announcement (Oct 2024)
- *ElevenLabs* docs
- *Vapi*, *Retell*, *LiveKit Agents* documentation
- *Pyannote audio* documentation
- **Liens internes** : [[Vision Language Models]], [[Self-attention]], [[Diffusion models]] (audio diffusion)
