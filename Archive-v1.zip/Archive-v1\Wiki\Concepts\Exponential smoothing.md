---
galaxie: wiki
nom: Exponential smoothing (ETS)
alias: [ETS, Holt-Winters, simple exponential smoothing, SES, double exp smoothing]
type: concept
categorie: concept/time-series
sous_categories: [ets, exponential-smoothing, holt-winters, time-series, forecasting]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Brown 1956, Holt 1957, Winters 1960, Hyndman]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, time-series, forecasting, ets, holt-winters]
---

# Exponential smoothing — ETS

## TL;DR

Famille de modèles de forecasting qui **lissent** la série en pondérant **exponentiellement** les observations passées (plus récent → plus de poids). De **SES** (level only) à **Holt** (level + trend) à **Holt-Winters** (+ seasonality), formalisée par **ETS** (Error-Trend-Seasonality, Hyndman 2002). Famille avec **30 modèles** combinant Error{A,M} × Trend{N,A,Ad,M,Md} × Seasonality{N,A,M}. **Auto-ETS** sélectionne via AIC. Standard, simple, robuste — souvent compétitif vs ARIMA (M-competitions). Implémenté dans statsforecast, forecast (R), statsmodels.

## Le problème

Comment forecaster une série avec **niveau, tendance et saisonnalité** sans la complexité d'ARIMA (pas besoin de différencier, identifier $p,q,d$) ? L'idée : moyenner les passé avec poids décroissants exponentiellement, mettant à jour à chaque pas via des **smoothing equations** lisibles.

## L'idée

### Simple Exponential Smoothing (SES)

Pour série sans tendance ni saisonnalité :

$$ \hat y_{t+1} = \alpha y_t + (1 - \alpha) \hat y_t $$

avec $\alpha \in [0, 1]$ le **smoothing parameter**.

Équivalent à :

$$ \hat y_{t+1} = \sum_{j=0}^t \alpha (1-\alpha)^j y_{t-j} $$

→ moyenne pondérée des observations, poids décroissants.

- $\alpha$ grand (~0.8) : réagit vite, peu de lissage
- $\alpha$ petit (~0.1) : très lissé, lent à réagir

**Forecast multi-step** : plat ($\hat y_{t+h} = \hat y_{t+1}$ pour tout $h$).

### Holt (Linear Trend)

Ajoute composante de tendance :

$$ \ell_t = \alpha y_t + (1-\alpha)(\ell_{t-1} + b_{t-1}) $$
$$ b_t = \beta (\ell_t - \ell_{t-1}) + (1-\beta) b_{t-1} $$
$$ \hat y_{t+h} = \ell_t + h \cdot b_t $$

- $\ell_t$ : niveau (level)
- $b_t$ : pente (trend)
- $\alpha, \beta$ : smoothing params (level, trend)

**Forecast** : extrapolation linéaire de la tendance.

#### Damped trend (Gardner-McKenzie 1985)

Évite les tendances qui explosent à long terme :

$$ \hat y_{t+h} = \ell_t + (\phi + \phi^2 + \dots + \phi^h) b_t $$

avec $\phi \in (0, 1)$. La tendance s'atténue à mesure que $h$ grandit. **Souvent meilleur** que Holt linéaire en pratique.

### Holt-Winters (Triple Exp Smoothing)

Ajoute saisonnalité :

$$ \ell_t = \alpha (y_t - s_{t-m}) + (1-\alpha)(\ell_{t-1} + b_{t-1}) $$
$$ b_t = \beta (\ell_t - \ell_{t-1}) + (1-\beta) b_{t-1} $$
$$ s_t = \gamma (y_t - \ell_t) + (1-\gamma) s_{t-m} $$
$$ \hat y_{t+h} = \ell_t + h b_t + s_{t-m+(h \mod m)} $$

Avec $m$ = période saisonnière, $s_t$ = composante saisonnière, $\gamma$ smoothing param.

Deux variantes :
- **Additive seasonality** : amplitude saisonnière constante (formules ci-dessus)
- **Multiplicative seasonality** : amplitude proportionnelle au niveau (utile pour séries growth-y)

### Taxonomie ETS (Hyndman 2002)

Notation **ETS(Error, Trend, Season)** :

| Position | Options |
|---|---|
| **Error** | A (additive) ou M (multiplicative) |
| **Trend** | N (none), A (additive), Ad (damped), M (multi), Md (damped multi) |
| **Season** | N (none), A (additive), M (multiplicative) |

30 modèles au total. Quelques exemples :
- **ETS(A, N, N)** = SES additive error
- **ETS(A, A, N)** = Holt additive
- **ETS(A, Ad, A)** = Holt-Winters damped additive
- **ETS(M, A, M)** = Holt-Winters multiplicative
- **ETS(M, Md, M)** : multi + damped, robuste long horizon

**Auto-ETS** : sélectionne le meilleur via AICc.

### Avantages / Limites

**Avantages** :
- **Simple, lisible** : smoothing equations interprétables
- **Robuste** : peu de paramètres, marche sur courtes séries
- **Pas de différenciation** à gérer
- **Forecast probabiliste** : intervalles de prédiction via formulation state-space
- **Damped trend** très efficace pour le long horizon
- **Performance M-comp** : Theta + ETS souvent en top du M-competitions

**Limites** :
- **Univarié** (pas de covariables natives)
- **Linéaire / log-linéaire** (multiplicative)
- **Une seule saisonnalité** par modèle (utiliser TBATS pour multi-saison)
- **Pas de feature engineering** : pure univarié

### Lien avec ARIMA

Surprise : certains ETS correspondent à des ARIMA particuliers.

- ETS(A, N, N) ≡ ARIMA(0, 1, 1)
- ETS(A, A, N) ≡ ARIMA(0, 2, 2)
- ETS(A, Ad, N) ≡ ARIMA(1, 1, 2)

Mais les ETS multiplicatifs et la plupart des saisonniers n'ont **pas** d'équivalent ARIMA. ETS est plus expressif sur saisonnalité multiplicative.

### State-space formulation

Hyndman et al. (2008) : tous les ETS ont une formulation espace d'états (state-space), permettant :
- **Intervalles de prédiction** avec hypothèses gaussiennes ou non
- **MLE** rigoureuse
- **Smoothing** + filtering
- **Forecasts probabilistes** complets

C'est ce qui rend ETS rigoureux et calibré, pas juste heuristique.

### Best practices

1. **Toujours essayer ETS + ARIMA + Naive saisonnier** en baseline
2. **Auto-ETS** est très robuste (statsforecast, R `ets()`)
3. **Damped trend** mieux pour h > 6 souvent
4. **Multiplicative seasonality** si la série croît (revenue, traffic)
5. **MASE < 1** vs naïve saisonnier obligatoire — sinon le modèle ne sert à rien
6. **Backtesting walk-forward** obligatoire ([[Walk-forward CV]])

## Quand c'est utile

- **Baseline forecasting** : avec ARIMA, must-have
- **Séries courtes** (50-100 points) : ETS très robuste
- **Multi-step forecasts** : damped trend pour long horizon
- **Beaucoup de séries** (retail SKU, énergie) : statsforecast vectorisé, des milliers d'ETS en parallèle
- **Saisonnalité multiplicative** : business growth
- **Pas de covariables** disponibles → univarié pur

## Quand ça ne marche pas / pièges

- **Séries avec covariables** : ETS ne les intègre pas. Préférer SARIMAX ou ML.
- **Multi-saisons** (jour de semaine + annuel) : ETS gère mal. Utiliser TBATS, Prophet, ou décomposition + ML.
- **Outliers / change points** : ETS lent à s'ajuster. Détecter + corriger.
- **Counts intermittents** (zéros) : ETS inadapté. Voir [[Intermittent demand]] (Croston).
- **Non-linéarités fortes** : ETS reste linéaire / log-linéaire.
- **Confusion damped trend** : sans damped, forecast peut diverger sur long horizon
- **Multiplicative avec zéros** : log impossible. Utiliser additive ou box-cox transform.
- **Long-term forecast** : tous les modèles deviennent flous, ETS ne fait pas exception. Intervalles s'élargissent vite.
- **Sélection automatique louper** : auto-ETS peut choisir multiplicative sur série pas adaptée. Vérifier visuellement le fit.

## Code minimal

```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.holtwinters import ExponentialSmoothing, SimpleExpSmoothing, Holt
from statsmodels.datasets.airline import load

# Data : airline passengers
data = load().data.iloc[:, 0]

# 1. SES (simple)
ses = SimpleExpSmoothing(data).fit()
print(f"SES α = {ses.params['smoothing_level']:.3f}")

# 2. Holt (linear trend)
holt = Holt(data).fit()
print(f"Holt α = {holt.params['smoothing_level']:.3f}, β = {holt.params['smoothing_trend']:.3f}")

# 3. Holt-Winters additive
hw_add = ExponentialSmoothing(data, trend='add', seasonal='add', seasonal_periods=12).fit()
# Multiplicatif
hw_mul = ExponentialSmoothing(data, trend='add', seasonal='mul', seasonal_periods=12).fit()
# Damped + multiplicatif (souvent meilleur sur ce type de série)
hw_dam = ExponentialSmoothing(data, trend='add', seasonal='mul', damped_trend=True, 
                                seasonal_periods=12).fit()

# Forecast
forecast = hw_dam.forecast(steps=24)
print(forecast[:5])

# Intervalles de prédiction
pred = hw_dam.get_forecast(steps=24)
# (pas dispo dans statsmodels.holtwinters classique, utiliser ETSModel)

# 4. ETS formulation state-space
from statsmodels.tsa.exponential_smoothing.ets import ETSModel
ets = ETSModel(data, error='add', trend='add', seasonal='mul', damped_trend=True,
                seasonal_periods=12).fit()
forecast_ets = ets.forecast(steps=24)
intervals = ets.get_prediction(start=len(data), end=len(data) + 23).conf_int(alpha=0.05)

# Comparer AIC entre modèles
print(f"HW add AIC = {hw_add.aic:.1f}")
print(f"HW mul AIC = {hw_mul.aic:.1f}")
print(f"HW damped mul AIC = {hw_dam.aic:.1f}")
# Plus petit = mieux

# 5. statsforecast (1000x plus rapide sur grand volume)
from statsforecast import StatsForecast
from statsforecast.models import AutoETS, HoltWinters

df = pd.DataFrame({'unique_id': 'air', 'ds': pd.date_range('1949', periods=len(data), freq='M'),
                    'y': data.values})

sf = StatsForecast(models=[AutoETS(season_length=12), HoltWinters(season_length=12)], freq='M')
sf.fit(df)
forecast_sf = sf.predict(h=12, level=[95])
print(forecast_sf.head())

# 6. Plot decomposition (level / trend / seasonality)
fig, axes = plt.subplots(3, 1, figsize=(10, 8))
hw_dam.level.plot(ax=axes[0], title="Level")
hw_dam.trend.plot(ax=axes[1], title="Trend")
hw_dam.season.plot(ax=axes[2], title="Seasonality")
```

## Pour aller plus loin

- Hyndman & Athanasopoulos, *Forecasting: Principles and Practice* (3e éd.) — chap. 8
- Hyndman, Koehler, Ord, Snyder, *Forecasting with Exponential Smoothing: The State Space Approach* (Springer 2008) — bible
- Holt, *Forecasting Seasonals and Trends by Exponentially Weighted Moving Averages* (1957)
- Gardner, *Exponential smoothing: The state of the art* — Part II (IJF 2006)
- **Liens internes** : [[ARIMA SARIMA]], [[Stationarity]], [[Forecasting framing]], [[Forecasting metrics]], [[statsforecast]] (service), [[Prophet]] (service)
