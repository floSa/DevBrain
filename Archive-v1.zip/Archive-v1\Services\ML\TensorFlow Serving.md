---
galaxie: dev
nom: TensorFlow Serving
alias: [tf-serving, tfserving, tensorflow-serving]
categorie: ml/serving
sous_categories: [serving, tensorflow, grpc, rest, savedmodel, versioning]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: C++
clients_officiels: [python, java, go, grpc]
plateforme: [linux, macos]
score: 3
mes_projets: []
alternatives: ["[[NVIDIA Triton]]", "[[TorchServe]]", "[[BentoML]]", "[[KServe]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, serving, tensorflow]
url_officiel: https://www.tensorflow.org/tfx/guide/serving
url_docs: https://www.tensorflow.org/tfx/serving/serving_basic
url_repo: https://github.com/tensorflow/serving
---

# TensorFlow Serving

## Pourquoi

**Serveur d'inférence officiel TensorFlow** (en C++ pour la perf), mature depuis 2016. Optimisé pour le format **SavedModel**, expose **gRPC** (port 8500) + **REST** (port 8501). Différenciateurs :
- **Versioning de modèles natif** : multiples versions chargées simultanément, routing via version policy (latest, specific, label)
- **Hot reload** sans downtime quand un nouveau SavedModel apparaît sur disque
- **Batching dynamique** : agrège les requêtes pour throughput (config fine-grained)
- **Modèle assets / signatures** : signatures multiples par modèle (predict, classify, regress)

Standard si tu sers du **TF / Keras en prod**. Pour multi-framework ou GPU optimisé H100+, **Triton** est devenu le défaut. TF Serving reste référence côté TF pur.

## Quand l'utiliser

- **Modèles TensorFlow / Keras** en prod (SavedModel)
- **gRPC pour latence basse** (< 5ms typiques en CPU)
- **Versioning multi-modèle** : A/B test version, canary
- **Hot reload SavedModel** sans downtime (drop fichier → server reload)
- **Stack TFX** : pipeline TFX exporte directement vers TF Serving
- **Throughput max via batching** : `max_batch_size`, `batch_timeout_micros` tunables
- **Edge inference TF Lite** : TF Serving plus serveur, mais TF écosystème complet

## Quand NE PAS l'utiliser

- **Modèles PyTorch** → [[TorchServe]] / vLLM / [[NVIDIA Triton]]
- **Multi-framework** → [[NVIDIA Triton]] / [[BentoML]] / [[Seldon Core]]
- **LLM transformers** → [[vLLM]] / [[TGI]] / [[SGLang]]
- **GPU H100+ optimisé** : [[NVIDIA Triton]] + TensorRT mieux
- **Petite équipe sans infra** : Docker + tuning → préférer cloud managed (Vertex AI, SageMaker)

## Pièges connus

- **TF-only** : pas de PyTorch, sklearn, XGBoost
- **Setup Docker config-driven** : `models.config` + `batching.config` à écrire (pas trivial)
- **Logging gRPC moins amical** que REST pour debug
- **Pas d'inference graphs** comme Seldon / KServe (un modèle, point)
- **Versioning policies** : latest par défaut, mais policy custom verbose (protobuf)
- **Memory growth** : modèles laissés en mémoire jusqu'à explicit unload → tuner `num_load_threads`, `model_config_list`
- **Pas natif Kubernetes** : à wrapper dans KServe / Seldon pour autoscale
- **SavedModel signatures mal comprises** : tensor names input/output critiques
- **Batching latence vs throughput trade-off** : `batch_timeout_micros` trop bas = pas de batching, trop haut = latence p99 explose
- **TFRT (TF Runtime moderne)** : optionnel, parfois plus rapide, parfois moins selon modèle

## Code minimal

```bash
# Exporter un modele Keras en SavedModel
python -c "
import tensorflow as tf
model = tf.keras.applications.MobileNetV2(weights='imagenet')
model.export('models/mobilenet/1')
"

# Lancer TF Serving via Docker
docker run -p 8500:8500 -p 8501:8501 \
    -v $PWD/models:/models \
    -e MODEL_NAME=mobilenet \
    tensorflow/serving:2.15.0
```

```python
# Client REST
import requests
import numpy as np
import json

data = {
    "signature_name": "serving_default",
    "instances": np.random.rand(1, 224, 224, 3).tolist(),
}
response = requests.post(
    "http://localhost:8501/v1/models/mobilenet:predict",
    data=json.dumps(data),
)
print(response.json()["predictions"][0][:5])

# Specifier une version
# http://localhost:8501/v1/models/mobilenet/versions/2:predict
```

```python
# Client gRPC (plus rapide, latence basse)
import grpc
import tensorflow as tf
from tensorflow_serving.apis import predict_pb2, prediction_service_pb2_grpc

channel = grpc.insecure_channel("localhost:8500")
stub = prediction_service_pb2_grpc.PredictionServiceStub(channel)

request = predict_pb2.PredictRequest()
request.model_spec.name = "mobilenet"
request.model_spec.signature_name = "serving_default"
request.inputs["input"].CopyFrom(
    tf.make_tensor_proto(np.random.rand(1, 224, 224, 3).astype("float32"))
)

response = stub.Predict(request, timeout=5.0)
print(tf.make_ndarray(response.outputs["output_0"])[0][:5])
```

```text
# models.config (multi-modeles + versioning)
model_config_list {
  config {
    name: "mobilenet"
    base_path: "/models/mobilenet"
    model_platform: "tensorflow"
    model_version_policy { specific { versions: 1, versions: 2 } }
  }
}
```

## Liens

- [[NVIDIA Triton]] — alternative multi-framework, GPU first
- [[TorchServe]] — équivalent PyTorch
- [[BentoML]] — alternative Python-first
- [[KServe]] / [[Seldon Core]] — wrappers K8s natifs
- TFX — pipeline ML qui exporte vers TF Serving
- Docs : https://www.tensorflow.org/tfx/guide/serving
- GitHub : https://github.com/tensorflow/serving
