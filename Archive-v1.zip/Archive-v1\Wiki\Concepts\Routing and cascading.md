---
galaxie: wiki
nom: LLM routing & cascading
alias: [RouteLLM, NotDiamond, model cascade, cheap-to-expensive, LiteLLM]
type: concept
categorie: concept/llm-production
sous_categories: [routing, cascading, cost-optimization, llm-ops]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Ong 2024 (RouteLLM)]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, routing, production, cost]
---

# LLM routing & cascading

## TL;DR

**Router** entre plusieurs modèles selon complexité de la query : queries simples → small model (cheap), queries complexes → big model (expensive). **Cascade** : essayer small first, escalate si fail/low confidence. Outils : **RouteLLM**, **NotDiamond**, **Martian**, **Unify**, **OpenRouter**, **LiteLLM router**, **Portkey**. Économies typiques : **50-80%** sur cost sans perte significative qualité. Variants : task-based, cost-based, confidence-based, **load balancing**, **failover**. Standard 2026 pour apps production multi-modèles.

## Le problème

Chaque LLM a un trade-off cost/quality :
- GPT-4o : $$$ mais excellent
- Claude Sonnet : $$ très bon
- Claude Haiku : $ rapide
- Open-source local : free mais limité

**90% des queries** sont simples (greetings, FAQ) — utiliser GPT-4o = waste.
**10% sont complexes** — needs Claude Opus.

Comment **router** ?

## L'idée

### Multi-model routing

#### Task-based routing

Classifier la query en categorie, route vers approprié :

```
"Hello!" → Haiku (cheap)
"Explain quantum mechanics step by step" → Claude Opus
"Translate to French" → GPT-4o-mini
"Write code with tests" → Claude Sonnet
```

#### Cost-based routing

Default to cheap, escalate si :
- Confidence low
- Query length high
- Specific keywords

#### Quality-based routing

Always route to **best available** model. Pas d'économie, optimise qualité.

#### Load balancing

Multiple providers même modèle (OpenAI + Azure OpenAI) :
- Round-robin
- Quota-aware
- Latency-aware

#### Failover

Provider A down → route to provider B (Anthropic → Bedrock). Resilience.

### Cascading

```
1. Try smallest model (Haiku)
   ↓ if confidence low / fail
2. Try medium (Sonnet)
   ↓ if confidence low / fail
3. Try big (Opus)
```

Économise quand cheap suffit.

#### Confidence-based escalation

```python
response_cheap = llm_cheap(query)
if response_cheap.confidence < THRESHOLD:
    response = llm_expensive(query)
else:
    response = response_cheap
```

Comment estimer confidence ? :
- Logprobs (perplexity du output)
- LLM self-rating
- Output length variability
- Specific keywords ("I'm not sure")
- Verifier model

#### Verifier-based

Generate avec cheap, **verifier model** judges. If wrong, escalate.

### Frameworks

#### RouteLLM (Ong 2024)

Open-source router academic. Train classifier sur preference data.

#### NotDiamond

Commercial : auto-select best model per query.

#### Martian

Multi-model router, automatic.

#### Unify

Multi-provider gateway + auto-route.

#### OpenRouter

Aggregator de 100+ models, single API. Pricing transparent.

#### LiteLLM Router

Open-source proxy :
- Unified API for 100+ LLMs
- Load balancing, fallback, retries
- Cost tracking

#### Portkey

Production gateway : cache + routing + observability.

#### Helicone

Proxy + caching + routing.

### Patterns courants

#### Cheap-to-expensive cascade

Most common. Save 50-80%.

#### Model committee

Run N models in parallel, take majority vote / best. Higher quality, higher cost.

#### Speculative cascade

Generate avec cheap, verify avec expensive. If verify says wrong, redo with expensive.

→ Similar to [[Speculative decoding]] mais au niveau request.

#### Provider failover

Anthropic down → fallback Bedrock. Resilience.

### Routing décisions

#### Static (LLM-based classifier)

Classifier query → category → model.

```python
def route(query):
    cat = classify(query)
    return MODEL_MAP[cat]
```

#### Dynamic (learned)

Train classifier on (query, model_x, success).

#### Hybrid

Static rules + learned for edge cases.

### Quality vs cost trade-off

Plot Pareto frontier (cost vs quality) :
- Single model = 1 point
- Routing = move along curve

Typical gain : at same quality, **2-5x cheaper**.

### Best practices

1. **LiteLLM** : default abstraction layer
2. **Start with simple cascade** : 2 models
3. **Eval on production traces** : pas synthetic
4. **Monitor** : quality drop ? cost decrease ?
5. **Failover** obligatoire : provider downtime happens
6. **Cache** semantic + exact (cf. [[LLM caching]])
7. **A/B test** routing strategies
8. **Per-feature routing** : different models per use case
9. **Track confidence** : refine threshold over time
10. **Cost alerts** : detect routing breakdown

## Quand c'est utile

- **Production cost reduction** : 50-80% économie
- **Multi-provider** : pas vendor lock-in
- **High-availability** : failover essential
- **Burst traffic** : load balance across providers
- **Quality-sensitive features** : route to best
- **Latency-sensitive** : route to fast (Groq, Cerebras)
- **Geo-distributed** : route to nearest provider
- **Tier-based pricing** : free users → cheap, paid → premium

## Quand ça ne marche pas / pièges

- **Wrong classifier** : route to weak model when needed strong → quality drop
- **Confidence estimation imparfait** : escalation rate too high → cost up
- **Vendor lock-in** : routing logic dépend de providers
- **Adversarial** : user knows routing, gaming the system
- **Inconsistent behavior** : same query → different model day-to-day
- **Debug harder** : multi-model interactions
- **Cache locality** : routing breaks caching strategies
- **Streaming pain** : switching models mid-conversation hard
- **Provider quirks** : tools / function calling différents
- **Cost monitoring complexe** : per-provider, per-model
- **Failover latency** : detection + switch adds delay

## Code minimal

```python
# 1. LiteLLM (standard)
# pip install litellm
from litellm import completion, Router

router = Router(
    model_list=[
        {"model_name": "gpt-4o-mini",
         "litellm_params": {"model": "openai/gpt-4o-mini", "api_key": "..."},
         "rpm": 1000},
        {"model_name": "claude-haiku",
         "litellm_params": {"model": "anthropic/claude-3-haiku-20240307", "api_key": "..."},
         "rpm": 1000},
    ],
    fallbacks=[{"gpt-4o-mini": ["claude-haiku"]}],  # if gpt fails, use claude
    routing_strategy="usage-based-routing",  # or "least-busy", "latency-based"
)

response = router.completion(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Hello"}]
)

# 2. Simple cascade
def cascade(query):
    # Try cheap first
    try:
        response = call_haiku(query)
        if estimate_confidence(response) > 0.8:
            return response
    except Exception:
        pass
    
    # Escalate to sonnet
    try:
        response = call_sonnet(query)
        if estimate_confidence(response) > 0.7:
            return response
    except Exception:
        pass
    
    # Last resort opus
    return call_opus(query)

def estimate_confidence(response):
    # Heuristic : check for hedging phrases
    hedges = ["I'm not sure", "I don't know", "It's unclear"]
    if any(h in response.lower() for h in hedges):
        return 0.5
    return 0.9

# 3. Task-based routing
TASK_ROUTING = {
    "code": "claude-3-7-sonnet-latest",
    "math": "o1",
    "translation": "gpt-4o-mini",
    "casual": "claude-3-haiku-20240307",
    "creative": "claude-3-7-sonnet-latest",
}

def classify_task(query):
    # LLM classifier or rules
    response = call_classifier(query)
    return response.task

def route_by_task(query):
    task = classify_task(query)
    model = TASK_ROUTING.get(task, "claude-3-7-sonnet-latest")
    return call_llm(model, query)

# 4. RouteLLM
# pip install routellm
# from routellm.controller import Controller
# controller = Controller(routers=["mf"], strong_model="gpt-4o", weak_model="gpt-4o-mini")
# response = controller.chat.completions.create(
#     messages=[{"role": "user", "content": "..."}],
#     model="router-mf-0.5"  # threshold
# )

# 5. OpenRouter (aggregator)
from openai import OpenAI
client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key="OPENROUTER_KEY"
)
response = client.chat.completions.create(
    model="anthropic/claude-3.5-sonnet",  # ou "openai/gpt-4o", "meta-llama/llama-3-70b", etc.
    messages=[{"role": "user", "content": "..."}]
)

# 6. Speculative cascade (verifier)
def speculative_cascade(query):
    draft = call_haiku(query)
    
    # Verifier checks
    verification = call_sonnet(f"Is this response correct for the query?\nQuery: {query}\nResponse: {draft}\n\nAnswer 'CORRECT' or 'INCORRECT'.")
    
    if "CORRECT" in verification:
        return draft
    else:
        return call_sonnet(query)  # full re-do

# 7. Custom routing with cost tracking
class CostAwareRouter:
    def __init__(self):
        self.cost_per_token = {
            "haiku": {"input": 0.25, "output": 1.25},  # per 1M
            "sonnet": {"input": 3.0, "output": 15.0},
            "opus": {"input": 15.0, "output": 75.0},
        }
    
    def route(self, query, max_cost_usd=0.01):
        # Estimate cost
        n_tokens = len(query) // 4
        for model in ["haiku", "sonnet", "opus"]:
            cost = (n_tokens * self.cost_per_token[model]["input"] / 1e6 +
                    1000 * self.cost_per_token[model]["output"] / 1e6)
            if cost <= max_cost_usd and self.is_capable(query, model):
                return model
        return "haiku"  # fallback
    
    def is_capable(self, query, model):
        # Custom logic
        return True

# 8. Load balancing multi-region
import random
PROVIDERS = ["openai-us", "openai-eu", "azure-openai-us", "anthropic"]

def route_random(query):
    provider = random.choice(PROVIDERS)
    return call_provider(provider, query)
```

## Pour aller plus loin

- Ong et al., *RouteLLM: Learning to Route LLMs with Preference Data* (2024)
- *LiteLLM* documentation — production standard
- *OpenRouter* docs — aggregator
- *NotDiamond*, *Martian*, *Unify*, *Portkey* docs
- Hamel Husain blogs on LLM routing patterns
- *Helicone* docs sur routing
- **Liens internes** : [[Inference optimization]], [[LLM observability]], [[Reliability patterns]], [[LLM caching]]
