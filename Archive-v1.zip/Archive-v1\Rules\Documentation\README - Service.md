---
galaxie: dev
type: rule
domaine: documentation
applicable: global
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, documentation, service]
---

# Règle — Documentation par service

## Principe (1 phrase)
Chaque service externe intégré dans un projet doit posséder son **README.md dédié** dans `services/<nom>/README.md`, indépendamment des règles spécifiques par type de service.

## MUST

- Tout service tiers intégré (DB, broker, vector store, LLM, storage…) a un `services/<nom>/README.md`.
- Le README contient AU MINIMUM :
  - **Rôle métier** : ce que ce service fait pour l'application
  - **Contrat d'interface** : entrées/sorties attendues
  - **Dépendances** : autres services dont il dépend ou qui dépendent de lui
  - **Configuration** : variables d'env requises, fichiers de config
  - **Liens** : doc officielle + fiche dans le DevBrain (`[[<Service>]]`)
- Les règles spécifiques par type (DB relationnelle, vector, graph, LLM…) **complètent** cette base — elles ne la remplacent pas.

## SHOULD

- Inclure un schéma de communication (Mermaid) si > 2 services interagissent
- Documenter le démarrage local (commande `docker-compose up <service>` ou équivalent)
- Lister les pièges courants (lien vers `Bugs/REX - <Service>.md` si applicable)
- Mentionner les choix d'architecture critiques avec ADR

## NICE

- Liens vers les dashboards de monitoring du service en prod
- Captures d'écran des UIs admin (ex: Grafana, Adminer, Mongo Express)

## Structure recommandée du dossier

```
mon-projet/
├── services/
│   ├── postgres/
│   │   ├── README.md            ← rôle + contrat (cette règle)
│   │   ├── schema.sql           ← schéma initial (lecture humaine)
│   │   └── alembic/             ← migrations
│   ├── qdrant/
│   │   ├── README.md
│   │   └── init_collections.py
│   └── ...
```

## Exemples bons / mauvais

### Mauvais

```markdown
# postgres
DB pour l'app.
URL : postgresql://...
```

### Bon

```markdown
# Service — Postgres

## Rôle métier
Stockage principal : utilisateurs, sessions, contenus, métadonnées des fichiers
uploadés. Source de vérité transactionnelle.

## Contrat d'interface
- Connexion via `DATABASE_URL`
- Schéma `public` pour les tables applicatives
- Schéma `audit` pour les logs (lecture seule depuis l'app)

## Dépendances
- En amont : aucune (root data store)
- En aval : services API, jobs background

## Configuration
Variables d'env (cf. `.env.example`) :
- `DATABASE_URL` — postgresql://user:pass@host:5432/db
- `POSTGRES_POOL_SIZE` — défaut 10

## Liens
- DevBrain : [[Postgres]] · [[REX - Postgres]]
- Doc : https://www.postgresql.org/docs/
- ADR migrations : `docs/adr/0003-alembic-strategy.md`
```

## Exceptions

- Services purement infra (reverse proxy nginx) : un `infra/<nom>/README.md` court suffit
- Services en cours d'évaluation (POC) : autorisé README minimal avec mention `STATUS: en évaluation`

## Voir aussi

- [[Database-Relational]], [[Database-Vector]], [[Database-Graph]] — règles spécifiques
- [[Storage-Object]], [[Orchestration-Data]], [[LLM-Orchestration]], [[Document-Processing]]
- [[Config-Env]] — gestion des `.env`
- Templates : `Templates/ServiceDocs/`
