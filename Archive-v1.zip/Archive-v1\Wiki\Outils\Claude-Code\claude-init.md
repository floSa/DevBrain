---
galaxie: wiki
nom: init
type: claude-code-skill
plateforme: claude-code
categorie: skill/dev-flow
sous_categories: [bootstrap, claude-md, project-setup]
auteur: Anthropic
source: claude-code natif
source_url: https://docs.claude.com/en/docs/claude-code
install_cmd: 
install_doc: 
licence: 
licence_type: proprietary
domaines: [data-science, data-eng, mlops, ml-eng, ai-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, bootstrap]
---

# init

## Pourquoi

Skill **bundled** Claude Code qui **génère un `CLAUDE.md`** pour un projet en analysant l'arborescence existante. Au lieu d'écrire ce fichier à la main, tu lances `/init` (ou demandes à l'agent), il te livre un draft cohérent avec ce qu'il trouve dans le repo.

C'est ton point de départ pour bootstrap un projet — et accessoirement, c'est *le seul* moyen de générer un `CLAUDE.md` qui suive les conventions Anthropic dès le début.

## Quand l'utiliser

- Nouveau projet : tu viens de `git init`, ou tu hérites d'un repo sans CLAUDE.md
- Refactor : ton CLAUDE.md a divergé de l'arbo, tu veux régénérer un baseline propre
- Bootstrap d'un sous-module qui a besoin de son propre CLAUDE.md

## Quand NE PAS l'utiliser

- Tu as un CLAUDE.md custom finement réglé — `/init` peut t'écraser des choses, fais un backup
- Tu travailles sur DevBrain lui-même → utilise `CLAUDE-project.md` comme template direct, pas `/init`

## Comment l'installer

Natif Claude Code, déclenchable via `/init` dans une session.

## Exemples d'usage

```
> /init
# ou
> Génère-moi un CLAUDE.md pour ce projet en suivant le skill init
```

## Pièges connus

- Sur un repo polyglotte (Python + TS + Docker), le draft peut être trop générique → enrichis-le à la main après
- Ne lit pas les README dans les sous-dossiers — tu perds peut-être de l'info importante

## Liens

- Doc Claude Code : https://docs.claude.com/en/docs/claude-code
