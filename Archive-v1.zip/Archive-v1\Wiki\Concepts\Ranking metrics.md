---
galaxie: wiki
nom: Ranking metrics
alias: [NDCG, MAP, MRR, recall at k, ranking, retrieval metrics]
type: concept
categorie: concept/metrics
sous_categories: [metrics, ranking, retrieval, evaluation, recommendation]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Järvelin-Kekäläinen 2002]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, metrics, ranking, retrieval, rag]
---

# Ranking metrics

## TL;DR

Métriques pour évaluer un **système qui ordonne** des items (search, recommendation, retrieval RAG). Famille **Precision@k / Recall@k** (top-k), **MRR** (rang du premier pertinent), **MAP** (precision moyenne pondérée par rang), **NDCG** (gain normalisé avec position weight). Critique en **RAG** : la qualité du retrieval détermine la qualité du LLM. Standard chez Google search, Amazon recsys, Spotify.

## Le problème

Un système rend une **liste ordonnée** d'items. Comment évaluer ?
- Les bonnes réponses sont-elles **dans les premières positions** ?
- Combien des pertinentes sont **récupérées** ?
- Position relative : 1ère vs 10ème vs 100ème → poids différent

Les métriques de classification (precision/recall sans rang) ne capturent pas la **position**.

## L'idée

### Setup

Pour une query $q$ :
- **Relevant items** : $R_q = \{i_1, i_2, \dots\}$ (vérité)
- **Predicted ranking** : $\hat L_q = [\hat i_1, \hat i_2, \dots, \hat i_K]$ (liste ordonnée du modèle)
- Souvent **graded relevance** : score 0/1/2/3 au lieu de binary

### Precision@k / Recall@k

$$ P@k = \frac{|\hat L_q[:k] \cap R_q|}{k} $$
$$ R@k = \frac{|\hat L_q[:k] \cap R_q|}{|R_q|} $$

- $k$ fixé (P@10, R@10 standards en search)
- Ignorent l'ordre **dans** le top-k
- Standard pour benchmarks RAG : "Recall@5 = 0.85"

**Hit Rate @ k** : 1 si au moins un pertinent dans top-k, 0 sinon. Métrique binaire utile pour recsys.

### MRR (Mean Reciprocal Rank)

$$ \text{MRR} = \frac{1}{|Q|} \sum_{q \in Q} \frac{1}{\text{rank}(\text{first relevant in } \hat L_q)} $$

- 1.0 si le 1er résultat est toujours pertinent
- 0.5 si le 1er pertinent est en moyenne en position 2
- **Utile quand on cherche une seule réponse** (Q&A, FAQ, navigation)
- Non-graded (binaire)

### Average Precision (AP) et MAP

**AP** pour une query :

$$ \text{AP}(q) = \frac{1}{|R_q|} \sum_{k=1}^K P@k \cdot \mathbb{1}[\text{item à position } k \text{ est pertinent}] $$

= moyenne des precision@k aux positions où on récupère un pertinent.

**MAP** : moyenne des AP sur toutes les queries.

- Récompense de récupérer pertinents tôt dans le ranking
- Non-graded
- Standard en information retrieval (TREC)

### NDCG (Normalized Discounted Cumulative Gain)

Le **gold standard** pour graded relevance et position.

**DCG@k** :

$$ \text{DCG}@k = \sum_{i=1}^k \frac{2^{\text{rel}_i} - 1}{\log_2(i + 1)} $$

- $\text{rel}_i$ = grade de relevance (0, 1, 2, 3, …)
- Poids $\frac{1}{\log_2(i+1)}$ : position 1 = 1.0, position 2 = 0.63, position 10 = 0.29
- "Logarithmic discount" : la 1ère position compte beaucoup plus

**IDCG** : DCG du ranking idéal (items triés par relevance).

$$ \text{NDCG}@k = \frac{\text{DCG}@k}{\text{IDCG}@k} \in [0, 1] $$

- 1.0 = ranking parfait
- Comparable entre queries de différentes tailles de $R_q$

**Variante "linear gain"** : $\text{rel}_i$ au lieu de $2^{\text{rel}_i} - 1$ — plus simple, moins agressive sur top-rank.

### Métriques RAG-spécifiques

#### Context Precision@k

$$ \text{CP}@k = \frac{1}{k} \sum_{i=1}^k v_i $$

avec $v_i \in \{0, 1\}$ vérifie si le chunk $i$ est pertinent. Standard chez RAGAS.

#### Context Recall

% des informations dans la answer ground truth retrouvables dans le retrieved context.

#### Faithfulness, Answer relevance

Métriques LLM-as-judge (cf. [[LLM eval metrics]]) — souvent couplées aux ranking metrics.

### Recsys-spécifiques

#### Coverage

% du catalogue jamais recommandé. Diversité du système.

#### Novelty

Récompenser items "rares" (long tail).

#### Serendipity

Items pertinents mais inattendus (diversification).

#### Personalization

Différences entre listes recommandées à différents users.

### Tableau récap

| Métrique | Graded relevance | Position-aware | Range |
|---|:-:|:-:|---|
| P@k, R@k | ✗ | ✗ (dans le top-k) | [0, 1] |
| Hit Rate@k | ✗ | partial | {0, 1} |
| MRR | ✗ | ✓ | [0, 1] |
| MAP | ✗ | ✓ | [0, 1] |
| NDCG@k | ✓ | ✓ | [0, 1] |

### Best practices

1. **Reporter à plusieurs k** : P@1, P@5, P@10 (top-1 vs top-10 ont des coûts business différents)
2. **NDCG quand graded relevance dispo** (5-star ratings, judges)
3. **MAP quand binary relevance** + tu veux pénaliser les positions
4. **MRR pour Q&A** : tu veux la réponse en position 1
5. **Recall@k pour RAG retrieval** : le LLM a besoin du context dans son window
6. **Coverage / diversity** pour recsys : éviter les bulles
7. **Cross-validation par query** : variabilité énorme entre queries

## Quand c'est utile

- **Search engines** : NDCG, MRR, P@10
- **Recommendation systems** : NDCG, MAP, Coverage, Novelty
- **RAG retrieval** : Recall@k, Context Precision, NDCG
- **Question Answering** : MRR (réponse en position 1)
- **Learning to Rank** : LambdaMART, XGBoost ranking — optimise NDCG directement
- **Ad ranking** : NDCG pondéré par revenue
- **Code search, semantic retrieval** : Recall@k

## Quand ça ne marche pas / pièges

- **Ground truth biaisée** : NDCG nécessite des judges humains. Coûteux. Ground truth implicit (clicks) est biaisée par position.
- **Confounding position** : un item en position 1 a 5x plus de clicks qu'en position 5, indépendamment de la relevance. Corrections : IPS (Inverse Propensity Scoring), counterfactual eval.
- **Sparse relevance** : pour des queries avec 0 ou 1 relevant, MAP/NDCG instables.
- **k arbitraire** : NDCG@10 vs NDCG@100 peuvent donner des conclusions différentes.
- **Diversité non capturée** : un ranker qui retourne 10 fois le même produit pertinent obtient NDCG=1 mais c'est mauvais en pratique.
- **Implicit feedback** : clicks ≠ pertinence (clickbait, position bias).
- **Long-tail evaluation** : MAP/NDCG dominés par head queries — pondérer ou stratifier par query frequency.
- **Optimization mismatch** : entraîner un modèle de ranking avec MSE → ne reflète pas NDCG. Utiliser pairwise (RankNet), listwise (LambdaMART), ou differentiable NDCG approximations.
- **Multiple-judges variance** : NDCG dépend du judging schema. Inter-annotator agreement (Cohen's κ) à reporter.

## Code minimal

```python
import numpy as np
from sklearn.metrics import ndcg_score

# Single query : graded relevance
y_true = np.asarray([[3, 2, 3, 0, 1, 2]])    # vrais grades (0=irrelevant, 3=very relevant)
y_score = np.asarray([[0.9, 0.8, 0.7, 0.6, 0.5, 0.4]])  # scores du modèle

ndcg = ndcg_score(y_true, y_score, k=5)
print(f"NDCG@5 = {ndcg:.3f}")

# MAP (binary relevance)
def average_precision(y_true_bin, y_score):
    order = np.argsort(-y_score)
    y_sorted = y_true_bin[order]
    n_relevant = y_sorted.sum()
    if n_relevant == 0:
        return 0.0
    precisions = []
    for k, rel in enumerate(y_sorted, 1):
        if rel:
            precisions.append(y_sorted[:k].sum() / k)
    return np.mean(precisions)

y_true_bin = np.array([1, 0, 1, 1, 0, 1])
y_score = np.array([0.9, 0.85, 0.8, 0.5, 0.4, 0.3])
print(f"AP = {average_precision(y_true_bin, y_score):.3f}")

# MRR
def mrr(y_true_bin_list, y_score_list):
    ranks = []
    for yt, ys in zip(y_true_bin_list, y_score_list):
        order = np.argsort(-ys)
        for i, idx in enumerate(order, 1):
            if yt[idx]:
                ranks.append(1 / i)
                break
        else:
            ranks.append(0)
    return np.mean(ranks)

# Precision/Recall @ k
def precision_at_k(y_true_bin, y_score, k):
    order = np.argsort(-y_score)[:k]
    return y_true_bin[order].sum() / k

def recall_at_k(y_true_bin, y_score, k):
    order = np.argsort(-y_score)[:k]
    return y_true_bin[order].sum() / y_true_bin.sum()

print(f"P@3 = {precision_at_k(y_true_bin, y_score, 3):.3f}")
print(f"R@3 = {recall_at_k(y_true_bin, y_score, 3):.3f}")

# Hit Rate @ k
def hit_rate_at_k(y_true_bin, y_score, k):
    order = np.argsort(-y_score)[:k]
    return int(y_true_bin[order].sum() > 0)

# Multi-query setup (typique pour RAG eval)
queries = [
    {"true": np.array([1, 0, 0, 1, 0]), "scores": np.array([0.9, 0.5, 0.3, 0.7, 0.4])},
    {"true": np.array([0, 1, 0, 0, 1]), "scores": np.array([0.2, 0.95, 0.5, 0.4, 0.6])},
]
maps = [average_precision(q["true"], q["scores"]) for q in queries]
print(f"MAP = {np.mean(maps):.3f}")

# NDCG ranking optimization avec LightGBM
from lightgbm import LGBMRanker
# X: features, y: relevance grade (0-4), group: nb items per query
# model = LGBMRanker(objective='lambdarank', metric='ndcg', ndcg_eval_at=[5, 10])
# model.fit(X_train, y_train, group=group_train)
```

## Pour aller plus loin

- Järvelin & Kekäläinen, *Cumulated Gain-Based Evaluation of IR Techniques* (TOIS 2002) — paper NDCG
- Manning, Raghavan, Schütze, *Introduction to Information Retrieval* (Cambridge 2008) — chap. 8 entier
- Liu, *Learning to Rank for Information Retrieval* (FnT IR 2009)
- RAGAS docs, *LangChain Eval*, *TruLens* — métriques RAG modernes
- **Liens internes** : [[RAG]], [[Classification metrics]], [[LLM eval metrics]], [[embeddings]]
