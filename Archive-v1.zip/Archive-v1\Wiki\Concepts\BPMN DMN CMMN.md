---
galaxie: wiki
nom: BPMN DMN CMMN
alias: [bpmn-dmn-cmmn, trinity-omg, process-decision-case, omg-trinity]
type: concept
categorie: concept/business-rules
sous_categories: [bpmn, dmn, cmmn, omg, process-modeling, decision-modeling, case-management]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [OMG, Bruce Silver, Henk Vanthienen]
lecture_min: 8
created: 2026-05-21
modified: 2026-05-21
tags: [concept, bpmn, dmn, cmmn, omg, modeling]
---

# BPMN, DMN, CMMN — la trinité OMG

## TL;DR

Trois standards complémentaires de l'**OMG** pour modéliser le travail dans l'entreprise :

- **BPMN** (Business Process Model and Notation) : **flux** de tâches et événements — *"que faire, quand, dans quel ordre"*
- **DMN** (Decision Model and Notation) : **logique de décision** — *"quelle règle, quel résultat"*
- **CMMN** (Case Management Model and Notation) : **cas-by-cas** non-prédictible — *"quoi faire selon ce qui arrive, sans script rigide"*

Ils sont **conçus pour se combiner** : une tâche BPMN de type *Business Rule Task* invoque une DMN ; un CMMN case peut déclencher des sous-processus BPMN ; etc. **BPMN domine** depuis 15 ans, **DMN gagne** depuis 2020, **CMMN reste de niche** (souvent remplacé par hybrid BPMN + DMN).

## Le problème

Modeliser le travail en entreprise = 3 problématiques distinctes que les outils mélangent souvent :

1. **Séquence** : "facturer puis recouvrer puis archiver" → besoin d'un workflow
2. **Décision** : "ce client est-il éligible ?" → besoin de règles
3. **Coordination ad-hoc** : "le dossier client X a une réclamation : selon situation, faire A, B ou C dans l'ordre que le case worker décide" → besoin de flexibilité

Tout faire en BPMN = workflows monstrueux avec 100 IF/ELSE et beaucoup de gateways. Tout faire en code = boîte noire opaque pour le métier. Les 3 standards adressent chacun **une dimension orthogonale** du problème.

## L'idée

### BPMN — Business Process Model and Notation

Standard depuis 2005, version 2.0 depuis 2011. Le plus mature et le plus déployé.

**Concepts clés** :
- **Tasks** (User Task, Service Task, Business Rule Task, Script Task, Send/Receive Task...)
- **Gateways** (Exclusive XOR, Parallel AND, Inclusive OR, Event-Based)
- **Events** (Start, Intermediate, End, Boundary)
- **Lanes / Pools** (qui fait quoi)
- **Sub-processes**, **call activities**

**Cas d'usage** : onboarding client, traitement réclamation, validation expense, pipeline déploiement, processus RH structuré.

**Outils de référence** : Camunda 7/8, Bonita, Activiti, jBPM, Signavio, IBM BPM.

### DMN — Decision Model and Notation

Voir [[Decision Model and Notation]] pour le détail. Standard depuis 2015, version 1.5 (2023).

**Concepts clés** :
- **DRD** (vue graphique des décisions)
- **Decision Tables** (lignes = règles)
- **FEEL** (langage d'expression)
- **BKM** (fonctions réutilisables)

**Cas d'usage** : éligibilité, scoring, pricing, routing, validation conformité — tout ce qui est de la **règle métier déterministe**.

**Outils** : Camunda DMN engine, Drools (kie-dmn), OpenL Tablets, Trisotech.

### CMMN — Case Management Model and Notation

Standard depuis 2014, version 1.1. **Moins adopté** que BPMN/DMN.

**Concepts clés** :
- **Case** (le dossier qu'on traite)
- **Plan items** (tâches potentielles, **pas forcément exécutées**)
- **Sentries** (déclencheurs sur événements)
- **Stages** (regroupements de tâches)
- **Discretionary items** (tâches que le case worker peut choisir d'activer)

**Différence clé vs BPMN** : BPMN définit *l'ordre exact* des tâches. CMMN définit un *catalogue de tâches disponibles* et le case worker décide quoi faire selon la situation.

**Cas d'usage** : gestion réclamations complexes, dossier patient à l'hôpital, enquête criminelle, dossier juridique — tout ce qui est **case-by-case** avec variations imprévisibles.

**Outils** : Camunda 7 a un engine CMMN (deprecated dans 8 cependant), Flowable, Activiti.

**Pourquoi CMMN est moins utilisé** : la plupart des "cas flexibles" peuvent être modélisés en BPMN + DMN avec des sous-processus dynamiques (event sub-process, ad-hoc sub-process). CMMN ajoute un standard de plus à apprendre pour un gain limité.

### Comment ils se combinent

#### Pattern 1 — BPMN orchestre, DMN décide

Le plus courant et le plus puissant. Un workflow BPMN contient une tâche *Business Rule Task* qui invoque une décision DMN.

```
[Start] → [User Task: Receive request]
       → [Business Rule Task: Decide eligibility] (invoque DMN)
              ↓
       [Gateway XOR sur résultat]
              ↓                    ↓
         eligible            non-eligible
              ↓                    ↓
       [Service Task]       [Send Task]
       Process payment     Notify rejection
              ↓                    ↓
            [End]               [End]
```

Le BPMN gère le **flux**. La décision d'éligibilité est externalisée dans une DMN — testable, auditable, modifiable par le métier sans toucher le workflow.

#### Pattern 2 — BPMN + DMN + CMMN

CMMN pour un dossier client multi-facettes, qui déclenche des sous-processus BPMN pour certaines étapes, lesquels invoquent des DMN pour leurs règles.

```
[CMMN Case : Insurance Claim]
   ├── [BPMN Subprocess: Initial validation] → DMN "validation rules"
   ├── [BPMN Subprocess: Expert assessment]   → DMN "scoring fraud risk"
   └── [Discretionary: Litigation]              → DMN "settle vs court"
```

CMMN dit *"voici les choses qui peuvent arriver sur ce dossier"*. BPMN dit *"voici comment chaque étape se déroule"*. DMN dit *"voici les règles à appliquer"*.

#### Pattern 3 — DMN seul

Pour une API de décision simple (pas de workflow), DMN seul suffit. Exposer un endpoint REST qui invoque le DMN engine. Pas besoin de BPMN si pas de séquence de tâches.

### Choix d'architecture

| Tu as besoin de... | Tu utilises... |
|---|---|
| Séquence stricte de tâches | BPMN |
| Règles métier complexes | DMN |
| Workflow + règles | BPMN + DMN |
| Coordination flexible cas-par-cas | CMMN (ou BPMN ad-hoc) |
| API "calcule cette décision" stateless | DMN seul |
| Long-running workflow avec compensation, retry, escalation | BPMN |
| Décision en code Java/Python pur, pas exposée au métier | Code natif (mais perte trust/audit) |

### État d'adoption en 2026

- **BPMN** : standard universel, adopté largement (banque, assurance, telco, public)
- **DMN** : adoption en forte croissance depuis 2020, surtout banque/assurance, complément naturel de BPMN
- **CMMN** : usage de niche, souvent remplacé par BPMN flexible. Camunda 8 a déprécié CMMN.

### Lien avec le profil DS/ML/AI eng

- **BPMN** orchestre des pipelines ML : *"après training, deploy + monitor + alert"* — alternative aux outils MLOps purs (Airflow, Prefect) quand intégré à un workflow business.
- **DMN** est la **couche trust** au-dessus des modèles : la prédiction ML est un input, la decision DMN choisit l'action selon des règles auditables.
- **CMMN** n'a quasi pas de croisement avec ML / AI eng.

Le triplet **ML model → DMN → BPMN task** est un pattern récurrent en assurance / finance / santé.

## Quand c'est utile

- **Tu décris un domaine métier complet** : tu auras besoin des 3 angles (process, décisions, cas exceptions)
- **Architecture séparation des concerns** : workflow vs règles vs ad-hoc
- **Communication métier ↔ tech** : les 3 standards sont lisibles par des analystes
- **Audit / conformité** : auditeur peut lire BPMN + DMN sans connaître le code
- **Modifiabilité** : changer une règle DMN sans déployer le code, changer un workflow BPMN sans changer les règles
- **Stack Camunda / Flowable** : outils unifiés pour les 3 (Camunda 8 = BPMN + DMN, CMMN deprecated)

## Quand ça ne marche pas / pièges

- **Tout en BPMN** : workflows monstrueux avec gateways IF/ELSE partout — extraire la logique en DMN
- **Tout en DMN** : pas de notion de séquence, pas le bon outil pour orchestrer 10 étapes — ajouter BPMN
- **CMMN sur-vendu** : souvent un BPMN avec sub-process ad-hoc suffit. Avant d'apprendre CMMN, vérifier le besoin réel
- **DMN dans le code Java** : transformer FEEL en if/then java = défaire l'intérêt (perte audit/lisibilité)
- **Trois standards = trois engines** : sur-engineering pour un petit projet. Commencer par BPMN seul ou DMN seul
- **Modèles trop fins** : 50 decisions DMN pour un workflow qui pourrait en avoir 5 — over-decomposition
- **Mélange code custom et BPMN** : *Script Tasks* Java/Groovy partout dans le BPMN = lecture difficile, audit cassé
- **Outils L1 only** (modeling sans exécution) : tu dessines mais n'exécutes pas → manques tout l'intérêt
- **Versioning mal géré** : modèles BPMN/DMN/CMMN en XML, merge Git non trivial sans modeling tools
- **CMMN deprecated** dans Camunda 8 : si tu pars sur CMMN, vérifier la roadmap de ton engine

## Code minimal

### BPMN qui invoque DMN — fichier BPMN (extrait)

```xml
<bpmn:process id="loanApprovalProcess" isExecutable="true">
  <bpmn:startEvent id="start" name="Loan request received"/>

  <bpmn:businessRuleTask id="checkEligibility"
                         name="Check eligibility"
                         camunda:decisionRef="eligibilityDecision"
                         camunda:resultVariable="eligibilityResult"
                         camunda:mapDecisionResult="singleEntry">
    <bpmn:incoming>flow1</bpmn:incoming>
    <bpmn:outgoing>flow2</bpmn:outgoing>
  </bpmn:businessRuleTask>

  <bpmn:exclusiveGateway id="gateway" name="Eligible?">
    <bpmn:incoming>flow2</bpmn:incoming>
    <bpmn:outgoing>toAccept</bpmn:outgoing>
    <bpmn:outgoing>toReject</bpmn:outgoing>
  </bpmn:exclusiveGateway>

  <bpmn:sequenceFlow id="toAccept" sourceRef="gateway" targetRef="processPayment">
    <bpmn:conditionExpression>${eligibilityResult == "accepted"}</bpmn:conditionExpression>
  </bpmn:sequenceFlow>
  <!-- ... -->
</bpmn:process>
```

Le `camunda:decisionRef="eligibilityDecision"` pointe vers une **décision DMN** définie dans un fichier `.dmn` séparé.

### Fichier DMN référencé

```xml
<decision id="eligibilityDecision" name="Eligibility">
  <decisionTable hitPolicy="UNIQUE">
    <!-- ... voir [[Decision Tables]] -->
  </decisionTable>
</decision>
```

### Invocation programmatique (Camunda Java)

```java
// Démarrer un process BPMN
ProcessInstance pi = runtimeService.startProcessInstanceByKey(
    "loanApprovalProcess",
    Variables.createVariables()
        .putValue("age", 35)
        .putValue("income", 25000)
);

// Le moteur exécute le workflow, invoque la DMN à l'étape "checkEligibility",
// route selon le résultat, et continue.
```

### CMMN — case avec discretionary items

```xml
<cmmn:case id="insuranceClaim" name="Insurance Claim">
  <cmmn:casePlanModel id="planModel">
    <cmmn:planItem id="initialValidation" definitionRef="validationStage"/>
    <cmmn:planItem id="expertAssessment" definitionRef="expertStage"/>
    <cmmn:planItem id="litigation" definitionRef="litigationStage"/>

    <cmmn:stage id="validationStage" name="Initial validation"/>
    <cmmn:stage id="expertStage" name="Expert assessment"/>
    <cmmn:stage id="litigationStage" name="Litigation"
                isDiscretionary="true"/>  <!-- discretionary : case worker decides -->
  </cmmn:casePlanModel>
</cmmn:case>
```

## Pour aller plus loin

- OMG specs : [BPMN](https://www.omg.org/spec/BPMN/), [DMN](https://www.omg.org/spec/DMN/), [CMMN](https://www.omg.org/spec/CMMN/)
- Bruce Silver, *BPMN Method and Style* + *DMN Method and Style* — les références pédagogiques
- Camunda 7/8 docs (BPMN + DMN, CMMN deprecated en 8) : https://docs.camunda.io/
- Flowable docs (BPMN + DMN + CMMN) : https://flowable.com/open-source/docs/
- *The Decision Model and Notation Handbook* (James Taylor et al.)
- **Liens internes** : [[Decision Model and Notation]], [[Decision Tables]], [[FEEL]], [[Decision Intelligence]]

Sources :
- [OMG DMN 1.5 specification](https://www.omg.org/spec/DMN/1.5/About-DMN)
- [Camunda DMN 1.5 namespaces support issue](https://github.com/camunda/camunda-bpm-platform/issues/3598)
- [What's New in DMN 1.4 and 1.5 (Method And Style)](https://www.methodandstyle.com/blog/whats-new-in-dmn-1-4-and-1-5/)
