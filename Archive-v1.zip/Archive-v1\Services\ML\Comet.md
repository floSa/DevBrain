---
galaxie: dev
nom: Comet
alias: [comet, comet-ml, cometml]
categorie: ml/tracking
sous_categories: [tracking, experiments, cloud, opik, llm-observability]
licence: Propriétaire (Opik = Apache-2.0)
licence_type: proprietary
hosted: cloud ou self (Enterprise)
maturite: production
langage: Python
clients_officiels: [python, java, javascript, r]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[Weights & Biases]]", "[[MLflow]]", "[[Aim]]", "[[Neptune]]", "[[ClearML]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, tracking, cloud, llm-observability]
url_officiel: https://www.comet.com/
url_docs: https://www.comet.com/docs/
url_repo: https://github.com/comet-ml
---

# Comet

## Pourquoi

Plateforme **ML experiment tracking cloud** (et self-host Enterprise), alternative directe à [[Weights & Biases]]. Tracking, model registry, sweeps, reports. Plus discrète que W&B mais features comparables et **pricing souvent plus accessible** pour les équipes < 50 personnes.

**Opik** (depuis 2024) est leur produit **LLM observability open-source (Apache-2.0)** : tracing, eval, prompt management, datasets. Concurrent direct de Langfuse / LangSmith / Helicone — Opik se télécharge et tourne en local, **Comet ML lui-même reste closed-source**.

## Quand l'utiliser

- **ML experiment tracking cloud** : SaaS turn-key, alternative à W&B avec pricing favorable
- **Opik** pour **LLM observability open-source** : tracing, evals, prompts (vs Langfuse / LangSmith)
- **Stack pricing avantageux** : Comet souvent moins cher que W&B en mid-market
- **Model Registry production** : versioning + model cards + lineage
- **Reports collaboratifs** : équivalent W&B Reports
- **Combo CV / NLP / tabular** : SDK générique, intégrations sklearn / PyTorch / TF / Lightning / HF / XGBoost
- **Panels custom** : visualisations interactives configurables

## Quand NE PAS l'utiliser

- **Open-source obligatoire** : Comet ML est closed-source (seul Opik l'est) → [[MLflow]] / [[Aim]] / [[ClearML]]
- **Stack 100% W&B existant** : migration coûteuse, gain marginal
- **Self-host gratuit** : pas d'option self-host gratuit grand public (Enterprise only)
- **Communauté énorme requise** : moins de momentum que W&B en 2024-2026
- **LLM tracking only** : si juste LLM → Langfuse open-source plus naturel

## Pièges connus

- **Comet ML pas open-source** : confusion fréquente avec Opik (Opik est open, Comet ne l'est pas)
- **Moins de momentum vs W&B** : intégrations communautaires moins riches
- **SSO / RBAC avancés payants** : tier Enterprise pour ces features
- **Doc inégale** : certaines features bien documentées, d'autres en jachère
- **Free tier modéré** : limites de runs / storage à surveiller
- **API key en clair** : configurer via `~/.comet.config` ou env, pas dans le code
- **Vendor lock-in** : export possible mais migration vers MLflow / W&B non triviale
- **Opik vs Comet ML** : deux produits distincts, pas confondre — Opik a son propre SDK `opik`

## Code minimal

```bash
pip install comet_ml
# Config (interactif ou via env)
export COMET_API_KEY="..."
export COMET_WORKSPACE="floSa"
export COMET_PROJECT_NAME="llama-finetune"
```

```python
# Tracking experience standard
from comet_ml import Experiment

experiment = Experiment(
    api_key="...",
    project_name="llama-finetune",
    workspace="floSa",
)
experiment.log_parameters({"lr": 1e-4, "batch_size": 32, "model": "llama-3-8b"})

for epoch in range(10):
    train_loss = train_one_epoch()
    val_loss = evaluate()
    experiment.log_metric("train_loss", train_loss, step=epoch)
    experiment.log_metric("val_loss", val_loss, step=epoch)

experiment.log_model("llama-finetuned", "./model.bin")
experiment.end()
```

```python
# Opik (LLM observability open-source) - SDK separe
# pip install opik
import opik
from opik import track

opik.configure(use_local=True)   # ou cloud Comet

@track
def rag_pipeline(question: str) -> str:
    docs = retrieve(question)
    answer = llm_call(question, docs)
    return answer

# Auto-trace : appels LLM, latence, tokens, prompt + completion
result = rag_pipeline("Capitale du Portugal ?")
```

## Liens

- [[Weights & Biases]] — alternative SaaS dominant
- [[MLflow]] — alternative open-source
- [[Aim]] / [[ClearML]] / [[Neptune]] — alternatives tracking
- [[Langfuse]] / [[LangSmith]] / [[Helicone]] — alternatives LLM observability (Opik = concurrent)
- Opik (LLM obs open-source) : https://github.com/comet-ml/opik
- Docs : https://www.comet.com/docs/
- Site : https://www.comet.com/
