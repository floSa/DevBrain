---
galaxie: dev
nom: Optuna
alias: [optuna]
categorie: ml/hyperopt
sous_categories: [hyperparameter-tuning, bayesian, pruning]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Ray Tune]]", "[[Hyperopt]]", "[[Weights & Biases]] Sweeps", "[[scikit-learn]] GridSearchCV"]
remplace: ["[[Hyperopt]]", "[[scikit-learn]] GridSearchCV"]
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ml, hyperopt, bayesian]
url_officiel: https://optuna.org/
url_docs: https://optuna.readthedocs.io/
url_repo: https://github.com/optuna/optuna
---

# Optuna

## Pourquoi
Framework de **hyperparameter optimization** moderne. API "define-by-run" (l'espace de recherche se déclare dans la fonction objective), samplers TPE/CMA-ES/NSGA-II, **pruning** automatique d'essais peu prometteurs, dashboard intégré. Le défaut Python pour le tuning sérieux.

## Quand l'utiliser
- Tuning de modèles ML / DL (sklearn, [[XGBoost]], [[LightGBM]], [[PyTorch]], etc.)
- Multi-objectif (latency vs accuracy)
- Distribué : plusieurs workers Optuna sur le même `study`
- Tracking visuel (Optuna Dashboard)
- Intégration [[MLflow]] / [[Weights & Biases]] pour logging

## Quand NE PAS l'utiliser
- Très petit espace (3-5 combos) → grid search direct
- Distributed très massif → [[Ray Tune]] est mieux outillé pour cluster
- Besoin de population-based training sophistiqué → [[Ray Tune]]

## Pièges connus
- **Storage** : par défaut in-memory, perdu au crash → utiliser SQLite/[[Postgres]] storage pour persister
- **`suggest_*` API** : `categorical`, `int`, `float`, `loguniform` — pas tout équivalent
- **Pruners** : MedianPruner pratique mais pas adapté à tous les modèles
- **Reproductibilité** : passer un `seed` au sampler
- **Parallélisation** : `n_jobs` dans optimize OU plusieurs process sur même storage — pas les deux

## Liens
- [[scikit-learn]] / [[XGBoost]] / [[LightGBM]] / [[PyTorch]] — utilisateurs principaux
- [[MLflow]] — intégration tracking
- Dashboard : `pip install optuna-dashboard`
- Tutorials : https://optuna.readthedocs.io/en/stable/tutorial/
