---
galaxie: dev
nom: CockroachDB
alias: [cockroachdb, crdb]
categorie: database/relational
sous_categories: [distributed, sql, multi-region, postgres-compatible]
licence: BSL (Business Source License) puis Apache après 3 ans
licence_type: source-available
hosted: both
maturite: production
langage: Go
clients_officiels: [python, ts, go, rust, java]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Postgres]]", Spanner, YugabyteDB, Citus]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, database, sql, distributed]
url_officiel: https://www.cockroachlabs.com/
url_docs: https://www.cockroachlabs.com/docs/
url_repo: https://github.com/cockroachdb/cockroach
---

# CockroachDB

## Pourquoi
Base SQL distribuée **wire-compatible Postgres**. Conçue pour la résilience multi-region : auto-rebalancing, replication par range, consensus Raft. Choix premier si tu as besoin de PostgreSQL **+ scale-out horizontal + multi-region**.

## Quand l'utiliser
- Multi-region active-active (latence locale, durabilité globale)
- Scale-out horizontal sans sharding manuel
- High availability avec tolérance pannes datacenter
- Apps SaaS B2B avec SLA forts
- Migration depuis Postgres en gardant la même API

## Quand NE PAS l'utiliser
- Single-region simple → [[Postgres]] (meilleur perf brute, plus mature)
- Workload OLAP → ClickHouse / [[DuckDB]]
- Budget serré → CockroachDB Enterprise/Cloud coûte cher
- Besoin extensions Postgres (pgvector, PostGIS) → souvent absentes ou partielles

## Pièges connus
- **Latence multi-region** : transactions cross-region payent un coût Raft
- **Compatibilité Postgres** : ~95% — quelques extensions (pgvector, PostGIS) absentes ou simulées
- **Licence BSL** : non-compete clause sur 3 ans, à check pour usage SaaS
- **Pricing managed** : Cloud peut exploser sur gros volumes
- **Performance single-node** : moins bon que Postgres pour workload simple
- **Tooling** : moins riche que l'écosystème Postgres (pgBouncer, pgvector, etc.)

## Liens
- [[Postgres]] — alternative single-region
- YugabyteDB — alternative open-source distribuée
- Docs : https://www.cockroachlabs.com/docs/
- Pricing : https://www.cockroachlabs.com/pricing/
