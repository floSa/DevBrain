---
galaxie: dev
nom: Marker
alias: [marker, marker-pdf]
categorie: data/document
sous_categories: [pdf, ocr, ml-extraction, table-extraction, equations]
licence: GPL-3.0 (open) / Commercial
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python, cli]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Docling]]", "[[LlamaParse]]", "[[Unstructured]]", "[[PyMuPDF]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, pdf, extraction, ml]
url_officiel: https://www.datalab.to/
url_docs: https://github.com/VikParuchuri/marker
url_repo: https://github.com/VikParuchuri/marker
---

# Marker

## Pourquoi

Convertisseur **PDF → Markdown** haute fidélité basé sur modèles **transformer** (layout detection + OCR + table extraction). Excellent sur PDFs scientifiques / techniques (tables, équations LaTeX, figures). Souvent **meilleur que pdfplumber/PyMuPDF + Unstructured** sur la qualité, plus rapide que LlamaParse cloud pour batch local.

Concrètement : pipeline de modèles (surya pour layout/OCR, texify pour équations, recognition pour tables) qui produit du Markdown propre avec tables → HTML, équations → LaTeX, images extraites.

## Quand l'utiliser

- **PDFs scientifiques / techniques** : tables complexes, formules math, multi-colonnes
- **Pipeline RAG** sur docs complexes (papers, manuels, reports)
- **Local processing** (privacy : pas de upload cloud)
- **Conversion batch** PDFs → Markdown pour ingestion
- **OCR de PDFs scannés** (avec `--force_ocr`)
- Stack **GPU dispo** (CPU possible mais lent)

## Quand NE PAS l'utiliser

- **PDFs simples** avec texte sélectable → `pypdf` / [[PyMuPDF]] suffisent (10x plus rapide)
- **Volumes massifs sans GPU** → [[LlamaParse]] cloud ou Datalab API (managed Marker)
- **Layout très exotique** → [[Unstructured]] + post-processing
- **Licence commerciale stricte** : GPL-3.0 → contagieux. Pour usage commercial fermé, voir Datalab commercial licence.
- **Latence < 1s par page** : Marker = secondes/page avec GPU, plus avec CPU

## Pièges connus

- **Licence GPL-3.0** : à check pour usage commercial. Datalab vend une licence commerciale.
- **GPU recommandé** : sur CPU, ~30s/page. GPU RTX 3090+ : ~2-5s/page.
- **Quality variable** selon type de PDF : excellent sur papers académiques, parfois moyen sur factures / formulaires
- **Memory** : modèles chargés ~3-5 GB VRAM. Process batch attention OOM.
- **Lib jeune** : breaking changes possibles entre versions, pin `marker-pdf==X.Y.Z`
- **Inline images** : extraites mais à gérer (output dir séparé)
- **Tables → HTML** : par défaut, à convertir si tu veux Markdown table syntax
- **OCR force** : `--force_ocr` ralentit beaucoup, à n'utiliser que sur PDFs scannés

## Code minimal

```bash
# CLI
# pip install marker-pdf
marker_single /path/to/doc.pdf /path/to/output_dir --output_format markdown
# Batch
marker /path/to/pdfs_dir /path/to/output_dir --workers 4
```

```python
# API Python
# pip install marker-pdf
from marker.converters.pdf import PdfConverter
from marker.models import create_model_dict
from marker.output import text_from_rendered

converter = PdfConverter(artifact_dict=create_model_dict())
rendered = converter("paper.pdf")
text, _, images = text_from_rendered(rendered)

# text est du Markdown propre
print(text[:500])

# Avec config
from marker.config.parser import ConfigParser
config = {
    "output_format": "markdown",
    "force_ocr": False,           # True pour PDFs scannés
    "use_llm": False,             # True = LLM pour qualité ++ (lent, coûteux)
    "extract_images": True,
}
parser = ConfigParser(config)
converter = PdfConverter(
    artifact_dict=create_model_dict(),
    config=parser.generate_config_dict(),
)
```

## Liens

- [[Docling]] (IBM, alt principal)
- [[LlamaParse]] (cloud, managed)
- [[Unstructured]] (multi-format)
- [[PyMuPDF]] / pdfplumber (extraction simple)
- **Datalab** (Marker managed / commercial licence) : https://www.datalab.to/
- **surya** (OCR sous-jacent) : https://github.com/VikParuchuri/surya
- Repo : https://github.com/VikParuchuri/marker
