---
galaxie: dev
type: pattern
contexte: agent LLM autonome qui doit accomplir une tâche multi-étapes en utilisant des tools (search, calc, code, API), avec besoin d'observabilité et de garde-fous
created: 2026-05-19
modified: 2026-05-19
services_cles: ["[[Anthropic Claude API]]", "[[LangGraph]]", "[[PydanticAI]]", "[[Phoenix Arize]]"]
projets_appliques: []
tags: [pattern, agent, react, llm, ai-eng]
---

# Pattern — Agent ReAct

## Contexte

Tu construis un **agent LLM autonome** qui doit accomplir une tâche multi-étapes : recherche d'info, analyse, calcul, action externe. La tâche ne se résout pas en un seul appel LLM — l'agent doit **observer, réfléchir, agir, réobserver**.

Cas typiques : assistant de support, agent de recherche, ops automation, code assistant. Charge faible à modérée (< 10k appels/jour), latence acceptable de quelques secondes par requête, coût LLM à surveiller mais pas critique.

Si tu veux une recette beaucoup plus simple **sans agence** (un seul appel LLM + RAG), voir [[Pattern - RAG basique]].

## Stack

- **LLM** : [[Anthropic Claude API]] (Claude Sonnet 4.7 ou Opus pour le raisonnement)
- **Framework agent** : [[LangGraph]] (graphe explicite, traceable) OU [[PydanticAI]] (Python-natif, type-safe)
- **Tools** :
  - Recherche : [[mcp-obsidian]] / [[mcp-github]] / web search API
  - Code exec : sandbox isolé (Docker, Modal sandbox)
  - APIs externes : SDK officiels (toujours wrap avec timeout + retry)
- **Structured output** : [[Instructor]] pour formats de réponse stricts
- **Observabilité** : [[Phoenix Arize]] ou OpenTelemetry direct (traces des tool calls + raisonnement)
- **Eval** : dataset gold + [[Ragas]] / DeepEval ou eval custom

## Structure de projet

```
my-agent/
├── pyproject.toml
├── README.md
├── docker-compose.yml         # observability (Phoenix) + ton agent
├── src/
│   └── my_agent/
│       ├── __init__.py
│       ├── config.py           # Settings (clés API, modèles)
│       ├── api.py              # FastAPI endpoint /ask
│       ├── agent/
│       │   ├── graph.py        # définition LangGraph (nodes + edges)
│       │   ├── prompts.py      # system prompts versionnés
│       │   └── reactive.py     # boucle ReAct si pas LangGraph
│       ├── tools/
│       │   ├── search.py       # tool web/DB search
│       │   ├── code.py         # tool execute Python (sandbox)
│       │   └── api_calls.py    # wrappers APIs externes
│       ├── observability/
│       │   ├── tracing.py      # OpenTelemetry / Phoenix instrumentation
│       │   └── eval.py         # éval continue
│       └── safety/
│           ├── guards.py       # max_steps, allowed_tools, content filter
│           └── prompt_injection.py  # détection injection
└── tests/
    ├── conftest.py
    ├── eval_dataset.py         # gold cases
    └── test_*.py
```

## Décisions clés

### 1. Choix de framework : LangGraph vs PydanticAI

| Critère | LangGraph | PydanticAI |
|---|---|---|
| Modèle mental | Graphe d'états explicite | Classes Python typées (FastAPI-style) |
| Multi-step complexe | ✅ excellent | ✅ bon |
| Maturité | Très mature (LangChain ecosystem) | Plus récent, en évolution |
| Type safety | Partial (via Pydantic) | Native, complète |
| Debugging | Graphe visualisable | Stack traces classiques |
| Choisir si | Workflows complexes, multi-agents | Préférence pour API Pythonique |

**Mon choix par défaut** : [[LangGraph]] pour la maturité écosystème.

### 2. Boucle ReAct standard

Pattern fondateur (Yao et al. 2022) :

```
loop:
    1. Thought  : LLM verbalise sa stratégie
    2. Action   : LLM choisit un tool + ses arguments
    3. Observation : exécuter le tool, capturer le résultat
    4. Decide   : objectif atteint ? → STOP. Sinon → step 1.
max_steps: 5-15 selon complexité
```

Implémentation native avec [[Anthropic Claude API]] et le mécanisme **tool use** (cf. [[tool-use|Tool Use]]).

### 3. Garde-fous obligatoires

**Sans exception** :
- `max_steps` (5-15) — éviter boucles infinies
- `max_tokens_total` budget par requête — limite le coût
- **Tool whitelist** explicite — ne JAMAIS donner `eval()` ou `shell()` à l'agent
- **Validation Pydantic** sur tous les tool inputs/outputs
- **Timeout par tool call** (5-30s selon)
- **Détection prompt injection** sur les outputs externes (URLs, docs scrappés) — voir `Wiki/Concepts/prompt-injection.md` à écrire

### 4. Prompt système structuré

```python
SYSTEM = """
Tu es un agent <rôle>. Ton objectif : <but mesurable>.

Tools disponibles :
- search(query: str) -> list[Result] : recherche dans la KB
- calculate(expression: str) -> float : calculs exacts
- ...

Règles strictes :
- Ne fabrique JAMAIS d'information. Si tu ne sais pas, dis-le.
- Cite tes sources via [SOURCE: <id>].
- Maximum 10 tool calls. Si tu n'as pas la réponse après ça, dis "je n'ai pas pu".
- Si une question sort de ton scope, dis-le clairement.
"""
```

**Cache** ce prompt via [[prompt-caching|Prompt Caching]] — ça change pas, ne paie qu'une fois par tour de cache.

### 5. Observabilité — trace tout

Pour chaque tour :
- Input utilisateur (anonymisé si PII)
- Tool calls + arguments + outputs
- Latence par tool
- Tokens in/out par appel LLM
- Décision finale + raisonnement

[[Phoenix Arize]] visualise les arbres d'appel. OpenTelemetry exporte vers Datadog/Honeycomb/etc.

### 6. Eval continue

Dataset gold de 30-100 questions représentatives. Chaque release :
- Lance l'agent sur le dataset
- Métriques : task completion rate, # steps moyen, hallucination rate, latence p95
- Compare à la baseline en CI

Voir [[Evaluer un systeme LLM]] pour la méthodologie d'éval.

### 7. Fallback gracieux

Quand l'agent échoue (max_steps, tool error répété, perplexité élevée) :
- Retourner un message clair "je n'ai pas pu, voici ce que j'ai exploré : ..."
- **JAMAIS** halluciner une réponse
- Logger la session complète pour analyse offline

## Pièges (vu en projets)

- **Boucles infinies** quand un tool retourne toujours la même erreur — toujours `max_steps`
- **Drift hors-sujet** : l'agent oublie l'objectif après quelques tours. Rappeler dans le system à chaque tour, ou utiliser LangGraph state explicite.
- **Tool hallucination** : l'agent invente un nom de tool inexistant. Toujours valider la whitelist en code, retourner une erreur claire au LLM si tool inconnu.
- **Coût exponentiel** : chaque step ajoute toute la conversation cumulée en contexte → 10 steps = 10× le coût. [[prompt-caching|Prompt Caching]] partiel obligatoire.
- **Agent qui ment** quand un tool échoue — il fabrique une réponse plausible. Solution : forcer un format structured ([[Instructor]]) avec champ `confidence` qui doit être faible quand pas d'info.
- **Pas de versioning des prompts** → impossible de comparer entre runs. Versionner system prompts dans Git, taguer chaque release.
- **Tests insuffisants** : un agent qui passe 1 test ne couvre pas les edge cases. Dataset gold + adversarial tests obligatoires.

## Voir aussi

- Concepts : [[tool-use|Tool Use]], [[agent-loops|Agent loops]], [[prompt-caching|Prompt Caching]], [[mcp-protocol|MCP Protocol]]
- Services : [[Anthropic Claude API]], [[LangGraph]], [[PydanticAI]], [[Instructor]], [[Phoenix Arize]], [[Ragas]]
- Patterns liés : [[Pattern - RAG basique]] (alternative plus simple sans agence)
- Workflows : [[Bootstrap projet AI eng]], [[Evaluer un systeme LLM]]
- Rules applicables : [[Rules/Global/security]] (prompt injection), [[Rules/Types/ML-pipeline]]
