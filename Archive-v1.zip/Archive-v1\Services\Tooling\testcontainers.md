---
galaxie: dev
nom: testcontainers
alias: [testcontainers-python, testcontainers]
categorie: tooling/test
sous_categories: [integration-tests, docker, ephemeral, fixtures]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python (port officiel multi-langues)
clients_officiels: [python, java, go, ts, rust, dotnet]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["docker-compose pour tests", "Tilt", "fixtures manuelles", "pytest-postgresql (specifique)"]
remplace: ["fixtures DB ad-hoc"]
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, tooling, test, integration, docker]
url_officiel: https://testcontainers.com/
url_docs: https://testcontainers-python.readthedocs.io/
url_repo: https://github.com/testcontainers/testcontainers-python
---

# testcontainers

## Pourquoi
Lib pour **démarrer des conteneurs Docker éphémères** dans tes tests d'intégration. Postgres, Redis, MinIO, Qdrant, Kafka, Elasticsearch, etc. — un container par test (ou par session), cleanup automatique. Le défaut pour des tests d'intégration **fiables et rapides**.

## Quand l'utiliser
- Tests d'intégration qui ont besoin d'une DB / cache / vector store réel
- CI où on veut éviter `docker-compose -f docker-compose.test.yml up` à la main
- Tests cross-version (matrix : PG 14, 15, 16) facilement
- Quand `pytest-postgresql` ou `mongomock` sont insuffisants (besoin du vrai service)

## Quand NE PAS l'utiliser
- Tests unitaires purs (mocks suffisent, plus rapides)
- Pas de Docker dispo (CI très contrainte) → fixtures custom
- Service très lourd à démarrer (gros modèle ML) → option fixture session-scoped + cache

## Pièges connus
- **Démarrage lent** : 1-3s par container × N tests si pas en `scope="session"`
- **Docker daemon requis** : CI doit l'exposer (GitHub Actions le fait, GitLab parfois pas)
- **Port collisions** : par défaut testcontainers prend des ports random, OK
- **Cleanup loupé** : si pytest crash hard, containers orphelins (mitigé par `Ryuk` reaper container, automatique)
- **Performance** : avec beaucoup de tests intégration, parallèle pose des questions de ressources

## Pattern essentiel — pytest fixture session-scoped

```python
import pytest
from testcontainers.postgres import PostgresContainer

@pytest.fixture(scope="session")
def postgres_url():
    """Démarrage Postgres une fois pour toute la session de tests."""
    with PostgresContainer("postgres:16-alpine") as pg:
        yield pg.get_connection_url()

@pytest.fixture
def db_session(postgres_url):
    """Reset DB entre chaque test via transaction rollback."""
    engine = create_engine(postgres_url)
    Base.metadata.create_all(engine)
    
    connection = engine.connect()
    transaction = connection.begin()
    session = Session(bind=connection)
    
    yield session
    
    session.close()
    transaction.rollback()
    connection.close()

# Usage
def test_create_user(db_session):
    user = User(email="x@y.z")
    db_session.add(user)
    db_session.flush()
    assert user.id is not None
```

## Containers utiles

| Container | Module |
|-----------|--------|
| Postgres | `from testcontainers.postgres import PostgresContainer` |
| MySQL | `from testcontainers.mysql import MySqlContainer` |
| Redis | `from testcontainers.redis import RedisContainer` |
| MongoDB | `from testcontainers.mongodb import MongoDbContainer` |
| Kafka | `from testcontainers.kafka import KafkaContainer` |
| MinIO | `from testcontainers.minio import MinioContainer` |
| Generic | `from testcontainers.core.container import DockerContainer` (pour Qdrant, Weaviate, etc.) |

### Pattern Generic Container (Qdrant)

```python
from testcontainers.core.container import DockerContainer
from testcontainers.core.waiting_utils import wait_for_logs

@pytest.fixture(scope="session")
def qdrant():
    qdrant = (
        DockerContainer("qdrant/qdrant:latest")
        .with_exposed_ports(6333, 6334)
    )
    qdrant.start()
    wait_for_logs(qdrant, "Actix runtime found")
    yield f"http://{qdrant.get_container_host_ip()}:{qdrant.get_exposed_port(6333)}"
    qdrant.stop()
```

## Configuration CI

GitHub Actions (Docker dispo nativement) :

```yaml
# .github/workflows/tests.yml
jobs:
  integration:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
      - run: uv sync
      - run: uv run pytest tests/integration/ -m integration
```

## Liens
- [[Postgres]], [[MongoDB]], [[Qdrant]], [[MinIO]] — services testables
- [[Tests]] (règle Documentation/) — qui impose testcontainers pour intégration
- [[Docker]] — prérequis
- Doc Python : https://testcontainers-python.readthedocs.io/
- Modules officiels : https://github.com/testcontainers/testcontainers-python/tree/main/modules
