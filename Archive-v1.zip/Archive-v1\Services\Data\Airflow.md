---
galaxie: dev
nom: Airflow
alias: [apache-airflow, airflow]
categorie: data/orchestration
sous_categories: [dag, task-based, workflow]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Dagster]]", "[[Prefect]]", "[[Mage]]", "[[Argo Workflows]]", "[[Kestra]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, data, orchestration, etl, dag]
url_officiel: https://airflow.apache.org/
url_docs: https://airflow.apache.org/docs/
url_repo: https://github.com/apache/airflow
---

# Airflow

## Pourquoi
Le **standard historique** de l'orchestration data (Apache, ex-Airbnb). Modèle DAG (tasks et dépendances), riche en operators (1000+ : SQL, S3, K8s, Spark, etc.), grand écosystème, déployé partout. Airflow 3.0 (2025) modernise sérieusement l'experience.

## Quand l'utiliser
- Stack data déjà sur Airflow → continuer
- Besoin d'un écosystème mûr d'operators (intégrations clé en main)
- Équipe formée Airflow
- Compliance / certifications enterprise (largement adopté)
- Cloud managed dispo : Astronomer, AWS MWAA, Google Cloud Composer

## Quand NE PAS l'utiliser
- Nouveau projet data → considérer [[Dagster]] ou [[Prefect]] (modèles plus modernes)
- Pipelines ML avec lineage et types stricts → [[Dagster]] est mieux pensé
- Petits jobs simples → over-engineering
- Workflow général non-data → [[Temporal]] ou outils dédiés

## Pièges connus
- **Scheduler** : lourd historiquement, beaucoup mieux depuis 2.x mais à dimensionner
- **Worker types** : Local / Celery / Kubernetes — choix architectural impactant
- **DAG dynamiques** : possibles mais pénibles avant 2.x, mieux avec dynamic task mapping
- **State** : Postgres Metastore obligatoire, à backuper et tuner
- **Idempotence** : à toi de la garantir dans tes tasks (Airflow ne t'aide pas)
- **Variables / Connections** : centralisées, à protéger (secret backends)
- **Airflow 2 → 3** : breaking changes, planifier la migration

## Liens
- [[Dagster]], [[Prefect]] — alternatives modernes
- [[Postgres]] — metastore typique
- Astronomer (managed) : https://www.astronomer.io/
- Airflow Best Practices : https://airflow.apache.org/docs/apache-airflow/stable/best-practices.html
- Providers (operators) : https://airflow.apache.org/docs/apache-airflow-providers/
