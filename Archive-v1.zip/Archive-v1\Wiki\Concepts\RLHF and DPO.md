---
galaxie: wiki
nom: RLHF, DPO & alignment
alias: [RLHF, DPO, PPO, GRPO, KTO, ORPO, alignement, reward modeling]
type: concept
categorie: concept/llm-training
sous_categories: [rlhf, dpo, ppo, alignment, llm]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Christiano 2017, Ouyang 2022 (RLHF), Rafailov 2023 (DPO), Shao 2024 (GRPO)]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, training, rlhf, alignment]
---

# RLHF, DPO & alignment

## TL;DR

Après [[SFT]], on aligne le modèle sur les **préférences humaines** : "réponse A est préférée à B". Deux grandes familles : **RLHF (PPO)** — train un reward model puis fine-tune via RL (PPO) ; **DPO** — directement optimiser sur paires de préférence, sans RL explicite, devenu standard 2024+. Variantes : **GRPO** (DeepSeek-R1), **KTO**, **ORPO**, **SimPO**. Pour reasoning models (o1, R1) : **RL avec verifiable rewards** (math, code, tests unitaires). Constitutional AI (Anthropic) = RLAIF + critique. **Alignment** est ce qui distingue un LLM utilisable d'un texte completion engine.

## Le problème

Après [[SFT]], le modèle est instructable mais :
- **Pas calibré** : peut être trop verbeux, trop sec, trop sycophant
- **Pas safe** : peut produire du harmful, faux, biased content
- **Pas aligné** : ne maximise pas l'utilité percue par l'humain

**Comment intégrer le signal "this response is better than that one"** ?

## L'idée

### Pipeline RLHF classique (Christiano 2017, Ouyang 2022)

```
[Pretrained] → [SFT] → [Reward Model (RM)] → [RL fine-tune (PPO)] → [Aligned model]
```

3 étapes :

#### 1. SFT (déjà vu)

Initialiser un modèle "decent" avec [[SFT]].

#### 2. Reward modeling

Collecter des **paires de préférence** humaines : "Pour le prompt $x$, response $y_w$ (winner) est préférée à $y_l$ (loser)".

Entraîner un **reward model** $r_\phi(x, y)$ (souvent un transformer modifié avec scalar head) avec **Bradley-Terry** loss :

$$ L_{RM} = -\mathbb{E}_{(x, y_w, y_l)} \log \sigma(r_\phi(x, y_w) - r_\phi(x, y_l)) $$

Le RM apprend à scorer les responses comme l'humain.

**Datasets** : Anthropic HH-RLHF, OpenAssistant, UltraFeedback, PKU SafeRLHF.

#### 3. PPO (Proximal Policy Optimization)

Fine-tune le LLM ($\pi_\theta$) pour maximiser le reward, avec **régularisation KL** vers le SFT model :

$$ \max_\theta \mathbb{E}_{x, y \sim \pi_\theta} [r_\phi(x, y)] - \beta \cdot \text{KL}(\pi_\theta || \pi_{SFT}) $$

KL pénalise la divergence du SFT model → évite **reward hacking** (exploitation des défauts du RM).

**Composants PPO** :
- **Reference model** : SFT model, frozen
- **Policy** : modèle qu'on entraîne
- **Reward model** : frozen
- **Value model** (critic) : estime $V(s)$ pour GAE
- **PPO loss** : clipped surrogate objective

→ Standard mais **lourd** : 4 modèles en mémoire (policy, ref, RM, critic).

### DPO (Direct Preference Optimization, Rafailov 2023)

**Innovation** : optimisation directe sur paires de préférence **sans RM ni RL**.

Insight : la solution optimale au problème RLHF a une **forme close** en fonction des préférences. On peut donc directement optimiser :

$$ L_{DPO} = -\mathbb{E}_{(x, y_w, y_l)} \log \sigma\left(\beta \log \frac{\pi_\theta(y_w|x)}{\pi_{ref}(y_w|x)} - \beta \log \frac{\pi_\theta(y_l|x)}{\pi_{ref}(y_l|x)}\right) $$

**Avantages** :
- Pas de RM séparé
- Pas de RL (PPO instable)
- Plus simple et stable
- Performance comparable ou supérieure

**Limites** :
- Pas de **online** RL (pas d'exploration)
- Distribution shift entre data offline et policy
- Moins flexible pour reasoning rewards

**Devenu standard** depuis 2024 (Llama 3, Tulu 3, etc.).

### Variantes DPO

#### IPO (Identity Preference Optimization, Azar 2024)

DPO peut overfit. IPO ajoute un terme de **regularisation**.

#### KTO (Kahneman-Tversky Optimization, Ethayarajh 2024)

Au lieu de paires, utilise **labels binaires** "good/bad" par sample. Plus simple à collecter.

#### ORPO (Odds Ratio PO, Hong 2024)

Combine SFT + alignment en une seule étape. **Pas besoin de SFT séparé**.

#### SimPO (Meng 2024)

Pas de reference model nécessaire. Plus simple, marche bien empiriquement.

#### CPO, SLiC, RRHF, etc.

Variations sur les contraintes / normalizations.

### GRPO (Group Relative Policy Optimization, DeepSeek 2024)

Innovation pour reasoning (R1) :
- Pas de critic (value model)
- Group de **plusieurs samples** par prompt, baseline = moyenne du groupe
- Mémoire / compute réduits vs PPO
- Combine bien avec **verifiable rewards** (math correct / code passes tests)

**Standard pour reasoning models** post 2024.

### RL avec verifiable rewards

Pour math, code : la "qualité" est **objective** (test unitaire passe ? réponse math correcte ?). Pas besoin de RM neural, juste un **vérificateur**.

- DeepSeek-R1 : RL pur sur math/code avec verifiable rewards
- R1-Zero : sans SFT, direct RL → emergent CoT
- OpenAI o1 family : RL extensif sur reasoning

**Implications** :
- Reward shape : 0/1 binaire (passe/passe pas)
- Pas de reward hacking sur le verifier
- Scaling possible massif

### Reward hacking

Le **risque #1** de RLHF : modèle exploite les défauts du RM.

Exemples :
- RM préfère réponses longues → modèle devient verbeux à mort
- RM préfère format markdown → réponses bourrées de bullet
- RM préfère réponses confidentes → hallucinations augmentent

**Mitigations** :
- **KL penalty** vers SFT
- RM **calibré** (re-train, ensembles)
- **Length normalization**
- **Early stopping** sur eval

### Constitutional AI (Anthropic)

Variante : **RLAIF** (RL from AI Feedback) + critique guidée par "constitution".

Deux phases :
1. **SL-CAI** : modèle critique ses propres outputs selon constitution, révise
2. **RL-CAI** : RM entraîné sur AI préférences (vs human)

Avantage : scaling de l'alignment sans human annotators à toutes les étapes.

### Self-rewarding / SPIN

- **Self-Rewarding LLM** (Yuan 2024) : modèle juge sa propre output, sert de RM
- **SPIN** (Chen 2024) : self-play, modèle vs lui-même

### Récapitulatif

| Méthode | RM | RL | Complexité | Performance |
|---|:-:|:-:|:-:|---|
| Vanilla SFT | ✗ | ✗ | low | base |
| RLHF (PPO) | ✓ | ✓ | high | excellent (si bien fait) |
| DPO | implicit | ✗ | medium | excellent, std 2024+ |
| KTO | implicit | ✗ | low | bon, data simple |
| ORPO | implicit | ✗ | low | bon, single-stage |
| GRPO | verifiable / implicit | ✓ | medium | SOTA reasoning |
| Constitutional AI | AI-RM | ✓ | high | safety++ |

### Best practices

1. **DPO d'abord** : plus simple, marche bien. Standard 2024+.
2. **PPO si on a infra mature** : reste meilleur sur certains cas
3. **GRPO pour reasoning** : math, code, agents
4. **Quality > quantity** sur preference data
5. **Online iterative** : DPO → re-collect preferences sur model nouveau → DPO → ... (Tulu 3, Llama 3)
6. **KL penalty calibré** (β) : pas trop bas (reward hacking), pas trop haut (stuck near SFT)
7. **Eval multi-axes** : task perf + safety + style + length + calibration
8. **Reward model audit** : detect hacking patterns

## Quand c'est utile

- **Tout chat model** : indispensable après SFT pour qualité production
- **Safety / refusal training** : RLHF excelle à refuser harmful queries
- **Reasoning models** : GRPO + verifiable rewards (math, code, science)
- **Tone / style alignment** : preferences capturent ces nuances
- **Constitutional AI** : large-scale safety sans human bottleneck
- **Reducing hallucinations** : preference for grounded responses
- **Reducing sycophancy** : preference for honest answers

## Quand ça ne marche pas / pièges

- **Reward hacking** : modèle exploite RM, devient inutilisable
- **DPO instable sur petits datasets** : besoin de qualité préf data
- **Forgetting** : RLHF peut dégrader capacités base (math, code) si pas bien calibré
- **Length bias** : modèle devient verbose (RM penche pour long)
- **Mode collapse** : modèle répond toujours pareil après agressive RLHF
- **PPO instabilité** : KL penalty trop bas explose
- **RM out-of-distribution** : RM trained sur SFT outputs voit policy outputs ≠ → mal calibré
- **Catastrophic forgetting** : capacités scientifiques perdues si data pref biaisée vers chat
- **Constitutional AI bias** : la "constitution" reflète biais de ses auteurs
- **GRPO sans verifiable** : besoin de reward signal solide
- **Preference data noise** : annotators inconsistants → RM bruité → policy bruitée

## Code minimal

```python
# DPO via TRL (standard 2024+)
from trl import DPOTrainer, DPOConfig
from transformers import AutoTokenizer, AutoModelForCausalLM
from datasets import load_dataset

model_id = "meta-llama/Meta-Llama-3-8B-Instruct"  # SFT model
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype="auto", device_map="auto")
# ref_model is created internally by DPOTrainer

# Dataset format: prompt, chosen, rejected
ds = load_dataset("argilla/ultrafeedback-binarized-preferences-cleaned")
# ds["train"] has columns: prompt, chosen, rejected

config = DPOConfig(
    output_dir="./dpo-llama3",
    per_device_train_batch_size=2,
    learning_rate=5e-7,  # Low!
    num_train_epochs=1,
    beta=0.1,            # KL regularization strength
    loss_type="sigmoid", # standard DPO
    max_length=2048,
    max_prompt_length=1024,
    bf16=True,
)

trainer = DPOTrainer(
    model=model,
    args=config,
    train_dataset=ds["train"],
    tokenizer=tokenizer,
)
# trainer.train()

# Pour PPO (legacy, plus complexe)
from trl import PPOTrainer, PPOConfig
# Demande RM + critic + ref_model + policy → setup plus lourd

# KTO (simple, binary labels)
from trl import KTOTrainer
# ds doit avoir colonnes : prompt, completion, label (bool)

# ORPO (combine SFT + alignment)
from trl import ORPOTrainer

# Reward model training (pour PPO)
from trl import RewardTrainer, RewardConfig
# ds avec : prompt, chosen, rejected
# trainer.train()

# GRPO (DeepSeek-style, pour reasoning)
from trl import GRPOTrainer, GRPOConfig
# Reward function = verifiable (math correct, code passes test)
def math_reward(completion, ground_truth):
    answer = extract_answer(completion)
    return 1.0 if answer == ground_truth else 0.0

# Eval alignement (MT-Bench, Arena Hard, AlpacaEval)
# from alpaca_eval import evaluate
# from arena_hard import judge
```

## Pour aller plus loin

- Christiano et al., *Deep reinforcement learning from human preferences* (NeurIPS 2017)
- Ouyang et al., *Training language models to follow instructions with human feedback* (InstructGPT, NeurIPS 2022)
- Rafailov et al., *Direct Preference Optimization: Your Language Model is Secretly a Reward Model* (NeurIPS 2023) — DPO
- Shao et al., *DeepSeekMath: Pushing the Limits of Mathematical Reasoning in Open Language Models* (2024) — GRPO
- Bai et al., *Constitutional AI: Harmlessness from AI Feedback* (Anthropic 2022)
- Ethayarajh et al., *KTO: Model Alignment as Prospect Theoretic Optimization* (2024)
- *TRL* (Hugging Face) — implémentations de référence
- AllenAI Tulu 3 paper — recette open SOTA
- **Liens internes** : [[SFT]], [[PEFT]], [[Reasoning models]], [[KL divergence]], [[LLM eval metrics]], [[PPO]], [[GRPO]], [[Reward modeling]], [[Reward shaping and hacking]], [[RL for LLMs]], [[Policy gradient]], [[Reinforcement learning]]
