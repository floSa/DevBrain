---
galaxie: wiki
nom: Advanced RAG architectures
alias: [GraphRAG, Self-RAG, CRAG, RAPTOR, contextual retrieval, agentic RAG]
type: concept
categorie: concept/rag
sous_categories: [rag, advanced, graphrag, self-rag, agentic-rag]
domaines: [ai-eng]
maturite: emerging
auteurs_cles: [Edge 2024 (GraphRAG), Asai 2023 (Self-RAG)]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, rag, advanced, llm]
---

# Advanced RAG architectures

## TL;DR

Au-delà du [[RAG]] naïf, plusieurs architectures sophistiquées : **Advanced RAG** (pre+post retrieval), **Self-RAG** (auto-évalue retrieval), **CRAG** (Corrective RAG), **GraphRAG** (Microsoft, graph + community summaries), **RAPTOR** (hierarchical clustering), **Contextual Retrieval** (Anthropic, chunk-level context + cache), **Agentic RAG** (multi-step retrieve), **HippoRAG** (memory-inspired), **LongRAG** (long chunks). Choisir selon : complexité queries, tolérance latence/cost, type docs. **Standard moderne 2026** : Contextual Retrieval + [[Hybrid retrieval]] + [[Reranking]] suffit dans 80% des cas ; GraphRAG / agentic pour use cases complexes.

## Le problème

[[RAG]] naïf (retrieve top-K → augment → generate) souffre :
- **Multi-hop queries** : "Compare X published in 2020 and Y in 2023" → 1 retrieve échoue
- **Aggregation queries** : "Summarize all opinions on Z" → naive RAG rate
- **Relationship queries** : "How does A connect to B?" → graph-shaped knowledge requis
- **Retrieval mauvais** : bad chunks → bad answer, garbage in/out
- **Context lost** : chunks isolés sans contexte global

## L'idée

### Naive RAG (baseline)

```
Query → Embed → Top-K retrieve → Stuff in prompt → Generate
```

Simple, marche pour 50% des use cases. Limites évidentes.

### Advanced RAG (pre/post-retrieval)

Add steps :

```
Query
  → [Pre-retrieval] : query rewrite, expansion, classification, HyDE
  → Retrieve (hybrid + filters)
  → [Post-retrieval] : reranking, compression, dedup
  → Augment + Generate
```

Voir [[Query transformations]], [[Hybrid retrieval]], [[Reranking]] pour détails.

### Self-RAG (Asai 2023)

LLM **émet des tokens spéciaux** pour décider :
- `[Retrieve]` : besoin de retrieve ?
- `[Relevant]` : ce chunk est-il pertinent ?
- `[Supported]` : ma réponse est-elle soutenue ?

Architecture :
1. Generate retrieve token → si Retrieve, retrieve
2. Score each retrieved chunk for relevance
3. Generate avec chunks pertinents
4. Self-critique

- LLM **decide** when to retrieve (not on every query)
- Filter retrieved chunks
- **Need fine-tuned model** with reflection tokens

### CRAG — Corrective RAG (Yan 2024)

Détecte les bad retrievals, corrige :

```
1. Retrieve initial top-K
2. Evaluator scores : "correct" / "incorrect" / "ambiguous"
3. If correct → standard RAG
4. If incorrect → web search fallback
5. If ambiguous → both + reweight
```

Robust face aux corpus limités.

### GraphRAG (Microsoft 2024)

**Idée révolutionnaire** :
1. **Build knowledge graph** depuis les docs (entities + relations)
2. Detect **communities** dans le graph (Leiden algorithm)
3. **Summarize each community** with LLM
4. À query time, choisir :
   - **Local search** : focus on entities mentioned
   - **Global search** : use community summaries pour aggregation queries

```
Docs → Extract entities/relations → Build graph
                                      ↓
                                  Communities + summaries
                                      ↓
Query → "What are themes about X?" → Global (community summaries)
                                   "Tell me about Alice" → Local (entity neighborhood)
```

**Bon pour** :
- Aggregation queries ("themes", "trends")
- Multi-hop reasoning
- Document collections with rich entities

**Cons** :
- **Cher à indexer** (entity extraction, community detection, summarization)
- Complexity setup

### RAPTOR (Sarthi 2024)

**Hierarchical clustering** :
1. Split docs en chunks
2. **Cluster** chunks (semantic)
3. **Summarize** chaque cluster
4. **Récursif** : cluster les summaries, re-summarize
5. Build tree (chunks at bottom, summaries higher)

À query time, retrieve à **tous les niveaux** : details (chunks) + abstractions (summaries).

### Contextual Retrieval (Anthropic 2024)

Voir [[Chunking strategies]]. **TL;DR** : pour chaque chunk, générer un **chunk-specific context** avec LLM + prepend → embed.

- Combine avec **prompt caching** du document entier → cheap
- **-49% retrieval errors** selon Anthropic
- Compatible avec hybrid + rerank

**Standard moderne** simple et efficace.

### Agentic RAG

L'agent **décide dynamiquement** :
- Retrieve ou pas ?
- Quel index ?
- Combien de retrieves ?
- Quelle query reformulation ?

```python
agent.run("Compare ML libraries", tools=[search_docs, search_code, web_search])
# Agent calls search_docs("ML libraries"), then web_search("ML libraries 2024 benchmarks"), etc.
```

Voir [[agent-loops]].

### FLARE — Forward-Looking Active REtrieval (Jiang 2023)

Retrieve **pendant** la generation, pas seulement avant :
- LLM commence à générer
- Quand confidence baisse (token avec faible proba) → retrieve
- Continue generation avec context

Réduit hallucinations sur long generation.

### Iter-RetGen

Itérative retrieve + generate :
- Retrieve → generate → use generation to refine retrieve → ...

Plus de queries, mais précision.

### HippoRAG (Gutiérrez 2024)

Memory-inspired :
- **Personalized PageRank** sur knowledge graph
- Combine semantic + symbolic retrieval
- Bon pour multi-hop

### LongRAG (Jiang 2024)

Utiliser **chunks longs** (4K tokens) au lieu de petits (200-500). Moins de retrieves nécessaires, plus de context.

- Combine avec long-context LLMs (Gemini, Claude 3.7)
- Plus simple que GraphRAG/RAPTOR

### RAGFlow, LightRAG

Frameworks open-source qui packagent ces patterns.

### Comparaison

| Pattern | Setup | Latency | Cost | Best for |
|---|---|---|---|---|
| Naive RAG | trivial | fast | low | simple Q&A |
| Advanced RAG | medium | medium | medium | general purpose |
| Self-RAG | fine-tune | medium | medium | quality-critical |
| CRAG | medium | medium-high | medium | sparse corpus |
| **GraphRAG** | **high** | medium | **high** | aggregation, multi-hop |
| RAPTOR | medium-high | medium | medium | hierarchical docs |
| **Contextual Retrieval** | **low** | low | **low** (with cache) | **default moderne** |
| Agentic RAG | medium | high (multi-step) | high | exploratory queries |
| FLARE | medium | high | high | long generation |
| LongRAG | low | low | medium | long-context model |

### Décision tree

```
- Simple Q&A → Naive ou Contextual Retrieval
- Need accuracy / safety → Self-RAG ou CRAG
- Aggregation / themes → GraphRAG ou RAPTOR
- Multi-step / exploratory → Agentic RAG
- Long-context model dispo → LongRAG (simpler)
- Production général → Contextual Retrieval + Hybrid + Rerank
```

### Best practices

1. **Start simple** (Naive RAG) → mesurer recall avant d'aller exotique
2. **Contextual Retrieval first** : bon ROI vs complexité
3. **GraphRAG** : justifier par use case (aggregation queries)
4. **Eval rigoureusement** : [[LLM eval metrics]] RAGAS
5. **Cost analysis** : indexing GraphRAG = 10-50x naive RAG
6. **Fallback strategies** : si RAG fail, use web search ou no-RAG
7. **Hybrid retrieval baseline** dans tous les cas
8. **Reranking** quasi-always
9. **Monitor en prod** : retrieval distribution shift
10. **Iterate** : pas la peine de tout faire d'un coup

## Quand c'est utile

- **Contextual Retrieval** : default moderne (Anthropic)
- **GraphRAG** : analyse corpus, themes, multi-hop entity reasoning
- **Self-RAG / CRAG** : qualité critique, low tolerance hallucination
- **RAPTOR** : nested hierarchical docs (books, manuals)
- **Agentic RAG** : research, exploration, ambiguous queries
- **LongRAG** : si tu as Claude 3.7 / Gemini 1.5 et budget context
- **FLARE** : long generation grounded
- **HippoRAG** : multi-hop sur knowledge graphs

## Quand ça ne marche pas / pièges

- **Over-engineering** : GraphRAG pour FAQ simple = waste
- **Eval missing** : impossible de savoir si advanced > naive sans baseline
- **GraphRAG entity extraction noise** : qualité graph dépend du extractor
- **RAPTOR clustering wrong** : random clusters = useless tree
- **Self-RAG fine-tune needed** : pas plug-and-play
- **Cost indexing GraphRAG** : 1M docs = 1M LLM calls
- **Agentic RAG loops** : agent infinite retrieve, cost explosion
- **Contextual Retrieval cache miss** : si chunks fréquemment updated → no benefit
- **LongRAG** + small context model : useless
- **Indices stale** : GraphRAG re-index hard quand docs update
- **Multi-modal** : la plupart de ces patterns text-only, vision RAG (ColPali) separate

## Code minimal

```python
# 1. Self-RAG (HuggingFace model dispo)
# from selfrag import SelfRagRetriever
# Or use Anthropic with prompted reflection :
def self_rag_step(query, docs):
    prompt = f"""
Query: {query}

Retrieved docs:
{docs}

Should we use these docs? Output JSON:
{{
  "use_docs": true/false,
  "relevant_docs": [indices],
  "answer_grounded": true/false (after answering)
}}"""
    # ... LLM call

# 2. CRAG
def crag_pipeline(query, retriever, web_search):
    candidates = retriever.search(query, k=10)
    # Evaluate quality
    score = llm_evaluate(query, candidates)
    
    if score == "correct":
        return generate(query, candidates)
    elif score == "incorrect":
        web_results = web_search(query)
        return generate(query, web_results)
    else:  # ambiguous
        combined = candidates + web_search(query)
        return generate(query, combined)

# 3. GraphRAG (using microsoft/graphrag library)
# pip install graphrag
# python -m graphrag.index --root ./my_docs
# python -m graphrag.query --root ./my_docs --method local --query "Tell me about Alice"
# python -m graphrag.query --root ./my_docs --method global --query "What are the main themes?"

# 4. RAPTOR (using github.com/parthsarthi03/raptor)
# from raptor import RetrievalAugmentation
# RA = RetrievalAugmentation()
# RA.add_documents(docs)
# answer = RA.answer_question("...")

# 5. Contextual Retrieval (Anthropic-style)
import anthropic
client = anthropic.Anthropic()

def add_chunk_context(doc, chunks):
    """For each chunk, generate context-aware prefix using full doc + prompt caching."""
    enriched = []
    for chunk in chunks:
        response = client.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=100,
            system="Provide 1-2 sentence context for this chunk to improve retrieval.",
            messages=[{
                "role": "user",
                "content": [
                    {"type": "text", "text": f"<document>{doc}</document>",
                     "cache_control": {"type": "ephemeral"}},  # CACHE!
                    {"type": "text", "text": f"<chunk>{chunk}</chunk>\nContext:"}
                ]
            }]
        )
        context = response.content[0].text
        enriched.append(f"{context}\n\n{chunk}")
    return enriched

# 6. Agentic RAG with LangGraph
# from langgraph import ...
# Build a graph with nodes : router, retriever, rewriter, answerer, validator

# 7. FLARE (forward-looking retrieval)
def flare_generate(query, retriever, llm, threshold=0.5):
    answer = ""
    for step in range(5):
        # Generate next chunk
        partial = llm.generate(query + answer, max_tokens=50, return_logprobs=True)
        avg_logprob = sum(partial.logprobs) / len(partial.logprobs)
        
        if avg_logprob < threshold:
            # Low confidence → retrieve more
            context = retriever.search(query + answer)
            partial = llm.generate(query + answer + str(context), max_tokens=50)
        
        answer += partial.text
        if partial.eos:
            break
    return answer

# 8. Eval with RAGAS
# from ragas import evaluate
# from ragas.metrics import faithfulness, answer_relevancy, context_precision, context_recall
# results = evaluate(
#     dataset=eval_dataset,
#     metrics=[faithfulness, answer_relevancy, context_precision, context_recall]
# )
```

## Pour aller plus loin

- Edge et al., *From Local to Global: A Graph RAG Approach to Query-Focused Summarization* (Microsoft, 2024)
- Asai et al., *Self-RAG: Learning to Retrieve, Generate, and Critique through Self-Reflection* (ICLR 2024)
- Yan et al., *Corrective Retrieval Augmented Generation* (CRAG, 2024)
- Sarthi et al., *RAPTOR: Recursive Abstractive Processing for Tree-Organized Retrieval* (ICLR 2024)
- Jiang et al., *Active Retrieval Augmented Generation* (FLARE, EMNLP 2023)
- Anthropic, *Introducing Contextual Retrieval* (blog 2024)
- Gao et al., *Retrieval-Augmented Generation for Large Language Models: A Survey* (2024)
- *RAGFlow*, *LightRAG*, *Microsoft GraphRAG* — open-source implementations
- **Liens internes** : [[RAG]], [[Chunking strategies]], [[Hybrid retrieval]], [[Reranking]], [[Query transformations]], [[agent-loops]], [[LLM eval metrics]]
