---
galaxie: dev
nom: BigQuery
alias: [bigquery, bq, google-bigquery]
categorie: data/warehouse
sous_categories: [data-warehouse, cloud, gcp, sql, dwh, serverless, analytics]
licence: Propriétaire
licence_type: proprietary
hosted: cloud (GCP)
maturite: production
langage: SQL
clients_officiels: [python, java, go, nodejs, bq-cli, dbt]
plateforme: [gcp]
score: 4
mes_projets: []
alternatives: ["[[Snowflake]]", "AWS Redshift", "Databricks SQL", "[[DuckDB]] (single-node)", "ClickHouse"]
remplace: []
remplace_par: []
created: 2026-05-21
modified: 2026-05-21
status: actif
tags: [service, data, warehouse, sql, gcp, cloud]
url_officiel: https://cloud.google.com/bigquery
url_docs: https://cloud.google.com/bigquery/docs
url_repo:
---

# BigQuery

## Pourquoi

**Data warehouse cloud serverless** de Google Cloud. Pas de gestion de cluster ni de warehouses à dimensionner — tu envoies du SQL, Google scale automatiquement (Dremel sous le capot). Storage et compute séparés, facturation **par octet scanné** (mode on-demand) ou **par slot-hour** (mode capacity / réservé).

Différenciateurs vs [[Snowflake]]/Redshift :
- **Vraiment serverless** : pas de warehouse à allumer/éteindre
- **BigQuery ML** : entraînement modèles ML directement en SQL (`CREATE MODEL`)
- **BigQuery DataFrames** (BPD) : API pandas-like qui pushdown vers BigQuery
- **Streaming inserts** natif
- **Geo / time / arrays / nested** types très puissants (Dremel = colonnes nested)
- **Dataform** (= dbt-like managed) inclus
- **Free tier 1 To/mois** de query + 10 Go storage

Standard de fait en stack GCP. Concurrent direct de [[Snowflake]] / Redshift.

## Quand l'utiliser

- **Stack GCP** : intégration profonde (Dataflow, Dataproc, Looker, Vertex AI)
- **Workload variable** : pas de coût si pas de query (mode on-demand)
- **Nested / JSON data** : type RECORD + ARRAY puissants, gestion semi-structuré excellente
- **BigQuery ML** : entraîner un modèle de classification/régression en `CREATE MODEL`
- **Geospatial** : GEOGRAPHY type, fonctions ST_* natives
- **Free tier généreux** : prototypes / petits projets gratuits
- **Combo [[dbt]]** : intégration mature
- **Streaming pipelines** : insert en temps réel via Storage Write API
- **Federated queries** : query Cloud SQL, Spanner, Cloud Storage sans ETL

## Quand NE PAS l'utiliser

- **Pas de GCP** → [[Snowflake]] (multi-cloud) ou Redshift (AWS)
- **OLTP / transactionnel** → Cloud SQL / Postgres (BigQuery = OLAP, latence query ~1s mini)
- **Single-node analytique** → [[DuckDB]] (gratuit, local)
- **Coût compute prédictible bas** → mode capacity slots ou Redshift Reserved
- **Volume énorme avec queries répétées** : on-demand pricing peut exploser, passer en mode slots
- **Charge constante 24/7** : Snowflake reserved warehouses ou Postgres + Citus moins cher
- **Open-source obligatoire** → ClickHouse, DuckDB, Trino

## Pièges connus

- **On-demand pricing** : facture aux octets scannés → un `SELECT *` sur grosse table = facture salée. **Toujours** filtrer + projeter
- **Partitioning + clustering critiques** : sans ça, full scan à chaque query → coût + lent
- **SELECT * coûte cher** : projeter explicitement les colonnes nécessaires
- **`WHERE date BETWEEN ...`** sur partition column = bon, sur autre col = full scan
- **Coût slots vs on-demand** : forte query → on-demand cher, charge prévisible → reservation moins cher mais cap fixe
- **Cache 24h** : les queries identiques sont gratuites depuis le cache, mais comprendre quand il invalide
- **SQL Standard vs Legacy** : par défaut Standard (BigQuery 2.0+), legacy déprécié — éviter
- **Streaming inserts** : facturés au volume + non-immédiats visibles dans les queries (latence ~quelques min)
- **Quotas** : 100 concurrent queries, 1500 table updates / jour — checker les limits
- **Costs hidden** : streaming, storage long terme, transferts inter-régions → audit régulier
- **Vendor lock-in GCP** : sortir = repenser stack, BQ-specific SQL (e.g. UNNEST + ARRAY_AGG patterns)
- **Federated queries** : pratique mais coûteuses (pas de cache, calcul à chaque fois)
- **BigQuery ML limits** : couvre régression / classif / clustering, mais pas le deep learning lourd (utiliser Vertex AI pour ça)

## Code minimal

```bash
# Install client Python
pip install google-cloud-bigquery google-cloud-bigquery-pandas pandas

# Auth via service account
export GOOGLE_APPLICATION_CREDENTIALS="$HOME/keys/sa.json"
# Ou en local : gcloud auth application-default login
```

```python
from google.cloud import bigquery
import pandas as pd

client = bigquery.Client(project="my-gcp-project")

query = """
SELECT corpus, count(*) AS n
FROM `bigquery-public-data.samples.shakespeare`
GROUP BY corpus
ORDER BY n DESC
LIMIT 10
"""

# Estimer le coût avant de lancer (dry run)
dry = client.query(query, job_config=bigquery.QueryJobConfig(dry_run=True, use_query_cache=False))
gb = dry.total_bytes_processed / 1e9
print(f"Cette query scannera {gb:.2f} Go (~${gb * 5 / 1000:.4f})")

# Exécuter
df = client.query(query).to_dataframe()
print(df)
```

```sql
-- Table partitionnée par date + clusterisée
CREATE TABLE mydataset.orders (
    order_id INT64, customer_id INT64, amount NUMERIC, order_date DATE
)
PARTITION BY order_date
CLUSTER BY customer_id;

-- Query qui exploite partition + cluster (rapide + bon marché)
SELECT customer_id, SUM(amount) AS total
FROM mydataset.orders
WHERE order_date BETWEEN '2026-01-01' AND '2026-01-31'
  AND customer_id = 42
GROUP BY customer_id;

-- Nested / ARRAY
SELECT
    user_id,
    ARRAY_AGG(STRUCT(event_name, event_time) ORDER BY event_time) AS events
FROM mydataset.events
GROUP BY user_id;

-- UNNEST pour exploser un ARRAY
SELECT user_id, event.event_name, event.event_time
FROM mydataset.user_events, UNNEST(events) AS event
WHERE event.event_name = 'purchase';
```

```sql
-- BigQuery ML : régression linéaire en SQL
CREATE OR REPLACE MODEL mydataset.churn_model
OPTIONS(model_type='LOGISTIC_REG', input_label_cols=['churned']) AS
SELECT * FROM mydataset.churn_training;

-- Prédire
SELECT * FROM ML.PREDICT(MODEL mydataset.churn_model,
    (SELECT * FROM mydataset.new_customers));
```

```python
# BigQuery DataFrames (BPD) : API pandas-like qui pushdown sur BigQuery
import bigframes.pandas as bpd

df = bpd.read_gbq("bigquery-public-data.ml_datasets.iris")
result = df.groupby("species").mean()       # tourne dans BigQuery
print(result.to_pandas())                    # rapatrie localement seulement le resultat
```

## Liens

- [[Snowflake]] / AWS Redshift — alternatives data warehouses cloud
- [[DuckDB]] — alternative single-node open-source
- [[dbt]] — combo standard (BigQuery + dbt = stack analytics moderne)
- [[Apache Iceberg]] — BigQuery lit les Iceberg tables (2024+)
- [[Spark]] / Dataproc — pour pipelines distribués GCP
- Vertex AI — combo ML / LLM
- ClickHouse / Trino — alternatives open-source
- Docs : https://cloud.google.com/bigquery/docs
- Pricing : https://cloud.google.com/bigquery/pricing
