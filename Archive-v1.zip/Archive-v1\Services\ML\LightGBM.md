---
galaxie: dev
nom: LightGBM
alias: [lgbm, Light Gradient Boosting Machine]
categorie: ml/framework
sous_categories: [gradient-boosting, supervised, tabular, fast, microsoft]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: C++
clients_officiels: [python, r, c, c-sharp]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[XGBoost]]", "[[CatBoost]]"]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, ml, gradient-boosting, supervised, tabular, microsoft]
url_officiel: https://lightgbm.readthedocs.io/
url_docs: https://lightgbm.readthedocs.io/en/latest/
url_repo: https://github.com/microsoft/LightGBM
---

# LightGBM

## Pourquoi

Gradient boosting sur arbres optimisé par **Microsoft** pour la **vitesse et la mémoire**. Différences principales avec [[XGBoost]] :
- **Croissance leaf-wise** (vs level-wise XGBoost) → arbres plus profonds plus vite, gain de perf mais risque d'overfit
- **Histogram-based** par défaut (binning des features continues) → train ~5-10× plus rapide sur gros dataset
- **Native categorical handling** (entiers, sans one-hot) → moins de RAM
- **EFB et GOSS** : techniques d'optim pour les datasets sparse et déséquilibrés

C'est l'algo à essayer si XGBoost est trop lent ou si tu as beaucoup de catégoriel.

## Quand l'utiliser

- Datasets gros à très gros (≥ 1M lignes, ≥ 100 features)
- Pipeline batch avec contraintes de temps d'entraînement
- Beaucoup de catégoriel (cf. paramètre `categorical_feature`)
- Compétitions ML / production où le tradeoff vitesse / perf est critique
- Quand XGBoost marche mais que tu veux 2-3× plus rapide

## Quand NE PAS l'utiliser

- Très petits datasets (< 10k lignes) : le leaf-wise overfit plus que XGBoost level-wise
- Catégoriel ultra-haute cardinalité native (>50 modalités) → [[CatBoost]] meilleur (target encoding interne)
- Production où la stabilité long-terme prime sur la vitesse → [[XGBoost]] (plus mature en environnements industriels)
- Tu utilises déjà XGBoost partout et la vitesse n'est pas un blocker

## Pièges connus

- **Leaf-wise growth** overfit facilement si `num_leaves` trop grand pour `max_depth`. Règle pragma : `num_leaves` < $2^{\text{max\_depth}}$
- **Petite taille de données** : le binning histogramme s'adapte mal → mettre `min_data_in_leaf` plus élevé
- **Bug `feature_fraction` < 1.0** sur tout petits datasets → désactiver pour < 1000 lignes
- **API native vs sklearn-compatible** : `LGBMClassifier/LGBMRegressor` pour sklearn, `lgb.train(...)` natif (avec datasets `lgb.Dataset` plus performants)
- **GPU support** moins mature qu'XGBoost (et qu'CatBoost). À tester avant de compter dessus en prod.
- **Catégoriel** : passer les colonnes catégorielles en pandas Categorical dtype OU lister via `categorical_feature=[...]` à `.fit()`

## Liens

- Doc officielle : https://lightgbm.readthedocs.io/
- Repo : https://github.com/microsoft/LightGBM
- Paper : Ke et al., *LightGBM: A Highly Efficient Gradient Boosting Decision Tree* (NIPS 2017)
- Concepts liés : [[Ensembling]] (boosting), [[Bias-variance tradeoff]], [[Regularization]], [[Cross-validation]]
- Alternatives : [[XGBoost]] (plus mature), [[CatBoost]] (meilleur catégoriel)
- [[Optuna]] (tuning hyperparams)
