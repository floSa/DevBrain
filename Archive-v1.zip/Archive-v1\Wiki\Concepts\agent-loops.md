---
galaxie: wiki
nom: Agent loops
type: concept
categorie: concept/llm
sous_categories: [agents, react, reflection, planning, multi-step]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Yao et al. 2022 (ReAct), Shinn 2023 (Reflexion), Anthropic]
lecture_min: 9
created: 2026-05-19
modified: 2026-05-20
tags: [concept, agents, llm, loops]
---

# Agent loops

## TL;DR

Un agent LLM n'est pas un appel unique : c'est une **boucle** qui alterne *réflexion → action → observation → réflexion → ...* jusqu'à atteindre l'objectif (ou abandonner). Plusieurs patterns de boucle existent (ReAct, Plan-and-Execute, Reflexion, etc.) — choisir le bon dépend de la nature de la tâche.

## Le problème

Pour des tâches non-triviales, **un seul prompt ne suffit pas**. Exemples :
- "Trouve les 3 papers les plus pertinents sur X et fais-en une synthèse" → search + filter + summarize, 3+ étapes
- "Débugge mon pipeline qui plante en prod" → inspecter logs + tester hypothèse + corriger, plusieurs itérations
- "Réserve un vol pour Tokyo lundi prochain" → chercher + comparer + booker, multi-étapes avec actions externes

L'agent doit pouvoir **enchaîner des tool calls**, **observer leurs résultats**, **adapter son plan**.

## L'idée

Le pattern de base :

```
boucle :
  1. Pensée  : "Pour atteindre l'objectif, je dois faire X"
  2. Action  : appel d'un tool (cf. [[tool-use]])
  3. Observation : résultat du tool
  4. Décision : objectif atteint ? → STOP. Sinon → revenir au 1.
fin boucle (avec max_steps)
```

Variantes principales :

### ReAct (Reasoning + Acting)

Simple boucle où le LLM verbalise sa réflexion avant chaque action :

```
Thought: I need to find the population of France
Action: web_search("population of France 2026")
Observation: "Approximately 68 million"
Thought: I have the info, I can answer.
Final Answer: 68 million.
```

**Avantage** : transparent, debuggable.
**Inconvénient** : verbeux, coûteux en tokens.

### Plan-and-Execute

Le LLM **planifie d'abord** toutes les étapes, puis exécute :

```
Plan:
  1. Chercher la population de la France
  2. Chercher la population de l'Allemagne
  3. Calculer le ratio
  4. Répondre

Execute step 1...
Execute step 2...
...
```

**Avantage** : moins de drift, parallélisation possible.
**Inconvénient** : adapte mal si une étape échoue (le plan est figé).

### Reflexion / Self-critique

Après une réponse, le LLM **critique sa propre sortie** et retente si nécessaire :

```
Réponse v1: ...
Critique: "Cette réponse a oublié de citer les sources"
Réponse v2: ... (avec sources)
```

**Avantage** : qualité finale meilleure.
**Inconvénient** : 2-3× le coût.

### Multi-agent / Délégation

Plusieurs agents collaborent (planner / executor / reviewer). Bien sur les workflows complexes mais ajoute beaucoup de complexité et de coût.

## Quand c'est utile

- **Tâches multi-étapes** intrinsèquement (recherche + synthèse, débug, automation)
- **Tâches qui requièrent observation du monde** (calls API/DB avec résultats imprévisibles)
- **Tâches où la qualité prime sur la latence** (reflexion vaut le coup)
- **Tâches longues** (>5 min de réflexion humaine) — l'agent ne se fatigue pas

## Quand ça ne marche pas / pièges

- **Boucles infinies** — toujours `max_steps` (5-20 selon tâche)
- **Coût exponentiel** — chaque step ajoute la conversation cumulée en contexte. Sur 10 steps avec 5k tokens de contexte, tu paies ~50k tokens par tour à la fin.
- **Drift hors-sujet** — le LLM peut s'égarer. Garder l'objectif dans le prompt système à chaque tour.
- **Tools mal foutus** → boucle infinie de retry. Valider les réponses des tools, fail fast.
- **Pas d'eval** — un agent est encore plus difficile à eval qu'un RAG. Voir [[Evaluer un systeme LLM]].
- **Hallucination de tool calls** → l'agent invente un tool inexistant. Valider la whitelist.

## Implémentations concrètes

- [[LangGraph]] — orchestration explicite de graphes d'agents, le plus mature
- [[PydanticAI]] — type-safe, agent + tools en Python natif
- [[DSPy]] — programmable et optimisable (la boucle elle-même peut être optimisée)
- [[Anthropic Claude API]] — tool use natif + extended thinking pour le step "réflexion"

## Code minimal

```python
# ReAct loop avec Anthropic — version "from scratch"
import anthropic
client = anthropic.Anthropic()

# 1. Définir les tools (cf. [[tool-use]])
tools = [{
    "name": "web_search",
    "description": "Search the web for current information",
    "input_schema": {
        "type": "object",
        "properties": {"query": {"type": "string"}},
        "required": ["query"]
    }
}]

def execute_tool(name, args):
    if name == "web_search":
        return f"Mock results for: {args['query']}"
    return f"Unknown tool: {name}"

# 2. Boucle agent
def agent_loop(user_task, max_steps=10):
    messages = [{"role": "user", "content": user_task}]
    
    for step in range(max_steps):
        response = client.messages.create(
            model="claude-3-7-sonnet-latest",
            max_tokens=1024,
            tools=tools,
            messages=messages,
        )
        
        # Append assistant turn
        messages.append({"role": "assistant", "content": response.content})
        
        if response.stop_reason == "end_turn":
            # Agent a fini
            return response.content[-1].text
        
        if response.stop_reason == "tool_use":
            # Exécuter chaque tool_use bloc
            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    result = execute_tool(block.name, block.input)
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": result,
                    })
            messages.append({"role": "user", "content": tool_results})
    
    return "Max steps reached, abandoning"

print(agent_loop("Quel est l'âge moyen de la population française ?"))

# Variante 1 : ajouter critique / reflexion
def agent_with_critique(task):
    answer = agent_loop(task)
    critique = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=500,
        messages=[{"role": "user", "content": f"Task: {task}\nDraft: {answer}\nCritique honestly."}]
    ).content[0].text
    # Optionnellement : re-run avec la critique en contexte
    return answer, critique

# Pour des cas réels : utiliser LangGraph (cf. [[Agent patterns]] et [[Multi-agent systems]])
```

## Pour aller plus loin

- Paper ReAct : https://arxiv.org/abs/2210.03629
- Paper Reflexion : https://arxiv.org/abs/2303.11366
- Anthropic — "Building effective agents" : https://www.anthropic.com/research/building-effective-agents
- Concepts liés : [[tool-use]], [[RAG]] (souvent un sub-step d'un agent)
