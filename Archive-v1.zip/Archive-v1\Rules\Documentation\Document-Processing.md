---
galaxie: dev
type: rule
domaine: documentation
applicable: type-service-document-processing
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, documentation, parsing, ocr, docling, ingestion]
---

# Règle — Documentation Traitement de documents

S'applique à : [[Docling]], Unstructured, Marker, PyMuPDF, services OCR (Tesseract, AWS Textract).

## Principe (1 phrase)
Le `services/<doc-processing>/README.md` doit lister **les formats supportés** et imposer **un format de sortie standardisé** pour le reste du pipeline — sinon chaque consommateur réinvente sa logique de normalisation.

## MUST

### 1. Formats supportés
Liste exhaustive des **extensions acceptées en entrée** :

```
| Format | Extension | Parser utilisé | OCR ? | Limite |
|--------|-----------|----------------|-------|--------|
| PDF natif | .pdf | Docling | non | 200 MB |
| PDF scanné | .pdf | Docling + Tesseract | oui | 50 MB |
| DOCX | .docx | Docling | non | 50 MB |
| HTML | .html | defuddle | non | 10 MB |
| Image | .png, .jpg | Tesseract | oui | 20 MB |
| Markdown | .md | passthrough | non | - |
```

- Pour chaque format : limites de taille, comportement si format mal formé
- Liste **explicite des formats refusés** (ex: `.doc` legacy, `.rtf`, `.epub`)

### 2. Pipeline de normalisation (CRITIQUE)
- **Format de sortie standardisé imposé** au reste du projet
- Recommandé : **Markdown structuré** avec frontmatter, headings hiérarchiques, tableaux préservés
- Le pipeline doit garantir que **TOUT input** (PDF complexe, DOCX, etc.) ressort en ce même format
- Schéma JSON ou Pydantic du document normalisé :
  ```python
  class NormalizedDocument(BaseModel):
      doc_id: str
      source_type: Literal["pdf", "docx", "html", "image", "md"]
      source_path: str
      title: str | None
      author: str | None
      created_at: datetime | None
      content_md: str           # markdown structuré
      sections: list[Section]   # hiérarchie h1/h2/h3
      tables: list[Table]
      images: list[Image]       # extraites séparément
      metadata: dict
  ```

### 3. Stratégie de chunking (souvent en aval, mais à documenter ici si géré ici)
Si le service de processing fait aussi le chunking (avant indexation vectorielle) :
- Voir [[Database-Vector]] pour les conventions de chunking
- Documenter explicitement quel composant fait quoi

### 4. Contrat d'interface
- Endpoint / fonction principal : `process_document(path: str) -> NormalizedDocument`
- Mode async / sync
- Gestion des erreurs (format inconnu, parsing fail, OCR fail)
- Idempotence (rejouer le parsing produit le même output)

### 5. Stratégie de conservation des originaux
- Les fichiers source sont-ils conservés (cf. [[Storage-Object]]) ?
- Combien de temps ?
- Le résultat normalisé est-il regénérable depuis la source ?

## SHOULD

- **Tests unitaires** sur des fichiers d'exemple (un par format)
- **Métriques de qualité** : taux de succès du parsing, temps moyen
- **Logs structurés** : doc_id, format, durée, taille
- **Stratégie OCR fallback** : si parser natif rate, basculer sur OCR
- **Multi-langue** : langues supportées par l'OCR (eng, fra, etc.)

## NICE

- Benchmark perf par type de document
- Dataset interne d'edge cases (PDFs cassés, DOCX corrompus, images low-res)
- Métriques fidélité : tables complexes correctement extraites %

## Pièges classiques

- **PDFs scannés détectés comme natifs** : faux positif sur la détection texte
- **Encoding UTF-8 vs Latin-1** : sources legacy en latin1 → mojibake
- **Tables fusionnées (rowspan, colspan)** : extraction imparfaite — à valider
- **Formules math** : LaTeX vs MathML vs image — choisir et tester
- **OCR hallucinations** : sur images très basse qualité, OCR invente
- **Images extraites volumineuses** : à compresser avant stockage
- **Documents très longs** (>500 pages) : timeout / mémoire — chunker tôt

## Voir aussi

- Template : `Templates/ServiceDocs/README - document-processing.md`
- [[README - Service]] — règle parente
- [[Database-Vector]] — consommateur en aval (chunking + indexation)
- [[Storage-Object]] — souvent en amont (bucket raw)
- [[Docling]] — fiche Service
