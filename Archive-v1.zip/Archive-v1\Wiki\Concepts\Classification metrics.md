---
galaxie: wiki
nom: Classification metrics
alias: [accuracy, precision, recall, F1, MCC, kappa, log loss, confusion matrix]
type: concept
categorie: concept/metrics
sous_categories: [metrics, classification, evaluation]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Matthews 1975, Cohen 1960]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, metrics, classification]
---

# Classification metrics

## TL;DR

Métriques pour évaluer un classifieur (binaire ou multi-classe). **Accuracy** trompeuse sur données déséquilibrées. Famille **precision/recall/F1** pour quantifier qualité par classe. **Log loss** pour les modèles probabilistes calibrés. **MCC** = meilleure métrique single-number sur binaire. **Kappa** pour multi-classe avec accord chance-corrected. Coupler systématiquement à [[ROC AUC]] et [[Calibration]].

## Le problème

Un classifieur sort soit une **classe**, soit un **score / proba**. Différentes métriques selon :
- Binaire vs multi-classe
- Équilibré vs déséquilibré
- Métriques hard (sur la classe) vs soft (sur la proba)
- Coût asymétrique des faux positifs vs faux négatifs

## L'idée

### Matrice de confusion (binaire)

|   | Prédit + | Prédit - |
|---|---|---|
| **Réel +** | TP | FN |
| **Réel -** | FP | TN |

Tout le reste se calcule à partir de là.

### Métriques de base

| Métrique | Formule | Interprétation |
|---|---|---|
| **Accuracy** | $\frac{TP+TN}{n}$ | % corrects, trompeur si déséquilibré |
| **Precision** (PPV) | $\frac{TP}{TP+FP}$ | parmi les "+ prédits", % vrais "+" |
| **Recall** (sensitivity, TPR) | $\frac{TP}{TP+FN}$ | parmi les "+ réels", % détectés |
| **Specificity** (TNR) | $\frac{TN}{TN+FP}$ | parmi les "- réels", % rejetés |
| **F1-score** | $\frac{2 \cdot P \cdot R}{P + R}$ | moyenne harmonique precision/recall |
| **NPV** | $\frac{TN}{TN+FN}$ | parmi les "- prédits", % vrais "-" |

### Trade-off precision / recall

**Toujours en tension** :
- Seuil bas → recall ↑, precision ↓ (alarme moindre)
- Seuil haut → precision ↑, recall ↓ (sélectif)

**PR curve** = precision vs recall en variant le seuil. **AUC-PR** = aire sous PR curve. **Meilleure que ROC AUC sur classes déséquilibrées** (ne récompense pas la spécificité gratuite).

### F-beta

$$ F_\beta = (1 + \beta^2) \frac{P \cdot R}{\beta^2 P + R} $$

- $\beta = 1$ → F1, équilibré
- $\beta = 2$ → F2, recall 2x plus important (médical, fraud)
- $\beta = 0.5$ → F0.5, precision 2x plus important (anti-spam)

Choix selon coût business.

### Métriques avancées single-number

#### MCC (Matthews Correlation Coefficient)

$$ \text{MCC} = \frac{TP \cdot TN - FP \cdot FN}{\sqrt{(TP+FP)(TP+FN)(TN+FP)(TN+FN)}} $$

- Range $[-1, 1]$, 0 = random
- **Symétrique** dans les 4 cellules de la matrice
- **Très robuste au déséquilibre** : ne peut pas être trompée
- Réf : Chicco & Jurman 2020 — meilleur que F1 et accuracy single-number

#### Cohen's kappa

$$ \kappa = \frac{p_o - p_e}{1 - p_e} $$

avec $p_o$ accord observé, $p_e$ accord attendu par chance.

- $\kappa = 1$ : accord parfait
- $\kappa = 0$ : accord chance
- $\kappa < 0$ : pire que chance
- **Multi-class** natif
- Interprétation Landis-Koch : > 0.6 = substantial, > 0.8 = almost perfect

#### Balanced accuracy

$$ \text{BA} = \frac{1}{2} \left( \frac{TP}{TP+FN} + \frac{TN}{TN+FP} \right) = \frac{\text{Recall}_+ + \text{Recall}_-}{2} $$

Moyenne des recalls par classe. Robuste au déséquilibre, simple à interpréter.

### Métriques probabilistes

#### Log loss (cross-entropy)

$$ L = -\frac{1}{n} \sum_{i=1}^n y_i \log \hat p_i + (1 - y_i) \log(1 - \hat p_i) $$

- Pénalise très fort les **prédictions confiantes mais fausses** ($\hat p \to 1$ avec $y=0$ → $-\log 0 = \infty$)
- Pour modèles calibrés (voir [[Calibration]])
- Standard loss pour entraînement (cross-entropy = neg log-likelihood Bernoulli)

#### Brier score

$$ \text{BS} = \frac{1}{n} \sum (y_i - \hat p_i)^2 $$

- MSE entre proba prédite et label binaire
- Décomposable : reliability + resolution + uncertainty
- Plus stable que log loss aux outliers de proba

#### ROC AUC / PR AUC

Voir [[ROC AUC]] pour la profondeur. Récap :
- ROC AUC = P(score d'un + > score d'un - sur paires aléatoires)
- Insensible au seuil
- Trompeuse en classes très déséquilibrées → préférer PR AUC

### Multi-classe

Trois façons d'agréger :

| Agrégation | Calcul | Quand |
|---|---|---|
| **Macro** | moyenne des métriques par classe (poids égaux) | classes équilibrées, on veut traiter égales |
| **Weighted** | moyenne pondérée par support de chaque classe | déséquilibré mais on veut perf globale |
| **Micro** | calcul global TP/FP/FN | identique à accuracy en multi-class hard |

**Confusion matrix multi-classe** : visualisation des confusions entre classes (où le modèle se trompe).

### Coût-sensible (cost-sensitive)

Quand FP et FN n'ont pas le même coût :

$$ \text{cost} = c_{FP} \cdot FP + c_{FN} \cdot FN $$

À minimiser. Choisir le **seuil de décision** qui minimise le coût pondéré :

$$ \text{seuil}^* = \frac{c_{FP}}{c_{FP} + c_{FN}} $$

(sous calibration parfaite). Cf. medical, fraud, defaults.

### Tableau récap

| Métrique | Range | Multi-class | Déséquilibre OK | Probabiliste |
|---|---|:-:|:-:|:-:|
| Accuracy | [0,1] | ✓ | ✗ | ✗ |
| Precision/Recall/F1 | [0,1] | ✓ (avec agrégation) | ~ | ✗ |
| MCC | [-1,1] | ✓ | ✓ | ✗ |
| Cohen's κ | [-1,1] | ✓ | ✓ | ✗ |
| Balanced accuracy | [0,1] | ✓ | ✓ | ✗ |
| ROC AUC | [0,1] | one-vs-rest | ~ | ✓ |
| PR AUC | [0,1] | one-vs-rest | ✓ | ✓ |
| Log loss | [0,∞] | ✓ | ~ | ✓ |
| Brier score | [0,1] | ✓ | ~ | ✓ |

## Quand c'est utile

- **Toute classif** : accuracy + F1 + AUC en première lecture
- **Déséquilibré** : F1/F-beta + MCC + PR AUC, **jamais accuracy seule**
- **Probabiliste calibré** : log loss + Brier + calibration plot
- **Multi-classe** : confusion matrix + macro-F1 + Cohen's κ
- **Costs asymétriques** : optimisation directe du coût pondéré
- **Reporting** : un dashboard de métriques, pas un seul nombre

## Quand ça ne marche pas / pièges

- **Accuracy paradox** : 99% accuracy sur 1% positifs = prédire toujours 0. Inutile.
- **F1 cache la moyenne harmonique** : P=1.0, R=0.01 → F1=0.02 (très bas). Peut sembler injuste si recall faible n'est pas grave.
- **Optimiser un seuil sur test set** = overfitting. Valider via cross-val.
- **AUC sans calibration** : ranking ok mais probas non-fiables → décision peut être mauvaise.
- **Multi-class macro vs micro** : ne pas comparer modèles avec agrégations différentes.
- **Confusion matrix normalization** : "rowwise" (recall) vs "colwise" (precision) vs "all" (joint) — toujours préciser quoi.
- **Stratified split obligatoire** sur déséquilibré : train/test doivent avoir la même répartition de classes.
- **Log loss explose** sur $\hat p = 0$ avec $y = 1$ — clipper $\hat p \in [\epsilon, 1-\epsilon]$.
- **Métrique d'optimisation ≠ métrique d'éval** : entraîner sur log loss et évaluer sur F1 ≠ entraîner sur F1 (proxy direct difficile).

## Code minimal

```python
import numpy as np
from sklearn.metrics import (
    confusion_matrix, classification_report,
    precision_score, recall_score, f1_score, fbeta_score,
    matthews_corrcoef, cohen_kappa_score, balanced_accuracy_score,
    roc_auc_score, average_precision_score, log_loss, brier_score_loss
)

# Binaire
y_true = np.array([0, 0, 0, 0, 1, 1, 1, 0, 0, 1])
y_pred = np.array([0, 0, 1, 0, 1, 1, 0, 0, 1, 1])
y_proba = np.array([0.1, 0.2, 0.6, 0.3, 0.9, 0.7, 0.4, 0.2, 0.8, 0.95])

print(classification_report(y_true, y_pred))  # precision, recall, F1 par classe + macro/weighted
cm = confusion_matrix(y_true, y_pred)
print(f"Confusion matrix:\n{cm}")

print(f"MCC              = {matthews_corrcoef(y_true, y_pred):.3f}")
print(f"Cohen κ          = {cohen_kappa_score(y_true, y_pred):.3f}")
print(f"Balanced acc     = {balanced_accuracy_score(y_true, y_pred):.3f}")
print(f"F2 (recall x2)   = {fbeta_score(y_true, y_pred, beta=2):.3f}")
print(f"ROC AUC          = {roc_auc_score(y_true, y_proba):.3f}")
print(f"PR AUC (avg prec)= {average_precision_score(y_true, y_proba):.3f}")
print(f"Log loss         = {log_loss(y_true, y_proba):.3f}")
print(f"Brier            = {brier_score_loss(y_true, y_proba):.3f}")

# Choisir le seuil optimal pour minimiser un coût
from sklearn.metrics import precision_recall_curve
precision, recall, thresholds = precision_recall_curve(y_true, y_proba)
c_fp, c_fn = 1, 5  # FN coûte 5x plus
# pour chaque seuil, recalculer le coût
costs = []
for t in thresholds:
    pred = (y_proba >= t).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred).ravel()
    costs.append(c_fp * fp + c_fn * fn)
best_t = thresholds[np.argmin(costs)]
print(f"Seuil optimal coût (FN cher): {best_t:.2f}")

# Multi-class
y_true_mc = np.array([0, 1, 2, 0, 1, 2, 0, 0, 1, 2])
y_pred_mc = np.array([0, 2, 2, 0, 1, 1, 0, 0, 1, 2])
print(classification_report(y_true_mc, y_pred_mc, target_names=['A', 'B', 'C']))

# Confusion matrix normalisée pour analyse
cm = confusion_matrix(y_true_mc, y_pred_mc, normalize='true')  # par classe réelle
# colonnes = précision-like ; lignes = recall-like

# Distribution des probas (calibration plot manuel)
from sklearn.calibration import calibration_curve
prob_true, prob_pred = calibration_curve(y_true, y_proba, n_bins=5)
# courbe à plotter, doit suivre la diagonale si calibré
```

## Pour aller plus loin

- Chicco & Jurman, *The advantages of the Matthews correlation coefficient (MCC) over F1 score and accuracy* (BMC Genomics 2020)
- He & Garcia, *Learning from Imbalanced Data* (TKDE 2009)
- Saito & Rehmsmeier, *The Precision-Recall Plot Is More Informative than ROC Plot When Evaluating Binary Classifiers on Imbalanced Datasets* (PLOS ONE 2015)
- **Liens internes** : [[ROC AUC]], [[Calibration]], [[Regression metrics]], [[Imbalanced classification]], [[Hypothesis testing]]
