---
galaxie: dev
nom: AWS S3
alias: [s3, amazon s3]
categorie: storage/object
sous_categories: [object-storage, blob, cloud, s3-api]
licence: Proprietaire (managed)
licence_type: proprietary
hosted: managed
maturite: production
langage: 
clients_officiels: [python (boto3), ts, go, rust, java, ruby]
plateforme: [cloud]
score: 5
mes_projets: []
alternatives: ["[[MinIO]]", "[[Cloudflare R2]]", GCS, Azure Blob]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, storage, object, s3]
url_officiel: https://aws.amazon.com/s3/
url_docs: https://docs.aws.amazon.com/s3/
url_repo: 
---

# AWS S3

## Pourquoi
Stockage objet de référence du cloud. Durabilité 99.999999999% (11 nines), API qui est devenue le **standard de facto** (tous les concurrents l'implémentent : MinIO, R2, Wasabi, Backblaze, GCS via XML). Pratiquement infini en volume et débit.

## Quand l'utiliser
- Stockage data lakes (Parquet partitionnés, Iceberg, Delta)
- Stockage fichiers utilisateurs (uploads, médias)
- Backups
- Static website hosting (avec CloudFront)
- Pipeline ML : artifacts, datasets, modèles
- Event-driven : trigger Lambda sur PUT
- ML training data sharding sur multiples nœuds

## Quand NE PAS l'utiliser
- Self-host obligatoire (souveraineté, on-prem) → [[MinIO]] (API S3-compatible)
- Coût egress critique (sortie data chère) → [[Cloudflare R2]] (egress gratuit)
- Read latency sub-10ms → CDN devant ou base spécialisée
- Append/edit fréquent → S3 = write-once (objets immutables, replace seulement)

## Pièges connus
- **Pricing complexe** : storage + requests + egress + transfers + data retrieval (Glacier). Easy to surprise yourself.
- **Egress AWS → internet** : ~$0.09/GB. Sur 1 TB/mois = $90, vite gros.
- **Eventual consistency** historique fixé en 2020 → maintenant strong read-after-write.
- **List objects coûteux** : LIST = 1 request per 1000 objects, lent sur gros buckets. Préférer index externe (DynamoDB, Postgres).
- **Versionning + lifecycle** : à activer dès le début (impossible de "retroactiver")
- **Public buckets accidentels** : block public access par défaut depuis 2023, vérifier
- **Régions** : transferts cross-region payants, choisir la bonne dès le départ

## Liens
- [[MinIO]] — self-host API-compatible
- [[Cloudflare R2]] — alternative cloud zero-egress
- boto3 (Python) : https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3.html
- S3 best practices : https://docs.aws.amazon.com/AmazonS3/latest/userguide/best-practices.html
