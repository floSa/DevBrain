---
galaxie: wiki
nom: Multiple Correspondence Analysis (MCA)
alias: [MCA, ACM, Analyse des Correspondances Multiples]
type: concept
categorie: concept/stats
sous_categories: [factor-analysis, categorical, dimensionality-reduction, burt-matrix]
domaines: [data-science]
maturite: established
auteurs_cles: [Benzécri 1973, Greenacre 1984, Lebart]
lecture_min: 10
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, mca, factor-analysis, categorical]
---

# Multiple Correspondence Analysis (MCA)

## TL;DR

Extension de [[CA]] à **plusieurs variables catégorielles** (au lieu de 2). Permet de réduire la dimension et de visualiser un questionnaire avec $Q$ questions catégorielles. Mathématiquement : appliquer une CA sur le **tableau disjonctif complet** (indicator matrix) ou sur la **matrice de Burt**.

## Le problème

Données : $n$ individus, $Q$ variables catégorielles, chacune ayant $J_q$ modalités. Total des modalités $J = \sum_q J_q$. On veut :
- Identifier les **profils d'individus** récurrents
- Visualiser les **associations** entre modalités, toutes variables confondues
- Réduire la dimension (utile avant clustering type k-modes)

## L'idée

### Tableau disjonctif complet

On encode chaque individu comme un vecteur de 0/1 sur les $J$ modalités. Cela donne la matrice indicatrice $Z \in \{0,1\}^{n \times J}$ avec exactement $Q$ uns par ligne.

### Approche 1 — CA sur la matrice indicatrice

Appliquer [[CA]] directement à $Z$. Les inerties principales sont obtenues par SVD du tableau standardisé.

### Approche 2 — CA sur la matrice de Burt

La matrice de Burt $B = Z^\top Z$ est la matrice $J \times J$ des cooccurrences entre modalités. Sa diagonale par blocs contient les comptages marginaux.

Appliquer CA sur $B$ donne les mêmes coordonnées de modalités qu'avec $Z$, à un facteur d'échelle près.

### Inertie et correction "Greenacre"

L'inertie totale d'une MCA naïve est :

$$ I = \frac{J - Q}{Q} $$

Indépendante des données ! C'est juste fonction de la taille du tableau. Pour corriger ce biais :

- **MCA ajustée** (Greenacre 1991, Benzécri) : on garde uniquement les valeurs propres $\lambda_k > 1/Q$ et on les recale :

$$ \lambda_k^{\text{adj}} = \left( \frac{Q}{Q-1} \right)^2 \left( \lambda_k - \frac{1}{Q} \right)^2 $$

- Cela donne une **variance expliquée plus réaliste** (souvent ≥ 30% sur les deux premiers axes ajustés, vs <10% en MCA brute).

### Interprétation

- **Coordonnées des individus** : profils types dans le plan
- **Coordonnées des modalités** : "rares" loin du centre, "fréquentes" proches
- Une **association forte** entre modalités → proches dans le plan factoriel

## Quand c'est utile

- Questionnaires sociaux, sondages multi-questions
- Préliminaire à un clustering catégoriel (HCPC sur les coordonnées MCA)
- Analyse de profils de consommateurs / patients
- Toute fois où tu utiliserais une [[CA]] mais avec >2 variables

## Quand ça ne marche pas / pièges

- **Mix continu + catégoriel** → [[FAMD]] ou discrétisation préalable (mais perte d'info)
- **Modalités très rares** (<5% des individus) → tirent les axes — fusionner ou marquer "supplémentaires"
- **MCA brute** te donne des taux d'inertie démoralisants (2% sur axe 1 !) — toujours utiliser la **MCA ajustée** pour communiquer.
- **Stabilité** : ajouter une variable change tout le plan. La MCA est plus instable qu'une PCA.
- **Beaucoup de modalités** (>50) → plan factoriel illisible. Filtrer les modalités contributives.

## Code minimal

```python
import prince
import pandas as pd

# df : DataFrame avec uniquement des colonnes catégorielles
mca = prince.MCA(n_components=2, n_iter=10, copy=True).fit(df)

mca.plot(df)
print(mca.eigenvalues_summary)   # eigenvalues + % variance ajustée

# Coordonnées
ind_coords = mca.row_coordinates(df)
mod_coords = mca.column_coordinates(df)
```

## Implémentations concrètes

- [[prince]] — `prince.MCA` avec ajustement Benzécri
- [[fanalysis]] — alternative
- R : `FactoMineR::MCA` (référence académique)
- `mca` package PyPI — plus ancien, moins de diagnostics

## Pour aller plus loin

- Husson, Lê, Pagès — *Analyse de données avec R* (chap. MCA)
- Greenacre, *Correspondence Analysis in Practice* — chapitres sur MCA et ajustement
- **Liens internes** : [[CA]] (le cas Q=2), [[FAMD]] (mix continu/cat.), [[MFA]] (groupes), [[PCA]] (le pendant continu), HCPC pour clustering post-MCA
