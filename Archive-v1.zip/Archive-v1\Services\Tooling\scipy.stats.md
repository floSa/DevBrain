---
galaxie: dev
nom: scipy.stats
alias: [scipy-stats, scipy.stats]
categorie: tooling/stats
sous_categories: [stats, scipy, statistical-tests, distributions, sampling]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python / C / Fortran
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: ["statsmodels", "pingouin", "numpy.random", "R (base)"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, stats, scipy]
url_officiel: https://docs.scipy.org/doc/scipy/reference/stats.html
url_docs: https://docs.scipy.org/doc/scipy/reference/stats.html
url_repo: https://github.com/scipy/scipy
---

# scipy.stats

## Pourquoi

Module statistique de **SciPy** : 100+ **distributions** (Normal, Beta, Gamma, Poisson, χ², t, F, mais aussi noncentral, truncated, mixture), **tests classiques** (t-test, ANOVA, Chi², Kolmogorov-Smirnov, Mann-Whitney, Wilcoxon, Kruskal-Wallis), **corrélations** (Pearson, Spearman, Kendall), **stats descriptives** (skew, kurtosis, mode, quantiles), **bootstrap**, **monte-carlo tests**.

**Standard bas niveau** pour les stats en Python : c'est la brique que **pingouin** wrappe, que **statsmodels** appelle, que **scikit-learn** utilise en interne. Si tu fais juste un t-test ou une distribution, c'est direct. Pour des analyses cliniques reproductibles avec effect sizes, passer à `pingouin`. Pour du modeling, à `statsmodels`.

## Quand l'utiliser

- **Tests statistiques de base** : t-test, Chi², Mann-Whitney, KS
- **Sampling depuis distributions** : `stats.norm.rvs(size=1000, loc=0, scale=1)`
- **Stats descriptives** : `stats.describe(x)`, `stats.skew`, `stats.kurtosis`
- **Fit distribution** : `stats.beta.fit(data)` pour estimer α, β
- **CDF / PDF / PPF** : calcul de p-values, quantiles
- **Bootstrap / permutation tests** : `stats.bootstrap`, `stats.permutation_test`
- **Brique de calcul scientifique** : utilisée par presque toutes les libs
- **Pas d'effect sizes requis** : t-test simple sans Cohen d

## Quand NE PAS l'utiliser

- **Modeling complexe** (GLM, time series, mixed models) → `statsmodels`
- **Analyse reproductible avec effect sizes** + sortie pandas → `pingouin`
- **Bayesian** → [[PyMC]] / [[ArviZ]] / NumPyro
- **ML predictif** → [[scikit-learn]]
- **Workflow R** : R est plus riche statistiquement pour certains domaines (mixed models, survival)

## Pièges connus

- **API inconsistante** : ancienne API (`stats.ttest_ind(a, b)`) vs nouvelle (`stats.ttest_ind(a, b, alternative='greater')`) — surveille les warnings
- **Pas d'effect sizes natifs** : pas de Cohen d, Hedges g built-in → calculer à la main ou utiliser pingouin
- **Documentation académique opaque** : formules denses, peu d'exemples pratiques
- **`stats.f_oneway` retourne juste F et p-val** : pas de table ANOVA, pas de post-hoc → statsmodels ou pingouin
- **Distributions `frozen` vs paramétrées** : `stats.norm(loc=0, scale=1)` vs `stats.norm.cdf(x, loc=0, scale=1)` — confus au début
- **`scale` paramètre pour exponentielle** : `stats.expon(scale=1/lam)`, pas `stats.expon(rate=lam)` (inverse de la convention courante)
- **Tests à grand N** : p-value devient ≈ 0 mécaniquement → reporter effect size aussi
- **Multiple comparisons** : pas de correction Bonferroni / FDR built-in → `statsmodels.stats.multitest.multipletests`
- **Tests assument continuity** : Chi² avec faibles effectifs (< 5) → Fisher exact à la place
- **`fit()` peut converger faussement** : initialiser les params si data exotique

## Code minimal

```python
from scipy import stats
import numpy as np

# t-test independants (alternative recente API)
a = np.random.normal(100, 15, 30)
b = np.random.normal(105, 15, 30)
t, p = stats.ttest_ind(a, b, alternative="two-sided", equal_var=False)
print(f"t={t:.3f}, p={p:.4f}")

# t-test paire
before = np.random.normal(100, 15, 30)
after = before + np.random.normal(5, 5, 30)
result = stats.ttest_rel(before, after)
print(result.statistic, result.pvalue, result.confidence_interval(0.95))
```

```python
# Distributions
from scipy import stats

# PDF / CDF / PPF
print(stats.norm.pdf(0))            # 0.398
print(stats.norm.cdf(1.96))         # 0.975
print(stats.norm.ppf(0.975))        # 1.96 (quantile)

# Sampling reproductible
rng = np.random.default_rng(42)
samples = stats.beta.rvs(2, 5, size=10_000, random_state=rng)

# Fit
alpha, beta_, loc, scale = stats.beta.fit(samples, floc=0, fscale=1)
print(alpha, beta_)   # ~2, ~5
```

```python
# Tests non-parametriques
stats.mannwhitneyu(a, b, alternative="two-sided")
stats.wilcoxon(before, after)
stats.kruskal(a, b, c)
stats.kstest(samples, "norm")           # Kolmogorov-Smirnov
stats.shapiro(a)                          # Normalite
```

```python
# Correlations
r, p = stats.pearsonr(x, y)
rho, p = stats.spearmanr(x, y)
tau, p = stats.kendalltau(x, y)
```

```python
# Bootstrap CI (SciPy 1.7+)
def stat(sample):
    return np.median(sample)

result = stats.bootstrap((data,), stat, n_resamples=10_000, confidence_level=0.95,
                         random_state=42)
print(result.confidence_interval)
```

```python
# ANOVA simple (1-way)
f_stat, p_val = stats.f_oneway(group_a, group_b, group_c)

# Chi-squared independance
contingency = np.array([[10, 20], [30, 40]])
chi2, p, dof, expected = stats.chi2_contingency(contingency)
```

## Liens

- statsmodels — alternative modeling complet
- pingouin — wrapper haut-niveau avec effect sizes pandas-friendly
- numpy.random — pour sampling pur sans tests
- R (base) — alternative historique riche
- [[Hypothesis testing]] / [[t-test and ANOVA]] / [[Chi-squared tests]] (concepts)
- Docs : https://docs.scipy.org/doc/scipy/reference/stats.html
- GitHub : https://github.com/scipy/scipy
