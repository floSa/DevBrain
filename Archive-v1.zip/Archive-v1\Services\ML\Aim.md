---
galaxie: dev
nom: Aim
alias: [aim, aimstack]
categorie: ml/tracking
sous_categories: [tracking, experiments, open-source, local, visualization]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python / TypeScript
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[MLflow]]", "[[Weights & Biases]]", "[[ClearML]]", "[[Comet]]", "[[Neptune]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, tracking, experiments, open-source]
url_officiel: https://aimstack.io/
url_docs: https://aimstack.readthedocs.io/
url_repo: https://github.com/aimhubio/aim
---

# Aim

## Pourquoi

Tracker d'expériences ML **open-source full local**. UI très rapide (web app React + storage local indexé), comparaison de runs interactive : explorer 1000+ runs sans lag, query via expressions Python-like (`run.hparams.lr > 0.001`).

Positionnement : **W&B-like 100% open-source self-hostable trivialement** (un seul `pip install aim` + `aim up`). Pas de cloud managed officiel, c'est le trade-off. Cible : ML perso, labs académiques, équipes qui ne veulent pas dépendre d'un SaaS payant ou pour qui les data ne peuvent pas sortir.

## Quand l'utiliser

- **ML perso / petit groupe** sans budget cloud
- **Open-source obligatoire** (licence Apache permissive)
- **Local-first** : pas d'upload data vers cloud, full on-prem
- **Visualisations rapides** : comparer 1000+ runs sans lag (vs MLflow UI qui rame)
- **Combo PyTorch / HuggingFace / Lightning** : intégrations natives propres
- **Distributed training** : agrège runs multi-node via SDK
- **Métriques granulaires** : tracking per-step très efficace (vs MLflow batch)
- **Self-host trivial** : `pip install aim && aim up` → dashboard live

## Quand NE PAS l'utiliser

- **Équipe grande, besoin SSO / RBAC** → [[Weights & Biases]] Enterprise / [[ClearML]] Server
- **Sweeps managed natifs** → [[Ray Tune]] / [[Optuna]] / W&B Sweeps (Aim track mais n'orchestre pas)
- **Combo Models registry intégré** → [[MLflow]] (Aim n'a pas de registry)
- **Cloud SaaS turn-key** → W&B / Comet / Neptune (Aim demande self-host)
- **Cross-team prod monitoring** → écosystème plus mature ailleurs

## Pièges connus

- **Pas de cloud managed officiel** : self-host obligatoire
- **Pas de Model Registry** : Aim track expériences uniquement, pas de versioning modèles
- **Écosystème intégrations moins riche** que MLflow / W&B (mais essentiels OK)
- **Pas de RBAC entreprise** : un Aim repo = un workspace, pas de permissions fine-grained
- **Storage local peut grossir** : `.aim` repo croît, prévoir nettoyage périodique
- **Multi-user concurrent** : possible mais pas pensé pour 50+ users simultanés
- **Pas d'agents managed** : pas de service "Aim Agent" comme W&B, à intégrer soi-même
- **Reports / dashboards partagés** moins puissants que W&B Reports
- **Migration vers/depuis MLflow** : tooling limité

## Code minimal

```bash
pip install aim
aim init          # cree un repo .aim/ dans le dossier courant
aim up            # lance le dashboard sur http://localhost:43800
```

```python
# Tracking PyTorch / scikit / generique
from aim import Run

run = Run(experiment="llama-finetune")
run["hparams"] = {"lr": 1e-4, "batch_size": 32, "model": "llama-3-8b"}

for step in range(1000):
    loss = train_step()
    run.track(loss, name="loss", step=step, context={"subset": "train"})
    if step % 100 == 0:
        val = eval_step()
        run.track(val, name="loss", step=step, context={"subset": "val"})

# Tags / notes
run.add_tag("baseline")
run["description"] = "Run de reference, dataset v3"
```

```python
# Integration Lightning
from aim.pytorch_lightning import AimLogger
import pytorch_lightning as pl

logger = AimLogger(experiment="my-exp", train_metric_prefix="train_")
trainer = pl.Trainer(logger=logger, max_epochs=10)
trainer.fit(model, datamodule)

# Query programmatique (depuis notebook)
from aim import Repo
repo = Repo(".")
for run in repo.query_runs("run.hparams.lr > 0.0001 and run.experiment == 'llama-finetune'"):
    print(run.hash, run["hparams"], run.get_metric("loss").values.last())
```

## Liens

- [[MLflow]] — alternative open-source plus complète (registry inclus)
- [[Weights & Biases]] — alternative SaaS managed plus riche
- [[ClearML]] — alternative open-source + pipelines + agents
- [[Comet]] / [[Neptune]] — alternatives SaaS
- [[Ray Tune]] / [[Optuna]] — pour les sweeps (Aim track les résultats)
- Docs : https://aimstack.readthedocs.io/
- GitHub : https://github.com/aimhubio/aim
