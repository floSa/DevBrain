---
galaxie: wiki
nom: Mixture of Experts (MoE)
alias: [MoE, sparse expert, Mixtral, DeepSeek MoE, expert routing]
type: concept
categorie: concept/transformers
sous_categories: [moe, sparse, expert, scaling]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Shazeer 2017, Fedus 2022 (Switch), Jiang 2024 (Mixtral)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, transformer, moe, llm, scaling]
---

# Mixture of Experts — MoE

## TL;DR

Architecture qui remplace le **FFN dense** d'un Transformer par **N "experts"** (chacun un FFN) + un **routeur** qui sélectionne les top-$k$ experts par token. Permet de **scaler les paramètres** sans scaler la **compute** : Llama 4, DeepSeek V3, Mixtral, GPT-4, Gemini sont tous MoE en 2026. Économie en inference de ~5-10x vs dense équivalent. **Défis** : routing, load balancing, communication all-to-all, infrastructure complexe. Standard pour modèles frontier 200B-1T+ params.

## Le problème

**Scaling laws** : ajouter des params améliore la perf, mais quadruple le compute. Comment **augmenter capacity** d'un modèle sans exploser le coût d'inference ?

Observation : la plupart des tokens n'ont **pas besoin** de l'expertise complète du modèle. Différents tokens nécessitent différents experts (code vs prose vs math).

## L'idée

### Architecture MoE de base

Remplacer le FFN dense par :

```
[Hidden state x] → [Router (linear)] → top-k experts
                                          ↓
                                [Expert 1] [Expert 2] ... [Expert N]
                                          ↓
                                  weighted sum → output
```

**Concrètement** :
- $N$ experts (typ. 8, 16, 32, 64) — chacun un MLP/SwiGLU complet
- **Router** : linear $\mathbb{R}^d \to \mathbb{R}^N$ + softmax → score par expert
- **Top-$k$ selection** : choisir les $k$ experts (typ. $k=2$) avec les plus hauts scores
- Output : combinaison pondérée des outputs des $k$ experts

### Active vs total parameters

- **Total params** : $N$ experts × params chacun
- **Active params** (par token) : $k$ experts × params chacun

Exemple Mixtral 8x7B :
- 8 experts × 7B params chacun
- Total : **47B params** (les attention layers sont partagées)
- Active per token : **13B params** (2 experts)
- → Inference comme un 13B, mais qualité plus proche d'un 47B dense

### Routing

#### Top-k routing (standard)

```python
def top_k_routing(x, W_router, k=2, n_experts=8):
    logits = x @ W_router  # (T, n_experts)
    scores = F.softmax(logits, dim=-1)
    top_k_scores, top_k_idx = scores.topk(k, dim=-1)
    # renormalize
    top_k_scores = top_k_scores / top_k_scores.sum(dim=-1, keepdim=True)
    return top_k_scores, top_k_idx
```

**Variants** :
- **Top-1** : Switch Transformer (Fedus 2022)
- **Top-2** : standard (Mixtral, Llama 4)
- **Expert Choice** : chaque expert choisit ses tokens (load-balanced naturellement)
- **Soft MoE** : pondération continue (pas hard top-k)

### Load balancing

Risque : un expert reçoit tous les tokens, autres jamais entraînés (collapse).

#### Auxiliary loss (Switch Transformer)

Ajouter une loss qui force la **distribution uniforme** des tokens :

$$ L_{aux} = N \sum_i f_i \cdot P_i $$

où $f_i$ = fraction de tokens routés vers expert $i$, $P_i$ = proba moyenne du routeur pour expert $i$.

#### Loss-free balancing (DeepSeek V3)

Ajuster les **biais** du routeur post-hoc pour équilibrer. Plus simple et performant.

#### Capacity factor

Limite : chaque expert peut traiter au max $c \cdot \frac{T \cdot k}{N}$ tokens (typ. $c = 1.0-1.25$). Tokens dépassant la capacity = **dropped** (skip experts, residual seul).

### Architecture choices

#### Fine-grained experts (DeepSeek)

Plus d'experts, chacun plus petit. Mixtral 8x7B → DeepSeek 256 experts × 700M chacun (avec partage).

- Plus de specialization
- Meilleure performance à compute équivalent

#### Shared experts (DeepSeek MoE)

Quelques experts **toujours actifs** (shared) + experts routés. Capture knowledge commune.

#### MoE layers vs dense layers

Pas nécessaire de transformer **toutes** les layers en MoE. Souvent : alterner dense et MoE.

### Inférence MoE — défis

#### Memory

Total params dans GPU mémoire (load tous les experts), même si seulement $k$ actifs par token.

→ MoE 400B params = ~800 GB en BF16 → besoin multi-GPU.

#### Expert parallelism

Distribuer les experts sur différents GPUs. Lors du routing : **all-to-all communication** pour envoyer chaque token au bon GPU.

- Latence bottleneck (interconnect)
- vLLM, SGLang implémentent ça nativement
- DeepSpeed-MoE, Megatron-MoE pour training

#### Batch effects

Avec un seul user (batch 1), seuls $k$ experts utilisés → reste du compute idle. **MoE optimal en serving multi-tenant.**

### Pretraining MoE

#### Stability

MoE moins stable que dense (router gradients tricky). Solutions :
- **Z-loss** : pénaliser logits du router pour éviter saturation
- **Router init** carefully
- **FP32 router** (pas BF16) pour stabilité

#### Sparse upcycling

Partir d'un modèle dense entraîné, "splitter" le FFN en $N$ copies, fine-tune en MoE. **Plus économique** que train MoE from scratch (Mixtral, Llama 4).

### Modèles MoE notables

| Modèle | Total | Active | k | N experts | Notes |
|---|---|---|---|---|---|
| GShard / Switch | varies | 1 (top-1) | 1 | up to 2048 | Google, 2021 |
| Mixtral 8x7B | 47B | 13B | 2 | 8 | Mistral, 2023 |
| Mixtral 8x22B | 141B | 39B | 2 | 8 | Mistral, 2024 |
| DeepSeek V2 | 236B | 21B | 6 | 160 + 2 shared | fine-grained |
| DeepSeek V3 | 671B | 37B | 8 | 256 + 1 shared | SOTA open |
| Llama 4 Scout | 109B | 17B | 1 | 16 | Meta, 2025 |
| Llama 4 Maverick | 400B | 17B | 1 | 128 | Meta, 2025 |
| Qwen3 MoE | 235B | 22B | 8 | 128 | Alibaba |
| GPT-4 (rumored) | ~1.7T | ~280B | 2 | ~16 | non-confirmé |

### Avantages

- **Scaling efficace** : ×N params, ×k FLOPs par token
- **Specialization** : experts spécialisés (math, code, langues)
- **Modular** : update / ajouter experts post-training
- **Compute-optimal scaling laws** différentes (Lepikhin, Hoffmann)

### Limites

- **Memory hog** : tout charger en RAM même si peu utilisé
- **Communication** : all-to-all en distributed expensive
- **Routing instability** : router peut collapse, drop tokens
- **Inferenced batch-size sensitive** : optimal seulement en multi-tenant
- **Fine-tuning** : harder à fine-tuner que dense (LoRA sur MoE non-trivial)
- **Quantization** : moins efficace que dense (experts différents)
- **Sparse upcycling biais** : tous les experts initialisés pareil → spécialisation lente

## Quand c'est utile

- **Frontier models** (200B+) : MoE standard pour balancer cost / quality
- **Serving multi-tenant** : batching naturel
- **Domain-specific routing** : experts spécialisés (code, math, langues)
- **Long horizon training** : capacity-rich, compute-budgeted
- **Open-source frontier** : DeepSeek, Mixtral, Llama 4 ouvrent la voie

## Quand ça ne marche pas / pièges

- **Small model (<10B)** : surcoût MoE (router, communication) pas justifié. Dense souvent meilleur.
- **Single-user inference** : batch 1, MoE pas plus rapide que dense équivalent active. Pire : load tous experts.
- **Low memory** : impossible de loader Mixtral 47B en 24GB. Mieux : Llama 8B dense.
- **Routing collapse** : sans load balancing, 1 expert mange tout. Monitor utilisation par expert.
- **Capacity overflow** : tokens dropped si batch déséquilibré. Tune capacity factor.
- **LoRA sur MoE** : naïf ne marche pas (un LoRA par expert ? un LoRA global ?). Research récente (X-LoRA, S-LoRA-MoE).
- **All-to-all bottleneck** : sur networks lents (cross-DC), MoE inférence diverge.
- **Numerical instability** : router en BF16 peut osciller. FP32 router stabilise.
- **Quantization** : GGUF Q4 sur MoE perd plus de qualité que sur dense équivalent.
- **Sparse upcycling** : experts trop similaires initial → spécialisation lente, sub-optimal vs train from scratch.

## Code minimal

```python
import torch
import torch.nn as nn
import torch.nn.functional as F

class MoELayer(nn.Module):
    def __init__(self, d_model, d_ff, n_experts=8, k=2):
        super().__init__()
        self.k = k
        self.n_experts = n_experts
        self.experts = nn.ModuleList([
            nn.Sequential(
                nn.Linear(d_model, d_ff, bias=False),
                nn.SiLU(),
                nn.Linear(d_ff, d_model, bias=False)
            ) for _ in range(n_experts)
        ])
        self.router = nn.Linear(d_model, n_experts, bias=False)
    
    def forward(self, x):
        # x: (B, T, d_model)
        B, T, d = x.shape
        x_flat = x.reshape(-1, d)  # (B*T, d)
        
        # Router
        router_logits = self.router(x_flat)  # (B*T, n_experts)
        router_probs = F.softmax(router_logits, dim=-1)
        
        # Top-k
        top_k_probs, top_k_idx = router_probs.topk(self.k, dim=-1)
        top_k_probs = top_k_probs / top_k_probs.sum(dim=-1, keepdim=True)
        
        # Dispatch to experts and combine
        out = torch.zeros_like(x_flat)
        for expert_idx in range(self.n_experts):
            # Find which tokens are routed to this expert (parmi le top-k)
            token_idx, k_idx = (top_k_idx == expert_idx).nonzero(as_tuple=True)
            if token_idx.numel() == 0:
                continue
            expert_out = self.experts[expert_idx](x_flat[token_idx])
            out[token_idx] += top_k_probs[token_idx, k_idx].unsqueeze(-1) * expert_out
        
        # Aux loss (load balancing)
        # f_i = fraction tokens routed to expert i
        # P_i = mean probability of router for expert i
        with torch.no_grad():
            f = (top_k_idx == torch.arange(self.n_experts, device=x.device).unsqueeze(0).unsqueeze(0))
            f = f.float().mean(dim=(0, 1))  # avg fraction per expert
        P = router_probs.mean(dim=0)
        aux_loss = self.n_experts * (f * P).sum()
        
        return out.reshape(B, T, d), aux_loss

# Usage
moe = MoELayer(d_model=512, d_ff=2048, n_experts=8, k=2)
x = torch.randn(2, 64, 512)
y, aux = moe(x)
print(f"Output shape: {y.shape}, aux loss: {aux.item():.3f}")

# Hugging Face : Mixtral, Llama 4, DeepSeek V3 en MoE
# from transformers import AutoModelForCausalLM
# model = AutoModelForCausalLM.from_pretrained("mistralai/Mixtral-8x7B-Instruct-v0.1",
#                                                torch_dtype=torch.bfloat16,
#                                                device_map="auto")

# vLLM serve MoE
# vllm serve mistralai/Mixtral-8x7B-Instruct-v0.1 \
#       --tensor-parallel-size 2 \
#       --enable-expert-parallel

# DeepSpeed-MoE pour training
# from deepspeed.moe.layer import MoE
# moe_layer = MoE(hidden_size=512, expert=expert_fn, num_experts=8, k=2)
```

## Pour aller plus loin

- Shazeer et al., *Outrageously Large Neural Networks: The Sparsely-Gated Mixture-of-Experts Layer* (ICLR 2017)
- Fedus, Zoph, Shazeer, *Switch Transformers: Scaling to Trillion Parameter Models with Simple and Efficient Sparsity* (JMLR 2022)
- Jiang et al., *Mixtral of Experts* (2024) — Mistral
- DeepSeek-AI, *DeepSeekMoE: Towards Ultimate Expert Specialization in Mixture-of-Experts Language Models* (2024)
- DeepSeek-AI, *DeepSeek-V3 Technical Report* (2024) — SOTA open MoE
- Komatsuzaki et al., *Sparse Upcycling: Training Mixture-of-Experts from Dense Checkpoints* (ICLR 2023)
- *vLLM*, *DeepSpeed-MoE* docs — serving / training
- **Liens internes** : [[Transformer architectures]], [[Self-attention]], [[Flash Attention and efficient attention]], [[Scaling laws]]
