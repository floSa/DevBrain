---
galaxie: dev
nom: Streamlit
alias: [streamlit]
categorie: ui/data-app
sous_categories: [data-app, dashboard, prototype, python-only]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Gradio]]", "[[Dash]]", "Panel", "Solara", "[[Shiny for Python]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ui, data-app, python, dashboard]
url_officiel: https://streamlit.io/
url_docs: https://docs.streamlit.io/
url_repo: https://github.com/streamlit/streamlit
---

# Streamlit

## Pourquoi
Framework Python pour transformer un script en app web interactive sans toucher au front. Re-run du script à chaque interaction, modèle mental simple, écosystème de composants riche. Le défaut pour data apps internes et dashboards.

## Quand l'utiliser
- Dashboard interne data / ML rapide
- POC pour montrer un modèle ML / une analyse
- Outil interne pour data scientists ou analystes
- App "lecture de données + filtres + viz"
- Quand seul Python est dispo dans l'équipe

## Quand NE PAS l'utiliser
- App user-facing avec UX exigeante → vrai framework front (Next.js, etc.)
- App très interactive avec state complexe → [[Gradio]] (pour ML demos), Dash, ou Solara
- Concurrence élevée → modèle "rerun script" devient coûteux, scaling vertical limité
- Auth / multi-tenancy sérieux → ajouter une couche (Streamlit-auth, ou Streamlit Cloud, ou proxy)

## Pièges connus
- **Re-run total à chaque interaction** : utiliser `@st.cache_data` et `@st.cache_resource` agressivement
- **`session_state`** : compréhension nécessaire dès qu'on dépasse "afficher des données"
- **Multipage apps** : structure `pages/` un peu rigide, navigation custom limitée
- **Theming** : limité avant 1.x, mieux maintenant (themes via TOML)
- **Long-running tasks** : pas adapté nativement, utiliser threads + `st.empty` ou jobs externes
- **Performance** : pas pour 1000+ utilisateurs simultanés sur la même instance

## Liens
- [[Gradio]] — alternative orientée ML demos
- Streamlit Cloud (hosting gratuit) : https://streamlit.io/cloud
- Composants tiers : https://streamlit.io/components
- Cheatsheet : https://docs.streamlit.io/develop/quick-reference/cheat-sheet
