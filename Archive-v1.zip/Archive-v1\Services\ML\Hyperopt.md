---
galaxie: dev
nom: Hyperopt
alias: [hyperopt]
categorie: ml/hp-tuning
sous_categories: [hyperparameter, bayesian, tpe, search, legacy]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 2
mes_projets: []
alternatives: ["[[Optuna]]", "[[Ray Tune]]", "scikit-optimize", "Nevergrad"]
remplace: []
remplace_par: ["[[Optuna]]"]
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, hyperparameter, tuning, legacy]
url_officiel: http://hyperopt.github.io/hyperopt/
url_docs: http://hyperopt.github.io/hyperopt/
url_repo: https://github.com/hyperopt/hyperopt
---

# Hyperopt

## Pourquoi

Bibliothèque **historique** d'hyperparameter optimization Python (depuis 2011). Algorithme phare : **TPE** (Tree-structured Parzen Estimator), un Bayesian optimization adapté aux espaces conditionnels (e.g. `if optimizer == "adam": lr ~ uniform`).

Aujourd'hui **largement supplantée par [[Optuna]]** : UX meilleure, dashboard intégré, pruning natif, define-by-run API. Hyperopt reste référencée pour deux raisons : code legacy qui l'utilise (notamment via **HyperoptEstimator** sklearn-like), et MLflow propose une intégration native `hyperopt + SparkTrials` pour la search distribuée sur Spark.

## Quand l'utiliser

- **Code legacy** qui l'utilise déjà — ne pas migrer pour le plaisir
- **TPE spécifique** : algorithme phare (mais Optuna a aussi TPE, et mieux exposé)
- **Combo MLflow + Spark** : `SparkTrials` permet de paralléliser la search sur cluster Spark
- **Intégration historique avec Databricks** : tutoriels et exemples documentés
- **HyperoptEstimator** : pipeline sklearn auto-tuné avec hpsklearn

## Quand NE PAS l'utiliser

- **Nouveau projet** → [[Optuna]] (UX, pruning, dashboard, intégrations toutes meilleures)
- **Distributed massif** → [[Ray Tune]] (ASHA, BOHB, plus scalable)
- **Sweeps W&B / Comet / Neptune** : utiliser leurs orchestrateurs natifs
- **Multi-objective** : Optuna le fait propre, Hyperopt mal
- **Pruning / early stopping** : Hyperopt n'a pas de pruning natif

## Pièges connus

- **Maintenance modeste** : releases rares vs Optuna très actif (2024-2026)
- **API moins Pythonic** : `hp.choice`, `hp.uniform` syntax verbeuse
- **Pruning / early stopping pas natif** : faut le coder à la main
- **Visualisation pauvre** : pas de dashboard, juste matplotlib custom
- **Espace de recherche figé** : pas de define-by-run comme Optuna
- **MongoDB pour distributed** (sans Spark) : storage backend MongoDB historique, lourd
- **Erreurs cryptiques** : tracebacks pas toujours actionables
- **fmin retourne dict d'indices** pour `hp.choice` (pas les valeurs) → piège classique
- **Pas de multi-objective natif** : il faut combiner manuellement en scalar

## Code minimal

```bash
pip install hyperopt
```

```python
from hyperopt import fmin, tpe, hp, Trials, STATUS_OK
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score

# Definition de l'espace de recherche
space = {
    "n_estimators": hp.choice("n_estimators", [50, 100, 200, 500]),
    "max_depth": hp.quniform("max_depth", 3, 20, 1),
    "min_samples_split": hp.uniform("min_samples_split", 0.01, 0.5),
    "criterion": hp.choice("criterion", ["gini", "entropy"]),
}

def objective(params):
    params["max_depth"] = int(params["max_depth"])
    clf = RandomForestClassifier(**params, n_jobs=-1, random_state=42)
    score = cross_val_score(clf, X, y, cv=5, scoring="accuracy").mean()
    return {"loss": -score, "status": STATUS_OK}

trials = Trials()
best = fmin(
    fn=objective,
    space=space,
    algo=tpe.suggest,
    max_evals=100,
    trials=trials,
    rstate=__import__("numpy").random.default_rng(42),
)
print(best)   # dict avec indices hp.choice, pas les valeurs directes
```

```python
# Distributed via Spark (Databricks)
from hyperopt import SparkTrials

spark_trials = SparkTrials(parallelism=4)
best = fmin(
    fn=objective, space=space, algo=tpe.suggest,
    max_evals=100, trials=spark_trials,
)
```

## Liens

- [[Optuna]] — alternative moderne **recommandée** (Hyperopt est en mode maintenance)
- [[Ray Tune]] — alternative distributed massif
- scikit-optimize / Nevergrad — autres alternatives historiques
- [[MLflow]] — combo SparkTrials documenté
- Docs : http://hyperopt.github.io/hyperopt/
- GitHub : https://github.com/hyperopt/hyperopt
