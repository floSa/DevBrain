---
galaxie: dev
type: pattern
contexte: app LLM Q&A sur corpus interne (docs, support tickets, codebase), volumétrie petite à moyenne (<10M chunks)
created: 2026-05-19
modified: 2026-05-19
services_cles: ["[[Anthropic Claude API]]", "[[Postgres]]", "[[LangChain]]", "[[LlamaIndex]]"]
projets_appliques: []
tags: [pattern, rag, llm, retrieval, ai-eng]
---

# Pattern — RAG basique

## Contexte

Tu veux **un système Q&A grounded sur tes propres documents** (docs internes, base de connaissances, ticketing, codebase). Stack moderne 2026, déployable sans monter une infra vectorielle dédiée, qui marche bien jusqu'à ~10M chunks. Cas typique : MVP d'un assistant sur la doc produit, search amélioré dans un wiki, support augmenté.

Si tu as **>10M chunks ou des contraintes latence < 100ms**, passe à une vector DB dédiée (Qdrant, Weaviate) et un re-ranker dédié.

## Stack

- **Ingestion / orchestration** : [[LlamaIndex]] (focalisé ingestion) ou [[LangChain]] (plus généraliste)
- **Embeddings** : Voyage AI `voyage-large-2` ou OpenAI `text-embedding-3-small` (équilibre coût/perf)
- **Vector DB** : [[Postgres]] + extension `pgvector` (suffit jusqu'à ~10M vecteurs)
- **LLM génération** : [[Anthropic Claude API]] (avec [[prompt-caching|prompt caching]] obligatoire sur le système prompt)
- **Structured output** : [[Instructor]] pour forcer le format de la réponse (avec citations)
- **Eval** : [[Ragas]] + [[TruLens]] pour mesurer faithfulness/answer relevancy
- **Monitoring** : [[Phoenix Arize]] ou trace via OpenTelemetry

## Structure de projet

```
my-rag/
├── pyproject.toml
├── README.md
├── docker-compose.yml          # PG + pgvector + app
├── src/
│   └── myrag/
│       ├── ingest/
│       │   ├── loaders.py       # PDF/MD/HTML → Document
│       │   ├── chunker.py       # Document → Chunks (semantic-aware)
│       │   └── pipeline.py      # orchestration ingestion
│       ├── index/
│       │   ├── embedder.py      # batch embed via API
│       │   └── store.py         # interface pgvector
│       ├── retrieve/
│       │   ├── retriever.py     # query → top-k chunks (hybrid : vector + BM25)
│       │   └── rerank.py        # cross-encoder re-rank (optionnel mais utile)
│       ├── generate/
│       │   ├── prompts.py       # système, few-shot, format réponse
│       │   └── llm.py           # wrapper Anthropic + cache
│       ├── eval/
│       │   ├── dataset.py       # gold Q/A pour eval
│       │   └── metrics.py       # faithfulness, answer relevance
│       └── api.py               # FastAPI endpoint /ask
└── tests/
```

## Décisions clés

### 1. Chunking sémantique, pas naïf

```python
# ❌ Naïf — coupe au milieu d'une idée
chunks = [text[i:i+500] for i in range(0, len(text), 400)]  # overlap 100

# ✅ Sémantique — respecte les frontières (paragraphe, section, code block)
from llama_index.core.node_parser import SemanticSplitterNodeParser
parser = SemanticSplitterNodeParser(buffer_size=1, breakpoint_percentile_threshold=95)
chunks = parser.get_nodes_from_documents(docs)
```

### 2. Embeddings : batch + cache

- Embed en batch de 100-500 à la fois (rate-limit + coût)
- Cache local par hash du chunk — si le chunk n'a pas changé, pas de re-embed

### 3. Hybrid search (vector + BM25)

Toujours hybrider. Vector seul rate les requêtes avec mots-clés exacts (numéros de version, noms propres, codes erreur).

```python
# pgvector + BM25 combinés via Reciprocal Rank Fusion
vector_hits = await vector_search(query_embed, k=20)
keyword_hits = await bm25_search(query, k=20)
fused = rrf(vector_hits, keyword_hits, k=10)
```

### 4. Re-ranking (si la qualité prime sur la latence)

Cross-encoder (Cohere Rerank, Voyage, ou local `bge-reranker`) sur les top-20 → garde les top-5. Ajoute 50-200ms mais double souvent la pertinence.

### 5. Prompt caching sur le système prompt

Le système prompt + few-shot exemples = stable. Le contexte récupéré + question = variables. **Marque la coupure** pour bénéficier du cache Anthropic :

```python
messages = [
    {"role": "user", "content": [
        {"type": "text", "text": SYSTEM_PROMPT + FEW_SHOTS, "cache_control": {"type": "ephemeral"}},
        {"type": "text", "text": f"Contexte:\n{retrieved_chunks}\n\nQuestion: {question}"},
    ]}
]
```

Voir [[prompt-caching|Prompt Caching]].

### 6. Structured output avec citations

Force la réponse à inclure les sources, via [[Instructor]] :

```python
class Answer(BaseModel):
    response: str
    citations: list[Citation]
    confidence: Literal["high", "medium", "low"]

class Citation(BaseModel):
    chunk_id: str
    quote: str
```

Si `confidence == "low"`, renvoie "je ne sais pas" plutôt que d'inventer.

### 7. Eval dès le premier sprint

Constitue un **gold dataset** de 30-100 Q/A représentatives **avant** de toucher au tuning. Sinon tu optimises à l'aveugle.

Métriques minimum :
- **Faithfulness** : la réponse est-elle basée sur le contexte récupéré ? (anti-hallucination)
- **Answer relevance** : la réponse répond-elle vraiment à la question ?
- **Context precision** : les chunks récupérés sont-ils tous utiles ?

## Pièges (récurrents)

- **Chunking par caractères vs tokens** : 500 caractères c'est ~125 tokens. Si ton modèle embedding limite à 512 tokens, prévoir.
- **Re-embed silencieux** lors d'un upgrade modèle → tous les vecteurs deviennent incompatibles. Tagger la version d'embedding dans le schéma.
- **Top-k trop grand qui sature le contexte LLM** — un Claude Sonnet a 200k tokens mais ça ne veut pas dire qu'on doit les remplir. Plus de contexte != meilleure réponse.
- **"It works on my queries"** — tester sur 5 questions ce n'est pas un eval. Constitue un dataset.
- **Citations bidons** — le LLM peut citer des chunks qui n'existent pas dans le retrieved. Valide les `chunk_id` côté code.

## Voir aussi

- Concept : [[RAG]], [[embeddings]], [[prompt-caching|Prompt Caching]]
- Services : [[LangChain]], [[LlamaIndex]], [[Postgres]], [[Anthropic Claude API]], [[Instructor]]
- Eval : [[Ragas]], [[TruLens]], [[Phoenix Arize]]
- Workflow associé : [[Bootstrap projet AI eng]]
