---
galaxie: dev
nom: HuggingFace
alias: [hf, huggingface, transformers, datasets, hub]
categorie: ml/framework
sous_categories: [transformers, datasets, hub, peft, accelerate, ecosystem]
licence: Apache-2.0 (libs)
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python, ts, rust]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[PyTorch]]", "[[TensorFlow]]", "[[OpenAI API]]", "[[Anthropic Claude API]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ml, framework, llm, transformers, ecosystem]
url_officiel: https://huggingface.co/
url_docs: https://huggingface.co/docs
url_repo: https://github.com/huggingface
---

# HuggingFace

## Pourquoi
Écosystème complet du ML moderne : **Transformers** (lib pour modèles open-weight), **Datasets** (lib + hub de datasets), **Hub** (registry de modèles/datasets/spaces), **PEFT** (fine-tuning paramètre-efficace : LoRA, etc.), **Accelerate** (multi-GPU/multi-node), **TRL** (RLHF, DPO). Le centre de gravité du ML open-source.

## Quand l'utiliser
- Charger / fine-tuner n'importe quel modèle open-weight (Llama, Qwen, Mistral, BERT…)
- Dataset standard ou custom (`load_dataset(...)`)
- Pousser un modèle sur le Hub (privé ou public)
- Demos rapides via [[Gradio]] + Hub Spaces
- Multi-GPU training avec Accelerate (sans réécrire en DDP brut)
- Fine-tuning paramètre-efficace (LoRA / QLoRA via PEFT)
- RLHF / DPO via TRL

## Quand NE PAS l'utiliser
- Tu veux juste consommer une API LLM cloud → [[Anthropic Claude API]] / [[OpenAI API]]
- Production serving haute charge → packager avec [[vLLM]] / [[Ray Serve]] / [[NVIDIA Triton]]
- Modèles très custom non-Transformer → [[PyTorch]] direct

## Sous-libs principales

| Lib | Usage |
|-----|-------|
| `transformers` | Charger/utiliser/fine-tuner des modèles |
| `datasets` | Datasets streaming, mapping, format Arrow |
| `tokenizers` | Tokenization rapide (Rust) |
| `accelerate` | Multi-GPU/TPU sans boilerplate |
| `peft` | LoRA, AdaLoRA, prefix tuning |
| `trl` | RLHF, DPO, SFTTrainer |
| `evaluate` | Métriques standardisées |
| `safetensors` | Format sûr pour les weights (vs pickle) |

## Pièges connus
- **Téléchargements lourds** : modèles 7B+ pèsent ~14GB+, prévoir disque + cache (`HF_HOME`)
- **`use_safetensors=True`** : préférer aux .bin pickle (sécurité)
- **`device_map="auto"`** : pratique mais peut surprendre, vérifier la répartition
- **Tokenizer ≠ modèle** : checkpoints distincts, à matcher (mêmes vocab/added_tokens)
- **Versions** : `transformers` bouge vite, pinner pour reproductibilité
- **Auth Hub** : token nécessaire pour modèles gated (Llama, etc.) — `huggingface-cli login`
- **Datasets streaming** : `streaming=True` pour gros datasets, sinon download complet

## Liens
- [[PyTorch]] — backend principal
- [[vLLM]] / [[Ollama]] / [[llama.cpp]] — pour servir les modèles HF en prod
- [[Gradio]] — pour les Spaces
- Hub : https://huggingface.co/models
- Course gratuit : https://huggingface.co/learn/nlp-course
