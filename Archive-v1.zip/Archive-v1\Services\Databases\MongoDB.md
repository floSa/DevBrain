---
galaxie: dev
nom: MongoDB
alias: [mongo, mongodb]
categorie: database/document
sous_categories: [document, nosql, json, bson]
licence: SSPL
licence_type: source-available
hosted: both
maturite: production
langage: C++
clients_officiels: [python, ts, go, rust, java, dotnet, php, ruby]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Postgres]]", "CouchDB", "Firestore", "DynamoDB"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, database, document, nosql]
url_officiel: https://www.mongodb.com/
url_docs: https://www.mongodb.com/docs/
url_repo: https://github.com/mongodb/mongo
---

# MongoDB

## Pourquoi
Base orientée **documents JSON/BSON**. Schéma flexible, scaling horizontal (sharding), aggregation pipeline puissante, MongoDB Atlas pour le managed. Standard de fait du NoSQL document.

## Quand l'utiliser
- Schéma qui évolue beaucoup (early-stage, prototypage)
- Données naturellement hiérarchiques (JSON imbriqué profond)
- Charge en écriture massive avec sharding
- Quand on n'a pas besoin de joins complexes / transactions multi-documents fréquentes

## Quand NE PAS l'utiliser
- Données fortement relationnelles avec joins → [[Postgres]] (qui fait aussi du JSON via JSONB et reste relationnel)
- Très petit projet → [[SQLite]]
- Compliance / licences strictes → la SSPL exclut certains usages cloud
- Quand "JSON dans Postgres" suffit → c'est très souvent le cas

## Pièges connus
- **Licence SSPL** : pas OSI-approved, contraintes pour offrir du SaaS basé sur MongoDB → c'est ce qui a poussé l'industrie vers AWS DocumentDB ou Postgres+JSONB
- **Transactions multi-documents** : disponibles depuis 4.0 mais coûteuses
- **Shard key choice** : critique, irréversible facilement, mauvais choix = hot spot
- **Aggregation pipeline** : puissant mais courbe d'apprentissage forte
- **Atlas pricing** : peut grimper vite, monitorer
- **Schema-less ≠ no schema** : il faut un schéma logique discipliné (validateurs, ODM type Beanie/Mongoose)

## Liens
- [[Postgres]] avec JSONB — alternative très souvent suffisante
- Atlas (managed) : https://www.mongodb.com/atlas
- Beanie (ODM Python async) : https://github.com/roman-right/beanie
- Mongoose (ODM Node) : https://mongoosejs.com/
