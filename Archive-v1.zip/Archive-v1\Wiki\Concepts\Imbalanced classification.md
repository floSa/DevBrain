---
galaxie: wiki
nom: Imbalanced classification
alias: [SMOTE, class weight, undersampling, oversampling, rare class]
type: concept
categorie: concept/ml
sous_categories: [imbalanced, classification, sampling, ml]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Chawla et al. 2002 (SMOTE), He-Garcia 2009]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, classification, imbalanced]
---

# Imbalanced classification

## TL;DR

Quand une classe est **fortement minoritaire** (fraud 0.1%, churn 5%, cancer 1%, defects 0.5%), les classifieurs standards apprennent à prédire la majoritaire et "réussissent" en accuracy mais sont **inutiles**. Solutions : **resampling** (oversampling minoritaire — SMOTE, ADASYN ; undersampling majoritaire — Tomek, random), **class weights** (cost-sensitive learning), **threshold tuning** (déplacer le seuil de décision), **ensemble methods** (EasyEnsemble, BalancedRandomForest), **anomaly detection** (one-class si très extrême). **Toujours évaluer avec [[Classification metrics]] adaptées** : F1/Recall/PR AUC/MCC, **pas accuracy**.

## Le problème

Distribution typique : 99% classe 0, 1% classe 1. Un modèle "tout prédire 0" obtient 99% accuracy. Mais :
- Recall classe 1 = 0% → modèle inutile
- Coût FN >> coût FP (médical, fraud) → catastrophique

Comment **forcer** le modèle à apprendre la minorité ?

## L'idée

### 1. Sampling

#### Oversampling (augmenter minorité)

**Random oversampling** : dupliquer des exemples minoritaires. Simple mais risque d'overfit (mémoriser).

**SMOTE** (Synthetic Minority Over-sampling, Chawla 2002) :
- Pour chaque exemple minoritaire $x_i$, trouver $k$ voisins minoritaires
- Synthétiser nouveaux exemples = $x_i + \lambda (x_j - x_i)$, $\lambda \in [0, 1]$, $x_j$ voisin
- Crée des points "entre" les minoritaires → étend la frontière de décision

Variants :
- **SMOTE-NC** : pour features catégorielles
- **BorderlineSMOTE** : focus sur les exemples près de la frontière
- **ADASYN** : oversample plus là où c'est difficile à classer

**Limitation** : génère du bruit si minorité contient outliers. **Pas pour images / texte** brut.

#### Undersampling (réduire majorité)

**Random undersampling** : jeter des exemples majoritaires aléatoirement. Perd info.

**Tomek links** : enlever les exemples majoritaires en bordure de classe.

**NearMiss** : garder les exemples majoritaires proches de la minorité.

**ClusterCentroids** : remplacer les majoritaires par leurs centroïdes (k-means).

**Limitation** : ne fonctionne pas sur petits datasets.

#### Combiné : SMOTE + Tomek

Oversampling SMOTE puis nettoyage Tomek pour réduire bruit. Standard.

### 2. Class weighting (cost-sensitive)

Au lieu de re-sampler, **pénaliser plus fortement** les erreurs sur la minorité dans la loss :

$$ L = \sum_i w_i \cdot \ell(y_i, \hat y_i), \quad w_i = \begin{cases} w_+ & \text{si } y_i = 1 \\ w_- & \text{si } y_i = 0 \end{cases} $$

Choix simple : $w_+ = n_- / n_+$ (inverse fréquence).

Standard dans sklearn (`class_weight='balanced'`), LightGBM (`scale_pos_weight`), XGBoost.

**Avantage** : pas de modification de la data, juste de la loss. Calibration meilleure que SMOTE.

### 3. Threshold tuning

Modèle prédit proba $\hat p$, décision $\hat y = \mathbb{1}[\hat p > t]$. Par défaut $t = 0.5$. Pour minorité, **abaisser le seuil**.

Optimiser $t$ pour maximiser F1, ou minimiser coût pondéré :

$$ t^* = \arg\min_t [c_{FP} \cdot FP(t) + c_{FN} \cdot FN(t)] $$

**Souvent suffisant** sans resampling : un modèle bien entraîné a juste besoin du bon seuil.

### 4. Ensemble methods

**Balanced Random Forest** : chaque arbre entraîné sur un undersampling random équilibré → vote.

**EasyEnsemble** : ensemble de classifieurs sur différents undersamplings.

**BalancedBaggingClassifier** : bagging + undersampling à chaque réplicat.

Standard dans `imbalanced-learn`.

### 5. Anomaly detection (cas extrême)

Quand minorité < 0.1% : trop peu pour classifier. Utiliser **one-class** :
- **Isolation Forest**
- **One-Class SVM**
- **LOF** (Local Outlier Factor)
- **Autoencoder** + reconstruction error

Modélise "ce qui est normal" et détecte l'anormal.

### 6. Cost-sensitive learning

Construire la **matrice de coûts** explicitement :

| | Prédit 0 | Prédit 1 |
|---|---|---|
| Réel 0 | 0 | $c_{FP}$ |
| Réel 1 | $c_{FN}$ | 0 |

Optimiser l'**espérance de coût** plutôt que l'accuracy. Plus principielle que les heuristiques de resampling.

### Évaluation — métriques obligatoires

**Pas accuracy** sur déséquilibré. Utiliser (voir [[Classification metrics]]) :
- **PR AUC (Average Precision)** : meilleur que ROC AUC en très déséquilibré
- **F1** ou **F-beta** (β > 1 si recall > precision important)
- **MCC** : robuste single-number
- **Confusion matrix** par classe
- **Recall@k precision** : selon coût asymétrique

**Stratified split** obligatoire : `train_test_split(stratify=y)`, `StratifiedKFold`.

### Pipeline typique

```
[Raw data]
   ↓
[Train/test split STRATIFIED]
   ↓
[Compute class_weight or sampling strategy]
   ↓
[Train model with weights / on resampled train]
   ↓
[Predict probabilities on test]
   ↓
[Tune threshold on validation]
   ↓
[Final evaluation: PR AUC + F1 + MCC + matrice de coûts]
```

### Best practices

1. **Évaluer d'abord** sans intervention : un modèle moderne (LightGBM, XGBoost) avec `scale_pos_weight` peut suffire
2. **Class weights >> SMOTE souvent** : moins de bruit, mieux calibré
3. **Threshold tuning** avant resampling : souvent c'est le seul problème
4. **Stratified split + CV** : non-négociable
5. **Évaluer en PR AUC + F1**, pas accuracy
6. **SMOTE seulement sur train**, jamais sur test (sinon leakage et eval inflated)
7. **Pour produits / fraud / médical** : matrice de coût explicite
8. **Données tabulaires** : SMOTE OK. **Images / texte** : SMOTE inutile, utiliser augmentation domain-specific (rotation, crop) ou class weights
9. **Calibration** : SMOTE casse la calibration → re-calibrer post-hoc ([[Calibration]])

## Quand c'est utile

- **Fraud detection** : 0.01-1% fraudes
- **Médical** : maladie rare, diagnostic
- **Churn prediction** : 5-10% churners
- **Defect detection** : manufacturing
- **Network intrusion** : attaques rares
- **Recommendation cold start** : items rarement vus
- **Marketing response** : conversion < 5%
- **Compliance / risk** : violations

## Quand ça ne marche pas / pièges

- **Accuracy reporting** : red flag immédiat. Toujours PR AUC + F1 sur déséquilibré.
- **SMOTE sur test set** : data leakage massif. SMOTE seulement train.
- **SMOTE casse la calibration** : probas après SMOTE ne reflètent plus la base rate. Re-calibrer ou utiliser class_weight.
- **Sur-resampler** : oversampling 1:1 peut faire perdre l'info de difficulté. Cible souvent 1:3 ou 1:5, pas 1:1.
- **Bias adversariel** : SMOTE en credit / hiring → peut introduire / amplifier biais sur sous-groupes. Auditer fairness.
- **SMOTE en haute dim** : curse of dimensionality, voisins peu significatifs. Moins efficace que sur low-dim.
- **SMOTE images / texte** : interpolation ne fait pas sens. Utiliser augmentation domain (rotation, paraphrasing).
- **Threshold optimisé sur test** : leakage. Optimiser sur validation séparée.
- **Évaluer sans matrice de coût** : F1 ≠ coût business. Toujours mapper aux coûts réels.
- **Class weight sans tune** : "balanced" sklearn est inverse fréquence. Souvent un ratio custom (e.g. weight=10 pas inverse 100) est meilleur. CV pour tuner.
- **Anomaly detection sur déséquilibre modéré** : OC-SVM overkill si tu as 1% (suffisant pour superv classif). Réserver pour < 0.1%.

## Code minimal

```python
import numpy as np
import pandas as pd
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report, average_precision_score, f1_score, matthews_corrcoef
)

# Dataset déséquilibré
X, y = make_classification(n_samples=10000, n_features=20, weights=[0.95, 0.05],
                            class_sep=0.5, random_state=0)
print(f"Classes: {np.bincount(y)}, ratio = {(y == 1).mean():.3f}")

# Split stratifié
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, stratify=y, random_state=0)

# 1. Baseline sans rien
clf = LogisticRegression(max_iter=1000).fit(X_train, y_train)
p_test = clf.predict_proba(X_test)[:, 1]
print(f"--- Baseline ---")
print(f"PR AUC = {average_precision_score(y_test, p_test):.3f}")
print(f"F1     = {f1_score(y_test, clf.predict(X_test)):.3f}")
print(f"MCC    = {matthews_corrcoef(y_test, clf.predict(X_test)):.3f}")

# 2. Class weights
clf_w = LogisticRegression(max_iter=1000, class_weight='balanced').fit(X_train, y_train)
p_test_w = clf_w.predict_proba(X_test)[:, 1]
print(f"--- Class weights ---")
print(f"PR AUC = {average_precision_score(y_test, p_test_w):.3f}")
print(f"F1     = {f1_score(y_test, clf_w.predict(X_test)):.3f}")

# 3. SMOTE
from imblearn.over_sampling import SMOTE
sm = SMOTE(random_state=0)
X_smote, y_smote = sm.fit_resample(X_train, y_train)
print(f"After SMOTE: {np.bincount(y_smote)}")
clf_sm = LogisticRegression(max_iter=1000).fit(X_smote, y_smote)
print(f"--- SMOTE ---")
print(f"PR AUC = {average_precision_score(y_test, clf_sm.predict_proba(X_test)[:, 1]):.3f}")

# 4. SMOTE + Tomek
from imblearn.combine import SMOTETomek
smt = SMOTETomek(random_state=0)
X_smt, y_smt = smt.fit_resample(X_train, y_train)

# 5. BalancedRandomForest
from imblearn.ensemble import BalancedRandomForestClassifier
brf = BalancedRandomForestClassifier(random_state=0).fit(X_train, y_train)
print(f"--- BalancedRandomForest ---")
print(f"PR AUC = {average_precision_score(y_test, brf.predict_proba(X_test)[:, 1]):.3f}")

# 6. Threshold tuning (sur validation)
from sklearn.metrics import precision_recall_curve
precision, recall, thresholds = precision_recall_curve(y_test, p_test)
f1_scores = 2 * precision * recall / (precision + recall + 1e-9)
best_threshold = thresholds[np.argmax(f1_scores[:-1])]
y_pred_optim = (p_test > best_threshold).astype(int)
print(f"Best threshold = {best_threshold:.3f}, F1 = {f1_score(y_test, y_pred_optim):.3f}")

# 7. LightGBM avec scale_pos_weight
from lightgbm import LGBMClassifier
scale = (y_train == 0).sum() / (y_train == 1).sum()
lgbm = LGBMClassifier(scale_pos_weight=scale, n_estimators=200, verbose=-1)
lgbm.fit(X_train, y_train)
print(f"--- LightGBM scale_pos_weight ---")
print(f"PR AUC = {average_precision_score(y_test, lgbm.predict_proba(X_test)[:, 1]):.3f}")

# 8. Pipeline correct (SMOTE intégré pour CV)
from imblearn.pipeline import Pipeline as ImbPipeline
from sklearn.model_selection import cross_val_score
pipe = ImbPipeline([('smote', SMOTE()), ('clf', LogisticRegression(max_iter=1000))])
scores = cross_val_score(pipe, X, y, cv=StratifiedKFold(5), scoring='average_precision')
print(f"CV PR AUC avec pipeline SMOTE: {scores.mean():.3f} +/- {scores.std():.3f}")
# CRITICAL: SMOTE dans le pipeline -> appliqué seulement sur train fold de chaque CV split
```

## Pour aller plus loin

- He & Garcia, *Learning from Imbalanced Data* (TKDE 2009) — référence
- Chawla, Bowyer, Hall, Kegelmeyer, *SMOTE: Synthetic Minority Over-sampling Technique* (JAIR 2002)
- *imbalanced-learn* documentation (intégrée sklearn API)
- Krawczyk, *Learning from imbalanced data: open challenges and future directions* (Prog AI 2016)
- Lemaître, Nogueira, Aridas, *Imbalanced-learn paper* (JMLR 2017)
- **Liens internes** : [[Classification metrics]], [[Calibration]], [[Cross-validation]], [[ROC AUC]], [[Feature engineering]]
