---
galaxie: dev
nom: TensorRT-LLM
alias: [tensorrt-llm, trt-llm]
categorie: llm/inference
sous_categories: [inference, nvidia, tensorrt, optimization, fp8]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python + C++/CUDA
clients_officiels: [python, triton-backend, openai-compat]
plateforme: [linux]
score: 4
mes_projets: []
alternatives: ["[[vLLM]]", "[[SGLang]]", "[[TGI]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, inference, nvidia, optimization]
url_officiel: https://github.com/NVIDIA/TensorRT-LLM
url_docs: https://nvidia.github.io/TensorRT-LLM/
url_repo: https://github.com/NVIDIA/TensorRT-LLM
---

# TensorRT-LLM

## Pourquoi

Backend NVIDIA pour **LLM serving optimisé hardware** (H100 / H200 / B200 / GH200). Compile chaque modèle en **TensorRT engine** spécifique au GPU cible → meilleure **latence (TTFT)** et **throughput** que vLLM / SGLang sur GPU NVIDIA récents, surtout avec quantization **FP8** (E4M3 / E5M2) ou **INT4**.

Combo standard : **NVIDIA Triton Inference Server + TensorRT-LLM backend** = stack production NVIDIA-natif. Si tu vis sur du H100/H200/B200, c'est ce qu'on te recommandera.

## Quand l'utiliser

- **Infra NVIDIA récent** (H100 / H200 / B200) avec besoin perf maximale
- **Latence critique** : TTFT minimum, batching optimisé
- **Quantization FP8** native (E4M3) sur H100+ → 2x throughput vs BF16
- **Quantization INT4 (AWQ + W4A16)** native, plus rapide que vLLM AWQ
- **Combo [[NVIDIA Triton]]** Inference Server (multi-modèle, multi-framework hosting)
- **Enterprise NVIDIA AI Enterprise** subscription (support, SLA)
- **Speculative decoding** (Medusa, Eagle) bien intégré

## Quand NE PAS l'utiliser

- **Pas de NVIDIA récent** (Ampere / Hopper / Blackwell) → [[vLLM]] / [[SGLang]] portent mieux
- **Multi-vendor / portable** → vLLM cross-hardware
- **Setup rapide / dev** → vLLM ou Ollama 10x plus simple
- **Modèles très exotiques** → couverture TensorRT-LLM < vLLM
- **AMD MI300 / Intel Gaudi** : pas supporté
- **Apple Silicon** : non-NVIDIA

## Pièges connus

- **Setup très complexe** : compile **engines** spécifiques au GPU cible. Recompile à chaque changement (modèle, batch size, GPU, version TensorRT-LLM). Pipeline build long (minutes-heures).
- **Lock-in NVIDIA hardware** : engines TRT non-portables entre architectures GPU
- **Versions matérielles + CUDA + TensorRT + TensorRT-LLM + driver** à matcher strictement → galère de compatibility
- **Models supportés < vLLM** : check le model zoo avant
- **Documentation dense** mais examples-driven, courbe d'apprentissage
- **Compile errors cryptiques** : erreurs internes TensorRT pas toujours actionables
- **Multi-LoRA** : supporté mais setup spécifique vs vLLM plug-and-play
- **Backend Triton** : ajoute une couche (mais nécessaire pour multi-modèle hosting)

## Code minimal

```bash
# Lancer via Triton + TensorRT-LLM backend (recommandé)
# 1. Build engine
docker run --rm --gpus all -v $PWD:/workspace \
    nvcr.io/nvidia/tritonserver:24.10-trtllm-python-py3 \
    /bin/bash -c "trtllm-build \
        --checkpoint_dir /workspace/llama-3-8b-checkpoint \
        --output_dir /workspace/engines/llama-3-8b \
        --gpt_attention_plugin float16 \
        --gemm_plugin float16 \
        --max_input_len 4096 \
        --max_seq_len 8192"

# 2. Servir
docker run --gpus all -p 8000:8000 -p 8001:8001 \
    -v $PWD/engines:/engines \
    nvcr.io/nvidia/tritonserver:24.10-trtllm-python-py3 \
    tritonserver --model-repository=/models

# Ou via TensorRT-LLM standalone OpenAI-compat
python -m tensorrt_llm.serve --model_dir engines/llama-3-8b --port 8000
```

```python
# Client OpenAI-compat
from openai import OpenAI
client = OpenAI(base_url="http://localhost:8000/v1", api_key="EMPTY")

response = client.chat.completions.create(
    model="llama-3-8b",
    messages=[{"role": "user", "content": "Hello"}],
)
print(response.choices[0].message.content)

# Quantization FP8 (H100+)
# trtllm-build --use_fp8 --... → engine FP8
# Throughput ~2x BF16 sur Llama 3 70B
```

## Liens

- [[vLLM]] / [[SGLang]] — alt portables
- [[NVIDIA Triton]] — combo recommandé pour multi-modèle
- [[TGI]] — alt HuggingFace
- [[Quantization]] (concept, FP8 / INT4)
- [[Inference optimization]] (concept)
- Docs : https://nvidia.github.io/TensorRT-LLM/
- GitHub : https://github.com/NVIDIA/TensorRT-LLM
- Models supportés : https://nvidia.github.io/TensorRT-LLM/llm-api/index.html
