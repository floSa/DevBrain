---
galaxie: dev
nom: JAX
alias: [jax]
categorie: ml/dl-framework
sous_categories: [autodiff, jit, xla, tpu, scientific]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python (XLA backend)
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[PyTorch]]", "[[TensorFlow]]", numpy + autograd]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, autodiff, jax, google]
url_officiel: https://jax.readthedocs.io/
url_docs: https://jax.readthedocs.io/en/latest/
url_repo: https://github.com/jax-ml/jax
---

# JAX

## Pourquoi
Numpy-like avec **autograd + JIT XLA + vmap + pmap**. Fonctionnel pur (immuable). Le framework de référence de Google DeepMind : Gemini, AlphaFold, Flamingo. Excellent pour **scientific ML, simulation différentiable, training TPU**. Pas une drop-in remplacement PyTorch — paradigme différent (fonctionnel).

## Quand l'utiliser
- Recherche ML avec besoins XLA / TPU
- Scientific computing différentiable (physique, biologie)
- Modèles custom avec autograd composable
- Stack Google (Gemini, Flax, Haiku)
- Performance: JIT donne souvent meilleures perfs que PyTorch eager
- Reinforcement Learning (vmap/pmap pour vectoriser environnements)

## Quand NE PAS l'utiliser
- LLM moderne avec écosystème HuggingFace → [[PyTorch]] standard
- Code impératif / state mutable → JAX functional est dur à debug
- Mobile / edge → ExecuTorch / TFLite
- Production serving simple → ONNX / TF Serving / vLLM

## Pièges connus
- **Pure functions** : pas de side effects dans `jit` — print, random sans key, etc. → erreurs cryptiques
- **PRNG keys** : pas d'état global, passer `key` explicitement (split avec `jax.random.split`)
- **Tracing** : `jit` retrace si shapes changent, lent au premier call
- **PyTrees** : structure de données nested, comprendre `tree_map`
- **Devices** : `jax.devices()` détecte GPU/TPU automatiquement, sinon CPU
- **GPU support** : `pip install -U "jax[cuda12]"` (versions précises)
- **vs Flax/Haiku/Equinox** : choisir UNE lib NN par-dessus JAX

## Liens
- Flax (NN Google) : https://flax.readthedocs.io/
- Haiku (NN DeepMind) : https://dm-haiku.readthedocs.io/
- Equinox (NN, le plus Pythonic) : https://docs.kidger.site/equinox/
- Optax (optimizers) : https://optax.readthedocs.io/
- Docs JAX : https://jax.readthedocs.io/en/latest/
