---
galaxie: dev
type: moc
created: 2026-05-01
modified: 2026-05-01
tags: [moc, rules, documentation]
up: "[[CLAUDE-build]]"
---

# Index — Rules/Documentation/

> Standards de documentation à appliquer dans **chaque projet** qui intègre les services correspondants. Ces règles sont chargées par Claude en mode PROJET (cf. `CLAUDE-project.md`) et appliquées à la phase 2 (squelette) puis complétées en phase 3 (implémentation) et auditées en phase 4 (tests + docs).

## Règle racine

- [[README - Service]] — règle générale : tout service intégré a un README dédié

## Niveau projet

- [[Project-README]] — sections obligatoires du README racine
- [[Config-Env]] — Pydantic Settings + `.env.example`
- [[Tests]] — unitaires + intégration (testcontainers) + eval LLM

## Par type de service

| Type de service | Règle | Template README |
|-----------------|-------|-----------------|
| Base de données relationnelle | [[Database-Relational]] | `Templates/ServiceDocs/README - database-relational.md` |
| Base vectorielle | [[Database-Vector]] | `Templates/ServiceDocs/README - database-vector.md` |
| Base graphe | [[Database-Graph]] | `Templates/ServiceDocs/README - database-graph.md` |
| Stockage objet | [[Storage-Object]] | `Templates/ServiceDocs/README - storage-object.md` |
| Orchestrateur de données | [[Orchestration-Data]] | `Templates/ServiceDocs/README - orchestration-data.md` |
| Orchestration LLM | [[LLM-Orchestration]] | `Templates/ServiceDocs/README - llm-orchestration.md` |
| Traitement de documents | [[Document-Processing]] | `Templates/ServiceDocs/README - document-processing.md` |
| Service générique (autre) | [[README - Service]] | `Templates/ServiceDocs/README - generic.md` |

## Comment l'agent les utilise (mode PROJET)

1. À chaque service intégré dans le projet, Claude :
   - Identifie le **type** de service (depuis sa fiche `Services/`)
   - Charge la **règle** correspondante (`Rules/Documentation/<type>.md`)
   - Génère le `services/<nom>/README.md` depuis le **template** approprié
   - Pré-remplit ce qu'il sait, marque `<À REMPLIR>` ce qui doit être complété par toi
2. Skill dédié : **`doc-service`** automatise tout ça.
3. Audit à faire en phase 4 : *"Pour chaque service du projet, vérifie que le README respecte la règle MUST"*.

## Skills associés

- `doc-service` (génère + audit la doc d'un service intégré)
- `add-service` (création d'une fiche dans le brain — usage en mode BUILD, pas projet)

## Voir aussi

- [[../CLAUDE-build]] section "Conventions Rules"
- [[../CLAUDE-project]] section "Phases du projet"
