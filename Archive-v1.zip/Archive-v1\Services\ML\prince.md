---
galaxie: dev
nom: prince
alias: [prince-py]
categorie: tooling/stats
sous_categories: [factor-analysis, pca, mca, ca, famd, mfa, gpa]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[fanalysis]]", "scikit-learn (PCA only)", "FactoMineR (R)"]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: en-eval
tags: [service, stats, factor-analysis, python]
url_officiel: https://github.com/MaxHalford/prince
url_docs: https://github.com/MaxHalford/prince
url_repo: https://github.com/MaxHalford/prince
---

# prince

## Pourquoi

Bibliothèque Python qui couvre la **gamme française des analyses factorielles** (PCA, CA, MCA, MFA, FAMD, GPA) avec une API pandas-friendly. C'est l'équivalent Python le plus complet de `FactoMineR` (R). Sortie de Max Halford (Tournesol, Cookiecutter Data Science).

## Quand l'utiliser

- Faire une [[PCA]], [[CA]], [[MCA]], [[FAMD]], [[MFA]], [[GPA]] sans repasser à R
- Tu veux des diagnostics riches (cos², contributions, modalités supplémentaires, individus illustratifs)
- Tu manipules un DataFrame pandas et veux des sorties pandas

## Quand NE PAS l'utiliser

- PCA très simple sur une matrice numpy → `sklearn.decomposition.PCA` suffit
- Pour les comparatifs détaillés avec la littérature française → reste sur R / FactoMineR
- Si tu veux du PCA sparse/probabilistic → utilise scikit-learn ou des libs spécialisées

## Pièges connus

- API a évolué (versions ≥ 0.10) — vérifie ta version, certains exemples Stack Overflow datent
- Performance moyenne sur les gros datasets (>100k lignes) → préférer scikit-learn ou implé custom
- Moins de diagnostics que FactoMineR (R) — ex. tests de significativité, intervalles bootstrap

## Liens

- Repo : https://github.com/MaxHalford/prince
- Concepts : [[PCA]], [[CA]], [[MCA]], [[FAMD]], [[MFA]], [[GPA]]
- Alternative : [[fanalysis]]
