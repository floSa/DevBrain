---
galaxie: wiki
nom: Video generation
alias: [Sora, Veo, Runway, Pika, Kling, video diffusion, T2V]
type: concept
categorie: concept/multimodal
sous_categories: [video-gen, t2v, diffusion, multimodal]
domaines: [ai-eng]
maturite: emerging
auteurs_cles: [Brooks 2024 (Sora)]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, multimodal, video-generation, diffusion]
---

# Video generation

## TL;DR

Génération vidéo depuis texte / image. Extensions de [[Diffusion models]] sur la dimension temporelle. **Closed leaders 2026** : **Sora 2** (OpenAI), **Veo 3** (Google), **Runway Gen-4**, **Kling 2** (Kuaishou), **Luma Ray 2**, **Pika 2**. **Open** : **HunyuanVideo** (Tencent), **CogVideoX**, **Mochi** (Genmo), **LTX-Video**, **Stable Video Diffusion** (Stability), **Wan 2** (Alibaba), **AnimateDiff** (image→video). Tasks : **text-to-video**, **image-to-video**, **video-to-video**, **lipsync**, **motion control**, **first-last frame conditioning**. Limitation actuelle : courte durée (5-60s), cohérence temporelle, coût.

## Le problème

Generate video → bien plus complexe qu'image :
- **Dimension temporelle** : cohérence frame-to-frame
- **Motion realistic** : physique, gravité
- **Coût** : 5-60s × 24-30 fps = beaucoup de frames
- **Tokens explosion** : un video = 100k+ visual tokens

## L'idée

### Architectures

#### Temporal diffusion (extensions de SD)

UNet 2D → UNet 3D (avec dimension temporelle). Standard Stable Video Diffusion, AnimateDiff.

#### DiT pour video

Diffusion Transformer adapté à video. **Standard moderne** : Sora, Veo, HunyuanVideo.

- Patches spatio-temporels (e.g. 1×16×16 ou 4×16×16 = "tubelets")
- Attention sur dim temporelle + spatiale

#### Architecture latente

Comme Latent Diffusion : VAE 3D compresse video → latent space, diffusion sur latents.

### Modèles 2026

#### Closed-source

| Modèle | Caractéristiques |
|---|---|
| **Sora 2** (OpenAI) | 60s+, physics, character consistency |
| **Veo 3** (Google) | High-res, native audio |
| **Runway Gen-4** | Camera control, motion brush |
| **Kling 2** (Kuaishou) | Long form, lipsync |
| **Luma Ray 2 / Dream Machine** | Image-to-video strong |
| **Pika 2** | Effects, motion |
| **Hailuo** (MiniMax) | Chinese, accessible |

#### Open-source

| Modèle | Notes |
|---|---|
| **HunyuanVideo** | Tencent 2024, open, 13B |
| **CogVideoX** | Tsinghua, multiple sizes |
| **Mochi** (Genmo) | Open, 5s, 720p |
| **LTX-Video** | Lightricks, fast |
| **Stable Video Diffusion** (SVD) | Stability |
| **Wan 2** (Alibaba) | Multi-modal |
| **AnimateDiff** | Image→Video, LoRA-based |

### Techniques de control

#### Text-to-video

Standard. Prompt → video.

#### Image-to-video

Single image → motion. Standard pour photos → cinemagraph.

#### Video-to-video

Restyle existant video.

#### First-last frame conditioning

Provide start + end frame, model interpole.

#### Motion control

- **Motion brush** (Runway) : peindre direction motion
- **Camera control** : pan, zoom, dolly
- **Pose control** : OpenPose-style pour characters

#### Lipsync

Audio → mouth movement. Specialized models : Wav2Lip, LatentSync, MuseTalk.

### Durée et résolution

| Modèle | Max durée | Résolution |
|---|---|---|
| Sora 2 | 60s+ | 1080p |
| Veo 3 | 60s+ | 1080p (4K some?) |
| Runway Gen-4 | 16s | 1080p |
| Kling | 10s | 720p-1080p |
| HunyuanVideo | 5s | 720p |
| CogVideoX | 6s | 720p |
| SVD | 4s | 576×1024 |

Loi générale : court + low-res en 2024 → plus long + 1080p+ en 2025-2026.

### Évaluation

Benchmarks :
- **VBench** : multi-aspect (motion, consistency, etc.)
- **EvalCrafter** : objective + subjective

Métriques :
- **FVD** (Fréchet Video Distance)
- **CLIP-score** sur frames
- Human eval (gold standard)

### Coût

Massive :
- Sora 60s ~$20-50 / clip (API)
- HunyuanVideo self-host : 5s ~5 min sur H100
- Inference video reste cher

### Workflow production

```
1. Génér image initiale (SD/FLUX) → contrôle aesthetic
2. Image-to-video (SVD, Runway, Kling)
3. Edit / refine (motion brush, prompts)
4. Upscale (Topaz, Real-ESRGAN)
5. Audio (separate : TTS, music gen)
6. Lipsync si needed (Wav2Lip, etc.)
7. Final edit dans video editor traditionnel
```

### Best practices

1. **Use closed for quality** : Sora/Veo/Runway pour pro work
2. **HunyuanVideo / CogVideoX** pour open, custom training
3. **Image-to-video > text-to-video** : plus de control
4. **Court clips** (3-5s) puis assembler
5. **Camera control** spec : pan, zoom, dolly precisely
6. **Character consistency** : challenging, use seed + LoRA
7. **Audio separate** : génér audio (Suno, ElevenLabs) puis combine
8. **Costs** : un projet 1min = 50+ clips → planifier budget

## Quand c'est utile

- **Marketing** : product showcase, ads
- **Social media** : short-form content
- **Concept videos** : pre-production cinema
- **Education** : illustrative animations
- **Architecture / design** : visualization
- **Personal art** : creative exploration
- **Game cinematic** : pre-rendered
- **Music videos** : visualisations

## Quand ça ne marche pas / pièges

- **Long durée** : cohérence breaks > 10s
- **Character consistency** : person change face frame-to-frame
- **Physics violations** : objects float, weird collisions
- **Hands / fingers** : same issue que images
- **Text in video** : sauf Veo 3, garbage
- **Complex compositional** : "A throws ball to B" hard
- **Specific motion** : "John walks then sits" → harder
- **Cost** : 10x image gen
- **Slow generation** : 5-30 min / clip self-host
- **Copyrights** : data legal grey
- **Watermarks** : modèles can reproduce watermarks training
- **Lipsync misalignment** : surtout open models

## Code minimal

```python
# 1. HunyuanVideo (open via Diffusers)
from diffusers import HunyuanVideoPipeline
import torch

pipe = HunyuanVideoPipeline.from_pretrained(
    "tencent/HunyuanVideo",
    torch_dtype=torch.bfloat16
).to("cuda")

video = pipe(
    prompt="A cinematic shot of a red dragon flying over mountains",
    num_frames=49,  # ~2 sec at 24 fps
    height=720,
    width=1280,
    num_inference_steps=50
).frames[0]

from diffusers.utils import export_to_video
export_to_video(video, "output.mp4", fps=24)

# 2. CogVideoX
from diffusers import CogVideoXPipeline
pipe = CogVideoXPipeline.from_pretrained("THUDM/CogVideoX-5b",
                                          torch_dtype=torch.bfloat16).to("cuda")
video = pipe(prompt="A cat jumping...", num_inference_steps=50, num_frames=49).frames[0]

# 3. Stable Video Diffusion (image-to-video)
from diffusers import StableVideoDiffusionPipeline
pipe = StableVideoDiffusionPipeline.from_pretrained(
    "stabilityai/stable-video-diffusion-img2vid-xt",
    torch_dtype=torch.float16, variant="fp16"
).to("cuda")

from PIL import Image
image = Image.open("input.png")
frames = pipe(image, decode_chunk_size=8, generator=torch.Generator("cuda").manual_seed(42),
              num_frames=25, motion_bucket_id=180).frames[0]
export_to_video(frames, "svd_output.mp4", fps=7)

# 4. Sora API (lorsque disponible)
# from openai import OpenAI
# client = OpenAI()
# response = client.videos.generate(model="sora-1", prompt="...", duration_seconds=10)

# 5. Runway API
# import runwayml
# client = runwayml.Client()
# response = client.image_to_video.create(prompt_image="image_url",
#                                          prompt_text="movement description",
#                                          duration=10)

# 6. Kling, Luma (similar APIs)

# 7. AnimateDiff (image→video via Diffusers)
from diffusers import AnimateDiffPipeline, MotionAdapter
adapter = MotionAdapter.from_pretrained("guoyww/animatediff-motion-adapter-v1-5-2")
pipe = AnimateDiffPipeline.from_pretrained("emilianJR/epiCRealism", motion_adapter=adapter,
                                            torch_dtype=torch.float16).to("cuda")
output = pipe(prompt="A bear playing guitar", num_frames=16, guidance_scale=7.5,
              num_inference_steps=25)
frames = output.frames[0]

# 8. Lipsync (Wav2Lip)
# python inference.py --checkpoint_path checkpoints/wav2lip.pth \
#                      --face video.mp4 --audio voice.wav --outfile result.mp4

# 9. Upscale video output
# Topaz Video AI (commercial)
# Real-ESRGAN-video, RIFE (frame interpolation)
```

## Pour aller plus loin

- Brooks et al., *Video generation models as world simulators* (Sora technical report, OpenAI 2024)
- Google Veo team blog
- Yang et al., *CogVideoX: Text-to-Video Diffusion Models with An Expert Transformer* (2024)
- Kong et al., *HunyuanVideo: A Systematic Framework For Large Video Generative Models* (Tencent 2024)
- Blattmann et al., *Stable Video Diffusion* (2023)
- Guo et al., *AnimateDiff* (ICLR 2024)
- *Diffusers* video pipelines docs
- *VBench*, *EvalCrafter* benchmarks
- **Liens internes** : [[Diffusion models]], [[Image generation]], [[Speech models]] (audio combinaison)
