---
galaxie: dev
nom: MLflow
alias: [mlflow]
categorie: ml/tracking
sous_categories: [tracking, registry, artifacts, projects, deployment]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python, java, r, rest]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Weights & Biases]]", "[[Neptune]]", "[[ClearML]]", "[[Comet]]", "[[Aim]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ml, tracking, mlops]
url_officiel: https://mlflow.org/
url_docs: https://mlflow.org/docs/latest/index.html
url_repo: https://github.com/mlflow/mlflow
---

# MLflow

## Pourquoi
Plateforme open-source de **MLOps** : tracking d'expériences, model registry, packaging (MLflow Projects), serving (MLflow Models). Self-hostable. Le défaut quand tu veux la stack ML logging sans lock-in propriétaire.

## Quand l'utiliser
- Tracker des expériences ML (params, metrics, artifacts)
- Model registry pour versionner et promouvoir des modèles (Staging → Production)
- Reproductibilité (logger les Conda env / pip freeze ensemble)
- Pipeline ML self-hosted (vs SaaS [[Weights & Biases]] / [[Neptune]])
- Intégration native avec [[Dagster]], [[scikit-learn]], [[PyTorch]], [[XGBoost]], [[LangChain]] (depuis 2.x)

## Quand NE PAS l'utiliser
- UX et collaboration sociale prioritaires → [[Weights & Biases]] est plus poussé
- Très petite équipe / projet → un fichier YAML / SQLite suffit
- Besoin de monitoring drift en prod sérieux → solutions dédiées (Evidently, Arize)

## Pièges connus
- **Tracking server** : SQLite OK pour solo, [[Postgres]] requis pour équipe / prod
- **Artifacts storage** : par défaut local, à pointer sur [[MinIO]] / S3 pour prod
- **Auth** : pas de RBAC fin natif (besoin proxy ou Databricks managé)
- **`mlflow.autolog()`** : magique mais peut tracker trop de choses, vérifier
- **Model Registry stages** : "Staging/Production" est le pattern legacy, "aliases" plus flexible (depuis 2.x)
- **MLflow 3** (récent) : majeurs changements, lire la migration

## Liens
- [[Weights & Biases]] — alternative SaaS
- [[Dagster]] — orchestration ML compatible
- [[Postgres]], [[MinIO]] — backends typiques pour production
- Tracking quickstart : https://mlflow.org/docs/latest/getting-started/intro-quickstart/
- Model Registry : https://mlflow.org/docs/latest/model-registry.html
