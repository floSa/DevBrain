---
galaxie: dev
nom: Docling
alias: [docling]
categorie: data/parsing
sous_categories: [pdf, document-parsing, ocr, layout, ibm]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python, cli]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Unstructured]]", "[[LlamaParse]]", "[[PyMuPDF]]", "[[pdfplumber]]", "[[Marker]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, data, parsing, pdf, ibm, document]
url_officiel: https://docling-project.github.io/docling/
url_docs: https://docling-project.github.io/docling/
url_repo: https://github.com/docling-project/docling
---

# Docling

## Pourquoi
**Parser de documents** open-source par IBM (devenu projet LF AI). Convertit PDF, DOCX, PPTX, HTML, images vers Markdown / JSON / formats RAG-ready. Gère **layout, tables, formules, images** avec modèles ML embarqués. Le concurrent open-source sérieux à [[LlamaParse]] / [[Unstructured]] payants.

## Quand l'utiliser
- Pipeline RAG avec PDFs lourds (techniques, scientifiques, contrats)
- Extraction de tableaux structurés depuis PDFs
- OCR sur scans (Tesseract intégré, ou modèles dédiés)
- Self-hosted (pas de coût API, pas de fuite data)
- Intégration LangChain/LlamaIndex (loaders officiels)

## Quand NE PAS l'utiliser
- PDFs purement textuels triviaux → [[PyMuPDF]] / [[pdfplumber]] suffit, plus léger
- Volume gigantesque avec budget cloud → [[LlamaParse]] managé peut être plus simple
- Latence critique en temps réel → modèles ML embarqués ont un coût d'inférence
- Pas de GPU et grand volume → CPU OK mais lent

## Pièges connus
- **Modèles à télécharger** : première utilisation = download lourd (à mettre en cache CI)
- **GPU vs CPU** : performance très différente, dimensionner
- **Tables complexes** : améliorations continues mais imparfait sur tables fusionnées / multipages
- **Mathematical content** : extraction LaTeX possible mais à valider
- **Releases rapides** : à pinner pour stabilité
- **Memory footprint** : modèles + libs gourmands, dimensionner les workers

## Liens
- [[Unstructured]], [[LlamaParse]] — alternatives commerciales
- [[LlamaIndex]] — DoclingReader intégré
- [[LangChain]] — DoclingLoader intégré
- Tutoriel : https://docling-project.github.io/docling/usage/
- Models hub : https://huggingface.co/ds4sd
