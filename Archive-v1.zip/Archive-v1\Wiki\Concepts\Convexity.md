---
galaxie: wiki
nom: Convexity
alias: [convexité, fonction convexe, ensemble convexe, KKT, dualité]
type: concept
categorie: concept/optimization
sous_categories: [convexity, convex-function, kkt, duality, lagrangian]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Karush 1939, Kuhn-Tucker 1951]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, optimization, convexity, kkt, duality]
---

# Convexity — convexité

## TL;DR

Propriété **magique** d'une fonction $f$ : tout minimum local est global, le gradient suffit pour optimiser parfaitement. Quand $f$ est convexe, **les algos de descente trouvent l'optimum global**. Beaucoup de problèmes ML classiques (régression linéaire, logistique, SVM, Lasso) sont convexes — c'est pourquoi ils ont des "bons" solveurs. Le deep learning est **non-convexe** — d'où sa difficulté théorique.

## Le problème

En optimisation, on minimise $f(\theta)$. La question fondamentale : **est-ce qu'un minimum local trouvé est le minimum global ?**

- **Convexe** : oui toujours. Vie facile.
- **Non-convexe** : non en général. Beaucoup de minima locaux possibles. Garanties de convergence faibles.

Identifier la convexité d'un problème change radicalement la stratégie.

## L'idée

### Ensemble convexe

Un ensemble $C$ est convexe si :

$$ \forall x, y \in C, \, \forall \alpha \in [0, 1]: \quad \alpha x + (1-\alpha) y \in C $$

Intuitif : "le segment entre 2 points de $C$ reste dans $C$". Exemples : boules Lp, demi-espaces, intersections, polyèdres.

### Fonction convexe

$f : C \to \mathbb{R}$ est convexe si pour tout $x, y \in C$ et $\alpha \in [0, 1]$ :

$$ f(\alpha x + (1-\alpha) y) \leq \alpha f(x) + (1-\alpha) f(y) $$

Géométrie : la corde entre 2 points de la courbe est **au-dessus** de la courbe.

**Strictement convexe** : inégalité stricte (sauf $x = y$). Garantit unicité du minimum.

**Concave** : $-f$ convexe.

### Caractérisations

Pour $f$ deux fois différentiable :
- $f$ convexe ⇔ $\nabla^2 f(x) \succeq 0$ (Hessien SDP) partout
- $f$ strictement convexe ⇔ $\nabla^2 f(x) \succ 0$ (Hessien DP)

Pour $f$ une fois différentiable :
- $f$ convexe ⇔ $f(y) \geq f(x) + \nabla f(x)^\top (y - x)$ (tangentes en-dessous de la courbe)

### Conséquences pour l'optimisation

Si $f$ est convexe :
1. Tout minimum local **est** global
2. $\nabla f(\theta^*) = 0$ ⇔ $\theta^*$ est un minimum global (condition nécessaire et suffisante)
3. [[Gradient descent]] converge vers le minimum global (avec LR raisonnable)
4. Les bornes de convergence sont bien meilleures :
   - Convexe + L-smooth : convergence $O(1/t)$
   - Strongly convex + L-smooth : convergence linéaire $O(\rho^t)$

### Opérations qui préservent la convexité

- Somme : $f, g$ convexes ⇒ $f + g$ convexe
- Multiplication par scalaire positif
- Max ponctuel : $\max(f, g)$ convexe
- Composition avec affine : $f(Ax + b)$ convexe si $f$ convexe
- Restriction : $f|_C$ convexe sur $C$ convexe

**Pas préservée** : produit, composition générale, min ponctuel.

### Exemples de fonctions convexes courantes

| Fonction | Domaine | Convexe ? |
|---|---|---|
| $x^2$ | $\mathbb{R}$ | strictement convexe |
| $e^x$ | $\mathbb{R}$ | strictement convexe |
| $-\log x$ | $\mathbb{R}_{>0}$ | strictement convexe |
| $\|x\|_p$ ($p \geq 1$) | $\mathbb{R}^n$ | convexe |
| max | $\mathbb{R}^n$ | convexe |
| min | $\mathbb{R}^n$ | concave |

### Modèles ML convexes

- **Régression linéaire OLS** : MSE est quadratique → strictement convexe
- **Ridge regression** : MSE + L2 → strictement convexe
- **Lasso** : MSE + L1 → convexe (pas strictement, mais avec contraintes)
- **Régression logistique** : NLL convexe
- **SVM** : hinge loss + L2 → convexe
- **MaxEnt** : convexe

### Modèles ML non-convexes

- **Tout réseau de neurones non-linéaire** : non-convexe par construction
- **K-means** : non-convexe (minima locaux selon init)
- **GMM via EM** : non-convexe
- **PCA via NN** : non-convexe (mais admet beaucoup de minima globaux équivalents)

### Conditions d'optimalité KKT (avec contraintes)

Pour problème :

$$ \min f(x) \quad \text{s.c.} \quad g_i(x) \leq 0, \, h_j(x) = 0 $$

Le **Lagrangien** :

$$ \mathcal{L}(x, \lambda, \mu) = f(x) + \sum_i \lambda_i g_i(x) + \sum_j \mu_j h_j(x) $$

**Conditions KKT** au point optimal $x^*$ :
1. **Stationnarité** : $\nabla_x \mathcal{L}(x^*) = 0$
2. **Faisabilité primale** : $g_i(x^*) \leq 0$, $h_j(x^*) = 0$
3. **Faisabilité duale** : $\lambda_i \geq 0$
4. **Complementary slackness** : $\lambda_i g_i(x^*) = 0$ pour tout $i$

Pour $f$ convexe et contraintes convexes, KKT est nécessaire **et** suffisante.

### Dualité

Le problème **dual** :

$$ \max_{\lambda \geq 0} \, g(\lambda) = \max_{\lambda} \inf_x \mathcal{L}(x, \lambda) $$

Propriété :
- **Faible dualité** : $\sup g \leq \inf f$ toujours
- **Forte dualité** : $\sup g = \inf f$ sous conditions (Slater, en convexe)

Utile pour :
- **SVM dual** : transformer le problème primal en dual pour faciliter avec kernels
- **Algorithmes de descente duale** : ADMM, Frank-Wolfe

## Quand c'est utile

- **Identifier qu'un problème est convexe** : tu sais que les solveurs trouveront l'optimum global → confiance dans le résultat
- **Régression / SVM / Lasso** : utiliser solveurs spécialisés (scipy, cvxpy, sklearn) qui exploitent la structure convexe
- **Bornes théoriques** sur la convergence (utile en publi, audit ML)
- **Reformulation convexe** d'un problème non-convexe (relaxations) : rang faible via norme nucléaire, sparsity via L1, etc.

## Quand ça ne marche pas / pièges

- **Deep learning est non-convexe** — résultats empiriques excellents malgré ça (loss landscape est "bénigne" sur des architectures sur-paramétrées)
- **Confusion concave/convexe** : maximiser une fonction concave = minimiser une convexe. Vérifier le sens.
- **Régression logistique L2** : convexe ✓. Mais si on rajoute une couche cachée non-linéaire ? Non-convexe.
- **K-means / EM** : sensibles à l'initialisation (minima locaux). Toujours plusieurs `n_init`.
- **Slater's condition** pour la dualité forte : ne s'applique pas en non-convexe.
- **"Local minima" en DL** : la plupart sont en fait des saddle points dans les NN modernes (cf. [[Loss landscape and saddle points]]).

## Code minimal

```python
import numpy as np
import cvxpy as cp

# Problème convexe avec cvxpy
n = 50
A = np.random.randn(100, n)
b = np.random.randn(100)

x = cp.Variable(n)
loss = cp.sum_squares(A @ x - b)  # convexe (quadratique)
constraints = [cp.norm(x, 1) <= 5]  # L1 ball — contrainte convexe

problem = cp.Problem(cp.Minimize(loss), constraints)
problem.solve()
print(f"Optimal value: {problem.value}")
print(f"Optimal x[:5]: {x.value[:5]}")

# Vérifier la convexité d'une fonction (test simple par échantillonnage)
def is_convex_empirical(f, x_range, n_samples=100):
    xs = np.random.uniform(*x_range, n_samples)
    ys = np.random.uniform(*x_range, n_samples)
    alphas = np.random.uniform(0, 1, n_samples)
    for x, y, a in zip(xs, ys, alphas):
        lhs = f(a * x + (1 - a) * y)
        rhs = a * f(x) + (1 - a) * f(y)
        if lhs > rhs + 1e-6:
            return False
    return True

print(is_convex_empirical(lambda x: x**2, (-5, 5)))  # True
print(is_convex_empirical(lambda x: x**3, (-5, 5)))  # False (concave-convexe)
```

## Pour aller plus loin

- Boyd & Vandenberghe, *Convex Optimization* (2004) — bible, gratuit en ligne
- Bertsekas, *Nonlinear Programming* (3e éd.) — référence académique
- *Convex Optimization* (Stanford CVX-101) — cours gratuit
- **Liens internes** : [[Gradient descent]], [[Newton & quasi-Newton]], [[Regularization]] (Ridge/Lasso convexes), [[Loss landscape and saddle points]]
