---
galaxie: dev
nom: Pattern - CLI Python distribuable
type: pattern
created: 2026-05-20
modified: 2026-05-20
tags: [pattern, python, cli, distribution]
---

# Pattern — CLI Python distribuable

> Construire un outil CLI Python que tu peux distribuer via `pip install`, `pipx`, ou même `uv tool install` sans friction.

## Contexte

Tu veux livrer un outil CLI :
- Installable en 1 commande (`pip install foo` → `foo --help` marche)
- Cross-platform (Linux / macOS / Windows)
- Pas de "compile from source"
- Argparse propre, completion shell idéalement

## Stack recommandée

| Brique | Choix | Pourquoi |
|---|---|---|
| **Argparser** | [Typer](https://typer.tiangolo.com/) ou [Click](https://click.palletsprojects.com/) | Typer = types + autocomplete shell ; Click = mature, plus de plugins |
| **Packaging** | `pyproject.toml` (PEP 621) | standard moderne |
| **Build** | `hatchling` ou `flit` | léger, no setup.py |
| **Distribution** | PyPI + `pipx` ou `[[uv]] tool` | install isolé |
| **Linting** | `[[Ruff]]` | rapide |
| **Tests** | `[[pytest]]` | standard |
| **CI** | GitHub Actions | publication PyPI automatique |

## Skeleton

```
my-tool/
├── pyproject.toml
├── README.md
├── LICENSE
├── src/
│   └── my_tool/
│       ├── __init__.py
│       ├── __main__.py        # python -m my_tool
│       └── cli.py             # entry point
└── tests/
    └── test_cli.py
```

### `pyproject.toml` typique

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "my-tool"
version = "0.1.0"
description = "..."
requires-python = ">=3.10"
dependencies = ["typer>=0.12", "rich"]

[project.scripts]
my-tool = "my_tool.cli:app"

[project.optional-dependencies]
dev = ["pytest", "ruff", "mypy"]
```

### `cli.py` (Typer)

```python
import typer
from rich.console import Console

app = typer.Typer(help="My tool")
console = Console()

@app.command()
def hello(name: str = "World"):
    """Greet someone."""
    console.print(f"[bold green]Hello[/] {name}!")

if __name__ == "__main__":
    app()
```

## Distribution

### Install end-user

```bash
# Best : install isolé via pipx ou uv
pipx install my-tool
# OU
uv tool install my-tool
```

### Publish PyPI

```bash
uv build           # construit wheel + sdist dans dist/
uv publish         # upload PyPI (avec UV_PUBLISH_TOKEN)
```

### GitHub Actions auto-publish

```yaml
# .github/workflows/publish.yml
on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    permissions:
      id-token: write   # PyPI trusted publishing
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv build
      - run: uv publish
```

## Décisions clés

1. **Typer ou Click ?**
   - Typer : Pythonic, types-driven, autocomplete intégré → **default 2026**
   - Click : plus mature, plus de plugins (rich-click, click-completion)
2. **Pure Python ou compile (PyInstaller / Nuitka) ?**
   - Pure Python = simple, install via `pip`/`pipx`
   - PyInstaller = single binary, pour user non-Python (mais lourd, 30-100 MB)
3. **Configuration** : env vars + `.config/my-tool/config.toml`, voir `pydantic-settings`

## Pièges connus

- **Console scripts vs `__main__.py`** : utiliser les deux (`pip install` créé le bin, `python -m my_tool` fallback)
- **Argparse vs Typer / Click** : argparse stdlib OK pour 1 commande, vite limité multi-subcommands
- **Async CLI** : Typer ne gère pas natif, utiliser `asyncio.run(main())` dans la fonction
- **Cross-platform paths** : `pathlib.Path` partout, jamais `os.path.join`
- **Couleurs Windows** : Rich gère bien, `colorama` legacy
- **Shell completion** : Typer `--install-completion` ou Click `click-completion`
- **Configs sensibles** : `keyring` pour creds, pas en fichier plain
- **Versionning** : `importlib.metadata.version("my-tool")` dans `--version`

## Voir aussi

- [[uv]] — packaging / publishing moderne
- [[Ruff]] — linter
- [[pytest]] — tests
- [[Pydantic]] — config validation
- `[[Rules/Types/CLI]]` — règles CLI globales du brain
