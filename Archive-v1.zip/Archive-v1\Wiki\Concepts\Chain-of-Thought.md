---
galaxie: wiki
nom: Chain-of-Thought (CoT)
alias: [CoT, zero-shot CoT, few-shot CoT, reasoning chains, scratchpad]
type: concept
categorie: concept/llm-inference
sous_categories: [cot, reasoning, prompting, llm]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Wei 2022, Kojima 2022]
lecture_min: 4
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, prompting, reasoning, cot]
---

# Chain-of-Thought (CoT)

## TL;DR

**Levier reasoning #1** sur LLMs : forcer le modèle à **expliciter ses étapes** avant de répondre. **Zero-shot CoT** (Kojima 2022) : "Let's think step by step". **Few-shot CoT** (Wei 2022) : examples avec reasoning shown. Boost massif sur math (GSM8K +20-30 pts), reasoning, logique. Variants : **Self-Consistency** (sample N CoT, vote), **Tree of Thoughts** (branche), **Least-to-Most** (décomposer), **Skeleton-of-Thought** (outline then fill), **Plan-and-Solve**. Reasoning models ([[Reasoning models]] : o1, R1) ont CoT **trained-in** (long, hidden). En 2026 : CoT explicit moins nécessaire pour reasoning models, encore utile pour standards LLMs.

## Le problème

LLM single-pass → predict next token, pas reasoning explicit. Erreurs sur math, logique, multi-step :

```
Q: "If a train leaves at 3pm and takes 2.5h, when arrives ?"
A: "5pm" ← wrong, should be 5:30pm
```

→ Forcer **étape par étape** améliore drastiquement.

## L'idée

### Zero-shot CoT (Kojima 2022)

Ajouter "Let's think step by step" :

```
Q: If a train leaves at 3pm and takes 2.5h, when arrives ?
A: Let's think step by step.
- Departure : 3:00 PM
- Travel time : 2.5 hours = 2h 30min
- Arrival : 3:00 + 2:30 = 5:30 PM
Answer : 5:30 PM
```

Magic phrase. Très simple, énorme gain.

Variants : "Let me think carefully", "Break this down", "Step by step :".

### Few-shot CoT (Wei 2022)

Donner **examples** avec reasoning :

```
Q: Roger has 5 balls. He buys 2 cans of 3 balls each. How many ?
A: Let me think. Roger has 5 + 2*3 = 5 + 6 = 11 balls.

Q: A car travels 60 mph for 2 hours. Distance ?
A: Let me think. Distance = speed × time = 60 × 2 = 120 miles.

Q: <user question>
A: Let me think.
```

Modèle copie le **pattern de reasoning**.

### Pourquoi ça marche

- LLM utilise les tokens intermédiaires comme **scratchpad**
- Chaque token built on les précédents
- Permet à **information** d'émerger
- Évite jump directly to answer (souvent wrong)

### Self-Consistency (Wang 2023)

Sample $N$ CoT chains avec **temperature > 0**, vote majoritaire :

```python
answers = []
for _ in range(10):
    response = llm(prompt + "\nLet's think step by step.", temperature=0.7)
    ans = extract_answer(response)
    answers.append(ans)

# Majority vote
final = Counter(answers).most_common(1)[0][0]
```

Boost reasoning ~5-10 pts. **Standard** pour high-stakes math/reasoning.

Coût : N× LLM calls.

### Tree of Thoughts (Yao 2023)

Explore **multiple branches** d'idée :

```
Initial : think of 3 approaches
Branch each : develop further
Evaluate : which best ?
Continue best, backtrack si fail
```

Plus puissant que linear CoT mais coûteux. DFS / BFS over thoughts.

### Skeleton-of-Thought

```
1. Generate outline (skeleton)
2. Fill in each section
```

Pour réponses structurées longues.

### Plan-and-Solve

```
1. Plan : "What are the sub-tasks ?"
2. Solve : execute each sub-task
```

Mieux que CoT simple sur multi-step.

### Least-to-Most

Décomposer en sub-questions, simple → complex :

```
Original : "Find x in 3x^2 - 5x + 2 = 0"
Sub-questions :
1. What's the discriminant ? Δ = b² - 4ac = 25 - 24 = 1
2. Apply formula : x = (5 ± 1) / 6
3. Solutions : x = 1 or x = 2/3
```

### Step-back prompting (Zheng 2024)

Abstraire avant solving :

```
Q: "What was France's GDP in 2023?"
Step-back: "What are general GDP stats for France?"
→ Retrieve general context
→ Apply to specific.
```

### Algorithm-of-Thought (Sel 2024)

CoT avec algorithm pattern : "Apply algorithm X step by step".

### Self-Verification

Modèle vérifie son own answer :

```
1. Solve
2. Re-derive from answer to check
3. If inconsistent, redo
```

### CoT limitations

#### Small models

CoT peut **hurt** small models (<3B) — pas capable de long reasoning, juste produce confusion.

#### Reasoning models

o1, R1, Claude extended thinking → already CoT trained-in. Adding explicit "step by step" can be **redundant** ou **hurt**.

#### Faithfulness

CoT ne reflète pas toujours le real reasoning du modèle (Turpin 2023). "Unfaithful" CoT.

#### Cost

Long CoT = many tokens = expensive.

### Reasoning models vs CoT prompting

| | CoT prompting | Reasoning models |
|---|---|---|
| Training | Pas spécifique | Trained sur CoT traces |
| Length | ~500 tokens typique | 10K-100K tokens |
| User sees | Yes (in output) | Hidden (o1) ou Visible (Claude) |
| Cost | Same as LLM | 10-100x |
| Best on | Medium difficulty | Hard reasoning |
| Combine ? | Generally additive | Redundant for reasoning models |

### Best practices

1. **Always try zero-shot CoT first** : easy win
2. **Few-shot CoT** for harder tasks (examples relevant)
3. **Self-Consistency** for critical reasoning : 5-10 samples
4. **Plan-and-Solve / Least-to-Most** for complex multi-step
5. **Reasoning models** for very hard : math olympiad, hard code
6. **T=0** for reasoning (deterministic) — except Self-Consistency
7. **Extract final answer** : structured format ("Answer: X")
8. **Skip CoT** for simple Q&A (waste tokens)
9. **Combine with structured outputs** : `<thinking>...</thinking><answer>X</answer>`
10. **Measure cost / quality** : CoT 2-10x tokens

## Quand c'est utile

- **Math problems**
- **Logical reasoning** (Big-Bench Hard)
- **Multi-step planning**
- **Code generation** (think before code)
- **Reading comprehension** complex
- **Strategic decisions**
- **Customer support diagnostic** : "Let's troubleshoot step by step"
- **Educational** : show reasoning to users
- **Debugging** : LLM explains its logic
- **Agents** : ReAct = CoT + actions

## Quand ça ne marche pas / pièges

- **Small models** : CoT can hurt, just confuse
- **Reasoning models** : redundant, sometimes hurts
- **Simple Q&A** : waste of tokens
- **Creative writing** : structure-thinking can kill creativity
- **Time-sensitive** : long CoT = slow
- **Unfaithful CoT** : reasoning ≠ actual computation
- **Self-consistency cost** : N× expense
- **Tree of Thoughts cost** : exponential
- **CoT can be wrong AND confident** : false confidence
- **Bias amplification** : CoT can amplify wrong intuition

## Code minimal

```python
# 1. Zero-shot CoT
import anthropic
client = anthropic.Anthropic()

def zero_shot_cot(question):
    return client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": f"{question}\n\nLet's think step by step."
        }]
    ).content[0].text

# 2. Few-shot CoT
def few_shot_cot(question, examples):
    examples_str = "\n\n".join([
        f"Q: {ex['q']}\nA: Let's think step by step. {ex['reasoning']}\nAnswer: {ex['answer']}"
        for ex in examples
    ])
    return client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": f"{examples_str}\n\nQ: {question}\nA: Let's think step by step."
        }]
    ).content[0].text

# 3. Self-Consistency
from collections import Counter

def self_consistent_cot(question, n=10):
    answers = []
    for _ in range(n):
        response = client.messages.create(
            model="claude-3-7-sonnet-latest",
            max_tokens=500,
            temperature=0.7,
            messages=[{
                "role": "user",
                "content": f"{question}\n\nThink step by step. Final answer in <answer></answer> tags."
            }]
        )
        text = response.content[0].text
        import re
        match = re.search(r"<answer>(.*?)</answer>", text)
        if match:
            answers.append(match.group(1).strip())
    
    return Counter(answers).most_common(1)[0][0]

# 4. Plan-and-Solve
def plan_and_solve(question):
    # Step 1 : Plan
    plan = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=500,
        messages=[{"role": "user", "content": f"Make a plan to solve: {question}"}]
    ).content[0].text
    
    # Step 2 : Execute plan
    solution = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": f"Question: {question}\nPlan: {plan}\n\nExecute the plan and solve."
        }]
    ).content[0].text
    
    return solution

# 5. Tree of Thoughts (simplified)
def tot(question, n_branches=3, n_depths=2):
    initial_thoughts = []
    for _ in range(n_branches):
        thought = llm(f"Question: {question}\nGenerate one possible approach:", temperature=0.7)
        initial_thoughts.append(thought)
    
    # Evaluate
    scores = [evaluate_thought(t, question) for t in initial_thoughts]
    best = initial_thoughts[scores.index(max(scores))]
    
    # Expand best
    for _ in range(n_depths):
        next_thoughts = [llm(f"Continue from: {best}", temperature=0.7) for _ in range(n_branches)]
        scores = [evaluate_thought(t, question) for t in next_thoughts]
        best = next_thoughts[scores.index(max(scores))]
    
    return best

# 6. Anthropic XML thinking
def xml_cot(question):
    prompt = f"""{question}

Think step by step inside <thinking> tags, then provide the answer in <answer> tags.
"""
    response = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=2000,
        messages=[{"role": "user", "content": prompt}]
    )
    text = response.content[0].text
    import re
    thinking = re.search(r"<thinking>(.*?)</thinking>", text, re.DOTALL)
    answer = re.search(r"<answer>(.*?)</answer>", text, re.DOTALL)
    return {
        "thinking": thinking.group(1) if thinking else "",
        "answer": answer.group(1).strip() if answer else text
    }

# 7. Extended thinking (Claude reasoning)
response = client.messages.create(
    model="claude-opus-4-7-latest",
    max_tokens=8192,
    thinking={"type": "enabled", "budget_tokens": 16000},  # CoT trained-in
    messages=[{"role": "user", "content": "Hard problem..."}]
)

# 8. Self-Discover (Zhou 2024)
def self_discover(question, llm):
    # Step 1 : SELECT modules
    modules = llm(f"Question: {question}\nSelect reasoning modules:")
    # Step 2 : ADAPT to problem
    adapted = llm(f"Adapt these modules: {modules}\nTo solve: {question}")
    # Step 3 : IMPLEMENT
    return llm(f"Use: {adapted}\nSolve: {question}")
```

## Pour aller plus loin

- Wei et al., *Chain-of-Thought Prompting Elicits Reasoning in Large Language Models* (NeurIPS 2022)
- Kojima et al., *Large Language Models are Zero-Shot Reasoners* (NeurIPS 2022)
- Wang et al., *Self-Consistency Improves Chain of Thought Reasoning in Language Models* (ICLR 2023)
- Yao et al., *Tree of Thoughts: Deliberate Problem Solving with Large Language Models* (NeurIPS 2023)
- Wang et al., *Plan-and-Solve Prompting* (ACL 2023)
- Zhou et al., *Least-to-Most Prompting Enables Complex Reasoning in Large Language Models* (ICLR 2023)
- Turpin et al., *Language Models Don't Always Say What They Think: Unfaithful Explanations in Chain-of-Thought Prompting* (NeurIPS 2023)
- **Liens internes** : [[Prompt engineering]], [[Reasoning models]], [[Self-attention]], [[Decoding strategies]]
