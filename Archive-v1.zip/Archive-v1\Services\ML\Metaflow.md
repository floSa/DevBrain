---
galaxie: dev
nom: Metaflow
alias: [metaflow]
categorie: ml/orchestration
sous_categories: [pipelines, dataflow, netflix, dx-first]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python (avec R, support)
clients_officiels: [python, r]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Kubeflow]]", "[[ZenML]]", "[[Flyte]]", "[[Prefect]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ml, orchestration, dataflow, dx]
url_officiel: https://metaflow.org/
url_docs: https://docs.metaflow.org/
url_repo: https://github.com/Netflix/metaflow
---

# Metaflow

## Pourquoi
Framework data science créé par Netflix. **Très orienté data scientist** (vs ML engineer/ops) : on écrit des `FlowSpec` Python avec `@step`, on exécute en local et on scale sur AWS/K8s/Argo sans changer le code. DX très soignée : versioning automatique, artifacts versioned, namespaces. Le défaut quand l'équipe est composée de DS qui veulent du scale sans complexité.

## Quand l'utiliser
- Équipe data scientists qui veut scaler sans devenir DevOps
- Stack AWS (Metaflow nait là, Step Functions / Batch supportés nativement)
- Reproductibilité forte (artifacts versionnés par run)
- Onboarding rapide (5 min pour comprendre)
- Branchements dynamiques (`@parallel`, foreach)

## Quand NE PAS l'utiliser
- Tu vis full K8s on-prem → [[Kubeflow]] est plus intégré
- Workflows data engineering généraux → [[Dagster]] / [[Airflow]]
- Tu as besoin d'agendas cron sophistiqués → moins outillé que [[Airflow]]
- Stack non-AWS sans expertise interne → Outerbounds (managed) ou autre orchestrator

## Pièges connus
- **AWS-first** : très bien intégré AWS (S3, Batch, Step Functions), GCP/Azure moins
- **Argo Workflows** : support disponible mais à configurer (vs natif Step Functions)
- **`@batch` / `@kubernetes`** : décorateurs pour scale, à comprendre tôt
- **Metadata service** : à déployer en self-hosted (sinon local files)
- **DAG implicite** : ordre de steps via `self.next(...)`, pas un graphe explicite
- **Outerbounds** : version managed officielle (par les créateurs)

## Liens
- [[Kubeflow]], [[ZenML]], [[Flyte]] — alternatives
- Outerbounds (managed) : https://outerbounds.com/
- Tutorials : https://outerbounds.com/docs/intro-tutorial-overview/
- Talks Netflix : https://netflixtechblog.com/open-sourcing-metaflow-a-human-friendly-framework-for-data-science-fa72e04a5d9
