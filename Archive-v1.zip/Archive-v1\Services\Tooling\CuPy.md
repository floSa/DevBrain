---
galaxie: dev
nom: CuPy
alias: [cupy]
categorie: tooling/numpy
sous_categories: [numpy, gpu, cuda, drop-in, scientific-computing, rocm]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python / CUDA / C++
clients_officiels: [python]
plateforme: [linux, windows]
score: 4
mes_projets: []
alternatives: ["[[PyTorch]]", "[[JAX]]", "[[MLX]]", "numpy"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, numpy, gpu, scientific-computing]
url_officiel: https://cupy.dev/
url_docs: https://docs.cupy.dev/en/stable/
url_repo: https://github.com/cupy/cupy
---

# CuPy

## Pourquoi

**Drop-in replacement numpy sur GPU NVIDIA** (et AMD ROCm). Remplace `import numpy as np` par `import cupy as cp` → tes arrays vivent en VRAM avec une API quasi-identique. Construit au-dessus de CUDA / cuBLAS / cuFFT / cuRAND / cuSPARSE / cuDNN / NCCL.

Cible : **calcul scientifique numpy-heavy** (FFT, algèbre linéaire, simulations, signal processing) qui peut bénéficier du GPU mais n'a **pas besoin d'autograd** (sinon PyTorch / JAX). Souvent meilleur que PyTorch pour du numpy pur sur GPU car pas d'overhead tracking gradient. Brique fondatrice de **RAPIDS** (cuDF, cuML, cuGraph) — l'écosystème NVIDIA data science.

## Quand l'utiliser

- **Calcul scientifique numpy massif sur GPU** : FFT, SVD, eigen, matmul
- **Code numpy existant** : port GPU rapide via swap d'import
- **Combo numba / RAPIDS** : cuDF (pandas-like GPU), cuML (sklearn-like GPU)
- **Pas besoin d'autograd** : si tu veux juste les ops numpy accélérées
- **Custom CUDA kernels Python** : `cupy.RawKernel` pour écrire du CUDA inline
- **Signal / image processing GPU** : convolutions, filtres, transformations
- **Monte Carlo massif** : cuRAND + opérations vectorielles
- **Interop avec PyTorch/JAX** : zero-copy via `__cuda_array_interface__` / `__dlpack__`

## Quand NE PAS l'utiliser

- **Pas de GPU NVIDIA / AMD ROCm** : numpy / scipy direct
- **Besoin autograd** → [[PyTorch]] / [[JAX]]
- **Apple Silicon** → [[MLX]] / Metal
- **Petits arrays** (< quelques MB) : overhead de transfert CPU↔GPU annule le gain
- **Réseau de neurones complet** : PyTorch / JAX plus appropriés (modules, dataloaders, optim)
- **API SciPy spécifique** : CuPy a `cupyx.scipy` partiel mais pas toute SciPy

## Pièges connus

- **CUDA versions à matcher** : wheel CuPy compilé pour CUDA 11.x vs 12.x → `pip install cupy-cuda12x` selon ton driver
- **Memory management explicite** : VRAM ne se libère pas auto, utiliser `mempool.free_all_blocks()` ou `cp.cuda.runtime.memGetInfo()`
- **Pas 100% numpy compatible** : certaines fonctions niche manquent ou ont une sémantique légèrement différente
- **Transfer CPU↔GPU coûteux** : `cp.asnumpy(arr)` synchrone, ne PAS faire dans une boucle
- **Streams CUDA non-bloquantes** : par défaut sync, async via `cp.cuda.Stream()` pour overlap
- **Float64 sur GPU consumer** : RTX 3xxx/4xxx ont des perfs FP64 catastrophiques → préférer FP32
- **Indexing fancy** moins optimisé que sur CPU (numpy)
- **Erreurs CUDA cryptiques** : `cudaErrorIllegalAddress` souvent = bug d'indexing ou mémoire libérée
- **Multi-GPU** : `cp.cuda.Device(0)` context manager explicit, pas de DDP auto comme PyTorch

## Code minimal

```bash
# Install pour CUDA 12.x
pip install cupy-cuda12x

# Verifier
python -c "import cupy as cp; print(cp.cuda.runtime.getDeviceCount())"
```

```python
import cupy as cp
import numpy as np
import time

# Comparaison numpy CPU vs CuPy GPU
size = 10_000

# numpy CPU
a_np = np.random.rand(size, size).astype("float32")
t0 = time.time()
inv_np = np.linalg.inv(a_np)
print(f"numpy CPU: {time.time() - t0:.2f}s")

# CuPy GPU
a_gpu = cp.asarray(a_np)
cp.cuda.Stream.null.synchronize()
t0 = time.time()
inv_gpu = cp.linalg.inv(a_gpu)
cp.cuda.Stream.null.synchronize()
print(f"CuPy GPU: {time.time() - t0:.2f}s")

# Retour CPU si besoin
inv_cpu = cp.asnumpy(inv_gpu)
```

```python
# FFT GPU
signal = cp.random.rand(1_000_000).astype("complex64")
spectrum = cp.fft.fft(signal)
power = cp.abs(spectrum) ** 2
print(power.shape)
```

```python
# Memory management
mempool = cp.get_default_memory_pool()
print(f"VRAM utilisee: {mempool.used_bytes() / 1e9:.2f} Go")
# Liberer apres usage gros tableau
del a_gpu, inv_gpu
mempool.free_all_blocks()
```

```python
# Custom CUDA kernel inline
add_kernel = cp.RawKernel(r"""
extern "C" __global__
void add_arrays(const float* a, const float* b, float* out, int n) {
    int i = blockDim.x * blockIdx.x + threadIdx.x;
    if (i < n) out[i] = a[i] + b[i];
}
""", "add_arrays")

n = 1_000_000
a = cp.random.rand(n).astype("float32")
b = cp.random.rand(n).astype("float32")
out = cp.empty_like(a)
add_kernel((n // 256 + 1,), (256,), (a, b, out, n))
```

```python
# Interop PyTorch (zero-copy)
import torch
import cupy as cp

a_torch = torch.randn(1000, 1000, device="cuda")
a_cp = cp.from_dlpack(a_torch)        # zero-copy
result_cp = cp.linalg.inv(a_cp)
result_torch = torch.from_dlpack(result_cp)
```

## Liens

- [[PyTorch]] — alternative avec autograd
- [[JAX]] — alternative fonctionnelle (jit, vmap, grad)
- [[MLX]] — alternative Apple Silicon
- RAPIDS (cuDF, cuML, cuGraph) — écosystème NVIDIA data science basé CuPy
- numba — JIT compiler Python qui complète CuPy
- Docs : https://docs.cupy.dev/en/stable/
- GitHub : https://github.com/cupy/cupy
- Compat numpy/scipy : https://docs.cupy.dev/en/stable/reference/comparison.html
