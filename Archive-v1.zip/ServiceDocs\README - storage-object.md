# Service — <NOM_DU_SERVICE>

<!--
Template à copier dans <projet>/services/<nom>/README.md.
Référence règle : Rules/Documentation/Storage-Object.md du DevBrain.
-->

## Rôle métier

<À REMPLIR : 2-3 lignes — quel rôle ce stockage joue dans l'app.>

Exemple :
> Stockage objet S3-compatible pour : (1) ingestion brute des PDFs uploadés par les users, (2) artefacts ML (modèles entraînés), (3) backups DB. Auto-hébergé en interne.

## Arborescence des buckets

| Bucket | Rôle | Convention objets | Public ? | Versionning | Encryption |
|--------|------|-------------------|----------|-------------|------------|
| `<projet>-raw` | Ingestion brute | `users/<user_id>/<doc_id>.<ext>` | ❌ | ✅ | SSE-S3 |
| `<projet>-processed` | JSON normalisés post-pipeline | `processed/<YYYY-MM-DD>/<doc_id>.json` | ❌ | ❌ | SSE-S3 |
| `<projet>-models` | Artefacts ML | `models/<model_name>/<version>/model.bin` | ❌ | ✅ | SSE-S3 |
| `<projet>-public` | Assets téléchargeables | `static/<asset_id>` | ✅ (CDN) | ❌ | — |
| `<projet>-backups` | Snapshots DB | `pg/<YYYY-MM-DD>/dump.sql.gz` | ❌ | ❌ | SSE-S3 + KMS |
| `<À REMPLIR>` |  |  |  |  |  |

## Politique de rétention

| Bucket | Rétention | Lifecycle | Restore tested |
|--------|-----------|-----------|----------------|
| `<projet>-raw` | 90 jours actif → Glacier | Move to Glacier après 90j, delete après 1 an | `<DATE>` |
| `<projet>-processed` | Indéfini (régénérable depuis raw) | Delete après 6 mois | — |
| `<projet>-models` | Indéfini | Versioned, delete versions > 5 anciennes | `<DATE>` |
| `<projet>-public` | Selon usage | Delete après inactivité 1 an | — |
| `<projet>-backups` | 30 jours daily + 12 mensuels + 5 annuels | Lifecycle GFS | `<DATE>` |

## Contrat d'interface

- **Endpoint** : `<À REMPLIR : http://minio:9000 / https://s3.amazonaws.com>`
- **Region** : `<À REMPLIR : us-east-1 / eu-west-1>`
- **Client** : `<À REMPLIR : boto3 / minio-py / aws-sdk-go>`
- **Patterns** :
  - Upload : `client.put_object(Bucket, Key, Body)` ou multipart si > 100 MB
  - Download : `client.get_object` ou présigned URL
  - Listing : `client.list_objects_v2` avec pagination

### Méthodes principales

```python
def upload_doc(user_id: str, file: BinaryIO) -> str: ...   # retourne s3_key
def get_presigned_url(s3_key: str, expires_in: int = 3600) -> str: ...
def delete_doc(s3_key: str) -> None: ...
def list_user_docs(user_id: str) -> list[ObjectMeta]: ...
```

## Configuration

| Variable | Type | Défaut | Description |
|----------|------|--------|-------------|
| `S3_ENDPOINT_URL` | `HttpUrl` | — | URL du service |
| `S3_ACCESS_KEY` | `str` | — | Access key |
| `S3_SECRET_KEY` | `str` | — | Secret (Field repr=False) |
| `S3_REGION` | `str` | `us-east-1` | Région |
| `S3_BUCKET_RAW` | `str` | `<projet>-raw` | Bucket ingestion |
| `S3_BUCKET_PROCESSED` | `str` | `<projet>-processed` | Bucket processed |
| `<À REMPLIR>` |  |  |  |

## Sécurité

- **IAM Policies** : configurées dans `services/<nom>/policies/` (versionné)
- **Buckets jamais publics par défaut** ; audit trimestriel
- **Presigned URLs** : durée par défaut **1h**, max **24h**
- **Encryption** : SSE-S3 par défaut, SSE-KMS pour `*-backups`
- **Audit logs** : <À REMPLIR : CloudTrail / MinIO audit endpoint>

## Démarrage local (MinIO)

```bash
docker-compose up -d minio
# Console : http://localhost:9001
# Default : minioadmin / minioadmin (changer en prod)

# Créer les buckets initiaux
uv run python services/<nom>/init_buckets.py

# Vérifier
docker-compose exec minio mc ls local/
```

## Cleanup & quotas

- **Cleanup périodique** : `services/<nom>/scripts/cleanup_orphans.py` (cron weekly)
- **Quotas par tenant** : `<À REMPLIR : 5 GB par user>` (vérifié à l'upload)
- **Métriques coût** : dashboard Grafana `<lien>`

## Pièges à anticiper

- **Buckets publics accidentels** : audit obligatoire
- **Egress fees** sur AWS S3 — surveiller
- **Filename collisions** sans UUID/timestamp
- **Restore non testé** : drill trimestriel sur `*-backups`
- **MinIO AGPL** : implications légales si distribution SaaS

## Liens

- DevBrain : [[MinIO]] (ou [[<À REMPLIR>]])
- Règle : [[Storage-Object]]
- Doc fournisseur : <URL>
- Runbook restore : `docs/OPERATIONS.md#restore-from-s3`
