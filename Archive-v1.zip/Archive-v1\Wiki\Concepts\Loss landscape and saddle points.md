---
galaxie: wiki
nom: Loss landscape and saddle points
alias: [loss landscape, saddle points, points selles, minima locaux, plateaux]
type: concept
categorie: concept/optimization
sous_categories: [loss-landscape, saddle-points, non-convex, geometry, hessian]
domaines: [ml-eng, ai-eng]
maturite: established
auteurs_cles: [Dauphin et al. 2014, Choromanska et al. 2015, Li et al. 2018]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, optimization, loss-landscape, saddle-points, non-convex]
---

# Loss landscape and saddle points

## TL;DR

Le **loss landscape** d'un NN est la surface géographique de la loss en fonction des paramètres. **Non-convexe** par construction → minima locaux, **points selles**, plateaux. Découverte clé (Dauphin 2014) : en haute dimension, **les vrais minima locaux sont rares** ; ce qui ralentit l'entraînement sont surtout les **points selles**. Le bruit de SGD aide à s'en échapper.

## Le problème

Pourquoi le DL fonctionne-t-il alors que la loss est non-convexe ? Si on avait des millions de minima locaux médiocres, l'optimisation serait désespérée. Pourtant en pratique on trouve presque toujours de bonnes solutions.

Comprendre la **géométrie** du loss landscape explique pourquoi.

## L'idée

### Types de points critiques

Un point $\theta^*$ est **critique** si $\nabla L(\theta^*) = 0$. Le Hessien $H(\theta^*)$ détermine la nature :

| Hessien | Nature | En 2D |
|---|---|---|
| Toutes valeurs propres $> 0$ | Minimum local | "bol" |
| Toutes $< 0$ | Maximum local | "dôme" |
| Mix de signes | **Point selle** | "selle de cheval" |
| Au moins une = 0 | Cas dégénéré (plateau) | "vallée plate" |

### Découverte clé — Dauphin et al. 2014

En **haute dimension** (typique en NN avec millions de paramètres), pour qu'un point critique soit un minimum local, **toutes** les valeurs propres du Hessien doivent être positives. Probabilité : faible si les vp sont distribuées symétriquement.

Conséquence : **les points selles dominent** largement les minima locaux. Et pire, les points selles avec beaucoup de directions plates ralentissent énormément la convergence.

### Pourquoi SGD échappe aux saddle points

Le **bruit** du mini-batch perturbe les paramètres dans des directions aléatoires → finit par trouver une direction descendante. Ce qui fait du SGD un échappatoire naturel aux saddle points (contrairement à GD batch ou Newton sans bruit).

### Connectivité des minima

Garipov et al. 2018 et autres : les minima trouvés par SGD sont **connectés** par des chemins de loss basse — pas de "vallées séparées". On peut interpoler entre 2 minima sans trop monter en loss.

Implications :
- Pas de "vrai" minimum unique
- **Mode connectivity** : ensembling de plusieurs runs peut converger vers des solutions liées
- Sub-network discovery (lottery ticket) : sous-réseaux qui suivent les mêmes vallées

### Sharp vs flat minima

Critère de qualité : les **minima plats** (Hessien à petites valeurs propres) **généralisent mieux** que les minima pointus (sharp minima).

Pourquoi : minimum plat = robust aux perturbations des paramètres = robust aux décalages train/test. Justification empirique de :
- **SGD vs Adam** : SGD trouve des minima plus plats
- **Large batch ≠ small batch** : grand batch trouve des minima plus pointus (généralise moins)
- **SAM** (Sharpness-Aware Minimization) : optimise explicitement vers minima plats

### Pourquoi le DL marche malgré la non-convexité

Hypothèses qui s'accumulent :
1. **Sur-paramétrisation** : avec >> paramètres que données, beaucoup de minima globaux équivalents → facile à atteindre
2. **Initialisation** + dynamics : SGD biais implicitement vers des solutions simples (implicit regularization)
3. **Loss landscape "amical"** : pour les NN sur-paramétrés, les minima dominants sont connectés et plats
4. **Bruit SGD** : échappe aux saddle points

C'est un **comportement empirique**, pas une garantie théorique. Le DL marche, mais on ne comprend pas complètement pourquoi.

### Visualisation

Li et al. 2018 (loss landscape visualization) :
- Projeter dans un plan 2D autour du minimum trouvé (via filtres random ou PCA)
- Tracer la surface
- Observer si le minimum est plat ou pointu

Bibliothèque : `loss-landscape` sur GitHub. Visualisations célèbres : ResNet sans skip connection vs avec → skip = landscape beaucoup plus lisse.

## Quand c'est utile

- **Comprendre pourquoi le DL marche** : intuition sur les "minima trouvés"
- **Choisir un optimizer** : SGD pour minima plats, Adam pour vitesse
- **Diagnostiquer une stagnation** : suspecter saddle point → ajouter bruit, baisser LR
- **Décider du batch size** : petit pour généralisation
- **Design d'architecture** : skip connections lissent le landscape (ResNet vs VGG plain)
- **Sharpness-Aware Minimization (SAM)** : si on veut explicitement minima plats

## Quand ça ne marche pas / pièges

- **Croire qu'on est dans un minimum local** : en haute dim, presque toujours c'est un saddle point. Vérifier les valeurs propres du Hessien si critical.
- **Saddle point persistant** : ajouter du bruit, perturber les params, redémarrer le LR (cosine warm restart)
- **Plateau** : Hessien dégénéré. Augmenter LR ou ajouter momentum.
- **Mauvaise généralisation** malgré low train loss : minimum pointu suspecté. Essayer SAM ou plus de régularisation.
- **Hessien explicit en DL** : impossible à calculer en pratique sur grand modèle. Utiliser approximations (Hutchinson trace estimator, K-FAC).
- **Visualisation 2D trompeuse** : projection 2D ne capture pas la haute dim. Prudence interprétation.

## Code minimal

```python
import torch
import torch.nn as nn

# Estimer la trace du Hessien via Hutchinson estimator
def hessian_trace(model, loss_fn, X, y, n_samples=10):
    """Estime tr(H) sans calculer H — Hutchinson estimator."""
    model.zero_grad()
    loss = loss_fn(model(X), y)
    grads = torch.autograd.grad(loss, model.parameters(), create_graph=True)
    grads_flat = torch.cat([g.flatten() for g in grads])
    
    trace = 0
    for _ in range(n_samples):
        v = torch.randn_like(grads_flat)
        # Hv via Hessian-vector product
        Hv = torch.autograd.grad(grads_flat @ v, model.parameters(), retain_graph=True)
        Hv_flat = torch.cat([h.flatten() for h in Hv])
        trace += (v * Hv_flat).sum().item()
    return trace / n_samples

# Sharpness-Aware Minimization (idée)
class SAM(torch.optim.Optimizer):
    def __init__(self, params, base_optimizer, rho=0.05, **kwargs):
        defaults = dict(rho=rho, **kwargs)
        super().__init__(params, defaults)
        self.base_optimizer = base_optimizer(self.param_groups, **kwargs)
    
    @torch.no_grad()
    def first_step(self):
        # Move to neighborhood maximum of loss
        for group in self.param_groups:
            grad_norm = torch.norm(torch.stack([
                p.grad.norm(p=2) for p in group['params'] if p.grad is not None
            ]), p=2)
            scale = group['rho'] / (grad_norm + 1e-12)
            for p in group['params']:
                if p.grad is None: continue
                e_w = p.grad * scale
                p.add_(e_w)
                self.state[p]['e_w'] = e_w
    
    @torch.no_grad()
    def second_step(self):
        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None: continue
                p.sub_(self.state[p]['e_w'])
        self.base_optimizer.step()
```

## Pour aller plus loin

- Dauphin et al., *Identifying and attacking the saddle point problem in high-dimensional non-convex optimization* (NIPS 2014)
- Li et al., *Visualizing the Loss Landscape of Neural Nets* (NeurIPS 2018)
- Foret et al., *Sharpness-Aware Minimization for Efficiently Improving Generalization* (ICLR 2021)
- *Why are saddle points so prevalent?* (blog Goh) — pédagogique
- **Liens internes** : [[Convexity]], [[Gradient descent]], [[Adam optimizer]], [[Eigendecomposition]] (Hessien), [[Bias-variance tradeoff]]
