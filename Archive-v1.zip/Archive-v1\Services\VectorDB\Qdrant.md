---
galaxie: dev
nom: Qdrant
alias: [qdrant]
categorie: database/vector
sous_categories: [hnsw, hybrid-search, payload-filtering]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Rust
clients_officiels: [python, ts, go, rust, dotnet, java]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Weaviate]]", "[[Milvus]]", "[[Chroma]]", "[[pgvector]]", "[[Faiss]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, database, vector, rust, hnsw]
url_officiel: https://qdrant.tech/
url_docs: https://qdrant.tech/documentation/
url_repo: https://github.com/qdrant/qdrant
---

# Qdrant

## Pourquoi
Base vectorielle écrite en Rust. Performance excellente, **payload filtering** puissant (filtres pré-search, pas post), mode hybride dense+sparse, scalar/binary quantization. Le défaut moderne pour un vector store sérieux self-hosted.

## Quand l'utiliser
- RAG / search sémantique en production
- Filtrage métier critique combiné au vector search ("docs de ce client uniquement, score > 0.8")
- Self-hosted avec performance et Rust ❤️
- Quand on veut éviter [[pgvector]] pour ne pas mélanger DB transactionnelle et search
- Hybrid search (BM25 sparse + dense embedding)

## Quand NE PAS l'utiliser
- Petit projet ou POC → [[Chroma]] est 5 fois plus simple
- Déjà sur Postgres et besoin modeste → [[pgvector]] suffit
- Embeddings et search en RAM dans un script → [[Faiss]] direct
- Si tu veux GraphQL natif → [[Weaviate]]

## Pièges connus
- **Distance metric** : à choisir à la création de la collection (Cosine/Dot/Euclidean), irréversible
- **HNSW params** : `m`, `ef_construct`, `ef` à tuner selon recall vs latency
- **Quantization** : trade-off précision/mémoire à mesurer (binary peut perdre du recall sur petits embeddings)
- **Cluster mode** : payant en cloud, complexe en self-hosted
- **API REST vs gRPC** : gRPC plus rapide, prendre l'habitude
- **Snapshots** : à automatiser pour les backups

## Liens
- [[Weaviate]], [[Milvus]], [[Chroma]], [[pgvector]] — alternatives
- Qdrant Cloud : https://cloud.qdrant.io/
- Benchmarks vector DBs : https://qdrant.tech/benchmarks/ (biased mais utile)
- Filtering reference : https://qdrant.tech/documentation/concepts/filtering/
