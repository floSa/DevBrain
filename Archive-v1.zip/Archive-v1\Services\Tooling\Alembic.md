---
galaxie: dev
nom: Alembic
alias: [alembic]
categorie: tooling/build
sous_categories: [migration, sql, sqlalchemy, schema-evolution]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python, cli]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["Flyway", "Liquibase", "yoyo-migrations", "golang-migrate"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, tooling, migration, sqlalchemy, postgres]
url_officiel: https://alembic.sqlalchemy.org/
url_docs: https://alembic.sqlalchemy.org/en/latest/
url_repo: https://github.com/sqlalchemy/alembic
---

# Alembic

## Pourquoi
Outil de migration de schéma SQL **standard pour SQLAlchemy** (même auteur, Mike Bayer). Auto-detection des changements de modèles, fichiers de migration Python, support `up`/`down`. Le défaut quand on fait du Python + [[Postgres]] / MySQL / SQLite avec SQLAlchemy.

## Quand l'utiliser
- Stack Python + SQLAlchemy + DB relationnelle
- Besoin d'auto-detection des changements de modèles
- Multi-environnements (dev / staging / prod) avec migrations idempotentes
- Equipe qui contribue au schéma (révisions versionnées en git)

## Quand NE PAS l'utiliser
- Pas SQLAlchemy → Flyway (Java-friendly), Liquibase, yoyo (Python sans ORM)
- DB graphe / NoSQL → migrations gérées différemment ([[Database-Graph]])
- Tu utilises Prisma / Drizzle / Diesel → outils intégrés à l'ORM choisi

## Pièges connus
- **Auto-generation imparfaite** : Alembic détecte mal les **renames** (drop+add à la place). Toujours **reviewer** le fichier généré.
- **`op.alter_column()`** : pour PG, certaines opérations exigent `CONCURRENTLY` ou `USING` à ajouter manuellement
- **Multi-head** : si plusieurs branches de migration, conflits à merger explicitement (`alembic merge`)
- **Down migrations** : souvent incomplètes (un `DROP COLUMN` ne récupère pas la donnée). Documenter les limites
- **Stamping** : `alembic stamp` pour aligner sans exécuter — utile en migration de DB legacy mais piège classique
- **Variables d'env** : `sqlalchemy.url` dans `alembic.ini` à override en prod (ne pas commit la prod URL)

## Patterns essentiels

### Setup initial

```bash
uv add alembic
alembic init -t async alembic       # template async pour SQLAlchemy 2.x async
# ou
alembic init alembic                # sync standard
```

### Configuration `env.py` (snippet clé)

```python
# alembic/env.py — pointer sur les modèles
from myapp.db.models import Base
target_metadata = Base.metadata

# Charger l'URL depuis settings Pydantic (pas alembic.ini)
from myapp.settings import settings
config.set_main_option("sqlalchemy.url", str(settings.database_url))
```

### Workflow d'ajout

```bash
# Auto-générer depuis les modèles
uv run alembic revision --autogenerate -m "add user.locale column"

# REVIEWER le fichier dans alembic/versions/

# Appliquer en local
uv run alembic upgrade head

# Rollback (en dev uniquement)
uv run alembic downgrade -1
```

### Migration Postgres sur grosse table

```python
def upgrade() -> None:
    # éviter le lock long → CONCURRENTLY (en dehors de la transaction Alembic)
    op.execute("COMMIT")  # finir la tx implicite
    op.execute("CREATE INDEX CONCURRENTLY ix_users_email ON users(email)")
```

(Cf. [[REX - Postgres]] pour les pièges courants.)

## Liens
- [[Postgres]] — DB cible la plus courante
- [[Database-Relational]] — règle doc qui impose Alembic
- Doc tutorial : https://alembic.sqlalchemy.org/en/latest/tutorial.html
- Cookbook recipes : https://alembic.sqlalchemy.org/en/latest/cookbook.html
