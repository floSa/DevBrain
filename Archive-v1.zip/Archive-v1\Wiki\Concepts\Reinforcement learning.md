---
galaxie: wiki
nom: Reinforcement learning
alias: [RL, apprentissage par renforcement, reinforcement-learning]
type: concept
categorie: concept/ml
sous_categories: [rl, sequential-decision, policy, value, exploration]
domaines: [ml-eng, ai-eng, data-science]
maturite: established
auteurs_cles: [Sutton & Barto, Bellman, Watkins, Silver, Schulman, Mnih]
lecture_min: 12
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, rl, index]
---

# Reinforcement learning — RL

## TL;DR

Un **agent** interagit avec un **environnement** : à chaque pas il observe un état, choisit une action, reçoit une récompense, transite vers un nouvel état. Objectif : apprendre une **politique** qui maximise la récompense cumulée. Diffère du supervised learning : pas de label "bonne action", juste un signal de récompense différé. Cadre formel : [[Markov Decision Process]]. Familles d'algos : **value-based** (Q-learning, DQN), **policy-based** (REINFORCE, PPO), **actor-critic** (A2C, SAC), **model-based** (Dreamer, MuZero). Application phare 2024-2026 : **alignement des LLMs** (RLHF, DPO, GRPO).

## Le problème

Trois settings de ML :

| Setting | Signal | Exemple |
|---|---|---|
| Supervised | label correct sur chaque sample | classifier des images |
| Unsupervised | aucun label, structure des données | clustering |
| **Reinforcement** | **récompense scalaire différée** sur des séquences d'actions | jouer aux échecs |

En RL, deux difficultés spécifiques :
1. **Credit assignment** : si je gagne une partie d'échecs en 40 coups, lequel a vraiment compté ?
2. **Exploration vs exploitation** : faut-il jouer le coup qu'on connaît bien (exploit) ou en tester un nouveau (explore) ?

## L'idée

### Boucle d'interaction

```
                       ┌─────────────┐
              action a │             │
        ┌──────────────►  ENVIRONMENT │
        │              │             │
   ┌────┴─────┐        └──────┬──────┘
   │  AGENT   │               │
   │  π(a|s)  │ état s         │
   └──────────┘ récompense r   │
        ▲                      │
        └──────────────────────┘
```

À chaque pas $t$ :
1. L'agent observe l'état $s_t$
2. Choisit une action $a_t \sim \pi(\cdot | s_t)$
3. L'environnement transitionne : $s_{t+1} \sim p(\cdot | s_t, a_t)$
4. L'agent reçoit récompense $r_{t+1}$

**Objectif** : maximiser le **retour** (somme actualisée des récompenses futures) :

$$ G_t = \sum_{k=0}^{\infty} \gamma^k r_{t+k+1} $$

où $\gamma \in [0, 1)$ est le **facteur d'actualisation** (préférence pour les récompenses proches).

### Vocabulaire de base

- **Politique** $\pi(a|s)$ : distribution sur les actions sachant l'état
- **Fonction de valeur** $V^\pi(s)$ : retour espéré en partant de $s$ et suivant $\pi$ — voir [[Value functions]]
- **Fonction action-valeur** $Q^\pi(s, a)$ : retour espéré en partant de $s$, jouant $a$, puis suivant $\pi$
- **Politique optimale** $\pi^*$ : maximise $V^\pi$ partout
- **Équations de Bellman** : récursions sur $V$ et $Q$ qui définissent l'optimum — voir [[Bellman equations]]

### Taxonomie des algorithmes

```
                    ┌─── Model-free ────┬── Value-based ──── Q-learning, DQN, Rainbow
                    │                   │
                    │                   ├── Policy-based ─── REINFORCE, PPO, TRPO
RL algorithms ──────┤                   │
                    │                   └── Actor-Critic ─── A2C, A3C, SAC, DDPG, TD3
                    │
                    └─── Model-based ───┬── Planning ─────── MCTS, AlphaZero
                                        │
                                        └── World Models ── Dreamer, MuZero, PlaNet
```

**Model-free** : apprend directement π ou Q depuis l'expérience, sans modèle de transition. Standard, robuste.

**Model-based** : apprend (ou utilise) un modèle de l'environnement $\hat{p}(s'|s,a)$, planifie dessus. Plus efficace en samples mais plus complexe.

**Value-based** : apprend $Q^*(s, a)$, déduit $\pi^*(s) = \arg\max_a Q^*(s, a)$. Marche pour actions discrètes.

**Policy-based** : optimise directement $\pi_\theta$ via gradient — voir [[Policy gradient]]. Marche pour actions continues.

**Actor-Critic** : combine les deux — un *actor* (politique) et un *critic* (valeur) qui se renforcent.

### On-policy vs off-policy

- **On-policy** : l'algo apprend à partir des données générées par la politique courante (PPO, A2C, SARSA). Plus stable, moins sample-efficient.
- **Off-policy** : l'algo apprend depuis des données d'une autre politique (Q-learning, DQN, SAC). Replay buffer possible, plus sample-efficient, mais peut diverger.

### Trois familles de problèmes pratiques

1. **Contrôle continu** : robotique, simulation physique → SAC, TD3, PPO
2. **Discret avec rewards bien définis** : jeux, recommandation → DQN, PPO
3. **LLMs / alignment** : RLHF, DPO, GRPO — voir [[RLHF and DPO]], récompense humaine ou *verifiable*

## Quand c'est utile

- **Décision séquentielle** : robotique, trading, gestion d'énergie, ad allocation
- **Pas de "vraie réponse"** : seulement un signal de qualité (préférences humaines pour LLMs)
- **Simulation disponible** : on peut générer des millions d'épisodes (jeux, sim physique)
- **Alignement des LLMs** : RLHF, DPO, GRPO pour ajuster un modèle aux préférences
- **Multi-step reasoning** : R1-like, agent qui décompose une tâche
- **Bandits / [[Multi-armed bandits]]** : cas simplifié sans état (recommendation, A/B adaptatif)
- **Optimisation combinatoire** : routage, scheduling (avec twist : function approximation)

## Quand ça ne marche pas / pièges

- **Sample inefficiency** : RL demande des millions d'interactions, hors simulation c'est cher
- **Reward hacking** : le modèle exploite des bugs dans la définition de la récompense — Goodhart en RL
- **Reward shaping** difficile : sparse rewards = rien n'apprend, dense rewards mal calibrés = mauvaise politique
- **Distribution shift** entre train et deploy : politique apprise en sim ne tient pas en réel (*sim-to-real gap*)
- **Instabilité** : RL est notoirement instable, surtout off-policy + neural nets
- **Pas de garanties** : convergence prouvée pour tabular linéaire, pas pour deep RL
- **Choix d'algo non-trivial** : PPO ≠ SAC ≠ DQN, dépend du problème (discret/continu, on/off-policy)
- **Eval honnête est difficile** : variance des seeds, cherry-picking fréquent dans la littérature
- **Si supervised marche, prends supervised** : RL est l'option de dernier recours

## Code minimal

```python
# Boucle RL canonique avec Gymnasium (héritier de OpenAI Gym)
import gymnasium as gym
import numpy as np

env = gym.make("CartPole-v1")
obs, info = env.reset(seed=42)

total_return = 0.0
gamma = 0.99

for step in range(500):
    # Politique aléatoire pour démonstration
    action = env.action_space.sample()

    next_obs, reward, terminated, truncated, info = env.step(action)
    total_return += (gamma ** step) * reward

    if terminated or truncated:
        print(f"Épisode fini à t={step}, retour actualisé={total_return:.2f}")
        break
    obs = next_obs

env.close()
```

```python
# Agent Q-learning tabulaire (gridworld discret)
import numpy as np
import gymnasium as gym

env = gym.make("FrozenLake-v1", is_slippery=False)
n_states, n_actions = env.observation_space.n, env.action_space.n

Q = np.zeros((n_states, n_actions))
alpha, gamma, eps = 0.1, 0.99, 0.1

for episode in range(5000):
    s, _ = env.reset()
    done = False
    while not done:
        # ε-greedy : voir [[Exploration vs exploitation]]
        a = env.action_space.sample() if np.random.rand() < eps else int(Q[s].argmax())
        s2, r, term, trunc, _ = env.step(a)
        # Mise à jour Q-learning : voir [[Bellman equations]] (Bellman optimality)
        Q[s, a] += alpha * (r + gamma * Q[s2].max() - Q[s, a])
        s, done = s2, term or trunc

print(f"Politique apprise : {Q.argmax(axis=1)}")
```

```python
# Pour deep RL en pratique, utiliser une lib éprouvée
# pip install stable-baselines3
from stable_baselines3 import PPO
import gymnasium as gym

env = gym.make("LunarLander-v2")
model = PPO("MlpPolicy", env, verbose=1)
model.learn(total_timesteps=200_000)
model.save("ppo_lunarlander")

# Eval
obs, _ = env.reset()
for _ in range(1000):
    action, _ = model.predict(obs, deterministic=True)
    obs, r, term, trunc, _ = env.step(action)
    if term or trunc:
        obs, _ = env.reset()
```

## Pour aller plus loin

- Sutton & Barto, *Reinforcement Learning: An Introduction* (2nd ed., 2018) — la bible, gratuit en ligne : http://incompleteideas.net/book/the-book.html
- David Silver, *RL Course* (UCL/DeepMind, 2015) — vidéos référentes
- Spinning Up in Deep RL (OpenAI) : https://spinningup.openai.com/
- Stable-Baselines3 — implémentations production-ready : https://stable-baselines3.readthedocs.io/
- CleanRL — implémentations pédagogiques single-file : https://github.com/vwxyzjn/cleanrl
- **Liens internes** : [[Markov Decision Process]], [[Bellman equations]], [[Value functions]], [[Policy gradient]], [[Exploration vs exploitation]], [[Multi-armed bandits]], [[RLHF and DPO]]
