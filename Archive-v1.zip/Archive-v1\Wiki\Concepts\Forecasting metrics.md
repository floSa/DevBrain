---
galaxie: wiki
nom: Forecasting metrics
alias: [MAPE, sMAPE, MASE, WAPE, CRPS, pinball loss, forecast accuracy]
type: concept
categorie: concept/metrics
sous_categories: [metrics, forecasting, time-series, evaluation]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Hyndman, Koehler 2006]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, metrics, forecasting, time-series]
---

# Forecasting metrics

## TL;DR

Métriques **spécifiques aux séries temporelles** : ce ne sont pas exactement les mêmes que pour la régression statique. Familles : **erreur absolue** (MAE), **erreur relative** (MAPE/sMAPE/WAPE), **erreur scalée** (MASE/RMSSE — comparables entre séries d'échelles différentes), **probabilistes** (pinball, CRPS, coverage des intervalles de prédiction), **directionnelles** (MDA — pour up/down de marché). Le **biais cumulé** est aussi essentiel : un biais persistant ruine les opérations même si MAPE est OK. Toujours évaluer en **walk-forward** ([[Walk-forward CV]]), pas en KFold.

## Le problème

Évaluer un modèle de [[Forecasting framing|forecasting]] demande de répondre à plusieurs questions :
- Quelle est l'erreur moyenne ?
- Le modèle est-il biaisé (sur-prédiction systématique) ?
- Les intervalles de prédiction sont-ils bien calibrés ?
- Comment comparer des modèles sur **plusieurs séries** d'échelles différentes ?

Les métriques de régression classique ne couvrent que la 1ère question. Le forecasting demande plus.

## L'idée

### Erreurs ponctuelles (point forecast)

#### Famille MAE / RMSE

Voir [[Regression metrics]] — direct application.

- **MAE** : erreur médiane, robuste outliers
- **RMSE** : pénalise gros écarts, important pour catastrophes
- Reporter en unité de la série (€, unités, MW…)

#### Erreurs relatives

**MAPE** : standard mais piégeux (asymétrique, explose à 0). Voir [[Regression metrics]].

**sMAPE** : symétrique mais toujours problématique à 0.

**WAPE** (= MAD/Mean en demand forecasting) :

$$ \text{WAPE} = \frac{\sum_t |y_t - \hat y_t|}{\sum_t |y_t|} $$

Mieux que MAPE pour des séries avec zéros (intermittent). Standard chez Amazon, retail.

#### Erreurs scalées (MASE, RMSSE)

**MASE** (Mean Absolute Scaled Error, Hyndman-Koehler 2006) :

$$ \text{MASE} = \frac{\frac{1}{n} \sum |y_t - \hat y_t|}{\frac{1}{n-m} \sum_{t=m+1}^n |y_t - y_{t-m}|} $$

Le dénominateur est la **MAE d'un baseline naïf saisonnier** (predict last season's value).

- **MASE < 1** → meilleur que naïve
- **MASE = 1** → équivalent à naïve
- **MASE > 1** → pire (red flag !)
- $m$ = période saisonnière (1 si non-saisonnier, 12 monthly, 7 daily)
- **Adimensionnelle** → comparable entre séries
- **Pas d'explosion à 0** → fonctionne avec intermittent
- Utilisé dans **M-competitions** (Makridakis)

**RMSSE** : variant quadratique, identique en logique.

#### Symmetric mean absolute scaled error (sMASE)

Variante avec naive forward (utile en cross-sectional forecasting).

### Biais

Souvent ignoré, **critique en opérations**.

**Bias** (Mean Error, ME) :

$$ \text{ME} = \frac{1}{n} \sum (y_t - \hat y_t) $$

- Positif → sous-prédit (modèle conservateur)
- Négatif → sur-prédit (modèle optimiste)
- Près de 0 → équilibré

**Cumulative Forecast Error (CFE)** :

$$ \text{CFE} = \sum_t (y_t - \hat y_t) $$

Si CFE diverge dans le temps → biais persistant → action corrective (recalibrer modèle, mettre à jour drift).

**Tracking signal** :

$$ \text{TS} = \frac{\text{CFE}}{\text{MAD}} $$

Si $|TS| > 4-6$, le modèle est out-of-control statistiquement. Trigger pour réentraînement.

### Forecast probabiliste

Pour intervalles de prédiction $(\hat y_{\tau, low}, \hat y_{\tau, high})$ :

#### Pinball loss / Quantile loss

$$ L_\tau(y, \hat y_\tau) = \begin{cases} \tau (y - \hat y_\tau) & y \geq \hat y_\tau \\ (\tau - 1)(y - \hat y_\tau) & y < \hat y_\tau \end{cases} $$

- $\tau = 0.5$ → MAE
- $\tau = 0.9$ → optimise quantile 90% (sur-stock toléré)
- $\tau = 0.1$ → optimise quantile 10% (rupture évitée)

Standard pour LightGBM quantile, GBM quantile, neuralforecast.

#### Coverage (PIC, prediction interval coverage)

$$ \text{Coverage}_\alpha = \frac{1}{n} \sum_t \mathbb{1}\left[\hat y_{t, low} \leq y_t \leq \hat y_{t, high}\right] $$

- Pour IC à 95% (α=0.95), coverage observé devrait être ≈ 95%
- < 95% → intervalles trop étroits (sous-estimation incertitude)
- \> 95% → trop larges (sur-prudent)

#### Interval Width

Largeur moyenne des intervalles. Trade-off avec coverage.

#### Winkler score

Pénalise width + non-coverage (intégration des deux) :

$$ W_\alpha(y, l, u) = (u - l) + \frac{2}{\alpha}(l - y) \mathbb{1}[y < l] + \frac{2}{\alpha}(y - u) \mathbb{1}[y > u] $$

Métrique single-number pour comparaison fair des intervalles.

#### CRPS (Continuous Ranked Probability Score)

Pour **forecast probabiliste complet** (distribution prédictive $F$) :

$$ \text{CRPS}(F, y) = \int_{-\infty}^{\infty} (F(z) - \mathbb{1}[z \geq y])^2 dz $$

- Généralise MAE aux distributions
- $\text{CRPS}(F, y) = \text{MAE}$ pour forecast déterministe
- Récompense calibration + sharpness conjointement
- Standard en météo (ECMWF), bayésien, deep ensembles
- Pour gaussienne $F = \mathcal{N}(\mu, \sigma)$ : forme close

### Métriques directionnelles

#### MDA (Mean Directional Accuracy)

$$ \text{MDA} = \frac{1}{n-1} \sum_t \mathbb{1}\left[\text{sign}(y_t - y_{t-1}) = \text{sign}(\hat y_t - y_{t-1})\right] $$

- % de fois où la direction (haut/bas) est correcte
- Important en finance, trading, demand
- Baseline = 50% (random)

### Erreurs hiérarchiques (cross-sectional)

En **hierarchical forecasting** (top-level, regional, SKU), on évalue à chaque niveau séparément + cohérence des prédictions agrégées (reconciliation).

### Tableau récap

| Métrique | Echelle | Robuste à 0 | Probabiliste | Comparable entre séries |
|---|---|:-:|:-:|:-:|
| MAE | unité y | ✓ | ✗ | ✗ |
| RMSE | unité y | ✓ | ✗ | ✗ |
| MAPE | % | ✗ | ✗ | ✓ |
| sMAPE | % | ~ | ✗ | ✓ |
| WAPE | % | ✓ | ✗ | ✓ |
| MASE | scalée | ✓ | ✗ | ✓ |
| Bias / CFE | unité y | ✓ | ✗ | ✗ |
| Pinball | unité y | ✓ | ✓ | ✗ |
| Coverage | % | ✓ | ✓ | ✓ |
| CRPS | unité y | ✓ | ✓ | ✗ |
| MDA | % | ✓ | ✗ | ✓ |

### Best practices

1. **Reporter plusieurs métriques** : un MAE bas + MASE > 1 = pire que naïve → mauvais modèle
2. **MASE pour les M-comp / benchmark** : ratio vs naïve interprétable
3. **WAPE pour le business retail** : standard de facto
4. **Bias toujours** : un modèle non-biaisé peut être préférable à un avec MAPE plus bas mais biaisé
5. **Pinball + coverage** pour le probabiliste
6. **Évaluer en walk-forward** : voir [[Walk-forward CV]] (jamais KFold sur TS)
7. **Évaluer par horizon h** : MAPE peut être ok à h=1 mais exploser à h=12

## Quand c'est utile

- **Forecasting de toutes natures** : retail, énergie, finance, traffic, météo
- **M-competitions, benchmarks** : MASE / OWA (Overall Weighted Average)
- **Demand planning** : WAPE + bias + coverage des intervalles
- **Anomaly detection sur résidus** : CFE diverge → drift
- **Choix d'horizon** : MAPE vs h pour calibrer business cycle
- **Comparaison entre modèles** : MASE car cross-series

## Quand ça ne marche pas / pièges

- **MAPE sur intermittent** (zéros) : division par zéro → utiliser MASE ou WAPE
- **Une métrique unique** : un seul nombre cache le profil temporel des erreurs. Plotter erreurs vs temps + erreurs vs horizon h.
- **Évaluation in-sample** : ne dit rien sur la généralisation. **Walk-forward seul valide**.
- **Naive baseline manquante** : sans MASE, on ne sait pas si le modèle vaut la peine vs predict-last.
- **Ignorer le biais** : MAPE 5% mais biais +3% = sur-stock systématique
- **Calibration des intervalles ignorée** : coverage 70% sur IC nominal 95% = modèle confident mais faux
- **Comparer modèles entraînés sur loss différents** : un GBM avec quantile loss vs MSE → choisir le bon métrique pour chaque
- **Horizon-aggregated metrics** : moyenne sur h=1..12 cache un modèle bon à court mais mauvais à long
- **Test set non-représentatif** : si test contient un Black Friday non vu en train, tous les modèles vont mal scorer
- **Évaluation sur log-transformed metric** : reporter dans l'unité business, pas en log

## Code minimal

```python
import numpy as np
import pandas as pd

# Setup : série mensuelle, baseline saisonnier
np.random.seed(0)
y_true = np.array([100, 110, 130, 120, 115, 105, 100, 95, 105, 120, 135, 130])
y_pred = np.array([95, 115, 125, 125, 118, 100, 105, 100, 110, 115, 130, 135])
y_train = y_true  # pour computing MASE
m = 12  # saisonnalité

# Erreurs ponctuelles
mae = np.mean(np.abs(y_true - y_pred))
rmse = np.sqrt(np.mean((y_true - y_pred)**2))
mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
smape = np.mean(2 * np.abs(y_true - y_pred) / (np.abs(y_true) + np.abs(y_pred))) * 100
wape = np.sum(np.abs(y_true - y_pred)) / np.sum(np.abs(y_true)) * 100

# MASE
def mase(y_true, y_pred, y_train, m=1):
    naive_mae = np.mean(np.abs(y_train[m:] - y_train[:-m]))
    return np.mean(np.abs(y_true - y_pred)) / naive_mae

mase_val = mase(y_true, y_pred, y_train, m=1)  # naive = lag-1

# Bias
me = np.mean(y_true - y_pred)
cfe = np.sum(y_true - y_pred)
tracking_signal = cfe / mae

print(f"MAE   = {mae:.2f}")
print(f"RMSE  = {rmse:.2f}")
print(f"MAPE  = {mape:.2f}%")
print(f"sMAPE = {smape:.2f}%")
print(f"WAPE  = {wape:.2f}%")
print(f"MASE  = {mase_val:.3f}  (< 1 = mieux que naïve)")
print(f"Bias  = {me:+.2f}")
print(f"CFE   = {cfe:+.2f}")
print(f"TS    = {tracking_signal:+.2f}")

# Probabiliste : quantiles 10%, 50%, 90%
y_q10 = y_pred - 10
y_q90 = y_pred + 10

# Pinball loss
def pinball(y, yhat, tau):
    r = y - yhat
    return np.mean(np.maximum(tau * r, (tau - 1) * r))

# Coverage interval 80%
in_interval = (y_true >= y_q10) & (y_true <= y_q90)
coverage = in_interval.mean()
width = np.mean(y_q90 - y_q10)

print(f"Pinball@0.5 = {pinball(y_true, y_pred, 0.5):.2f}")
print(f"Pinball@0.9 = {pinball(y_true, y_q90, 0.9):.2f}")
print(f"Coverage 80% nominal = {coverage*100:.1f}%, mean width = {width:.1f}")

# Winkler score
alpha = 0.2  # interval 80%
def winkler(y, l, u, alpha):
    width = u - l
    below = (l - y) * (y < l) * (2 / alpha)
    above = (y - u) * (y > u) * (2 / alpha)
    return np.mean(width + below + above)

print(f"Winkler = {winkler(y_true, y_q10, y_q90, alpha):.2f}")

# CRPS pour forecast gaussien
from scipy import stats
def crps_gaussian(y, mu, sigma):
    z = (y - mu) / sigma
    return sigma * (z * (2 * stats.norm.cdf(z) - 1) + 2 * stats.norm.pdf(z) - 1/np.sqrt(np.pi))

mu, sigma = y_pred, np.full_like(y_pred, 8.0, dtype=float)
print(f"CRPS (gauss) = {crps_gaussian(y_true, mu, sigma).mean():.3f}")

# MDA
def mda(y, yhat):
    dy = np.diff(y)
    dyhat = np.diff(yhat)
    return (np.sign(dy) == np.sign(dyhat)).mean()

print(f"MDA = {mda(y_true, y_pred)*100:.1f}%")

# Evaluation per-horizon (typique en walk-forward)
horizons = pd.DataFrame({'h': range(1, len(y_true)+1),
                          'error': y_true - y_pred,
                          'abs_err': np.abs(y_true - y_pred)})
print(horizons.groupby('h').agg({'abs_err': 'mean'}).head())
```

## Pour aller plus loin

- Hyndman & Koehler, *Another look at measures of forecast accuracy* (IJF 2006) — paper de référence MASE
- Hyndman & Athanasopoulos, *Forecasting: Principles and Practice* (3e éd.) — chap. 5 entier sur metrics
- Makridakis et al., *M5 accuracy competition* (2020) — review WSPL / RMSSE
- Gneiting & Raftery, *Strictly Proper Scoring Rules, Prediction, and Estimation* (JASA 2007) — CRPS, log score
- **Liens internes** : [[Regression metrics]], [[Walk-forward CV]], [[Forecasting framing]], [[Stationarity]], [[Autocorrelation]], [[Evaluer un modele forecast]]
