---
galaxie: dev
nom: pyDMNrules
alias: [pyDMNrules, py-dmn-rules, dmn-python]
categorie: decision/engine
sous_categories: [dmn, python, rules-engine, excel, feel]
licence: MIT
licence_type: open-source
hosted: self
maturite: production (small community)
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[Camunda]] (via REST)", "[[Drools]] (via REST)", "[[OpenL Tablets]] (via REST)", "py-dmn-engine", "decisionrules.io API"]
remplace: []
remplace_par: []
created: 2026-05-21
modified: 2026-05-21
status: actif
tags: [service, python, dmn, rules-engine]
url_officiel: https://pydmnrules.readthedocs.io/
url_docs: https://pydmnrules.readthedocs.io/en/latest/
url_repo: https://github.com/russellmcdonell/pyDMNrules
---

# pyDMNrules

## Pourquoi

**Implémentation DMN en Python pur** par Russell McDonell. Permet d'évaluer des decision tables DMN **sans JVM**, directement dans un script ou service Python. Version courante en 2026 : **1.4.4**. Support partiel mais pratique de **FEEL** (S-FEEL + une grande partie de FEEL complet), input via **Excel** (.xlsx avec un format spécifique) ou **XML DMN**.

Pour le profil **DS/ML/AI eng** : c'est **le** moyen d'intégrer du DMN dans un pipeline Python sans dépendre d'une JVM externe. Combo naturel avec FastAPI / Streamlit / Jupyter pour exposer une décision DMN comme service Python. Limites : couverture FEEL incomplète, performance modérée (Python pur), pas le niveau de rigueur du DMN TCK que Camunda/Drools offrent.

Alternative récente : il existe aussi un **`pydmnrules-mcp-server`** (MCP server qui expose pyDMNrules pour agents Claude/LLM) — utile pour intégrer DMN dans des workflows IA.

## Quand l'utiliser

- **Stack Python pure** : pas envie de monter une JVM juste pour évaluer une DMN
- **Notebooks Jupyter** : prototyper rapidement une décision DMN sur des données pandas
- **Microservices Python (FastAPI / Flask)** : embarquer DMN dans ton service
- **Data scientists qui veulent toucher au DMN** : Excel input, courbe minimale
- **Prototypage / POC** : valider une stratégie DMN avant de passer en Camunda
- **Pipelines ML Python** : combiner ML predict + DMN dans le même script (cf. [[DMN and ML hybrid]])
- **Combo Streamlit** : UI rapide pour qu'un business analyst modifie la decision table Excel et voit le résultat
- **MCP integration** : exposer DMN comme tool pour agents LLM via `pydmnrules-mcp-server`

## Quand NE PAS l'utiliser

- **Production critique à haute fréquence** : Python pur sera 10-100x plus lent que Drools/Camunda Java compilé
- **DMN conformance maximum** : non-100% TCK, certaines features FEEL avancées peuvent manquer → préférer Camunda / Drools
- **Stack Java existante** : si tu as déjà JVM, prends [[Camunda]] ou [[Drools]]
- **BPMN intégré** : pyDMNrules est DMN-only, pas de workflow
- **Concurrency forte** : Python GIL limite, pour 1000+ rps préférer engines compilés
- **Support enterprise** : projet maintenu par 1-2 devs, pas de SLA commercial
- **DMN avec BKM complexes / contexts profonds** : couverture FEEL partielle

## Pièges connus

- **Couverture FEEL partielle** : la doc liste ce qui est supporté, vérifier que tes expressions FEEL passent (notamment list comprehensions complexes, certains datetime corner cases)
- **Format Excel spécifique** : pas n'importe quelle decision table Excel — convention `Decisions`, `RuleSets`, `Definitions`, `Glossary` tabs. Voir la doc
- **Erreurs FEEL peu explicites** : message d'erreur peut être obscur sur expression mal formée
- **Pas de Modeler visuel** : tu édites en Excel ou XML, pas de drag-drop DMN graphique (utiliser Camunda Modeler pour générer le XML puis charger)
- **Maintenance par 1 dev principal** : risque bus factor — fork [paudan/pyDMNrules](https://github.com/paudan/pyDMNrules) existe
- **Performance** : pour > 1000 décisions/seconde, c'est limite — préférer engines compilés
- **DRD limité** : pas de visualisation native du DRD, focus sur l'exécution
- **Pas de hot-reload** : changer le DMN → recharger le module / restart service
- **Pas de versioning natif** : à toi de gérer le versionning des fichiers .xlsx/.dmn
- **Hit policies** : la plupart supportées (U, A, F, C, P) — vérifier les rares P avec output ordering
- **DMN 1.5 features récentes** : non supportées (DMN 1.3 / 1.4 partiel)
- **Documentation parfois sommaire** : examples peu nombreux comparé à Camunda

## Code minimal

### Installation

```bash
pip install pyDMNrules
# Ou la dernière version directement depuis GitHub :
pip install git+https://github.com/russellmcdonell/pyDMNrules
```

### Decision Table en Excel

Créer un fichier `credit.xlsx` avec ces onglets (convention pyDMNrules) :

**Tab `Glossary`** :
```
| Variable           | Business Concept | Attribute  |
|--------------------|------------------|------------|
| Customer Age       | Customer         | age        |
| Customer Income    | Customer         | income     |
| ML Score           | Prediction       | score_ml   |
| Eligibility        | Decision         | result     |
```

**Tab `Decisions`** :
```
| Decisions    | Execute Decision Tables |
|--------------|--------------------------|
| Find Eligibility | Eligibility           |
```

**Tab `Eligibility`** (la decision table) :
```
Eligibility    U
| Customer Age | Customer Income | ML Score    | Eligibility               |
| < 25         | -               | -           | "refused"                 |
| [25..65]     | > 30000         | > 0.7       | "accepted"                |
| [25..65]     | [15000..30000]  | -           | "accepted_with_guarantor" |
| [25..65]     | < 15000         | -           | "refused"                 |
| > 65         | > 50000         | > 0.6       | "accepted"                |
| > 65         | -               | -           | "refused"                 |
```

### Charger et évaluer

```python
from pyDMNrules import DMN

dmn = DMN("credit.xlsx")

# Évaluer
status, data = dmn.decide({
    "Customer": {"age": 35, "income": 25000},
    "Prediction": {"score_ml": 0.78},
})

if status["status"] == "no errors":
    print(data["Decision"]["Eligibility"])    # "accepted_with_guarantor"
else:
    print("Errors:", status["errors"])
```

### Combo ML + DMN dans un pipeline Python

```python
import xgboost as xgb
import pickle
from pyDMNrules import DMN

# Modèle ML pré-entraîné
with open("credit_xgb.pkl", "rb") as f:
    model = pickle.load(f)

# DMN
dmn = DMN("credit_decision.xlsx")

def decide_credit(customer: dict, request: dict) -> dict:
    # Features ML
    features = build_features(customer, request)
    score = float(model.predict_proba(features)[0][1])

    # DMN
    status, data = dmn.decide({
        "Customer": {"age": customer["age"], "income": customer["income"]},
        "Prediction": {"score_ml": score},
        "Request": {"amount": request["amount"]},
    })

    return {
        "decision": data["Decision"]["Eligibility"],
        "ml_score": score,
        "audit": status,
    }
```

### Exposer en FastAPI

```python
from fastapi import FastAPI
from pyDMNrules import DMN

app = FastAPI()
dmn = DMN("credit.xlsx")

@app.post("/decide")
def decide(payload: dict):
    status, data = dmn.decide(payload)
    if status["status"] != "no errors":
        return {"errors": status["errors"]}, 400
    return {"decision": data["Decision"]["Eligibility"], "audit": status}
```

### MCP server pyDMNrules (intégration agents LLM)

```bash
# Exposer un DMN comme tool MCP pour agents Claude/LLM
pip install pydmnrules-mcp-server
# Configurer dans claude_desktop_config.json
```

```json
{
  "mcpServers": {
    "dmn-credit": {
      "command": "python",
      "args": ["-m", "pydmnrules_mcp_server", "--dmn-file", "/path/to/credit.xlsx"]
    }
  }
}
```

L'agent Claude peut alors invoquer la décision DMN comme un tool.

### Évaluation batch sur DataFrame pandas

```python
import pandas as pd
from pyDMNrules import DMN

dmn = DMN("credit.xlsx")
df = pd.read_csv("applicants.csv")

def apply_dmn(row):
    status, data = dmn.decide({
        "Customer": {"age": row["age"], "income": row["income"]},
        "Prediction": {"score_ml": row["score_ml"]},
    })
    return data["Decision"]["Eligibility"]

df["decision"] = df.apply(apply_dmn, axis=1)
print(df["decision"].value_counts())
```

### Charger un XML DMN standard (au lieu d'Excel)

```python
# pyDMNrules supporte aussi le XML DMN OMG (avec limitations)
dmn = DMN("credit.dmn")     # Format XML DMN OMG
status, data = dmn.decide({"age": 35, "income": 25000})
```

## Liens

- [[Camunda]] — alternative Java production-grade (via REST si depuis Python)
- [[Drools]] — alternative Java open-source
- [[OpenL Tablets]] — alternative Excel-friendly avec engine Java
- [[Decision Model and Notation]] / [[Decision Tables]] / [[FEEL]] — concepts DMN
- [[DMN and ML hybrid]] — pattern combiné avec ML
- decisionrules.io — alternative SaaS Python-friendly (REST API)
- Fork paudan/pyDMNrules — autre maintien : https://github.com/paudan/pyDMNrules
- pydmnrules-mcp-server — MCP integration
- Docs : https://pydmnrules.readthedocs.io/
- GitHub : https://github.com/russellmcdonell/pyDMNrules
- PyPI : https://pypi.org/project/pyDMNrules/
