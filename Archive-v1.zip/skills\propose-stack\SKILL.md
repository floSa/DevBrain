---
name: propose-stack
description: |
  Use this skill at the start of a new project, when the user wants a
  technology stack proposal based on their DevBrain. Triggers: "propose
  un stack", "quel stack pour ce projet", "aide-moi à choisir les services".
  Reads Services + Patterns from devbrain via MCP, returns a motivated stack.
---

# Skill — propose-stack

## Quand l'utiliser

L'utilisateur démarre un **nouveau projet** et veut une suggestion de stack motivée par le contenu du brain (Services, Patterns, Rules). Cas typiques :
- "propose un stack pour <type de projet>"
- "quel stack pour ce besoin"
- "aide-moi à choisir les services"

Distinct de :
- `add-pattern` (formalise une stack en pattern réutilisable)
- `compare-services` (compare 2-3 services dans une catégorie précise)
- `add-service` (création d'une seule fiche)

## Pré-requis vault

Mode build ou project. Lit `Services/`, `Patterns/`, `Rules/` mais n'écrit rien dans le brain (la sortie est verbale ou destinée à un README projet).

## Procédure

### Étape 1 — Cerner le besoin
Pose ces questions si l'utilisateur ne les a pas couvertes :
1. Type de projet ? (CLI / Web app / Library / ML / Data pipeline)
2. Charge attendue ? (toy / SaaS petit / SaaS gros)
3. Contraintes spéciales ? (offline-first, GDPR, on-prem only, equipe maitrise X…)
4. Stack préféré ou ouvert ?

## Étape 2 — Chercher des Patterns existants
- Y a-t-il un `Patterns/Pattern - <type>.md` qui matche ? Si oui, **pars de là**.
- Cherche dans `Patterns/` les blueprints réutilisables pour le type de projet.

## Étape 3 — Compléter avec les Comparatifs
Pour chaque besoin (DB, framework, auth, jobs, etc.) :
- Lis le Comparatif Bases pertinent (`Patterns/Comparatif - <type>.base`).
- Filtre par `score >= 4`, `mes_projets` non vide (services déjà testés).
- Présente 2-3 options.

## Étape 4 — Présenter
Format de la proposition :

```markdown
## Stack proposé

### Backend : <X>
**Pourquoi** : <2 lignes basées sur Services/<X>.md>
**Alternatives écartées** : <Y> (raison), <Z> (raison)

### DB : <X>
[...]

### Auth : <X>
[...]

[...]

## Patterns appliqués
- [[Pattern - <Y>]]

## Risques connus
- (depuis `Bugs/REX - <X>.md` s'il existe) : <piège majeur à anticiper>
```

## Étape 5 — Itérer
Demande feedback. Adapte. Quand validé, écris dans `Projects/<projet>/Stack.md`.

## Voir aussi

- `add-pattern` (formaliser le stack proposé comme pattern réutilisable)
- `compare-services` (zoomer sur 2-3 services concurrents dans une catégorie)
- `add-service` (si un service utile manque dans le brain)
- `doc-service` (documenter chaque service intégré dans le projet une fois lancé)

## Anti-patterns

- Proposer un service sans fiche dans le brain (= choix non justifié).
- Choisir uniquement par hype (préfère ce qui a été testé : `mes_projets` non vide).
- Ignorer les contraintes (équipe, légal, infra).
