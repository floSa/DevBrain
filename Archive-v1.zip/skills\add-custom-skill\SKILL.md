---
name: add-custom-skill
description: |
  Use this skill to bootstrap a new custom executable skill in
  AI/skills/<nom>/SKILL.md. Triggers: "crée un skill", "ajoute un skill
  custom", "bootstrap un skill <nom>", "j'ai un prompt récurrent à
  transformer en skill". Generates SKILL.md compliant with Anthropic's
  format (name + description triggers + procedure), with the right
  conventions for DevBrain (galaxie cible, sub-skills invocation).
---

# Skill — add-custom-skill

## Quand l'utiliser

L'utilisateur veut créer **un nouveau skill exécutable** dans `AI/skills/`. Cas typiques :
- "J'ai un prompt récurrent que je veux automatiser"
- "Ajoute un skill `xxx` qui fait Y"
- "Bootstrap un skill pour orchestrer Z"

C'est le skill **méta** pour créer d'autres skills.

## Pré-requis vault

Mode build (les SKILL.md vivent dans AI/skills/, espace agent). Mais l'utilisateur peut le demander en n'importe quel mode — c'est de la production de méta-config.

## Procédure

### 1. Identifier l'intention

Demander à l'utilisateur :
- **Nom** du skill (slug en kebab-case : `process-inbox`, `add-pattern`)
- **Galaxie cible** : `dev | wiki | meta`. Détermine la sémantique.
- **Trigger** : quelles phrases utilisateur doivent déclencher ce skill ?
- **But en 1 phrase** : qu'est-ce qu'il fait ?

### 2. Vérifier la non-duplication

Cherche `AI/skills/<nom>/SKILL.md`. Si existe, propose une mise à jour (pas couvert ici, refactor manuel ou via `validate-skill`).

### 3. Format de description Anthropic — strict

La `description:` est ce que l'agent lit pour décider d'invoquer le skill. Elle DOIT contenir :
1. **Une formulation "Use this skill to/when..."** au début
2. **Des triggers explicites** : "Triggers: '...', '...', or when ..."
3. **L'effet** : ce qu'il produit
4. **(Optionnel)** : exceptions, contraintes

Mauvais : `description: "Skill pour ajouter une fiche."`
Bon : `description: "Use this skill to add a new Service fiche to DevBrain. Triggers: 'ajoute le service X', 'documente Y', or when the user provides a URL. Generates a fiche compliant with the schema in Services/<Cat>/."`

### 4. Frontmatter SKILL.md

```yaml
---
name: <slug en kebab-case>
description: |
  Use this skill to <verbe d'action>. Triggers: "<phrase 1>", "<phrase 2>",
  or when <condition contextuelle>. Generates/Modifies/... <produit>.
  <Contraintes éventuelles, ex: mode requis, périmètre>.
---
```

> ⚠️ **Pas** de champ `galaxie:` dans le frontmatter d'un SKILL.md — ce frontmatter suit le format Anthropic strict (name + description uniquement).

### 5. Corps en sections fixes

Structure DevBrain :

```markdown
# Skill — <nom>

## Quand l'utiliser
<1-2 paragraphes, exemples de phrases utilisateur, distinction avec skills cousins>

## Pré-requis vault
<mode requis, périmètre filesystem, droits>

## Procédure
1. **Localiser/Identifier** — première étape
2. **Demander la matière** — récolter l'info
3. **Préserver/Construire** — assembler
4. **Mettre à jour le frontmatter** — modified: today
5. **Wikilinker** — chercher les références liées
6. **Montrer le diff** — toujours valider avant écriture
7. **Écrire** — path précis

## Anti-patterns à éviter
- 

## Voir aussi
- skills cousins
- templates utilisés
```

### 6. Validation

Avant de créer, invoque mentalement `validate-skill` : checke que la description respecte le format Anthropic. Sinon, retravaille.

### 7. Demander validation utilisateur, puis écrire

Path : `AI/skills/<nom>/SKILL.md`.

### 8. Mettre à jour CLAUDE.md et README.md

Ajouter une ligne au tableau des skills disponibles (CLAUDE.md section "Skills disponibles" + README.md section équivalente).

## Anti-patterns à éviter

- **Skill trop générique** (ex. "skill qui aide l'utilisateur") → description illisible, déclenche mal
- **Pas de triggers explicites** dans la description → agent ne sait pas quand l'invoquer
- **Skill qui touche plusieurs galaxies** → split en 2 skills
- **Sous-skill mal référencé** : si le nouveau skill délègue à `add-service`, le mentionner explicitement
- **Oublier d'ajouter `galaxie:` ?** Non — les SKILL.md n'ont pas ce champ, leur format est figé par Anthropic
- **Mettre du code Python ou bash long** dans le SKILL.md → c'est une description procédurale, pas du code exécutable

## Voir aussi

- `validate-skill` (linter pour vérifier le SKILL.md créé)
- `list-skills` (voir l'inventaire pour ne pas dupliquer)
- `anthropic-skills:skill-creator` (skill officiel Anthropic, équivalent plus complet)
