---
galaxie: wiki
nom: simplify
type: claude-code-skill
plateforme: claude-code
categorie: skill/code-quality
sous_categories: [refactor, dry, code-review]
auteur: Anthropic
source: claude-code natif
source_url: https://docs.claude.com/en/docs/claude-code
install_cmd: 
install_doc: 
licence: 
licence_type: proprietary
domaines: [data-eng, mlops, ml-eng, ai-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, refactor, dry]
---

# simplify

## Pourquoi

Skill **bundled** qui **review le code changé pour la qualité et la réutilisabilité** : détecte les duplications avec du code existant, propose des simplifications, applique les corrections.

Différent de [[claude-review]] (qui regarde tout l'éventail review PR) et [[claude-security-review]] (qui se focalise sécu) : `simplify` est focalisé sur **DRY et clarté** du code que tu viens d'écrire.

## Quand l'utiliser

- Tu as ajouté une nouvelle fonction et tu veux check si elle dupplique un truc qui existe
- Refactor d'un module : "simplifie ce fichier"
- Avant un commit, pour faire un pass de cleanup auto
- Apprentissage : voir comment l'agent réécrirait ton code

## Quand NE PAS l'utiliser

- Code temporaire / POC où tu vas re-refactor de toute façon
- Notebook d'exploration data — la duplication y est souvent voulue (clarté pédagogique)

## Comment l'installer

Natif Claude Code, déclenchable via `/simplify` ou "simplifie ce code".

## Exemples d'usage

```
> /simplify
> simplifie src/pipeline.py — il y a des trucs dupliqués
> review et simplifie les changements depuis le dernier commit
```

## Pièges connus

- Peut sur-factoriser (extraire une "abstraction" trop précoce). Toujours valider ses propositions.
- Sur du code data/ML, certains "doublons" sont en fait des paths divergents intentionnellement.

## Liens

- Doc Claude Code : https://docs.claude.com/en/docs/claude-code
- [[claude-review]] (revue PR globale)
