---
galaxie: dev
nom: pingouin
alias: [pingouin]
categorie: tooling/stats
sous_categories: [stats, statistical-tests, python, effect-sizes, bayesian]
licence: GPL-3.0
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["statsmodels", "scipy.stats", "R (base + tidyverse)"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, stats, hypothesis-testing]
url_officiel: https://pingouin-stats.org/
url_docs: https://pingouin-stats.org/build/html/index.html
url_repo: https://github.com/raphaelvallat/pingouin
---

# pingouin

## Pourquoi

Library Python de **tests statistiques pandas-friendly** : t-tests, ANOVA (à mesures répétées, mixed), corrélations (Pearson, Spearman, Kendall, partial), MANOVA, ANCOVA, **effect sizes** (Cohen d, Hedges g, η², ω²), **power analysis**, **Bayes factors** simples, mixed models, normality / homoscedasticity tests.

Wrapper élégant au-dessus de `scipy.stats` + `statsmodels` : retourne des **DataFrames pandas** structurés (test name, p-value, effect size, CI), pas des tuples obscurs. Cible : **sciences sociales, médical, psychologie, biologie** où il faut produire des analyses stat reproductibles avec effect sizes (exigence éditeurs scientifiques).

## Quand l'utiliser

- **Analyse stats reproductible** : output pandas, prêt à publier
- **Effect sizes** systématiquement (Cohen d, Hedges g, partial η²)
- **ANOVA répétées / mixed designs** : `pg.rm_anova`, `pg.mixed_anova` plus simples que statsmodels
- **Corrélations avancées** : partielle, semi-partielle, distance correlation
- **Tests Bayesian simples** : Bayes factor pour t-test, corrélation
- **Power analysis** : calculer N requis pour détecter un effet
- **Pairwise tests + corrections** : Bonferroni, Holm, Sidak, FDR automatiques
- **Plotting stats** : QQ plots, paired plots intégrés

## Quand NE PAS l'utiliser

- **Modèles purs (GLM, mixed effects complexes, time series, GARCH)** → `statsmodels` plus complet
- **ML / classification / régression prédictive** → [[scikit-learn]]
- **R workflow** : pingouin moins riche que les packages R (`lme4`, `afex`, `BayesFactor`)
- **Tests très bas niveau / scipy** : `scipy.stats` direct OK
- **Licence permissive obligatoire** : GPL-3.0 → utiliser scipy.stats / statsmodels (BSD)

## Pièges connus

- **Licence GPL-3.0 contagieuse** : bibliothèques tierces qui embarquent pingouin doivent être GPL → check compliance
- **Moins de tests que statsmodels** : pas de GLM family complète, pas de time series
- **Bayes factors limités** : BF simple via JZS, pas de Stan/PyMC sous le capot
- **Maintenance par 1 dev principal** (Raphael Vallat) : risque bus factor
- **DataFrames format wide vs long** : pingouin attend du long format pour rm_anova, à pivot
- **Multiple comparison correction** : Bonferroni default parfois trop conservatif → préciser `padjust='fdr_bh'`
- **`pg.ttest` retourne effect size mais avec convention différente** selon paired/unpaired
- **Mixed models limités** : pingouin a un peu de mixed ANOVA, mais lme4-like complet = statsmodels MixedLM
- **Pas de support données manquantes** explicite : dropna à faire avant

## Code minimal

```bash
pip install pingouin
```

```python
import pingouin as pg
import pandas as pd

# Donnees exemple : essai medical, 2 groupes
df = pd.DataFrame({
    "group": ["control"] * 30 + ["treatment"] * 30,
    "score": [...],   # 60 valeurs
})

# t-test independants avec effect size + Bayes factor
result = pg.ttest(
    df.loc[df.group == "control", "score"],
    df.loc[df.group == "treatment", "score"],
    paired=False, alternative="two-sided",
)
print(result)
# Colonnes : T, dof, alternative, p-val, CI95%, cohen-d, BF10, power
```

```python
# ANOVA a mesures repetees (long format)
df_rm = pd.DataFrame({
    "subject": list(range(20)) * 3,
    "time": ["pre"] * 20 + ["mid"] * 20 + ["post"] * 20,
    "score": [...],
})

aov = pg.rm_anova(data=df_rm, dv="score", within="time", subject="subject", detailed=True)
print(aov)   # source, ddof1, ddof2, F, p-unc, ng2 (eta carre generalise)

# Post-hoc avec correction
posthoc = pg.pairwise_tests(
    data=df_rm, dv="score", within="time", subject="subject",
    padjust="bonf", effsize="cohen",
)
print(posthoc)
```

```python
# Correlations partielles : effet de age controle
pg.partial_corr(data=df, x="reaction_time", y="score", covar="age",
                method="spearman")

# Power analysis : N pour detecter d=0.5 avec power 0.8
n = pg.power_ttest(d=0.5, power=0.8, alpha=0.05, alternative="two-sided")
print(f"N requis : {n:.0f} par groupe")
```

```python
# Verifications prealables ANOVA
print(pg.normality(df, dv="score", group="group"))         # Shapiro par groupe
print(pg.homoscedasticity(df, dv="score", group="group"))  # Levene
print(pg.sphericity(df_rm.pivot_table(index="subject", columns="time", values="score")))
```

## Liens

- statsmodels — alternative plus complète (GLM, time series, mixed models)
- scipy.stats — backend bas niveau
- R (`lme4`, `afex`, `BayesFactor`) — alternatives R plus riches
- [[Hypothesis testing]] (concept)
- Docs : https://pingouin-stats.org/build/html/index.html
- GitHub : https://github.com/raphaelvallat/pingouin
- Paper : https://joss.theoj.org/papers/10.21105/joss.01026
