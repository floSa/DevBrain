---
galaxie: dev
nom: Ruff
alias: [ruff]
categorie: tooling/lint-format
sous_categories: [linter, formatter, fixer, python]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Rust
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: [flake8 + isort + black, pylint, pycodestyle]
remplace: [flake8, isort, black, pyupgrade, pydocstyle, autoflake]
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, linter, formatter]
url_officiel: https://docs.astral.sh/ruff/
url_docs: https://docs.astral.sh/ruff/
url_repo: https://github.com/astral-sh/ruff
---

# Ruff

## Pourquoi
**Linter + formatter Python en Rust**, par les auteurs de [[uv]] (Astral). Remplace flake8, isort, black, pyupgrade, pydocstyle, autoflake. **10-100x plus rapide** que ces outils. Standard moderne Python depuis 2023-2024.

## Quand l'utiliser
- Tout projet Python neuf
- Migration depuis flake8+isort+black (1 outil au lieu de 3)
- CI rapide (lint en 100ms vs 30s)
- Pre-commit hook (instantané)
- Editor integration (LSP via `ruff-lsp` ou natif VSCode/JetBrains)

## Quand NE PAS l'utiliser
- Stack legacy avec configs flake8/black très custom — migration coûteuse
- Besoin de checks que Ruff ne fait pas (encore rare aujourd'hui)
- Type checking → utiliser pyright/mypy en complément (Ruff ne fait pas typecheck)

## Pièges connus
- **Config** : `[tool.ruff]` dans `pyproject.toml`. Sections `lint` et `format` séparées.
- **Select rules** : par défaut très peu activé. Activer `["E", "F", "I", "B", "UP"]` minimum.
- **Formatter** : `ruff format` (compatible black, depuis 2024). Avant : utiliser black séparément.
- **Auto-fix** : `ruff check --fix` répare automatiquement. Attention si modif d'imports.
- **Conflit avec autres formatters** : choisir un seul (Ruff OU Black, pas les deux)
- **Per-file-ignores** : pratique pour `__init__.py` (ignore F401)

## Liens
- [[uv]] — autre outil Astral, combo naturel
- Docs : https://docs.astral.sh/ruff/
- Rules : https://docs.astral.sh/ruff/rules/
- Migration depuis flake8 : https://docs.astral.sh/ruff/migration/
