---
galaxie: dev
nom: SQLite
alias: [sqlite, sqlite3]
categorie: database/relational
sous_categories: [embedded, sql, single-file, oltp]
licence: Public domain
licence_type: open-source
hosted: self
maturite: production
langage: C
clients_officiels: [python, ts, go, rust, java, ruby, php]
plateforme: [linux, macos, windows, android, ios, browser]
score: 5
mes_projets: []
alternatives: ["[[Postgres]]", DuckDB (analytique), libSQL, Turso]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, database, sql, embedded]
url_officiel: https://www.sqlite.org/
url_docs: https://www.sqlite.org/docs.html
url_repo: https://sqlite.org/src/
---

# SQLite

## Pourquoi
Base SQL **embedded** : un seul fichier, zéro setup, zéro daemon. La DB la plus déployée au monde (téléphones, browsers, apps). Parfaite pour single-writer apps, prototypes, tests, edge.

## Quand l'utiliser
- App desktop / mobile / embedded
- Prototype rapide sans infra DB
- Tests d'intégration (in-memory : `:memory:`)
- Stockage de config / cache local
- Edge computing, IoT
- Dataset analytique read-only à déployer (sidecar)

## Quand NE PAS l'utiliser
- Multi-writer concurrent (1 writer à la fois — sérialisation)
- Charge serveur web haute concurrence → [[Postgres]]
- Analytique OLAP volumineuse → [[DuckDB]] (même API single-file, mieux fait pour ça)
- Backups / réplication critique → [[Postgres]] managed
- Multi-machine sync → libSQL / Turso (fork SQLite avec sync)

## Pièges connus
- **WAL mode** : activer (`PRAGMA journal_mode = WAL;`) pour permettre lectures concurrentes pendant écriture
- **Foreign keys** : OFF par défaut, activer (`PRAGMA foreign_keys = ON;`)
- **Types dynamiques** : SQLite ignore largement les types déclarés (STRICT tables depuis 3.37 pour fix)
- **Backups à chaud** : utiliser `.backup` ou WAL checkpoint, pas un `cp` brut
- **Locks Windows** : fichier locké tant qu'une connection ouverte, peut bloquer
- **Limite réelle** : marche bien jusqu'à ~100 GB et ~100K writes/sec sur SSD

## Liens
- [[Postgres]] — pour le mode serveur
- [[DuckDB]] — pour l'analytique single-file
- libSQL / Turso (fork avec sync) : https://turso.tech/
- Doc : https://www.sqlite.org/lang.html
- "When to use SQLite" : https://www.sqlite.org/whentouse.html
