---
galaxie: dev
nom: KServe
alias: [kserve, kfserving]
categorie: ml/serving
sous_categories: [serving, kubernetes, cncf, kubeflow, knative, autoscaling]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python / Go
clients_officiels: [python, http, grpc]
plateforme: [linux]
score: 4
mes_projets: []
alternatives: ["[[Seldon Core]]", "[[BentoML]]", "[[Ray Serve]]", "[[NVIDIA Triton]]"]
remplace: ["KFServing"]
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, serving, kubernetes, cncf]
url_officiel: https://kserve.github.io/website/
url_docs: https://kserve.github.io/website/master/
url_repo: https://github.com/kserve/kserve
---

# KServe

## Pourquoi

**Standard CNCF de model serving Kubernetes-native** (anciennement KFServing, sous Kubeflow, rebrandé KServe en 2021 et sorti en projet indépendant). Le concept central : la **CRD `InferenceService`** — une seule ressource K8s qui déclare "j'ai un modèle, sers-le". KServe s'occupe du reste : autoscale via **KNative**, mTLS via Istio, routing, transformers, explainers.

Vs **Seldon Core** : KServe est plus **simple, plus actif côté communauté CNCF**, et **Apache-2.0 strict** (Seldon v2 est BSL). Ne couvre pas les inference graphs complexes comme Seldon mais a tout ce qu'il faut pour 90% des cas. **ModelMesh** (sous-projet KServe) gère du **multi-model serving** dense (10k+ modèles sur un même pod).

## Quand l'utiliser

- **Stack Kubeflow / Kubernetes** : KServe est le serving officiel Kubeflow
- **Auto-scale to zero** : KNative laisse à zéro quand pas de trafic (free quand idle)
- **Multi-framework** : sklearn, XGBoost, PyTorch, TF, ONNX, HuggingFace, Triton, MLflow, custom
- **Standard CNCF ouvert** non-vendor
- **ModelMesh** : densité haute (10k+ modèles partageant des pods)
- **GitOps friendly** : `InferenceService` YAML versionné
- **Combo Triton** : KServe orchestre, Triton sert les GPUs
- **LLM serving via HuggingFace runtime** : KServe a un runtime HF natif (2024+)

## Quand NE PAS l'utiliser

- **Pas de K8s** → [[BentoML]] / [[Ray Serve]] / cloud managed
- **Inference graphs complexes** (A/B, ensemble multi-niveau) → [[Seldon Core]] plus avancé
- **LLM dédié haute perf** → [[vLLM]] / [[SGLang]] / [[TGI]] direct, KServe wrappe vLLM mais ajoute une couche
- **Petite équipe sans plateforme K8s** : overhead opérationnel important
- **Latence ultra-critique avec scale-to-zero** : cold start KNative = 5-30s

## Pièges connus

- **Setup K8s + KNative + (Istio ou Kourier) + cert-manager** : pile lourde
- **Cold start** : scale-to-zero = latence premier appel élevée → garder `minReplicas: 1` en prod
- **Doc moins riche** que Seldon historiquement (rattrape depuis 2023)
- **Predictor / Transformer / Explainer concepts** à apprendre
- **Multi-modèle (ModelMesh) ≠ KServe classic** : architectures différentes, ne pas confondre
- **Storage URI requis** : modèles servis depuis GCS / S3 / PVC, pas embed
- **Knative quirks** : `revisions`, traffic split — encore une couche à maîtriser
- **GPU scheduling** : pas magique, prévoir node selectors / tolerations / device plugin
- **gRPC vs REST** : KServe v1 protocol (REST) vs v2 (REST + gRPC, OIP standardisé) → choisir tôt

## Code minimal

```bash
# Install (Helm)
helm install kserve oci://ghcr.io/kserve/charts/kserve --version v0.13.0 -n kserve --create-namespace
```

```yaml
# InferenceService : sklearn model from GCS
apiVersion: serving.kserve.io/v1beta1
kind: InferenceService
metadata:
  name: sklearn-iris
  namespace: kserve-test
spec:
  predictor:
    minReplicas: 1
    maxReplicas: 3
    sklearn:
      storageUri: "gs://kfserving-examples/models/sklearn/1.0/model"
      resources:
        requests: {cpu: "100m", memory: "256Mi"}
        limits: {cpu: "1", memory: "1Gi"}
```

```yaml
# LLM serving (HuggingFace runtime, 2024+)
apiVersion: serving.kserve.io/v1beta1
kind: InferenceService
metadata:
  name: llama-3-8b
spec:
  predictor:
    model:
      modelFormat: {name: huggingface}
      storageUri: "hf://meta-llama/Meta-Llama-3-8B-Instruct"
      args: ["--backend=vllm", "--max-model-len=4096"]
      resources:
        limits: {nvidia.com/gpu: "1"}
```

```python
# Client : appel V2 protocol REST
import requests

url = "http://sklearn-iris.kserve-test.example.com/v2/models/sklearn-iris/infer"
payload = {
    "inputs": [{
        "name": "input-0", "shape": [1, 4], "datatype": "FP32",
        "data": [[5.1, 3.5, 1.4, 0.2]],
    }],
}
response = requests.post(url, json=payload)
print(response.json())   # {"model_name": "sklearn-iris", "outputs": [...]}
```

## Liens

- [[Seldon Core]] — alternative avec inference graphs avancés
- [[BentoML]] / [[Ray Serve]] — alternatives non-K8s
- [[NVIDIA Triton]] — runtime GPU souvent backend
- [[Kubeflow]] — projet d'origine, combo classique
- ModelMesh — sous-projet KServe pour multi-model serving dense
- Docs : https://kserve.github.io/website/master/
- GitHub : https://github.com/kserve/kserve
