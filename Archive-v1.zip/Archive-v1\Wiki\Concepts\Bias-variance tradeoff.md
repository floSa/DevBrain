---
galaxie: wiki
nom: Bias-variance tradeoff
alias: [biais-variance, bias-variance decomposition]
type: concept
categorie: concept/ml
sous_categories: [generalization, overfitting, underfitting, model-selection]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Geman et al. 1992, Hastie-Tibshirani-Friedman ESL]
lecture_min: 9
created: 2026-05-19
modified: 2026-05-19
tags: [concept, ml, bias-variance, generalization]
---

# Bias-variance tradeoff

## TL;DR

L'erreur de généralisation d'un modèle se décompose en **3 termes** : biais² + variance + bruit irréductible. Augmenter la complexité du modèle **réduit le biais** mais **augmente la variance**, et inversement. Trouver le sweet spot est l'objectif central de la **sélection de modèle**.

## Le problème

Un modèle peut échouer de deux façons :
- **Sous-apprentissage** (underfitting) : trop simple, rate la structure réelle des données (régression linéaire sur une vraie courbe non-linéaire)
- **Sur-apprentissage** (overfitting) : trop complexe, mémorise le bruit du training set, ne généralise pas

Le bias-variance tradeoff formalise cette tension de manière mathématique.

## L'idée

### Décomposition formelle

Soit $y = f(x) + \varepsilon$ avec $\varepsilon$ bruit centré de variance $\sigma^2$. On entraîne un modèle $\hat f$ sur un dataset aléatoire. L'erreur quadratique attendue en un point $x_0$ se décompose :

$$
\mathbb{E}\big[(y - \hat f(x_0))^2\big] = \underbrace{\big(\mathbb{E}[\hat f(x_0)] - f(x_0)\big)^2}_{\text{biais}^2} + \underbrace{\mathrm{Var}[\hat f(x_0)]}_{\text{variance}} + \underbrace{\sigma^2}_{\text{bruit irréductible}}
$$

- **Biais** : écart entre la moyenne des prédictions (sur tous les datasets possibles) et la vraie valeur. Un modèle biaisé se trompe **systématiquement** dans le même sens.
- **Variance** : dispersion des prédictions selon le dataset d'entraînement. Une variance élevée signifie que le modèle est **instable** : un autre échantillon donnerait une prédiction très différente.
- **Bruit** : ce qui est intrinsèquement aléatoire dans le processus générateur. Inatteignable.

### Visualisation en cible

```
  Biais bas, variance basse   |  Biais bas, variance haute
        ● ● ●                   |        ●       ●
        ● centre ●               |        centre
        ● ● ●                   |   ●            ●
  (idéal)                       |  (instable)
                                |
  Biais haut, variance basse  |  Biais haut, variance haute
                                |
        ● ● ●                   |        ●   ●
        centre                  |        centre
   ● ● ●                        |   ●            ●
  (modèle systématiquement faux)|  (le pire)
```

### Lien avec la complexité du modèle

Pour la plupart des familles de modèles :
- Plus de paramètres / capacité → **biais ↓** mais **variance ↑**
- Régularisation forte → **biais ↑** mais **variance ↓**

Courbe en U typique de l'erreur de validation en fonction de la complexité :
- À gauche (modèle simple) : haute erreur de train ET de test → underfitting
- À droite (modèle complexe) : basse erreur de train, haute erreur de test → overfitting
- Au milieu : sweet spot

### Méthodes de résolution

**Réduire le biais** :
- Modèle plus expressif (deep learning, gradient boosting)
- Features plus riches / feature engineering
- Moins de régularisation
- Plus de capacité (couches, profondeur)

**Réduire la variance** :
- Régularisation (L1/L2, dropout, early stopping)
- Plus de données d'entraînement
- Bagging / ensembling (cf. Random Forest, moyenner réduit la variance)
- Sélection de features (réduire les features parasites)

### Cas spécifiques

- **Random Forest** : faible biais (arbres profonds) + variance réduite par bagging
- **Gradient boosting** ([[XGBoost]], [[LightGBM]]) : optimise itérativement, peut overfit mais avec early stopping et régularisation
- **Deep learning** : très faible biais, contrôle la variance par dropout, batch norm, augmentation de données

### Modern caveat : double descent

Pour des modèles très sur-paramétrés (deep nets, certains kernel methods), l'erreur de test peut **rebaisser** après le pic d'overfitting "classique". Phénomène de la **double descent** (Belkin et al. 2019). La courbe en U n'est plus universelle.

## Quand c'est utile

- Diagnostic d'un modèle qui sous-performe : biais ou variance ?
- Choix du modèle / hyperparams (gradient boosting profond vs léger)
- Justification d'ajouter des données (réduit variance)
- Justification de la régularisation (compromis biais-variance)

## Quand ça ne marche pas / pièges

- **La décomposition est exacte pour MSE**, mais s'applique mal aux losses non-quadratiques (cross-entropy, hinge loss). En classification on parle plutôt de bias/variance de manière qualitative.
- **Estimer biais et variance** demande plusieurs datasets — en pratique on les approxime via bootstrap ou validation croisée.
- **Double descent** rend l'intuition "plus de capacité = plus de variance" obsolète en deep learning.
- **Confusion avec underfitting/overfitting** : ce sont des **manifestations** du tradeoff, pas le tradeoff lui-même.

## Code minimal — visualisation du tradeoff

```python
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import learning_curve

np.random.seed(0)
X = np.random.uniform(-3, 3, (200, 1))
y = np.sin(X).ravel() + 0.3 * np.random.randn(200)

# Vary la complexité (max_depth)
depths = range(1, 20)
train_scores, val_scores = [], []
for d in depths:
    model = DecisionTreeRegressor(max_depth=d, random_state=0)
    sizes, train, val = learning_curve(
        model, X, y, cv=5,
        train_sizes=[0.8], scoring='neg_mean_squared_error')
    train_scores.append(-train.mean())
    val_scores.append(-val.mean())

plt.plot(depths, train_scores, label='train')
plt.plot(depths, val_scores, label='val')
plt.xlabel('max_depth (complexité)'); plt.ylabel('MSE')
plt.legend()
```

Tu verras la courbe en U classique sur la validation.

## Implémentations concrètes

- Pas un "outil" mais une **lentille d'analyse** — applicable à tout modèle ML
- En pratique, c'est le concept derrière la validation croisée ([[Walk-forward CV]], KFold)
- Lié à : [[Cross-validation]] (concept à venir), [[ROC AUC]] (eval), Random Forest / [[XGBoost]] / [[LightGBM]] / [[CatBoost]] (modèles)

## Pour aller plus loin

- Hastie, Tibshirani, Friedman, *The Elements of Statistical Learning* (ESL) — chap. 2 et 7, référence
- Geman, Bienenstock, Doursat, *Neural networks and the bias/variance dilemma* (1992) — paper canonique
- Belkin et al., *Reconciling modern machine-learning practice and the classical bias–variance trade-off* (PNAS 2019) — double descent
- **Liens internes** : [[Walk-forward CV]] (mesure du tradeoff en pratique), [[embeddings]] (capacité élevée mais bonne généralisation grâce à pré-entraînement)
