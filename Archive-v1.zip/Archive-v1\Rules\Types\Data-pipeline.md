---
galaxie: dev
type: rule
domaine: data-pipeline
applicable: type-data
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, data, etl, elt]
---

# Règles — Type de projet : Data pipeline

## Principe
**Idempotence**, **lineage**, **qualité contrôlée**. Un rerun = même résultat. Toute donnée a une provenance traçable.

## MUST

- **Idempotence** : rerun d'un job = même résultat. Pas d'effets cumulatifs cachés.
- **Lineage tracé** (dbt, OpenLineage, Marquez) : pour chaque table, savoir d'où viennent les données.
- **Validation de qualité** sur les données entrantes (Great Expectations, Pandera, dbt tests).
- **Backfill possible** et documenté. Tu dois pouvoir relancer une période passée.
- **Idempotency keys** sur les ingestions externes pour éviter les doublons.
- **Coût/perf monitoré** (warehouse compute, scan size).

## SHOULD

- **Orchestration** propre (Airflow, Dagster, Prefect) avec retry policies et alerting.
- **Tests sur les transformations** comme du code (dbt tests, pytest sur fonctions Python).
- **Schéma versionné** (Avro, Parquet evolution, dbt models).
- **Catalog de données** (DataHub, Amundsen, OpenMetadata).
- **SLAs documentées** : freshness attendue, downtime acceptable.

## NICE-TO-HAVE

- Streaming complement aux batch (Kafka, [[Flink]], Materialize).
- Self-service analytics layer (Cube, Lightdash, Metabase).
- Data contracts entre producers et consumers.

## Anti-patterns

- **Update en place** sans audit trail.
- **Magic queries** monstrueuses dans des notebooks ou Tableau (200 lignes SQL non versionnées).
- **Pas d'environnement dev/staging** — modifs testées direct en prod.
- **Pipelines silencieuses** : pas d'alerte sur job failed.

## Stack typique

- **Warehouse** : [[BigQuery]] / [[Snowflake]] / Redshift / DuckDB (small-medium)
- **Orchestration** : Dagster / Airflow / Prefect
- **Transformations** : dbt (SQL-first) ou Python (Pandas/Polars/PySpark)
- **Ingestion** : Airbyte / Fivetran / dlt (Python)
- **Quality** : Great Expectations / Soda / dbt tests
- **Observability** : Monte Carlo / Bigeye / OpenLineage

## Voir aussi

- [[Rules/Types/ML-pipeline]]
- [[Rules/Global/Tests]]
