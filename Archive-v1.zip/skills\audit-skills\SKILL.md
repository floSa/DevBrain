---
name: audit-skills
description: |
  Use this skill to audit the personal Wiki/Outils/ collection in DevBrain :
  list skills sitting in 'discovered' status for too long, find duplicates,
  detect outdated install commands or stale URLs, propose status updates.
  Triggers: "audit mes skills", "fais le point sur mes skills wiki",
  "quels skills j'ai jamais testés", "skills discovered depuis longtemps".
  Only operates on Wiki/Outils/, never on Services/.
---

# Skill — audit-skills

## Quand l'utiliser

Hygiène périodique du Wiki/Outils/. L'utilisateur veut savoir :
- Quels skills sont en `status: discovered` depuis plus de N jours sans avoir été testés ?
- Y a-t-il des doublons (deux fiches pour le même outil) ?
- Y a-t-il des URLs cassées ou des install commands périmées ?
- Quels skills `status: used` n'ont pas de `score` rempli ?

Cadence recommandée : 1× par mois.

## Pré-requis

- L'utilisateur doit être en **mode wiki** (cf. `CLAUDE.md`).
- Read-only par défaut sur les fiches : ce skill **propose** des changements mais ne les applique pas sans confirmation explicite.

## Procédure

### Étape 1 — Inventaire

Scan `Wiki/Outils/**/*.md`. Pour chaque fiche, extraire du frontmatter :
- `nom`, `type`, `status`, `score`, `created`, `modified`
- `source_url`, `install_cmd`

Compte par bucket :
- `discovered` : par défaut, "vu mais pas testé"
- `tested` : testé une fois
- `used` : en routine
- `abandoned` : testé, pas pour moi

### Étape 2 — Détections automatiques

**a) Discovered stagnants**

Liste les fiches `status: discovered` avec `created` < (aujourd'hui - 30 jours). Pour chacune, propose :
- Tu as testé entre-temps ? → passer à `tested`
- Tu n'as plus prévu de tester ? → passer à `abandoned`
- Toujours intéressé mais pas eu le temps ? → laisser tel quel, noter dans une "À tester" liste

**b) Used sans score**

Liste les fiches `status: used` avec `score: ` vide. Propose de scorer 1-5 puisque utilisé en routine.

**c) Doublons potentiels**

Détecte les fiches dont le `nom` est très proche (édit-distance < 3) ou dont la `source_url` pointe sur le même repo. Propose merge.

**d) Modified vs Created delta**

Liste les fiches dont `modified == created` ET `status != discovered`. Cela indique que la fiche n'a probablement jamais été mise à jour depuis sa création (suspect — un skill `used` devrait avoir été touché au moins une fois).

**e) URLs cassées (best-effort)**

Si autorisé via WebFetch, vérifier que les `source_url` retournent un 200. Liste les liens cassés.

### Étape 3 — Présenter le rapport

Format attendu (markdown structuré) :

```markdown
# Audit Wiki/Outils/ — YYYY-MM-DD

## Inventaire
- discovered: X
- tested: Y
- used: Z
- abandoned: W

## À arbitrer (discovered > 30j) — N fiches
- [[nom1]] (créé YYYY-MM-DD, ne jamais touché)
- [[nom2]] (créé YYYY-MM-DD)
...

## À scorer (used sans score) — N fiches
- [[nom3]]
- [[nom4]]

## Doublons suspects
- [[nom5]] et [[nom6]] : sources identiques, fusionner ?

## URLs cassées
- [[nom7]] : source_url renvoie 404

## Actions proposées
1. ...
2. ...
```

### Étape 4 — Demander validation par bloc

Pour **chaque** changement proposé, demander à l'utilisateur avant d'écrire. Ne pas faire de masse update silencieux.

### Étape 5 — Appliquer

Pour les changements validés, patcher uniquement le frontmatter (pas le corps) :
- Mise à jour `status` + `modified: <today>`
- Mise à jour `score` + `modified`
- Suppression d'un doublon (toujours demander quel fichier garder)

### Étape 6 — Logger

Optionnel : écrire un résumé dans `AI/sessions/YYYY-MM-DD-audit-skills.md`.

## Anti-patterns à éviter

- **Patch en masse silencieux** — toujours demander avant d'écrire
- **Sortir du périmètre Wiki/Outils/** — ce skill ne touche jamais `Services/`, `Patterns/`, etc.
- **Inventer des données** — si l'utilisateur n'a pas dit qu'il a testé un skill, le statut reste `discovered`
- **Score automatique** — un score est subjectif, c'est l'utilisateur qui décide

## Format YAML d'un patch typique

```yaml
# avant
status: discovered
modified: 2026-05-19

# après confirmation utilisateur "je l'ai testé, score 4"
status: tested
score: 4
modified: 2026-09-15
```

## Voir aussi

- Skill complémentaire : `add-wiki-outil` (ajouter de nouveaux skills)
- Vue tableau : `Wiki/Comparatif - Outils.base` (vue "À tester")
- Workflow : pas encore de fiche, mais ça pourrait devenir `Wiki/Workflows/Hygiene mensuelle du brain.md`
