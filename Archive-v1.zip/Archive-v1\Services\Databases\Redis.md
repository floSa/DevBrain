---
galaxie: dev
nom: Redis
alias: [redis]
categorie: database/cache
sous_categories: [cache, kv-store, in-memory, pub-sub, queue]
licence: RSAL+SSPL (Valkey fork = BSD)
licence_type: source-available
hosted: both
maturite: production
langage: C
clients_officiels: [python, ts, go, rust, java, ruby, php]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: ["[[Postgres]]", Valkey, DragonflyDB, KeyDB, Memcached]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, database, cache, kv-store]
url_officiel: https://redis.io/
url_docs: https://redis.io/docs/
url_repo: https://github.com/redis/redis
---

# Redis

## Pourquoi
Cache key-value en mémoire ultra-rapide, sub-ms. Aussi pub/sub, queue (Streams), session store, rate limiting, geo. La brique cache par défaut quand Postgres ne suffit plus en lecture.

## Quand l'utiliser
- Cache devant une DB lente (Postgres, requêtes complexes)
- Session store / token bucket pour rate limiting
- Queue de jobs (Celery, RQ, BullMQ backend)
- Pub/sub temps réel léger
- Leaderboards, compteurs distribués (INCR atomic)
- Cache LLM (semantic cache via hash + embedding)

## Quand NE PAS l'utiliser
- Persistence forte / ACID → [[Postgres]]
- Très grosse volumétrie cold storage → S3
- Single-machine app → un dict in-process suffit
- Volonté open-source pure (licence RSAL/SSPL) → Valkey (fork BSD AWS/Linux Foundation)

## Pièges connus
- **Persistence** : RDB snapshots ou AOF — choisir selon RTO. Le défaut snapshot peut perdre quelques secondes.
- **Eviction policy** : `allkeys-lru` souvent voulu mais pas le défaut.
- **Single-thread** : ne scale pas sur cores via un seul process. Cluster mode pour scale-out.
- **TTL drift** : précision en ms mais éviction lazy + active, pas instantanée.
- **Pipelines** : indispensables pour batch (×10-100 throughput).
- **Licence 2024** : RSAL/SSPL non OSI → Valkey est le fork BSD si tu veux du vrai open.

## Liens
- [[Postgres]] — DB source de vérité derrière le cache
- Valkey (fork open) : https://valkey.io/
- Docs : https://redis.io/docs/
- Best practices : https://redis.io/docs/manual/patterns/
