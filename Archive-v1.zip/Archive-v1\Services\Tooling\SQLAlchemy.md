---
galaxie: dev
nom: SQLAlchemy
alias: [sqlalchemy]
categorie: tooling/orm
sous_categories: [orm, sql, database, python, async]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: [SQLModel (built on SQLAlchemy), Tortoise ORM, Peewee, Django ORM, raw asyncpg/psycopg]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, orm, sql]
url_officiel: https://www.sqlalchemy.org/
url_docs: https://docs.sqlalchemy.org/
url_repo: https://github.com/sqlalchemy/sqlalchemy
---

# SQLAlchemy

## Pourquoi
**ORM Python le plus complet et le plus mature**. Deux couches : Core (SQL Expression Language, query builder) et ORM (mapping objet). Async natif depuis 1.4 / 2.0. Combiné avec [[Postgres]] = stack backend Python standard. SQLModel (Tiangolo) le wrap pour Pydantic+API.

## Quand l'utiliser
- Backend Python avec DB SQL ([[Postgres]], [[MySQL]], [[SQLite]])
- Migrations propres avec Alembic
- Multi-DB (dev SQLite, prod Postgres) avec même code
- Query builder pour requêtes dynamiques complexes
- Sessions / Unit of Work pattern

## Quand NE PAS l'utiliser
- App ultra-simple → asyncpg / psycopg direct (raw SQL)
- Apps Django → Django ORM (intégration meilleure)
- Type safety forte sans wrappers → SQLModel (combo Pydantic + SQLAlchemy)
- Pas de SQL prévu → Beanie (MongoDB ODM), pas d'ORM

## Pièges connus
- **Core vs ORM** : choisir un style et s'y tenir. Mélanger crée de la confusion.
- **Session scope** : `scoped_session` vs `Session` async — règles différentes, source de bugs.
- **N+1 queries** : `joinedload()` / `selectinload()` pour eager loading
- **Async ORM** : utiliser `AsyncSession`, `select()` style (pas le legacy Query)
- **Migrations** : Alembic ne génère pas tout (renommage colonnes), check les migrations générées
- **2.0 style mandatory** depuis 2023 : passer au nouveau style `select()` partout

## Liens
- [[Postgres]] / [[SQLite]] / [[MySQL]] — DBs supportées
- SQLModel (Pydantic + SA) : https://sqlmodel.tiangolo.com/
- Alembic (migrations) : https://alembic.sqlalchemy.org/
- Docs : https://docs.sqlalchemy.org/en/20/
- 2.0 migration : https://docs.sqlalchemy.org/en/20/changelog/migration_20.html
