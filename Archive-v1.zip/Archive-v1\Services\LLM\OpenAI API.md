---
galaxie: dev
nom: OpenAI API
alias: [openai, gpt-api, chatgpt-api]
categorie: llm/api
sous_categories: [api, gpt, vision, voice, embeddings, assistants]
licence: Proprietary
licence_type: proprietary
hosted: managed
maturite: production
langage: API REST
clients_officiels: [python, ts, java, go, dotnet]
plateforme: [linux, macos, windows, web]
score: 
mes_projets: []
alternatives: ["[[Anthropic Claude API]]", "[[Google Gemini API]]", "[[Mistral API]]", "[[Azure OpenAI]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, api, openai, gpt]
url_officiel: https://openai.com/
url_docs: https://platform.openai.com/docs
url_repo: https://github.com/openai/openai-python
---

# OpenAI API

## Pourquoi
API LLM d'OpenAI. Modèles **GPT-5** / **GPT-4.1** / **o-series (reasoning)** + multi-modal complet : vision, audio (Whisper), voice (TTS), images (DALL-E / GPT-Image), embeddings (text-embedding-3-*). **Format API standard de fait** que beaucoup d'autres providers émulent.

## Quand l'utiliser
- Multi-modal varié (audio, image, voice generation)
- Embeddings (`text-embedding-3-large`/`small`) — référence du marché
- Whisper transcription (toujours excellent rapport qualité/prix)
- Modèles "o-series" reasoning pour problèmes math/logique
- Quand l'écosystème compte (compat tout le monde sur l'API spec)
- Realtime API pour voice agents

## Quand NE PAS l'utiliser
- Code agents / instructions strictes longues → [[Anthropic Claude API]] souvent meilleur
- Privacy / on-prem → [[vLLM]] + open-weight
- Volume critique sur prix → comparer Gemini Flash / Claude Haiku selon use case
- Tool use chaîné très long → Claude Sonnet/Opus est plus robuste

## Modèles principaux (2026)

| Modèle | Usage |
|--------|-------|
| GPT-5 / GPT-4.1 | Workhorse general purpose |
| o-series (o4 etc.) | Reasoning intensif (math, logique, planning) |
| GPT-4.1-mini / nano | Volume / coût-sensible |
| GPT-Image | Génération d'images |
| Whisper-large-v3 | Speech-to-text |
| TTS-1 / TTS-1-hd | Text-to-speech |
| text-embedding-3-large/small | Embeddings |

## Pièges connus
- **Format Chat Completions vs Responses API** : nouvelle "Responses" API (2024+) à privilégier pour features modernes
- **Tool calling** : `tools` + parsing `tool_calls`, parser strictement les JSON args
- **Structured outputs** : `response_format={"type": "json_schema", ...}` avec strict mode
- **Streaming** : SSE, parser `delta`
- **Rate limits** : par tier, et par modèle
- **`temperature` ≠ panacée** : pour les o-series, paramètres limités
- **Prix très variables** entre modèles, lire la pricing page
- **Azure OpenAI** : variant enterprise, API similaire mais auth/régions/modèles différents

## Patterns clés

### Chat basique

```python
from openai import OpenAI
client = OpenAI()
resp = client.chat.completions.create(
    model="gpt-4.1",
    messages=[{"role": "user", "content": "Hello"}]
)
```

### Structured output

```python
resp = client.chat.completions.parse(
    model="gpt-4.1",
    messages=[...],
    response_format=MaPydanticClass,  # pydantic v2
)
```

### Embeddings

```python
emb = client.embeddings.create(
    model="text-embedding-3-small",
    input=["doc 1", "doc 2"],
)
```

## Liens
- [[Anthropic Claude API]], [[Google Gemini API]] — alternatives
- Plateforme : https://platform.openai.com/
- Cookbook : https://github.com/openai/openai-cookbook
- Azure OpenAI : https://azure.microsoft.com/en-us/products/ai-services/openai-service
- Pricing : https://openai.com/api/pricing/
