---
name: log-bug
description: |
  Use this skill when the user reports a bug they encountered with a service
  while working on a project, and wants it logged in the DevBrain. Triggers:
  "log ce bug", "enregistre ce REX", "j'ai eu un problème avec X". Writes
  to Bugs/REX - <service>.md and Projects/<projet>/Bugs.md.
---

# Skill — log-bug

## Quand l'utiliser

L'utilisateur a rencontré un **bug en projet** avec un service du brain et veut le tracer comme REX (Retour d'Expérience). Cas typiques :
- "log ce bug" / "enregistre ce REX"
- "j'ai eu un problème avec Postgres, voici le symptôme"
- Pendant une session projet, après diagnostic d'une panne

Distinct de `add-service` (création de fiche) et `update-service` (mise à jour). Le REX est **séparé** de la fiche service et vit dans `Bugs/REX - <service>.md`.

## Pré-requis vault

Mode build ou project. Périmètre `Bugs/` et `Projects/`.

## Procédure

### Étape 1 — Identifier

- Quel **service** est en cause ? (chercher dans `Services/**`)
- Quel **projet** ? (chercher dans `Projects/`)

Si ambigu → demander.

### Étape 2 — Collecter les infos (5 champs requis)

1. **Symptôme** — ce qu'on a vu (logs, erreurs, comportement)
2. **Cause racine** — ce qui le causait réellement
3. **Fix** — ce qui a résolu (commandes, configs, code)
4. **Référence projet** — wikilink vers `Projects/<projet>/Bugs.md#<ancre>`
5. **Leçon** — généralisable

Si l'utilisateur saute des champs, demande explicitement.

### Étape 3 — Écrire dans `Bugs/REX - <Service>.md`

Path : `Bugs/REX - <Service>.md` (un fichier par service, **pas dans `Services/`**).

#### Si le fichier n'existe pas

Créer avec ce contenu initial :

```markdown
---
service: "[[<Service>]]"
type: rex
created: <YYYY-MM-DD aujourd'hui>
modified: <YYYY-MM-DD aujourd'hui>
tags: [rex, bugs, <slug-service>]
---

# REX — <Service>

> Retours d'expérience et bugs rencontrés avec [[<Service>]]. Triés par date décroissante. Format standard : Symptôme → Cause → Fix → Référence projet → Leçon.

---

<entrée du bug à insérer ici>
```

#### Si le fichier existe

Insérer la nouvelle entrée **en haut** (juste après le `---` qui suit la phrase d'intro), pour conserver le tri par date décroissante.

#### Format de l'entrée (strict)

```markdown
## YYYY-MM-DD — <Symptôme court>

**Symptôme** : <détails>

**Cause racine** : <explication>

**Fix** :
1. ...
2. ...

**Référence** : [[Projects/<projet>/Bugs#YYYY-MM-DD]]

**Leçon** : <synthèse réutilisable>
```

#### Outils

Utiliser `mcp__devbrain__patch_content` ou `mcp__devbrain__append_content` si disponible pour insérer sans réécrire tout le fichier. Sinon Edit/Write standard.

### Étape 4 — Écrire dans `Projects/<projet>/Bugs.md`

Append section avec ancre date :

```markdown
## YYYY-MM-DD — <Symptôme court>

Service : [[<Service>]]
Voir : [[REX - <Service>#YYYY-MM-DD]]

<Optionnel : contexte projet, impact, leçons spécifiques au projet>
```

### Étape 5 — Mettre à jour la fiche Service (une seule fois, lors du premier REX)

Si c'est le **premier** REX pour ce service, ajouter dans la section "Liens" de `Services/<categorie>/<Service>.md` :

```markdown
- [[REX - <Service>]] — REX accumulés
```

Et dans la section "Pièges connus" de la fiche Service, indiquer que les détails sont dans le fichier REX.

### Étape 6 — Confirmer

Liste les modifications faites avec leurs paths :

- `Bugs/REX - <Service>.md` (créé OU patché)
- `Projects/<projet>/Bugs.md` (append)
- `Services/<categorie>/<Service>.md` (modifié — section Liens, **uniquement si premier REX**)

Demande si à commit maintenant.

## Voir aussi

- `add-service` (créer la fiche service si elle n'existe pas)
- `update-service` (le REX peut justifier de patcher la fiche service pour ajouter le piège dans "Pièges connus")
- `add-pattern` (un REX répétitif peut révéler un pattern à formaliser)

## Anti-patterns

- Logger un bug sans cause racine identifiée — ce n'est pas encore un REX.
- Logger sans leçon — l'objectif est la généralisation.
- Logger uniquement côté Project sans REX dans `Bugs/` — le brain n'apprend pas.
- **Créer le REX dans `Services/`** — ancien pattern, ne plus faire. Toujours dans `Bugs/`.
- Modifier le titre H1 ou frontmatter d'un fichier REX existant.
