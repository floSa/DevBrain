---
galaxie: wiki
nom: CUPED
alias: [CUPED, variance reduction, controlled pre-experiment data]
type: concept
categorie: concept/statistics
sous_categories: [cuped, variance-reduction, ab-test, experimentation]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Deng-Xu-Kohavi-Walker 2013]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, statistics, cuped, variance-reduction, ab-test]
---

# CUPED — Controlled Pre-Experiment Data

## TL;DR

Technique de **réduction de variance** pour [[A-B testing|A/B tests]], publiée par Microsoft (Deng, Xu, Kohavi, Walker 2013). Idée : utiliser une variable **pré-expérience** $X$ corrélée à la métrique $Y$ pour réduire la variance de l'estimateur. **Réduction = $1 - \rho^2$** où $\rho = \text{corr}(X, Y)$. Standard chez Microsoft, Netflix, Booking, Meta. Peut réduire la sample size par **2-4x** sans rien changer au design.

## Le problème

Un A/B test demande un certain $n$ pour détecter un MDE avec 80% de power. Ce $n$ scale en $\sigma^2 / \text{MDE}^2$. Plus la métrique est **bruyante**, plus on attend. Comment détecter le même effet avec moins d'utilisateurs ?

## L'idée

### Principe

Soit $Y$ la métrique d'intérêt et $X$ une variable **pré-expérience** (mesurée avant le début du test). Sous randomisation, $X$ est indépendant du treatment.

Définir une métrique ajustée :

$$ Y'_i = Y_i - \theta (X_i - \bar X) $$

avec $\theta = \text{Cov}(Y, X) / \text{Var}(X)$ (coefficient de régression de $Y$ sur $X$).

**Propriétés** :
- $\mathbb{E}[Y'] = \mathbb{E}[Y]$ (estimateur reste **sans biais**)
- $\text{Var}(Y') = \text{Var}(Y) (1 - \rho^2)$ où $\rho = \text{corr}(X, Y)$
- Différence des moyennes $\bar Y'_B - \bar Y'_A$ a une variance réduite → t-test plus puissant

### Pourquoi ça marche

Sous randomisation, $X$ est balanced entre groupes en moyenne, mais **pas en échantillon fini**. Si $X$ est correlated à $Y$, ajuster pour $X$ retire le bruit de variance attribuable à des déséquilibres random de $X$. C'est essentiellement une **régression** où $X$ joue le rôle de **covariable**.

### Choisir $X$

Le mieux : **la même métrique mesurée avant le test** :
- A/B test sur CTR ce mois → $X$ = CTR de l'user le mois dernier
- A/B test sur revenue → $X$ = revenue baseline

Corrélation typique 0.5-0.8 → réduction de variance 25%-65%.

Autres options :
- Variables démographiques (mais souvent moins corrélées)
- Multiples covariables ("CUPED++")
- Predictions ML (Deng et al. 2023 : ML-CUPED)

### Estimation de $\theta$

En pratique, $\theta$ est estimé sur les données du test elles-mêmes :

$$ \hat\theta = \frac{\sum_i (X_i - \bar X)(Y_i - \bar Y)}{\sum_i (X_i - \bar X)^2} $$

Légère perte de degrés de liberté, mais négligeable pour $n$ grand.

### Variantes / extensions

#### CUPED multi-covariables

$$ Y' = Y - \beta^\top (X - \bar X) $$

avec $\beta$ estimé par OLS. Réduction de variance = $1 - R^2$ où $R^2$ est le coef de détermination de $Y \sim X_1, \dots, X_k$.

#### CUPAC (Predictive Adjustment for Confounders)

Variant DoorDash : utiliser une prédiction ML $\hat Y$ basée sur features pre-experiment. Réduction de variance > simple CUPED si bonne prédiction.

#### Sensitivity ratio

$$ \text{SR} = \frac{\text{Var}(Y)}{\text{Var}(Y')} = \frac{1}{1 - R^2} $$

Si $R^2 = 0.5$ → SR = 2 → sample size divisée par 2.

### Implémentation typique

1. Calculer $X$ (baseline metric) pour chaque user avant le test
2. Pendant le test, mesurer $Y$
3. Ex post : régresser $Y$ sur $X$ pour estimer $\theta$
4. Calculer $Y' = Y - \hat\theta (X - \bar X)$
5. Faire le test stat classique (t-test) sur $Y'$ au lieu de $Y$

C'est le standard chez la plupart des plateformes d'expérimentation modernes (Statsig, Eppo, Optimizely).

### Lien avec régression linéaire

CUPED ≡ régression linéaire avec covariable de baseline. Cohérent avec literature économétrique (ANCOVA = analysis of covariance).

L'OLS du modèle $Y = \alpha + \tau T + \beta X + \varepsilon$ donne directement le même estimateur que CUPED pour $\tau$.

## Quand c'est utile

- **Métriques bruyantes** : revenue per user (long-tail), session duration, etc.
- **Coût marginal** : c'est gratuit, juste un retraitement
- **Petite fraction de trafic** : tests holdout 1-5%, besoin de power max
- **Itération rapide** : raccourcir durée des tests
- **Métriques continues**, mais aussi proportions / counts (avec adaptation)
- **Toute plateforme A/B** : à intégrer en standard

## Quand ça ne marche pas / pièges

- **Pas de pre-period** : nouveau user → pas de $X$. Options : segmenter (post-CUPED), imputer, exclure.
- **Métrique nouvelle** : si la feature crée une nouvelle métrique, pas de baseline. Utiliser proxy.
- **$X$ non corrélé à $Y$** : pas de gain (mais pas de perte non plus).
- **$X$ affecté par le treatment** : viole la randomisation conditionnelle, biais. **$X$ doit être pré-experience.**
- **Tail metric extreme** : moyenne de $Y'$ peut être tirée par outliers, winsoriser avant.
- **Confondre CUPED avec adjustment causal** : CUPED ne corrige pas un biais de confondage (randomisation est ce qui fait ça), juste la variance.
- **Cas binaires** : pour conversion rate, CUPED simple marche mais covariate continue plus efficace.
- **Estimer θ sur les données** : valide sous taille raisonnable, mais en très petit $n$ légère perte de power.

## Code minimal

```python
import numpy as np
from scipy import stats

np.random.seed(0)
n = 5000

# Pre-experiment baseline metric (covariable)
X = np.random.normal(10, 3, 2 * n)

# Outcome corrélé à X + treatment effect
treatment = np.array([0]*n + [1]*n)
y_noise = np.random.normal(0, 5, 2 * n)
y = 0.7 * X + 0.5 * treatment + y_noise  # vrai treatment effect = 0.5

# Sans CUPED
y_A, y_B = y[:n], y[n:]
diff = y_B.mean() - y_A.mean()
se = np.sqrt(y_A.var(ddof=1)/n + y_B.var(ddof=1)/n)
t = diff / se
p_value = 2 * (1 - stats.norm.cdf(abs(t)))
print(f"Sans CUPED : effet = {diff:+.3f}, SE = {se:.4f}, p = {p_value:.5f}")

# Avec CUPED
theta = np.cov(y, X)[0, 1] / np.var(X)
y_cuped = y - theta * (X - X.mean())

y_cuped_A, y_cuped_B = y_cuped[:n], y_cuped[n:]
diff_cuped = y_cuped_B.mean() - y_cuped_A.mean()
se_cuped = np.sqrt(y_cuped_A.var(ddof=1)/n + y_cuped_B.var(ddof=1)/n)
t_cuped = diff_cuped / se_cuped
p_cuped = 2 * (1 - stats.norm.cdf(abs(t_cuped)))
print(f"Avec CUPED : effet = {diff_cuped:+.3f}, SE = {se_cuped:.4f}, p = {p_cuped:.5f}")

# Réduction de variance
var_reduction = 1 - se_cuped**2 / se**2
print(f"Réduction de variance : {var_reduction * 100:.1f}%")

# Réduction de sample size équivalente
print(f"Sample size effectif divisé par : {(se / se_cuped)**2:.2f}x")

# Version régression équivalente
import statsmodels.api as sm
X_design = sm.add_constant(np.column_stack([treatment, X]))
model = sm.OLS(y, X_design).fit()
print(f"Treatment coef (régression) : {model.params[1]:.3f}, SE = {model.bse[1]:.4f}")
# Donne le même résultat que CUPED
```

## Pour aller plus loin

- Deng, Xu, Kohavi, Walker, *Improving the Sensitivity of Online Controlled Experiments by Utilizing Pre-Experiment Data* (WSDM 2013) — paper original
- Kohavi, Tang, Xu, *Trustworthy Online Controlled Experiments* — chap. variance reduction
- Microsoft Experimentation Platform, blog posts
- DoorDash Engineering, *CUPAC* (variant ML-based)
- **Liens internes** : [[A-B testing]], [[Hypothesis testing]], [[Multi-armed bandits]]
