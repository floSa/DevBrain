---
galaxie: dev
nom: NVIDIA Triton Inference Server
alias: [triton, triton-inference-server, nvidia-triton]
categorie: ml/serving
sous_categories: [serving, gpu, multi-framework, high-performance]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: C++
clients_officiels: [python, c++, java, http, grpc]
plateforme: [linux]
score: 
mes_projets: []
alternatives: ["[[Ray Serve]]", "[[BentoML]]", "[[TorchServe]]", "[[TensorFlow Serving]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ml, serving, gpu, nvidia]
url_officiel: https://developer.nvidia.com/triton-inference-server
url_docs: https://docs.nvidia.com/deeplearning/triton-inference-server/
url_repo: https://github.com/triton-inference-server/server
---

# NVIDIA Triton Inference Server

## Pourquoi
Serveur d'inférence **multi-framework** de NVIDIA. Supporte PyTorch, TensorFlow, ONNX, TensorRT, OpenVINO, Python custom backend. Conçu pour **performance maximale GPU** : dynamic batching, model ensembles, concurrent execution, séquences/streaming. Le choix prod quand on optimise chaque ms.

## Quand l'utiliser
- Inférence GPU à très haut throughput / faible latence
- Multi-modèles, multi-frameworks dans un seul serveur
- Optimisations TensorRT (compilation graphe → quantization)
- Production NVIDIA enterprise (Triton est gratuit, NVIDIA AI Enterprise pour le support)
- Servir un même modèle dans plusieurs versions (A/B, canary)

## Quand NE PAS l'utiliser
- Pas d'expertise GPU/NVIDIA → courbe d'apprentissage forte
- App simple Python → [[BentoML]] ou [[FastAPI]] suffit
- Besoin Python-natif facile → Triton "Python backend" marche mais avec friction
- Pas de GPU NVIDIA (AMD, Intel, Mac) → moins idéal

## Pièges connus
- **Model repository structure** : convention stricte `<model>/<version>/model.<ext>` + `config.pbtxt`
- **`config.pbtxt`** : format Protobuf, syntaxe spécifique, pas trivial
- **Dynamic batching** : règles à régler (`preferred_batch_size`, `max_queue_delay_microseconds`)
- **Versions** : nouvelles releases NGC fréquentes, vérifier compat CUDA / drivers
- **Memory management** : GPU OOM = configuration `instance_group` à revoir
- **Logs** : verbeux, à filtrer en prod
- **Container size** : image officielle ~10GB, base trim possible

## Liens
- [[Ray Serve]], [[BentoML]] — alternatives plus Python-friendly
- TensorRT (souvent combiné) : https://developer.nvidia.com/tensorrt
- Model Analyzer (tuning auto) : https://github.com/triton-inference-server/model_analyzer
- Tutorial : https://github.com/triton-inference-server/tutorials
