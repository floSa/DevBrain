---
galaxie: wiki
nom: SFT (Supervised Fine-Tuning)
alias: [SFT, instruction tuning, chat tuning, fine-tuning supervisé]
type: concept
categorie: concept/llm-training
sous_categories: [sft, fine-tuning, instruction-tuning, llm]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Wei 2022 (FLAN), Ouyang 2022 (InstructGPT)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, training, sft, fine-tuning]
---

# SFT — Supervised Fine-Tuning

## TL;DR

**Première étape de post-training** d'un LLM après pretraining : entraîner sur des paires **(prompt, response)** human-curées pour transformer un "predict next token" en "assistant utile". **Instruction tuning** (FLAN) + **chat tuning** + **tool-use tuning**. Datasets standards : Alpaca, ShareGPT, UltraChat, LIMA, Tulu, OpenHermes. Format : **chat templates** spécifiques au modèle. Techniques : **loss masking** (loss only on assistant tokens), **packing** (concat samples for efficiency). Suivi par [[RLHF and DPO]] pour alignement. Sans SFT, un modèle pretrained est inutilisable comme assistant.

## Le problème

Un LLM pretrained (next-token prediction sur web) prédit le mot suivant. Si on lui dit "Écris une recette de cookies", il pourrait répondre... une autre question ("Quels ingrédients ?"), au lieu de répondre.

→ **Aligner** le modèle pour suivre des **instructions** et répondre **utilement**.

## L'idée

### Pipeline standard

```
[Pretrained base model]
       ↓
[Supervised Fine-Tuning (SFT)]  ← cette fiche
       ↓
[Reward modeling + RLHF/DPO]    ← alignement (voir [[RLHF and DPO]])
       ↓
[Instruct / Chat model]
```

### Format de training

Données = liste de conversations :

```json
[
  {"role": "system", "content": "You are a helpful assistant."},
  {"role": "user", "content": "What's the capital of France?"},
  {"role": "assistant", "content": "Paris is the capital of France."}
]
```

Appliquer le **chat template** du modèle (voir [[Tokenization]]) :

```
<|system|>You are a helpful assistant.<|user|>What's the capital of France?<|assistant|>Paris is the capital of France.
```

### Loss

**Causal LM loss** (cross-entropy sur next token), **MAIS** :

#### Loss masking

On ne calcule la loss **que sur les tokens de l'assistant**. Pas sur le system / user (qu'on ne veut pas apprendre à générer).

```python
labels = input_ids.clone()
labels[:user_mask] = -100  # IGNORE_INDEX → ignoré par cross_entropy
```

→ Le modèle apprend à **répondre**, pas à reformuler la question.

### Packing

Au lieu d'1 sample par batch element (avec padding waste), **concaténer plusieurs samples** dans un seul exemple :

```
<|user|>Q1<|assistant|>A1<|eos|><|user|>Q2<|assistant|>A2<|eos|>...
```

Avec un attention mask qui empêche un sample de "voir" un autre (block-diagonal mask).

**Gain** : 2-3x throughput training, utilisation GPU optimale.

### Types de SFT

#### Instruction tuning

Datasets de paires (instruction, réponse) variées :
- FLAN (Wei 2022) : 1.8K tasks, 15M examples
- T0, P3 (BigScience)
- Self-Instruct (Wang 2022) : généré par LLM

#### Chat / dialog tuning

Conversations multi-turn :
- ShareGPT (Vicuna), WildChat, LMSYS-Chat
- UltraChat, Tulu mix

#### Tool-use tuning

Inclut function calls dans les réponses :
- Glaive function calling
- xLAM tool dataset
- Anthropic tool-use examples

#### Reasoning tuning

CoT traces, o1-style :
- OpenMathInstruct, MathInstruct
- DeepSeek-R1 distill traces

### Datasets standards (2026)

| Dataset | Type | Taille | Notes |
|---|---|---|---|
| **Alpaca** | instructions self-gen | 52K | classique, base de tout |
| **Dolly 15K** | human-written | 15K | Databricks |
| **OpenAssistant (OASST)** | crowdsourced | 161K conv | open community |
| **ShareGPT / Vicuna** | scraped ChatGPT | 90K | conv multi-turn |
| **WildChat** | real users | 650K conv | Allen AI |
| **LIMA** | 1K curated | **1K** | "less is more" — 1K bien curé > 50K bruité |
| **UltraChat** | LLM-generated | 1.5M | quality++ |
| **Tulu 3** | curated mix | varies | AllenAI, SOTA open |
| **Open-Hermes** | mixed | 1M | NousResearch |
| **Magpie** | self-gen from chat template | varies | trick efficace |

### Hyperparams typiques

- **Learning rate** : 1e-5 à 5e-5 (bas — éviter catastrophic forgetting)
- **Epochs** : 1-3 (overfit rapide en SFT)
- **Batch size** : effectif 32-128
- **Max length** : 4K-32K selon use case
- **Warmup** : 3-10% des steps
- **LR schedule** : cosine decay

### Quality > Quantity (LIMA)

Zhou et al. (2023) : **1000 examples bien curés** peuvent battre **52K** d'Alpaca. La qualité du dataset > la taille.

Implications :
- Human-written > LLM-generated (parfois)
- Diversité critique
- Trash data peut dégrader

### Synthetic SFT data

Standard 2026 : générer le SFT data via LLM teacher (GPT-4, Claude). Techniques :
- **Self-Instruct** : seed examples → LLM génère variations
- **Evol-Instruct** (WizardLM) : "complexifier" les instructions
- **Persona-driven** (Tu 2024)
- **Magpie** : trick où on tronque le chat template au début pour faire générer une instruction par le modèle

### Catastrophic forgetting

SFT peut **dégrader** la capacité base (knowledge, reasoning) si :
- LR trop élevé
- Dataset trop spécialisé (e.g. ne SFT que sur math → modèle oublie autre chose)
- Trop d'epochs

**Mitigations** :
- LR bas
- Continued pretraining léger pendant SFT
- LoRA (voir [[PEFT]]) : préserve les weights base
- Replay mix : ajouter samples du pretraining ou SFT généraliste

### SFT vs few-shot prompting

- **SFT** : modifier les weights, persistant, marche en zero-shot
- **Few-shot prompting** : in-context learning, pas de modification, dépend du context window

Pour use case **récurrent** : SFT meilleur. Pour exploration / one-shot : few-shot suffit.

### Évaluation SFT

- **MT-Bench** : multi-turn benchmark
- **AlpacaEval / Arena Hard** : pairwise vs reference
- **MMLU, GSM8K** : knowledge / reasoning préservés ?
- **Task-specific** : selon use case

**Important** : SFT-only model **peut être bon en quality mais mal calibré**. RLHF/DPO ajoute la dernière couche d'alignement.

### Best practices

1. **Format chat template du modèle exactement** (`tokenizer.apply_chat_template`)
2. **Loss masking obligatoire** (sur outputs only)
3. **Packing** pour efficiency
4. **Mix généraliste + spécialisé** pour éviter forgetting
5. **Eval continu** sur dataset gold + benchmarks
6. **LoRA pour expérimentation** ([[PEFT]]) — 100x moins cher que full SFT
7. **Quality control** dataset : filtrer hallucinations, formats cassés
8. **Multi-turn** si chat use case (pas que single-turn)
9. **Échantillonner pendant training** pour qualitative checks

## Quand c'est utile

- **Customiser un modèle open** : Llama 3 base → ton chat tuné
- **Domain-specific** : médical, légal, finance avec data curé
- **Stylistic alignment** : ton, format, persona
- **Tool-use spécialisé** : tools custom de ton app
- **Multi-langue** : adapter à français/japonais
- **Reasoning training** : injecter CoT traces
- **Distillation** : passer connaissance d'un gros à un petit modèle
- **Réduction de l'API cost** : SFT permet d'utiliser un modèle plus petit

## Quand ça ne marche pas / pièges

- **Catastrophic forgetting** : modèle oublie ses capacités base. Mix data, LR bas.
- **Dataset bruité** : LLM-generated avec hallucinations → modèle apprend les erreurs.
- **Pas de loss masking** : modèle apprend à générer le system prompt / user query.
- **Chat template incorrect** : modèle produit du garbage en inference.
- **Overfit** : trop d'epochs, modèle mémorise des réponses (verbatim).
- **Distribution shift** : SFT data ≠ usage réel → modèle hallucine en prod.
- **One-shot multi-turn** : SFT sur single-turn et expect multi-turn → casse.
- **Mode collapse** : modèle répond toujours de la même manière (utiliser RLHF/DPO pour corriger).
- **Eval sur SFT data** : leak, optimiste. Toujours holdout.
- **PEFT mal réglé** : LoRA rank trop petit pour capturer changement → modèle pas SFT vraiment.

## Code minimal

```python
from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments
from trl import SFTTrainer, SFTConfig
from datasets import load_dataset

# Load base model
model_id = "meta-llama/Meta-Llama-3-8B"
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype="auto", device_map="auto")

# Dataset format avec chat template
ds = load_dataset("HuggingFaceH4/ultrachat_200k", split="train_sft[:1000]")

def format_chat(example):
    return {"text": tokenizer.apply_chat_template(example["messages"], tokenize=False)}

ds = ds.map(format_chat)

# Config
config = SFTConfig(
    output_dir="./sft-llama3",
    num_train_epochs=1,
    per_device_train_batch_size=2,
    gradient_accumulation_steps=8,
    learning_rate=2e-5,
    warmup_ratio=0.03,
    lr_scheduler_type="cosine",
    max_seq_length=4096,
    packing=True,
    dataset_text_field="text",
    bf16=True,
)

trainer = SFTTrainer(
    model=model,
    tokenizer=tokenizer,
    train_dataset=ds,
    args=config,
)
# trainer.train()

# Avec PEFT/LoRA (cf. [[PEFT]])
from peft import LoraConfig
peft_config = LoraConfig(
    r=16, lora_alpha=32, target_modules="all-linear", lora_dropout=0.05,
    bias="none", task_type="CAUSAL_LM"
)
# Re-init trainer avec peft_config=peft_config

# Inference après SFT
inputs = tokenizer.apply_chat_template(
    [{"role": "user", "content": "Explain quantum computing in 1 sentence."}],
    return_tensors="pt", add_generation_prompt=True
).to("cuda")
out = model.generate(inputs, max_new_tokens=100)
print(tokenizer.decode(out[0]))

# Loss masking custom (sans TRL)
# tokenizer apply_chat_template avec return_dict=True + attention_mask
# labels = input_ids.clone()
# Pour chaque message, set labels[message_range] = -100 si role != "assistant"
```

## Pour aller plus loin

- Ouyang et al., *Training language models to follow instructions with human feedback* (NeurIPS 2022) — InstructGPT
- Wei et al., *Finetuned Language Models Are Zero-Shot Learners* (ICLR 2022) — FLAN
- Zhou et al., *LIMA: Less Is More for Alignment* (NeurIPS 2023)
- Wang et al., *Self-Instruct: Aligning Language Models with Self-Generated Instructions* (ACL 2023)
- *TRL* (Hugging Face) — bibliothèque de référence
- AllenAI Tulu 3 paper — moderne SOTA open SFT recipe
- **Liens internes** : [[Tokenization]], [[RLHF and DPO]], [[PEFT]], [[Synthetic data generation]], [[LLM eval metrics]]
