---
name: add-wiki-outil
description: |
  Use this skill when the user wants to add a new skill/tool fiche to the
  personal Wiki of DevBrain. Triggers: "ajoute le skill", "ajoute le MCP",
  "documente l'outil", "ajoute cette CLI", or when the user provides a URL
  to a GitHub repo / plugin marketplace / tool homepage and asks to file it.
  Generates a fiche compliant with Templates/Wiki-Outil.md in
  Wiki/Outils/<Category>/<Name>.md. Distinct from add-service: add-service
  is for projects' technical components, add-wiki-outil is for the user's
  personal toolbox.
---

# Skill — add-wiki-outil

## Quand l'utiliser

L'utilisateur veut ranger un **outil personnel** dans son wiki :
- Un Claude Code skill (anthropic-*, claude-*, communautaire)
- Un Obsidian skill (kepano-*, ou autre)
- Un MCP server (mcp-*, plugin pour agent)
- Un CLI tool utile au quotidien (uv, gh, jq, lazygit, etc.)

Différence avec `add-service` :
- `add-service` → fiche **réutilisable dans un projet client** (database, framework, etc.)
- `add-wiki-outil` → outil **personnel** de l'utilisateur, sa boîte à outils

Si tu hésites : si l'outil tourne dans un projet déployé, c'est un Service. Si c'est un outil que l'utilisateur lance sur sa machine pour augmenter sa productivité ou celle de l'agent, c'est un Outil wiki.

## Pré-requis vault

L'utilisateur doit être en **mode wiki** (cf. `CLAUDE.md` du vault). Si tu n'es pas sûr, demande "On est en mode wiki ?" avant de toucher à `Wiki/`.

## Procédure

### Étape 1 — Identifier le type

Demande (ou déduis du contexte) :

| Indice | Type |
|---|---|
| URL `github.com/anthropics/skills` ou `claude plugin install` dans la doc | `claude-code-skill` |
| URL `github.com/kepano/*` ou install via `npx skills add kepano/*` | `obsidian-skill` |
| URL `github.com/modelcontextprotocol/*`, `mcp-*`, install via `claude mcp add` | `mcp-server` |
| Binaire shell (winget/brew/apt), pas d'install agent | `cli-tool` |

Plateforme correspondante :
- `claude-code` pour les claude-code-skill et obsidian-skill (oui — kepano s'installe via Claude Code)
- `universel` pour mcp-server
- `cli` pour cli-tool

### Étape 2 — Vérifier la non-duplication

Cherche `Wiki/Outils/**/<nom>*.md`. Si la fiche existe déjà, propose de la **mettre à jour** plutôt que créer un doublon.

### Étape 3 — Catégoriser

Choisir parmi la taxonomie skill (cf. `CLAUDE-build.md`) :

```
skill/documents     - PDF, XLSX, DOCX, PPTX, lecture/écriture documents
skill/dev-flow      - bootstrap, init, package mgmt, API SDK, GitHub workflows
skill/code-quality  - review, security, lint, refactor
skill/knowledge     - Obsidian, scraping, ingestion contenu
skill/data          - accès DB, query, exploration
skill/meta          - skills sur les skills (skill-creator, eval)
```

Et le sous-dossier de rangement :

```
Wiki/Outils/Claude-Code/    <- type=claude-code-skill
Wiki/Outils/Obsidian/       <- type=obsidian-skill
Wiki/Outils/MCP-Servers/    <- type=mcp-server
Wiki/Outils/CLI-Tools/      <- type=cli-tool
```

### Étape 4 — Pré-remplir depuis URL

Si l'utilisateur a fourni une URL :
1. Invoke le skill `defuddle` (kepano) pour extraire le contenu propre du README.
2. Récupère : auteur, licence, install command, description courte, domaines d'usage.

Sinon, demande chaque champ manquant.

### Étape 5 — Frontmatter complet

Schéma strict (cf. `Templates/Wiki-Outil.md`) :

```yaml
---
nom: <id-court>                         # ex: anthropic-xlsx, mcp-github, uv
type: claude-code-skill | obsidian-skill | mcp-server | cli-tool
plateforme: claude-code | claude-desktop | obsidian | cli | universel
categorie: skill/<famille>
sous_categories: [tag1, tag2]
auteur: <Nom auteur ou organisation>
source: <owner/repo> ou <package name>
source_url: <URL GitHub ou doc canonique>
install_cmd: |
  <commande shell exacte>
install_doc: <URL doc d'install si distincte du source_url>
licence: MIT | Apache-2.0 | …
licence_type: open-source | proprietary | source-available
domaines: []                             # parmi : data-science, data-eng, mlops, ml-eng, ai-eng, doc
score:                                   # vide tant que pas testé
status: discovered                       # toujours discovered à la création
mes_projets: []
created: <YYYY-MM-DD>
modified: <YYYY-MM-DD>
tags: [skill, <type-court>, …]
---
```

### Étape 6 — Corps de la fiche

7 sections fixes :

1. **Pourquoi** — 2-3 lignes : ce que ça fait, pourquoi c'est dans MA boîte à outils
2. **Quand l'utiliser** — 3-5 bullets concrets
3. **Quand NE PAS l'utiliser** — limites / outils concurrents préférables dans ces cas
4. **Comment l'installer** — commande exacte + lien vers `[[_installer-un-skill]]` pour le détail par famille
5. **Exemples d'usage** — 2-3 invocations réelles courtes
6. **Pièges connus** — vide à la création si pas de retour, à enrichir au fur et à mesure
7. **Liens** — repo, doc, fiches Wiki/Outils/ ou Services/ liées

### Étape 6bis — Repérer les fiches qui mentionnent déjà cet outil (via `find-connexes.ps1`)

**Avant** d'écrire :

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/find-connexes.ps1 -Name "<nom>"
```

Liste les fiches [FAIBLE] (mentions sans wikilink) — à patcher à l'étape 10.

### Étape 7 — Wikilinker (via `discover-links.ps1`)

**Toujours utiliser le script** pour découvrir les fiches candidates à wikilinker :

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/discover-links.ps1 \
    -Title "<nom>" \
    -Categorie "skill/<famille>" \
    -Domaines "<csv>" \
    -SousCategories "<csv>" \
    -Tags "<csv>" \
    -TopN 15
```

Le script retourne le top des fiches (Outils, Services, Concepts, Patterns) avec score + justification.

**Workflow** :
1. Lance avec les metadata de la nouvelle fiche
2. Présente les top 5-10 candidats à l'utilisateur
3. Pour chaque retenu, l'insère en section **Liens** de la nouvelle fiche
4. Cas particuliers :
   - Pour des références à des **sujets non-fichiers** (plugin Obsidian, paper, blog), ne pas wikilinker → URL inline
   - Pour des **services dans Services/** liés (ex. Postgres pour mcp-postgres), garder en wikilink

**Reverse linking** : si la nouvelle fiche est un meilleur match pour des fiches existantes, propose à l'utilisateur de l'ajouter dans leur section "Liens".

### Étape 8 — Demander confirmation

Avant écriture, affiche à l'utilisateur :
- Le chemin cible : `Wiki/Outils/<sous-dossier>/<nom>.md`
- Le frontmatter complet
- La section "Pourquoi" (la plus importante)

Demande : "OK pour écrire ?"

### Étape 9 — Écrire

Path : `Wiki/Outils/<sous-dossier>/<nom>.md`.

Rappelle ensuite à l'utilisateur :
- "Status: discovered — pense à le passer à `tested` ou `used` quand tu l'auras essayé"
- "Tu peux le voir dans `Wiki/Comparatif - Outils.base` → vue 'À tester'"

### Étape 10 — Audit post-création + propagation des wikilinks

```bash
# Audit fantomes introduits
powershell -ExecutionPolicy Bypass -File AI/scripts/find-connexes.ps1 -Path "Wiki/Outils/<sous-dossier>/<nom>.md"

# Propage le wikilink [[<nom>]] dans les fiches qui le mentionnent en bare
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "<nom>" -All
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "<nom>" -All -Apply

# Verification finale : 0 fantôme
powershell -ExecutionPolicy Bypass -File AI/scripts/report-ghosts.ps1
```

## Anti-patterns à éviter

- **Ne pas inventer un `score`** — laisse vide tant que l'utilisateur n'a pas testé
- **Ne pas mettre `status: used`** par défaut — toujours `discovered` à la création
- **Ne pas mélanger Skills wiki et Services** — un MCP server va dans `Wiki/Outils/MCP-Servers/`, pas dans `Services/`
- **Ne pas créer une nouvelle famille `categorie:` sans demander** — utilise la taxonomie existante ou propose explicitement
- **Ne pas écrire en mode build** — `Wiki/` est hors-périmètre du build (cf. CLAUDE-build.md). Demande explicitement le mode wiki si nécessaire.
- **Wikilinks fantômes** : ne pas créer de `[[X]]` vers un fichier qui n'existe pas (ex. `[[DevBrain]]` n'existe pas en tant que .md). Soit créer la cible, soit utiliser une référence inline.

## Format minimal pour rappel rapide

```yaml
---
galaxie: wiki
nom: <id>
type: claude-code-skill | obsidian-skill | mcp-server | cli-tool
plateforme: claude-code | universel | cli
categorie: skill/<famille>
sous_categories: []
auteur: 
source: 
source_url: 
install_cmd: 
licence: 
licence_type: 
domaines: []
score: 
status: discovered
mes_projets: []
created: <today>
modified: <today>
tags: [skill]
---
```

## Voir aussi

- `update-wiki-outil` (patcher une fiche existante, transitions de status)
- `audit-skills` (hygiène globale du catalogue Wiki/Outils/)
- `expand-stub` (étoffer une fiche encore en status: stub)
- `add-service` (distinction : Service = brique projet, Outil = outil perso)
- `add-wiki-concept` / `add-wiki-workflow` (autres types de fiches Wiki)
