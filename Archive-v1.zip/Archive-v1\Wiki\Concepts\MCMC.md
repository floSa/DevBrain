---
galaxie: wiki
nom: MCMC (Markov Chain Monte Carlo)
alias: [MCMC, Metropolis-Hastings, Gibbs sampling, HMC, NUTS]
type: concept
categorie: concept/probability
sous_categories: [mcmc, metropolis-hastings, gibbs, hmc, nuts, sampling]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Metropolis 1953, Hastings 1970, Geman 1984 (Gibbs), Duane 1987 (HMC), Hoffman-Gelman 2014 (NUTS)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, probability, mcmc, sampling, bayesian]
---

# MCMC — Markov Chain Monte Carlo

## TL;DR

Famille d'algorithmes pour **échantillonner d'une distribution $\pi$ inconnue (ou intractable)**, à condition de pouvoir évaluer $\pi(x)$ (ou seulement $\pi(x)$ à constante près). Construit une [[Markov chains|chaîne de Markov]] dont la **distribution stationnaire est $\pi$**, et échantillonne en suivant la chaîne suffisamment longtemps. Variantes : **Metropolis-Hastings** (général), **Gibbs sampling** (conditionnelles), **HMC** (gradient-based), **NUTS** (auto-tuning de HMC). Fondation de l'inférence bayésienne (PyMC, Stan).

## Le problème

En inférence bayésienne, on veut **échantillonner du posterior** $p(\theta | D)$. Mais :
- Le posterior est typiquement **intractable** (constante de normalisation $p(D)$ impossible à calculer)
- On peut calculer $p(\theta) p(D | \theta) \propto p(\theta | D)$ (numérateur)
- En haute dim, méthodes classiques (rejet, importance sampling) échouent

MCMC contourne en construisant une chaîne dont $\pi^* = p(\theta | D)$.

## L'idée

### Principe général

Construire une **chaîne de Markov** sur $\theta$ telle que :
1. Sa **distribution stationnaire** $\pi^*$ est la cible $\pi$
2. La chaîne est **ergodique** : on peut atteindre tout état depuis tout état

Alors par le théorème ergodique :

$$ \frac{1}{T} \sum_{t=1}^T f(\theta_t) \xrightarrow{T \to \infty} \mathbb{E}_\pi[f(\theta)] $$

→ moyennes temporelles de la chaîne approximent les espérances sous $\pi$.

### Metropolis-Hastings (le générique)

```
Initialiser θ_0
À chaque step t :
    1. Proposer θ' ~ q(θ' | θ_t)        # proposition (gaussienne souvent)
    2. Calculer ratio d'acceptation :
       α = min(1, [π(θ') q(θ_t | θ')] / [π(θ_t) q(θ' | θ_t)])
    3. Tirer u ~ U(0, 1)
       Si u < α : θ_{t+1} = θ'           (accepter)
       Sinon : θ_{t+1} = θ_t             (rejeter)
```

**Magie** : la constante de normalisation de $\pi$ se simplifie dans le ratio. On a besoin uniquement de $\pi$ à une constante près.

Choix de la proposition $q$ :
- **Gaussienne centrée** : $q(\theta' | \theta) = \mathcal{N}(\theta, \sigma^2 I)$ → MH symétrique, $q$ se simplifie
- **Variance trop petite** → marche peu, accepte tout, mais corrélation forte
- **Variance trop grande** → rejette beaucoup, peu de mouvement
- Optimal : taux d'acceptation ≈ **23%** en haute dim (Roberts et al.)

### Gibbs sampling

Cas spécial efficace quand on a accès aux **conditionnelles** $p(\theta_i | \theta_{-i})$ :

```
Initialiser θ_0
À chaque step :
    Pour i = 1 ... d :
        θ_i ← échantillonner depuis p(θ_i | θ_{-i})
```

Pas de rejet — chaque coordonnée est mise à jour. Marche bien sur modèles graphiques où les conditionnelles sont faciles (LDA, GMM).

### Hamiltonian Monte Carlo (HMC)

Utilise le **gradient** de $\log \pi$ pour proposer des moves intelligents. Idée : simuler une dynamique hamiltonienne fictive avec énergie = $-\log \pi(\theta) + p^\top p / 2$ ($p$ moment auxiliaire).

```
1. Tirer momentum p ~ N(0, I)
2. Simuler trajectoire hamiltonienne pendant L steps avec step ε
   (intégrateur leapfrog, utilise ∇ log π)
3. Acceptation MH classique sur la position finale
```

**Avantages** :
- Moves longue distance dans des directions informées par le gradient
- Mixing très rapide en haute dim
- Standard pour modèles bayésiens continus

**Hyperparams critiques** : $\varepsilon$ (step size) et $L$ (nb de leapfrog steps). Sensibles.

### NUTS (No-U-Turn Sampler)

Auto-tuning de HMC (Hoffman-Gelman 2014) : choisit automatiquement $L$ en arrêtant la trajectoire quand elle commence à "faire demi-tour".

**Standard de PyMC, Stan, NumPyro**. Excellent par défaut, peu de tuning.

### Diagnostics de convergence

**Indispensables** :

- **$\hat R$ (Gelman-Rubin)** : compare variance intra-chaîne et inter-chaînes. Si $\hat R < 1.01$, OK convergé.
- **ESS (Effective Sample Size)** : nombre d'échantillons indépendants équivalent. Si ESS très petit (< 100), chaîne mal mélangée.
- **Trace plots** : visualiser θ_t au cours du temps. Doit ressembler à du bruit, pas de tendance/cycle.
- **Autocorrelation function** : ACF des échantillons. Décroit vite = bon mixing.

### Burn-in et thinning

- **Burn-in** : jeter les premiers échantillons (1000-10000) avant que la chaîne converge
- **Thinning** : ne garder qu'un échantillon sur $k$ (réduit corrélation, mais perd info) — pratiquée moins maintenant qu'on utilise ESS directement

## Quand c'est utile

- **Inférence bayésienne** : posterior intractable (cf. [[PyMC]])
- **Modèles hiérarchiques** : mixed effects, GLMM bayésiens
- **Modèles latents** : LDA, GMM avec EM remplacé par Gibbs
- **Sampling depuis distribution avec densité connue** mais pas paramétrisée standard
- **Optimisation difficile** : simulated annealing est MCMC avec température décroissante
- **Vérification de modèles** (posterior predictive checks)

## Quand ça ne marche pas / pièges

- **Multimodalité** : MCMC peut rester piégé dans un mode. Solutions : parallel tempering, multiple chains, replica exchange.
- **Convergence non-vérifiée** : utiliser MCMC sans diagnostic = mauvaise pratique. Toujours $\hat R$ + ESS + trace plots.
- **Chains corrélées** : $T$ samples MCMC ≠ $T$ indep samples. ESS donne le vrai compte.
- **Cherryl-picking** : faire tourner plusieurs chaînes et garder la "meilleure" → biais.
- **Lent en haute dim** sans HMC : Metropolis simple inutilisable au-delà de quelques dizaines de paramètres
- **HMC mal réglé** : $\varepsilon$ trop grand → trajectoire instable et rejets. Trop petit → marche aléatoire. Utiliser NUTS.
- **Discret + continu mélangé** : HMC ne marche pas sur paramètres discrets. Utiliser Gibbs interne ou méthodes hybrides.
- **Coût** : chaque step nécessite évaluer $\pi$ (et son gradient pour HMC). Sur gros datasets, c'est lent — utiliser mini-batch MCMC ou variational inference.

## Code minimal

```python
import numpy as np
import pymc as pm

# Exemple PyMC : régression bayésienne simple
with pm.Model() as model:
    # Priors
    alpha = pm.Normal('alpha', mu=0, sigma=10)
    beta = pm.Normal('beta', mu=0, sigma=10)
    sigma = pm.HalfNormal('sigma', sigma=1)
    
    # Vraisemblance
    mu = alpha + beta * X
    y_obs = pm.Normal('y_obs', mu=mu, sigma=sigma, observed=y)
    
    # MCMC (NUTS par défaut)
    trace = pm.sample(2000, tune=1000, chains=4, target_accept=0.95)

# Diagnostics
import arviz as az
print(az.summary(trace))  # incl. r_hat, ess
az.plot_trace(trace)
az.plot_posterior(trace)

# Metropolis-Hastings from scratch (pour comprendre)
def metropolis(target_logpdf, x0, n_iter, proposal_scale=1.0):
    x = x0
    samples = []
    n_accepted = 0
    for _ in range(n_iter):
        x_new = x + np.random.normal(0, proposal_scale, size=x.shape)
        log_alpha = target_logpdf(x_new) - target_logpdf(x)
        if np.log(np.random.uniform()) < log_alpha:
            x = x_new
            n_accepted += 1
        samples.append(x.copy())
    print(f"Acceptance rate: {n_accepted / n_iter:.2%}")
    return np.array(samples)

# Cible : gaussienne 2D corrélée
def logpdf(x):
    return -0.5 * (x[0]**2 + x[1]**2 - 1.6 * x[0] * x[1])

samples = metropolis(logpdf, np.zeros(2), 10000, proposal_scale=0.5)
# Visualiser : samples[:, 0] vs samples[:, 1] forme une ellipse
```

## Pour aller plus loin

- Brooks et al., *Handbook of Markov Chain Monte Carlo* (2011) — bible
- Gelman et al., *Bayesian Data Analysis* (3e éd. 2013) — référence bayésienne
- Hoffman & Gelman, *The No-U-Turn Sampler* (JMLR 2014)
- Betancourt, *A Conceptual Introduction to Hamiltonian Monte Carlo* (2018) — pédagogique
- **Liens internes** : [[Markov chains]], [[PyMC]], [[Bootstrap]] (alternative non-bayésienne), [[Hypothesis testing]], [[KL divergence]] (variational alternative)
