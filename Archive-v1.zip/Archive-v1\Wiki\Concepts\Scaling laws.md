---
galaxie: wiki
nom: Scaling laws
alias: [Chinchilla, Kaplan, scaling laws, compute-optimal, emergent abilities]
type: concept
categorie: concept/llm-training
sous_categories: [scaling-laws, chinchilla, emergent, llm]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Kaplan 2020, Hoffmann 2022 (Chinchilla), Wei 2022 (Emergent)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, scaling, training]
---

# Scaling laws

## TL;DR

Les **lois empiriques** qui décrivent comment la **performance** d'un LLM scale avec **(N) params**, **(D) tokens d'entraînement**, **(C) compute**. **Kaplan et al. (2020)** : loss en power-law $L = (N_c/N)^{\alpha_N}$. **Chinchilla (Hoffmann 2022)** : pour budget compute fixe, optimum = $D \approx 20N$ (Llama 1 sous-entraîné ; Llama 3 over-trained à $D \gg 20N$). **Test-time compute** (o1, R1) : nouveau scaling au-delà du training. **Phénomènes émergents** : capacités absentes à petit modèle, apparaissent au-dessus d'un seuil (math, code, reasoning) — controversé. **Double descent**, **grokking** : phénomènes liés. Sert à **budgéter** training et **prédire** perf.

## Le problème

Si je veux entraîner un LLM, j'ai un **budget compute** (e.g. 10^24 FLOPs). Comment l'**allouer** entre :
- Plus de paramètres ?
- Plus de données ?
- Plus d'epochs ?

Réponse pré-Chinchilla : "scale params" (GPT-3, 175B). Réponse post-Chinchilla : "scale data aussi". Réponse 2024+ : "over-train pour cost-effective inference" + "scale test-time compute".

## L'idée

### Kaplan et al. (2020) — original scaling laws

Loss en fonction de $N$ (params), $D$ (tokens), $C$ (compute) :

$$ L(N) = (N_c / N)^{0.076} $$
$$ L(D) = (D_c / D)^{0.095} $$

**Power-law** : amélioration s'écrase à mesure qu'on scale.

Conclusion Kaplan : **params >> data**. Allouer 75% du budget aux params.

→ Influenza GPT-3 (175B sur 300B tokens).

### Chinchilla (Hoffmann 2022)

**Re-examen** des scaling laws avec meilleurs experiments. Résultat surprenant :

**Pour budget compute fixe, optimum = $D \approx 20 \cdot N$** (token-param ratio).

GPT-3 (175B, 300B tokens, ratio 1.7) → **sous-entraîné**.
Optimal serait : ~70B params + 1.4T tokens.

**Chinchilla 70B** : avec ce ratio, bat GPT-3 175B sur la plupart des benchmarks, à compute identique.

→ **Change le paradigme** : on entraîne maintenant plus longtemps sur plus de data.

### Au-delà de Chinchilla : over-training (Llama 2, 3)

Chinchilla = optimal **training compute**. Mais on déploie un modèle pour **inférer** N fois.

→ Si inference coût domine, **plus petit modèle, plus de tokens** est mieux. C'est l'**inference-optimal**.

**Llama 2 7B** : 2T tokens (ratio ~280). Llama 3 8B : 15T tokens (ratio ~1800). Loss continue à descendre, certes lentement, mais on amortit sur des milliards d'inferences.

### Formule de compute

$$ C \approx 6 N D $$

- $C$ : FLOPs (forward + backward)
- $N$ : params
- $D$ : tokens

Exemple Llama 3 70B sur 15T tokens : $C \approx 6 \cdot 7 \cdot 10^{10} \cdot 1.5 \cdot 10^{13} = 6.3 \cdot 10^{24}$ FLOPs.

### Inference-time scaling (o1, R1)

Nouveau paradigme depuis 2024 : **scaler le compute à l'inférence** (CoT long, RL on reasoning, MCTS).

- OpenAI o1, o3 : "long thinking" → meilleure perf reasoning
- DeepSeek-R1 : RL pur sur math/code → emergent CoT
- **Test-time compute** = nouvelle dimension du scaling

Trade-off training vs inference compute revisitable.

### Emergent abilities (Wei 2022)

**Observation** : certaines capacités sont **absentes** à petit modèle, apparaissent **abruptement** au-dessus d'un seuil.

Exemples typiques :
- Arithmétique multi-digit
- Word manipulation
- Reasoning chain
- Code

**Controverse** (Schaeffer 2023) : émergence est en partie un artefact de **métriques discrètes** (e.g. "exact match"). Avec métriques continues, l'amélioration est progressive.

Mais **certains comportements** restent franchement discontinus.

### Phénomènes liés

#### Double descent (Belkin 2019, Nakkiran 2021)

Pour certains modèles, loss en U-shape inverse : descend, monte, descend à nouveau quand on continue à scaler ou over-fit.

**Implications** : "more is better" non-monotone localement, mais globalement oui.

#### Grokking (Power 2022)

Modèles peut **mémoriser** d'abord, puis **généraliser** brusquement après long training (au-delà de l'overfit).

Visible sur small tasks algorithmiques (modular arithmetic).

#### Lottery Ticket Hypothesis (Frankle 2019)

Sous-réseaux "gagnants" existent dans un gros modèle, suffisants pour la perf.

#### Phase transitions

Behavior change discontinu à certains thresholds (model size, training steps).

### Data-constrained scaling

Si les data sont **limitées** (et le seront en 2026+) :
- Repeating data : marche jusqu'à certain point (Muennighoff 2023)
- Diminishing returns au-delà de 4 epochs
- Synthetic data devient essentielle

### Practical implications

#### Budgeter un training

Given budget $C$, paramètres :
- **Chinchilla optimal** : $N \propto C^{0.5}$, $D \propto C^{0.5}$
- $N = (C/6 \cdot 20)^{1/2}$

Exemple : $C = 10^{24}$ FLOPs → $N \approx 18$B, $D \approx 360$B tokens.

#### Choisir taille modèle

- Inference cost dominant → smaller model + more tokens (Llama-style)
- Training cost dominant → Chinchilla-optimal
- Single-use research → match Chinchilla pour comparaisons

#### Extrapolation de loss

Loss curve sur fraction du training → extrapole loss final. Permet de **prédire** si valable de continuer.

### Practical numbers (2026)

| Modèle | N | D (tokens) | Ratio D/N | Notes |
|---|---|---|---|---|
| GPT-3 | 175B | 300B | 1.7 | Sous-Chinchilla |
| Chinchilla | 70B | 1.4T | 20 | Optimal |
| Llama 2 7B | 7B | 2T | 286 | Over-trained |
| Llama 3 8B | 8B | 15T | 1875 | Heavy over-train |
| Llama 3 70B | 70B | 15T | 214 | Over-trained |
| Gemini Ultra | rumored | est. | varies | unknown |
| DeepSeek V3 | 671B (37B active) | 14.8T | ~22 / ~400 | MoE complicates |

### Critical batch size

Au-delà d'un certain batch size, gradient noise est suffisant et augmenter batch ne sert plus à rien. Important pour **distributed training** (linear scaling rule).

### Best practices

1. **Pas re-derive scaling laws** : utiliser celles publiées (Hoffmann 2022, etc.)
2. **Match inference vs training cost** : sur produit, over-train probable. Sur research, Chinchilla.
3. **Mesurer loss curve** : extrapoler avant de spend.
4. **Eval downstream task** vs juste loss : émergence peut hide.
5. **Plot log-log** : power laws apparaissent comme lignes.
6. **Iso-FLOP curves** : pour budget fixe, varier (N, D) → find optimum.
7. **Scale en plusieurs dims** : params, data, ctx length, training tokens (over-training).
8. **Réfléchir test-time compute** : maybe smaller model + more inference compute > bigger model.

## Quand c'est utile

- **Budgeter un training** : compute → choisir N, D
- **Comparer modèles** : iso-compute vs iso-data
- **Prédire perf** : extrapoler curve
- **Décider over-training** vs build bigger
- **Frontier research** : pousser les scaling
- **Inference cost analysis** : décide self-host vs API
- **Multi-modal scaling** : apply to VLMs (Kaplan 2024 multi)
- **Distillation strategy** : teacher / student trade-offs

## Quand ça ne marche pas / pièges

- **Extrapolation hors range** : scaling laws calibrées sur range donné, danger à extrapoler beaucoup au-dessus
- **Architecture change** : new arch (Mamba, MoE) ne suit pas mêmes laws
- **Data quality matter** : Chinchilla suppose "Tokens are equal" — wrong en pratique
- **Métriques discrètes** : "emergent" peut être artefact (Schaeffer 2023)
- **OPTML** : scaling laws ignorent l'inference compute, mais c'est ce qui domine en cost prod
- **Distillation breaks laws** : teacher distillation peut donner small models bien meilleurs que scaling laws prédiraient
- **Multi-modal data** : laws différentes pour vision, audio
- **RLHF / DPO** ne suivent pas mêmes laws
- **Single-experiment "this curve looks weird"** : ne pas confondre noise et law breakdown
- **"Bigger is better" naively** : trade compute cost et hosting cost matter
- **Data contamination** : test set leak en train → scaling appears continued

## Code minimal

```python
import numpy as np
import matplotlib.pyplot as plt

# Chinchilla optimal point
def chinchilla_optimal(C_flops):
    """Returns (N_params, D_tokens) for given compute budget."""
    N = (C_flops / 6 / 20) ** 0.5
    D = 20 * N
    return N, D

# Pour budget de 10^24 FLOPs (Llama 3 8B ballpark)
N, D = chinchilla_optimal(1e24)
print(f"Optimal N = {N/1e9:.1f}B params, D = {D/1e9:.1f}B tokens")
# ~18B params, 360B tokens

# Compute estimation : C = 6 * N * D
def estimate_compute(N_params, D_tokens):
    return 6 * N_params * D_tokens

print(f"Llama 3 8B : {estimate_compute(8e9, 15e12):.2e} FLOPs")
# ~7.2e23 FLOPs

# Power law fit
sizes = np.array([1e9, 7e9, 70e9, 175e9])
losses = np.array([2.5, 1.9, 1.5, 1.4])  # hypothetical
# Fit L = (N_c / N) ** alpha
from scipy.optimize import curve_fit
def power_law(N, N_c, alpha):
    return (N_c / N) ** alpha

popt, _ = curve_fit(power_law, sizes, losses, p0=[1e10, 0.1])
N_c, alpha = popt
print(f"Power law fit : alpha = {alpha:.3f}, N_c = {N_c:.1e}")

# Plot iso-FLOP curves (Chinchilla style)
fig, ax = plt.subplots()
for C in [1e22, 1e23, 1e24]:
    Ns = np.logspace(8, 12, 50)
    Ds = C / (6 * Ns)
    losses_curve = (N_c / Ns) ** alpha + (1e13 / Ds) ** alpha  # toy combined
    ax.plot(Ns, losses_curve, label=f"C={C:.0e}")
ax.set_xscale('log')
ax.set_xlabel("N params")
ax.set_ylabel("Loss")
ax.legend()
# Le min de chaque courbe = optimal N pour ce budget

# Cost / inference analysis
def cost_per_inference(N_params, n_tokens_per_call):
    """Approximate FLOPs per inference call."""
    return 2 * N_params * n_tokens_per_call  # forward only

# Compare 70B vs 7B en inference
calls_per_day = 1e9
flops_70b = cost_per_inference(70e9, 1000) * calls_per_day
flops_7b = cost_per_inference(7e9, 1000) * calls_per_day
print(f"70B inference / day : {flops_70b:.2e} FLOPs")
print(f"7B  inference / day : {flops_7b:.2e} FLOPs (10x cheaper)")
# Si 7B over-trained suffit → énorme économie en prod
```

## Pour aller plus loin

- Kaplan et al., *Scaling Laws for Neural Language Models* (2020)
- Hoffmann et al., *Training Compute-Optimal Large Language Models* (Chinchilla, NeurIPS 2022)
- Wei et al., *Emergent Abilities of Large Language Models* (TMLR 2022)
- Schaeffer, Miranda, Koyejo, *Are Emergent Abilities of Large Language Models a Mirage?* (NeurIPS 2023)
- Belkin et al., *Reconciling modern machine-learning practice and the classical bias–variance trade-off* (PNAS 2019) — double descent
- Power et al., *Grokking: Generalization Beyond Overfitting on Small Algorithmic Datasets* (2022)
- Muennighoff et al., *Scaling Data-Constrained Language Models* (NeurIPS 2023)
- Su et al., *Scaling Laws for Test-Time Compute* (2024)
- **Liens internes** : [[Bias-variance tradeoff]] (double descent), [[Generalization bounds]], [[Reasoning models]], [[Distillation]]
