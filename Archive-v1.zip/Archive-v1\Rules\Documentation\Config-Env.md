---
galaxie: dev
type: rule
domaine: documentation
applicable: global
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, documentation, config, env, pydantic-settings]
---

# Règle — Gestion des variables d'environnement et configuration

## Principe (1 phrase)
Toute configuration applicative passe par **un schéma typé et validé au démarrage** (Pydantic BaseSettings) — `os.getenv()` direct au milieu du code est interdit en MUST.

## MUST

### 1. Pydantic BaseSettings (interdiction de `os.getenv()` direct)

```python
# settings.py
from pydantic import Field, PostgresDsn
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    # Database
    database_url: PostgresDsn
    database_pool_size: int = Field(default=10, ge=1, le=100)

    # LLM
    anthropic_api_key: str = Field(min_length=10)
    llm_model: str = Field(default="claude-opus-4-7")

    # Vector DB
    qdrant_url: str = Field(default="http://localhost:6333")
    qdrant_api_key: str | None = None

    # App
    debug: bool = False
    log_level: str = Field(default="INFO", pattern="^(DEBUG|INFO|WARNING|ERROR)$")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="forbid",  # interdit les variables non déclarées
    )

settings = Settings()  # crash au démarrage si manquant/invalide
```

Bénéfices :
- **Validation au démarrage** (fail-fast)
- **Typage strict** : `int`, `bool`, `str`, `PostgresDsn`, `HttpUrl`, etc.
- **Auto-documentation** : `Settings.model_json_schema()` produit le schéma
- **`extra="forbid"`** : empêche les fautes de frappe silencieuses

### 2. Séparation des environnements

Quatre fichiers selon le contexte :

```
.env                    ← non commit (gitignored), valeurs locales du dev
.env.dev                ← dev mode default
.env.prod               ← prod (généralement pas dans le repo, dans le secret manager)
.env.test               ← pour les tests CI (mocks / containers)
.env.example            ← committé, refleté à 100% les vars requises
```

Charger selon le contexte :
```python
env = os.getenv("APP_ENV", "dev")
Settings(_env_file=f".env.{env}")
```

### 3. `.env.example` — transparence

- **Doit refléter EXACTEMENT** les vars du `Settings` Pydantic
- **Tenu à jour à chaque ajout/suppression** de variable
- **Pas de vraies valeurs** — placeholders : `<your_api_key>`, `<REPLACE_ME>`
- **Commentaires** sur les vars non triviales

```bash
# .env.example
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/myapp
DATABASE_POOL_SIZE=10  # taille du pool SQLAlchemy

# LLM (Anthropic)
ANTHROPIC_API_KEY=<your_anthropic_key>
LLM_MODEL=claude-opus-4-7

# Vector DB (Qdrant)
QDRANT_URL=http://localhost:6333
QDRANT_API_KEY=  # vide si pas d'auth

# App
DEBUG=false
LOG_LEVEL=INFO
```

### 4. Pas de secrets en clair dans le code ou les logs

- **Jamais** un secret hardcodé, même dans un commentaire
- **Jamais** un secret loggé (filter logging des champs `*_key`, `*_token`, `password`)
- Pour Pydantic Settings, marquer les fields sensibles avec `Field(repr=False)` :
  ```python
  anthropic_api_key: str = Field(repr=False)  # pas dans repr/print
  ```

## SHOULD

- **`.env.test` automatique** en CI (containers, fixtures)
- **Validation custom** avec `@field_validator` pour les contraintes métier
- **Defaults sensés** pour les vars non critiques (debug, timeouts)
- **`pydantic-settings` v2** (pas la v1 ni dotenv pur) — meilleure DX
- **Documentation** dans le `README.md` racine : section "Configuration" qui pointe vers `.env.example` + lien vers cette règle

## NICE

- **Secret manager** en prod (AWS Secrets Manager, HashiCorp Vault, Doppler) plutôt que `.env.prod`
- **Validation cross-fields** : ex: si `feature_x_enabled=True`, alors `feature_x_url` obligatoire
- **Auto-génération** du `.env.example` depuis les Settings (script `scripts/gen_env_example.py`)

## Pièges classiques

- **`os.getenv()` au milieu du code** : éparpille la config, pas de validation
- **`.env.example` qui diverge** du code → onboarding raté
- **Secrets commit** : pre-commit hook avec `git-secrets` obligatoire
- **Booléens** : `bool("false")` = `True` en Python ! Pydantic gère ça correctement, pas un parser custom
- **Variables avec valeur par défaut sensible en prod** : `debug=True` par défaut est dangereux
- **Pas de `extra="forbid"`** → typo dans `.env` non détectée

## Outils recommandés

- [`pydantic-settings`](https://docs.pydantic.dev/latest/concepts/pydantic_settings/) — validation typée
- [`python-dotenv`](https://github.com/theskumar/python-dotenv) — chargement `.env` (intégré dans pydantic-settings)
- [`git-secrets`](https://github.com/awslabs/git-secrets) — hook anti-leak
- [`detect-secrets`](https://github.com/Yelp/detect-secrets) — alternative Yelp

## Voir aussi

- [[README - Service]] — chaque service doit lister ses variables d'env
- [[Pydantic Settings]] — fiche Service (à créer si pas encore)
- [[Tests]] — règle tests (utilise `.env.test`)
