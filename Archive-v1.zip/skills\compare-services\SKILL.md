---
name: compare-services
description: |
  Use this skill when the user wants to compare multiple services/technos
  and create a Comparatif in their DevBrain. Triggers: "compare X et Y",
  "crée un comparatif", "fais-moi une base pour les <catégorie>".
  Generates either a .base (dynamic) or a .md (opinionated) in Patterns/.
---

# Skill — compare-services

## Quand l'utiliser

L'utilisateur veut **comparer plusieurs services** sur un thème ou une catégorie, et ranger le résultat dans `Patterns/` :
- "compare X et Y" → vue côte-à-côte
- "crée un comparatif des vector DBs open-source" → vue dynamique `.base`
- "explique pourquoi je choisis X plutôt que Y dans tel contexte" → opinion `.md`

Distinct de `add-pattern` (pattern architectural avec stack complète) et de `add-service` (création d'une seule fiche).

## Pré-requis vault

Mode build. Périmètre `Patterns/`.

## Décider le format

Si l'utilisateur veut une **vue dynamique** (filtrée sur frontmatter, mise à
jour auto quand on ajoute des fiches) → créer `.base`.

Si l'utilisateur veut une **opinion structurée** (pourquoi X plutôt que Y
dans tel contexte) → créer `.md`.

Demande explicitement si ce n'est pas clair.

## Format `.base`

```yaml
filters:
  and:
    - file.path.startsWith("Services/")
    - categorie == "<categorie>"   # ou IN [...]

views:
  - type: table
    name: "<titre>"
    order:
      - file.name
      - hosted
      - licence
      - maturite
      - score
      - clients_officiels
    sort:
      - property: score
        direction: desc
```

Path : `Patterns/Comparatif - <theme>.base`.

## Format `.md` opinionné

Frontmatter pattern + corps :

```markdown
# Comparatif — <X> vs <Y> vs <Z>

## Contexte
<quand cette comparaison s'applique>

## Tableau synthèse
| Critère | X | Y | Z |
|---------|---|---|---|
| Licence | ... | ... | ... |
| Hosted | ... | ... | ... |
| Maturité | ... | ... | ... |

## Mon choix par défaut
<X> parce que <raison>. Bascule vers <Y> si <condition>.

## Voir aussi
- [[X]], [[Y]], [[Z]]
```

Path : `Patterns/Comparatif - <theme>.md`.

## Procédure

1. Identifier la catégorie ou les services à comparer.
2. Vérifier que les fiches Services concernées existent. Si manquantes, proposer d'invoquer `add-service` d'abord.
3. Choisir format `.base` (dynamique) ou `.md` (opinionné).
4. Générer le fichier dans `Patterns/`.
5. Vérifier que le frontmatter `categorie` des Services concernés matche le filtre de la `.base`. Sinon, lister les écarts.

## Anti-patterns

- Créer un `.md` figé alors qu'une `.base` ferait le job (et restera à jour).
- Inventer des Services dans le tableau qui n'ont pas de fiche.
