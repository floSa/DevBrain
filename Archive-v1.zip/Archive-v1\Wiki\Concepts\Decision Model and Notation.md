---
galaxie: wiki
nom: Decision Model and Notation
alias: [DMN, decision-model-notation, decision modeling, decision tables]
type: concept
categorie: concept/business-rules
sous_categories: [dmn, decision-modeling, business-rules, omg, feel, decision-tables]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [OMG (Object Management Group), Bruce Silver, James Taylor]
lecture_min: 10
created: 2026-05-21
modified: 2026-05-21
tags: [concept, business-rules, dmn, decision-modeling, index]
---

# Decision Model and Notation — DMN

## TL;DR

Standard **OMG** depuis 2015 (DMN 1.5 approuvé mars 2023, version courante en 2026) pour formaliser la **logique de décision métier** en notation graphique + tabulaire. Complète **BPMN** (processus) et **CMMN** (case management) — la trinité OMG. Briques : **DRD** (Decision Requirements Diagram, vue graphique des décisions et dépendances), **Decision Tables** (lignes = règles, hit policies pour résoudre les conflits), **FEEL** (Friendly Enough Expression Language, langage d'expression standard), **BKM** (Business Knowledge Models, fonctions réutilisables). Exécutable par moteur (Camunda, Drools, OpenL Tablets). Cas d'usage : souscription, scoring, éligibilité, pricing, routing. Côté **ML/AI eng** : couche d'**audit + trust** au-dessus des modèles ML (déterministe, explicable, versionnable).

## Le problème

Trois pathologies récurrentes des règles métier en applis :

1. **Règles enfouies dans le code** → personne ne sait combien il y en a, le métier ne peut pas les valider, les changer demande un déploiement
2. **Règles disséminées** : un peu de SQL, un peu de IF/THEN, un peu d'Excel "validation_2024_v3.xlsx" → cauchemar d'audit
3. **Aucune trace du raisonnement** : "pourquoi ce dossier a été refusé ?" — bonne chance pour expliquer post-mortem

DMN est la réponse OMG : un **format standard, déclaratif, lisible business**, exécutable par un moteur, qui sépare la décision du processus.

## L'idée

### Trinité OMG

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│  BPMN 2.0    │     │   DMN 1.x    │     │  CMMN 1.1    │
│  Processus   │     │  Décisions   │     │  Cases       │
│  "Quoi quand"│     │  "Quelle     │     │  "Workflow   │
│              │     │   règle ?"   │     │   souple"    │
└──────┬───────┘     └──────┬───────┘     └──────────────┘
       │                    │
       │  task "Decide X"   │
       └────invoque ────────┘
```

BPMN modélise le **workflow** ("après réception, valider puis facturer"). DMN modélise **la logique de chaque décision** ("est-ce que ce dossier est éligible ?"). Ils se combinent : une tâche BPMN de type *Business Rule Task* invoque une décision DMN.

### Les 4 briques DMN

#### 1. DRD — Decision Requirements Diagram

Vue **graphique** des décisions et de leurs dépendances. 4 types de nœuds :

```
   ┌─────────┐         ┌─────────┐
   │ INPUT   │         │ INPUT   │      ovales = input data
   │  age    │         │ revenu  │
   └────┬────┘         └────┬────┘
        │                   │
        ▼                   ▼
   ┌──────────────────────────────┐
   │  DECISION : eligibilité      │     rectangles = decisions
   └──────────────┬───────────────┘
                  │
                  ▼
   ┌──────────────────────────────┐
   │  DECISION : taux applicable  │
   └──────────────┬───────────────┘
                  │
        ┌─────────┴─────────┐
        │                   │
   ┌────▼────┐         ┌────▼────┐
   │  BKM    │         │  KS     │       BKM = fonction réutilisable
   │ calcul  │         │ Norme   │       KS = knowledge source (humaine/doc)
   │ taux    │         │ Bâle    │
   └─────────┘         └─────────┘
```

Voir [[DRD - Decision Requirements Diagram]].

#### 2. Decision Tables

La forme la plus utilisée. Une table = une décision, avec lignes = règles :

| Règle | Âge | Revenu | → Eligibilité |
|---|---|---|---|
| 1 | < 25 | * | refusé |
| 2 | [25..65] | > 30000 | accepté |
| 3 | [25..65] | [15000..30000] | accepté avec garant |
| 4 | [25..65] | < 15000 | refusé |
| 5 | > 65 | > 50000 | accepté |
| 6 | > 65 | <= 50000 | refusé |

Hit policy (comment résoudre les multi-match) : **U** Unique, **A** Any, **F** First, **P** Priority, **R** Rule Order, **O** Output Order, **C** Collect. Voir [[Decision Tables]].

#### 3. FEEL — Friendly Enough Expression Language

Langage d'expression standard DMN. Lisible business, plus simple qu'un langage de programmation. Exemples :

```feel
// Conditions
age >= 18 and pays in ["FR", "BE", "CH"]

// Date arithmetic
date and time("2024-12-25") - date("2024-12-01")

// List comprehension
sum([item.montant | item in commandes, item.statut = "validée"])

// String / regex
contains(email, "@") and matches(email, "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$", "i")
```

Voir [[FEEL]].

#### 4. BKM — Business Knowledge Models

Fonctions **réutilisables** entre décisions. Ex : `calculerTaux(montant, durée, scoreCredit)` invoqué depuis plusieurs decisions. Voir [[BKM - Business Knowledge Model]].

### Conformance Levels

Trois niveaux d'implémentation pour les outils :

| Level | Couvre | Outils typiques |
|---|---|---|
| **L1** | DRD + decision tables sans exécution | Visio, Lucidchart (modeling only) |
| **L2** | L1 + FEEL "simplifié" (S-FEEL : ranges, lists, dates basiques) | beaucoup d'outils enterprise |
| **L3** | L2 + FEEL complet (lambdas, contexts, list comprehensions) | Camunda, Drools, Trisotech, OpenL Tablets |

Voir [[DMN Conformance Levels]].

### Boxed expressions

Plus généralement, une décision DMN n'est pas forcément une table — elle peut être :
- **Decision Table** (la plus courante)
- **Literal Expression** (une expression FEEL simple)
- **Invocation** (appel d'un BKM avec bindings)
- **Function** (définition d'un BKM)
- **Context** (key-value, comme un objet)
- **List**, **Relation** (collection)
- **Conditional**, **Iterator**, **Filter** (DMN 1.4+)

Voir [[Boxed Expressions]].

### Cas d'usage typiques

| Domaine | Exemple |
|---|---|
| **Assurance** | Tarification, souscription, gestion sinistres |
| **Banque** | Scoring crédit, KYC, AML compliance |
| **Telco** | Pricing forfaits, éligibilité offres |
| **Santé** | Triage, éligibilité remboursement |
| **RH** | Onboarding, validation notes de frais |
| **E-commerce** | Pricing dynamique, fraude, recommandation produit |
| **Public** | Calcul prestations sociales, éligibilité aides |

### Lien avec ML / AI engineering

DMN n'est pas natif ML, mais **complémentaire** dans une architecture mature :

1. **Layer trust / audit** au-dessus des modèles ML
   - Un modèle predict_score sort 0.73 → règle DMN décide : "si score > 0.85 → auto-approve, sinon humain"
   - Tu peux **auditer la décision finale** sans auditer le modèle (boîte noire)

2. **Hybrid AI**
   - DMN orchestre les appels au modèle et applique les règles métier "dures"
   - Garde la conformité réglementaire (RGPD, Bâle, MIFID) explicite

3. **Override humain**
   - DMN permet d'exprimer les **exceptions** : "si client VIP, ignore le score ML"
   - Auditeur / régulateur peut lire la règle

4. **Feature-store + DMN**
   - Features ML (Feast, Tecton) → input DMN → décision
   - Pipeline : feature store → ML model → DMN engine → action

Voir [[DMN and ML hybrid]] et [[Explainability and decision automation]].

## Quand c'est utile

- **Règles métier qui changent souvent** : le métier édite la table, déploiement = chargement nouveau XML
- **Audit / conformité critique** : RGPD, Bâle, MIFID, HIPAA — chaque décision tracée
- **Décisions complexes mais déterministes** : assurance, crédit, éligibilité
- **Layer trust au-dessus d'un modèle ML** : routing, threshold, exceptions
- **Communication métier ↔ dev** : un business analyst lit et corrige une decision table sans dev
- **Versioning des règles** : XML DMN versionné dans Git, diff lisible
- **Tests métier** : decision tables exécutables → testable unitairement
- **Combo BPMN** : workflow + décisions séparés mais combinables

## Quand ça ne marche pas / pièges

- **Décisions vraiment probabilistes** → modèle ML pur, DMN ajouterait du bruit
- **NLP / image / signal** → DMN n'est pas fait pour ça, restez en ML
- **Logique très procédurale** : si t'as 12 niveaux de IF imbriqués avec side-effects, DMN n'aidera pas (probable smell : c'est du processus = BPMN, pas une décision)
- **Équipe sans culture business-rules** : le coût d'adoption (outil + formation + ops) > bénéfice si peu de règles
- **Décisions à très haute fréquence** (microsecondes, trading HFT) : DMN engines ont une latence qui peut être incompatible — préférer code natif compilé
- **Sur-modélisation** : 200 decision tables alors que 5 SQL queries suffiraient
- **Confondre DMN avec un workflow** : DMN ≠ orchestration, c'est de la décision pure
- **Hit policy mal comprise** : choisir A (Any) sans s'assurer que toutes les règles qui matchent donnent le même résultat → bug silencieux
- **FEEL est un langage à part** : pas standardisé hors DMN, courbe d'apprentissage non nulle
- **Versioning XML DMN** : merge Git non-trivial (XML), préférer modeling tool avec workflow Git friendly
- **Trinité OMG sous-utilisée** : beaucoup d'orgs adoptent DMN sans BPMN/CMMN → manquent le combo
- **Conformance Level non clair** : un outil "supporte DMN" peut être L1 (modeling pur) sans exécution

## Code minimal

DMN est du **XML**, pas du code Python. Voici une decision table simple :

```xml
<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="https://www.omg.org/spec/DMN/20191111/MODEL/"
             xmlns:dmndi="https://www.omg.org/spec/DMN/20191111/DMNDI/"
             id="creditCheck" name="Credit Check"
             namespace="https://example.com/dmn">

  <decision id="eligibility" name="Eligibility">
    <informationRequirement>
      <requiredInput href="#age"/>
    </informationRequirement>
    <informationRequirement>
      <requiredInput href="#income"/>
    </informationRequirement>

    <decisionTable hitPolicy="UNIQUE">
      <input id="i1" label="Age"><inputExpression typeRef="number"><text>age</text></inputExpression></input>
      <input id="i2" label="Income"><inputExpression typeRef="number"><text>income</text></inputExpression></input>
      <output id="o1" label="Eligibility" typeRef="string"/>

      <rule id="r1">
        <inputEntry><text>&lt; 25</text></inputEntry>
        <inputEntry><text>-</text></inputEntry>
        <outputEntry><text>"refused"</text></outputEntry>
      </rule>
      <rule id="r2">
        <inputEntry><text>[25..65]</text></inputEntry>
        <inputEntry><text>&gt; 30000</text></inputEntry>
        <outputEntry><text>"accepted"</text></outputEntry>
      </rule>
      <rule id="r3">
        <inputEntry><text>[25..65]</text></inputEntry>
        <inputEntry><text>[15000..30000]</text></inputEntry>
        <outputEntry><text>"accepted_with_guarantor"</text></outputEntry>
      </rule>
      <!-- ... -->
    </decisionTable>
  </decision>

  <inputData id="age" name="age"/>
  <inputData id="income" name="income"/>
</definitions>
```

Exécution avec **Camunda 8** (Java/Spring) :

```java
DmnEngine engine = DmnEngineConfiguration.createDefaultDmnEngineConfiguration().buildEngine();
DmnDecision decision = engine.parseDecision("eligibility", inputStream);

VariableMap vars = Variables.createVariables()
    .putValue("age", 35)
    .putValue("income", 25000);

DmnDecisionResult result = engine.evaluateDecision(decision, vars);
System.out.println(result.getSingleResult().getSingleEntry()); // "accepted_with_guarantor"
```

Avec **pyDMNrules** (Python) :

```python
# pip install pyDMNrules
from pyDMNrules import DMN

dmn = DMN("credit_check.xlsx")   # ou .dmn XML
status, data = dmn.decide({"age": 35, "income": 25000})
print(data["eligibility"])        # "accepted_with_guarantor"
```

Avec **Drools** (Java, via kie-dmn) :

```java
KieServices ks = KieServices.Factory.get();
KieContainer kContainer = ks.getKieClasspathContainer();
DMNRuntime runtime = kContainer.newKieSession().getKieRuntime(DMNRuntime.class);

DMNModel model = runtime.getModel("https://example.com/dmn", "Credit Check");
DMNContext ctx = runtime.newContext();
ctx.set("age", 35);
ctx.set("income", 25000);

DMNResult result = runtime.evaluateAll(model, ctx);
System.out.println(result.getDecisionResultByName("Eligibility").getResult());
```

## Pour aller plus loin

- Spec OMG officielle : https://www.omg.org/spec/DMN/
- Bruce Silver, *DMN Method and Style* (2018) — la référence pédagogique
- James Taylor, *Real-World Decision Modeling with DMN* (2016)
- DMN TCK (Technology Compatibility Kit) : https://dmn-tck.github.io/tck/ — suite de tests d'interopérabilité
- Camunda DMN docs : https://docs.camunda.io/docs/components/modeler/dmn/
- DMN Cookbook (KIE / Drools) : https://docs.drools.org/
- **Liens internes** : [[DRD - Decision Requirements Diagram]], [[Decision Tables]], [[FEEL]], [[BKM - Business Knowledge Model]], [[Boxed Expressions]], [[DMN Conformance Levels]], [[BPMN DMN CMMN]], [[Decision Intelligence]], [[DMN and ML hybrid]], [[Explainability and decision automation]]
