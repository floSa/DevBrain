---
galaxie: dev
nom: bokeh
alias: [bokeh]
categorie: tooling/viz
sous_categories: [visualization, interactive, web, python, dashboards]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python / TypeScript
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["plotly", "matplotlib", "altair", "seaborn", "Streamlit"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, viz, interactive, dashboards]
url_officiel: https://bokeh.org/
url_docs: https://docs.bokeh.org/
url_repo: https://github.com/bokeh/bokeh
---

# bokeh

## Pourquoi

Library Python de **visualisation interactive pour le web**. Génère du **BokehJS** (TypeScript) qui rend dans le navigateur : zoom, pan, hover tooltips, sélection, callbacks JS, streaming temps réel. Embedable comme HTML statique ou servi via **Bokeh Server** (réactif, callbacks Python live).

Concurrent direct de **plotly** : moins polish "out of the box" mais **plus puissant côté streaming / very-large-data** (combo `datashader` pour 100M+ points), **callbacks Python serveur** propres, **API plus stable**. Souvent associé à **Panel** (sister project, framework dashboard Python complet basé sur Bokeh + ipywidgets).

## Quand l'utiliser

- **Dashboards interactifs custom** : callbacks, widgets, layout complexe
- **Plots web embedable** : HTML standalone à intégrer dans un site
- **Visualisations très grandes** (10M-100M+ points) via **datashader**
- **Combo Panel** pour apps Python (alternative à Streamlit/Dash)
- **Streaming temps réel** : update plots live (sensors, monitoring)
- **Callbacks Python serveur** : widget bouge → fonction Python → update plot
- **Geo-visualisation** : tiles + GeoJSON natif
- **Plots scientifiques publication** : control fin du style

## Quand NE PAS l'utiliser

- **Notebooks / plots statiques** → matplotlib / seaborn (plus simples)
- **Polish ready-made** : plotly a meilleur design par défaut
- **Apps prod end-user** → Streamlit / Gradio (UI plus facile)
- **Dashboards BI classiques** → Superset / Metabase / Grafana
- **Plots grammar-of-graphics déclaratif** → altair (Vega-Lite)
- **Très petit besoin viz** : seaborn + 5 lignes suffit

## Pièges connus

- **API plus verbose** que plotly express : il faut souvent construire le plot couche par couche
- **Doc moins claire** : bonne mais éparpillée entre user guide et reference, moins de cookbooks
- **Communauté plus petite** que plotly/matplotlib → moins de Stack Overflow
- **Bokeh Server complexe à setup** en prod : Tornado + bokeh serve + reverse proxy à orchestrer
- **Versioning JS / Python à matcher** : bokehjs version doit correspondre à bokeh Python
- **Notebooks Jupyter** : `output_notebook()` + parfois extensions à charger
- **Légends customisation lourde** : positions, multi-lines, à tweaker
- **`ColumnDataSource` à connaître** : structure pivot pour mettre à jour des plots
- **Static export PNG/PDF** : nécessite `selenium` + chromedriver/geckodriver → friction
- **Pas de "express" API** : plotly.express > bokeh sur ergonomie

## Code minimal

```bash
pip install bokeh
# Optionnels
pip install panel datashader holoviews
```

```python
from bokeh.plotting import figure, show, output_file
import numpy as np

x = np.linspace(0, 10, 200)
y = np.sin(x)

p = figure(
    title="Sinusoide interactive",
    x_axis_label="x", y_axis_label="sin(x)",
    width=700, height=400,
    tools="pan,wheel_zoom,box_zoom,reset,save,hover",
)
p.line(x, y, line_width=2, color="navy", legend_label="sin(x)")
p.circle(x[::10], y[::10], size=8, color="firebrick", alpha=0.5)

output_file("sinus.html")
show(p)
```

```python
# Plot interactif avec hover + ColumnDataSource
from bokeh.models import ColumnDataSource, HoverTool
import pandas as pd

df = pd.DataFrame({
    "x": [1, 2, 3, 4, 5],
    "y": [3, 7, 2, 8, 5],
    "name": ["A", "B", "C", "D", "E"],
})
source = ColumnDataSource(df)

p = figure(width=600, height=400, tools="pan,wheel_zoom,reset")
p.scatter("x", "y", size=15, source=source, color="green")
p.add_tools(HoverTool(tooltips=[
    ("Name", "@name"),
    ("(x, y)", "(@x, @y)"),
]))
show(p)
```

```python
# Bokeh Server : callback Python live
# fichier : app.py
from bokeh.io import curdoc
from bokeh.layouts import column
from bokeh.models import Slider, ColumnDataSource
from bokeh.plotting import figure
import numpy as np

x = np.linspace(0, 10, 200)
source = ColumnDataSource(data={"x": x, "y": np.sin(x)})

p = figure(width=600, height=400)
p.line("x", "y", source=source)

freq = Slider(title="Frequence", start=0.1, end=5, step=0.1, value=1)
def update(attr, old, new):
    source.data = {"x": x, "y": np.sin(freq.value * x)}
freq.on_change("value", update)

curdoc().add_root(column(freq, p))
# Lancer : bokeh serve --show app.py
```

```python
# Datashader pour 100M points
import datashader as ds
from datashader.bokeh_ext import InteractiveImage
import pandas as pd

df = pd.DataFrame({"x": np.random.randn(100_000_000),
                   "y": np.random.randn(100_000_000)})

def create_image(x_range, y_range, w, h):
    canvas = ds.Canvas(plot_width=w, plot_height=h, x_range=x_range, y_range=y_range)
    agg = canvas.points(df, "x", "y")
    return ds.transfer_functions.shade(agg, cmap="viridis")

p = figure(width=800, height=600)
InteractiveImage(p, create_image)
```

## Liens

- plotly — alternative populaire, API plus accessible
- matplotlib — alternative statique standard
- altair — alternative déclarative (Vega-Lite)
- seaborn — alternative statistique
- Panel — sister project (dashboards Python complets)
- HoloViews — abstraction haut-niveau sur Bokeh
- datashader — combo big data viz (100M+ points)
- Docs : https://docs.bokeh.org/
- GitHub : https://github.com/bokeh/bokeh
