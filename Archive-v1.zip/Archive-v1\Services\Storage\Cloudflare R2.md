---
galaxie: dev
nom: Cloudflare R2
alias: [r2]
categorie: storage/object
sous_categories: [object-storage, s3-api, no-egress, edge]
licence: Proprietaire (managed)
licence_type: proprietary
hosted: managed
maturite: production
langage: 
clients_officiels: [boto3-compatible, ts, go]
plateforme: [cloud]
score: 4
mes_projets: []
alternatives: ["[[AWS S3]]", "[[MinIO]]", Backblaze B2]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, storage, s3-compat, cloudflare]
url_officiel: https://www.cloudflare.com/products/r2/
url_docs: https://developers.cloudflare.com/r2/
url_repo: 
---

# Cloudflare R2

## Pourquoi
Stockage objet **S3-compatible** avec **egress gratuit**. C'est l'argument principal : Cloudflare ne facture **pas** la sortie data (vs AWS S3 ~$0.09/GB). Idéal pour content distribution, CDN-style, AI dataset serving.

## Quand l'utiliser
- Serving public massif (vidéos, ML datasets téléchargés)
- Multi-cloud sans vendor lock-in egress
- App qui transfère beaucoup de data vers internet
- AI inference cache où le modèle est lu en boucle
- Cas d'usage CDN (combiner avec Workers)

## Quand NE PAS l'utiliser
- Intégration native AWS (Lambda triggers, etc.) → reste sur [[AWS S3]]
- Compliance/régulations qui exigent une région AWS spécifique
- Tooling AWS-natif lourd (DataSync, etc.)
- Features S3 avancées : Object Lambda, Replication multi-region native

## Pièges connus
- **Pas 100% S3 compat** : quelques APIs avancées manquent (Object Lock partiel, certaines features de replication)
- **Pricing storage** : ~$0.015/GB (un peu plus que S3 Standard $0.023), donc le break-even est sur l'egress
- **Class A vs Class B ops** : writes plus chères que reads
- **Workers binding** : pour latence ultra-basse, utiliser direct depuis Workers (pas via HTTPS)
- **Pas de tiering automatique** (Glacier-like) — pour cold storage froide, pas l'optimal

## Liens
- [[AWS S3]] — alternative cloud premium
- [[MinIO]] — self-host
- Docs R2 : https://developers.cloudflare.com/r2/
- Pricing : https://www.cloudflare.com/r2/pricing/
