---
galaxie: dev
type: pattern
contexte: pipeline ELT (Extract-Load-Transform) pour datasets petits à moyens (< 1 TB), stack moderne 2025-2026 sans data warehouse cloud
created: 2026-05-19
modified: 2026-05-19
services_cles: ["[[DuckDB]]", "[[Polars]]", "[[Airflow]]", "[[Dagster]]", "[[Parquet]]"]
projets_appliques: []
tags: [pattern, elt, data-eng, duckdb, dbt]
---

# Pattern — Pipeline ELT moderne

## Contexte

Tu construis un pipeline data pour ingester des sources (API, CSV, DB OLTP), les **stocker en Parquet**, et les transformer en datasets analytiques exploitables. Volumétrie petite à moyenne (< 1 TB compressé). Pas de gros budget cloud DWH ([[Snowflake]]/[[BigQuery]]), mais besoin de qualité production.

Le pattern repose sur la trinité **Parquet + DuckDB + dbt-duckdb** (ou Polars pour transfos Python) — devenue mainstream en 2024-2026.

Si tu as > 10 TB ou besoin de cluster massif, passer à Spark / Trino. Si tu veux cloud-native, BigQuery + dbt-bigquery.

## Stack

- **Stockage** : [[Parquet]] (columnar, compressé) sur S3 / disk local. Convention de partitionnement `year=/month=/day=`.
- **Engine de transformation** : [[DuckDB]] (SQL, in-process) + dbt-duckdb pour la modélisation
- **Transfos Python custom** : [[Polars]] (DataFrame Rust, lazy, 10× pandas)
- **Orchestration** : [[Dagster]] (asset-based, moderne) ou [[Airflow]] (mature, standard)
- **Quality** : Great Expectations ou dbt tests natifs
- **Catalog** : Apache Iceberg ou simplement un dossier `_catalog/` versionné
- **Observability** : OpenTelemetry → Datadog/Grafana

## Structure de projet

```
my-elt/
├── pyproject.toml
├── README.md
├── docker-compose.yml         # DuckDB, MinIO (S3-compatible), Dagster UI
├── dagster_project/           # ou airflow/dags/
│   ├── definitions.py         # Dagster Definitions
│   └── assets/
│       ├── raw/               # sources brutes (API, fichiers)
│       ├── bronze/            # Parquet brut sur S3
│       ├── silver/            # nettoyé, dédupliqué, conformé
│       └── gold/              # agrégations métier
├── dbt_project/
│   ├── dbt_project.yml
│   ├── models/
│   │   ├── staging/           # nettoyage par source
│   │   ├── intermediate/      # joins, dérivations
│   │   └── marts/             # tables métier
│   ├── tests/                 # data quality
│   └── seeds/                 # données de référence
├── python/                    # transfos Polars custom (quand SQL pas adapté)
│   └── transforms/
│       ├── parse_complex_json.py
│       └── ml_feature_eng.py
└── tests/
```

## Décisions clés

### 1. ELT au lieu d'ETL

**Extract → Load (brut) → Transform** plutôt que **Extract → Transform → Load**.

Pourquoi :
- Garder le brut → tu peux re-transformer plus tard sans re-ingérer
- Séparer infrastructure (extract+load) du métier (transform)
- Tests possibles sur les transformations en isolation
- Audit trail : tu peux reproduire toute transformation

### 2. Format Parquet + partitionnement temporel

```
s3://my-bucket/bronze/orders/
  └── year=2026/
       └── month=05/
            └── day=19/
                 └── data.parquet
```

Avantages :
- Compression 5-10× vs CSV/JSON
- Lecture columnar (DuckDB / Polars / Spark / Trino tous compatibles)
- Pruning de partition → ne lit que les jours pertinents
- Évolution de schéma supportée (avec quelques précautions)

### 3. Architecture Bronze / Silver / Gold (Medallion)

Inspirée Databricks, applicable partout :

- **Bronze** : ingestion brute, **immutable**. Tel quel depuis la source, juste typé.
- **Silver** : nettoyé (dédup, valeurs manquantes, format dates), conforme, **prêt à analyser**.
- **Gold** : agrégations métier, jointures, datasets prêts pour la consommation (BI, ML features).

Cette discipline force la séparation et permet de re-jouer chaque couche indépendamment.

### 4. DuckDB pour 80% des transfos

DuckDB lit Parquet directement, exécute du SQL ANSI, scale jusqu'à ~100 GB sur un laptop. Pour tout ce qui est joinable / agrégeable / aggrégable :

```sql
-- dbt model silver/orders.sql
SELECT
    order_id,
    customer_id,
    amount_cents / 100 AS amount_eur,
    DATE_TRUNC('day', order_ts) AS order_date,
    CASE 
        WHEN amount_cents > 100000 THEN 'high'
        ELSE 'normal' 
    END AS amount_tier
FROM read_parquet('s3://bucket/bronze/orders/year=*/month=*/day=*/data.parquet')
WHERE order_ts IS NOT NULL
QUALIFY ROW_NUMBER() OVER (PARTITION BY order_id ORDER BY ingestion_ts DESC) = 1
```

### 5. Polars pour les transfos Python complexes

Quand SQL devient illisible (parsing JSON imbriqué, feature engineering ML, opérations stat) :

```python
import polars as pl

df = (
    pl.scan_parquet('s3://bucket/bronze/events/*.parquet')   # lazy
    .filter(pl.col('user_id').is_not_null())
    .with_columns([
        pl.col('payload').str.json_decode().alias('p'),
        (pl.col('ts') - pl.col('ts').shift(1)).alias('delta_t'),
    ])
    .group_by('user_id')
    .agg([
        pl.col('delta_t').mean().alias('avg_delta'),
        pl.col('p').struct.field('amount').sum().alias('total_amount'),
    ])
    .collect()                                                # exec
)
```

### 6. dbt-duckdb pour la modélisation

dbt avec adapter DuckDB :
- Modélisation SQL versionnée
- Tests data (uniqueness, not null, foreign key, custom)
- Lineage automatique
- Documentation générée

```yaml
# dbt_project/models/silver/schema.yml
models:
  - name: silver_orders
    columns:
      - name: order_id
        tests: [unique, not_null]
      - name: customer_id
        tests:
          - not_null
          - relationships:
              to: ref('silver_customers')
              field: customer_id
```

### 7. Orchestration : Dagster (moderne) ou Airflow (mature)

| Critère | Dagster | Airflow |
|---|---|---|
| Modèle mental | Assets (les données sont 1ère classe) | Tasks (DAG d'opérations) |
| Lineage automatique | ✅ natif | ⚠️ via plugins |
| Local dev | ✅ excellent (UI locale) | ⚠️ docker-compose lourd |
| Communauté / hire | Plus petite | Énorme |
| Choisir si | Greenfield, focus data assets | Equipe existante Airflow, autres usages que data |

**Mon défaut** : [[Dagster]] pour nouveaux projets, [[Airflow]] si déjà en place.

### 8. Data quality dès le bronze

`expectations/`:
- Counts par jour (alerte si chute inattendue)
- Schema check (alerte si nouvelle colonne)
- Distribution (alerte si dérive)

Avec [[Great Expectations]] ou dbt tests + freshness :

```yaml
- name: bronze_orders
  freshness:
    error_after: {count: 6, period: hour}
```

## Pièges (vu en projets)

- **Schéma qui dérive** silencieusement (nouvelle colonne en source) → casse les transfos. dbt tests + schema versioning obligatoires.
- **Pas de partitionnement** : re-lire tout l'historique à chaque run → coût et lenteur. Toujours partition temporelle.
- **Mélanger Bronze/Silver** : appliquer dédup + cleaning au stade bronze → tu perds l'audit trail. Bronze = brut, point.
- **Trop de petits fichiers Parquet** (1 par minute) → pénalité S3, lecture lente. Compaction périodique (par jour ou semaine).
- **Tests data oubliés** → bug en prod 6 mois plus tard sur une colonne corrompue
- **dbt-duckdb sur S3 sans cache** : re-télécharge tout à chaque run. Configurer un cache local ou Iceberg.
- **Polars 0.x → 1.x** : breaking changes fréquents, pinner précisément
- **Cron job pour ordonnancement** : oubli des dépendances entre tâches → ré-implémente Airflow / Dagster naïvement. Mieux vaut l'outil.

## Voir aussi

- Concepts : (à venir : data quality, schema drift, idempotence)
- Services : [[DuckDB]], [[Polars]], [[Parquet]], [[Airflow]], [[Dagster]]
- Workflows : [[Debug pipeline data]]
- Patterns liés : [[Pattern - API REST FastAPI minimale]] (souvent l'API qui consomme les gold tables)
- Rules applicables : [[Rules/Types/Data-pipeline]]
