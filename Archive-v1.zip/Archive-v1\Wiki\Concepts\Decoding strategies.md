---
galaxie: wiki
nom: Decoding strategies
alias: [greedy, beam search, top-k, top-p, nucleus, temperature, sampling]
type: concept
categorie: concept/llm-inference
sous_categories: [decoding, sampling, generation, llm]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Holtzman 2020 (nucleus), Su 2022 (contrastive)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, decoding, sampling, inference]
---

# Decoding strategies

## TL;DR

Une fois qu'un LLM produit des **logits** sur le vocabulaire au step $t$, comment **choisir le token** ? Deterministes : **greedy** (argmax), **beam search** (top-k beams). Stochastiques : **temperature**, **top-k**, **top-p (nucleus)**, **min-p**. **Repetition penalties** (frequency, presence, no-repeat-ngram, DRY) pour éviter loops. **Contrastive search** pour génération diverse + qualité. Choix critique : trop greedy = répétitif/déterministe ; trop random = incohérent. **Standard moderne** : $\text{temp}=0.7$ + $\text{top-p}=0.9$ pour chat, $\text{temp}=0$ pour reasoning structuré (code, math).

## Le problème

Un LLM produit $P(y_t | y_{<t}, x)$ — distribution sur le vocab. Comment en tirer un **token** ? Plein de choix avec des effets très différents sur fluence, diversité, factualité.

## L'idée

### Greedy decoding

$$ y_t = \arg\max_y P(y_t = y) $$

Toujours le token le plus probable.

- **Déterministe** (sauf temperature 0 dans probas)
- **Répétitif** : tend à boucler, mode collapse
- Standard pour **tâches déterministes** (math, code structuré)
- Cas spécial : `temperature=0` dans la plupart des APIs

### Beam search

Garder top-$k$ **séquences partielles** (beams) à chaque step. Choisir la séquence finale qui maximise la probabilité jointe.

- Mieux que greedy en log-likelihood
- **Texte trop régulier**, manque de surprise → unnatural
- Standard en **traduction**, summarization (où la "bonne" réponse existe)
- Variants : **diverse beam search** (Vijayakumar 2018) pour diversité inter-beams
- **Length penalty** : pénaliser sequences trop courtes/longues

### Sampling stochastique

#### Temperature scaling

$$ P_\tau(y) = \frac{\exp(z_y / \tau)}{\sum_{y'} \exp(z_{y'} / \tau)} $$

- $\tau < 1$ : distribution plus piquée (proche greedy)
- $\tau = 1$ : softmax standard
- $\tau > 1$ : plus uniforme (plus aléatoire)
- $\tau \to 0$ : limite = greedy

Standard : $\tau = 0.7$ pour chat, $\tau = 1.0$ pour brainstorm créatif.

#### Top-k sampling

Garder les $k$ tokens les plus probables, re-normaliser, sample dans :

$$ P'(y) = \begin{cases} P(y) / Z & \text{si } y \in \text{top-}k \\ 0 & \text{sinon} \end{cases} $$

- $k$ typique : 10-50
- **Problème** : taille fixe → trop restrictif si distribution piquée, trop large si plate

#### Top-p (Nucleus, Holtzman 2020)

Garder le **plus petit ensemble** de tokens tel que somme proba ≥ $p$.

- **Adaptatif** : peu de tokens si modèle confiant, plus si incertain
- Standard moderne : $p = 0.9-0.95$
- Souvent combiné avec temperature

#### Min-p (Liu 2024)

Garder tokens $y$ tels que $P(y) \geq p_{min} \cdot \max_{y'} P(y')$.

- Relativement nouveau, performant
- Plus robuste que top-p sur distributions piquées
- $p_{min} = 0.05-0.1$ typique

#### Typical sampling (Meister 2022)

Sampler tokens dont la log-probability est **proche de l'entropy** — évite tokens trop prévisibles et trop surprenants.

#### Mirostat (Basu 2021)

Maintien dynamique de la perplexity cible via feedback. Génération plus "lisse".

#### η-sampling, Tail-free, Top-A

Variantes adaptatives. Moins standard mais utile pour fine-tuning de la qualité.

### Penalties

#### Repetition penalty

Pénaliser tokens **déjà apparus** :

$$ P'(y) \propto P(y) / \theta^{c(y)} $$

avec $c(y)$ = nombre d'occurrences, $\theta \geq 1$ (typ. 1.1-1.3).

#### Frequency / Presence penalty (OpenAI)

- **Presence** : pénaliser si déjà présent (binaire)
- **Frequency** : pénaliser proportionnellement à la fréquence

#### No-repeat n-gram

Interdire répéter une **séquence de $n$ tokens** déjà générée. Évite les boucles "I am happy I am happy I am happy".

#### DRY (Don't Repeat Yourself)

Évolution récente : pénaliser intelligemment les répétitions longues sans pénaliser les patterns naturels.

### Contrastive decoding (Li 2022)

Au lieu de juste maximiser P, **maximiser la différence** entre la distribution du gros modèle et celle d'un small "amateur" :

$$ y_t = \arg\max_y \log P_{\text{expert}}(y) - \lambda \log P_{\text{amateur}}(y) $$

- Réduit les modes failures du small
- Améliore reasoning sans entraînement

#### Contrastive Search (Su 2022)

Combine probabilité + diversité (penalty sur similarité avec contexte récent) :

$$ y_t = \arg\max_y (1-\alpha) P(y) - \alpha \cdot s(h_y, H) $$

où $s$ est cosine similarity. Évite degenerate repetition.

### DoLa (Chuang 2024)

Decoding by Layer Contrasting : contraster logits de la dernière layer vs layers intermédiaires → mieux factualité, moins d'hallucinations.

### Stop conditions

- **Max tokens** : limit absolu
- **Stop sequences** : strings qui terminent la génération (e.g. `</answer>`)
- **EOS token** : modèle a "fini"
- **Custom stop**: regex, json valide, etc.

### Logit manipulation

Modifications brutes des logits avant softmax :
- **Logit bias** : forcer / interdire des tokens
- **Banned tokens** : interdire (e.g. swear words)
- **Structured output** : forcer JSON schema (voir [[Structured outputs]])

### Choix recommandés

| Tâche | Décodage |
|---|---|
| **Code / math / reasoning structuré** | greedy ou T=0 |
| **Chat / Q&A factuel** | T=0.7, top-p=0.9 |
| **Creative writing** | T=0.9-1.2, top-p=0.95 |
| **Brainstorming** | T=1.0+, min-p=0.05 |
| **Translation** | beam search 5-10 |
| **Summarization** | beam search 4 |
| **Avoid loops** | + repetition_penalty=1.1 |
| **Reasoning models (o1, R1)** | T=0.6, top-p=0.95 (recommend) |

### Best practices

1. **Reasoning structuré → T=0** : on veut le best answer, pas la diversité
2. **Chat → T=0.7 + top-p=0.9** : standard solide
3. **Mesurer perplexity vs perception** : low PPL ≠ better user perception
4. **Repetition penalty** modéré (1.1) : ne pas exagérer (peut casser code)
5. **Ne pas combiner** trop : top-p + top-k + min-p + temperature ensemble = behavior chaotique
6. **Stop sequences explicites** : éviter `\n\nUser:` qui pollue
7. **Streaming** : décoder token-by-token pour latence perçue
8. **Self-consistency** (Wang 2022) : sample $N$ fois, vote majoritaire → boost reasoning

## Quand c'est utile

- **Tout LLM en production** : choix de décodage impacte la qualité
- **Optimisation qualité** : tuner temperature/top-p pour use case
- **Diverse outputs** : creative apps need T>0
- **Deterministic apps** : code, math, parsing need T=0
- **Self-consistency** : reasoning boost en samplant plusieurs
- **Cost reduction** : penalty pour éviter loops infinis
- **Constrained output** : combiner avec structured output

## Quand ça ne marche pas / pièges

- **T=0 + reasoning** : peut converger vers réponse fausse mais confiante (no exploration)
- **High T** sur knowledge tasks : hallucinations explosent
- **Beam search degeneration** : "thank you" "thank you" "thank you"
- **Top-p sur piquée** : trivial (1 token dans 90%), aucun effet
- **Top-k trop bas** : modèle bloqué dans top tokens
- **Repetition penalty trop fort** : casse code (tokens valides répétés normalement), tabs
- **No-repeat n-gram=2** sur poetry : peut interdire patterns naturels
- **Combiner multiple penalties** : interactions imprévisibles
- **Stop sequences mal choisies** : génération coupée trop tôt
- **Streaming + structured output** : difficile, partial JSON
- **EOS oublié** : modèle génère jusqu'à max_tokens même si fini
- **Different libs different defaults** : OpenAI T=1 default, HF T=1 default, mais signification ≠ après softmax variations

## Code minimal

```python
import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer

model = AutoModelForCausalLM.from_pretrained("meta-llama/Meta-Llama-3-8B-Instruct",
                                                torch_dtype=torch.bfloat16, device_map="auto")
tokenizer = AutoTokenizer.from_pretrained("meta-llama/Meta-Llama-3-8B-Instruct")

prompt = "The capital of France is"
inputs = tokenizer(prompt, return_tensors="pt").to("cuda")

# 1. Greedy
out = model.generate(**inputs, max_new_tokens=50, do_sample=False)
print(tokenizer.decode(out[0], skip_special_tokens=True))

# 2. Beam search
out = model.generate(**inputs, max_new_tokens=50, num_beams=4, no_repeat_ngram_size=2)

# 3. Temperature sampling
out = model.generate(**inputs, max_new_tokens=50, do_sample=True, temperature=0.7)

# 4. Top-k
out = model.generate(**inputs, max_new_tokens=50, do_sample=True, top_k=50)

# 5. Top-p (nucleus)
out = model.generate(**inputs, max_new_tokens=50, do_sample=True, top_p=0.9)

# 6. Combined: T + top-p + repetition penalty
out = model.generate(
    **inputs,
    max_new_tokens=200,
    do_sample=True,
    temperature=0.7,
    top_p=0.9,
    repetition_penalty=1.1,
    no_repeat_ngram_size=3,
)

# 7. Stop sequences
out = model.generate(
    **inputs,
    max_new_tokens=500,
    stopping_criteria=[StoppingCriteria(...)]
)

# 8. Contrastive search
out = model.generate(**inputs, max_new_tokens=100, penalty_alpha=0.6, top_k=4)

# 9. Self-consistency for reasoning
def self_consistent(model, prompt, n=10):
    samples = []
    for _ in range(n):
        out = model.generate(prompt, do_sample=True, temperature=0.7)
        answer = extract_answer(tokenizer.decode(out[0]))
        samples.append(answer)
    from collections import Counter
    return Counter(samples).most_common(1)[0][0]  # majority vote

# 10. Custom : top-p impl from scratch
def top_p_filter(logits, p=0.9):
    sorted_logits, sorted_indices = torch.sort(logits, descending=True)
    cum_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
    sorted_indices_to_remove = cum_probs > p
    # Shift right to keep first token exceeding p
    sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
    sorted_indices_to_remove[..., 0] = 0
    indices_to_remove = sorted_indices.gather(-1, sorted_indices_to_remove.nonzero(as_tuple=True)[0].view(1, -1))
    logits[..., indices_to_remove] = -float('inf')
    return logits

# OpenAI API
# response = client.chat.completions.create(
#     model="gpt-4o",
#     messages=[...],
#     temperature=0.7,
#     top_p=0.9,
#     frequency_penalty=0.1,
#     presence_penalty=0.1,
#     stop=["\n\n", "User:"]
# )

# vLLM
from vllm import LLM, SamplingParams
llm = LLM(model="meta-llama/Meta-Llama-3-8B-Instruct")
sampling = SamplingParams(
    temperature=0.7,
    top_p=0.9,
    max_tokens=200,
    min_p=0.05,  # vLLM supports
    repetition_penalty=1.1
)
# outputs = llm.generate([prompt], sampling)
```

## Pour aller plus loin

- Holtzman et al., *The Curious Case of Neural Text Degeneration* (ICLR 2020) — nucleus sampling
- Vijayakumar et al., *Diverse Beam Search* (2018)
- Su et al., *A Contrastive Framework for Neural Text Generation* (NeurIPS 2022)
- Meister et al., *Locally Typical Sampling* (2022)
- Li et al., *Contrastive Decoding* (ACL 2023)
- Chuang et al., *DoLa: Decoding by Contrasting Layers Improves Factuality in Large Language Models* (ICLR 2024)
- Wang et al., *Self-Consistency Improves Chain of Thought Reasoning* (ICLR 2023)
- *Hugging Face generation_strategies* documentation
- **Liens internes** : [[Self-attention]], [[Speculative decoding]], [[Prompt engineering]], [[Structured outputs]], [[Perplexity]]
