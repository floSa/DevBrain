---
galaxie: dev
nom: numpy
alias: [numpy, np]
categorie: tooling/data
sous_categories: [array, numerical, foundation, linalg]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python (C core)
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[CuPy]]", "[[JAX]]", "[[PyTorch]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, tooling, data, array, numerical, foundation]
url_officiel: https://numpy.org/
url_docs: https://numpy.org/doc/stable/
url_repo: https://github.com/numpy/numpy
---

# numpy

## Pourquoi
La fondation du calcul numérique en Python. Tableaux N-dim performants, broadcasting, BLAS/LAPACK pour linalg. Brique sous-jacente de [[pandas]], [[scikit-learn]], [[PyTorch]] (au moins en interop), tout l'écosystème scientifique. Pas une option, c'est un prérequis.

## Quand l'utiliser
- Calcul numérique scientifique
- Manipulation d'arrays multi-dim (images, signaux, tenseurs simples)
- Briques bas niveau pour ML / stats
- Interop entre libs (tout le monde parle numpy)

## Quand NE PAS l'utiliser
- Calcul GPU intensif → [[PyTorch]], [[JAX]], [[CuPy]]
- Auto-différentiation → [[JAX]], [[PyTorch]]
- DataFrames structurés → [[pandas]] / [[Polars]]

## Pièges connus
- **`int` Python ≠ `np.int64`** : promotion silencieuse de types
- **Views vs copies** : modification de view modifie l'original
- **Broadcasting** : règles à comprendre, sinon shapes inattendues
- **NumPy 2.0** : nombreux breaking changes en 2024, vérifier compat
- **Random API** : `np.random.default_rng()` (moderne) vs `np.random.seed` (legacy)

## Liens
- [[pandas]], [[Polars]] — utilisent numpy en partie
- [[scikit-learn]] — APIs en arrays numpy
- [[PyTorch]] — interop via `.numpy()` / `.from_numpy()`
- NumPy quickstart : https://numpy.org/doc/stable/user/quickstart.html
