---
galaxie: meta
nom: _orphans
type: meta-doc
created: 2026-05-20
modified: 2026-05-20
tags: [meta, orphans, housekeeping]
---

# `_orphans/` — Capture des notes créées par accident

## À quoi ça sert

Obsidian est configuré (via `.obsidian/app.json`) pour créer **ici** toute
nouvelle note quand tu cliques sur un wikilink fantôme (`[[Apache ORC]]`,
`[[Avro]]`, etc.) au lieu de la créer à la racine du vault.

Sans cette redirection, chaque clic accidentel polluait le vault de fichiers
0-byte à la racine — qui revenaient sans cesse même après suppression.

## Comment l'utiliser

- **Si tu voulais réellement créer la note** → déplace-la vers le bon
  dossier (`Services/<Cat>/`, `Wiki/Concepts/`, `Patterns/`, etc.) ET
  ajoute le bon frontmatter (`galaxie:`, `type:`, etc.).
- **Si c'était un clic accidentel** → supprime simplement, ou laisse-la,
  le script `audit-vault.ps1 -Cleanup` la nettoiera.

## Audit régulier

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/audit-vault.ps1 -Cleanup
```

Demande confirmation par fichier 0-byte. Avec `-Force`, supprime sans
demander.

## Ce dossier dans Git

Le contenu de `_orphans/*.md` est **ignoré par Git** (sauf ce README).
Les notes orphelines créées par Obsidian ne polluent donc plus l'historique.
