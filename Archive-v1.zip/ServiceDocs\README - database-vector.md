# Service — <NOM_DU_SERVICE>

<!--
Template à copier dans <projet>/services/<nom>/README.md.
Référence règle : Rules/Documentation/Database-Vector.md du DevBrain.
À remplacer : <NOM_DU_SERVICE> et tous les <À REMPLIR>.
-->

## Rôle métier

<À REMPLIR : 2-3 lignes — quel besoin RAG / search / similarité cette base sert.>

Exemple :
> Index vectoriel des documents internes pour le moteur RAG. ~5M chunks indexés. Source : pipeline `services/docling/` qui parse les PDFs uploadés.

## Modèle d'embedding (CRITIQUE)

> ⚠️ Changer de modèle invalide TOUTE la base. Ré-embedding complet requis.

| Champ | Valeur |
|-------|--------|
| **Nom** | `<À REMPLIR : ex BAAI/bge-m3>` |
| **Provider** | `<À REMPLIR : HuggingFace local / OpenAI API / Cohere>` |
| **Dimension** | `<À REMPLIR : 384 / 768 / 1024 / 1536 / 3072>` |
| **Version (si applicable)** | `<À REMPLIR>` |
| **Code d'embedding** | `services/<nom>/embedder.py` |

## Stratégie d'indexation

| Param | Valeur | Justification |
|-------|--------|---------------|
| **Type d'index** | `<À REMPLIR : HNSW / IVFFlat / DiskANN>` |  |
| **Métrique** | `<À REMPLIR : Cosine / Dot / L2>` | <pourquoi> |
| **`m` (HNSW)** | `<16>` | Recall vs RAM |
| **`ef_construct`** | `<200>` | Build quality |
| **`ef` (search)** | `<64>` | Latency vs recall |

## Schéma des métadonnées

| Champ | Type | Filtrable | Indexé | Description |
|-------|------|-----------|--------|-------------|
| `doc_id` | string (UUID) | ✅ | ✅ | ID du doc parent |
| `chunk_idx` | int | ❌ | ❌ | Position dans le doc |
| `source_type` | enum | ✅ | ✅ | `pdf` / `web` / `manual` |
| `tenant_id` | string | ✅ | ✅ | Multi-tenant isolation |
| `created_at` | timestamp | ✅ | ❌ | Date d'indexation |
| `content_preview` | text (200ch) | ❌ | ❌ | Pour debug humain |
| `<À REMPLIR>` |  |  |  |  |

## Stratégie de chunking

- **Source** : `services/<doc-processing-service>/` (pipeline en amont)
- **Méthode** : `<À REMPLIR : recursive / semantic / structure-aware (Markdown headings)>`
- **Taille de chunk** : `<À REMPLIR : 512 / 1024 tokens>`
- **Overlap** : `<À REMPLIR : 50 / 100 tokens>`
- **Splitter** : `<À REMPLIR : LangChain RecursiveCharacterTextSplitter / custom>`

## Contrat d'interface

```python
# Méthodes principales (signatures)
def upsert_chunks(chunks: list[Chunk]) -> None: ...
def search(query: str, top_k: int = 10, filters: dict = None) -> list[SearchResult]: ...
def delete_by_doc_id(doc_id: str) -> int: ...
def count() -> int: ...
```

- **Endpoint** : `<À REMPLIR : http://qdrant:6333>`
- **Client** : `<À REMPLIR : qdrant-client / weaviate-client / pymilvus>`
- **Batch limit** : `<À REMPLIR : 1000 vecteurs par upsert>`

## Configuration

| Variable | Type | Défaut | Description |
|----------|------|--------|-------------|
| `QDRANT_URL` | `HttpUrl` | — | Endpoint |
| `QDRANT_API_KEY` | `str | None` | `None` | Auth (cloud) |
| `QDRANT_COLLECTION` | `str` | `documents` | Nom de la collection |
| `<À REMPLIR>` |  |  |  |

## Hybrid search (si activé)

- **Activé ?** : <oui / non>
- **Méthode dense** : embedding ci-dessus
- **Méthode sparse** : `<BM25 / SPLADE>`
- **Fusion** : `<RRF / weighted>`
- **Configuration** : `services/<nom>/hybrid_config.yaml`

## Démarrage local

```bash
docker-compose up -d qdrant
# UI : http://localhost:6333/dashboard

# Initialiser les collections
uv run python services/<nom>/init_collections.py
```

## Volumétrie cible

- **Nombre de vecteurs** : `<À REMPLIR : 40M>`
- **Mémoire estimée** : `<À REMPLIR : 32 GB>` (= dim × 4B × N + overhead HNSW)
- **Disque** : `<À REMPLIR : 100 GB>`

## Backups & restore

- **Snapshots** : `<À REMPLIR : daily, sur MinIO>`
- **Procédure de restore** : `<lien>`
- **Réindexation full** depuis source : `services/<nom>/scripts/reindex_all.py`

## Pièges à anticiper

- **Cosine vs Dot** : cosine suppose vecteurs normalisés
- **Filtres pre-search sur cardinality élevée** : lent
- **Modèle changé sans réindexation** = corruption silencieuse
- **Dimension hardcodée** : à éviter, lire depuis settings

## Liens

- DevBrain : [[<À REMPLIR : Qdrant / Weaviate / Milvus / Chroma / pgvector>]] · [[Comparatif - Bases vectorielles]]
- Règle : [[Database-Vector]]
- Doc fournisseur : <URL>
- Eval RAG : `tests/eval/` (cf. règle [[Tests]])
