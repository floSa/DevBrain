---
galaxie: wiki
nom: Newton & quasi-Newton (BFGS, L-BFGS)
alias: [Newton-Raphson, BFGS, L-BFGS, Gauss-Newton, méthodes 2e ordre]
type: concept
categorie: concept/optimization
sous_categories: [newton, bfgs, lbfgs, second-order, quasi-newton]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Newton, Raphson, Broyden 1969, Fletcher 1970, Goldfarb 1970, Shanno 1970]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, optimization, newton, quasi-newton, second-order]
---

# Newton & quasi-Newton

## TL;DR

Méthodes d'optimisation de **second ordre** : utilisent le **Hessien** (matrice des dérivées secondes) en plus du gradient. **Newton-Raphson** est la méthode théorique : un update par itération, convergence quadratique. **Quasi-Newton (BFGS, L-BFGS)** approxime le Hessien pour éviter son calcul coûteux. Utilisés en ML classique (régression logistique, SVM), pour Gaussian Processes, MLE — **rarement en deep learning** car le Hessien explose en taille.

## Le problème

[[Gradient descent]] ne sait que la **pente locale** (gradient). Quand la loss est mal conditionnée (très "vallée étroite"), il rebondit beaucoup. Les méthodes de 2nd ordre exploitent la **courbure** (Hessien) pour faire des pas plus intelligents — direct vers le minimum d'une approximation quadratique locale.

## L'idée

### Newton-Raphson

Approximation locale de la loss par **développement de Taylor d'ordre 2** :

$$ L(\theta + d) \approx L(\theta) + g^\top d + \frac{1}{2} d^\top H d $$

avec $g = \nabla L(\theta)$ (gradient) et $H = \nabla^2 L(\theta)$ (Hessien). Minimum de cette quadratique :

$$ d = -H^{-1} g $$

Update :

$$ \theta_{t+1} = \theta_t - H_t^{-1} g_t $$

**Convergence quadratique** près du minimum : chaque itération double approximativement le nombre de décimales correctes. C'est largement plus rapide que GD (convergence linéaire au mieux).

#### Limitations

- **Hessien de taille $n \times n$** où $n$ = nb de paramètres. Pour $n = 10^6$ : $10^{12}$ entrées. Impossible à stocker en DL.
- **Inverser $H$** : $O(n^3)$, en plus de stocker
- **$H$ doit être SDP** près du minimum. Loin du minimum (ou en non-convexe), $H$ peut être indéfinie → update part dans le mauvais sens
- **Calcul de $H$** : automatique mais coûteux (autodiff 2nd ordre)

Solutions :
- Régularisation : $H \leftarrow H + \lambda I$ (Levenberg-Marquardt)
- Approximation : **quasi-Newton**
- Stochastic / mini-batch versions

### Quasi-Newton — BFGS

Idée : **approximer $H^{-1}$ itérativement** à partir des gradients passés, sans le calculer.

À chaque pas :
- $s_t = \theta_{t+1} - \theta_t$ (step)
- $y_t = g_{t+1} - g_t$ (changement de gradient)

L'approximation $B_{t+1}$ de $H^{-1}$ se met à jour via la **formule BFGS** :

$$ B_{t+1} = \left(I - \frac{s_t y_t^\top}{y_t^\top s_t}\right) B_t \left(I - \frac{y_t s_t^\top}{y_t^\top s_t}\right) + \frac{s_t s_t^\top}{y_t^\top s_t} $$

Propriétés :
- Garde $B$ SDP (si initialisation SDP et $y^\top s > 0$)
- **Convergence super-linéaire** (entre linéaire et quadratique)
- Pas besoin d'évaluer $H$, juste le gradient

**Coût** : $O(n^2)$ par itération (mémoire et calcul). Encore trop pour DL.

### L-BFGS — Limited memory BFGS

Au lieu de stocker $B$ entière ($O(n^2)$), garder les **$m$ derniers couples $(s_i, y_i)$** ($m$ typique : 5-20). Reconstruction implicite de l'action de $B$ via un two-loop recursion.

**Coût** : $O(mn)$ par itération. **Faisable jusqu'à $n \sim 10^7$**.

Devient l'optimiseur de référence pour beaucoup de problèmes ML "petits à moyens" : régression logistique, MLE de GLM, MaxEnt, Gaussian Processes.

### Gauss-Newton

Cas spécial pour problèmes des moindres carrés non-linéaires $L = \frac{1}{2} \sum r_i(\theta)^2$ :

$$ H \approx J^\top J $$

où $J$ est la Jacobienne des résidus $r$. Toujours SDP, calcul plus facile que le Hessien complet.

Variante : **Levenberg-Marquardt** $H \approx J^\top J + \lambda I$ — robust dans tous les cas (entre GD et Gauss-Newton selon $\lambda$).

### Pourquoi (presque) pas en deep learning ?

- Hessien de NN modernes : matrices $10^{8+} \times 10^{8+}$ infaisables
- Approximations diagonales (AdaGrad/Adam) capturent un peu de l'info 2nd ordre à moindre coût
- Méthodes spécialisées : **K-FAC** (Kronecker-Factored Approximate Curvature), **Shampoo**, **Sophia** — approximations du Hessien adaptées aux NN. Encore peu mainstream.

## Quand c'est utile

- **Régression logistique / MLE** : sklearn `LogisticRegression(solver='lbfgs')` par défaut
- **Gaussian Processes** : hyperparamètres tunes via L-BFGS (likelihood marginal)
- **MaxEnt models** en NLP traditionnel
- **Tuning d'hyperparams continues** (scipy.optimize.minimize)
- **Curve fitting** non-linéaire (scipy.optimize.curve_fit utilise Levenberg-Marquardt)
- **Problèmes ML small/medium** ($n < 10^7$ paramètres) avec gradient facilement calculable

## Quand ça ne marche pas / pièges

- **Deep learning à grande échelle** : Hessien complet impossible, L-BFGS marginal en pratique. Préférer Adam/AdamW.
- **Loss non-convexe** : $H$ peut être indéfinie loin du minimum → update fait monter la loss. Régularisation Levenberg-Marquardt nécessaire.
- **Wolfe conditions / line search** : BFGS/L-BFGS demandent un line search satisfaisant les conditions de Wolfe — implémentation non-triviale, sensible aux hyperparams (c1, c2).
- **L-BFGS stochastique** : marche mal en pratique (le bruit casse l'approximation du Hessien). Préférer L-BFGS sur batch complet ou Adam stochastique.
- **Memoire L-BFGS** : choix de $m$ trop grand n'aide pas (rendements décroissants). $m = 5$-$10$ suffit souvent.
- **Newton en non-convexe** : peut converger vers un point selle ou maximum local. Diagnostic difficile.

## Code minimal

```python
import numpy as np
from scipy.optimize import minimize
from sklearn.linear_model import LogisticRegression

# Régression logistique avec L-BFGS (default sklearn)
clf = LogisticRegression(solver='lbfgs', max_iter=1000).fit(X, y)

# scipy.optimize avec L-BFGS
def loss(theta, X, y):
    # ex. logistic loss
    logits = X @ theta
    return np.mean(np.log1p(np.exp(logits)) - y * logits)

def grad(theta, X, y):
    logits = X @ theta
    return X.T @ (1 / (1 + np.exp(-logits)) - y) / len(y)

theta0 = np.zeros(X.shape[1])
result = minimize(loss, theta0, args=(X, y), jac=grad, method='L-BFGS-B',
                  options={'maxiter': 100, 'disp': True})
theta_opt = result.x

# Newton "vrai" (rarement utilisé) — via Hessien
result_newton = minimize(loss, theta0, args=(X, y), method='Newton-CG',
                          jac=grad, hess=hessian_func)

# PyTorch — L-BFGS pour optim batch sur petit modèle
import torch
import torch.optim as optim

model = torch.nn.Linear(10, 1)
optimizer = optim.LBFGS(model.parameters(), lr=1.0, max_iter=20)

def closure():
    optimizer.zero_grad()
    loss = ((model(X_t) - y_t) ** 2).mean()
    loss.backward()
    return loss

optimizer.step(closure)  # un step L-BFGS = plusieurs sous-itérations
```

## Pour aller plus loin

- Nocedal & Wright, *Numerical Optimization* (2006) — bible du domaine
- Bottou, Curtis, Nocedal, *Optimization Methods for Large-Scale Machine Learning* (2018) — review
- Liu & Nocedal, *On the limited memory BFGS method* (1989) — paper L-BFGS
- Martens, *New insights and perspectives on the natural gradient method* (2014) — pour K-FAC et 2nd ordre en DL
- **Liens internes** : [[Gradient descent]], [[Adam optimizer]], [[Convexity]], [[Loss landscape and saddle points]]
