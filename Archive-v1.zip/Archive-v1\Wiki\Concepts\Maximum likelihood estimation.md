---
galaxie: wiki
nom: Maximum likelihood estimation (MLE)
alias: [MLE, maximum likelihood, maximum de vraisemblance, log-likelihood]
type: concept
categorie: concept/statistics
sous_categories: [mle, likelihood, estimation, frequentist]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Fisher 1922]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, statistics, mle, estimation]
---

# Maximum likelihood estimation — MLE

## TL;DR

Méthode **fréquentiste** d'estimation de paramètres : choisir $\hat\theta$ qui **maximise la probabilité (vraisemblance) d'observer les données**. Quasi-omniprésent : c'est le moteur derrière OLS, logistic regression, GLMs, modèles de mélange (via EM), réseaux de neurones (cross-entropy = neg log-likelihood). Sous régularité, l'estimateur est **consistent, asymptotiquement normal, et efficace**.

## Le problème

Données $D = \{x_1, \dots, x_n\}$ supposées tirées d'une famille paramétrique $p(x; \theta)$. Comment estimer $\theta$ ?

## L'idée

### Vraisemblance

La **vraisemblance** est la densité des données vue comme fonction de $\theta$ :

$$ L(\theta; D) = p(D; \theta) = \prod_{i=1}^n p(x_i; \theta) \quad \text{(si i.i.d.)} $$

L'**estimateur du maximum de vraisemblance** :

$$ \hat\theta_{MLE} = \arg\max_\theta L(\theta; D) = \arg\max_\theta \sum_{i=1}^n \log p(x_i; \theta) $$

On maximise la **log-vraisemblance** (sum > prod, numériquement stable).

### Exemple 1 : moyenne d'une gaussienne

$X_i \sim \mathcal{N}(\mu, \sigma^2)$.

$$ \log L(\mu) = -\frac{n}{2} \log(2 \pi \sigma^2) - \frac{1}{2\sigma^2} \sum (x_i - \mu)^2 $$

$\partial_\mu \log L = 0 \Rightarrow \hat\mu_{MLE} = \bar x_n$. La moyenne empirique est MLE.

### Exemple 2 : Bernoulli

$X_i \sim \text{Bernoulli}(p)$.

$$ \log L(p) = (\sum x_i) \log p + (n - \sum x_i) \log(1 - p) $$

$\hat p_{MLE} = \bar x_n$. La proportion observée.

### Exemple 3 : régression linéaire (OLS)

$y_i = \beta^\top x_i + \varepsilon_i, \varepsilon_i \sim \mathcal{N}(0, \sigma^2)$. La log-vraisemblance se réduit à la **MSE** (au signe + constantes près). **OLS = MLE sous bruit gaussien**.

### Propriétés asymptotiques

Sous régularité (identifiabilité, support fixe, etc.) :

1. **Consistency** : $\hat\theta_{MLE} \xrightarrow{P} \theta^*$ (vraie valeur)
2. **Asymptotic normality** :

$$ \sqrt{n}(\hat\theta_{MLE} - \theta^*) \xrightarrow{d} \mathcal{N}(0, I(\theta^*)^{-1}) $$

où $I(\theta)$ est l'**information de Fisher** :

$$ I(\theta) = -\mathbb{E}\left[\frac{\partial^2 \log p(X; \theta)}{\partial \theta^2}\right] $$

3. **Efficacité** : atteint la **borne de Cramer-Rao** — variance minimale asymptotiquement parmi les estimateurs sans biais.

### Information de Fisher

Mesure la **quantité d'information** que les données portent sur $\theta$. Plus l'information est grande, plus l'estimation est précise.

- Inverse de l'information = **borne théorique** sur la variance d'un estimateur
- $I(\theta)^{-1}/n$ ≈ variance de $\hat\theta_{MLE}$ → utilisé pour les SE et IC

### Lien avec d'autres méthodes

| Méthode | Lien avec MLE |
|---|---|
| **Cross-entropy loss** | = neg log-likelihood pour classification |
| **MSE loss** | = neg log-likelihood sous bruit gaussien |
| **Logistic regression** | MLE sur Bernoulli avec lien logit |
| **GLM** | MLE sur exponential family |
| **EM** | MLE quand variables latentes |
| **Deep learning** | Pratiquement tout est NLL minimization |

### MLE numérique

Souvent pas de forme close → optimisation :
- **Newton-Raphson** : utilise hessien (= info Fisher locale)
- **BFGS / L-BFGS** : quasi-Newton
- **Gradient descent** : pour les cas grosse data
- **EM (Expectation-Maximization)** : pour les modèles avec latentes (GMM, HMM, LDA)

### Régularisation

Penalty terms → **MAP** ([[MAP estimation]]) :
- Ridge / L2 = MAP avec prior gaussien
- Lasso / L1 = MAP avec prior Laplace
- MLE pur = MAP avec prior plat (improper)

## Quand c'est utile

- **Toute estimation paramétrique** : c'est l'approche fréquentiste par défaut
- **GLM (logistic, Poisson regression)** : implémentés via MLE/IRLS
- **Modèles de mélange** : MLE via EM (GMM, k-modes)
- **HMMs** : forward-backward + Baum-Welch = MLE via EM
- **Réseaux de neurones** : neg log-likelihood = loss standard
- **Survival analysis** : Cox proportional hazards = partial MLE
- **Tests d'hypothèses** : likelihood ratio test, Wald test, score test

## Quand ça ne marche pas / pièges

- **Modèle mal-spécifié** : MLE estime le "meilleur $\theta$ sous le modèle faux", pas la vérité. Toujours faire diagnostic.
- **Overfitting** : MLE pur sur petits échantillons peut overfit. Régulariser (MAP) ou cross-valider.
- **Identifiabilité** : si plusieurs $\theta$ donnent la même log-vraisemblance, MLE est non-unique (label-switching en mélanges).
- **Frontière** : MLE peut tomber sur le bord du domaine (e.g. $\hat\sigma^2 = 0$). Cas pathologique.
- **Variance d'estimateur biaisée** : MLE de $\sigma^2$ est $\frac{1}{n}\sum(x_i - \bar x)^2$ — biaisé. Estimateur unbiased = $\frac{1}{n-1}\sum$.
- **EM converge vers local max** : initialiser plusieurs fois ou utiliser k-means++ init.
- **Sample size petit** : propriétés asymptotiques ne s'appliquent pas. Bootstrap pour IC.
- **Heavy tails** : MLE sur gaussienne est non-robuste. Utiliser t-Student ou estimateurs robustes (Huber).

## Code minimal

```python
import numpy as np
from scipy import optimize, stats

# MLE manuel : gaussienne (μ, σ²)
def neg_log_likelihood_gaussian(params, X):
    mu, log_sigma = params
    sigma = np.exp(log_sigma)  # paramétrisation log pour stabilité
    return -np.sum(stats.norm.logpdf(X, mu, sigma))

X = np.random.normal(5, 2, 100)
result = optimize.minimize(neg_log_likelihood_gaussian, x0=[0, 0], args=(X,))
mu_hat, log_sigma_hat = result.x
print(f"μ̂ = {mu_hat:.3f} (vrai: 5), σ̂ = {np.exp(log_sigma_hat):.3f} (vrai: 2)")

# MLE pour régression logistique (from scratch)
def neg_log_likelihood_logistic(beta, X, y):
    logits = X @ beta
    log_lik = y * logits - np.log1p(np.exp(logits))
    return -np.sum(log_lik)

X = np.random.randn(200, 3)
y = (X @ np.array([1, -0.5, 0.3]) + np.random.randn(200) > 0).astype(int)
result = optimize.minimize(neg_log_likelihood_logistic, x0=np.zeros(3), args=(X, y))
print(f"β̂ = {result.x}")

# Comparer à sklearn (qui utilise aussi MLE en interne)
from sklearn.linear_model import LogisticRegression
print(f"sklearn = {LogisticRegression(penalty=None).fit(X, y).coef_[0]}")

# Information de Fisher (matrice hessienne au MLE)
# Pour gaussienne : I(μ) = n/σ²
n = len(X)
fisher_mu = n / np.exp(log_sigma_hat)**2
SE_mu = 1 / np.sqrt(fisher_mu)
print(f"SE(μ̂) = {SE_mu:.3f}")
# IC à 95% : μ̂ ± 1.96 SE
```

## Pour aller plus loin

- Casella & Berger, *Statistical Inference* (2e éd. 2002) — chap. 7 sur MLE
- Wasserman, *All of Statistics* — chap. 9
- Murphy, *Probabilistic ML: An Introduction* (2022) — chap. 5
- **Liens internes** : [[MAP estimation]] (régularisé), [[Bayesian inference]] (alternative), [[Cross-validation]], [[Regularization]], [[Hypothesis testing]] (LRT)
