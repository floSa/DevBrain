---
galaxie: wiki
nom: Positional encoding
alias: [RoPE, ALiBi, sinusoidal, learned PE, YaRN, position encoding]
type: concept
categorie: concept/transformers
sous_categories: [positional-encoding, rope, transformer]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Vaswani 2017, Su 2021 (RoPE), Press 2021 (ALiBi), Peng 2023 (YaRN)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, transformer, positional-encoding, llm]
---

# Positional encoding

## TL;DR

[[Self-attention]] est **invariante par permutation** — sans info de position, "le chat mange la souris" = "la souris mange le chat". On injecte la position dans le modèle. Évolutions : **sinusoidal absolute** (Transformer original) → **learned absolute** (BERT, GPT-2) → **relative** (T5, Shaw) → **RoPE** (Rotary, LLaMA standard) → **ALiBi** (Press). Pour **extension de contexte** au-delà du train : **YaRN, NTK-aware, LongRoPE**. Pas trivial — un mauvais positional encoding casse l'extrapolation à long contexte.

## Le problème

Le Transformer ne sait rien des positions. Or beaucoup d'info linguistique dépend de l'**ordre** (syntaxe, sémantique). Comment encoder la position de manière efficace et **généralisable** à des séquences plus longues que celles vues en training ?

## L'idée

### Sinusoidal (Vaswani 2017)

Ajouter à chaque embedding $x_i$ un vecteur :

$$ PE(pos, 2i) = \sin(pos / 10000^{2i/d}) $$
$$ PE(pos, 2i+1) = \cos(pos / 10000^{2i/d}) $$

- **Non-apprise**, fonction sinusoïdale à différentes fréquences
- Propriété : $PE(pos + k)$ = combinaison linéaire de $PE(pos)$ → peut généraliser
- En pratique : pas la meilleure extrapolation
- Standard Transformer original

### Learned absolute (BERT, GPT-2)

Apprendre un vecteur $PE_i \in \mathbb{R}^d$ par position $i$, jusqu'à $max\_len$.

- Plus expressif
- **Ne s'extrapole pas** au-delà de $max\_len$ vu en training
- Limites pour long context

### Relative positional encoding (Shaw 2018, T5)

Encoder la **distance relative** entre tokens, pas position absolue :

$$ \text{Attention scores} = \frac{Q K^\top}{\sqrt{d_k}} + B $$

avec $B_{ij}$ = fonction de $j - i$.

- T5 utilise un **bias scalaire** par bucket de distance
- Plus flexible que absolute
- Mieux pour généralisation

### RoPE (Rotary Positional Embedding, Su 2021)

**Standard actuel** : Llama, Mistral, Qwen, Gemma, DeepSeek, GPT-NeoX.

Idée : **faire tourner** les vecteurs $Q$ et $K$ par un angle qui dépend de la position :

$$ R_\theta = \begin{pmatrix} \cos\theta & -\sin\theta \\ \sin\theta & \cos\theta \end{pmatrix} $$

Pour la position $m$, on applique $R_{m\theta}$ à $Q$ et $R_{n\theta}$ à $K$. Alors :

$$ (R_{m\theta} q)^\top (R_{n\theta} k) = q^\top R_{(n-m)\theta} k $$

→ dépendance uniquement à la **différence** de position $n - m$ (relative).

**Avantages** :
- Encoder par **rotation** dans des sous-espaces 2D
- Pas de paramètres appris (comme sinusoidal)
- Bonne extrapolation
- Maths élégantes (analytic, smooth)

**Hyperparamètre** : **base frequency** $\theta_b = 10000$ (défaut). Modifier permet d'étendre le contexte.

### ALiBi (Press 2021)

Pas de positional encoding du tout — **biais linéaire** sur scores d'attention :

$$ \text{score}_{ij} = q_i^\top k_j - m \cdot |i - j| $$

avec $m$ slope head-specific. Pénalise l'attention sur tokens lointains.

- Simple, pas d'embedding additionnel
- **Excellente extrapolation** (peut générer 16K avec train à 1K)
- Utilisé dans BLOOM, MPT

### NoPE (Kazemnejad 2023)

**Sans positional encoding** — surprise, ça marche en decoder-only ! Le causal mask suffit à briser la symétrie. Bonne extrapolation théorique.

### Extension de contexte (long context)

Modèles entraînés sur 4K et déployés sur 32K, 128K → problème : RoPE n'extrapole pas naturellement très loin.

#### PI (Position Interpolation, Chen 2023)

Diviser les positions par un facteur $s$ → "compresse" les nouvelles positions dans la range vue en train.

- Simple
- Dégrade la résolution courte distance

#### NTK-aware scaling

Au lieu de scale linéairement, modifier la **base frequency** $\theta_b$ pour étendre seulement les fréquences hautes (longues distances).

#### YaRN (Peng 2023)

Combinaison NTK + interpolation par bandes de fréquence. **Standard** moderne pour étendre.

- Llama 3 / Qwen utilisent YaRN ou variantes
- Fine-tune court (sur ~1B tokens long context) pour adapter

#### LongRoPE / LongRoPE 2

Recherche d'hyperparamètres optimaux par evolutionary search. Microsoft, 2M context.

### Comparaison

| Method | Type | Extrap | Apprise | Standard |
|---|---|:-:|:-:|---|
| Sinusoidal | absolute | moyenne | ✗ | original Transformer |
| Learned absolute | absolute | ✗ | ✓ | BERT, GPT-2 |
| Shaw relative | relative | bonne | ✓ | T5 |
| RoPE | relative (rotation) | OK + extension | ✗ | Llama, Mistral, **moderne** |
| ALiBi | relative (bias) | **excellente** | ✗ | BLOOM, MPT |
| NoPE | implicit | bonne | ✗ | research |

### Best practices

1. **Decoder-only LLM moderne** : RoPE par défaut
2. **Très long context** : RoPE + YaRN ou ALiBi
3. **Encoder-decoder** : RoPE ou T5-style relative
4. **Extension de contexte** : YaRN avec fine-tune court
5. **Custom data très long** : envisager NoPE

## Quand c'est utile

- **Tout Transformer** : sans PE, modèle = bag-of-words
- **Extension de contexte** : YaRN pour passer de 8K à 128K
- **Tâches structure-sensitive** : code, math, parsing — RoPE supérieur
- **Long document QA** : ALiBi extrapole gratos
- **Multimodal** : adapter PE pour images, audio (RoPE 2D pour ViT)

## Quand ça ne marche pas / pièges

- **Oublier le PE** : modèle ne comprend rien à l'ordre, marche bizarrement
- **Learned PE et long context** : ne s'extrapole pas, modèle pète au-delà de max_len
- **RoPE base frequency non-tunée** : Llama2 trained 4K → utilisé en 32K sans YaRN = perte de qualité
- **PI seul** : dégrade les distances courtes
- **Mixing PE** : utiliser RoPE sur un modèle entraîné avec learned PE = incompatible
- **Position-sensitive tasks fail** : si un modèle 8K échoue à 16K même avec extension, c'est que tout a été entraîné sur courte distance — le fine-tune long context est nécessaire
- **Attention sink** + extension PE : premiers tokens sur-pondérés en long context, à monitorer
- **Multi-modal PE** : naïvement coller PE 1D à des images 2D = sous-optimal. Utiliser RoPE-2D ou learned 2D.

## Code minimal

```python
import torch
import math

# Sinusoidal
def sinusoidal_pe(max_len, d_model):
    pe = torch.zeros(max_len, d_model)
    position = torch.arange(0, max_len).unsqueeze(1).float()
    div_term = torch.exp(torch.arange(0, d_model, 2).float() * -(math.log(10000.0) / d_model))
    pe[:, 0::2] = torch.sin(position * div_term)
    pe[:, 1::2] = torch.cos(position * div_term)
    return pe

# RoPE
def precompute_rope_freqs(d_k, max_len, theta=10000.0):
    freqs = 1.0 / (theta ** (torch.arange(0, d_k, 2).float() / d_k))
    t = torch.arange(max_len).float()
    freqs = torch.outer(t, freqs)  # (max_len, d_k/2)
    freqs_cis = torch.polar(torch.ones_like(freqs), freqs)  # complex
    return freqs_cis

def apply_rope(x, freqs_cis):
    # x shape: (B, n_heads, T, d_k)
    B, h, T, d_k = x.shape
    x_complex = torch.view_as_complex(x.float().reshape(B, h, T, d_k // 2, 2))
    freqs_cis = freqs_cis[:T].view(1, 1, T, d_k // 2)
    x_rotated = x_complex * freqs_cis
    return torch.view_as_real(x_rotated).reshape(B, h, T, d_k).type_as(x)

# Usage in attention
freqs_cis = precompute_rope_freqs(d_k=64, max_len=2048)
# Apply to Q and K before attention
# Q_rot = apply_rope(Q, freqs_cis)
# K_rot = apply_rope(K, freqs_cis)

# ALiBi bias
def alibi_bias(n_heads, max_len):
    # Slopes : geometric sequence 2^(-8/h) for each head
    slopes = torch.tensor([2 ** (-8.0 * (i + 1) / n_heads) for i in range(n_heads)])
    distances = -torch.abs(torch.arange(max_len)[None, :] - torch.arange(max_len)[:, None]).float()
    bias = distances.unsqueeze(0) * slopes.unsqueeze(-1).unsqueeze(-1)  # (h, T, T)
    return bias

# YaRN-style scaling (sketch)
def yarn_rope(d_k, max_len, scale=4.0, original_max_len=2048, theta=10000):
    # Combine PI for low-freq + extrapolation for high-freq
    # See Peng 2023 paper for full formula
    pass

# Hugging Face : RoPE est dans transformers.models.llama.modeling_llama
# from transformers import LlamaConfig
# config = LlamaConfig(rope_theta=10000.0, rope_scaling={"type": "yarn", "factor": 4.0})
```

## Pour aller plus loin

- Su et al., *RoFormer: Enhanced Transformer with Rotary Position Embedding* (2021) — RoPE paper
- Press et al., *Train Short, Test Long: Attention with Linear Biases Enables Input Length Extrapolation* (ICLR 2022) — ALiBi
- Peng et al., *YaRN: Efficient Context Window Extension of Large Language Models* (2023)
- Chen et al., *Extending Context Window of Large Language Models via Positional Interpolation* (2023) — PI
- Kazemnejad et al., *The Impact of Positional Encoding on Length Generalization in Transformers* (NeurIPS 2023) — NoPE
- **Liens internes** : [[Self-attention]], [[Transformer architectures]], [[Flash Attention and efficient attention]]
