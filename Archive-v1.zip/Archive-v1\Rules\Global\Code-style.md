---
galaxie: dev
type: rule
domaine: code-style
applicable: global
strictness: should
created: 2026-05-01
modified: 2026-05-01
tags: [rule, code-style, lint, format]
---

# Règle — Style de code

## Principe
Outillage automatique > discipline humaine. Linter + formatter activés en CI, pre-commit hooks pour ne pas avoir à y penser.

## MUST

- **Linter activé en CI**. Build casse si lint fail.
- **Formatter automatique** lancé pre-commit. Pas de débat de style en review.
- **Pas de magic numbers** : constantes nommées, ou paramètres de config.

## SHOULD

- **Fonctions courtes** : < 50 lignes (sauf si justifié — parsers, machines à états).
- **Nommage explicite** : `user_count` pas `n`, `is_admin` pas `flag`.
- **Pas de mutation cachée** : préférer immutable (frozen dataclasses, readonly types) quand pertinent.
- **Imports triés** par le formatter (isort, ruff, biome).
- **Type hints** complets sur les signatures publiques (Python, TypeScript).

## NICE-TO-HAVE

- Complexité cyclomatique limitée (radon, ESLint complexity rule).
- Profondeur d'imbrication < 4.
- Pas plus de 4-5 paramètres par fonction (au-delà : passer un dict / dataclass).

## Outils par stack

### Python
- **Ruff** (linter + formatter, remplace black + isort + flake8 + pyupgrade)
- **mypy** ou **pyright** pour types
- Config dans `pyproject.toml` :
  ```toml
  [tool.ruff]
  line-length = 100
  [tool.ruff.lint]
  select = ["E", "F", "I", "N", "UP", "B", "SIM"]
  ```

### TypeScript / Node
- **Biome** (préféré, plus rapide) ou **ESLint + Prettier**
- **TypeScript strict mode** (`"strict": true` dans tsconfig)

### Rust
- `cargo fmt`, `cargo clippy` (warning → error en CI)

### Go
- `gofmt`, `golangci-lint`

## Pre-commit setup (Python)

`.pre-commit-config.yaml` :

```yaml
repos:
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.x.x  # pinner
    hooks:
      - id: ruff
        args: [--fix]
      - id: ruff-format
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.x.x
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
      - id: check-yaml
      - id: check-added-large-files
```

## Voir aussi

- [[Rules/Global/Tests]] — tests aussi formatés/lintés
- [[Ruff]] (service)
- Biome (service)
