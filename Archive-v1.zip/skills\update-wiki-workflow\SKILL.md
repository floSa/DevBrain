---
name: update-wiki-workflow
description: |
  Use this skill to patch an existing workflow fiche in Wiki/Workflows/.
  Triggers: "modifie le workflow", "patch le workflow <nom>", "mets à jour
  ma procédure <nom>", "j'ai amélioré l'étape X de <workflow>", or when the
  user wants to integrate a new step, a piège discovered, or a variante.
  Preserves the rest of the procédure, updates 'modified:' date.
---

# Skill — update-wiki-workflow

## Quand l'utiliser

L'utilisateur veut **améliorer une procédure existante** dans `Wiki/Workflows/`. Exemples :
- "Ajoute l'étape 4.5 'configurer pgvector index' dans [[Bootstrap projet AI eng]]"
- "Le piège des timeouts manque dans [[Debug pipeline data]]"
- "Update [[Evaluer un systeme LLM]] avec la nouvelle métrique X"

Différent de `add-wiki-workflow` (création) ou `expand-stub` (stub → complet).

## Pré-requis vault

Mode wiki. Périmètre `Wiki/Workflows/`.

## Procédure

1. **Localiser** la fiche. Si nom ambigu, lister les workflows existants.
2. **Lire** la structure : sections fixes (Quand l'utiliser, Pré-requis, Procédure, Checklist, Pièges, Variantes, Voir aussi).
3. **Identifier où le changement va** :
   - Nouvelle étape → renuméroter les suivantes
   - Nouveau piège → append à "Pièges courants"
   - Nouvelle variante → append à "Variantes"
   - Correction d'une commande → patch ciblé
4. **Demander la matière** à l'utilisateur (texte, commande shell, URL).
5. **Renuméroter automatiquement** les étapes si insertion au milieu.
6. **Mettre à jour la Checklist de fin** si la nouvelle étape introduit un item à vérifier.
7. **Mettre à jour** `modified:` dans le frontmatter.
8. **Wikilinker** les services/concepts nouvellement cités.
9. **Montrer le diff** avant écriture.

## Anti-patterns à éviter

- **Renuméroter incohérent** — vérifie que la Checklist correspond aux étapes
- **Commandes shell sans précision OS** — Windows PowerShell vs Bash, ne pas mélanger
- **Oublier de mentionner le pré-requis** si la nouvelle étape en introduit un
- **Rewrite intégral**

## Voir aussi

- `add-wiki-workflow` (création)
- `expand-stub` (stub → complet)
- `log-bug` (si la modification vient d'un bug rencontré)
