---
galaxie: wiki
nom: Regularization
alias: [régularisation, L1, L2, Ridge, Lasso, ElasticNet]
type: concept
categorie: concept/ml
sous_categories: [ridge, lasso, elastic-net, dropout, early-stopping, overfitting]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Tikhonov 1943, Tibshirani 1996 (Lasso), Hastie-Tibshirani]
lecture_min: 9
created: 2026-05-19
modified: 2026-05-19
tags: [concept, ml, regularization, ridge, lasso]
---

# Regularization

## TL;DR

Pénaliser la **complexité du modèle** dans la fonction de coût pour éviter l'overfitting. Deux familles principales en linéaire : **L2** (Ridge) qui rétrécit les coefficients vers 0 sans les annuler, et **L1** (Lasso) qui les annule complètement → sélection de features. **ElasticNet** combine les deux. En deep learning : **dropout**, **weight decay**, **early stopping**. Outil n°1 contre la variance excessive (cf. [[Bias-variance tradeoff]]).

## Le problème

Un modèle non régularisé tend à :
- **Overfit** sur de petits datasets ou avec beaucoup de features
- **Donner des coefficients énormes** (instables, mal interprétables)
- **Échouer sur de nouveaux échantillons** par sensibilité aux variations

Augmenter la régularisation = sacrifier un peu de fit sur le train pour gagner de la **généralisation**.

## L'idée

### Cadre général

Au lieu de minimiser uniquement la loss :

$$ \min_\theta \mathcal{L}(\theta; \mathcal{D}) $$

on minimise loss + pénalité de complexité :

$$ \min_\theta \mathcal{L}(\theta; \mathcal{D}) + \lambda \cdot R(\theta) $$

Le coefficient $\lambda \geq 0$ contrôle l'intensité de la régularisation :
- $\lambda = 0$ : pas de régul → modèle libre, risque d'overfit
- $\lambda \to \infty$ : modèle ultra-contraint → underfit
- $\lambda$ "bien choisi" (par [[Cross-validation]]) → sweet spot

### Ridge (régression L2)

Pénalité $R(\theta) = \|\theta\|_2^2 = \sum_j \theta_j^2$.

Loss régression linéaire :

$$ \min_\theta \sum_i (y_i - x_i^\top \theta)^2 + \lambda \sum_j \theta_j^2 $$

**Effet** : tous les $\theta_j$ sont rétrécits vers 0, mais **aucun n'est exactement 0**. Solution unique même quand $p > n$ (plus de features que d'observations).

Solution analytique : $\hat\theta = (X^\top X + \lambda I)^{-1} X^\top y$.

### Lasso (régression L1)

Pénalité $R(\theta) = \|\theta\|_1 = \sum_j |\theta_j|$.

**Effet** : certains $\theta_j$ deviennent **exactement 0** → **sélection automatique de features**. Solution non-analytique (algos type coordinate descent), pas toujours unique.

Quand utiliser :
- **Beaucoup de features**, beaucoup attendues comme inutiles
- Recherche d'un modèle parcimonieux et interprétable
- Co-variables redondantes : Lasso choisit l'une, met les autres à 0 (peut être arbitraire)

### ElasticNet — L1 + L2

$$ R(\theta) = \alpha \|\theta\|_1 + (1-\alpha) \|\theta\|_2^2 $$

Combine la sélection (L1) et le rétrécissement stable (L2). Hyperparam $\alpha \in [0, 1]$ règle le mix.

**Préféré quand** : features fortement corrélées (Lasso pur peut être instable, ElasticNet "groupe" les corrélées).

### Au-delà du linéaire

#### Trees-based

- [[XGBoost]] / [[LightGBM]] / [[CatBoost]] : régularisation via `max_depth`, `min_child_weight`, `gamma`, `reg_alpha` (L1), `reg_lambda` (L2)
- Random Forest : régulation implicite par bagging (variance réduite par moyennage)

#### Neural networks

- **L2 weight decay** : équivalent Ridge sur les poids
- **Dropout** : aléatoirement, certaines unités sont "éteintes" pendant l'entraînement → empêche la coadaptation
- **Early stopping** : arrêter l'entraînement quand la val loss commence à monter → régularisation implicite
- **Batch normalization** : effet régularisant indirect
- **Data augmentation** : enrichit les données → effet régularisant fort sans toucher au modèle

### Choix de $\lambda$

Via [[Cross-validation]] : grid search ou random search sur une grille log-spacée ($\lambda \in \{10^{-4}, 10^{-3}, \dots, 10^4\}$), choisir celui qui minimise l'erreur de validation.

**Indicateur "1-SE rule"** (Hastie) : choisir le $\lambda$ **le plus régularisé** dont le score CV reste à moins d'1 SE du meilleur. Modèle plus simple, légèrement moins bon en CV, souvent meilleur en généralisation réelle.

## Quand c'est utile

- $p > n$ ou $p \approx n$ (plus de features que d'observations)
- Multicollinéarité (features fortement corrélées)
- Modèle qui overfit le train
- Sélection automatique de features (Lasso/ElasticNet)
- Tout modèle avec beaucoup de paramètres (deep nets en particulier)

## Quand ça ne marche pas / pièges

- **Standardisation obligatoire** avant Ridge/Lasso : sinon, les features à grande variance reçoivent une régul proportionnellement faible → biais. Toujours `StandardScaler` dans le pipeline.
- **Lasso et features corrélées** : sélection arbitraire (laquelle des 2 colinéaires garder ?). Préfère ElasticNet ou un domain-expert pour décider.
- **$\lambda$ trop fort** : tous les coefs vers 0, modèle inutile
- **Régul pas adaptée au problème** : Ridge sur classification avec très peu d'observations en minoritaire → masque le signal
- **Confusion régularisation / sélection de features** : Lasso fait les deux. Ridge ne fait QUE de la régul (aucun feature n'est éliminé)

## Code minimal

```python
from sklearn.linear_model import Ridge, Lasso, ElasticNet, LassoCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

# Ridge avec λ fixé
ridge = Pipeline([
    ('scaler', StandardScaler()),
    ('model', Ridge(alpha=1.0)),  # alpha = λ chez sklearn
]).fit(X, y)

# Lasso avec sélection auto de α par CV
lasso_cv = Pipeline([
    ('scaler', StandardScaler()),
    ('model', LassoCV(cv=5, n_alphas=100, random_state=0)),
]).fit(X, y)

print(f"Lasso α choisi : {lasso_cv['model'].alpha_:.4f}")
print(f"# features non nulles : {(lasso_cv['model'].coef_ != 0).sum()}")
```

## Implémentations concrètes

- `sklearn.linear_model` : `Ridge`, `Lasso`, `ElasticNet`, `LogisticRegression(penalty='l2'|'l1'|'elasticnet')`, `RidgeCV`, `LassoCV`, `ElasticNetCV`
- [[XGBoost]] / [[LightGBM]] / [[CatBoost]] : params `reg_alpha`, `reg_lambda`
- PyTorch : `optim.AdamW` (weight decay), `nn.Dropout`, callbacks early stopping
- `glmnet` (R) — implémentation de référence ElasticNet, encore plus rapide

## Pour aller plus loin

- Tibshirani, *Regression shrinkage and selection via the lasso* (1996) — paper canonique Lasso
- Hastie, Tibshirani, Friedman, *ESL* — chap. 3.4 et 4
- **Liens internes** : [[Bias-variance tradeoff]] (cadre théorique), [[Cross-validation]] (choix de $\lambda$), [[XGBoost]] / [[LightGBM]] (régul dans gradient boosting)
