---
galaxie: dev
nom: Milvus
alias: [milvus]
categorie: database/vector
sous_categories: [distributed, cloud-native, large-scale]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Go
clients_officiels: [python, ts, go, java, rust]
plateforme: [linux]
score: 
mes_projets: []
alternatives: ["[[Qdrant]]", "[[Weaviate]]", "[[pgvector]]", "[[Chroma]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, database, vector, distributed, cloud-native]
url_officiel: https://milvus.io/
url_docs: https://milvus.io/docs
url_repo: https://github.com/milvus-io/milvus
---

# Milvus

## Pourquoi
Vector DB **distribuée cloud-native** (LF AI Foundation). Architecture séparée storage/compute, scaling horizontal, supports énormes volumes (milliards de vecteurs). Variant léger **Milvus Lite** (embedded) pour dev. Le choix pour de très grosses workloads.

## Quand l'utiliser
- Très grande scale (centaines de millions à milliards de vecteurs)
- Besoin de séparer compute et storage (K8s natif)
- Workload multi-collections avec quotas par collection
- Quand l'équipe a une compétence ops K8s
- Milvus Lite pour dev / embedded sans full deployment

## Quand NE PAS l'utiliser
- Petit/moyen volume → [[Qdrant]] / [[Weaviate]] / [[pgvector]] sont plus simples
- Pas d'équipe ops K8s → ne pas s'aventurer dans Milvus distribué
- Single-node simple → Milvus Lite OK mais Chroma est plus user-friendly

## Pièges connus
- **Architecture lourde** : 5+ composants en mode distribué (Coordinator, Proxy, etc.)
- **Standalone vs Cluster** : choisir selon usage, switch non trivial
- **Index types** : nombreux (FLAT, IVF_FLAT, IVF_PQ, HNSW, DISKANN) — tester selon recall/latency
- **Memory mapping** : DiskANN économise la RAM mais latency plus haute
- **Backup/restore** : Milvus Backup tool à déployer en plus
- **Zilliz Cloud** : managed officiel, pricing à comprendre

## Liens
- [[Qdrant]], [[Weaviate]] — alternatives self-hosted
- Zilliz Cloud (managed Milvus) : https://zilliz.com/
- Milvus Lite : https://milvus.io/docs/milvus_lite.md
- Index selection guide : https://milvus.io/docs/index.md
