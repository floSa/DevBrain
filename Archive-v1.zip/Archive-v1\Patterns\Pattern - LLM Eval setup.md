---
galaxie: dev
type: pattern
contexte: système LLM (RAG, agent, classifieur) à évaluer en continu pour détecter régressions et drift en prod
created: 2026-05-19
modified: 2026-05-19
services_cles: ["[[Ragas]]", "[[DeepEval]]", "[[TruLens]]", "[[Phoenix Arize]]", "[[Anthropic Claude API]]"]
projets_appliques: []
tags: [pattern, llm-eval, ai-eng, observability]
---

# Pattern — LLM Eval setup

## Contexte

Tu as un système LLM (RAG, agent, classifieur, extracteur) et tu veux savoir s'il **fonctionne**, **s'améliore** entre versions, et **ne dérive pas** en prod. Sans eval rigoureuse, tu navigues à vue.

Cas typiques : RAG sur doc interne, agent support, extracteur d'entités, classifieur de tickets. Le système est en prod ou sur le point de l'être.

Pour la méthodologie d'éval pas à pas, voir [[Evaluer un systeme LLM]]. Ce pattern décrit la **stack technique** à mettre en place.

## Stack

- **Dataset gold** : 50-200 cas représentatifs versionnés en Git (CSV/JSON)
- **Framework d'éval** : [[Ragas]] (RAG-spécifique), [[DeepEval]] (assertion-style), [[TruLens]] (feedback functions)
- **LLM-as-judge** : [[Anthropic Claude API]] (Opus pour évaluer Sonnet, modèle plus fort que celui évalué)
- **Observabilité** : [[Phoenix Arize]] pour traces + auto-eval ; OpenTelemetry pour le pipeline
- **CI** : GitHub Actions qui lance l'eval sur chaque PR
- **Tracking** : MLflow ou simple CSV versionné pour l'historique des scores
- **Drift detection** (prod) : Evidently AI ou implé custom

## Structure de projet

```
my-llm-app/
├── eval/
│   ├── dataset/
│   │   ├── gold_v1.json          # cas représentatifs, versionné
│   │   ├── adversarial.json      # cas piégeux (injections, edge cases)
│   │   └── README.md             # comment annoter de nouveaux cas
│   ├── metrics/
│   │   ├── ragas_metrics.py      # faithfulness, answer relevance, context precision
│   │   ├── custom_metrics.py     # métriques métier (ex : citation correcte)
│   │   └── llm_judge.py          # prompts du juge LLM
│   ├── run_eval.py               # lance l'éval, écrit le rapport
│   ├── compare_versions.py       # diff entre 2 runs d'éval
│   └── history.csv               # log historique
├── src/
│   └── my_llm_app/
│       ├── core.py               # le système à évaluer
│       └── observability.py      # instrumentation Phoenix
├── .github/workflows/
│   └── eval.yml                  # CI : eval sur chaque PR
└── tests/
    └── test_eval_runs.py         # smoke test que l'éval tourne
```

## Décisions clés

### 1. Dataset gold avant tout

**Avant d'optimiser quoi que ce soit**, constituer 50-200 cas :
- Couvre les cas typiques + edge cases + hors-scope (doit dire "je ne sais pas")
- **Versionne en Git** (CSV/JSON) — pas dans une DB qui peut bouger
- Documenter la **convention d'annotation** dans `eval/dataset/README.md`
- Inclure des **cas adversariaux** (prompt injection, ambiguïtés, questions piégeuses)

Format minimal :

```json
{
  "id": "gold-001",
  "question": "Comment configurer le timeout PG ?",
  "expected_answer_contains": ["statement_timeout", "ms"],
  "expected_sources": ["docs/db/postgres.md"],
  "category": "config",
  "difficulty": "easy",
  "notes": ""
}
```

### 2. Choix des métriques par type de système

| Système | Métriques principales |
|---|---|
| **RAG** | Faithfulness, Answer Relevance, Context Precision, Context Recall ([[Ragas]]) |
| **Agent** | Task completion rate, # steps moyen, tool call accuracy, hallucination rate |
| **Classifieur** | Accuracy, F1 par classe, confusion matrix, calibration |
| **Extracteur** | Field-level precision/recall, schema compliance rate, exact match |
| **Chatbot** | Helpfulness (LLM-judge), refus rate, latence p95, # turns |

### 3. LLM-as-judge avec garde-fous

Pour les évaluations qualitatives (helpfulness, fluency, conversational quality) :
- Modèle juge **plus fort** que celui évalué (Opus pour évaluer Sonnet, GPT-4o pour évaluer GPT-4-mini)
- Prompt structuré avec **rubric explicite** (échelle 1-5, critères, exemples)
- Sortie structurée via [[Instructor]] (force le format)
- **Calibration humaine** : annoter 30-50 cas par humain, mesurer corrélation juge/humain (Spearman ρ > 0.7 idéal)

```python
JUDGE_PROMPT = """
Tu évalues une réponse d'assistant LLM.

Question : {question}
Réponse : {answer}
Réponse attendue : {expected}

Note de 1 à 5 sur :
- accuracy : la réponse est-elle correcte ?
- helpfulness : aide-t-elle vraiment l'utilisateur ?
- conciseness : longueur adaptée ?

Sortie JSON strict.
"""
```

### 4. Tracking historique

Versionner les résultats d'éval permet de détecter les régressions :

```csv
date,commit,model,faithfulness,answer_relev,context_prec,latency_p95,notes
2026-05-19,abc1234,sonnet-4.7,0.72,0.81,0.65,1.2,baseline
2026-05-20,def5678,sonnet-4.7,0.78,0.82,0.74,1.3,+reranker cohere
2026-05-21,ghi9012,sonnet-4.7+,0.85,0.88,0.78,1.5,upgrade modele
```

### 5. Eval en CI

```yaml
# .github/workflows/eval.yml
on: pull_request
jobs:
  eval:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: uv sync
      - run: uv run python eval/run_eval.py --baseline main
      - run: uv run python eval/compare_versions.py
      - name: Comment PR
        if: github.event_name == 'pull_request'
        # poste le diff de scores en commentaire de PR
```

Garde-fous CI :
- **Block merge** si métrique critique baisse de > 5%
- **Coût de l'éval** : maintenir sous 100k tokens / run (50 cas × 1.5k tokens × 1-2 modèles)
- **Reproductibilité** : `temperature=0` sur tous les modèles évalués

### 6. Drift detection en prod

Une fois en prod, les vraies données diffèrent du dataset gold :
- Logger échantillon (~5%) des requêtes prod (anonymisé)
- Re-évaluer périodiquement (hebdo, mensuel)
- Comparer distribution des features (latence, longueur réponse, taux de "je ne sais pas")
- Alerte si drift > seuil → enquête manuelle

### 7. Observabilité instrumentée

Tous les appels LLM passent par [[Phoenix Arize]] :
- Traces complètes (input, output, latence, tokens, coût)
- Annotations humaines possibles via UI
- Génération automatique de cas d'éval depuis la prod (curation)

## Pièges (vu en projets)

- **Dataset trop petit** (< 30 cas) → métriques très bruitées, pas de signal
- **Dataset homogène** → tu ne mesures qu'un seul mode de défaillance. Diversifier.
- **Pas de cas hors-scope** → rate les hallucinations (modèle qui invente sur ce qu'il ne sait pas)
- **LLM-judge non calibré** → tu mesures le biais du juge plutôt que la performance
- **Métriques absolues sans baseline** : "faithfulness = 0.72" ne dit rien. Compare au baseline et au modèle naïf.
- **Eval one-shot** : tester une fois et ne plus jamais → tu rates le drift. Eval continue obligatoire.
- **Optimiser sur la métrique de validation** sans test out-of-sample final → overfitting au CV
- **Sous-estimer le coût** : 50 cas × 5 métriques × 2 modèles juges × 100 tokens = 50k tokens / run. ~5€/run avec Claude Sonnet. Multiplier par fréquence CI.
- **Pas de versioning du dataset** : changer le dataset entre 2 runs → tu compares pommes et oranges

## Voir aussi

- Concepts : [[RAG]], [[tool-use|Tool Use]], [[agent-loops|Agent loops]], [[Hypothesis testing]] (parallèles éval ML classique)
- Workflows : [[Evaluer un systeme LLM]] (procédure détaillée), [[Evaluer un modele forecast]] (logique parallèle pour TS)
- Services : [[Ragas]], [[DeepEval]], [[TruLens]], [[Phoenix Arize]], [[Anthropic Claude API]], [[Instructor]]
- Patterns liés : [[Pattern - RAG basique]], [[Pattern - Agent ReAct]]
- Rules applicables : [[Rules/Types/ML-pipeline]]
