---
galaxie: wiki
nom: Structured outputs
alias: [JSON mode, function calling, Outlines, Instructor, constrained decoding, BAML]
type: concept
categorie: concept/llm-inference
sous_categories: [structured-outputs, json-mode, function-calling, llm]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Willard 2023 (Outlines)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, structured-outputs, json]
---

# Structured outputs

## TL;DR

Forcer un LLM à produire du **JSON / XML / type-safe output** parseable. Plusieurs niveaux : **prompt instruction** (basic, parfois échoue), **JSON mode** (OpenAI, Anthropic — better), **JSON Schema constrained** (OpenAI Structured Outputs, Anthropic Tool Use, vLLM `guided_json`), **grammar-based** (Outlines, XGrammar, GBNF — universal), **type-safe wrappers** (Instructor, BAML, TypeChat). Sous le capot : **constrained decoding** = mask tokens invalides au moment du sampling. Essentiel pour : extraction, API responses, tool calls, multi-step pipelines. Sans structured outputs, on parse du free text avec regex → fragile.

## Le problème

LLM = générateur de texte libre. En production on veut souvent :
- **JSON parseable** (API responses, data extraction)
- **Schema strict** (sans champs en plus, types corrects)
- **Tool calls** (function name + args)
- **Multi-step pipelines** où chaque step donne input au suivant

Free text → fragile. Comment **garantir** la structure ?

## L'idée

### Niveaux d'approche

#### 1. Prompt instruction (basic)

```
Return your answer as JSON with these keys:
{"name": str, "age": int, "city": str}
```

- Marche pour modèles forts (GPT-4, Claude)
- **Parfois échoue** : trailing commas, markdown wrappers, extra text
- Pas de garantie

#### 2. JSON mode (provider)

- **OpenAI** : `response_format={"type": "json_object"}` — garantit JSON parseable
- **Anthropic** : prefill assistant avec `{` pour amorcer
- **Gemini** : `response_mime_type="application/json"`

- Garantit JSON valide
- **Mais pas le schema** : champs / types peuvent varier

#### 3. JSON Schema constrained (Structured Outputs)

- **OpenAI Structured Outputs** (`response_format={"type": "json_schema", "schema": ...}`) : depuis Aug 2024, garantit conformance schema 100%
- **Anthropic Tool Use** : `input_schema` valide chaque tool call
- **vLLM** : `guided_json=schema`
- **TGI** : `grammar={"type": "json", "value": schema}`

- **Garantit schema** : champs exacts, types corrects, enum values, etc.
- Implementation via **constrained decoding** (voir plus bas)

#### 4. Grammar-based (universal)

- **Outlines** : regex, JSON schema, CFG (context-free grammar)
- **XGrammar** (CMU, vLLM) : compilation FSM/PDA pour CFG efficient
- **GBNF** (llama.cpp) : grammar syntax simple

Plus flexible que JSON schema : peut contraindre n'importe quel format (e.g. SQL valide, Python syntactically correct, etc.).

#### 5. Type-safe wrappers

##### Instructor (Liu 2023)

```python
from pydantic import BaseModel
import instructor
from openai import OpenAI

class User(BaseModel):
    name: str
    age: int

client = instructor.from_openai(OpenAI())
user = client.chat.completions.create(
    model="gpt-4o",
    response_model=User,  # Pydantic class
    messages=[{"role": "user", "content": "John, 30 years old"}]
)
# user is a User instance, validated
```

- **Pydantic-based**, super propre
- Retry automatique sur invalid
- Streaming partial Pydantic

##### BAML

DSL pour structured prompts + outputs. Compile vers Python/TS clients.

##### TypeChat (Microsoft)

Type-driven prompting. TypeScript focus.

##### Marvin

Pythonic, dataclass-based.

### Constrained decoding (how it works)

**Idée** : à chaque step, **masker** les tokens qui violeraient le schema.

Exemple JSON {"name": str} :
- Position 0 : seul `{` autorisé → tous autres tokens masqués
- Position 1-7 : seul `"name":` (un token à la fois)
- Position 8 : seul `"` (open string)
- Position 9+ : tout sauf `"` autorisé
- ...

**Implementation** :
- **Token masking** : zéroer logits des tokens invalides avant softmax
- **Finite State Machine (FSM)** : pour regex / JSON
- **Pushdown automata** : pour CFG (Python, SQL...)

Coût : ~5-15% overhead vs unconstrained, mais garantie totale.

### Function calling (tool use)

Cas spécial de structured outputs : le LLM choisit **quelle function appeler** + **avec quels args** :

```python
tools = [{
    "name": "get_weather",
    "description": "Get weather for a city",
    "input_schema": {
        "type": "object",
        "properties": {
            "city": {"type": "string"},
            "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]}
        },
        "required": ["city"]
    }
}]
```

LLM output :
```json
{
  "name": "get_weather",
  "input": {"city": "Paris", "unit": "celsius"}
}
```

Voir [[tool-use]] et [[agent-loops]].

### Variants pour cas spécifiques

#### Forced choice / multiple choice

Forcer la réponse à être dans une liste finie :

```python
class Answer(BaseModel):
    choice: Literal["A", "B", "C", "D"]
```

#### Conditional schemas

Schema dépend de la valeur d'un champ (e.g. discriminated unions).

#### Streaming structured outputs

Stream du JSON partial. Instructor supporte. Difficile mais utile pour UX.

### Comparaison

| Méthode | Provider lock-in | Garantit JSON | Garantit Schema | Flexible |
|---|:-:|:-:|:-:|:-:|
| Prompt instruction | ✗ | ✗ | ✗ | ✓ |
| JSON mode OpenAI | ✓ OpenAI | ✓ | ✗ | ✓ |
| Structured Outputs OpenAI | ✓ OpenAI | ✓ | ✓ | ~ |
| Anthropic Tool Use | ✓ Anthropic | ✓ | ✓ | ~ |
| vLLM guided_json | ✗ (vLLM) | ✓ | ✓ | ✓ |
| Outlines | ✗ | ✓ | ✓ | ✓✓ |
| Instructor | ✗ (multi-provider) | ✓ | ✓ | ✓ |
| GBNF | ✗ (llama.cpp) | ✓ | ✓ | ✓ |

### Best practices

1. **Use providers' structured outputs** : OpenAI Structured Outputs, Anthropic Tool Use → meilleure qualité
2. **Pydantic + Instructor** pour code propre Python
3. **Schemas simples** : LLM gère mieux que 50 champs imbriqués
4. **Required vs optional** : marquer correctement
5. **Enums quand applicable** : limite l'espace
6. **Descriptions des champs** : LLM utilise comme guidance
7. **Examples** : few-shot dans le prompt aide
8. **Validation post-hoc** : même avec constrained, valider business logic (Pydantic validators)
9. **Streaming** : décider si on en a vraiment besoin (complexité)
10. **Retry on invalid** : retry strategy (n=2-3) pour modèles weaker

## Quand c'est utile

- **Data extraction** : convertir text → records
- **API responses** : LLM-powered API
- **Multi-step pipelines** : output structuré = input du step suivant
- **Tool use / function calling** : params type-safe
- **Classification** : sortie dans Literal["A", "B", ...]
- **Reasoning structuré** : "answer + confidence + reasoning"
- **Data labeling** : extract annotations en batch
- **RAG** : citations format, source IDs
- **Workflows** : chaque étape produit input typé pour la suivante

## Quand ça ne marche pas / pièges

- **Free-form creative** : pas besoin de structured, restreint la qualité
- **Schemas trop complexes** : modèle se perd, output dégrade
- **Constrained decoding overhead** : +5-15% latency, parfois rédhibitoire
- **Quality drop** : structured outputs **peuvent** dégrader qualité textuelle (le modèle "force" un token suboptimal pour respecter syntax)
- **Schema field names confusants** : "x" / "y" → modèle ne comprend pas
- **Required vs optional mal géré** : modèle hallucine optional fields
- **Streaming partial parsing** : difficile, JSON partial pas toujours parseable
- **Provider differences** : OpenAI strict schema, Anthropic via tool_use, vLLM via guided — code non portable
- **Token limit during constrained** : grosses structures peuvent overflow
- **Mauvais retry strategy** : retry sans changement → même erreur
- **Pydantic validators custom** : Instructor retry, mais consomme tokens vite

## Code minimal

```python
# 1. OpenAI Structured Outputs
from pydantic import BaseModel
from openai import OpenAI
client = OpenAI()

class User(BaseModel):
    name: str
    age: int
    email: str

response = client.beta.chat.completions.parse(
    model="gpt-4o-2024-08-06",
    messages=[
        {"role": "system", "content": "Extract user info."},
        {"role": "user", "content": "John Smith, 30, john@example.com"}
    ],
    response_format=User,
)
user = response.choices[0].message.parsed
print(user.name, user.age)

# 2. Anthropic Tool Use (= structured outputs)
import anthropic
client = anthropic.Anthropic()

tool = {
    "name": "extract_user",
    "description": "Extract user information",
    "input_schema": {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
            "email": {"type": "string", "format": "email"}
        },
        "required": ["name", "age", "email"]
    }
}

response = client.messages.create(
    model="claude-3-7-sonnet-latest",
    max_tokens=200,
    tools=[tool],
    tool_choice={"type": "tool", "name": "extract_user"},  # Forcer le tool
    messages=[{"role": "user", "content": "John Smith, 30, john@example.com"}]
)
user_data = response.content[0].input
print(user_data)

# 3. Instructor (multi-provider, sleek)
import instructor
from openai import OpenAI

class UserModel(BaseModel):
    name: str
    age: int
    email: str

client = instructor.from_openai(OpenAI())
user = client.chat.completions.create(
    model="gpt-4o",
    response_model=UserModel,
    max_retries=3,  # auto-retry sur invalid
    messages=[{"role": "user", "content": "John, 30, john@example.com"}]
)
print(user)

# Instructor with Anthropic
import instructor
from anthropic import Anthropic
client = instructor.from_anthropic(Anthropic())
user = client.messages.create(
    model="claude-3-7-sonnet-latest",
    response_model=UserModel,
    max_tokens=200,
    messages=[{"role": "user", "content": "..."}]
)

# 4. Outlines (constrained decoding)
import outlines
model = outlines.models.transformers("microsoft/Phi-3-mini-4k-instruct")

# Regex constraint
generator = outlines.generate.regex(model, r"[A-Z][a-z]+, [0-9]+ years")
result = generator("Tell me about a person: ")
# Garantit format "Name, NN years"

# JSON schema constraint
schema = '{"type": "object", "properties": {"name": {"type": "string"}, "age": {"type": "integer"}}}'
generator = outlines.generate.json(model, schema)
result = generator("Extract: John is 30")

# 5. vLLM guided JSON
from vllm import LLM, SamplingParams
llm = LLM(model="meta-llama/Meta-Llama-3-8B-Instruct")

sampling = SamplingParams(
    temperature=0,
    max_tokens=200,
    guided_decoding={"json": UserModel.model_json_schema()}
)
outputs = llm.generate(["Extract user from: John, 30"], sampling)

# 6. GBNF (llama.cpp)
# grammar = """
# root ::= "{" "\"name\":" string "," "\"age\":" number "}"
# string ::= "\"" [a-zA-Z]+ "\""
# number ::= [0-9]+
# """
# ./main -m model.gguf --grammar "$(cat grammar.gbnf)"

# 7. Custom validation + retry
from pydantic import field_validator

class StrictUser(BaseModel):
    name: str
    age: int
    
    @field_validator("age")
    @classmethod
    def age_positive(cls, v):
        if v < 0 or v > 150:
            raise ValueError("Invalid age")
        return v

# Instructor retries automatically on ValidationError

# 8. Streaming structured (Instructor partial)
from instructor import Partial

stream = client.chat.completions.create_partial(
    model="gpt-4o",
    response_model=Partial[UserModel],
    messages=[...],
    stream=True,
)
for partial_user in stream:
    print(partial_user)  # Voir le model se construire
```

## Pour aller plus loin

- Willard, Louf, *Efficient Guided Generation for Large Language Models* (Outlines, 2023)
- Beurer-Kellner et al., *Prompting Is Programming: A Query Language for Large Language Models* (LMQL, 2023)
- *OpenAI Structured Outputs* docs (Aug 2024)
- *Anthropic Tool Use* docs
- *Instructor* docs (Jason Liu)
- *Outlines* library docs
- *BAML* docs
- *XGrammar* (CMU 2024) — research paper
- **Liens internes** : [[Prompt engineering]], [[tool-use]], [[agent-loops]], [[Decoding strategies]]
