---
galaxie: wiki
nom: mcp-github
type: mcp-server
plateforme: universel
categorie: skill/dev-flow
sous_categories: [github, git, pr, issues]
auteur: GitHub (officiel)
source: github/github-mcp-server
source_url: https://github.com/github/github-mcp-server
install_cmd: "claude mcp add github --command npx --args -y @modelcontextprotocol/server-github --env GITHUB_PERSONAL_ACCESS_TOKEN=<token>"
install_doc: https://github.com/github/github-mcp-server
licence: MIT
licence_type: open-source
domaines: [data-eng, mlops, ml-eng, ai-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [mcp, github, dev-flow]
---

# mcp-github

## Pourquoi

MCP server officiel **GitHub** qui expose les opérations courantes : lister/lire/créer issues et PRs, voir le CI, lire les fichiers d'un repo distant, gérer les releases. Permet à l'agent de **travailler sur GitHub sans `gh` CLI** et sans changer de contexte.

Complète bien `gh` CLI (qui reste l'outil de référence) : MCP pour les requêtes en cours de conversation, `gh` pour les actions intentionnelles que tu lances toi-même.

## Quand l'utiliser

- "Liste les PRs ouvertes du repo X" pendant qu'on bosse sur autre chose
- Cross-référencer du code dans plusieurs repos sans cloner localement
- Workflow d'auto-triage : "résume les issues de la semaine, propose des labels"

## Quand NE PAS l'utiliser

- Pour push / commit → reste sur `git` + `gh` (action explicite côté humain)
- Si tu n'as pas de token GitHub utilisable → préfère `gh auth` qui gère le device flow

## Comment l'installer

1. Génère un *Personal Access Token (fine-grained)* sur https://github.com/settings/tokens?type=beta
   - Permissions minimum : `repo` (read), `issues` (read+write), `pull_requests` (read+write)
2. Stocke le token quelque part (gestionnaire de secrets, pas en clair dans le repo)
3. Ajoute le MCP :

```bash
claude mcp add github \
  --command npx \
  --args -y @modelcontextprotocol/server-github \
  --env GITHUB_PERSONAL_ACCESS_TOKEN=<colle_ton_token>

claude mcp list
```

Voir [[_installer-un-skill]] section *MCP server*.

## Exemples d'usage

```
> liste les PRs en review sur github.com/floSa/DevBrain
> ouvre une issue "améliorer le guide d'install" avec un template
> sur le repo X, trouve le commit qui introduit la fonction parse_yaml
```

## Pièges connus

- Le token donne accès large : crée un token *fine-grained* limité aux repos qui en ont besoin
- Rate limit GitHub (5000 req/h sur PAT) — peut limiter sur des analyses lourdes

## Liens

- Repo officiel : https://github.com/github/github-mcp-server
- Doc MCP : https://modelcontextprotocol.io/
