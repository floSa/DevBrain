---
galaxie: dev
nom: Cohere API
alias: [cohere, command, rerank]
categorie: llm/api
sous_categories: [api, llm, embedding, rerank]
licence: Proprietaire
licence_type: proprietary
hosted: managed
maturite: production
langage: 
clients_officiels: [python, ts, go, java]
plateforme: [cloud]
score: 4
mes_projets: []
alternatives: ["[[Anthropic Claude API]]", "[[OpenAI API]]", "[[Mistral API]]", "[[Google Gemini API]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, api, cohere]
url_officiel: https://cohere.com/
url_docs: https://docs.cohere.com/
url_repo: 
---

# Cohere API

## Pourquoi
LLM API canadien. Modèles **Command** (génération), **Embed v4** (embeddings, multilingue fort), **Rerank v3** (réordonnancement). Pas le plus puissant en génération vs Claude/GPT, mais **leader sur les embeddings multilingues** et le reranking pour RAG.

## Quand l'utiliser
- **Embed v4** : embeddings multilingues très performants (100+ langues)
- **Rerank v3** : standard pour [[Reranking]] dans pipelines RAG (préférable au cross-encoder local pour quality)
- Génération en langues non-EN (français, allemand bien supportés)
- Compliance Canada / Europe (régions disponibles)
- Modèles fine-tunables (Command R fine-tuning dispo)

## Quand NE PAS l'utiliser
- Reasoning hard / SOTA general → [[Anthropic Claude API]] ou OpenAI
- Coding → Claude / GPT
- Pas besoin de multilingue → OpenAI embed-3 / Voyage moins cher
- Vision/multimodal → Claude / GPT-4o / Gemini

## Pièges connus
- **Rerank v3 vs v3.5** : check version, perf différentes
- **Embed v4** vs v3 : breaking changes API, vérifier dimensions
- **Pricing** : Rerank facturé `searches` (par 1000), embed par tokens, Command par tokens — modèles séparés
- **Latence Rerank** : ~200-500ms, à compter dans budget RAG
- **Token limit** : 4096 tokens par doc en Rerank, à chunker

## Liens
- [[Reranking]] (concept) — Cohere Rerank est standard
- [[embeddings]] (concept)
- [[Anthropic Claude API]] / [[OpenAI API]] — alternatives
- [[RAG]] / [[Advanced RAG]]
- Docs : https://docs.cohere.com/
- Pricing : https://cohere.com/pricing
