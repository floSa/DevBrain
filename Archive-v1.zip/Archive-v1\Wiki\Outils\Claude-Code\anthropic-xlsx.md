---
galaxie: wiki
nom: anthropic-skills:xlsx
type: claude-code-skill
plateforme: claude-code
categorie: skill/documents
sous_categories: [xlsx, spreadsheet, data, csv]
auteur: Anthropic
source: anthropics/skills
source_url: https://github.com/anthropics/skills
install_cmd: claude plugin install anthropic-skills
install_doc: https://docs.claude.com/en/docs/build-with-claude/skills
licence: MIT
licence_type: open-source
domaines: [data-science, data-eng, mlops]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, documents, data]
---

# anthropic-skills:xlsx

## Pourquoi

Skill officiel pour **lire, modifier, créer des fichiers Excel/CSV/TSV** sans dépendances obscures. Quand l'agent voit un `.xlsx` mentionné, ce skill prend le relais et applique les bonnes pratiques openpyxl/pandas (préservation des formules, formats, formatage conditionnel).

## Quand l'utiliser

- nettoyer un fichier client crade (lignes vides, en-têtes baladeurs)
- générer des rapports tabulaires propres à partir de queries SQL/parquet
- fusionner/splitter/cross-référencer plusieurs spreadsheets
- transformer CSV ↔ XLSX en gardant la mise en forme

## Quand NE PAS l'utiliser

- pour un pipeline de production : préfère un script `pandas` versionné dans le projet (le skill, c'est pour l'ad-hoc et l'investigation)
- pour des données > 1M lignes : passe en parquet/duckdb, le skill n'est pas conçu pour ça

## Comment l'installer

```bash
claude plugin install anthropic-skills
```

Le skill se déclenche automatiquement quand un `.xlsx`, `.xlsm`, `.csv` ou `.tsv` est mentionné dans une session.

Voir [[_installer-un-skill]] pour la procédure détaillée.

## Exemples d'usage

```
> ouvre ~/data/clients.xlsx et liste-moi les colonnes
> dans clients.xlsx, ajoute une colonne "score" = revenue/CA_total
> exporte le résultat en CSV propre dans ~/out/
```

## Pièges connus

- Si le `.xlsx` contient des macros (`.xlsm`), le skill les préserve mais ne les exécute pas — normal côté sécurité.
- Les feuilles avec cellules fusionnées sont lues mais peuvent produire des `NaN` inattendus en sortie pandas.

## Liens

- Source : https://github.com/anthropics/skills
- Doc skills Claude : https://docs.claude.com/en/docs/build-with-claude/skills
