---
galaxie: dev
nom: DuckDB
alias: [duckdb]
categorie: database/warehouse
sous_categories: [olap, embedded, analytical, in-process]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: C++
clients_officiels: [python, r, java, js, ts, rust, go, c, swift]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: [SQLite, ClickHouse, "[[Postgres]]", BigQuery]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, database, olap, analytical]
url_officiel: https://duckdb.org/
url_docs: https://duckdb.org/docs/
url_repo: https://github.com/duckdb/duckdb
---

# DuckDB

## Pourquoi

**Le SQLite des analytics** : base OLAP embarquée, in-process, zéro setup. Tu fais `import duckdb` et tu lances des requêtes SQL ANSI sur des **Parquet/CSV/JSON/Arrow/Polars dataframes** directement, sans loader dans une vraie DB.

Performance excellente (vectorized execution, columnar), interop natif avec pandas/Polars/Arrow. C'est devenu en 2024-2026 le couteau suisse de tout data scientist/engineer pour l'exploration locale ou le batch de taille moyenne.

## Quand l'utiliser

- Exploration ad-hoc sur des fichiers Parquet/CSV de quelques GB (jusqu'à ~100GB sur un laptop décent)
- ETL local avant chargement dans une vraie DW
- Notebook / scripts data sans avoir à monter une infra
- Tests d'intégration data : DuckDB comme remplacement légère de Postgres/[[Snowflake]] en CI

## Quand NE PAS l'utiliser

- OLTP (transactionnel, beaucoup de writes concurrents) → [[Postgres]]
- Multi-utilisateur / accès simultané important → vraie DW ([[BigQuery]], Snowflake, ClickHouse)
- Volumétrie TB+ avec besoin de scaling horizontal → vraie infra

## Pièges connus

- L'engine est single-process : pas de scaling horizontal natif
- Les `INSERT` ligne par ligne sont lents — utilise toujours `COPY FROM` ou `INSERT INTO ... SELECT FROM`
- La persistance se fait sur fichier `.duckdb` — pas adapté à du serveur multi-clients (single-writer)

## Liens

- Doc : https://duckdb.org/docs/
- Repo : https://github.com/duckdb/duckdb
- [[Polars]] (interop natif, souvent combinés)
- [[Parquet]] (format préféré en input)
