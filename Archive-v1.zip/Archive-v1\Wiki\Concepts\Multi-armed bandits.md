---
galaxie: wiki
nom: Multi-armed bandits
alias: [MAB, bandits, Thompson sampling, UCB, epsilon-greedy, contextual bandits]
type: concept
categorie: concept/statistics
sous_categories: [bandits, exploration-exploitation, online-learning, rl]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Robbins 1952, Thompson 1933, Auer 2002 (UCB)]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, statistics, bandits, online-learning]
---

# Multi-armed bandits — MAB

## TL;DR

Cadre **online** d'apprentissage où on doit choisir **séquentiellement** entre $K$ actions (les "bras"), chacune retournant une récompense aléatoire de distribution inconnue. Objectif : **maximiser la récompense cumulée** = trade-off entre **exploration** (apprendre quel bras est le meilleur) et **exploitation** (jouer le meilleur bras connu). Standard pour optimisation de A/B testing adaptatif, recommendation, ad serving, dynamic pricing. Algorithmes clés : **ε-greedy**, **UCB**, **Thompson sampling**.

## Le problème

A/B testing classique : on alloue 50/50 à chaque variant jusqu'à la fin du test, **même si on sait déjà que B perd**. Coût en regret. Bandits : adapter dynamiquement l'allocation pour favoriser les meilleurs bras tout en gardant assez d'exploration.

## L'idée

### Cadre formel

À chaque step $t$ :
1. Le joueur choisit un bras $a_t \in \{1, \dots, K\}$
2. Reçoit récompense $r_t \sim D_{a_t}$ (inconnue, e.g. Bernoulli($p_a$))

**Objectif** : maximiser $\sum_{t=1}^T r_t$, ou de manière équivalente, minimiser le **regret** :

$$ R_T = T \mu^* - \mathbb{E}\left[\sum_{t=1}^T r_t\right] $$

où $\mu^* = \max_a \mu_a$ est la récompense moyenne du meilleur bras.

**Borne théorique optimale** : $R_T = O(\sqrt{KT \log T})$ pour les meilleurs algorithmes.

### Algorithmes principaux

#### ε-greedy

Avec probabilité $\varepsilon$, choisir un bras uniformément (explorer) ; sinon, choisir le bras avec la plus haute moyenne empirique (exploiter).

- Simple, baseline universelle
- $\varepsilon$ fixe = regret linéaire (sous-optimal)
- $\varepsilon_t = 1/t$ ou $\sqrt{\log t / t}$ = regret logarithmique

#### UCB (Upper Confidence Bound)

Choisir le bras maximisant :

$$ a_t = \arg\max_a \left[\hat\mu_a + \sqrt{\frac{2 \log t}{N_a(t)}}\right] $$

où $\hat\mu_a$ est la moyenne empirique et $N_a(t)$ le nombre de pulls de $a$ jusqu'à $t$. **Optimisme face à l'incertitude** : on joue le bras avec la meilleure "borne supérieure" plausible.

- Regret $O(\log T)$ — optimal
- Déterministe (pas de tirage aléatoire)
- Bonne baseline production

#### Thompson sampling

Bayésien :
1. Garder un posterior $p(\mu_a | D)$ pour chaque bras
2. À chaque step, **sampler** $\tilde\mu_a \sim p(\mu_a | D)$ pour chaque bras
3. Jouer $a_t = \arg\max_a \tilde\mu_a$

Pour bras Bernoulli avec prior $\text{Beta}(\alpha, \beta)$ :
- Sample $\tilde\mu_a \sim \text{Beta}(\alpha_a + s_a, \beta_a + n_a - s_a)$
- Bras le plus échantillonné = bras le plus "probable d'être le meilleur"

- **Performance empirique** souvent meilleure qu'UCB
- Naturellement bayésien, calibré
- Standard chez Yahoo, Netflix, Microsoft

#### Gittins index

Optimal théorique pour problèmes à horizon infini discounted. Trop coûteux en pratique pour la plupart des cas.

### Variantes

#### Contextual bandits

À chaque step, on observe **contexte** $x_t$ (e.g. features user). On veut une politique $\pi(a | x)$. Algos :
- **LinUCB** : modélise $\mathbb{E}[r | a, x] = \theta_a^\top x$, UCB sur le modèle linéaire
- **Neural bandits** : réseau de neurones pour modéliser la récompense
- Lien fort avec **policy optimization** en RL

#### Non-stationary bandits

Les moyennes $\mu_a$ varient avec le temps (e.g. user preferences). Solutions :
- **Sliding window UCB** : ne prend en compte que les W derniers samples
- **Discounted UCB** : weight exponentiellement les samples
- **Adaptive ε**

#### Adversarial bandits

Aucune hypothèse sur les rewards (peuvent être adversariales). Algorithme : **EXP3** (exponential weighting). Regret $O(\sqrt{T K \log K})$.

#### Combinatorial bandits

Choisir un **sous-ensemble** de bras à chaque step (e.g. ranking, top-K).

### Lien avec A/B testing

Bandits = **A/B test adaptatif** :
- A/B testing fixe l'allocation, mesure à la fin → "explore-then-exploit"
- Bandit alloue dynamiquement, accumule regret minimal

**Mais** : bandits "perdent" la garantie p-value standard. Si l'objectif est **inférence rigoureuse**, A/B reste mieux. Si l'objectif est **maximiser le revenue cumulé**, bandit gagne.

Compromis :
- **Multi-armed Thompson** : Bayes, intervalles de crédibilité disponibles
- **Sequential testing** : alternative entre A/B et bandit

### Exploration-exploitation trade-off

Concept central :
- **Explorer** : essayer des bras peu visités pour réduire l'incertitude
- **Exploiter** : jouer le meilleur connu pour maximiser la récompense immédiate

Trop d'exploration → regret de jouer des mauvais bras
Trop d'exploitation → coincé sur un sous-optimal si l'estimation initiale est trompeuse

Algos optimaux équilibrent dynamiquement.

### Évaluation offline

Difficile : on n'a pas les contrefactuels. Méthodes :
- **Replay / off-policy evaluation** : Inverse Propensity Scoring (IPS), Doubly Robust
- **Counterfactual simulation** : si on a un modèle du monde
- **OPE benchmarks** : OpenAI gym, batch RL

## Quand c'est utile

- **News recommendation** : Yahoo News (LinUCB)
- **Ad targeting** : choisir quelle pub montrer
- **Dynamic pricing** : tester prix avec adaptation
- **Email subject line optimization** : optimiser open rate
- **A/B testing adaptatif** : maximiser revenue pendant le test
- **Clinical trials adaptatifs** : Bayesian adaptive designs
- **Optimisation de hyperparamètres** : Bayesian optimization (lié)
- **RL light** : quand pas de state ou actions séquentielles

## Quand ça ne marche pas / pièges

- **Besoin d'inférence statistique rigoureuse** : bandits ne donnent pas de p-value valide standard. Préférer A/B test classique.
- **Récompenses delayed** : bandits supposent reward immédiate. Pour reward différée (clics → conversions), utiliser bandit retardé ou RL.
- **Non-stationarity ignorée** : algos stationary perdent vite. Utiliser variantes adaptatives.
- **Cold start** : tous les bras commencent inconnus, l'exploration initiale coûte
- **Small reward differences** : pour bras très proches, identification difficile en peu de samples
- **Trop de bras** ($K$ grand) : exploration explose, regret $\sqrt{K}$
- **Feedback partiel mal modélisé** : si on observe que la décision/non-décision mais pas le contrefactuel, biais
- **Cross-arm interference** : effets de spillover (e.g. marketplace bras = produits, jouer un produit affecte les autres)
- **Sur-fit en évaluation offline** : OPE notoirement difficile

## Code minimal

```python
import numpy as np

# Setup : 3 bras Bernoulli
true_probs = [0.3, 0.5, 0.4]
n_steps = 5000

# 1. Epsilon-greedy
def epsilon_greedy(true_probs, n_steps, epsilon=0.1):
    K = len(true_probs)
    counts = np.zeros(K)
    rewards = np.zeros(K)
    history = []
    for t in range(n_steps):
        if np.random.random() < epsilon or counts.sum() < K:
            a = np.random.randint(K)
        else:
            a = np.argmax(rewards / np.maximum(counts, 1))
        r = np.random.binomial(1, true_probs[a])
        counts[a] += 1
        rewards[a] += r
        history.append(r)
    return np.array(history), counts

# 2. UCB
def ucb(true_probs, n_steps):
    K = len(true_probs)
    counts = np.zeros(K)
    rewards = np.zeros(K)
    history = []
    for t in range(n_steps):
        if counts.min() == 0:
            a = np.argmin(counts)
        else:
            ucb_values = rewards / counts + np.sqrt(2 * np.log(t + 1) / counts)
            a = np.argmax(ucb_values)
        r = np.random.binomial(1, true_probs[a])
        counts[a] += 1
        rewards[a] += r
        history.append(r)
    return np.array(history), counts

# 3. Thompson sampling
def thompson_sampling(true_probs, n_steps):
    K = len(true_probs)
    alpha = np.ones(K)  # prior Beta(1, 1) = uniform
    beta = np.ones(K)
    history = []
    for t in range(n_steps):
        samples = np.random.beta(alpha, beta)
        a = np.argmax(samples)
        r = np.random.binomial(1, true_probs[a])
        if r == 1:
            alpha[a] += 1
        else:
            beta[a] += 1
        history.append(r)
    return np.array(history), alpha - 1  # counts of successes

# Comparaison
for name, algo in [("ε-greedy", epsilon_greedy), ("UCB", ucb), ("Thompson", thompson_sampling)]:
    rewards, counts = algo(true_probs, n_steps)
    optimal_reward = max(true_probs) * n_steps
    regret = optimal_reward - rewards.sum()
    print(f"{name:12} : reward = {rewards.sum():.0f}, regret = {regret:.0f}, "
          f"meilleur bras choisi {int(counts[np.argmax(true_probs)])}/{n_steps} fois")

# Regret cumulatif visualisé
import matplotlib.pyplot as plt
for name, algo in [("ε-greedy", epsilon_greedy), ("UCB", ucb), ("Thompson", thompson_sampling)]:
    rewards, _ = algo(true_probs, n_steps)
    cum_regret = np.cumsum(max(true_probs) - rewards)
    plt.plot(cum_regret, label=name)
plt.legend(); plt.xlabel("step"); plt.ylabel("cum regret")
```

## Pour aller plus loin

- Lattimore & Szepesvári, *Bandit Algorithms* (Cambridge 2020) — bible, gratuit en ligne
- Russo et al., *A Tutorial on Thompson Sampling* (2018) — FT Booking et al.
- Sutton & Barto, *Reinforcement Learning* — chap. 2 sur MAB
- Li et al., *A Contextual-Bandit Approach to Personalized News* (LinUCB, WWW 2010)
- **Liens internes** : [[A-B testing]], [[Bayesian inference]], [[Reinforcement learning]], [[Exploration vs exploitation]], [[Markov Decision Process]], [[Value functions]]
