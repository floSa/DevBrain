---
galaxie: wiki
nom: No Free Lunch theorem
alias: [NFL, théorème No Free Lunch, Wolpert-Macready]
type: concept
categorie: concept/learning-theory
sous_categories: [no-free-lunch, model-selection, generalization, philosophy]
domaines: [ml-eng]
maturite: established
auteurs_cles: [Wolpert 1996, Wolpert-Macready 1997]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, learning-theory, nfl]
---

# No Free Lunch theorem

## TL;DR

Résultat fondamental (Wolpert 1996) : **moyenné sur tous les problèmes possibles**, tous les algorithmes d'apprentissage ont la même performance. Conséquence : il n'existe **pas** d'algorithme universellement meilleur. Le succès d'un algo dépend de l'**adéquation entre ses biais inductifs et la distribution réelle** du problème. Justifie pourquoi le tuning et la sélection de modèle sont indispensables.

## Le problème

Question naïve : "Quel est le meilleur algo de ML ?" Réponse via NFL : **la question n'a pas de sens**. Tous les algos sont équivalents en moyenne sur tous les problèmes — leurs performances dépendent du problème particulier.

C'est un résultat **anti-intuitif** mais qui guide profondément la pratique ML.

## L'idée

### Énoncé informel

Sur l'ensemble de **toutes les fonctions cibles possibles** $f : \mathcal{X} \to \mathcal{Y}$ (tirées uniformément), l'**erreur attendue** d'un algorithme d'apprentissage $A$ ne dépend **pas** de $A$ :

$$ \mathbb{E}_{f, S} [R(A; S, f)] = \text{constante en } A $$

Tous les algos sont équivalents en moyenne universelle.

### Énoncé optimisation (Wolpert-Macready 1997)

Pareil pour l'optimisation : sur toutes les fonctions objectif possibles, tous les algorithmes de recherche ont la même performance en moyenne.

### Conséquences

1. **Pas d'algo universel** : XGBoost / Random Forest / Neural Net / SVM / KNN — chacun a ses "amis" et ses "ennemis" parmi les problèmes.

2. **Biais inductifs matter** : un algo réussit quand ses biais (linéarité, smoothness, sparsity, structure spatiale...) **matchent** la vraie structure du problème.

3. **Apprentissage = restriction** : on apprend en **excluant** des fonctions cibles (hypothèses simplificatrices, régularisation). Sans biais, pas d'apprentissage.

4. **Comparaisons de benchmarks** : un algo "meilleur" sur ImageNet et MS-MARCO et MNIST n'est pas meilleur "en général" — il est meilleur sur **ces** distributions.

### Hypothèses du théorème

NFL repose sur des hypothèses fortes :
- **Distribution uniforme** sur l'espace des fonctions cibles — irréaliste en pratique
- **Pas de structure exploitable** dans les problèmes
- **Aucune connaissance préalable** sur la cible

**Le monde réel est très non-uniforme** : les problèmes qu'on rencontre ont des structures (continuité, sparsity, locality, smoothness). Algos qui exploitent ces structures dominent en pratique → NFL est **vacuous en pratique**, mais profondément **vrai philosophiquement**.

### Interprétation pratique

NFL ne dit **pas** :
- ❌ Tous les algos sont équivalents sur tes données
- ❌ Tuning ne sert à rien
- ❌ Random search vaut Bayesian Opt

NFL dit :
- ✅ Pas d'algo magique qui marche partout
- ✅ Le succès vient de l'adéquation biais ↔ problème
- ✅ Comprendre ton problème > choisir aveuglément un algo

### Exemples concrets

- **CNN** sur images : excellent, biais inductifs (locality, translation invariance) matchent la structure visuelle
- **CNN** sur tabular : médiocre, biais ne correspondent pas
- **Transformer** sur séquences : excellent (attention) — mais lourdement compensé par massive data
- **KNN** sur petites données low-dim : excellent, prior "smoothness"
- **KNN** en haute dim : effondrement (curse of dimensionality)

Chaque algo a son **terrain de chasse**.

### NFL vs DL/Foundation models

Les fondation models modernes (GPT, CLIP) semblent contredire NFL — ils marchent sur **plein de tâches**. Mais :
- Ils ont été **pré-entraînés** sur des distributions massives représentatives → biais inductifs appris matchent les distributions futures (qui partagent structure)
- Ils marchent sur les tâches que **NOUS** considérons intéressantes (langage, images naturelles) — qui ont une structure
- Sur des tâches **vraiment** out-of-distribution (data synthétique adversariale, langues exotiques mal représentées), ils échouent

NFL n'est pas violé — il est juste **moins contraignant** quand on restreint l'espace des problèmes à "ceux que l'humanité rencontre".

## Quand c'est utile

- **Argument contre le "best algorithm" thinking** : utile pour réfuter une croyance dogmatique
- **Justification du tuning et de la cross-validation** : il faut tester sur ton problème, pas se fier aux benchmarks
- **Justification de l'EDA** (Exploratory Data Analysis) : comprendre la structure du problème pour choisir un algo adapté
- **Philosophie ML** : rappel humblesse — pas de méthode miraculeuse
- **Argument en revue de papiers** : "ce papier prétend que X marche partout" → demander des évidences inter-distributions

## Quand ça ne marche pas / pièges

- **Sur-citer NFL pour défendre n'importe quel algo** : "NFL dit qu'on ne peut pas comparer", faux — sur **ton** problème spécifique on peut tout à fait comparer.
- **Conclure que tous les algos sont équivalents en pratique** : faux. Sur des distributions naturelles (images, texte, tabular), certains algos dominent largement.
- **Ne pas faire de sélection de modèle car "NFL"** : aberrant. NFL motive justement la sélection de modèle.
- **NFL vs "data > algorithm"** : NFL n'est pas en contradiction avec "plus de données aide" — c'est compatible.
- **Confusion avec "free lunch"** dans d'autres contextes (gratuit vs payant, etc.) — sans rapport.
- **Croire que les benchmarks ne disent rien** : ils disent quelque chose **sur ces distributions**. C'est juste pas généralisable à toutes.

## Code minimal

```python
# Pas de code direct pour NFL (théorème), mais une illustration empirique

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier

# Datasets très différents
datasets = {
    'linéairement séparable': make_linearly_separable(),
    'non-linéaire compact (XOR)': make_xor(),
    'haute dim sparse': make_sparse_high_dim(),
    'sphère vs intérieur': make_spheres(),
}

algos = {
    'LogReg': LogisticRegression(),
    'RF': RandomForestClassifier(),
    'SVM-RBF': SVC(kernel='rbf'),
    'KNN': KNeighborsClassifier(),
}

# Performance varie selon le couple (algo, dataset)
for name_d, (X, y) in datasets.items():
    print(f"\n{name_d}:")
    for name_a, algo in algos.items():
        score = cross_val_score(algo, X, y, cv=5).mean()
        print(f"  {name_a}: {score:.3f}")

# Illustration NFL : aucun algo n'est en tête partout
```

## Pour aller plus loin

- Wolpert, *The lack of a priori distinctions between learning algorithms* (Neural Computation 1996)
- Wolpert & Macready, *No free lunch theorems for optimization* (IEEE Trans. Evol. Comput. 1997)
- *No Free Lunch and Inductive Bias* — article pédagogique sur les conséquences pratiques
- **Liens internes** : [[VC dimension]], [[PAC learning]], [[Bias-variance tradeoff]], [[Cross-validation]]
