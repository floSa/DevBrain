---
galaxie: wiki
nom: Decision Tables
alias: [decision-table, dmn-table, decision tables, hit policy, hit-policies]
type: concept
categorie: concept/business-rules
sous_categories: [dmn, decision-tables, hit-policy, business-rules, rules]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [OMG, T. R. Pollack 1971 (decision tables historiques), Bruce Silver]
lecture_min: 9
created: 2026-05-21
modified: 2026-05-21
tags: [concept, dmn, decision-tables, business-rules]
---

# Decision Tables

## TL;DR

La forme **canonique** d'expression d'une décision en DMN, mais le concept est antérieur (années 1960-70 : Pollack, Vanthienen). Une table = des **règles en lignes**, des **inputs en colonnes**, et **un ou plusieurs outputs**. Pour gérer les multi-match, DMN définit **7 hit policies** : **U**nique, **A**ny, **P**riority, **F**irst, **R**ule order, **O**utput order, **C**ollect. Lisible business, exécutable par moteur, testable. C'est *le* gain pédagogique de DMN sur le code natif.

## Le problème

Tu écris une règle métier en code :

```python
if age < 25:
    decision = "refused"
elif 25 <= age <= 65 and income > 30000:
    decision = "accepted"
elif 25 <= age <= 65 and 15000 <= income <= 30000:
    decision = "accepted_with_guarantor"
elif 25 <= age <= 65 and income < 15000:
    decision = "refused"
elif age > 65 and income > 50000:
    decision = "accepted"
elif age > 65:
    decision = "refused"
else:
    decision = "?"  # cas oublié
```

Problèmes :
- **Cas oublié** : facile à manquer (ex. `age == 25` avec `income == 30000` ?)
- **Cas en double** : les conditions peuvent se chevaucher silencieusement
- **Métier ne peut pas le relire** : c'est du Python
- **Audit pénible** : pas de format normé
- **Test : 1 ligne = 1 test**, mais où est la liste exhaustive ?

Une **decision table** résout les 5 d'un coup.

## L'idée

### Structure standard

```
+-------+-----------------+-----------------+--------------------------+
| Règle | Âge (input)     | Revenu (input)  | → Éligibilité (output)   |
+-------+-----------------+-----------------+--------------------------+
|   1   | < 25            | -               | "refused"                |
|   2   | [25..65]        | > 30000         | "accepted"               |
|   3   | [25..65]        | [15000..30000]  | "accepted_with_guarantor"|
|   4   | [25..65]        | < 15000         | "refused"                |
|   5   | > 65            | > 50000         | "accepted"               |
|   6   | > 65            | <= 50000        | "refused"                |
+-------+-----------------+-----------------+--------------------------+
```

- `-` (tiret) = "any", la condition est ignorée pour cette règle
- `[a..b]` = intervalle fermé (FEEL)
- `(a..b)` = intervalle ouvert
- `<`, `>`, `<=`, `>=` = comparateurs
- `"x", "y"` (avec virgule) = enum (union)
- `not(...)` = négation
- expressions FEEL complètes possibles dans les cellules

### Hit policies — comment résoudre les multi-match

Quand plusieurs règles matchent simultanément, comment résoudre ? DMN définit 7 politiques :

#### Politiques single-output (une seule conclusion sortie)

| Code | Nom | Comportement |
|---|---|---|
| **U** | **Unique** | Au plus **une seule** règle peut matcher. Erreur sinon. *Le plus utilisé*, force le designer à couvrir sans chevauchement |
| **A** | **Any** | Plusieurs règles peuvent matcher, mais elles **doivent toutes donner la même sortie**. Erreur sinon |
| **P** | **Priority** | Si plusieurs matchent, prendre celle dont l'output a la **priorité la plus haute** (priorité définie sur les valeurs d'output) |
| **F** | **First** | Si plusieurs matchent, prendre la **première dans l'ordre des lignes** ⚠️ |

#### Politiques multi-output (liste de conclusions)

| Code | Nom | Comportement |
|---|---|---|
| **R** | **Rule Order** | Liste, ordre des lignes |
| **O** | **Output Order** | Liste, ordre par priorité d'output |
| **C** | **Collect** | Liste, opérateurs optionnels : `C+` somme, `C<` min, `C>` max, `C#` count, `C` set |

### Pourquoi U est préférable

- **Force la complétude** : tu dois couvrir tous les cas (sinon erreur runtime)
- **Force l'unicité** : tu ne peux pas chevaucher (sinon erreur)
- **Auditable** : un seul match = un seul raisonnement à expliquer
- **Optimisable** : le moteur peut court-circuiter

**A** est utile pour les règles "défensives" où plusieurs conditions confirment la même sortie. **F** est dangereuse (ordre = sémantique, fragile au refactoring). **P** est utile pour les exceptions hiérarchiques. **C** est utile pour aggregations (somme de pénalités, liste d'alertes).

### Complétude et chevauchement

DMN définit 2 propriétés clés à vérifier :

- **Complétude** : pour toute combinaison d'inputs valides, **au moins une règle** matche
- **Non-chevauchement** : pour toute combinaison, **au plus une règle** matche

Avec hit policy U : les deux doivent être garanties (sinon erreur runtime).

Les bons outils (Camunda Modeler, Trisotech) **détectent statiquement** les chevauchements et trous → feedback immédiat au design time. C'est un des superpouvoirs de DMN.

### Orientation : horizontale vs verticale vs crosstab

DMN supporte 3 orientations visuelles, équivalentes en sémantique :

```
HORIZONTALE (par défaut)        VERTICALE                    CROSSTAB
+----+----+----+                +----+----+----+----+        Age \ Revenu  | > 30k | [15..30]k | < 15k
| C1 | C2 | →O |                | R1 | R2 | R3 | R4 |        ----------+-------+----------+------
+----+----+----+                +----+----+----+----+         < 25     | ref   | ref      | ref
| R1 |    |    |                | C1 |    |    |    |         [25..65] | acc   | guarant  | ref
| R2 |    |    |                | C2 |    |    |    |         > 65     | acc(*)| ref      | ref
| R3 |    |    |                | →O |    |    |    |
+----+----+----+                +----+----+----+----+

R = rule, C = condition, O = output, * = avec condition supplémentaire
```

La **horizontale** est dominante en pratique (la plus lisible pour > 5 règles).

### Types d'inputs et outputs

DMN type chaque colonne :
- `string`, `number`, `boolean`, `date`, `time`, `dateTime`, `duration`
- **Types custom** définis via `<itemDefinition>` (structs FEEL)
- **Listes** : `List<string>`, etc.
- **Énums** restreints : `colors = "red", "green", "blue"` → la cellule input ne peut prendre que ces valeurs

L'outil de modeling valide statiquement et autocomplète.

### Decision Table vs autres boxed expressions

Les decision tables ne sont pas la seule façon d'exprimer une décision DMN. Voir [[Boxed Expressions]] pour les alternatives (literal expression, invocation, function, context, etc.). Mais 80% des décisions en pratique = table.

### Compilation et exécution

Le moteur DMN parse le XML, compile la table en arbre de décision (ou réseau Rete pour des engines comme Drools), et évalue les inputs. Pour des tables très grandes (> 1000 lignes), les optimisations indexées (ex. **Hash-Indexed Decision Tables**) sont disponibles dans certains moteurs.

## Quand c'est utile

- **Toute logique IF/ELIF/ELSE** > 5 branches → table plus lisible que code
- **Règles métier qui changent** : éditer une table > déployer du code
- **Audit obligatoire** (banque, assurance, santé) : tableau exécutable + tracé
- **Test exhaustif** : chaque ligne = 1 test unitaire trivial à générer
- **Communication métier ↔ tech** : business analyst édite la table
- **Détection de trous / chevauchements** : feedback statique par les outils
- **Versioning lisible** : XML diff plus parsable que diff sur du code IF/ELSE
- **Combo BPMN** : *Business Rule Task* invoque cette table

## Quand ça ne marche pas / pièges

- **Logique itérative / récursive** : une table n'est pas faite pour "tant que", "pour chaque" → utiliser BKM avec FEEL list comprehension, ou retomber sur du code
- **Trop de colonnes inputs (> 7-8)** : la table devient illisible, à découper via DRD (sous-décisions)
- **Hit policy First sur logique complexe** : ordre fragile, refactoring casse silencieusement → préférer U
- **Hit policy Any mal vérifiée** : "elles devraient toutes donner le même output" est une assertion qu'il faut tester
- **Cellules avec expressions FEEL très longues** : si tu écris `if (x > y) then ... else ...` dans une cellule, c'est probablement une autre décision à extraire
- **Tables avec sub-décision implicite** : "calculer le ratio puis classer" en une seule table → 2 décisions à séparer
- **Pas de couverture de complétude** : avec hit U sans clauses catch-all, erreur runtime sur cas non prévu
- **Énumérations non typées** : `"refused"` vs `"refus"` → typage `enum` empêche cette erreur
- **Table avec 500 lignes générées par script** : si c'est du data, ce n'est pas une table de décision → mettre en table SQL et joiner
- **Confusion U vs A** : choisir A "au cas où" = laxisme, U est plus propre par défaut
- **Output unique alors qu'il devrait y avoir plusieurs** : si tu calcules à la fois `score` et `motif`, 2 outputs dans la même table > 2 décisions séparées

## Code minimal

### Table en XML DMN (extrait)

```xml
<decision id="eligibility" name="Eligibility">
  <decisionTable hitPolicy="UNIQUE">
    <input id="age" label="Age">
      <inputExpression typeRef="number"><text>age</text></inputExpression>
    </input>
    <input id="income" label="Income">
      <inputExpression typeRef="number"><text>income</text></inputExpression>
    </input>
    <output id="result" label="Eligibility" typeRef="string"/>

    <rule id="r1">
      <inputEntry><text>&lt; 25</text></inputEntry>
      <inputEntry><text>-</text></inputEntry>
      <outputEntry><text>"refused"</text></outputEntry>
    </rule>
    <rule id="r2">
      <inputEntry><text>[25..65]</text></inputEntry>
      <inputEntry><text>&gt; 30000</text></inputEntry>
      <outputEntry><text>"accepted"</text></outputEntry>
    </rule>
    <rule id="r3">
      <inputEntry><text>[25..65]</text></inputEntry>
      <inputEntry><text>[15000..30000]</text></inputEntry>
      <outputEntry><text>"accepted_with_guarantor"</text></outputEntry>
    </rule>
    <!-- ... rules 4-6 -->
  </decisionTable>
</decision>
```

### Exemple Collect (somme)

Calcul d'une pénalité totale, sommée par règles qui matchent :

```xml
<decisionTable hitPolicy="COLLECT" aggregation="SUM">
  <input label="Late days"><inputExpression typeRef="number"><text>days</text></inputExpression></input>
  <input label="Amount"><inputExpression typeRef="number"><text>amount</text></inputExpression></input>
  <output label="Penalty" typeRef="number"/>

  <rule><inputEntry><text>&gt; 30</text></inputEntry><inputEntry><text>-</text></inputEntry><outputEntry><text>50</text></outputEntry></rule>
  <rule><inputEntry><text>&gt; 90</text></inputEntry><inputEntry><text>-</text></inputEntry><outputEntry><text>100</text></outputEntry></rule>
  <rule><inputEntry><text>-</text></inputEntry><inputEntry><text>&gt; 10000</text></inputEntry><outputEntry><text>200</text></outputEntry></rule>
</decisionTable>
<!-- Si retard 100j ET montant 15k : matche r1+r2+r3 → 50+100+200 = 350 -->
```

### Test unitaire d'une table (Camunda)

```java
@Test
public void testEligibilityAcceptedWithGuarantor() {
    DmnEngine engine = DmnEngineConfiguration.createDefaultDmnEngineConfiguration().buildEngine();
    DmnDecision decision = engine.parseDecision("eligibility", inputStream);

    VariableMap vars = Variables.createVariables()
        .putValue("age", 35)
        .putValue("income", 20000);

    DmnDecisionResult result = engine.evaluateDecision(decision, vars);
    assertEquals("accepted_with_guarantor", result.getSingleResult().getSingleEntry());
}
```

### Génération de tests exhaustifs (un par règle)

```java
for (DmnDecisionTableRule rule : table.getRules()) {
    VariableMap testCase = synthesizeInputs(rule);  // génère un input qui matche cette règle
    DmnDecisionResult result = engine.evaluateDecision(decision, testCase);
    assertEquals(rule.expectedOutput(), result.getSingleEntry());
}
```

Les outils Camunda / Drools ont aussi un **mode debug** : "pour cet input, quelles règles ont matché ?" → trace explicable.

## Pour aller plus loin

- Vanthienen et al., *Validation and verification of decision tables* (papers académiques années 90) — l'origine théorique
- Bruce Silver, *DMN Method and Style*, ch. 6-8 (tables et hit policies)
- OMG DMN spec, sections 8.2-8.3 (decision tables et hit policies) : https://www.omg.org/spec/DMN/
- Camunda DMN reference : https://docs.camunda.io/docs/components/modeler/dmn/decision-table/
- Drools DMN doc (hit policies en détail) : https://docs.drools.org/
- **Liens internes** : [[Decision Model and Notation]], [[FEEL]], [[DRD - Decision Requirements Diagram]], [[Boxed Expressions]], [[DMN Conformance Levels]]
