---
galaxie: dev
nom: plotly
alias: [plotly, plotly.py, plotly-express, px]
categorie: tooling/viz
sous_categories: [plotting, interactive, web, dash]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python (JS d3 backend)
clients_officiels: [python, ts, r]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[matplotlib]]", "[[bokeh]]", "[[altair]]", "ECharts"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, tooling, viz, interactive]
url_officiel: https://plotly.com/python/
url_docs: https://plotly.com/python/
url_repo: https://github.com/plotly/plotly.py
---

# plotly

## Pourquoi
Plotting **interactif** Python first-class. Plotly Express pour la simplicité (`px.scatter()`), Graph Objects pour le contrôle. Sortie HTML/JSON, embed direct dans notebook ou web. Compagnon de [[Streamlit]] / Dash pour dashboards.

## Quand l'utiliser
- Plots interactifs (zoom, hover, click events)
- Dashboards [[Streamlit]] / Dash
- Embed HTML dans rapports web ou Notion
- Geo-viz (maps Mapbox, choropleth)
- Quand l'esthétique compte sans config lourde

## Quand NE PAS l'utiliser
- Publication scientifique statique → [[matplotlib]] (PDF/SVG net)
- Très large dataset (> 100k points) → utiliser scattergl, Datashader, ou autre lib
- Customisation très fine de chaque pixel → matplotlib offre plus de contrôle

## Pièges connus
- **Bundle size** : ~3 MB de JS, à connaitre pour pages web légères
- **Plotly Express vs Graph Objects** : commencer par Express, basculer GO si besoin
- **Performance** : passer en `Scattergl` (WebGL) au-delà de quelques milliers de points
- **Theming** : `template="plotly_white"` ou `simple_white` pour exports propres
- **Export PNG/PDF** : nécessite `kaleido` (lib séparée) ou Orca legacy

## Liens
- [[matplotlib]] — alternative statique
- [[Streamlit]] / [[Gradio]] — embed `st.plotly_chart(fig)`
- Plotly Express docs : https://plotly.com/python/plotly-express/
- Dash (companion framework dashboards) : https://dash.plotly.com/
