---
galaxie: wiki
nom: schedule
type: claude-code-skill
plateforme: claude-code
categorie: skill/dev-flow
sous_categories: [cron, agents, routines, automation]
auteur: Anthropic
source: claude-code natif
source_url: https://docs.claude.com/en/docs/claude-code
install_cmd: 
install_doc: 
licence: 
licence_type: proprietary
domaines: [mlops, ai-eng, data-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, cron, automation]
---

# schedule

## Pourquoi

Skill **bundled** pour **créer, gérer, exécuter des agents distants planifiés** (routines) qui tournent sur cron côté Anthropic. Différent de [[claude-loop|loop]] (qui tourne tant que la session est ouverte) : `schedule` lance un agent indépendant, même si tu fermes Claude.

Cas d'usage : monitoring quotidien, audit hebdo, rappel mensuel, triage GitHub matinal.

## Quand l'utiliser

- "Tous les matins à 8h, résume mes issues GitHub assignées"
- "Chaque lundi, audit la qualité de mes pipelines de la semaine"
- "Une fois par mois, propose une consolidation de mes fiches DevBrain"
- One-shot : "lance ceci une fois demain à 15h"

## Quand NE PAS l'utiliser

- Polling temps réel — utilise [[claude-loop|loop]] (synchrone, en session)
- Le skill nécessite un compte avec accès aux remote agents — pas dispo en self-hosted

## Comment l'installer

Natif Claude Code. Invocation : `/schedule ...`.

## Exemples d'usage

```
> /schedule create "0 8 * * 1-5" "résume mes notifications GitHub"
> /schedule list
> /schedule run audit-devbrain  # one-shot maintenant
> rappelle-moi de check ce déploiement demain à 15h
```

## Pièges connus

- Les agents schedulés consomment du quota — surveille l'usage
- Pas de garantie d'exécution à la seconde près (best-effort cron)
- Pour les actions critiques (déploiement prod), préfère un vrai cron / Airflow

## Liens

- Doc Claude Code : https://docs.claude.com/en/docs/claude-code
- [[claude-loop|loop]] (alternative synchrone en session)
