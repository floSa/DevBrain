---
galaxie: wiki
nom: Actor-Critic methods
alias: [actor-critic, A2C, A3C, DDPG, TD3, SAC, off-policy actor-critic]
type: concept
categorie: concept/ml
sous_categories: [rl, actor-critic, policy-gradient, sac, ddpg, td3, a2c]
domaines: [ml-eng, ai-eng]
maturite: established
auteurs_cles: [Konda & Tsitsiklis 1999, Mnih 2016 (A3C), Lillicrap 2016 (DDPG), Fujimoto 2018 (TD3), Haarnoja 2018 (SAC)]
lecture_min: 9
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, rl, actor-critic]
---

# Actor-Critic methods

## TL;DR

Combine **policy gradient** (l'*actor* π_θ) et **value function** (le *critic* V_φ ou Q_φ) qui sert de baseline. Réduit la variance vs REINFORCE. Famille des algos production : **A2C / A3C** (on-policy, synchrone / async), **DDPG / TD3** (off-policy, déterministe, actions continues), **SAC** (off-policy, stochastique, max-entropy — l'algo *par défaut* en robotique continue). PPO est aussi techniquement un actor-critic on-policy. C'est l'architecture dominante en deep RL moderne.

## Le problème

REINFORCE / vanilla policy gradient a une **variance énorme** : $\nabla J \propto \log \pi \cdot G_t$, et $G_t$ varie massivement. Q-learning marche mal en actions continues. **L'idée actor-critic** : utiliser un **critic** (réseau de valeur) pour estimer $Q$ ou $V$, et **plugger ces estimations dans le gradient policy** comme baseline / cible — réduit la variance sans introduire (trop) de biais.

## L'idée

### Le couple actor + critic

- **Actor** $\pi_\theta(a | s)$ : la politique paramétrée, mise à jour par [[Policy gradient]]
- **Critic** $V_\phi(s)$ ou $Q_\phi(s, a)$ : la fonction de valeur, mise à jour par TD (cible Bellman)

**Mise à jour de l'actor** (advantage form) :

$$ \nabla_\theta J \approx \mathbb{E} \big[ \nabla \log \pi_\theta(a_t | s_t) \cdot \hat A_t \big] $$

avec $\hat A_t = \delta_t = r + \gamma V_\phi(s') - V_\phi(s)$ (one-step) ou GAE pour mieux — voir [[Value functions]].

**Mise à jour du critic** (régression sur la cible TD) :

$$ \mathcal{L}_\phi = \big( V_\phi(s_t) - (r + \gamma V_\phi(s_{t+1})) \big)^2 $$

Les deux se renforcent : un meilleur critic → un meilleur avantage → un meilleur policy ; une meilleure politique → des trajectoires plus pertinentes pour le critic.

### A2C / A3C — synchrone vs asynchrone

**A3C** (Mnih 2016) : plusieurs workers asynchrones, chacun avec sa copie des paramètres, qui appliquent des updates sur un master. Décorrélation des samples → exploration naturelle.

**A2C** : version synchrone (un master, attend tous les workers, fait un batch update). Plus simple, perf équivalente. **C'est la baseline standard** on-policy.

Loss combinée :

$$ \mathcal{L} = \mathcal{L}_{\text{actor}} + c_v \mathcal{L}_{\text{critic}} - c_e H(\pi) $$

avec un bonus d'entropie ($c_e \approx 0.01$) pour exploration. PPO ajoute juste le **clipping**.

### Off-policy actor-critic

Réutiliser les samples via un replay buffer (comme DQN), mais avec un actor :
- DDPG, TD3, SAC : critic = $Q_\phi(s, a)$ (vs $V$ pour A2C)
- Replay buffer + target networks (comme DQN)

Permet une **sample efficiency** beaucoup meilleure, au prix de complexité.

### DDPG — Deep Deterministic Policy Gradient (Lillicrap 2016)

**Pour actions continues**. La politique est **déterministe** : $a = \mu_\theta(s)$. Le gradient est :

$$ \nabla_\theta J = \mathbb{E}_{s \sim D} \big[ \nabla_\theta \mu_\theta(s) \cdot \nabla_a Q_\phi(s, a) \big|_{a = \mu_\theta(s)} \big] $$

Le critic $Q_\phi$ est entraîné comme DQN. L'exploration vient d'un **bruit additif** sur l'action (Ornstein-Uhlenbeck ou gaussien).

**Connu pour son instabilité** → motivait TD3.

### TD3 — Twin Delayed DDPG (Fujimoto 2018)

Trois améliorations sur DDPG :
1. **Double critic** : deux Q-nets, prendre le min → corrige l'overestimation (comme Double DQN)
2. **Delayed policy updates** : actor mis à jour 1 fois sur 2 du critic → stabilise
3. **Target policy smoothing** : bruit ajouté à l'action target → régularise

→ Plus stable, performant. Mais **politique déterministe** → exploration extérieure.

### SAC — Soft Actor-Critic (Haarnoja 2018)

**L'algo de référence pour le RL continu** depuis 2018. Trois idées clés :

#### 1. Max-entropy RL
Objectif modifié pour récompenser la diversité de la politique :

$$ J(\pi) = \mathbb{E}\left[\sum_t \gamma^t \big( r_t + \alpha H(\pi(\cdot | s_t)) \big)\right] $$

#### 2. Politique stochastique gaussienne
$\pi_\theta(a|s) = \mathcal{N}(\mu_\theta(s), \sigma_\theta(s))$ avec **reparameterization trick** ($a = \mu + \sigma \cdot \epsilon$) → gradient pathwise propre.

#### 3. Double Q + temperature adaptative
Comme TD3 (deux Q-nets, min des deux). $\alpha$ (force de l'entropie) est appris automatiquement pour atteindre une entropie cible.

**Pros** :
- Sample-efficient (off-policy)
- Stable, peu d'hyperparams à régler
- Exploration naturelle via entropy
- Marche pour discret et continu

**SAC est devenu le default pour la robotique RL** et plus largement le contrôle continu en simulation.

### Récapitulatif

| Algo | Politique | Critic | On/off | Action | Notes |
|---|---|---|:-:|---|---|
| A2C / A3C | stochastique | V | on | discret + continu | baseline, simple |
| PPO | stochastique | V | on | discret + continu | clip ratio, standard |
| DDPG | déterministe | Q | off | continu | instable |
| TD3 | déterministe | Q (double) | off | continu | corrige DDPG |
| **SAC** | stochastique | Q (double) | off | continu (+ disc) | **default** |
| DQN | greedy | Q | off | discret | value-based pur |

### Choix pratique

- **Robotique / contrôle continu** : SAC (default), TD3 si SAC instable
- **Atari / discret avec sample efficiency** : DQN/Rainbow, ou SAC discret
- **LLMs / RLHF** : PPO (legacy), DPO (sans RL), GRPO (reasoning)
- **Multi-task / curriculum** : PPO marche mieux quand l'environnement change
- **Tu hésites** : SAC pour continu, PPO sinon

## Quand c'est utile

- **Actions continues** : DDPG/TD3/SAC sont les outils du métier
- **Sample efficiency demandée** : off-policy (SAC) >> on-policy (PPO)
- **Robotique sim/réel** : SAC + sim-to-real domain randomization
- **Hyperparam-robuste** : SAC en pratique demande peu de tuning
- **Combo avec curiosité / exploration** : actor-critic absorbe bien les bonus intrinsèques (RND, ICM)
- **Recherche moderne** : la plupart des papers post-2018 partent d'un SAC ou variant

## Quand ça ne marche pas / pièges

- **DDPG est connu pour diverger** sans hyperparams parfaits → préférer TD3 ou SAC
- **Reward scaling** : magnitudes affectent fortement (alpha entropy vs reward) → clipper / normaliser
- **Sample efficiency illusoire** : off-policy demande quand même des millions de transitions sur tâches complexes
- **Bug critic** = bug policy : si $V_\phi$ ou $Q_\phi$ est mal entraîné, l'actor pointe au mauvais endroit
- **Target net update** trop lent / rapide : impact perf, à tuner ($\tau \approx 0.005$ Polyak typique)
- **Replay buffer tail off-policy lag** : transitions trop vieilles ne reflètent plus la politique courante
- **Multi-task / non-stationnaire** : actor-critic off-policy souffre, PPO mieux
- **Entropy collapse SAC** : si $\alpha$ trop bas, politique devient déterministe trop tôt → tuner / utiliser auto-α
- **CPU bottleneck en A2C** : un seul env est lent, parallèle (vec env) requis pour vitesse réelle
- **Logging de la KL et de l'entropy** est crucial pour diagnostiquer les drift

## Code minimal

```python
# A2C minimal (PyTorch, single env)
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical
import gymnasium as gym

class ActorCritic(nn.Module):
    def __init__(self, obs_dim, n_actions, hidden=128):
        super().__init__()
        self.shared = nn.Sequential(nn.Linear(obs_dim, hidden), nn.ReLU())
        self.actor = nn.Linear(hidden, n_actions)
        self.critic = nn.Linear(hidden, 1)
    def forward(self, x):
        h = self.shared(x)
        return self.actor(h), self.critic(h).squeeze(-1)

env = gym.make("CartPole-v1")
model = ActorCritic(env.observation_space.shape[0], env.action_space.n)
opt = optim.Adam(model.parameters(), lr=3e-4)
gamma = 0.99

for ep in range(1000):
    obs, _ = env.reset()
    log_probs, values, rewards, entropies = [], [], [], []
    done = False
    while not done:
        logits, V = model(torch.tensor(obs, dtype=torch.float))
        dist = Categorical(logits=logits)
        a = dist.sample()
        log_probs.append(dist.log_prob(a)); values.append(V); entropies.append(dist.entropy())
        obs, r, term, trunc, _ = env.step(a.item())
        rewards.append(r); done = term or trunc

    # Retours et avantages
    G, returns = 0.0, []
    for r in reversed(rewards):
        G = r + gamma * G
        returns.insert(0, G)
    returns = torch.tensor(returns, dtype=torch.float)
    values = torch.stack(values); log_probs = torch.stack(log_probs)
    advantages = returns - values.detach()
    advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

    actor_loss = -(log_probs * advantages).mean()
    critic_loss = (values - returns).pow(2).mean()
    entropy_bonus = torch.stack(entropies).mean()
    loss = actor_loss + 0.5 * critic_loss - 0.01 * entropy_bonus

    opt.zero_grad(); loss.backward()
    nn.utils.clip_grad_norm_(model.parameters(), 0.5)
    opt.step()
```

```python
# SAC en pratique (Stable-Baselines3)
from stable_baselines3 import SAC
import gymnasium as gym

env = gym.make("HalfCheetah-v4")
model = SAC(
    "MlpPolicy", env,
    learning_rate=3e-4, buffer_size=1_000_000,
    batch_size=256, tau=0.005, gamma=0.99,
    ent_coef="auto",                    # alpha appris automatiquement
    train_freq=1, gradient_steps=1,
    verbose=1,
)
model.learn(total_timesteps=1_000_000)
model.save("sac_halfcheetah")
```

```python
# TD3 en pratique
from stable_baselines3 import TD3
from stable_baselines3.common.noise import NormalActionNoise
import numpy as np

action_noise = NormalActionNoise(mean=np.zeros(6), sigma=0.1 * np.ones(6))
model = TD3("MlpPolicy", env, action_noise=action_noise,
            learning_rate=1e-3, policy_delay=2,         # delayed update
            target_policy_noise=0.2, target_noise_clip=0.5,
            verbose=1)
model.learn(total_timesteps=1_000_000)
```

```python
# Diagnostic d'entraînement (à logger systématiquement)
# - actor_loss, critic_loss, entropy
# - explained_variance(V, returns)
# - mean episode return + std
# - SAC : alpha value, target_entropy gap
# - learning rate, gradient norm
```

## Pour aller plus loin

- Sutton & Barto, sections actor-critic (ch. 13)
- Mnih et al., *Asynchronous Methods for Deep RL* (A3C, ICML 2016)
- Lillicrap et al., *Continuous Control with Deep RL* (DDPG, ICLR 2016)
- Fujimoto et al., *Addressing Function Approximation Error in Actor-Critic* (TD3, ICML 2018)
- Haarnoja et al., *Soft Actor-Critic* (ICML 2018) — https://arxiv.org/abs/1801.01290
- Haarnoja et al., *SAC: Algorithms and Applications* (2018) — version avec auto-α
- CleanRL single-file SAC : https://github.com/vwxyzjn/cleanrl/blob/master/cleanrl/sac_continuous_action.py
- **Liens internes** : [[Policy gradient]], [[Value functions]], [[Q-learning and DQN]], [[Reinforcement learning]], [[PPO]], [[Exploration vs exploitation]]
