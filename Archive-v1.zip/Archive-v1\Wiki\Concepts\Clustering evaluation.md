---
galaxie: wiki
nom: Clustering evaluation
alias: [silhouette, Davies-Bouldin, Calinski-Harabasz, ARI, NMI, clustering metrics]
type: concept
categorie: concept/ml
sous_categories: [clustering, evaluation, silhouette, metrics, validation]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Rousseeuw 1987 (silhouette), Davies-Bouldin 1979]
lecture_min: 8
created: 2026-05-19
modified: 2026-05-19
tags: [concept, ml, clustering, evaluation, metrics]
---

# Clustering evaluation — comment juger un clustering

## TL;DR

Le clustering est **non-supervisé** : pas de "bonne réponse" universelle. Évaluation en 2 cas : (1) **interne** (sans labels vrais) — silhouette, Davies-Bouldin, Calinski-Harabasz, BIC ; (2) **externe** (avec labels de référence) — ARI, NMI, V-measure. La **silhouette** est l'évaluation la plus polyvalente, mais aucune métrique unique ne dit "ce clustering est le bon".

## Le problème

Tu as essayé [[K-means]], [[DBSCAN]], [[GMM]], [[HCPC]] sur tes données. Comment savoir lequel est **meilleur** ? Le score à minimiser/maximiser pour le tuning de $K$ ?

Contrairement au supervisé (accuracy, MAE), le clustering n'a pas de "vraie réponse" → les métriques sont **proxy**.

## L'idée

### Évaluation interne (pas de labels)

Mesures qui ne nécessitent pas de "ground truth".

#### Silhouette

Pour chaque point $i$ :
- $a_i$ = distance moyenne aux points **du même cluster** (cohésion intra)
- $b_i$ = distance moyenne aux points du **cluster voisin le plus proche** (séparation)

$$ s_i = \frac{b_i - a_i}{\max(a_i, b_i)} \in [-1, 1] $$

- $s_i \to 1$ : point bien clustérisé
- $s_i \to 0$ : sur la frontière
- $s_i < 0$ : probablement mal assigné

**Silhouette moyenne** = qualité globale du clustering. Compare différents $K$ ou différents algos.

```python
from sklearn.metrics import silhouette_score, silhouette_samples
s = silhouette_score(X, labels)  # moyenne globale
s_per_point = silhouette_samples(X, labels)  # par point
```

**Interprétation** :

| Silhouette | Qualité |
|---|---|
| 0.7+ | Excellent |
| 0.5–0.7 | Bonne structure |
| 0.25–0.5 | Faible structure |
| < 0.25 | Pas de structure significative |

**Silhouette plot** : barres par cluster, permet de voir les clusters dégénérés.

#### Davies-Bouldin index

Moyenne des **ratios "diamètre intra / distance inter"** entre clusters voisins :

$$ \text{DB} = \frac{1}{K} \sum_{k=1}^K \max_{j \neq k} \frac{\sigma_k + \sigma_j}{d(\mu_k, \mu_j)} $$

Plus **bas** = meilleur. Pénalise les clusters chevauchants ou peu compacts.

#### Calinski-Harabasz (Variance Ratio Criterion)

Rapport entre dispersion **inter-cluster** et dispersion **intra-cluster** :

$$ \text{CH} = \frac{\text{tr}(B_K) / (K-1)}{\text{tr}(W_K) / (n-K)} $$

Plus **haut** = meilleur. Inspiré de la F-statistique de l'ANOVA.

#### BIC / AIC pour [[GMM]]

Quand le modèle est probabiliste (GMM), comparer par BIC. Métrique principale pour le choix de $K$ en GMM.

#### Inertia (WCSS) pour [[K-means]]

Décroît monotone avec $K$ → utiliser elbow method, **pas** comme score absolu.

### Évaluation externe (avec labels de référence)

Quand on a une **vraie classification** (ex. classes connues qu'on veut "retrouver"), on peut mesurer l'adéquation entre clusters trouvés et classes vraies.

#### Adjusted Rand Index (ARI)

Mesure d'accord ajusté pour le hasard. $\text{ARI} \in [-1, 1]$ :
- 1 : parfait
- 0 : aléatoire
- < 0 : pire qu'aléatoire

Calculé sur les paires de points qui sont/ne sont pas dans le même cluster ET dans la même classe.

```python
from sklearn.metrics import adjusted_rand_score
adjusted_rand_score(y_true, labels_predicted)
```

#### Normalized Mutual Information (NMI)

Information mutuelle normalisée entre les deux partitions. $\text{NMI} \in [0, 1]$.

Robust à la permutation des labels (cluster 1 du modèle peut correspondre à la classe 3 du ground truth).

#### V-measure

Moyenne harmonique de **homogénéité** (chaque cluster contient principalement une classe) et **complétude** (chaque classe est dans un seul cluster).

```python
from sklearn.metrics import normalized_mutual_info_score, v_measure_score
nmi = normalized_mutual_info_score(y_true, labels)
v = v_measure_score(y_true, labels)
```

### Quand utiliser quoi

| Cas | Métrique principale |
|---|---|
| Pas de labels, choisir $K$ pour K-means / GMM | Silhouette, Davies-Bouldin |
| Choisir $K$ pour GMM (probabiliste) | BIC |
| DBSCAN/HDBSCAN (pas de $K$ à choisir) | Silhouette + persistence (HDBSCAN) |
| Labels connus, valider un algo | ARI ou NMI |
| Comparer plusieurs algos sur le même dataset | Silhouette + ARI si labels |
| Time series / DBSCAN avec noise | Silhouette **excluant le bruit** (label -1) |

## Quand c'est utile

- Choisir $K$ pour K-means / GMM
- Comparer plusieurs algos sur le même dataset
- Valider qualitativement un clustering
- Tuning d'hyperparams ($\varepsilon$ pour DBSCAN, `min_cluster_size` pour HDBSCAN)

## Quand ça ne marche pas / pièges

- **Aucune métrique unique n'est universelle** — toujours croiser plusieurs (silhouette + DB + interprétation domaine)
- **Silhouette élevée ≠ bon clustering business** : un dataset avec 1 vrai cluster + 1 outlier aura une silhouette artificielle élevée si on splittermine en 2. **Validation domaine** indispensable.
- **Métriques externes (ARI, NMI)** : nécessitent un ground truth qui n'existe souvent pas en clustering
- **Distance euclidienne** sous-jacente : si les données ne sont pas métriques, les scores deviennent suspects (texte, catégoriel)
- **DBSCAN avec bruit** : silhouette inclut les noise points → fausse la métrique. **Exclure** label -1.
- **Comparer K-means $K=3$ vs DBSCAN $K=7$** sur silhouette : OK mathématiquement, mais à interpréter avec prudence — algos très différents

## Code minimal

```python
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

X_std = StandardScaler().fit_transform(X)

# Comparer plusieurs K (K-means)
for k in range(2, 11):
    km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(X_std)
    s = silhouette_score(X_std, km.labels_)
    db = davies_bouldin_score(X_std, km.labels_)
    ch = calinski_harabasz_score(X_std, km.labels_)
    print(f"K={k}: silhouette={s:.3f}, DB={db:.3f}, CH={ch:.1f}")

# Externe (si y_true dispo)
y_pred = KMeans(n_clusters=4, n_init=10, random_state=0).fit_predict(X_std)
ari = adjusted_rand_score(y_true, y_pred)
nmi = normalized_mutual_info_score(y_true, y_pred)
print(f"ARI={ari:.3f}, NMI={nmi:.3f}")

# Pour DBSCAN : exclure noise
from sklearn.cluster import DBSCAN
labels_db = DBSCAN(eps=0.5, min_samples=10).fit_predict(X_std)
mask = labels_db != -1
s_no_noise = silhouette_score(X_std[mask], labels_db[mask])
```

## Implémentations concrètes

- `sklearn.metrics` : `silhouette_score`, `silhouette_samples`, `davies_bouldin_score`, `calinski_harabasz_score`, `adjusted_rand_score`, `normalized_mutual_info_score`, `v_measure_score`, `homogeneity_score`, `completeness_score`
- `hdbscan.validity` : score spécifique HDBSCAN (Density-Based Cluster Validity)
- R : `cluster::silhouette`, `clValid` package

## Pour aller plus loin

- Rousseeuw, *Silhouettes: a graphical aid to the interpretation and validation of cluster analysis* (1987)
- Halkidi, Batistakis, Vazirgiannis, *On Clustering Validation Techniques* (2001) — review
- **Liens internes** : [[K-means]], [[DBSCAN]], [[GMM]], [[HCPC]], [[t-SNE and UMAP]]
