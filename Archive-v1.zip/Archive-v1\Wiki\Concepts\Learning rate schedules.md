---
galaxie: wiki
nom: Learning rate schedules
alias: [LR schedule, warmup, cosine, cyclical, OneCycle, lr decay]
type: concept
categorie: concept/optimization
sous_categories: [learning-rate, warmup, cosine, scheduling, hyperparameter]
domaines: [ml-eng, ai-eng]
maturite: established
auteurs_cles: [Smith 2017 (1cycle), Loshchilov-Hutter 2017 (SGDR)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, optimization, learning-rate, schedule]
---

# Learning rate schedules

## TL;DR

Le **learning rate** $\eta$ est l'hyperparamètre le plus critique en deep learning. Le **garder constant** est rarement optimal : on veut **gros LR au début** (exploration) et **petit LR à la fin** (raffinement). Plusieurs stratégies : **step decay**, **exponential decay**, **cosine annealing**, **warmup** (linéaire avant le LR max), **1cycle** (warmup + cooldown asymétrique). En LLM training, **warmup + cosine** est devenu standard.

## Le problème

Avec un LR constant :
- **Trop haut** : oscille, ne converge pas finement
- **Trop bas** : convergence ultra-lente, blocage en début

Avec un schedule :
- **Début** : grand LR pour explorer la loss landscape, sortir de mauvais voisinages
- **Fin** : petit LR pour fine-tuner près du minimum

## L'idée

### Step decay

Diviser le LR par un facteur tous les $k$ epochs :

$$ \eta_t = \eta_0 \cdot \gamma^{\lfloor t / k \rfloor} $$

avec $\gamma$ typique 0.1, 0.5, ou 0.9.

```
LR : 0.1 → 0.01 → 0.001 → ...
```

Simple, encore utilisé sur CV / ImageNet classique. Pas optimal en moderne.

### Exponential decay

$$ \eta_t = \eta_0 \cdot e^{-\lambda t} $$

Decay continu. Moins de stabilité que step (pas de plateau).

### Polynomial / linear decay

$$ \eta_t = \eta_0 \cdot \left(1 - \frac{t}{T}\right)^p $$

Linear ($p = 1$) très utilisé en NLP / RoBERTa-like.

### Cosine annealing (Loshchilov-Hutter 2017)

$$ \eta_t = \eta_{\min} + \frac{1}{2}(\eta_{\max} - \eta_{\min})\left(1 + \cos\frac{t \pi}{T}\right) $$

Décroissance lisse, cosinusoïdale, du max au min. **Standard** en NLP / vision moderne. Plus efficace que step ou linear empiriquement.

### Warmup

Démarrer avec **LR = 0** et l'**augmenter linéairement** jusqu'à $\eta_{\max}$ sur les premiers $W$ steps.

$$ \eta_t = \eta_{\max} \cdot \min(1, t / W) $$

**Critique pour transformers** : sans warmup, la loss diverge dans les premiers steps. Raison : Adam stocke des moments mal calibrés au début → updates erratiques.

Typique : $W = 1000$ à $10000$ steps, soit 1-10% du training total.

### Warmup + cosine (le standard LLM)

Combine warmup + cosine annealing :

```
LR
 |     /\
 |    /  \____
 |   /        \____
 |  /              \____
 | /                    \___
 |/__________________________\
   warmup    cosine decay
```

Defaults populaires :
- LLM pre-training : warmup 2000 steps, total 100k+ steps, $\eta_{\max} = 3 \times 10^{-4}$
- Fine-tuning : warmup 100-500 steps, $\eta_{\max} = 5 \times 10^{-5}$ à $10^{-4}$

### 1cycle / OneCycle (Leslie Smith 2017)

Variant rapide : warmup linéaire jusqu'à un LR très haut, puis decay symétrique vers très bas, en **un seul cycle** sur tout le training.

$$ 1: \eta \nearrow \eta_{\max}, \quad 2: \eta_{\max} \searrow \eta_{\min} \quad (\eta_{\min} = \eta_{\max} / 100) $$

Peut accélérer l'entraînement de 2-10× sur CV. Demande tuning fin de $\eta_{\max}$ via **LR finder**.

### Cosine warm restarts (SGDR)

Cosine annealing **redémarré périodiquement** :

```
LR
 |\         /\         /\
 | \       /  \       /  \
 |  \     /    \     /    \
 |   \___/      \___/      \___
```

Permet de "réessayer" : sortir d'un mauvais minimum local en relançant un grand LR. Utilisé en CV, parfois en LLM.

### ReduceLROnPlateau

LR réduit **automatiquement** quand la val_loss stagne :

```python
optimizer = ...
scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5)
for epoch in range(num_epochs):
    train_one_epoch()
    val_loss = evaluate()
    scheduler.step(val_loss)
```

Pratique mais réactif (pas proactif). Plutôt en complément.

### LR finder (Smith Cyclical LR)

Avant l'entraînement, faire un **mini-run** où le LR croit exponentiellement de $10^{-8}$ à 10. Plot loss vs LR :

```
loss
  |\
  | \
  |  \____  ← début de la zone où LR est utile
  |       \
  |        \___  ← minimum loss
  |             \
  |              ⤢⤢ ← divergence
  +-----------------
   LR (log scale)
```

Choisir $\eta_{\max}$ légèrement avant le minimum. Méthode **très efficace** pour calibrer le LR initial sans search.

## Quand c'est utile

- **Transformers / LLMs** : warmup + cosine, indispensable
- **CNN / Vision classique** : step decay ou cosine
- **Fine-tuning** : LR plus petit + warmup court
- **Petits modèles** : OneCycle pour entraîner vite
- **Hyperparam tuning** : LR finder en pré-étape

## Quand ça ne marche pas / pièges

- **Pas de warmup sur transformers** : divergence quasi-garantie. Ne jamais skip.
- **Schedule trop long** : LR descend trop vite, modèle bloqué au début
- **Schedule trop court** : LR reste haut, oscille
- **Total steps mal calculé** : cosine doit savoir où elle finit. Si on continue past T : LR = $\eta_{\min}$ constant, fin sans cooldown.
- **ReduceLROnPlateau seul** sans warmup : réactive mais souvent insuffisante pour transformers
- **LR finder mal interprété** : choisir le minimum exact = trop optimiste. Marge de sécurité × 1/10.
- **LR partagé sur tous les paramètres** : pour fine-tuning, **LR différencié** entre layers (discriminative LR) souvent meilleur.

## Code minimal

```python
import torch.optim as optim
from torch.optim.lr_scheduler import (
    StepLR, ExponentialLR, CosineAnnealingLR, CosineAnnealingWarmRestarts,
    ReduceLROnPlateau, OneCycleLR, LambdaLR
)

optimizer = optim.AdamW(model.parameters(), lr=1e-4)

# Step decay
sched = StepLR(optimizer, step_size=10, gamma=0.5)

# Cosine annealing simple
sched = CosineAnnealingLR(optimizer, T_max=100, eta_min=1e-6)

# Warm restarts
sched = CosineAnnealingWarmRestarts(optimizer, T_0=10, T_mult=2)

# ReduceOnPlateau (réactif)
sched = ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=3)

# OneCycle (très efficace pour CV)
sched = OneCycleLR(optimizer, max_lr=1e-3, total_steps=10000, pct_start=0.3)

# Warmup + cosine custom (idiome LLM)
import math
def warmup_cosine(step, warmup_steps, total_steps):
    if step < warmup_steps:
        return step / warmup_steps
    progress = (step - warmup_steps) / (total_steps - warmup_steps)
    return 0.5 * (1 + math.cos(math.pi * progress))

sched = LambdaLR(optimizer, lr_lambda=lambda s: warmup_cosine(s, 1000, 50000))

# Boucle d'entraînement
for step in range(total_steps):
    optimizer.zero_grad()
    loss = compute_loss(...)
    loss.backward()
    optimizer.step()
    sched.step()  # appelle après optimizer.step()
```

## Pour aller plus loin

- Smith, *Cyclical Learning Rates for Training Neural Networks* (2017) — LR finder + cyclical
- Loshchilov & Hutter, *SGDR* (ICLR 2017) — cosine annealing
- Vaswani et al., *Attention is All You Need* (2017) — propose warmup pour transformer
- Goyal et al., *Accurate, Large Minibatch SGD* (2017) — warmup pour grand batch
- **Liens internes** : [[Gradient descent]], [[Adam optimizer]], [[Cross-validation]] (pour tuning du schedule)
