---
galaxie: wiki
nom: PAC learning
alias: [Probably Approximately Correct, PAC, agnostic PAC, PAC-Bayes]
type: concept
categorie: concept/learning-theory
sous_categories: [pac-learning, agnostic-pac, sample-complexity, generalization]
domaines: [ml-eng]
maturite: established
auteurs_cles: [Valiant 1984]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, learning-theory, pac]
---

# PAC learning — Probably Approximately Correct

## TL;DR

Cadre théorique fondamental de l'apprentissage statistique (Valiant 1984) : un algorithme est **PAC-learner** s'il peut, avec un nombre **polynomial** d'échantillons, trouver une hypothèse qui est avec **haute probabilité** ($1 - \delta$) **approximativement correcte** (erreur ≤ $\varepsilon$). Définit ce qu'on peut "apprendre" en théorie, et combien de données il faut.

## Le problème

Quand peut-on **garantir** qu'un algorithme apprend ? Avec combien d'échantillons ? Avec quelle confiance ?

PAC formalise ces questions et donne un cadre pour répondre.

## L'idée

### Setup

- $\mathcal{X}$ : espace des inputs
- $\mathcal{Y} = \{0, 1\}$ : labels binaires (cas standard)
- $\mathcal{D}$ : distribution sur $\mathcal{X} \times \mathcal{Y}$ inconnue
- $\mathcal{H}$ : classe d'hypothèses
- $h^*$ : hypothèse cible (cas réalisable : $h^* \in \mathcal{H}$)

L'apprenant voit $m$ échantillons i.i.d. selon $\mathcal{D}$ et doit produire $\hat h \in \mathcal{H}$.

### Risque vrai vs empirique

- **Risque vrai** : $R(h) = \mathbb{P}_{(x, y) \sim \mathcal{D}}[h(x) \neq y]$
- **Risque empirique** : $\hat R(h) = \frac{1}{m} \sum_{i=1}^m 1[h(x_i) \neq y_i]$

L'**ERM** (Empirical Risk Minimization) choisit $\hat h = \arg\min_h \hat R(h)$.

### Définition PAC learnability (cas réalisable)

$\mathcal{H}$ est **PAC-apprenable** s'il existe un algorithme $A$ et une fonction polynomiale $m(\varepsilon, \delta)$ tels que, pour tout $\varepsilon, \delta \in (0, 1)$ et toute distribution $\mathcal{D}$ telle que $h^* \in \mathcal{H}$ :

$$ \mathbb{P}\big[R(A(S_m)) \leq \varepsilon\big] \geq 1 - \delta $$

dès que $m \geq m(\varepsilon, \delta)$.

**Probably** ($1 - \delta$) **Approximately Correct** ($\leq \varepsilon$). PAC.

### Sample complexity

Pour une classe finie $\mathcal{H}$, en cas réalisable :

$$ m \geq \frac{1}{\varepsilon} \left(\log |\mathcal{H}| + \log \frac{1}{\delta}\right) $$

Si $\mathcal{H}$ a VC dim finie ([[VC dimension]]) :

$$ m \geq \frac{C}{\varepsilon} \left(\text{VC}(\mathcal{H}) \log \frac{1}{\varepsilon} + \log \frac{1}{\delta}\right) $$

**Théorème fondamental** : $\mathcal{H}$ est PAC-apprenable ⇔ $\text{VC}(\mathcal{H}) < \infty$.

### Agnostic PAC learning

Le cas réalisable suppose $h^* \in \mathcal{H}$ — souvent faux en pratique. **Agnostic PAC** étend au cas où la meilleure hypothèse $h^*$ peut avoir une erreur $R(h^*) > 0$.

Critère : on demande $R(\hat h) \leq R(h^*) + \varepsilon$ avec haute proba. Sample complexity devient $O(1/\varepsilon^2)$ (au lieu de $O(1/\varepsilon)$).

### PAC-Bayes

Extension bayésienne (McAllester 1999) : pour une distribution prior $P$ sur $\mathcal{H}$ et posterior $Q$ :

$$ \mathbb{E}_{h \sim Q}[R(h)] \leq \mathbb{E}_{h \sim Q}[\hat R(h)] + \sqrt{\frac{D_{\text{KL}}(Q \| P) + \log(1/\delta)}{2m}} + \text{lower order} $$

**Bornes tight pour le DL** (Dziugaite-Roy 2017) : choisir $Q$ comme la distribution autour des poids appris, $P$ comme l'initialisation. La $D_{\text{KL}}$ remplace la VC dim → bornes pertinentes même pour NN sur-paramétrés.

### Limitations classique PAC

- **Worst-case** : suppose le pire distribution $\mathcal{D}$
- **Non-uniform** convergence en pratique nécessaire pour NN (norm-based bounds)
- **Polynomial in parameters** : pas dans le nombre de samples vs paramètres (où DL excelle bizarrement)

### Pour les NN

Bornes classiques PAC (via VC) inutilisables. Cadres modernes :
- **Norm-based** : borne sur produits de normes des matrices de poids (Bartlett 2017)
- **PAC-Bayes** : choix bien pensé de $P$ et $Q$ donne des bornes "non-vacuous"
- **Information-theoretic** : I(weights ; data) borne la généralisation (Xu-Raginsky 2017)

## Quand c'est utile

- **Justifier** théoriquement qu'un algorithme converge avec assez de données
- **Estimer la sample complexity** pour un problème donné
- **Comparer classes d'hypothèses** sur la difficulté d'apprentissage
- **Bornes pour la sécurité ML** : garantir que le modèle ne dépassera pas un risque donné
- **Choix de la régularisation** : agir sur la capacité effective

## Quand ça ne marche pas / pièges

- **Application directe au DL** : bornes vacuous (≥ 1 alors qu'on est intéressé par erreur ≤ 0.1)
- **Sample complexity worst-case** très pessimiste : empirique souvent meilleure
- **Hypothèse i.i.d. violée** (time series, données dépendantes) → PAC ne s'applique pas tel quel
- **Distribution shift** : PAC garantit sur la même distribution. Sur OOD, aucune garantie.
- **Confusion PAC avec "marche en pratique"** : un algo non-PAC peut marcher empiriquement (heuristique). Un algo PAC garantit la convergence mais peut être lent.
- **Borne ≠ erreur réelle** : c'est une borne sup, souvent très lâche. Test empirique reste indispensable.

## Code minimal

```python
import numpy as np

# Pas de "PAC en code" en soi, c'est un cadre théorique
# Mais on peut illustrer la sample complexity

def sample_complexity_finite_h(epsilon, delta, H_size):
    """Cas réalisable, classe finie."""
    return int(np.ceil((1 / epsilon) * (np.log(H_size) + np.log(1 / delta))))

def sample_complexity_vc(epsilon, delta, vc_dim):
    """Cas réalisable, classe infinie avec VC dim."""
    C = 8  # constante
    return int(np.ceil(
        (C / epsilon) * (vc_dim * np.log(1 / epsilon) + np.log(1 / delta))
    ))

# Exemple : SVM linéaire en dim 10
print(f"m ≥ {sample_complexity_vc(0.05, 0.05, vc_dim=11)} pour ε=5%, δ=5%, d=11")

# Vérification empirique de la borne (Monte Carlo)
def empirical_pac_check(algo, distribution, h_star, m, n_runs=100, epsilon=0.1):
    """Combien de fois R(h_hat) ≤ epsilon ?"""
    successes = 0
    for _ in range(n_runs):
        S = distribution.sample(m)
        h_hat = algo(S)
        R_h = distribution.true_risk(h_hat, h_star)
        if R_h <= epsilon:
            successes += 1
    return successes / n_runs  # estimate of 1 - delta
```

## Pour aller plus loin

- Valiant, *A theory of the learnable* (CACM 1984) — paper fondateur
- Kearns & Vazirani, *An Introduction to Computational Learning Theory* (1994) — classique
- Shalev-Shwartz & Ben-David, *Understanding Machine Learning* — chap. 3, 6, 31, gratuit
- Dziugaite & Roy, *Computing Nonvacuous Generalization Bounds for Deep (Stochastic) Neural Networks with Many More Parameters than Training Data* (UAI 2017) — PAC-Bayes pour DL
- **Liens internes** : [[VC dimension]], [[Rademacher complexity]], [[No Free Lunch theorem]], [[Bias-variance tradeoff]]
