---
name: process-inbox
description: |
  Use this skill to process items from the DevBrain root-level Inbox.md.
  Triggers: "traite mon inbox", "process inbox", "traite l'inbox",
  "vide l'inbox", "passe en revue mon inbox". Iterates over unchecked
  items ('- [ ]'), proposes a target (Services, Wiki/Concepts,
  Wiki/Workflows, Wiki/Outils, Patterns), delegates to the appropriate
  sub-skill (add-service, add-wiki-concept, add-wiki-workflow,
  add-wiki-outil), then checks the item and adds a wikilink to the
  created fiche.
---

# Skill — process-inbox

## Quand l'utiliser

L'utilisateur dit "traite mon inbox" ou variante. Le fichier `Inbox.md` à la racine du vault contient des items à ranger.

## Procédure

### Étape 1 — Inventaire

Lire `Inbox.md`. Extraire :
- Tous les items non cochés : `- [ ] <texte>`
- Le contexte/section dans lequel ils apparaissent (titre H2/H3 le plus proche au-dessus)

Compter par type détectable (heuristique : présence de `(service)`, `(concept)`, `(workflow)`, `(skill)`, `(pattern)` dans la ligne).

Annonce à l'utilisateur :

```
J'ai trouvé X items à traiter dans Inbox.md :
- 5 concepts
- 3 services
- 1 workflow
- 1 ambigu

Je les traite un par un. Tu peux dire 'skip' à tout moment, ou 'stop' pour arrêter.
```

### Étape 2 — Boucle item par item

Pour chaque item, dans l'ordre du fichier :

**a) Identifier le type**

Si `(<type>)` est dans la ligne, l'utiliser. Sinon, demander à l'utilisateur ou déduire du contexte.

**b) Identifier la cible**

| Type | Sub-skill à invoquer | Chemin cible |
|---|---|---|
| `service` | `add-service` | `Services/<Cat>/<Nom>.md` |
| `concept` | `add-wiki-concept` | `Wiki/Concepts/<Nom>.md` |
| `workflow` | `add-wiki-workflow` | `Wiki/Workflows/<Nom>.md` |
| `skill` | `add-wiki-outil` | `Wiki/Outils/<sous-dossier>/<nom>.md` |
| `pattern` | (créer manuellement) | `Patterns/Pattern - <nom>.md` |

**c) Choisir le niveau de complétude**

Trois options à proposer à l'utilisateur :

1. **Stub complet** : créer la fiche minimale (frontmatter + titre + 1 ligne de note depuis l'inbox) en `status: stub`. Rapide, à étoffer plus tard.
2. **Fiche complète maintenant** : invoque le sub-skill add-* qui demande infos détaillées (URL, install_cmd, etc.) et écrit la fiche en `status: discovered` (skills) ou `actif` (services) ou rien (concepts/workflows).
3. **Skip** : laisse cocher pas, prochain item.

L'utilisateur peut dire "tout en stub", "tout complet", ou item par item.

**d) Exécuter**

- Si **stub** : crée le fichier avec frontmatter minimal + 1 ligne. Pas de prompt-loop additionnel.
- Si **complet** : invoque le sub-skill correspondant.
- Si **skip** : passe.

**e) Mettre à jour Inbox.md**

Si l'item a été traité (stub ou complet) :
1. Remplacer `- [ ]` par `- [x]`
2. À la fin de la ligne, ajouter : ` → [[<chemin/nom du fichier créé>]]`
3. Garder l'item dans sa section d'origine (pas de déplacement automatique vers "Traité — historique")

À la fin de la session : déplacer tous les `- [x]` de la session vers la section "## Traité — historique" en bas, **uniquement** sur confirmation utilisateur ("range les traités ?").

### Étape 3 — Récap final

Annonce à la fin :

```
✅ Traité : N items
   - X en stub (à étoffer plus tard)
   - Y en fiches complètes
⏭️ Skippé : M items
❓ À clarifier : P items

Fiches créées :
- [[Wiki/Concepts/ACP]] (stub)
- [[Services/ML/prince]] (complet, score à attribuer après usage)
- ...

Prochaine étape suggérée :
- Pour étoffer les stubs : "expand-stub" sur Wiki/Concepts/
- Pour scorer les services nouveaux : utiliser, puis revenir mettre à jour
```

## Format minimal d'un stub

### Stub concept (Wiki/Concepts/)

```yaml
---
nom: <Nom>
type: concept
categorie: concept/<famille>     # ex: concept/stats, concept/llm, concept/ml
sous_categories: []
domaines: []
maturite: 
status: stub
created: <today>
modified: <today>
tags: [concept, stub]
---

# <Nom>

> **Stub** — à étoffer. Notes brutes depuis Inbox : <copie de la ligne Inbox>
```

### Stub workflow (Wiki/Workflows/)

```yaml
---
nom: <Nom>
type: workflow
categorie: workflow/<famille>    # ex: workflow/data-eng, workflow/ai-eng
sous_categories: []
domaines: []
duree_estimee: 
prerequis: []
status: stub
created: <today>
modified: <today>
tags: [workflow, stub]
---

# <Nom>

> **Stub** — à étoffer. Notes brutes : <copie ligne Inbox>
```

### Stub service (Services/)

Utilise le frontmatter complet du template Service, mais laisse les champs non-renseignés vides + `status: en-eval` (proche d'un stub côté Services).

### Stub skill (Wiki/Outils/)

Utilise le frontmatter Wiki-Skill complet, mais champs vides + `status: discovered`.

## Anti-patterns à éviter

- **Vider l'inbox d'un coup** sans validation par item — on rate la nuance utilisateur
- **Inventer des catégories** quand le type est ambigu — toujours demander
- **Créer un fichier vide** sans frontmatter (toujours au moins le minimum)
- **Ne pas cocher les items traités** — l'inbox doit refléter l'état réel
- **Toucher au CLAUDE.md ou autre fichier de méta** pendant le processing — uniquement Inbox.md + les fiches créées

## Voir aussi

- `add-service` (services)
- `add-wiki-concept` (concepts)
- `add-wiki-workflow` (workflows)
- `add-wiki-outil` (skills)
- `expand-stub` (étoffer les stubs créés par cette session)
