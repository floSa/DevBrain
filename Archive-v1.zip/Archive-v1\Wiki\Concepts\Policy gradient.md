---
galaxie: wiki
nom: Policy gradient
alias: [policy gradient, REINFORCE, log-derivative trick, score function estimator, vanilla PG]
type: concept
categorie: concept/ml
sous_categories: [rl, policy-gradient, reinforce, log-derivative-trick, variance-reduction]
domaines: [ml-eng, ai-eng]
maturite: established
auteurs_cles: [Williams 1992 (REINFORCE), Sutton 2000 (PG theorem), Schulman 2015 (TRPO), 2017 (PPO)]
lecture_min: 9
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, rl, policy-gradient]
---

# Policy gradient

## TL;DR

Optimise directement une politique paramétrée $\pi_\theta(a|s)$ par **gradient stochastique** sur l'objectif $J(\theta) = \mathbb{E}_\pi[G_0]$. Algorithme racine : **REINFORCE** ($\nabla J = \mathbb{E}[\nabla \log \pi_\theta(a|s) \cdot G_t]$). Variance énorme → on soustrait une **baseline** (typiquement $V(s)$), on obtient l'**avantage** $A(s,a)$ et un estimateur bien meilleur. Famille moderne : **PPO, TRPO, A2C, SAC, DDPG** — tous variantes de policy gradient. Indispensable pour actions continues, et c'est ce qui est utilisé en **RLHF** (PPO) et **GRPO** (DeepSeek-R1).

## Le problème

Q-learning marche pour actions discrètes mais :
- **Actions continues** : $\max_a Q(s, a)$ est intractable
- **Politiques stochastiques** désirées (exploration naturelle, jeux non-déterministes)
- **Stabilité** : Q-learning peut diverger avec function approximation

→ Optimiser la politique **directement** en tant que fonction paramétrée $\pi_\theta(a|s)$, par gradient sur la performance.

## L'idée

### Objectif et théorème du policy gradient

On veut maximiser :

$$ J(\theta) = \mathbb{E}_{\tau \sim \pi_\theta} \left[\sum_{t=0}^{T} \gamma^t r_{t+1}\right] $$

**Théorème du policy gradient** (Sutton 2000) :

$$ \nabla_\theta J(\theta) = \mathbb{E}_{\tau \sim \pi_\theta} \left[ \sum_{t=0}^{T} \nabla_\theta \log \pi_\theta(a_t | s_t) \, Q^{\pi_\theta}(s_t, a_t) \right] $$

**Remarquable** : aucune dérivée du modèle de transition $P$ ni de la récompense $R$ n'apparaît. On peut donc l'estimer **sans connaître le MDP**, juste en échantillonnant.

### Le log-derivative trick

Comment passer d'une espérance impossible à dériver à un gradient échantillonnable ? Astuce classique :

$$ \nabla_\theta \mathbb{E}_{a \sim \pi_\theta}[f(a)] = \mathbb{E}_{a \sim \pi_\theta}[ f(a) \, \nabla_\theta \log \pi_\theta(a) ] $$

C'est ce qu'on appelle aussi **score function estimator** ou **REINFORCE trick**. Pratique : la politique doit être différentiable (softmax, gaussienne), $f(a)$ peut être un boîte noire (récompense, simulateur).

### REINFORCE (Williams 1992)

Le plus simple des policy gradients :

```
pour chaque épisode :
    échantillonner τ = (s_0, a_0, r_1, s_1, ..., s_T)
    pour chaque t :
        G_t = Σ_{k=t}^{T} γ^{k-t} r_{k+1}
        θ ← θ + α · ∇log π_θ(a_t | s_t) · G_t
```

**Pros** : non biaisé, intuitif. **Cons** : **variance massive** — $G_t$ varie énormément d'un épisode à l'autre.

### Réduction de variance : baseline et avantage

On peut soustraire **n'importe quelle fonction qui ne dépend pas de $a$** sans biais :

$$ \nabla_\theta J = \mathbb{E} \left[ \nabla \log \pi_\theta(a_t | s_t) \, (Q^\pi(s_t, a_t) - b(s_t)) \right] $$

(Démonstration : $\mathbb{E}_a [\nabla \log \pi \cdot b(s)] = b(s) \cdot \nabla \mathbb{E}_a[1] = 0$.)

Le choix optimal de baseline minimise la variance, en pratique on prend $b(s) = V^\pi(s)$ → l'estimateur devient

$$ \nabla_\theta J = \mathbb{E} \big[ \nabla \log \pi_\theta(a_t|s_t) \cdot A^\pi(s_t, a_t) \big] $$

où $A^\pi(s_t, a_t) = Q^\pi - V^\pi$ est l'**avantage** — voir [[Value functions]].

C'est la base de **A2C / A3C** (synchronous / async advantage actor-critic).

### Trust region : TRPO

Naïvement, un pas de gradient sur $\theta$ peut effondrer la performance (les politiques en RL ne sont pas localement linéaires). TRPO (Schulman 2015) impose une **contrainte de divergence KL** entre $\pi_{\theta_{\text{old}}}$ et $\pi_\theta$ :

$$ \max_\theta \mathbb{E}\left[\frac{\pi_\theta(a|s)}{\pi_{\theta_{\text{old}}}(a|s)} A^\pi(s, a)\right] \quad \text{s.t.} \quad \mathbb{E}[\text{KL}(\pi_{\theta_{\text{old}}} \| \pi_\theta)] \le \delta $$

Stable mais lourd (résolution par conjugate gradient + line search).

### PPO — Proximal Policy Optimization (Schulman 2017)

L'**implémentation pragmatique** de TRPO. Remplace la contrainte KL par un **clip** sur le ratio :

$$ \mathcal{L}^{\text{CLIP}}(\theta) = \mathbb{E}_t \left[\min\left(r_t(\theta) \hat A_t, \, \text{clip}(r_t(\theta), 1-\epsilon, 1+\epsilon) \hat A_t \right)\right] $$

où $r_t(\theta) = \pi_\theta(a_t|s_t) / \pi_{\theta_{\text{old}}}(a_t|s_t)$ et $\epsilon \approx 0.2$.

L'idée : si une mise à jour pousse $r_t$ trop loin de 1, on **clippe** l'objectif → le gradient devient nul → on n'avance plus dans cette direction.

PPO est l'algo standard de RL deep depuis 2018. C'est aussi le **PPO de RLHF** (cf. [[RLHF and DPO]]).

### Variantes importantes

- **A2C / A3C** : actor-critic synchrone / asynchrone, baseline $V_\phi(s)$
- **DDPG** : deterministic policy gradient pour actions continues (Silver 2014)
- **TD3** : DDPG + double Q + delayed updates (Fujimoto 2018)
- **SAC** : Soft Actor-Critic, ajoute terme d'entropie pour exploration (Haarnoja 2018)
- **GRPO** : Group Relative Policy Optimization — pas de critic, avantage = écart à la moyenne du *group* (DeepSeek 2024)
- **Reparameterization trick** : pour politiques continues différentiables, $a = \mu_\theta(s) + \sigma_\theta(s) \cdot \epsilon$, gradient pathwise (utilisé dans SAC, VAE)

### Score function vs reparameterization

Deux familles d'estimateurs de gradient stochastique :

| Méthode | Quand | Variance | Biais |
|---|---|:-:|:-:|
| **Score function** (REINFORCE) | $f$ boîte noire, action discrète | haute | 0 |
| **Reparameterization** | $f$ différentiable, action continue gaussienne | basse | 0 |

PPO/REINFORCE utilisent score function (action = sample d'une catégorielle ou gaussienne, on évalue $\log \pi$). SAC utilise reparameterization.

### Entropy regularization

Ajouter $\beta \cdot H[\pi(\cdot|s)]$ à l'objectif **encourage l'exploration** (ne pas s'effondrer sur une seule action). Standard dans PPO et SAC (où c'est central : max-entropy RL).

## Quand c'est utile

- **Actions continues** : robotique, contrôle, finance — Q-learning ne s'applique pas
- **Politiques stochastiques nécessaires** : poker, scissors-paper-stone, exploration naturelle
- **RLHF / DPO / GRPO** : alignement des LLMs — tous variantes de policy gradient
- **Combine bien avec deep nets** : gradient propre, pas de bootstrap si Monte Carlo
- **On-policy** : conceptuellement plus simple à raisonner que Q-learning off-policy
- **Optimisation par préférences** : reward = signal préférentiel, PPO/DPO sont les standards

## Quand ça ne marche pas / pièges

- **Variance énorme sans baseline** : REINFORCE pur ne marche pratiquement pas, toujours utiliser un critic
- **Sample inefficient (on-policy)** : chaque sample n'est utilisé qu'une fois (sauf importance sampling). DQN/SAC plus sample-efficient
- **Step size critique** : un pas trop grand effondre la politique. TRPO/PPO essaient de gérer ça
- **Local minima** : politique converge vers un optimum local "safe" (timide), surtout sans bonus d'entropie
- **Score function pour grandes dimensions d'action** : variance scale en $|\mathcal{A}|$ → preferer reparam
- **Mauvais critic = mauvais avantage = mauvais gradient** : si le critic est mal entraîné, le PG va dans la mauvaise direction
- **PPO clipping mal compris** : un clip à 0.2 ne *limite* pas la KL — c'est un effet de bord, mesurer la KL réelle
- **Importance ratio explosif** : si on réutilise les samples trop longtemps (épochs PPO multiples), $r_t$ devient extrême → instabilité
- **Reward sparse** : si aucun retour positif rencontré, $\nabla J \approx 0$ partout → ajouter shaping / exploration explicite

## Code minimal

```python
# REINFORCE vanilla (PyTorch) — pédagogique
import torch
import torch.nn as nn
import torch.optim as optim
import gymnasium as gym
from torch.distributions import Categorical

env = gym.make("CartPole-v1")
policy_net = nn.Sequential(
    nn.Linear(4, 128), nn.ReLU(),
    nn.Linear(128, 2),
)
opt = optim.Adam(policy_net.parameters(), lr=1e-3)

def reinforce_episode(gamma=0.99):
    obs, _ = env.reset()
    log_probs, rewards = [], []
    done = False
    while not done:
        logits = policy_net(torch.tensor(obs, dtype=torch.float))
        dist = Categorical(logits=logits)
        a = dist.sample()
        log_probs.append(dist.log_prob(a))
        obs, r, term, trunc, _ = env.step(a.item())
        rewards.append(r)
        done = term or trunc

    # Retours cumulés arrière
    G, returns = 0.0, []
    for r in reversed(rewards):
        G = r + gamma * G
        returns.insert(0, G)
    returns = torch.tensor(returns, dtype=torch.float)
    returns = (returns - returns.mean()) / (returns.std() + 1e-8)  # baseline implicite

    loss = -(torch.stack(log_probs) * returns).sum()
    opt.zero_grad(); loss.backward(); opt.step()
    return sum(rewards)

for ep in range(500):
    R = reinforce_episode()
    if ep % 50 == 0:
        print(f"épisode {ep}: retour={R}")
```

```python
# Actor-Critic avec advantage (squelette A2C)
class ActorCritic(nn.Module):
    def __init__(self, obs_dim, n_actions, hidden=128):
        super().__init__()
        self.shared = nn.Sequential(nn.Linear(obs_dim, hidden), nn.ReLU())
        self.actor = nn.Linear(hidden, n_actions)
        self.critic = nn.Linear(hidden, 1)
    def forward(self, x):
        h = self.shared(x)
        return self.actor(h), self.critic(h).squeeze(-1)

# Pour chaque batch (s, a, r, s', done) :
logits, V = model(s)
_, V_next = model(s_next)
target = r + gamma * V_next.detach() * (1.0 - done.float())
advantage = (target - V).detach()

dist = Categorical(logits=logits)
log_pi = dist.log_prob(a)
entropy = dist.entropy().mean()

actor_loss = -(log_pi * advantage).mean()
critic_loss = (V - target).pow(2).mean()
loss = actor_loss + 0.5 * critic_loss - 0.01 * entropy
```

```python
# PPO clipped objective (le cœur de l'algo)
def ppo_loss(log_pi_new, log_pi_old, advantages, eps=0.2):
    ratio = (log_pi_new - log_pi_old).exp()                 # r_t(θ)
    surr1 = ratio * advantages
    surr2 = ratio.clamp(1 - eps, 1 + eps) * advantages
    return -torch.min(surr1, surr2).mean()
```

```python
# Stable-Baselines3 : PPO en 5 lignes (en pratique)
from stable_baselines3 import PPO
import gymnasium as gym

env = gym.make("Pendulum-v1")
model = PPO("MlpPolicy", env, gamma=0.99, gae_lambda=0.95, clip_range=0.2, verbose=1)
model.learn(total_timesteps=500_000)
```

## Pour aller plus loin

- Sutton & Barto, ch. 13 *Policy Gradient Methods*
- Sutton et al., *Policy Gradient Methods for RL with Function Approximation* (NeurIPS 2000) — théorème PG
- Williams, *Simple statistical gradient-following algorithms for connectionist RL* (1992) — REINFORCE
- Schulman et al., *Trust Region Policy Optimization* (ICML 2015) — TRPO
- Schulman et al., *Proximal Policy Optimization Algorithms* (2017) — PPO
- Haarnoja et al., *Soft Actor-Critic* (2018)
- Shao et al., *DeepSeekMath* (2024) — GRPO
- Andrew Ng, *Stanford CS229 — Policy Gradient lecture*
- **Liens internes** : [[Value functions]], [[Bellman equations]], [[Markov Decision Process]], [[Reinforcement learning]], [[RLHF and DPO]], [[Exploration vs exploitation]]
