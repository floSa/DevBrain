---
galaxie: dev
nom: pytest
alias: [pytest]
categorie: tooling/testing
sous_categories: [testing, unit-tests, fixtures, python]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: [unittest (stdlib), nose2, Hypothesis (property-based)]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, testing]
url_officiel: https://pytest.org/
url_docs: https://docs.pytest.org/
url_repo: https://github.com/pytest-dev/pytest
---

# pytest

## Pourquoi
**Le framework de test** Python de fait. Syntaxe simple (`assert` direct), fixtures puissantes, écosystème énorme (pytest-asyncio, pytest-cov, pytest-mock, pytest-benchmark, etc.). Compatible avec tout — unittest, Django, FastAPI.

## Quand l'utiliser
- Tout projet Python qui a des tests (lire : tous)
- Tests unitaires, intégration, e2e
- Property-based testing (avec Hypothesis)
- Tests async ([[FastAPI]] + pytest-asyncio)
- Parameterized tests (`@pytest.mark.parametrize`)
- Snapshot testing (syrupy, pytest-snapshot)

## Quand NE PAS l'utiliser
- Test framework imposé par stack (rare aujourd'hui)
- Stdlib-only project sans dépendances → unittest

## Pièges connus
- **Fixtures scope** : `function` / `class` / `module` / `session` — comprendre quand chaque fixture est recréée
- **Async tests** : `pytest-asyncio` requis. Mark `@pytest.mark.asyncio` ou `asyncio_mode = "auto"` dans config
- **conftest.py** : héritage par dossier, pratique mais piège pour debug
- **Mocking** : `pytest-mock` (`mocker` fixture) ou `unittest.mock` direct
- **Test isolation** : DB fixtures avec rollback (transaction par test) — voir testcontainers
- **Collect order** : pas garanti, donc tests dépendants = bug
- **Warnings → errors** : `filterwarnings = error` dans config pour pas rater warnings

## Liens
- Hypothesis (property-based) : https://hypothesis.readthedocs.io/
- pytest-asyncio : https://pytest-asyncio.readthedocs.io/
- testcontainers (DB tests) : voir Services/Tooling/testcontainers.md
- Docs : https://docs.pytest.org/
- Examples : https://docs.pytest.org/en/stable/example/index.html
