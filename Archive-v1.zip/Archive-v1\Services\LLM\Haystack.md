---
galaxie: dev
nom: Haystack
alias: [haystack, deepset-haystack]
categorie: llm/framework
sous_categories: [rag, pipelines, llm-orchestration]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[LangChain]]", "[[LlamaIndex]]", "[[DSPy]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, rag, pipelines]
url_officiel: https://haystack.deepset.ai/
url_docs: https://docs.haystack.deepset.ai/
url_repo: https://github.com/deepset-ai/haystack
---

# Haystack

## Pourquoi
Framework **pipeline LLM** orienté production par deepset (Allemagne). Concept central : **Pipeline** de Components reliés. Très structuré, type-safe, observable. Moins hype que LangChain mais réputation solide en RAG enterprise. Haystack 2 (2024) = rewrite plus propre.

## Quand l'utiliser
- RAG production avec besoin de traçabilité / observability
- Stack enterprise structuré (vs LangChain DIY)
- Pipelines complexes multi-étapes typés
- deepset Cloud (managed, partner)
- Équipe qui préfère config / YAML pour pipelines

## Quand NE PAS l'utiliser
- Écosystème énorme requis → [[LangChain]] (plus de plugins / integrations)
- RAG vraiment léger → [[LlamaIndex]] (focus retrieval)
- Programmable / optimisation prompts → [[DSPy]]
- Petite scale / proto → SDK direct + Pydantic suffit

## Pièges connus
- **Haystack 1 vs 2** : breaking changes massifs. v1 obsolète, tutos online mélangés
- **Pipelines YAML** : utile pour declaratif mais debug peut être harder
- **Less adopted** : moins de tutos / SO / extensions vs LangChain
- **deepset Cloud lock-in** : possible si tu utilises trop leurs primitives propriétaires
- **Component contract** : strict, parfois verbeux pour des cas simples

## Liens
- [[LangChain]] / [[LlamaIndex]] / [[DSPy]] — alternatives
- [[RAG]] / [[Advanced RAG]] (concepts)
- deepset Cloud : https://www.deepset.ai/
- Docs : https://docs.haystack.deepset.ai/
- GitHub : https://github.com/deepset-ai/haystack
