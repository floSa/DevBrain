---
galaxie: wiki
nom: Context engineering
alias: [prompt caching, long context, lost in the middle, context management]
type: concept
categorie: concept/llm-inference
sous_categories: [context, caching, long-context, llm]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Liu 2023 (lost in middle), Xiao 2023 (StreamingLLM)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, context, caching, inference]
---

# Context engineering

## TL;DR

Gérer **ce qui rentre dans le context window** d'un LLM : token accounting, **prompt caching** (Anthropic/OpenAI/Gemini — réduit coût 50-90%), **compression** (LLMLingua), **conversational memory** (buffer/summary/retrieval), **position effects** (lost-in-the-middle, attention sinks). **Long context patterns** : map-reduce, refine, stuff, hierarchical. Standard 2026 : context **1M+ tokens** disponible mais lost-in-middle, **prompt caching** essentiel pour cost, **structured chunking** pour retrieval. Sans bon context engineering, un app LLM gaspille tokens et perd qualité.

## Le problème

LLMs ont des **context windows** finis (8K → 1M tokens). Coûts :
- **Tokens d'input** (~$1-5 / M tokens)
- **Tokens d'output** (~$5-20 / M tokens)
- **KV cache** mémoire en serving

Comment **optimiser l'usage du context** pour qualité + coût ?

## L'idée

### Token accounting

**Compter avant d'envoyer** :

```python
import tiktoken
enc = tiktoken.encoding_for_model("gpt-4o")
n_tokens = len(enc.encode(prompt))
```

Allouer le budget :
- **System prompt** : fixe
- **Few-shot examples** : optionnel
- **Retrieved context (RAG)** : variable
- **Conversation history** : variable
- **User query** : variable
- **Reserved for output** : 1K-4K typique

Budget = `context_window - sum(above) - safety_margin`.

### Prompt caching (provider-side)

**Innovation 2024** : payer une fois pour cacher un prefix, puis réutiliser cheap.

#### Anthropic prompt caching

- **Explicit** : `cache_control: {"type": "ephemeral"}` sur message blocks
- Cache 5 minutes (TTL court) ou 1h (extended)
- Cache write : 25% plus cher
- Cache read : **10% du prix normal**
- Use case : system prompt + tools + few-shot → cached

#### OpenAI prompt caching

- **Automatic** : detect prefix matches automatiquement (depuis Oct 2024)
- 50% discount sur cache hits
- TTL ~5-10 min

#### Gemini context caching

- **Explicit** : `cachedContents.create()`
- 25% du prix normal sur cache hits
- TTL configurable (1h - 1y)
- Use case : énorme document (PDF) loaded une fois

#### Stratégies prompt caching

1. **Order matters** : mettre **stable prefix d'abord** (system, tools, few-shot), variable **après**
2. **System prompt** = candidat parfait (toujours pareil)
3. **Few-shot examples** : cacher (rarely changes)
4. **RAG context** : cache si même chunks réutilisés (multi-turn sur même doc)
5. **User query** : last (variable, not cached)

Économies typiques en production : **30-80%** sur input cost.

### Compression de context

#### Summarization

Long doc → summary court. Loss de détails mais OK pour high-level.

#### Hierarchical summary

Chapitre 1 → summary 1. Chapitre 2 → summary 2. Summary final = combine. Préserve plus d'info qu'un summary global.

#### LLMLingua / LongLLMLingua (Microsoft)

Compresser prompts en **gardant tokens importants**, supprimer redondants. Train un small model pour scorer importance.

- 5-20x compression
- 1-3% perte de qualité
- Standard pour long context cost reduction

#### Selective context

Pour chaque token, scorer son importance et garder top-X%. Moins agressif que LLMLingua.

### Conversational memory

Pour chat bots :

#### Buffer (rolling)

Garder les N derniers messages. Simple, OK pour court.

#### Window (sliding)

Garder les W derniers tokens.

#### Summary

Résumer ce qui sort de la window dans un "summary memory".

#### Vector retrieval

Embedder chaque message, retriever les plus pertinents pour la requête courante.

#### Knowledge graph

Construire un graph d'entities/relations extraites des conversations.

#### Mem0, Letta, Zep

Solutions packaged : memory automatique pour apps.

### Position effects

#### Lost in the Middle (Liu 2023)

**Observation cruciale** : modèles ont **U-shape attention** sur position. Performance haute en début et fin, basse au milieu.

Implications :
- **Important info au début OU à la fin**, pas au milieu
- **Pour RAG** : top retrieved chunks en début ET en fin
- **Re-rank** pour mettre le best en position 1

#### Attention sinks (StreamingLLM, Xiao 2023)

Premier tokens accaparent de l'attention disproportionnée. Si on les supprime (rolling window), modèle s'effondre.

Solution : **garder les premiers tokens** en sliding window (attention sinks).

#### Order sensitivity

Few-shot examples → **l'ordre** importe. Tester plusieurs permutations.

### Long context patterns

#### Stuff

Tout mettre dans le context, un seul call.

- Simple, marche si fits
- Best quality si modèle gère bien long context
- Cher

#### Map-reduce

```
Split doc → process each chunk → combine results
```

- Parallelizable
- Chaque chunk dans isolation
- Bon pour summarization, extraction

#### Refine

```
result = process(chunk_1)
for chunk in remaining:
    result = refine(result, chunk)
```

- Séquentiel
- Préserve context

#### Hierarchical

Combine map-reduce récursivement (chunks → groupes → globale).

#### Iterative retrieval

Retrieve, generate, retrieve more if needed (cf. Self-RAG, [[Advanced RAG]]).

### Long context evaluation

- **Needle in a Haystack (NIAH)** : insérer une "needle" (fact rare) dans un long doc, vérifier que le modèle le trouve
- **RULER** : multi-needle, retrieval, aggregation tasks
- **LongBench** : bench multi-task long context

**Observation** : modèles annoncent 1M context mais NIAH multi-needle souffre. Toujours évaluer son use case.

### Token-saving tips

1. **Pas de redondance** : ne répétez pas info dans system + user
2. **Compact format** : éviter markdown lourd si pas nécessaire
3. **Truncate examples** : few-shot 3 > 10 si même qualité
4. **Délimiteurs concis** : XML tags `<x>` vs verbose
5. **Strip whitespace** des PDFs / web scrapes
6. **Code minification** parfois acceptable
7. **Cache cache cache** : tout ce qui est stable

### Best practices

1. **Cache d'abord** : économie facile, gros gain
2. **Stable prefix → variable suffix** : ordre pour cache
3. **Re-ranking** retrieved chunks (lost-in-middle)
4. **Map-reduce** pour très long
5. **Tokenizer du modèle** pour count exact
6. **Streaming** pour UX
7. **Monitor token usage** (Langfuse, Helicone)
8. **Compression LLMLingua** si cost critical
9. **Test long context limite** réelle (NIAH custom)
10. **Reserve output budget** : ne pas remplir 100%

## Quand c'est utile

- **Production chat / RAG** : cost reduction massif via cache
- **Long document QA** : Gemini 1M context + cache
- **Multi-turn** : memory engineering
- **Cost-sensitive apps** : compression + cache
- **Agentic loops** : history grows fast, need management
- **Codebase analysis** : whole repo dans context (cache + compression)
- **Few-shot heavy apps** : cache les examples
- **Multi-tenant** : prefix shared across users (cache hit)

## Quand ça ne marche pas / pièges

- **Cache miss patterns** : si prefix change même un peu, cache miss. Stabilité critique.
- **Lost in middle** ignoré : info clé au milieu = ignorée
- **Long context ≠ used context** : modèle ne lit pas vraiment 1M tokens
- **Cache TTL court** : 5 min Anthropic peut expirer entre requests
- **Cache write 25% supplémentaire** : si tu écris sans réutiliser, plus cher
- **Compression agressive** : LLMLingua peut perdre info critique
- **Memory bias** : summary memory amplifie biais de l'agent
- **Order effects** : changer l'ordre des examples = changer perf
- **Token count mismatch** : tiktoken pour OpenAI ≠ tokenizer Anthropic
- **Streaming structured outputs** : pas trivial
- **Reranking ne corrige pas tout** : lost-in-middle persistant
- **Cache pour user-specific data** : pas réutilisable cross-user

## Code minimal

```python
import tiktoken
import anthropic
from openai import OpenAI

# 1. Token counting
def count_tokens(text, model="gpt-4o"):
    enc = tiktoken.encoding_for_model(model)
    return len(enc.encode(text))

print(count_tokens("Hello world"))  # 2

# 2. Anthropic prompt caching (explicit)
client = anthropic.Anthropic()
response = client.messages.create(
    model="claude-3-7-sonnet-latest",
    max_tokens=1024,
    system=[
        {
            "type": "text",
            "text": "You are a helpful assistant with knowledge of...",
            "cache_control": {"type": "ephemeral"}  # Cache this!
        }
    ],
    messages=[{"role": "user", "content": "What is..."}]
)
# Check cache usage
print(response.usage.cache_creation_input_tokens)  # Tokens cached (cher)
print(response.usage.cache_read_input_tokens)     # Tokens read from cache (90% off)

# 3. OpenAI prompt caching (automatic, since Oct 2024)
client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {"role": "system", "content": "Stable system prompt..."},  # Auto-cached on 2nd call
        {"role": "user", "content": "Question"}
    ]
)
print(response.usage.prompt_tokens_details.cached_tokens)

# 4. Conversation memory : sliding window
class WindowMemory:
    def __init__(self, max_tokens=4000):
        self.messages = []
        self.max_tokens = max_tokens
    
    def add(self, message):
        self.messages.append(message)
        # Trim if too long
        while self._token_count() > self.max_tokens:
            self.messages.pop(0)
    
    def _token_count(self):
        return sum(count_tokens(m["content"]) for m in self.messages)

# 5. Summary memory
class SummaryMemory:
    def __init__(self, llm):
        self.summary = ""
        self.llm = llm
    
    def add_turn(self, user_msg, ai_msg):
        new_text = f"User: {user_msg}\nAssistant: {ai_msg}"
        if count_tokens(self.summary + new_text) > 1000:
            # Summarize
            self.summary = self.llm(f"Summarize: {self.summary}\n{new_text}")
        else:
            self.summary += "\n" + new_text

# 6. LLMLingua compression
# from llmlingua import PromptCompressor
# compressor = PromptCompressor()
# compressed = compressor.compress_prompt(long_text, target_token=500)

# 7. Map-reduce pattern (LangChain style, à reproduire à la main)
def map_reduce(chunks, map_fn, reduce_fn):
    summaries = [map_fn(c) for c in chunks]
    while len(summaries) > 1:
        new = []
        for i in range(0, len(summaries), 2):
            pair = summaries[i:i+2]
            new.append(reduce_fn(pair))
        summaries = new
    return summaries[0]

# 8. Re-ranking pour lost-in-middle
def rerank_for_position(chunks, query):
    # Score chaque chunk, mettre les meilleurs aux positions 0 et -1
    scores = [score(c, query) for c in chunks]
    sorted_chunks = [c for _, c in sorted(zip(scores, chunks), reverse=True)]
    # Best en position 0 (et 1 si possible)
    # Worst (déjà retrieved donc utiles) au milieu
    return sorted_chunks

# 9. Needle in a Haystack test (custom)
def niah_test(model, context_len=10000, needle="The secret is 42"):
    haystack = "..." * (context_len - len(needle))
    haystack = haystack[:context_len // 2] + needle + haystack[context_len // 2:]
    answer = model(f"Context: {haystack}\nQuestion: What is the secret?")
    return "42" in answer
```

## Pour aller plus loin

- Liu et al., *Lost in the Middle: How Language Models Use Long Contexts* (TACL 2024)
- Xiao et al., *Efficient Streaming Language Models with Attention Sinks* (ICLR 2024)
- Jiang et al., *LLMLingua: Compressing Prompts for Accelerated Inference of Large Language Models* (EMNLP 2023)
- Anthropic docs: *Prompt Caching*
- OpenAI: *Prompt Caching in the API* (Oct 2024)
- Google: *Context caching in the Gemini API*
- *Needle in a Haystack* (Kamradt) — benchmark and test
- **Liens internes** : [[prompt-caching]], [[Prompt engineering]], [[RAG]], [[Positional encoding]], [[Flash Attention and efficient attention]]
