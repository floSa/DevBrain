---
galaxie: dev
nom: TorchServe
alias: [torchserve]
categorie: ml/serving
sous_categories: [serving, pytorch, mar, model-archive, aws-sagemaker]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python / Java
clients_officiels: [python, http, grpc]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[NVIDIA Triton]]", "[[BentoML]]", "[[Ray Serve]]", "[[vLLM]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, serving, pytorch]
url_officiel: https://pytorch.org/serve/
url_docs: https://pytorch.org/serve/
url_repo: https://github.com/pytorch/serve
---

# TorchServe

## Pourquoi

**Serveur d'inférence officiel PyTorch**, développé par Meta + AWS. Standard pour servir des modèles PyTorch (CV, NLP non-LLM, recsys, ASR) en prod. Format pivot : **MAR** (Model ARchive) — un zip contenant `.pt` + handler Python + config, déployable en une commande.

Différenciateurs : **handlers Python customisables** (pre/post-processing dans le serveur), **batching dynamique** simple, **versioning multi-modèle**, **metrics Prometheus natifs**, **image officielle SageMaker AWS** (intégration deep). Pour LLM serving moderne, **vLLM / TGI / SGLang** sont meilleurs. TorchServe reste pertinent pour **modèles PyTorch non-LLM**.

## Quand l'utiliser

- **PyTorch models en prod non-LLM** : CV (ResNet, YOLO), recsys (DLRM), ASR (Whisper finetuned), NLP small (BERT)
- **Multi-modèle hosting** : un serveur, plusieurs MAR loaded
- **Combo SageMaker** : image officielle TorchServe = serving par défaut SageMaker PyTorch
- **Handlers Python customs** : pre/post-processing complexe dans le serveur
- **Metrics Prometheus natifs** : monitoring out-of-the-box
- **gRPC + REST** exposés en parallèle
- **CPU + GPU** serving avec config simple

## Quand NE PAS l'utiliser

- **LLM transformers** → [[vLLM]] / [[TGI]] / [[SGLang]] (PagedAttention, continuous batching, FP8)
- **Multi-framework** → [[NVIDIA Triton]] / [[BentoML]] / [[KServe]]
- **TensorFlow** → [[TensorFlow Serving]]
- **GPU H100+ ultra-optimisé** → [[NVIDIA Triton]] + [[TensorRT-LLM]]
- **Python-first dev** → [[BentoML]] plus moderne, plus pythonic

## Pièges connus

- **MAR format à comprendre** : `torch-model-archiver` à scripter dans CI
- **Maintenance modeste depuis 2023** : releases plus rares, Meta a déplacé focus vers vLLM/PyTorch foundation
- **Batching primitif vs vLLM** : pas de continuous batching → throughput LLM mauvais
- **Handler Python = SPOF** : un handler buggé crash le worker → tester en local d'abord
- **Java backend** : config JVM (heap size) à tuner si gros throughput
- **Hot reload limité** : possible mais moins propre que TF Serving
- **Doc inégale** : exemples souvent dispersés entre repo et site
- **Config snapshots** : TorchServe garde des `config.properties` snapshots qui peuvent surprendre au restart
- **GPU OOM silencieux** : si batch trop gros, kill du worker sans message clair → tuner `batch_size` et `max_batch_delay`
- **Pas designed pour LLM streaming** : pas de token-by-token natif

## Code minimal

```bash
pip install torchserve torch-model-archiver torch-workflow-archiver

# Package un modele en MAR
torch-model-archiver \
    --model-name resnet18 \
    --version 1.0 \
    --serialized-file resnet18.pt \
    --handler image_classifier \
    --extra-files index_to_name.json \
    --export-path model_store

# Lancer le serveur
torchserve --start \
    --model-store model_store \
    --models resnet18=resnet18.mar \
    --ncs   # no-config-snapshot
```

```python
# Client REST
import requests

with open("kitten.jpg", "rb") as f:
    response = requests.post(
        "http://localhost:8080/predictions/resnet18",
        files={"data": f},
    )
print(response.json())   # [{"tabby": 0.31, "tiger_cat": 0.22, ...}]
```

```python
# Handler custom (handlers/my_handler.py)
import torch
from ts.torch_handler.base_handler import BaseHandler

class MyHandler(BaseHandler):
    def preprocess(self, data):
        # parse input HTTP, return tensor
        raw = data[0].get("body") or data[0].get("data")
        return torch.tensor(raw["features"]).unsqueeze(0).float()

    def inference(self, x):
        with torch.no_grad():
            return self.model(x)

    def postprocess(self, out):
        return [{"score": float(out[0][0]), "label": int(out.argmax(dim=1))}]
```

```bash
# Management API : load/unload modeles a chaud
curl -X POST "http://localhost:8081/models?url=resnet18.mar&initial_workers=2"
curl http://localhost:8081/models                              # liste
curl -X PUT "http://localhost:8081/models/resnet18?min_worker=4"  # scale
curl -X DELETE "http://localhost:8081/models/resnet18"         # unload
```

## Liens

- [[NVIDIA Triton]] — alternative multi-framework, GPU-first
- [[BentoML]] — alternative Python-friendly moderne
- [[Ray Serve]] — alternative distributed Python
- [[vLLM]] / [[TGI]] / [[SGLang]] — pour LLM serving (TorchServe pas adapté)
- [[KServe]] / [[Seldon Core]] — wrappers K8s qui peuvent host TorchServe
- AWS SageMaker — image officielle TorchServe = default PyTorch serving
- Docs : https://pytorch.org/serve/
- GitHub : https://github.com/pytorch/serve
