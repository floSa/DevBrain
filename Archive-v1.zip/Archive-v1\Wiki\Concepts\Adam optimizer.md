---
galaxie: wiki
nom: Adam optimizer (et famille)
alias: [Adam, AdamW, AdaMax, Nadam, Lion, AdaGrad, RMSprop]
type: concept
categorie: concept/optimization
sous_categories: [adam, adamw, adaptive, second-moment, optimizer]
domaines: [ml-eng, ai-eng]
maturite: established
auteurs_cles: [Kingma-Ba 2014 (Adam), Loshchilov-Hutter 2017 (AdamW), Chen et al. 2023 (Lion)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, optimization, adam, optimizer]
---

# Adam optimizer (et famille adaptive)

## TL;DR

**Adam** = SGD + momentum + adaptation du learning rate par paramètre (basée sur moments des gradients). Devient depuis 2014 l'optimizer **par défaut** en deep learning (NLP, CV moderne, LLMs). **AdamW** corrige un bug de l'implé originale sur le weight decay et est aujourd'hui le standard pour les LLMs. **Lion** (2023) est une alternative plus mémoire-efficient. Tous descendent d'**AdaGrad** (2011) → **RMSprop** (2012) → **Adam** (2014).

## Le problème

[[Gradient descent|SGD+momentum]] utilise un **learning rate global** identique pour tous les paramètres. Mais en ML :
- Certains paramètres reçoivent des gradients petits (rare features, biais profonds)
- D'autres reçoivent des gradients énormes (features fréquentes)

Un LR global force à choisir un compromis. Les optimizers **adaptatifs** ajustent automatiquement le LR par paramètre.

## L'idée

### AdaGrad (2011) — l'ancêtre

Accumule les **carrés des gradients passés** par paramètre. Plus un paramètre a vu de gros gradients, plus son LR effectif diminue :

$$ G_t = G_{t-1} + g_t^2 $$
$$ \theta_{t+1} = \theta_t - \frac{\eta}{\sqrt{G_t + \varepsilon}} g_t $$

✅ Bon pour features sparse (NLP avec one-hot)
❌ LR effectif tend vers 0 — convergence prématurée

### RMSprop (Hinton 2012, non publié)

Remplace l'accumulation par **moyenne exponentielle mobile** (EMA) :

$$ G_t = \rho G_{t-1} + (1 - \rho) g_t^2 $$

Avec $\rho \approx 0.99$. LR ne décroît plus à 0 → convergence plus robuste. Toujours utilisé en RNN.

### Adam (2014) — la star

Combine **momentum** (1er moment EMA) ET **adaptation** (2nd moment EMA), avec **correction de biais** :

$$ m_t = \beta_1 m_{t-1} + (1 - \beta_1) g_t \quad \text{(momentum)} $$
$$ v_t = \beta_2 v_{t-1} + (1 - \beta_2) g_t^2 \quad \text{(2nd moment)} $$
$$ \hat m_t = \frac{m_t}{1 - \beta_1^t}, \quad \hat v_t = \frac{v_t}{1 - \beta_2^t} \quad \text{(bias correction)} $$
$$ \theta_{t+1} = \theta_t - \eta \frac{\hat m_t}{\sqrt{\hat v_t} + \varepsilon} $$

Defaults : $\beta_1 = 0.9$, $\beta_2 = 0.999$, $\varepsilon = 10^{-8}$, $\eta = 10^{-3}$.

**Pourquoi ça marche** : adapte le LR par paramètre, robust à différentes échelles de gradient, peu sensible au choix de $\eta$ initial.

### AdamW (2017) — correction du weight decay

Bug d'Adam d'origine : le weight decay (régularisation L2) est intégré **dans le gradient**, ce qui interagit mal avec l'adaptation du LR. AdamW le **découple** :

$$ \theta_{t+1} = \theta_t - \eta \left( \frac{\hat m_t}{\sqrt{\hat v_t} + \varepsilon} + \lambda \theta_t \right) $$

Le terme $\lambda \theta_t$ (decay) est appliqué **après** la normalisation, pas avant.

**Conséquence** : AdamW a une meilleure généralisation, en particulier sur transformers. **Standard pour entraîner tous les LLMs modernes.**

### Lion (Chen et al. 2023)

Découverte par AutoML : utilise uniquement le **signe** du gradient avec momentum, pas de 2nd moment.

$$ u_t = \text{sign}(\beta_1 m_{t-1} + (1 - \beta_1) g_t) $$
$$ \theta_{t+1} = \theta_t - \eta (u_t + \lambda \theta_t) $$
$$ m_t = \beta_2 m_{t-1} + (1 - \beta_2) g_t $$

Avantages :
- **Moitié mémoire** vs AdamW (un seul moment au lieu de deux)
- **Comparable ou meilleur** sur certains transformers
- Plus simple à implémenter et profiler

Inconvénients : moins testé en pratique, parfois instable au début du training (warmup important).

### Autres variantes

- **Nadam** : Adam + Nesterov (gain marginal en pratique)
- **AdaMax** : Adam avec norme L∞ (au lieu de L2) du 2nd moment
- **LARS / LAMB** : optimizers pour très gros batch en distribué
- **Sophia** : approximation Hessien diagonal, plus stable que Adam sur LLMs (2024)

## Quand c'est utile

- **AdamW** : choix par défaut pour LLMs, transformers, NLP moderne
- **Adam** : choix par défaut pour la plupart des problèmes DL hors transformers (vieille habitude — préfère AdamW partout)
- **RMSprop** : RNN traditionnels (LSTM, GRU)
- **AdaGrad** : NLP avec features sparse, embeddings
- **SGD + momentum** : CV avec ImageNet (meilleure généralisation que Adam, mais demande plus de tuning)
- **Lion** : quand mémoire est critique (gros modèles, devices contraints)

## Quand ça ne marche pas / pièges

- **Adam avec L2 dans la loss (sans AdamW)** : weight decay mal appliqué, généralisation dégradée. Toujours utiliser AdamW si tu fais du weight decay.
- **LR Adam trop haut** ($10^{-2}$ ou plus) : divergence. Defaults ($10^{-3}$ à $10^{-4}$) sont presque toujours bons. Sur LLMs : souvent $5 \times 10^{-5}$ à $5 \times 10^{-4}$.
- **Warmup obligatoire** sur transformers : premiers 1000-5000 steps avec LR croissant de 0 au max
- **$\varepsilon$ par défaut $10^{-8}$** peut être trop petit en FP16 → utiliser $10^{-6}$ ou plus en mixed precision
- **Adam vs SGD pour la généralisation** : SGD+momentum souvent **mieux** que Adam sur ImageNet (Wilson et al.). Sur transformers c'est l'inverse. Tester les deux.
- **Memory bandwidth** : Adam stocke 2× les poids en moments → 3× mémoire totale (poids + 2 moments). Lion divise par 2.
- **Switching d'optimizer en cours d'entraînement** : courant en LLM training (warmup AdamW puis cooldown avec autre). Délicat.

## Code minimal

```python
import torch
import torch.optim as optim

model = ...

# Adam classique
opt_adam = optim.Adam(model.parameters(), lr=1e-3)

# AdamW (préféré pour transformers/LLM)
opt_adamw = optim.AdamW(
    model.parameters(),
    lr=5e-5,
    betas=(0.9, 0.95),  # β2=0.95 plus stable pour LLMs que 0.999 default
    weight_decay=0.1,    # decay fort, plus que pour CV
    eps=1e-8,
)

# Avec warmup + cosine schedule
from torch.optim.lr_scheduler import LambdaLR
import math

def warmup_cosine(step, warmup, total):
    if step < warmup:
        return step / warmup
    progress = (step - warmup) / (total - warmup)
    return 0.5 * (1 + math.cos(math.pi * progress))

scheduler = LambdaLR(opt_adamw, lr_lambda=lambda s: warmup_cosine(s, warmup=2000, total=100000))

# Lion (huggingface ou pip install lion-pytorch)
from lion_pytorch import Lion
opt_lion = Lion(model.parameters(), lr=1e-4, weight_decay=1e-2)
```

## Pour aller plus loin

- Kingma & Ba, *Adam: A Method for Stochastic Optimization* (ICLR 2015) — paper canonique
- Loshchilov & Hutter, *Decoupled Weight Decay Regularization* (ICLR 2019) — AdamW
- Chen et al., *Symbolic Discovery of Optimization Algorithms* (2023) — Lion
- *The Marginal Value of Adaptive Gradient Methods* (Wilson et al. 2017) — critique de Adam vs SGD
- **Liens internes** : [[Gradient descent]], [[Newton & quasi-Newton]], [[Learning rate schedules]], [[Regularization]] (weight decay)
