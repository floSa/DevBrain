---
galaxie: wiki
nom: K-means
alias: [k-means clustering, Lloyd's algorithm, k-means++]
type: concept
categorie: concept/ml
sous_categories: [clustering, partitioning, lloyd, centroid, elbow]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Lloyd 1957 (algo), MacQueen 1967 (nom), Arthur-Vassilvitskii 2007 (k-means++)]
lecture_min: 8
created: 2026-05-19
modified: 2026-05-19
tags: [concept, ml, clustering, k-means]
---

# K-means

## TL;DR

Algorithme **simplissime** pour partitionner $n$ points en $K$ clusters. À chaque itération : (1) assigner chaque point au centroïde le plus proche ; (2) recalculer les centroïdes comme moyenne des points assignés. Converge en quelques itérations. **K-means++** = initialisation maline qui évite les mauvais minima locaux. Limité aux clusters **sphériques et de taille similaire**.

## Le problème

Tu as des données non-labelisées et tu veux les **grouper** en $K$ classes : segmentation client, regroupement de docs similaires, compression d'images (quantification), pré-traitement avant supervision.

K-means est l'algo de partition le plus simple et le plus utilisé.

## L'idée

### Algorithme (Lloyd 1957)

Étant donné $K$ et un dataset $X = \{x_1, \dots, x_n\}$ :

1. **Initialiser** $K$ centroïdes $\mu_1, \dots, \mu_K$ (aléatoirement ou par k-means++)
2. **Assigner** chaque point au centroïde le plus proche :

$$ c_i = \arg\min_k \|x_i - \mu_k\|^2 $$

3. **Mettre à jour** les centroïdes comme moyenne des points assignés :

$$ \mu_k = \frac{1}{|\{i : c_i = k\}|} \sum_{i : c_i = k} x_i $$

4. **Répéter** 2-3 jusqu'à convergence (assignations stables)

### Fonction de coût

K-means minimise la **somme intra-cluster des distances au carré** (within-cluster sum of squares, WCSS / inertie) :

$$ J = \sum_{i=1}^n \|x_i - \mu_{c_i}\|^2 $$

Pas de garantie d'optimum global. Solution dépend de l'initialisation → toujours lancer **plusieurs fois** (`n_init=10`).

### K-means++ initialisation

Au lieu d'initialiser au hasard (mauvaise idée), k-means++ choisit les centroïdes initiaux **espacés** :

1. Premier centroïde : tiré uniformément au hasard
2. Suivants : tirés avec probabilité proportionnelle à $d(x, \text{centroïde le plus proche})^2$

Résultat : meilleure convergence, peu de chance de tomber dans un mauvais minimum local. **Par défaut** dans `sklearn.cluster.KMeans`.

### Choix de $K$ — Elbow method

Tracer la WCSS en fonction de $K$ :

```
WCSS
  |\
  | \
  |  \
  |   \___
  |       --___
  |             -----___
  +----|----|----|----|----|--- K
       2    3    4    5    6
            ^
         elbow
```

Le "coude" indique le $K$ optimal : ajouter un cluster supplémentaire ne réduit plus significativement l'inertie.

Alternatives :
- **Silhouette score** : maximise la silhouette moyenne (voir [[Clustering evaluation]])
- **Gap statistic** : compare WCSS à WCSS attendue sous distribution uniforme
- **Domain knowledge** : "on sait qu'il y a ~4 segments"

### Hypothèses implicites

K-means suppose :
- **Clusters sphériques** (distance euclidienne)
- **Tailles similaires** entre clusters
- **Densité uniforme** dans chaque cluster
- **Features standardisées** (sinon les features à grande variance dominent)

Si l'une de ces hypothèses est violée → utiliser [[DBSCAN]], [[GMM]], ou hierarchical clustering.

### Variantes

| Variante | Quand |
|---|---|
| **MiniBatchKMeans** | Grands datasets (>100k points) — fit sur sous-batches, ~10× plus rapide |
| **K-medoids** (PAM) | Distance non-euclidienne, robuste aux outliers |
| **Fuzzy c-means** | Soft assignment (point appartient à plusieurs clusters avec degrés) |
| **Bisecting K-means** | Approche divisive, plus stable |
| **Spherical K-means** | Distance cosinus (texte, embeddings normalisés) |

## Quand c'est utile

- Segmentation client / produit
- Quantification d'images / compression
- Pré-traitement avant ML supervisé (cluster ID comme feature)
- Premier essai de clustering — **toujours essayer K-means d'abord**
- Visualisation après PCA/UMAP (colorier par cluster)

## Quand ça ne marche pas / pièges

- **Clusters non-sphériques** (forme de lune, anneaux) → K-means échoue. Utiliser [[DBSCAN]] ou spectral clustering.
- **Densités très différentes** → mauvais clustering. Utiliser GMM ou DBSCAN.
- **Tailles très inégales** → K-means tend à "voler" des points du gros cluster pour équilibrer
- **Outliers** → tirent les centroïdes. Robuste : K-medoids ou retirer les outliers avant.
- **Pas de standardisation** → si une feature a une variance 1000× supérieure, elle domine. **Toujours** `StandardScaler` avant.
- **K mal choisi** : trop petit → clusters hétérogènes ; trop grand → fragmentation
- **n_init = 1** : risque de mauvais minimum local. Toujours `n_init=10` (ou plus).
- **Données catégorielles** : K-means ne marche pas natif. Utiliser K-modes ou one-hot + K-means (mais distance euclidienne sur dummies = mauvais)

## Code minimal

```python
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt

# Toujours standardiser
X_std = StandardScaler().fit_transform(X)

# Choisir K par elbow
inertias = []
silhouettes = []
for k in range(2, 11):
    km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(X_std)
    inertias.append(km.inertia_)
    silhouettes.append(silhouette_score(X_std, km.labels_))

fig, ax = plt.subplots(1, 2, figsize=(12, 4))
ax[0].plot(range(2, 11), inertias, marker='o'); ax[0].set_title('Elbow')
ax[1].plot(range(2, 11), silhouettes, marker='o'); ax[1].set_title('Silhouette')

# Final
km = KMeans(n_clusters=4, n_init=10, random_state=0).fit(X_std)
labels = km.labels_

# Pour gros dataset
km_big = MiniBatchKMeans(n_clusters=4, batch_size=1000, n_init=10, random_state=0).fit(X_std)
```

## Implémentations concrètes

- `sklearn.cluster.KMeans`, `MiniBatchKMeans`, `KMedoids` (via sklearn-extra)
- `pyclustering` — variantes (Bisecting, X-means, etc.)
- `cuml.KMeans` (RAPIDS) — GPU
- R : `kmeans` base, `cluster::pam` (k-medoids)

## Pour aller plus loin

- Arthur & Vassilvitskii, *k-means++: The Advantages of Careful Seeding* (2007)
- Hastie, Tibshirani, Friedman, *ESL* — chap. 14
- **Liens internes** : [[DBSCAN]] (alternative densité), [[GMM]] (alternative probabiliste), [[Clustering evaluation]], [[HCPC]] (combine PCA + clustering), [[PCA]] (souvent prétraitement avant K-means)
