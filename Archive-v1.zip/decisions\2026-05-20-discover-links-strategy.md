---
galaxie: ai
nom: Strategie de decouverte de wikilinks
type: decision
created: 2026-05-20
tags: [decision, wikilinks, skills, scripts]
---

# Stratégie de découverte de wikilinks

## Contexte

Au fur et à mesure que le vault grandit (300+ fiches), il devient difficile :
1. **À la création d'une fiche** : savoir quels wikilinks ajouter
2. **Sur les fiches existantes** : détecter les liens manquants évidents

Avant : devinette mentale → liens incomplets, voire wikilinks fantômes.

## Décision

Outillage en deux scripts PowerShell, intégrés dans les skills `add-*`.

### 1. `AI/scripts/discover-links.ps1` — Engine de découverte

**Usage avant création** : passer les metadata pressenties.

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/discover-links.ps1 \
    -Title "Adam optimizer" \
    -Categorie "concept/optimization" \
    -Domaines "ml-eng,ai-eng" \
    -SousCategories "optimizer,gradient" \
    -Tags "concept,optimization" \
    -TopN 15
```

**Usage sur fiche existante** : passer le path.

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/discover-links.ps1 \
    -Path "Wiki/Concepts/RAG.md"
```

**Scoring** :

| Critère | Points |
|---|---:|
| Alias exact (titre/alias = titre/alias) | +15 |
| Alias partial (containing) | +8 |
| Même `categorie:` | +10 |
| Même top-level catégorie (concept/* = concept/*) | +4 |
| Par `domaines:` en commun | +4 |
| Par `sous_categories:` en commun | +3 |
| Par `tags:` en commun | +2 |
| Par mot du titre en commun (hors stopwords) | +1 |

Top-N candidats par score décroissant + section "Liens internes" prête à copier-coller.

**Options** :
- `-Galaxie dev|wiki|skills` pour filtrer (utile pour `add-service` qui ne devrait pas linker vers SKILL.md)
- `-TopN N` (défaut 15)

### 2. `AI/scripts/audit-links.ps1` — Détection de liens manquants

Pour chaque fiche du vault, compare ses wikilinks actuels avec les top candidats par score. Reporte les candidats forts non-linkés.

```bash
# Audit complet du vault
powershell -ExecutionPolicy Bypass -File AI/scripts/audit-links.ps1

# Audit ciblé
powershell -File AI/scripts/audit-links.ps1 -Path "Wiki/Concepts/RAG.md"
powershell -File AI/scripts/audit-links.ps1 -Galaxie wiki -MinScore 15
```

Génère `AI/audits/links-audit-YYYY-MM-DD.md` avec, pour chaque fiche, un tableau des liens proposés mais non encore présents.

### 3. Intégration dans les skills

Mise à jour des 5 skills de création :

- `add-wiki-concept` — Étape 7 → `discover-links` avec `-TopN 15`
- `add-wiki-outil` — Étape 7 → idem
- `add-wiki-workflow` — Étape 6 → `-TopN 20` (workflows = cross-galaxy)
- `add-service` — Étape 5 → `-Galaxie dev -TopN 15`
- `add-pattern` — Étape 6 → `-TopN 20`

Pattern uniforme :
1. Lance le script avec les metadata pressentis
2. Présente les top candidats à l'utilisateur (groupés par galaxie/type si pertinent)
3. L'utilisateur sélectionne ceux à garder
4. Insère les wikilinks dans la nouvelle fiche
5. **Reverse linking** (optionnel) : propose d'ajouter la nouvelle fiche en wikilink dans les top fiches existantes

## Conséquences

**Positives** :
- Plus de wikilinks fantômes — le script ne propose que des fiches existantes
- Découverte automatique des connections inattendues (e.g. RAG ↔ Ranking metrics par les tags)
- Audit périodique possible (re-run `audit-links.ps1`)
- Reproductible — pas de devinette mentale

**Négatives** :
- Scoring purement metadata-based — un concept lié sémantiquement mais sans tags partagés peut être manqué
- Pas de similarité d'embedding (futur travail si pertinent : ajouter embedding cosine sur les TL;DR)
- Dépendance à la qualité du frontmatter — les fiches mal tagées sont moins bien matchées

## Évolutions possibles

- **v2** : ajouter une couche embedding (sentence-transformers via Python si dispo) pour capturer la similarité sémantique au-delà des tags
- **Pre-commit hook** : auto-run `audit-links` sur les fiches modifiées et bloquer si liens manquants > seuil
- **Mode batch d'application** : `apply-suggested-links.ps1` qui prend le rapport et applique les liens validés
- **Intégrer aux skills `update-*`** : pas seulement à la création, mais aussi à la mise à jour

## Voir aussi

- `AI/scripts/audit-vault.ps1` — audit général (galaxies, vides, stubs)
- `AI/skills/cross-link/SKILL.md` — skill historique avant scripts (à mettre à jour pour utiliser le script)
