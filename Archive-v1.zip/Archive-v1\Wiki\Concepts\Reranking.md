---
galaxie: wiki
nom: Reranking
alias: [cross-encoder, ColBERT, Cohere Rerank, RankGPT, BGE Reranker]
type: concept
categorie: concept/rag
sous_categories: [reranking, cross-encoder, retrieval, rag]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Nogueira 2019, Khattab 2020 (ColBERT)]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, rag, reranking, retrieval]
---

# Reranking

## TL;DR

**Deuxième étape** d'un retrieval RAG : prendre les **top-N retrieved** (e.g. 50-100), les **scorer plus précisément** avec un modèle dédié, garder le **top-K final** (e.g. 5-10). Familles : **cross-encoders** (Cohere Rerank, Voyage, Jina, BGE, mxbai), **ColBERT** (late interaction multi-vector), **LLM rerankers** (RankGPT, RankZephyr — coûteux mais flexible). Gain typique : **+10-20% NDCG**, surtout sur des corpus larges. Standard moderne : retrieve large (hybrid + N=50) → rerank precise (N=10) → context window. Pattern **"two-stage retrieve-then-rerank"** est de facto chez Cohere, Anthropic, OpenAI.

## Le problème

[[embeddings]] denses (bi-encoder) sont **rapides** mais **moins précis** : ils encodent query et doc indépendamment.

Solution : **cross-encoder** prend **query + doc ensemble** → meilleure interaction sémantique, mais **trop coûteux** pour scorer tout l'index.

→ Pattern hybride : **retrieve cheap, rerank precise**.

## L'idée

### Cross-encoder vs Bi-encoder

#### Bi-encoder (embedding)

```
query → [Encoder] → emb_q
doc   → [Encoder] → emb_d
score = cosine(emb_q, emb_d)
```

- Embeddings calculés indépendamment
- **Cachable** : pré-calcul des doc embeddings
- **Fast** : 1 inference pour query, lookup pour docs
- **Less accurate** : interaction limited

#### Cross-encoder

```
[query + doc] → [Encoder] → score (scalar)
```

- Joint processing
- **No caching** : doit recalculer pour chaque (query, doc) pair
- **Slow** : impossible de scorer 1M docs
- **Plus précis** : meilleure interaction sémantique

### Two-stage retrieval

```
[Query]
  │
  ▼
[Stage 1: Retrieve top-N (N=50-200)]
  │ (bi-encoder + BM25 hybrid)
  ▼
[Stage 2: Rerank top-K (K=5-20)]
  │ (cross-encoder, sur les N candidats)
  ▼
[Final top-K → context window]
```

### Solutions de rerankers

#### Cross-encoders open-source

- **BGE Reranker** (large, v2-m3, v2.5) : BAAI, multilingue, performant
- **bge-reranker-v2-m3** : Multi-3 multilingue
- **mxbai-rerank-large-v1** : Mixedbread, open, fort
- **Jina Reranker v1, v2** : commercial-friendly
- **sentence-transformers/ms-marco-MiniLM** : léger, classique

Utiliser via `sentence_transformers` ou `transformers`.

#### Cross-encoders API

- **Cohere Rerank v3** : standard, multilingue, $1/1K queries
- **Voyage Rerank** : compétitif, focus retrieval
- **Jina Reranker** : API + open

#### ColBERT / ColBERTv2

Multi-vector : chaque token de doc a son embedding, similarity = max-sim sur tokens.

- **Mieux que bi-encoder**, **moins cher que cross-encoder**
- Standard pour grande échelle
- ColPali pour vision documents

#### LLM rerankers

**RankGPT** (Sun 2023), **RankZephyr**, **RankT5** : utiliser un LLM directement pour ordonner :

```
"Given query: 'X', rank these passages: [A, B, C, D]. Output: BCAD"
```

- Très flexible, prompt-engineerable
- **Très cher** (1 LLM call par batch de docs)
- Bonnes perfs sur reasoning-heavy queries

#### Setwise reranking

LLM rerank top-K en **set** (vs pairwise), plus efficient.

### Comparaison

| Méthode | Latency / query | Cost | Quality | Use case |
|---|---|---|---|---|
| Bi-encoder seul | ms | $ | OK | first stage |
| BM25 + dense | ms | $ | better | first stage hybrid |
| ColBERT | 10-50ms | $$ | very good | retrieval + rerank fusion |
| Cross-encoder (BGE, mxbai) | 50-500ms / batch | $$ | very good | standard rerank |
| Cohere Rerank API | 200-500ms | $$ | excellent | managed rerank |
| LLM reranker | 1-5s | $$$$ | best | hard queries, niche |

### Quand reranker

**Toujours** quand :
- Retrieval recall@N est bon mais precision@K mauvaise
- Corpus large (>100K docs)
- Budget acceptable

**Skip** si :
- Latency-critical (chat real-time avec petit corpus)
- Budget très contraint
- Bi-encoder déjà suffit (small high-quality corpus)

### Choisir top-N pour rerank

- **N trop petit** (10) : bons docs filtrés avant rerank
- **N trop grand** (500) : latency rerank explose
- **Sweet spot** : 50-100, parfois 200

Tradeoff recall (large N) vs latency (small N).

### Best practices

1. **Always rerank** en production (sauf latency critique)
2. **N=50 first stage, K=5-10 final** : standard
3. **Hybrid first stage** (BM25 + dense) → rerank
4. **Cohere v3 ou BGE-v2-m3** : safe defaults
5. **Eval reranker** sur ton domain (varies a lot)
6. **Batch les rerank calls** : amortir overhead
7. **Cache reranker scores** si query similaires fréquentes
8. **ColBERT** si corpus large + budget storage
9. **LLM reranker** seulement si justified (reasoning queries)
10. **Mesurer NDCG@K** ([[Ranking metrics]]) avant / après rerank

## Quand c'est utile

- **Tout RAG production** : amélioration gratuite presque
- **Search engines** : standard chez Google, Bing
- **Code search** : queries complexes
- **E-commerce search** : intent + keywords
- **Legal / scientific** : precision crucial
- **Multi-step reasoning** : LLM reranker capture context
- **Multilingue** : BGE-v2-m3 fort
- **Vision RAG** : ColPali rerank

## Quand ça ne marche pas / pièges

- **Reranker out-of-domain** : Cohere trained général, peut être mauvais sur ton domaine spécifique
- **Latency budget tight** : rerank ajoute 200-500ms
- **N trop élevé** : rerank devient bottleneck
- **Reranker hallucinates relevance** : LLM rerankers peuvent inverser scores aléatoirement
- **Confusion bi vs cross** : utiliser un bi-encoder comme reranker ne change rien
- **Trop de re-ranking layers** : retrieve → rerank → rerank → diminishing returns
- **Cohere API latency variable** : tail latency à monitorer
- **Eval bias** : test sur ground truth qui a été utilisé pour train le reranker
- **ColBERT storage** : 100x plus de storage que bi-encoder
- **Cost LLM reranker** : exploser le budget si pas surveillé

## Code minimal

```python
# 1. BGE Reranker (open-source, standard)
from sentence_transformers import CrossEncoder

reranker = CrossEncoder("BAAI/bge-reranker-v2-m3")

query = "What is machine learning?"
docs = ["ML is a subset of AI...", "Cooking pasta requires...", "Neural networks are..."]

pairs = [[query, d] for d in docs]
scores = reranker.predict(pairs)
ranked = sorted(zip(docs, scores), key=lambda x: -x[1])
for doc, score in ranked:
    print(f"{score:.3f} - {doc[:50]}")

# 2. Cohere Rerank API
import cohere
co = cohere.Client(api_key="...")

response = co.rerank(
    query="What is machine learning?",
    documents=docs,
    top_n=3,
    model="rerank-v3.5"  # or "rerank-multilingual-v3.0"
)
for r in response.results:
    print(f"{r.relevance_score:.3f} - {docs[r.index][:50]}")

# 3. ColBERTv2 (open-source)
# from ragatouille import RAGPretrainedModel
# RAG = RAGPretrainedModel.from_pretrained("colbert-ir/colbertv2.0")
# RAG.index(collection=docs, index_name="my_index")
# results = RAG.search(query="What is ML?", k=10)

# 4. mxbai-rerank
from sentence_transformers import CrossEncoder
mxbai = CrossEncoder("mixedbread-ai/mxbai-rerank-large-v1")
scores = mxbai.predict([[query, d] for d in docs])

# 5. Voyage Rerank
# import voyageai
# vo = voyageai.Client()
# response = vo.rerank(query=query, documents=docs, model="rerank-2", top_k=3)

# 6. LLM reranker (RankGPT-style)
import anthropic
client = anthropic.Anthropic()

def llm_rerank(query, docs):
    docs_str = "\n".join([f"[{i+1}] {d[:200]}" for i, d in enumerate(docs)])
    response = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=100,
        messages=[{
            "role": "user",
            "content": f"""Rank these passages by relevance to query.
Query: {query}

Passages:
{docs_str}

Output the IDs in order of relevance, e.g. "[3] [1] [2]" """
        }]
    )
    # Parse the output to get order
    return response.content[0].text

# 7. Pipeline complet (retrieve + rerank)
def rag_with_rerank(query, vector_db, reranker, top_n=50, top_k=5):
    # Stage 1 : retrieve top-N
    candidates = vector_db.search(query, k=top_n)
    
    # Stage 2 : rerank top-K
    docs = [c.content for c in candidates]
    pairs = [[query, d] for d in docs]
    scores = reranker.predict(pairs)
    
    # Sort and return top-K
    reranked = sorted(zip(candidates, scores), key=lambda x: -x[1])[:top_k]
    return [c for c, _ in reranked]

# 8. Eval reranker (NDCG@K, MRR)
def eval_reranker(eval_set, reranker):
    from sklearn.metrics import ndcg_score
    ndcgs = []
    for query, candidates, gold_relevances in eval_set:
        pairs = [[query, d] for d in candidates]
        scores = reranker.predict(pairs)
        ndcgs.append(ndcg_score([gold_relevances], [scores], k=10))
    return sum(ndcgs) / len(ndcgs)

# 9. Cohere multilingue
# response = co.rerank(query=query_fr, documents=docs_mixed_lang,
#                       model="rerank-multilingual-v3.0")
```

## Pour aller plus loin

- Nogueira, Cho, *Passage Re-ranking with BERT* (2019) — pionnier
- Khattab, Zaharia, *ColBERT: Efficient and Effective Passage Search via Contextualized Late Interaction over BERT* (SIGIR 2020)
- Santhanam et al., *ColBERTv2* (NAACL 2022)
- Sun et al., *Is ChatGPT Good at Search? Investigating Large Language Models as Re-Ranking Agents* (RankGPT, EMNLP 2023)
- Pradeep et al., *RankVicuna, RankZephyr* (2023) — open LLM reranker
- *Cohere Rerank* documentation
- *BGE-reranker* (BAAI) GitHub
- *Reranker benchmarks*: BEIR, MTEB reranking subset
- **Liens internes** : [[RAG]], [[Advanced RAG]], [[Hybrid retrieval]], [[Ranking metrics]], [[embeddings]]
