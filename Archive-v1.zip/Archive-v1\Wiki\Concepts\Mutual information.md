---
galaxie: wiki
nom: Mutual information
alias: [information mutuelle, MI, NMI, AMI]
type: concept
categorie: concept/info-theory
sous_categories: [mutual-information, dependency, feature-selection, clustering-eval]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Shannon 1948]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, info-theory, mutual-information]
---

# Mutual information — information mutuelle

## TL;DR

Mesure la **dépendance statistique** entre deux variables $X$ et $Y$. Réponse à la question : "combien d'info sur $Y$ est-ce que je gagne en observant $X$ ?" Vaut 0 ssi $X \perp Y$ (indépendance). **Capture des relations non-linéaires** (contrairement à la corrélation Pearson qui est linéaire uniquement). Utilisée en feature selection, clustering eval ([[Clustering evaluation|NMI/AMI]]), réseaux de neurones (Information Bottleneck).

## Le problème

La **corrélation de Pearson** mesure la dépendance **linéaire** entre deux variables. Insuffisant :

- $Y = X^2$ avec $X \sim \mathcal{N}(0, 1)$ → corrélation = 0, alors qu'on a dépendance parfaite
- Variables catégorielles : pas de corrélation Pearson applicable directement
- Relations en U, sinusoïdales, par paliers : Pearson rate

On veut une mesure **universelle** de dépendance, capable de capter n'importe quelle forme.

## L'idée

### Définition

$$ I(X; Y) = \sum_{x, y} p(x, y) \log \frac{p(x, y)}{p(x) p(y)} = D_{\text{KL}}\big(p(x, y) \| p(x) p(y)\big) $$

C'est la [[KL divergence]] entre la distribution **jointe** réelle et le **produit des marginales** (qui serait la jointe sous indépendance).

### Propriétés

- **Symétrique** : $I(X; Y) = I(Y; X)$
- **Non-négative** : $I(X; Y) \geq 0$
- **Zéro ssi $X \perp Y$** : indépendance parfaite
- **Lien avec entropie** :

$$ I(X; Y) = H(X) - H(X|Y) = H(Y) - H(Y|X) = H(X) + H(Y) - H(X, Y) $$

Intuition : $I(X; Y)$ = réduction d'incertitude sur $X$ après avoir observé $Y$.

### Versions normalisées

L'info mutuelle n'est pas bornée à $[0, 1]$, ce qui complique les comparaisons. Versions normalisées :

- **NMI (Normalized Mutual Information)** :

$$ \text{NMI}(X, Y) = \frac{I(X; Y)}{\sqrt{H(X) \cdot H(Y)}} \in [0, 1] $$

- **AMI (Adjusted MI)** : ajuste pour le hasard, $\text{AMI} \in [0, 1]$ avec 0 si tirage aléatoire

Très utilisées en évaluation de clustering (vs ground truth).

### Estimation

**Cas discret** : compter les co-occurrences, calculer les estimateurs naïfs (biaisés sur petit $N$).

**Cas continu** : non trivial.
- **Histogramme** : binning, simple mais sensible au choix de bins
- **KNN** : Kraskov estimator (KSG), efficace en haute dim
- **MINE** (Mutual Information Neural Estimation, 2018) : neural network qui maximise un lower bound

### Variantes / extensions

- **Conditional MI** : $I(X; Y | Z)$ — dépendance entre $X$ et $Y$ sachant $Z$. Utile pour controler des confondeurs.
- **Multi-information / total correlation** : généralisation à $> 2$ variables
- **InfoGAN, MINE** : utiliser MI comme loss en deep learning (encourager certaines features à être informatives)

## Quand c'est utile

- **Feature selection non-linéaire** : `sklearn.feature_selection.mutual_info_classif/regression` mesure MI entre features et target, capte non-linéarités
- **Évaluation de clustering** ([[Clustering evaluation|NMI / AMI]]) vs ground truth
- **Image registration** : aligner deux images via maximisation de MI (très utilisée en imagerie médicale)
- **Information bottleneck** : régulariser un réseau pour qu'il préserve l'info pertinente et compresse le reste
- **InfoNCE loss** : base du contrastive learning (CLIP, SimCLR)
- **Détection de redondance** entre features
- **Causalité** (indices, pas preuve directe — utilisé en transfer entropy)

## Quand ça ne marche pas / pièges

- **Estimation continue** : très bruitée sur petit $N$. Toujours rapporter avec IC bootstrap.
- **Curse of dimensionality** : MI en haute dim difficile à estimer fiablement (>10 dim → problématique sans MINE)
- **Pas une distance** : pas de notion d'ordonnance "X est plus dépendant de Y₁ que de Y₂" sans normalisation
- **Discrétisation arbitraire** : si tu bin un signal continu, le choix de bins change la MI. Préférer KSG ou MINE.
- **NMI sans correction** d'aléatoire : préférer AMI quand on compare des partitions
- **Confusion avec corrélation** : MI = 0 ne implique pas Pearson = 0 et vice versa (en général). Toujours regarder les deux.

## Code minimal

```python
import numpy as np
from sklearn.feature_selection import mutual_info_regression, mutual_info_classif
from sklearn.metrics import normalized_mutual_info_score, adjusted_mutual_info_score
from scipy.stats import entropy

# Feature selection — sklearn (KNN estimator pour continu)
mi_scores = mutual_info_regression(X, y, random_state=0)
# Trier features par MI décroissante

# Cas discret pur (variables catégorielles)
# Comme corrélation mais non-linéaire
ami = adjusted_mutual_info_score(labels_true, labels_pred)
nmi = normalized_mutual_info_score(labels_true, labels_pred)

# Implémentation manuelle pour X, Y discrètes
def mi_discrete(x, y, base=2):
    from sklearn.feature_extraction.text import CountVectorizer
    from collections import Counter
    
    joint = Counter(zip(x, y))
    n = len(x)
    px = Counter(x)
    py = Counter(y)
    
    mi = 0
    for (xi, yi), n_xy in joint.items():
        p_xy = n_xy / n
        p_x = px[xi] / n
        p_y = py[yi] / n
        if p_xy > 0:
            mi += p_xy * np.log(p_xy / (p_x * p_y)) / np.log(base)
    return mi

# Test sur Y = X**2 (non-linéaire)
np.random.seed(0)
X = np.random.randn(1000).reshape(-1, 1)
Y = X.ravel() ** 2
print(f"MI(X, X²) = {mutual_info_regression(X, Y)[0]:.3f}")  # > 0
print(f"Pearson(X, X²) = {np.corrcoef(X.ravel(), Y)[0,1]:.3f}")  # ≈ 0
```

## Pour aller plus loin

- Cover & Thomas, *Elements of Information Theory* — chap. 2 et 4
- Kraskov, Stögbauer, Grassberger, *Estimating mutual information* (2004) — KSG estimator
- Belghazi et al., *MINE: Mutual Information Neural Estimation* (2018)
- Tishby & Zaslavsky, *Deep Learning and the Information Bottleneck Principle* (2015)
- **Liens internes** : [[Shannon entropy]], [[KL divergence]], [[Clustering evaluation]] (NMI/AMI)
