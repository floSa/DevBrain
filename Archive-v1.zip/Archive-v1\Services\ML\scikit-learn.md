---
galaxie: dev
nom: scikit-learn
alias: [sklearn, scikit-learn]
categorie: ml/framework
sous_categories: [classical-ml, supervised, unsupervised, pipelines]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python (Cython core)
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[XGBoost]]", "[[LightGBM]]", "[[CatBoost]]", "[[PyTorch]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ml, framework, classical-ml]
url_officiel: https://scikit-learn.org/
url_docs: https://scikit-learn.org/stable/user_guide.html
url_repo: https://github.com/scikit-learn/scikit-learn
---

# scikit-learn

## Pourquoi
La référence pour le **ML classique** Python : régression, classification, clustering, PCA, preprocessing, pipelines, model selection. API homogène (`fit`/`predict`/`transform`), excellente doc, intégrations partout. Le défaut quand le DL n'est pas requis.

## Quand l'utiliser
- ML supervisé/non-supervisé tabulaire
- Baselines et benchmarks
- Preprocessing pipelines avec [[pandas]] / [[Polars]]
- Petits-moyens datasets (jusqu'à quelques GB / millions de lignes)
- Cross-validation et hyperparameter search basique
- Modèles "explicables" (linear, tree-based)

## Quand NE PAS l'utiliser
- Deep Learning → [[PyTorch]], [[HuggingFace]] Transformers
- Gradient boosting state-of-the-art → [[XGBoost]], [[LightGBM]], [[CatBoost]] (souvent déjà via wrappers compatibles sklearn API)
- Très grand volume → Spark MLlib, Dask-ML
- Production serving avec features online complexes → archi dédiée

## Pièges connus
- **`fit_transform` sur train, `transform` sur test** : à respecter pour éviter data leakage
- **Pipeline + ColumnTransformer** : à maîtriser dès qu'on a du mixed-type
- **`random_state`** : à fixer partout pour reproductibilité
- **Métriques scoring** : `neg_log_loss`, `neg_mean_squared_error` (signe inversé) — surprend
- **Sparse matrices** : certains estimateurs les exigent, pandas DataFrames non
- **Versions** : 1.x stable, mais quelques deprecations à surveiller

## Liens
- [[XGBoost]], [[LightGBM]], [[CatBoost]] — gradient boosting (alternatives + compat API)
- [[Optuna]] — hyperopt avec wrapper sklearn
- [[MLflow]] — tracking des expériences
- [[pandas]], [[numpy]] — entrées typiques
- Choosing the right estimator : https://scikit-learn.org/stable/machine_learning_map.html
