---
galaxie: dev
nom: Semantic Kernel
alias: [semantic-kernel, sk]
categorie: llm/framework
sous_categories: [agent, framework, microsoft, dotnet, python, orchestration]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: C# / Python / Java
clients_officiels: [python, dotnet, java]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[LangChain]]", "[[LlamaIndex]]", "[[AutoGen]]", "[[DSPy]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, framework, microsoft, agent, orchestration]
url_officiel: https://learn.microsoft.com/en-us/semantic-kernel/
url_docs: https://learn.microsoft.com/en-us/semantic-kernel/
url_repo: https://github.com/microsoft/semantic-kernel
---

# Semantic Kernel

## Pourquoi

Framework d'orchestration LLM **Microsoft**, conçu enterprise-first. Construit autour de trois concepts : **Kernel** (le hub central), **Plugins** (fonctions natives ou prompt callables par LLM) et **Planners** (génération automatique de pipelines multi-étapes). SDK multi-langage : **C# natif** (référence), Python et Java suivent.

Positionnement : équivalent **LangChain mais orienté .NET / Azure**. Plus opinionated, moins de moving parts que LangChain, intégrations Microsoft Graph / Cosmos DB / Azure OpenAI / Azure AI Search natives. Si ta stack est Microsoft, c'est le choix par défaut. Sinon, LangChain / LlamaIndex restent plus matures côté Python.

## Quand l'utiliser

- **Stack .NET / C#** : intégration LLM dans une codebase ASP.NET, Blazor, Azure Functions
- **Combo Azure** : Azure OpenAI + Azure AI Search + Cosmos DB + Microsoft Graph
- **Agents Microsoft 365** : plugins natifs Outlook, Teams, SharePoint, OneDrive
- **Architecture entreprise** : opinionated, conventions claires, plus carré que LangChain
- **Multi-langage équipe** : besoin C#/Python/Java parlant le même SDK
- **Process Framework** : workflows multi-agents stateful (équivalent LangGraph)
- **Combo [[AutoGen]]** : SK pour orchestration, AutoGen pour multi-agent

## Quand NE PAS l'utiliser

- **Stack Python pure** → [[LangChain]], [[LlamaIndex]], [[DSPy]] plus matures et plus actifs
- **Pas d'écosystème Microsoft** → autres frameworks ont plus d'intégrations
- **Frameworks-fatigue** : équivalent LangChain → préférer code direct via SDK officiels
- **RAG-only** → [[LlamaIndex]] plus spécialisé
- **Multi-LLM provider exotique** : SK couvre OpenAI, Azure, HuggingFace, Mistral mais reste centré OpenAI-compat
- **Prototype rapide** : LangChain plus rapide à bootstrapper côté Python

## Pièges connus

- **Doc Python en retard sur .NET** : exemples et features arrivent d'abord en C#
- **API instable** : breaking changes fréquents entre versions (v0.x → v1.x → ...). Lock ta version
- **Concepts à apprendre** : Kernel, Plugins, Planners, Memory, Filters → courbe initiale
- **Planners deprecated** : ancien système Planners (Sequential, Stepwise) → migrer vers **function calling** natif des LLMs
- **Memory abstractions** : refactor en cours, parfois 2-3 manières de faire la même chose
- **Lock-in Microsoft modéré** : pas vraiment lock-in code mais documentation/exemples assument Azure
- **Python SDK moins fluent** : C# bénéficie des attributs natifs, Python utilise décorateurs verbeux
- **Process Framework jeune** : alternative à LangGraph mais moins mature, moins de retours
- **Examples-driven** : beaucoup d'exemples notebook, peu de production patterns documentés

## Code minimal

```bash
pip install semantic-kernel
# Ou C#
dotnet add package Microsoft.SemanticKernel
```

```python
# Kernel + Azure OpenAI + plugin natif
import asyncio
from semantic_kernel import Kernel
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion
from semantic_kernel.functions import kernel_function
from semantic_kernel.connectors.ai.function_choice_behavior import FunctionChoiceBehavior
from semantic_kernel.contents import ChatHistory

# Plugin natif (function calling)
class WeatherPlugin:
    @kernel_function(description="Get the current weather for a city.")
    def get_weather(self, city: str) -> str:
        # Faux API pour l'exemple
        return f"Il fait 18C et nuageux a {city}."

async def main():
    kernel = Kernel()
    kernel.add_service(AzureChatCompletion(
        service_id="chat",
        deployment_name="gpt-4o",
        endpoint="https://<your>.openai.azure.com/",
        api_key="<KEY>",
    ))
    kernel.add_plugin(WeatherPlugin(), plugin_name="weather")

    chat = kernel.get_service("chat")
    settings = chat.instantiate_prompt_execution_settings(service_id="chat")
    settings.function_choice_behavior = FunctionChoiceBehavior.Auto()

    history = ChatHistory()
    history.add_user_message("Quel temps fait-il a Paris ?")

    response = await chat.get_chat_message_content(
        chat_history=history, settings=settings, kernel=kernel,
    )
    print(response.content)

asyncio.run(main())
```

```python
# Prompt function (template Jinja-like)
from semantic_kernel.functions import KernelArguments

summarize = kernel.add_function(
    plugin_name="text",
    function_name="summarize",
    prompt="Resume en 3 puces le texte suivant :\n{{$input}}",
)

result = await kernel.invoke(summarize, KernelArguments(input=long_text))
print(result)
```

## Liens

- [[LangChain]] / [[LlamaIndex]] / [[DSPy]] — alternatives Python plus matures
- [[AutoGen]] — autre Microsoft (multi-agent, complémentaire)
- [[Azure OpenAI]] — combo naturel
- [[LangGraph]] — équivalent du Process Framework
- Docs : https://learn.microsoft.com/en-us/semantic-kernel/
- GitHub : https://github.com/microsoft/semantic-kernel
- Cookbook Python : https://github.com/microsoft/semantic-kernel/tree/main/python/samples
