---
galaxie: dev
nom: Shiny for Python
alias: [shiny, shiny-python, py-shiny]
categorie: ui/dashboard
sous_categories: [dashboard, reactive, posit, python, web-app]
licence: MIT
licence_type: open-source
hosted: self ou cloud (Posit Connect / shinyapps.io)
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[Streamlit]]", "[[Gradio]]", "[[Dash]]", "Panel", "Solara"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ui, dashboard, python, reactive]
url_officiel: https://shiny.posit.co/py/
url_docs: https://shiny.posit.co/py/
url_repo: https://github.com/posit-dev/py-shiny
---

# Shiny for Python

## Pourquoi

Port Python de **Shiny R** (Posit, ex-RStudio). Modèle **réactif** explicite : tu déclares des `@reactive.calc` et `@render.*` qui re-calculent automatiquement quand leurs inputs changent. Plus structuré que [[Streamlit]] (script-rerun), philosophiquement proche de [[Dash]] mais avec un graphe réactif plus fin (réactivité par valeur, pas par callback).

Cible : (1) **équipes data avec background R/Shiny** qui migrent vers Python, (2) **apps réactives complexes** où la finesse du graphe réactif compte, (3) stack Posit (Posit Connect / Workbench / shinyapps.io). Plus jeune que Shiny R (1.0 mid-2023) mais maturité solide en 2026.

## Quand l'utiliser

- **Background R / Shiny** : migration Python familière (API quasi-identique)
- **Apps réactives complexes** : graphes dynamiques, dépendances fines, debounce
- **Stack Posit** : déploiement Posit Connect / shinyapps.io / Workbench intégré
- **Modèle réactif explicite préféré** à un script Streamlit linéaire
- **Modules réutilisables** : `Shiny module` pour componentiser
- **Streaming UI Outputs** : `@render.text`, `@render.plot`, `@render.table`, `@render.ui`
- **Shinylive** : déploiement WASM (browser-only, sans serveur) pour démos
- **Combo Quarto** : intégration native dans docs Quarto

## Quand NE PAS l'utiliser

- **Quick prototype < 50 lignes** → [[Streamlit]] / [[Gradio]] plus rapides à bootstrapper
- **Pas familier Shiny** : courbe d'apprentissage du modèle réactif (réactivité par valeur)
- **Communauté énorme requise** : Streamlit / Gradio ont plus de momentum côté Python
- **LLM / Chat UI** → [[Gradio]] / Chainlit (composants chat natifs)
- **Multi-page complexe** : Shiny Express simplifie mais pas aussi propre que Dash Pages
- **Posit lock-in à éviter** : déploiement Posit Connect = payant

## Pièges connus

- **Plus jeune que Shiny R** : certaines features R manquent encore (modules nested, certains widgets)
- **Doc parfois R-centric** : tutoriels traduits de R, exemples portés
- **Posit Connect managed payant** : déploiement gratuit sur shinyapps.io limité (sleep après inactivité)
- **Deux API : Express vs Core** : Express (script-style, 2024+) plus simple ; Core (ui.page / server function) plus puissant — choisir tôt
- **Réactivité par valeur** : `input.x()` (avec parenthèses) — oublier les `()` est une erreur classique
- **Isolation requise** parfois : `with reactive.isolate(): ...` pour éviter dépendances réactives non-voulues
- **Pas de hot-reload aussi smooth** que Streamlit (mais existe : `--reload`)
- **Async support** : possible mais plus subtil que Dash
- **Composants tiers** moins nombreux que Streamlit / Dash
- **Bundle size Shinylive WASM** lourd : 30-100 Mo pour app standalone navigateur

## Code minimal

```bash
pip install shiny
# Lancer
shiny run app.py --reload
```

```python
# app.py : Shiny Express (style script, 2024+)
from shiny.express import input, render, ui
import seaborn as sns
import matplotlib.pyplot as plt

ui.page_opts(title="Tips Explorer", fillable=True)

with ui.sidebar():
    ui.input_slider("min_bill", "Min total bill", 0, 50, 10)
    ui.input_select("day", "Day", choices=["Thur", "Fri", "Sat", "Sun"])

@render.plot
def scatter():
    tips = sns.load_dataset("tips")
    sub = tips[(tips["total_bill"] >= input.min_bill()) & (tips["day"] == input.day())]
    fig, ax = plt.subplots()
    sns.scatterplot(data=sub, x="total_bill", y="tip", hue="sex", ax=ax)
    return fig

@render.text
def summary():
    tips = sns.load_dataset("tips")
    sub = tips[(tips["total_bill"] >= input.min_bill()) & (tips["day"] == input.day())]
    return f"{len(sub)} rows | mean tip = {sub['tip'].mean():.2f}"
```

```python
# Style "Core" classique : ui + server function
from shiny import App, ui, render, reactive

app_ui = ui.page_fluid(
    ui.h1("Counter app"),
    ui.input_action_button("inc", "Increment"),
    ui.input_action_button("reset", "Reset"),
    ui.output_text("count"),
)

def server(input, output, session):
    counter = reactive.value(0)

    @reactive.effect
    @reactive.event(input.inc)
    def _():
        counter.set(counter.get() + 1)

    @reactive.effect
    @reactive.event(input.reset)
    def _():
        counter.set(0)

    @render.text
    def count():
        return f"Count: {counter.get()}"

app = App(app_ui, server)
```

```python
# Reactive calc : mise en cache + dependance auto
from shiny import reactive

@reactive.calc
def filtered_data():
    # recalcule seulement si input.min_bill() ou input.day() change
    tips = sns.load_dataset("tips")
    return tips[(tips["total_bill"] >= input.min_bill()) & (tips["day"] == input.day())]

@render.table
def table():
    return filtered_data().head(20)

@render.text
def n_rows():
    return f"{len(filtered_data())} rows"
```

```bash
# Deploy : Posit Connect / shinyapps.io
# Local Docker :
shiny run app.py --host 0.0.0.0 --port 8080

# Shinylive (browser-only WASM)
pip install shinylive
shinylive export app.py site/
# Servir le dossier site/ via nginx / Pages
```

## Liens

- [[Streamlit]] — alternative simple, prototype rapide
- [[Gradio]] — alternative LLM/ML demos
- [[Dash]] — alternative callbacks-based
- Panel — alternative basée Bokeh
- Solara — alternative React-like
- Shiny R (origine) : https://shiny.posit.co/
- Posit Connect — déploiement managed (payant)
- shinyapps.io — déploiement free tier limité
- Shinylive — WASM browser-only
- Docs : https://shiny.posit.co/py/
- GitHub : https://github.com/posit-dev/py-shiny
