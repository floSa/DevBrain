---
galaxie: dev
nom: Pattern - SaaS multi-tenant
type: pattern
created: 2026-05-20
modified: 2026-05-20
tags: [pattern, saas, multi-tenant, architecture]
---

# Pattern — SaaS multi-tenant

> Application B2B où plusieurs **tenants** (clients) cohabitent dans la même infrastructure, avec **isolation logique** stricte.

## Contexte

Tu construis une app B2B vendue à plusieurs clients (tenants). Chaque tenant doit :
- Avoir ses données **isolées** (pas de cross-tenant data leak)
- Pouvoir être **provisionné** rapidement
- Être **traçable** en monitoring / coûts
- Idéalement, pouvoir **scaler indépendamment**

3 modèles principaux d'isolation : **shared DB shared schema** / **shared DB schema-per-tenant** / **DB-per-tenant**.

## Modèles d'isolation

### 1. Shared DB, shared schema (row-level)

Une seule DB, toutes tables ont une colonne `tenant_id`. Tous les queries filtrent par `tenant_id`.

**Pour** : économique, simple à provisionner, migrations centralisées.
**Contre** : risque de **leak** si oubli de filtre, noisy neighbor (1 tenant qui mange les ressources).

```sql
SELECT * FROM orders WHERE tenant_id = $tenant AND id = $id;
```

→ **Politique Row Level Security ([[Postgres]] RLS) recommandée** pour appliquer le filtre côté DB :

```sql
CREATE POLICY tenant_isolation ON orders
  USING (tenant_id = current_setting('app.current_tenant')::uuid);
```

### 2. Shared DB, schema-per-tenant

Une DB, un schema PostgreSQL par tenant. Schema search path = `tenant_xyz, public`.

**Pour** : isolation plus forte que row-level, migrations gérables jusqu'à ~1000 tenants.
**Contre** : connection pooling complexe, backup/restore par tenant pénible.

### 3. DB-per-tenant

Chaque tenant = sa propre DB (managed) ou son propre cluster.

**Pour** : isolation totale, compliance (HIPAA, sovereign), restore granulaire.
**Contre** : coût plus élevé, ops plus lourdes (N DBs à patcher).

## Recommandation

| Scale tenants | Modèle recommandé |
|---|---|
| 10-100 tenants, similaires | Shared schema row-level + RLS |
| 100-1000 tenants, certains exigent isolation | Hybride : default shared, "premium" sur DB dédiée |
| Compliance stricte / very-large tenants | DB-per-tenant |

## Stack typique

| Brique | Choix | Rôle |
|---|---|---|
| **DB** | [[Postgres]] | RLS natif, mature multi-tenant |
| **Backend** | [[FastAPI]] + [[Pydantic]] + [[SQLAlchemy]] | injection `tenant_id` via dependency |
| **Auth / Tenant resolution** | [Clerk](https://clerk.com/), [WorkOS](https://workos.com/), Auth0 | SSO B2B + organisation |
| **Cache** | [[Redis]] | namespacer les keys (`tenant:xyz:key`) |
| **Storage** | [[AWS S3]] / [[MinIO]] | prefix par tenant (`s3://bucket/tenant-xyz/...`) |
| **Observability** | [[Langfuse]] / Datadog | tag `tenant_id` partout |
| **Quotas / billing** | Stripe + middleware rate limit | par tenant |

## Architecture cible (high-level)

```
[Request] → [API Gateway] → [Auth middleware]
                              ↓
                       [Resolve tenant_id]
                              ↓
              [Inject context: tenant_id, plan, quotas]
                              ↓
          [App business logic] ← (RLS Postgres, prefix S3, namespace Redis)
                              ↓
                  [Trace tagged tenant_id]
```

## Décisions clés

1. **Tenant resolution** : sous-domaine (acme.app.com), header (X-Tenant), JWT claim ?
   - JWT claim = standard moderne (avec WorkOS / Clerk)
2. **Onboarding self-serve** : auto-provisionning (compte → schema/RLS prêt en 1 click)
3. **Billing** : Stripe per-tenant, **metered** (usage-based) ou seat-based
4. **Quotas** : storage, API calls, LLM tokens — tracker par tenant
5. **Isolation premium** : option payante DB dédiée pour les gros clients ?
6. **Backups par tenant** : `pg_dump --schema=tenant_xyz` ou snapshots dédiés

## Pièges connus

- **Cross-tenant leaks** : tester avec un test que JAMAIS un query ne renvoie data d'un autre tenant. **Critique**.
- **Migrations** : sur schema-per-tenant, parcourir tous les schémas. Sur DB-per-tenant, orchestrer parallèle.
- **Connection pooling** : pgBouncer en mode "session" si tu setSession variables (RLS), pas "transaction"
- **Noisy neighbor** : un tenant qui mange 80% CPU. Quotas applicatifs + monitoring.
- **Coût per tenant** : tracker (storage / compute / API LLM). Sinon plan unique = perte sur gros tenants.
- **Soft delete** : ne PAS hard delete, garde le `tenant_id` + `deleted_at` pour audit.
- **Test data** : test fixtures sont par tenant, attention aux tests parallèles.
- **GDPR right-to-erasure** : doit pouvoir wipe **un** tenant entier rapidement.

## Voir aussi

- [[Postgres]] (RLS, schemas) — DB de référence
- [[Pattern - API REST FastAPI minimale]] — base FastAPI
- [[FastAPI]] / [[Pydantic]] / [[SQLAlchemy]]
- [[Redis]] — namespacing
- WorkOS / Clerk — auth B2B SSO
- *Multi-tenant SaaS Patterns* (AWS) : https://docs.aws.amazon.com/whitepapers/latest/saas-architecture-fundamentals/
