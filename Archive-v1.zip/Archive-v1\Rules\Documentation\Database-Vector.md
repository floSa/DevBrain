---
galaxie: dev
type: rule
domaine: documentation
applicable: type-service-database-vector
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, documentation, vector, embedding, rag]
---

# Règle — Documentation Base de données vectorielle

S'applique à : [[Qdrant]], [[Weaviate]], [[Milvus]], [[Chroma]], [[pgvector]], [[Faiss]].

## Principe (1 phrase)
Le `services/<vector-db>/README.md` doit fixer **le modèle d'embedding, sa dimension, la métrique de distance et les paramètres d'index** — sans ces 4 éléments, la base est ininterprétable et **non-reproductible**.

## MUST

### 1. Modèle d'embedding (CRITIQUE)
Documenter explicitement :
- **Nom exact du modèle** (ex: `BAAI/bge-m3`, `text-embedding-3-large`, `sentence-transformers/all-MiniLM-L6-v2`)
- **Provider** (HuggingFace local, OpenAI API, Cohere, Voyage, etc.)
- **Dimension des vecteurs** (ex: 384, 768, 1024, 1536, 3072)
- **Versionning** : si le modèle évolue côté provider, noter la version utilisée
- **⚠️ Avertissement** : changer de modèle invalide TOUTE la base. Tout vecteur stocké doit être ré-embedé.

### 2. Stratégie d'indexation
- **Type d'index** : HNSW, IVFFlat, IVF_PQ, DiskANN, FLAT…
- **Métrique de distance** : Cosine, Dot Product, L2 (Euclidean), Hamming
- **Paramètres clés** :
  - HNSW : `m`, `ef_construct`, `ef` (search-time)
  - IVF : `nlist`, `nprobe`
  - PQ : `nbits`, `M`
- **Justification** des choix : recall vs latency vs RAM

### 3. Schéma des métadonnées
- Lister les champs métadonnées attachés à chaque vecteur :
  ```
  | Champ | Type | Filtrable | Indexé | Description |
  |-------|------|-----------|--------|-------------|
  | doc_id | string | yes | yes | UUID source doc |
  | source | enum | yes | yes | "pdf" / "web" / "manual" |
  | tenant_id | string | yes | yes | Multi-tenant isolation |
  | created_at | timestamp | yes | no | Date insertion |
  | content_preview | text | no | no | Pour debug humain |
  ```
- Préciser quels champs sont indexés pour le **filtrage hybride** (filter pre-search vs post-search)

### 4. Stratégie de chunking
- Méthode de découpage du texte source : token-based, sentence-based, recursive, semantic, structure-aware (Markdown sections, etc.)
- **Taille de chunk** (en tokens ou caractères)
- **Overlap** entre chunks
- Lien avec le service de parsing en amont (ex: `services/docling/`)

### 5. Contrat d'interface
- Endpoints / méthodes : `upsert`, `search`, `delete`, `count`
- Format de payload (Python dict, JSON, etc.)
- Limites de batch (nb max de vecteurs par appel)

## SHOULD

- **Volumétrie attendue** : nb de vecteurs cible (ex: 5M docs × 8 chunks ≈ 40M vecteurs)
- **Stratégie de réindexation** : full rebuild vs incremental
- **Snapshots/backups** : fréquence et procédure
- **Hybrid search** : si activé, méthode de fusion (RRF, weighted) et configuration
- **Score thresholds** : seuils minimum pour considérer un résultat "bon"

## NICE

- Benchmarks de recall sur un dataset interne
- Comparaison des paramètres testés (M=8 vs 16 vs 32)
- Eval périodique avec [[Ragas]] / [[DeepEval]] des chunks récupérés

## Pièges classiques

- **Cosine vs Dot Product** : cosine suppose des vecteurs normalisés. Si non normalisés et tu utilises dot, tu favorises les vecteurs de grande norme
- **`IndexFlatIP` (Faiss)** ≠ cosine sauf si vecteurs normalisés
- **Filtres pre-search** sur cardinality élevée → lent (scan)
- **Modèle changé sans réindexation** = corruption silencieuse
- **Dimension hardcodée** dans le code → bug à la migration vers un nouveau modèle

## Voir aussi

- Template : `Templates/ServiceDocs/README - database-vector.md`
- [[README - Service]] — règle parente
- [[Document-Processing]] — règle pour le chunking en amont
- [[Qdrant]], [[Weaviate]], [[Milvus]], [[Chroma]], [[pgvector]], [[Faiss]] — fiches Services
- [[Comparatif - Bases vectorielles]] — vue dynamique
