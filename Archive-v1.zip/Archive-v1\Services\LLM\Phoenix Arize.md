---
galaxie: dev
nom: Phoenix Arize
alias: [phoenix, arize-phoenix]
categorie: llm/observability
sous_categories: [tracing, evals, otel, opensource]
licence: Elastic-2.0
licence_type: source-available
hosted: both
maturite: production
langage: Python (TS frontend)
clients_officiels: [python, ts]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[LangSmith]]", "[[Langfuse]]", "[[Helicone]]", "[[Weights & Biases]] Weave"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, observability, tracing, eval]
url_officiel: https://phoenix.arize.com/
url_docs: https://docs.arize.com/phoenix
url_repo: https://github.com/Arize-ai/phoenix
---

# Phoenix Arize

## Pourquoi
Observability LLM **open-source** par Arize AI. Standard **OpenTelemetry** (tu instrumentes une fois, lit Phoenix + autres backends OTEL). Tracing détaillé des chaînes LLM, eval intégré (LLM-as-judge), datasets / experiments, prompt playground. Self-hostable, gratuit. Le défaut quand tu ne veux pas dépendre d'un SaaS pour le tracing.

## Quand l'utiliser
- Observability LLM self-hosted (data privacy)
- Tu veux du tracing OTEL standard (pas du vendor lock-in [[LangSmith]])
- Pipelines RAG complexes — voir chaque étape (retrieval, prompt, génération)
- Eval offline + monitoring online dans la même stack
- Comparaison de prompts / configs avec datasets

## Quand NE PAS l'utiliser
- Tu vis 100% LangChain et veux la meilleure intégration native → [[LangSmith]]
- Tu veux le maximum de polish UI → [[Langfuse]] ou [[LangSmith]] sont peut-être plus jolis
- Setup ultra-simple SaaS → [[Helicone]] / [[Langfuse]] cloud sont rapides

## Pièges connus
- **Licence Elastic-2.0** : pas vraiment OSS (restrictions sur SaaS de Phoenix lui-même)
- **OTEL setup** : `openinference-instrumentation-*` à installer par lib (LangChain, LlamaIndex, OpenAI…)
- **Storage** : SQLite par défaut, [[Postgres]] pour scale
- **Eval API** : double rôle (offline + online), comprendre le modèle conceptuel
- **Datasets** : versionning utile, à structurer dès le début

## Liens
- [[LangSmith]], [[Langfuse]] — alternatives
- OpenInference (libs OTEL) : https://github.com/Arize-ai/openinference
- Arize AX (managed enterprise) : https://arize.com/
- Tutorials : https://docs.arize.com/phoenix/tutorials/notebooks
