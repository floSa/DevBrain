---
galaxie: dev
type: rule
domaine: security
applicable: global
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, security]
---

# Règle — Sécurité (baseline)

## Principe
Hygiène minimale : pas de secret en clair, validation au boundary, dépendances scannées, HTTPS partout.

## MUST

- **Secrets en `.env` ou secret manager**, jamais dans le code ou les commits. Vérifier avec `git-secrets`, `trufflehog` ou équivalent.
- **`.env*` dans `.gitignore`** systématiquement.
- **Validation des entrées au boundary** : tout input qui vient de l'extérieur (HTTP, CLI, fichier user) est validé avant traitement. Pydantic, zod, etc.
- **Dépendances scannées** : `Dependabot`, `Snyk`, `pip-audit`, `npm audit`. Action dans la CI.
- **HTTPS en prod**. Pas d'exception.
- **Pas de SQL formatté** (concat strings) : ORM ou requêtes paramétrées. Toujours.
- **Authentification cryptographiquement saine** : ne pas inventer d'auth. Utiliser bcrypt/argon2 pour les mots de passe, JWT/sessions standard.
- **CORS configuré strictement** en prod : whitelist explicite, pas de `*` sur les endpoints qui touchent l'auth.

## SHOULD

- **CSP headers** sur les apps web.
- **Rate limiting** sur les endpoints publics (login, signup, reset password).
- **Headers de sécurité** : `X-Content-Type-Options`, `X-Frame-Options`, `Strict-Transport-Security`.
- **Audit logging** sur les actions sensibles (login, changement de role, suppression).
- **Backup** automatisés et **restauration testée** (un backup non testé n'est pas un backup).
- **Permissions GitHub** : restreindre `GITHUB_TOKEN` dans les workflows à ce qui est nécessaire.
- **Action GitHub pinnées par SHA** plutôt que par tag (supply chain).

## NICE-TO-HAVE

- Pen test annuel pour projets sensibles.
- WAF devant les apps publiques.
- Bug bounty program si projet public mature.
- Threat modeling au démarrage des features sensibles.

## Anti-patterns

- "On mettra du HTTPS plus tard"
- API key dans l'URL (`?token=...`) — apparaît dans les logs/proxies.
- "Le client validera" — non, **toujours** valider côté serveur.
- Logs avec PII / secrets en clair.
- Stockage de mots de passe en MD5/SHA1.
- Désactiver TLS pour déboguer en prod.

## Outils

- Secrets scanning : `git-secrets`, `trufflehog`, `gitleaks`
- Dependency scan : `pip-audit`, `npm audit`, `cargo audit`, `Trivy`
- SAST : `bandit` (Python), `semgrep`, `CodeQL` (GitHub)
- Container scan : `Trivy`, `Grype`

## Voir aussi

- [[Rules/Global/Git]] — secrets et commits
- [[Rules/Types/Web-app]] — section sécurité spécifique web
