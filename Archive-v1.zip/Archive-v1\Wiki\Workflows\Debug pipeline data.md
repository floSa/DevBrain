---
galaxie: wiki
nom: Debug pipeline data
type: workflow
categorie: workflow/data-eng
sous_categories: [debug, pipeline, data-quality, troubleshooting]
domaines: [data-eng, mlops]
duree_estimee: 30min-2h selon nature
prerequis: [accès aux logs du pipeline, accès aux DBs source et destination]
created: 2026-05-19
modified: 2026-05-19
tags: [workflow, data-eng, debug, pipeline]
---

# Debug pipeline data

## Quand l'utiliser

Un pipeline data (ETL/ELT, Airflow, Prefect, dbt) a un comportement anormal :
- Lignes manquantes en destination
- Doublons inattendus
- Schémas qui dérivent
- Job qui plante sans message clair
- Compteurs (`row count`) qui décalent entre étapes

Avant de chercher à corriger : **comprendre où ça casse**. Ce workflow t'aide à isoler la cause.

## Pré-requis

- Accès aux logs du pipeline (Airflow UI, Prefect, CloudWatch, etc.)
- Accès en read aux DBs source et destination
- Idéalement : capacité à re-run un step en isolation

## Procédure

### 1. Définir le symptôme précisément

Avant de toucher au code, écris en 1 phrase :
- ❌ "Le pipeline plante" → trop vague
- ❌ "Il manque des données" → trop vague
- ✅ "Le job `daily-orders` du 18/05 a écrit 12 450 lignes en destination alors que la source en contenait 12 800 (delta : 350 lignes manquantes)"

Si tu peux pas écrire cette phrase, retourne checker.

### 2. Localiser l'étape qui casse

Si pipeline en étapes (extract → transform → load) :

```bash
# Compter à chaque étape
source_count       = SELECT count(*) FROM source WHERE date = '2026-05-18'
staging_count      = SELECT count(*) FROM staging.orders WHERE ingestion_date = '2026-05-18'
final_count        = SELECT count(*) FROM warehouse.orders WHERE order_date = '2026-05-18'
```

Si le delta apparaît entre `source_count` et `staging_count` → souci d'extract/ingest. Entre `staging_count` et `final_count` → souci de transform/load.

### 3. Inspecter les logs côté étape suspecte

```bash
# Airflow CLI exemple
airflow tasks logs daily-orders extract 2026-05-18
airflow tasks logs daily-orders transform 2026-05-18

# Filtres utiles dans les logs
grep -i "warning\|error\|filter\|skip\|dropped" logs.txt
grep -i "rows\|count\|insert\|update" logs.txt
```

Cherche :
- `WARNING/ERROR` (cassant ou silencieux)
- `Filter applied: X` (lignes filtrées intentionnellement)
- `Skipping row` (lignes ignorées — souvent un schema mismatch)
- `Dropped duplicates` (déduplication agressive)

### 4. Reproduire en local sur un échantillon

```python
# Charge l'échantillon problématique
import polars as pl
df = pl.read_parquet("s3://bucket/source/2026-05-18.parquet")

# Reproduis la transformation
df_transformed = pipeline.transform(df)

# Compare
print(f"In:  {len(df)}")
print(f"Out: {len(df_transformed)}")
print(f"Lost rows:")
lost = df.join(df_transformed.select("id"), on="id", how="anti")
lost.head(20)
```

L'avantage de [[Polars]] / [[DuckDB]] ici : tu peux charger 100MB+ en local et inspecter sans toucher la prod.

### 5. Hypothèses à tester (par ordre de probabilité)

**Données :**
- Schéma source a changé → colonne renommée, type changé, nullable devenu obligatoire
- Encodage (UTF-8 vs Latin-1) — lignes avec caractères spéciaux droppées
- Timezone : `2026-05-18 23:30 UTC` vs `2026-05-18 23:30 Paris` → frontière de jour
- NULL handling incohérent entre étapes

**Code :**
- Filtre trop strict (`WHERE x > 0` mais x peut être NULL)
- Join (`INNER` au lieu de `LEFT`, perte de lignes orphelines)
- Déduplication sur la mauvaise clé
- Type cast destructif (float → int qui floore silencieusement)

**Infra :**
- Timeout sur une étape → batch incomplet
- Disque plein → écriture partielle
- Idempotence cassée → 2 runs concurrents qui s'écrasent
- Permissions changées → écriture refusée silencieusement

### 6. Fixer + ajouter une garde

Une fois la cause trouvée, fix **et ajoute un assert** dans le pipeline pour que ça ne réarrive pas :

```python
# Avant le fix
df = clean_orders(raw_df)

# Après le fix : avec garde
df = clean_orders(raw_df)
assert len(df) >= 0.95 * len(raw_df), \
    f"Perte anormale de lignes : {len(raw_df)} → {len(df)}"
```

Idéalement : ajouter à ta **suite de checks** (Great Expectations, dbt tests, etc.).

### 7. Documenter dans un REX

Crée ou enrichis `Bugs/REX - <Pipeline ou Service>.md` avec :
- Symptôme exact
- Cause racine
- Fix
- Leçon

C'est exactement la procédure du skill `log-bug`.

## Checklist de fin

- [ ] Symptôme reproduit en local sur un échantillon
- [ ] Cause racine identifiée (pas juste une corrélation)
- [ ] Fix testé sur l'échantillon
- [ ] Garde ajoutée dans le pipeline pour détecter la régression
- [ ] REX écrit dans `Bugs/REX - <X>.md`
- [ ] Pipeline re-lancé en prod, vérification post-run du compteur

## Pièges courants

- **Fix avant compréhension** — tu "fixes" un symptôme et le vrai bug reste latent
- **Pas de garde** — le bug revient dans 6 mois, tu re-débugges from scratch
- **REX oublié** — toi ou ton équipe re-tombe dans le panneau
- **Trop large** : "je vais réécrire toute l'ingestion" alors qu'une ligne aurait suffi
- **Ne pas regarder les **infra logs** (CloudWatch, etc.) en plus des logs app — les timeouts/OOM y vivent

## Variantes

- **Drift de schéma** : besoin de Great Expectations ou dbt source freshness
- **Bug en prod uniquement** : c'est probablement un **données-spécifique** (volume, distribution). Échantillonne la prod.
- **Bug intermittent** : log plus, ajoute du tracing (OpenTelemetry), check les retries silencieux

## Voir aussi

- Skill : `log-bug` (créer le REX au format)
- Services : [[Airflow]], [[Dagster]], [[Polars]], [[DuckDB]]
- Pattern : à venir, `Pattern - ELT moderne` (DuckDB + dbt)
- Concept : data quality (à écrire dans `Wiki/Concepts/`)
