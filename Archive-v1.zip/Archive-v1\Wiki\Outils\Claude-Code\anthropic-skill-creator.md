---
galaxie: wiki
nom: anthropic-skills:skill-creator
type: claude-code-skill
plateforme: claude-code
categorie: skill/meta
sous_categories: [skill, dev-flow]
auteur: Anthropic
source: anthropics/skills
source_url: https://github.com/anthropics/skills
install_cmd: claude plugin install anthropic-skills
install_doc: https://docs.claude.com/en/docs/build-with-claude/skills
licence: MIT
licence_type: open-source
domaines: [ai-eng, ml-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, meta]
---

# anthropic-skills:skill-creator

## Pourquoi

**Skill méta** : il aide à créer/améliorer d'autres skills. Permet de structurer un `SKILL.md` proprement, de mesurer la performance d'un skill via des évals, et d'optimiser sa description pour qu'il se déclenche au bon moment (et seulement au bon moment).

C'est l'outil pour **passer du "j'ai un prompt long que je colle souvent" au "j'ai un skill custom"**.

## Quand l'utiliser

- transformer un prompt récurrent en skill propre
- optimiser un skill existant (sa description ne se déclenche pas / se déclenche trop)
- benchmarker un skill sur un dataset de cas réels
- comparer deux variantes d'un skill (A/B)

## Quand NE PAS l'utiliser

- pour du one-shot — le ROI d'un skill arrive vers la 5-10ᵉ réutilisation
- pour wrapper un truc déjà fait par un skill officiel → préfère étendre l'officiel via plugin install

## Comment l'installer

```bash
claude plugin install anthropic-skills
```

Voir [[_installer-un-skill]].

## Exemples d'usage

```
> crée un skill "review-data-pipeline" qui audite un script ETL Python
> améliore la description de mon skill add-service — il se déclenche trop souvent
> évalue mon skill propose-stack sur 10 demandes de stack typiques
```

## Pièges connus

- L'éval nécessite un dataset de cas réels → prends le temps de le constituer
- Une description trop large = skill qui se déclenche partout, devient bruit

## Liens

- Source : https://github.com/anthropics/skills
- Doc construire un skill : https://docs.claude.com/en/docs/build-with-claude/skills
