---
galaxie: wiki
nom: Generalized Procrustes Analysis (GPA)
alias: [GPA, Analyse Procrustéenne Généralisée]
type: concept
categorie: concept/stats
sous_categories: [factor-analysis, alignment, multi-table, shape, sensometrics]
domaines: [data-science]
maturite: established
auteurs_cles: [Gower 1975, Ten Berge 1977]
lecture_min: 10
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, gpa, procrustes, alignment]
---

# Generalized Procrustes Analysis (GPA)

## TL;DR

Étant donné **plusieurs configurations de points** représentant les mêmes objets vus par plusieurs sources (juges, instruments, expériences), on cherche à les **aligner optimalement** en supprimant les transformations rigides triviales (translation, rotation, scaling). Le résultat : un **consensus** + des contributions individuelles à ce consensus.

Le nom vient de Procuste, brigand grec qui ajustait ses victimes à son lit en les étirant ou les coupant. Ici, on ajuste plus civilement.

## Le problème

Plusieurs juges (ou instruments) évaluent les mêmes produits sur des dimensions qui leur sont propres. Chaque juge fournit une **configuration de points** :

$$ X_k \in \mathbb{R}^{n \times p}, \quad k = 1, \dots, K $$

où $n$ est le nombre d'objets communs. Les configurations diffèrent par :
- Translation (origine différente)
- Rotation (axes orientés différemment)
- Échelle (juge sévère/laxiste)

Comment trouver un **consensus** et mesurer combien chaque juge s'en écarte ?

GPA cherche les transformations $(T_k, R_k, c_k)$ qui minimisent globalement la dispersion.

## L'idée

### Cas à deux configurations (orthogonal Procrustes)

Soit $A, B \in \mathbb{R}^{n \times p}$ centrées. On cherche $R$ orthogonale qui minimise :

$$ \min_{R^\top R = I} \| A R - B \|_F^2 $$

**Solution analytique** via SVD de $B^\top A = U \Sigma V^\top$ :

$$ R^* = V U^\top $$

C'est l'orthogonal Procrustes. Avec scaling : on ajoute $c = \mathrm{Tr}(\Sigma) / \|A\|_F^2$.

### Cas généralisé (K configurations)

On cherche simultanément $(R_k, c_k, T_k)_{k=1..K}$ et un **consensus** $Y$ minimisant :

$$ \min \sum_{k=1}^K \| c_k X_k R_k + T_k - Y \|_F^2 \quad \text{avec contraintes pour identifiabilité} $$

Pas de solution analytique → **algorithme itératif** :

1. Initialiser $Y$ comme la moyenne des $X_k$ centrés
2. Pour chaque $k$, calculer $(R_k, c_k)$ qui aligne $X_k$ sur $Y$ (orthogonal Procrustes 2-à-2)
3. Mettre à jour $Y$ = moyenne des $c_k X_k R_k$
4. Répéter 2-3 jusqu'à convergence (mouvement de $Y$ < ε)

### Mesures de qualité

- **R² Procrustéenne** : fraction de variance "consensuelle" / variance totale
- **Variance résiduelle par juge** : dispersion de chaque juge autour du consensus → juges atypiques
- **Coefficient RV** (cf. [[MFA]]) — alternative pour mesurer la similarité entre configurations

### Variante : Pré-traitement par PCA

Souvent on combine GPA et PCA : on aligne les configurations avec GPA, puis on fait une PCA sur le consensus pour visualiser.

## Quand c'est utile

- **Analyse sensorielle libre** : chaque juge choisit ses propres descripteurs (free profiling, projective mapping)
- **Morphométrie** : alignement de points anatomiques entre individus
- **Multi-omics** : aligner espaces d'embedding entre tissus/conditions
- **Évaluation d'embeddings** : tester si deux espaces d'embedding (BERT vs OpenAI ada) sont "alignables" (à une rotation près)
- **Multi-experiment comparison** : alignement de configurations issues de runs différents

## Quand ça ne marche pas / pièges

- **Pas de mêmes objets entre configurations** → GPA suppose $n$ objets communs. Pas applicable sinon.
- **Très peu d'objets ($n < p$)** → sur-ajustement de la rotation
- **Sensibilité aux outliers** : un objet aberrant tire fortement la rotation. Considérer GPA robuste.
- **Confusion avec MFA** : MFA équilibre des groupes de variables sur mêmes individus. GPA aligne des configurations différentes des mêmes individus. À voir comme deux paradigmes complémentaires.
- **Non-unicité** : la solution est définie à une rotation globale près. Imposer un référentiel (premier juge fixe ou contrainte sur $Y$).

## Code minimal

```python
from scipy.spatial import procrustes
import numpy as np

# 2 configurations centrées
A = np.random.randn(20, 3)
B = A @ random_rotation_matrix() + 0.5 * np.random.randn(20, 3)

mtx1, mtx2, disparity = procrustes(A, B)
# mtx1, mtx2 alignés
# disparity = somme des distances au carré post-alignement
```

Pour le cas généralisé (K > 2) :

```python
# K configurations, chacune n × p
configurations = [X_1, X_2, ..., X_K]

# Itératif
Y = np.mean([X - X.mean(axis=0) for X in configurations], axis=0)
for _ in range(50):
    aligned = []
    for X in configurations:
        Xc = X - X.mean(axis=0)
        # SVD de Y^T X
        U, _, Vt = np.linalg.svd(Y.T @ Xc, full_matrices=False)
        R = Vt.T @ U.T
        aligned.append(Xc @ R)
    Y_new = np.mean(aligned, axis=0)
    if np.linalg.norm(Y_new - Y) < 1e-8:
        break
    Y = Y_new
```

Bibliothèque haut niveau : [[prince]] ne le fait pas, mais R `FactoMineR::GPA` ou le package python `pyOpensci/factor_analyzer`.

## Implémentations concrètes

- `scipy.spatial.procrustes` — cas à 2 configurations
- R : `FactoMineR::GPA` ou `vegan::procrustes`
- `morpho` (R) — pour la morphométrie 3D
- En sensometrics : `SensoMineR` (R)

## Pour aller plus loin

- Gower & Dijksterhuis, *Procrustes Problems* (Oxford, 2004) — référence
- Application en analyse sensorielle : Pagès, *Statistique générale pour utilisateurs*
- **Liens internes** : [[PCA]] (souvent utilisée après alignement), [[MFA]] (alternative paradigme pour multi-tables), [[PGA]] (extension non-euclidienne)
