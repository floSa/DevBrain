---
galaxie: wiki
nom: LLM observability
alias: [LangSmith, Langfuse, Helicone, traces, spans, OpenLLMetry, LLM monitoring]
type: concept
categorie: concept/llm-production
sous_categories: [observability, monitoring, llm-ops, production]
domaines: [ai-eng, mlops]
maturite: established
auteurs_cles: []
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, observability, production, monitoring]
---

# LLM observability

## TL;DR

Standard 2026 pour **monitoring LLM apps en prod** : traces complètes (request → spans → generations), token usage, cost per call/user/feature, latency (TTFT, total), tool calls, errors. Plateformes : **LangSmith** (LangChain), **Langfuse** (open-source), **Helicone** (proxy), **Arize Phoenix** (open), **Braintrust**, **Weave** (W&B), **Traceloop/OpenLLMetry**, **Lunary**, **Portkey**. Standards émergents : **OpenTelemetry for LLMs**, **OpenInference**. Sans observability, impossible de debug, optimiser cost, ou évaluer continuously. **Indispensable** pour toute app LLM en production.

## Le problème

LLM en production = **black box** :
- Pourquoi ce call a coûté 50¢ ?
- Pourquoi la latence a explosé ?
- L'agent a fait 10 tool calls — utiles ?
- User satisfaction = ? Conversation drift ?
- Quel modèle marche le mieux ?

Sans **tracing structuré**, impossible à répondre.

## L'idée

### Concepts

#### Trace

**Une request user complète** : du clic → réponse finale.

Contient plusieurs spans (étapes).

#### Span

**Une opération** dans une trace : LLM call, tool execution, DB query, etc.

#### Generation

Sous-type de span : un **LLM call** spécifiquement, avec :
- Model name
- Input tokens, output tokens, cached tokens
- Latency, TTFT
- Temperature, sampling params
- Cost ($)
- Prompt / completion text

#### Tokens

- **Input tokens** : prompt + context + system
- **Output tokens** : généré
- **Cached input tokens** : prompt caching read (cheap)
- **Cache creation tokens** : prompt caching write (cher)

#### Cost

Calculer per call : tokens × pricing model.

#### Latency

- **TTFT** : Time To First Token (critical UX)
- **Total** : full response
- **TPOT** : Inter-Token Latency

#### Tool calls

Si agent : trace chaque tool execution.

### Plateformes

#### LangSmith (LangChain)

Native LangChain integration, traces beautiful, dataset/eval intégré. Commercial.

#### Langfuse

**Open-source**, self-hostable. Production-ready. Standard 2026 pour qui veut open.

Features :
- Traces, sessions, users
- Prompt management + versioning
- Evals
- Datasets
- LLM-as-judge

#### Helicone

**Proxy** : tu changes ton API endpoint, automatique. Zero-config tracking. Open + cloud.

#### Arize Phoenix

Open-source, OpenInference standard. Strong on RAG evaluation.

#### Braintrust

Eval + observability combiné. Strong dataset management.

#### Weave (Weights & Biases)

W&B's LLM offering. Tightly integrated with W&B suite.

#### Traceloop / OpenLLMetry

OTel-compatible. Open-source. Standard pour multi-vendor stack.

#### Portkey

LLM gateway + observability + caching + routing.

#### Comet Opik

Open-source par Comet.

#### Galileo, Patronus AI, Confident AI, Athina

Other commercial alternatives.

### Standards

#### OpenTelemetry for LLMs

OTel community working on LLM specifications.

#### OpenInference (Arize, OTel)

Standard semantic conventions pour LLM spans :
- `llm.model.name`
- `llm.prompt.template`
- `llm.token.count.input` / `output` / `cache_read`
- `llm.cost.usd`

#### OpenLLMetry (Traceloop)

OTel-based instrumentation for LLM SDKs (OpenAI, Anthropic, etc.).

### Que tracer

#### Per request (trace)

- User ID (per-tenant)
- Session ID (conversation)
- Feature / use case tag
- Input
- Output final
- Total cost, tokens, latency
- Status (success / error)

#### Per generation (span)

- Model name, version
- Provider (OpenAI / Anthropic / etc.)
- Prompt (templated + filled)
- Completion (full output)
- Tokens (input / output / cached)
- Cost
- Latency (TTFT, total)
- Sampling params
- Cache hit / miss

#### Per tool call

- Tool name
- Args
- Output / error
- Latency

#### Custom metadata

- Business context (user tier, locale, ...)
- A/B test variant
- Prompt version
- Quality score (if eval)
- User feedback (thumbs up/down)

### Stratégies de sampling

#### Dev

100% sampling. All traces visible.

#### Production

- **100% trace** pour erreurs, low success
- **% sample** pour succès (1-10%)
- **Tail sampling** : decide after seeing if trace interesting

#### Pourquoi sampler

Production high QPS = millions de traces / jour. Coût de storage / processing.

### Dashboards

Standard dashboards :
- **Cost** : per day, per user, per feature
- **Latency** : p50, p95, p99
- **Error rate** : 4xx/5xx, timeout
- **Token usage** : input/output, cached
- **Cache hit rate**
- **Tool call success**
- **Top users / features** by cost

### Use cases

#### Cost reduction

Identifier où ça coûte. Optimiser : prompt caching, smaller model, less retrieval.

#### Latency debugging

Trace permet de voir si bottleneck = LLM, retrieval, tool, network.

#### Quality monitoring

LLM-as-judge sur sample → detect quality drops.

#### Production eval

Convert traces → dataset eval pour CI.

#### Compliance / audit

Garder traces pour reglementé (medical, financial).

#### User feedback loop

Capturer thumbs up/down → améliorer prompts / data.

### Best practices

1. **Trace everything en dev**, sample en prod
2. **Tag par feature** : pas tout dans "production"
3. **User ID** : pour multi-tenant analysis
4. **Session ID** : pour conversations
5. **Cost dashboard** : alertes sur spike
6. **Prompt version** dans traces
7. **Eval continuous** : sample traces → judge → dataset
8. **A/B test** : variant tag, compare metrics
9. **Open standards** (OTel) si multi-stack
10. **Privacy** : PII redaction in traces

## Quand c'est utile

- **Toute app LLM prod** : non-négociable
- **Cost optimization** : identifier waste
- **Latency debugging** : tracer bottlenecks
- **Quality regression detection** : dataset eval
- **A/B test prompts** : compare variants
- **User support** : reproduire user's issue
- **Compliance** : audit trail
- **Continuous improvement** : data flywheel

## Quand ça ne marche pas / pièges

- **Privacy issues** : PII dans traces (emails, passwords)
- **Storage cost** : traces = lots of data
- **Sample bias** : prod sampling biaisé
- **Tool overhead** : ajout latency ~5-20ms par span
- **Multi-platform pain** : OpenAI + Anthropic + local model → unifier traces
- **Migration painful** : changer de provider = re-instrumenter
- **No standard** encore complet : OTel evolving
- **Cardinality explosion** : trop de tags → query slow
- **Eval bias** : LLM judge sur sample → biased sample
- **Production load** : tracing 100% can saturate ingest
- **Sensitive data** : medical / financial → encrypt at rest

## Code minimal

```python
# 1. Langfuse (open-source, recommended)
# pip install langfuse
from langfuse.decorators import observe
from langfuse.openai import openai  # automatic tracing

@observe(name="my_agent")
def my_agent(question: str) -> str:
    response = openai.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": question}]
    )
    return response.choices[0].message.content

# Toutes les calls Openai automatiquement tracées dans Langfuse

# Tag custom
from langfuse import Langfuse
langfuse = Langfuse()

with langfuse.trace(name="rag_query", user_id="user_123", session_id="sess_456",
                     metadata={"feature": "search", "ab_variant": "A"}) as trace:
    # ... your code
    trace.update(output=final_answer)
    trace.score(name="quality", value=4.5)

# 2. LangSmith (LangChain)
import os
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = "..."
# Tout LangChain auto-tracé

# 3. Helicone (proxy, easy)
from openai import OpenAI
client = OpenAI(
    base_url="https://oai.helicone.ai/v1",  # Proxy
    default_headers={"Helicone-Auth": f"Bearer {HELICONE_KEY}"}
)
# Toutes les calls passent par Helicone, automatically tracked

# 4. Arize Phoenix (open + OpenInference)
import phoenix as px
session = px.launch_app()
# Use OpenInference auto-instrumentation
from openinference.instrumentation.openai import OpenAIInstrumentor
OpenAIInstrumentor().instrument()

# 5. Weave (W&B)
import weave
weave.init("my-project")

@weave.op()
def chat(question):
    return openai_call(question)

# 6. OpenLLMetry (OTel-based)
from traceloop.sdk import Traceloop
Traceloop.init(app_name="my_app")

# 7. Custom tracing decorator
from functools import wraps
import time

def trace_llm(name):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            start = time.time()
            try:
                result = fn(*args, **kwargs)
                # Log to your backend
                log_trace(name, args, kwargs, result, duration=time.time()-start)
                return result
            except Exception as e:
                log_error(name, e)
                raise
        return wrapper
    return decorator

@trace_llm("my_func")
def my_func(...):
    ...

# 8. Token / cost calculation
def calculate_cost(model, input_tokens, output_tokens, cached_input=0):
    pricing = {
        "gpt-4o": {"input": 2.50, "output": 10.00, "cached": 1.25},  # per 1M
        "claude-3-7-sonnet": {"input": 3.00, "output": 15.00, "cached": 0.30},
    }
    p = pricing[model]
    return ((input_tokens - cached_input) * p["input"] +
            cached_input * p["cached"] +
            output_tokens * p["output"]) / 1e6

# 9. Production sampling
import random
def should_sample(trace):
    if trace.has_error:
        return True  # 100% sampling errors
    if trace.cost_usd > 1.0:
        return True  # 100% sampling expensive
    return random.random() < 0.05  # 5% normal sampling

# 10. PII redaction before logging
import re
def redact_pii(text):
    text = re.sub(r"\b[\w.-]+@[\w.-]+\.\w+\b", "[EMAIL]", text)
    text = re.sub(r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b", "[PHONE]", text)
    # Add more patterns
    return text
```

## Pour aller plus loin

- *Langfuse*, *LangSmith*, *Helicone*, *Arize Phoenix*, *Braintrust* documentation
- *OpenLLMetry* (Traceloop) docs
- *OpenTelemetry* LLM working group
- *OpenInference* spec
- Anthropic, OpenAI cookbook on monitoring
- *Made With ML* / *Hamel's blog* — production LLM patterns
- **Liens internes** : [[Inference optimization]], [[LLM eval metrics]], [[Guardrails]], [[Routing and cascading]], [[Reliability patterns]]
