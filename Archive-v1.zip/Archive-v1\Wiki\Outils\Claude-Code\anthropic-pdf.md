---
galaxie: wiki
nom: anthropic-skills:pdf
type: claude-code-skill
plateforme: claude-code
categorie: skill/documents
sous_categories: [pdf, ocr, extraction]
auteur: Anthropic
source: anthropics/skills
source_url: https://github.com/anthropics/skills
install_cmd: claude plugin install anthropic-skills
install_doc: https://docs.claude.com/en/docs/build-with-claude/skills
licence: MIT
licence_type: open-source
domaines: [ai-eng, ml-eng, data-science, doc]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, documents, pdf]
---

# anthropic-skills:pdf

## Pourquoi

Skill officiel pour **lire, extraire, fusionner, splitter, remplir des PDF**. Inclut l'OCR pour les PDF scannés, l'extraction de tableaux, le remplissage de formulaires. C'est le couteau suisse PDF de l'agent.

## Quand l'utiliser

- lire un *paper* arXiv et en extraire les tableaux/équations
- remplir un formulaire PDF programmatiquement
- fusionner plusieurs rapports en un seul PDF
- OCR sur un PDF scanné pour le rendre searchable
- extraire des chiffres clés d'un rapport financier/technique

## Quand NE PAS l'utiliser

- pour **générer** un PDF à partir de zéro avec mise en page propre : préfère `anthropic-skills:docx` puis export PDF, ou un template LaTeX
- pour parser massivement (>50 PDFs) : passe à `unstructured` ou `pymupdf` dans un script dédié

## Comment l'installer

```bash
claude plugin install anthropic-skills
```

Voir [[_installer-un-skill]].

## Exemples d'usage

```
> lis ~/papers/attention.pdf et résume les contributions principales
> extrais le tableau de résultats page 7 en CSV
> fusionne ~/reports/*.pdf en un seul rapport_2026.pdf
```

## Pièges connus

- Pour les PDF > 10 pages, **fournir un range** (`pages: "1-5"`) explicite, sinon le skill refuse.
- L'OCR sur PDF mal scanné peut donner des résultats foireux — vérifie un échantillon.

## Liens

- Source : https://github.com/anthropics/skills
