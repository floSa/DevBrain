---
galaxie: dev
nom: PyMuPDF
alias: [pymupdf, fitz, mupdf]
categorie: data/document
sous_categories: [pdf, extraction, fast, python, rendering]
licence: AGPL-3.0 (open-source) / commercial (Artifex)
licence_type: dual-license
hosted: self
maturite: production
langage: Python / C
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[pdfplumber]]", "[[Unstructured]]", "[[Docling]]", "[[Marker]]", "pikepdf"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, pdf, python, extraction, rendering]
url_officiel: https://pymupdf.readthedocs.io/
url_docs: https://pymupdf.readthedocs.io/en/latest/
url_repo: https://github.com/pymupdf/PyMuPDF
---

# PyMuPDF

## Pourquoi

Binding Python du moteur **MuPDF** (C, Artifex). **Très rapide** : ~10x pdfplumber sur extraction texte massive. Supporte PDF + EPUB + XPS + CBZ + FB2. Couvre l'éventail complet : **extraction texte/images/metadata**, **rendering pages → images**, **édition** (annotations, pages, watermarks), **search**, **redaction**, **OCR via Tesseract** intégré.

Cible : **extraction de masse** (10k+ PDFs), pipelines RAG haute volumétrie, applications qui doivent rendre / éditer PDFs. **Attention licence AGPL-3.0** ou licence commerciale Artifex — si tu vends un SaaS qui utilise PyMuPDF, la licence commerciale s'impose (sinon AGPL contagieuse).

Module wrapper plus récent : **`pymupdf4llm`** → conversion PDF → Markdown structuré spécifiquement pour LLM/RAG, alternative locale à LlamaParse.

## Quand l'utiliser

- **Volume élevé** (10k+ PDFs) : la vitesse fait la différence
- **Extraction texte + images + metadata** en un seul tool
- **Rendering pages → images** : `page.get_pixmap()` pour thumbnails, preview, OCR downstream
- **Search + highlight** dans PDFs (annotations)
- **Edition** : merge, split, watermark, redact, encrypt
- **Combo OCR** : Tesseract intégré pour PDFs scannés (`page.get_textpage_ocr()`)
- **`pymupdf4llm`** pour RAG : conversion Markdown structurée, headers, tables
- **OCR + extraction** combinés dans un seul pipeline

## Quand NE PAS l'utiliser

- **Layout tables complexes** : [[pdfplumber]] / Camelot meilleurs pour ça
- **RAG element-aware** (Title/NarrativeText/Table typés) → [[Unstructured]] / [[Docling]]
- **Quality ML transformer** (mise en page complexe, formules) → [[Marker]] / [[Docling]]
- **Licence permissive obligatoire** : AGPL contagieuse → utiliser **pypdf** ou pdfplumber (MIT)
- **SaaS commercial sans budget licence** : AGPL ne permet pas SaaS closed-source → acheter licence commerciale Artifex

## Pièges connus

- **Licence AGPL-3.0 ou commerciale** : contamine ton code si publié. SaaS commercial → licence Artifex (4-5 chiffres / an typiques)
- **API moins Pythonic** : héritée de C, `import fitz`, `doc = fitz.open(...)`, `page.get_text()` — pas mauvais mais singulier
- **Pas de chunking RAG natif** (sauf via `pymupdf4llm`)
- **Cellules de tables détectées différemment** que pdfplumber → résultats divergents sur mêmes PDFs
- **Coordonnées Y inversées** selon version : MuPDF utilise un système où Y va vers le bas (logique image) → confusion fréquente
- **Memory leaks possibles** sur très long-running jobs : `doc.close()` explicite recommandé
- **OCR Tesseract intégré** demande Tesseract installé sur le système (pas trivial Windows)
- **Versions PyMuPDF récentes** : refactor API en 1.24+, certains examples web obsolètes
- **Multi-threading** : pas thread-safe partout → un `fitz.Document` par thread

## Code minimal

```bash
pip install pymupdf            # ou pymupdf4llm pour RAG
```

```python
import fitz  # alias historique de pymupdf

# Extraction texte rapide
doc = fitz.open("rapport.pdf")
print(f"{len(doc)} pages, {doc.metadata}")
full_text = "\n".join(page.get_text() for page in doc)
doc.close()
```

```python
# Extraction structuree (text blocks avec bbox)
doc = fitz.open("rapport.pdf")
for page in doc:
    blocks = page.get_text("dict")["blocks"]
    for block in blocks:
        if block["type"] == 0:  # text
            for line in block["lines"]:
                for span in line["spans"]:
                    print(span["bbox"], span["font"], span["size"], span["text"])
```

```python
# Rendering page -> image
import fitz
doc = fitz.open("doc.pdf")
page = doc[0]
pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))   # 2x zoom = ~144 DPI
pix.save("page1.png")
```

```python
# OCR sur PDF scanne (Tesseract en backend)
doc = fitz.open("scanned.pdf")
for page in doc:
    tp = page.get_textpage_ocr(language="fra", dpi=200)
    text = page.get_text(textpage=tp)
    print(text[:500])
```

```python
# pymupdf4llm : conversion Markdown structuree pour RAG
import pymupdf4llm

md_text = pymupdf4llm.to_markdown("rapport.pdf")
# Markdown propre : titres hierarchiques, listes, tableaux GFM, images extraites
print(md_text[:1000])

# Avec chunking page-by-page pour RAG
chunks = pymupdf4llm.to_markdown("rapport.pdf", page_chunks=True)
for chunk in chunks:
    print(chunk["metadata"]["page"], chunk["text"][:200])
```

```python
# Edition : merger 2 PDFs, ajouter watermark
a = fitz.open("a.pdf")
b = fitz.open("b.pdf")
a.insert_pdf(b)
a.save("merged.pdf")

doc = fitz.open("merged.pdf")
for page in doc:
    page.insert_text((50, 50), "CONFIDENTIEL", fontsize=40,
                     color=(1, 0, 0), rotate=45)
doc.save("watermarked.pdf")
```

## Liens

- [[pdfplumber]] — alternative meilleure pour tables (plus lente, MIT)
- [[Unstructured]] / [[Docling]] — alternatives RAG element-aware
- [[Marker]] — alternative ML (transformers Surya/Texify)
- pypdf — alternative pure Python, MIT (édition / split / merge)
- pikepdf — wrapper QPDF, MIT, édition uniquement
- pymupdf4llm — module sœur pour RAG
- Docs : https://pymupdf.readthedocs.io/
- GitHub : https://github.com/pymupdf/PyMuPDF
- Licence commerciale Artifex : https://artifex.com/licensing
