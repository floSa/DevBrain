---
galaxie: wiki
nom: mcp-filesystem
type: mcp-server
plateforme: universel
categorie: skill/dev-flow
sous_categories: [filesystem, files, fs-access]
auteur: Model Context Protocol team (modelcontextprotocol)
source: "@modelcontextprotocol/server-filesystem"
source_url: https://github.com/modelcontextprotocol/servers/tree/main/src/filesystem
install_cmd: "claude mcp add fs --command npx --args -y @modelcontextprotocol/server-filesystem /chemin/autorisé"
install_doc: https://github.com/modelcontextprotocol/servers
licence: MIT
licence_type: open-source
domaines: [data-science, data-eng, mlops, ml-eng, ai-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [mcp, filesystem, dev-flow]
---

# mcp-filesystem

## Pourquoi

MCP server officiel pour donner à l'agent un **accès filesystem contrôlé** à un (ou plusieurs) répertoire. Différent de Claude Code qui voit déjà le CWD : ici tu peux exposer un dossier *en dehors* du projet (ex. ton dataset `~/data/`, ton dossier de notebooks `~/lab/`) sans changer de CWD.

C'est l'équivalent agentique de "monter un volume Docker" — borné, explicite, sandboxé.

## Quand l'utiliser

- Tu veux qu'un agent Claude Desktop accède à `~/Documents/` sans le lancer dans un répertoire spécifique
- Multi-dossiers : exposer plusieurs racines à la fois (`~/projets/A`, `~/datasets/`)
- Tu bosses depuis un projet mais tu veux que l'agent puisse aller voir tes datasets sans cd

## Quand NE PAS l'utiliser

- Claude Code dans un projet → il a déjà accès au CWD via ses outils natifs (`Read`, `Write`, `Glob`, `Grep`), pas besoin de MCP par-dessus
- Donner accès à tout `/` → mauvaise idée, sandbox toujours

## Comment l'installer

```bash
claude mcp add fs \
  --command npx \
  --args -y @modelcontextprotocol/server-filesystem ~/datasets ~/lab

claude mcp list   # "fs  ✓ Connected"
```

Voir [[_installer-un-skill]] section *MCP server*.

## Exemples d'usage

```
> liste les CSV dans ~/datasets de plus de 100 Mo
> compare la structure de ~/datasets/v1/ et ~/datasets/v2/
```

## Pièges connus

- Le chemin passé à `--args` est *l'unique* racine accessible — pas de remontée via `../`
- Sur Windows, utilise des chemins avec slashes ou échappe les backslashes correctement

## Liens

- Repo officiel : https://github.com/modelcontextprotocol/servers
- Doc MCP : https://modelcontextprotocol.io/
