---
galaxie: wiki
nom: Gradient descent and variants
alias: [SGD, gradient descent, mini-batch, momentum, Nesterov]
type: concept
categorie: concept/optimization
sous_categories: [sgd, momentum, nesterov, mini-batch, gradient-descent]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Cauchy 1847, Robbins-Monro 1951, Polyak 1964 (momentum), Nesterov 1983]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, optimization, gradient-descent, sgd, momentum]
---

# Gradient descent and variants

## TL;DR

Algorithme d'optimisation de base : à chaque step, faire un pas opposé au gradient $\theta \leftarrow \theta - \eta \nabla L(\theta)$. **Variantes selon le batch** : Batch GD (tout le dataset), SGD (1 sample), **mini-batch SGD (standard moderne)**. **Variantes accélérées** : momentum (mémoire des gradients passés), Nesterov (lookahead). Fondation de tout l'entraînement de modèles ML/DL.

## Le problème

Minimiser $L(\theta)$ une loss différentiable par rapport aux paramètres $\theta$. Pour les modèles ML modernes (millions à milliards de paramètres), les méthodes analytiques ne marchent pas — on est forcés au numérique itératif.

## L'idée

### Update de base

$$ \theta_{t+1} = \theta_t - \eta \nabla L(\theta_t) $$

où $\eta$ est le **learning rate**. Direction = opposé du gradient (descente la plus raide localement).

### Variantes selon le batch

#### Batch Gradient Descent (BGD)

Calcule le gradient sur **tout le dataset** :

$$ \nabla L(\theta) = \frac{1}{N} \sum_{i=1}^N \nabla \ell_i(\theta) $$

✅ Convergence stable, monotone
❌ Coût par step énorme, impossible si $N$ grand

#### Stochastic Gradient Descent (SGD pur)

Gradient sur **un seul sample** à la fois :

$$ \theta_{t+1} = \theta_t - \eta \nabla \ell_i(\theta_t) $$

✅ Coût par step minimal
❌ Très bruité, oscille beaucoup. En pratique presque jamais utilisé pur.

#### Mini-batch SGD (le standard moderne)

Gradient sur un **batch** de taille $B$ (typique : 32, 64, 128, 256, 512) :

$$ \theta_{t+1} = \theta_t - \eta \cdot \frac{1}{B} \sum_{i \in \text{batch}} \nabla \ell_i(\theta_t) $$

Compromis : bruité (SGD-like) mais vectorisable sur GPU. **Par défaut partout en deep learning.**

### Momentum (Polyak / Heavy Ball)

Au lieu de suivre le gradient brut, on **moyenne** les gradients passés via une **vélocité** $v_t$ :

$$ v_{t+1} = \mu v_t + \nabla L(\theta_t) $$
$$ \theta_{t+1} = \theta_t - \eta v_{t+1} $$

avec $\mu \in [0, 1]$ (typique : 0.9). Effet : **amortit les oscillations** dans les directions à forte courbure, **accélère** dans les directions plates.

Intuition physique : une boule qui roule en bas d'une vallée, accumulant de la vitesse.

### Nesterov Accelerated Gradient (NAG)

Variante avec **lookahead** : calculer le gradient à la position **future** prédite, pas la position actuelle.

$$ v_{t+1} = \mu v_t + \nabla L(\theta_t - \eta \mu v_t) $$
$$ \theta_{t+1} = \theta_t - \eta v_{t+1} $$

Théoriquement meilleure convergence (sur problèmes convexes : $O(1/t^2)$ vs $O(1/t)$ pour GD classique). En pratique : amélioration modeste sur ML non-convexe.

### Choix du learning rate

Critique. Trop haut → divergence. Trop bas → convergence lente. Stratégies :
- **Constant** : simple mais sous-optimal
- **Decay** : décroissance avec le temps (cf. [[Learning rate schedules]])
- **Adaptatif** : Adam et compagnie (cf. [[Adam optimizer]])
- **LR finder** (Cyclical LR, Leslie Smith) : sweep d'une plage et observer la courbe de loss

### Effet du batch size

- **Petit batch** (4-32) : gradient bruité = effet régularisant, généralisation meilleure. Coût par epoch plus élevé.
- **Grand batch** (1k+) : gradient moins bruité, training plus rapide, mais souvent généralisation moins bonne. Nécessite **warmup** + LR plus haut.
- **LR linear scaling** (Goyal 2017) : doubler le batch ⇒ doubler le LR (approximativement).

## Quand c'est utile

- **Tout entraînement de modèle paramétrique différentiable** : NN, régression logistique, GBM en mode online…
- **Baseline pour tester de nouveaux optimizers** (toujours comparer à SGD+momentum)
- **Pour les compétitions** : un SGD bien tuned bat souvent Adam
- **Robustesse en généralisation** : SGD+momentum tend à généraliser mieux qu'Adam sur ImageNet (Wilson et al. 2017)

## Quand ça ne marche pas / pièges

- **LR trop élevé** : loss explose (NaN). Solution : LR finder, gradient clipping, warmup.
- **LR trop bas** : convergence lentissime. Critère : si la loss n'a pas baissé après 100 batches, augmenter LR.
- **Plateau / minima locaux** : SGD pur s'y bloque facilement. Momentum aide.
- **Saddle points** en haute dim : très fréquents en DL. Le bruit du SGD aide à s'en échapper (paradoxalement).
- **Non-convexe** : pas de garantie d'atteindre le minimum global. Mais en pratique les minima locaux trouvés sont "bons enough" en DL.
- **Batch size mal géré** : changer le batch sans changer le LR → mauvaise convergence
- **Gradient explose** (RNN, deep nets sans normalisation) : gradient clipping par norme ou par valeur

## Code minimal

```python
import torch
import torch.nn as nn
import torch.optim as optim

model = nn.Linear(10, 1)
criterion = nn.MSELoss()

# SGD pur
optimizer = optim.SGD(model.parameters(), lr=0.01)

# SGD avec momentum (standard)
optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.9)

# Nesterov
optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.9, nesterov=True)

# Boucle d'entraînement type
for epoch in range(num_epochs):
    for X, y in train_loader:
        optimizer.zero_grad()
        loss = criterion(model(X), y)
        loss.backward()
        # Optionnel : gradient clipping (utile en RNN)
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
```

## Pour aller plus loin

- Ruder, *An overview of gradient descent optimization algorithms* (2017) — excellente review
- *Why Momentum Really Works* (Gabriel Goh, Distill 2017) — visualisations magnifiques
- Polyak, *Some methods of speeding up convergence* (1964) — paper momentum
- Nesterov, *A method for solving the convex programming problem* (1983) — paper NAG
- **Liens internes** : [[Adam optimizer]], [[Newton & quasi-Newton]], [[Learning rate schedules]], [[Convexity]], [[Loss landscape and saddle points]]
