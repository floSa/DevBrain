---
galaxie: dev
nom: TensorFlow
alias: [tensorflow, tf]
categorie: ml/dl-framework
sous_categories: [deep-learning, keras, gpu, production]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python (C++ core)
clients_officiels: [python, cpp, java, js]
plateforme: [linux, macos, windows, android, ios]
score: 3
mes_projets: []
alternatives: ["[[PyTorch]]", "[[JAX]]", Keras (multi-backend)]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, deep-learning, tensorflow]
url_officiel: https://www.tensorflow.org/
url_docs: https://www.tensorflow.org/api_docs
url_repo: https://github.com/tensorflow/tensorflow
---

# TensorFlow

## Pourquoi
Framework Google, historiquement dominant (avant 2020), aujourd'hui en recul face à PyTorch côté recherche. Reste fort sur : **production / mobile / edge** (TFLite), TPU, déploiement (TF Serving). Keras 3 multi-backend (TF/JAX/PyTorch) le rend plus flexible.

## Quand l'utiliser
- Stack TF existante (legacy, modèles entraînés en TF)
- Edge deployment (TFLite Android/iOS)
- TPU sans passer par JAX
- TensorFlow Extended (TFX) pipelines en prod
- Keras 3 si tu veux écrire du code multi-backend

## Quand NE PAS l'utiliser
- Recherche / fine-tuning LLM moderne → [[PyTorch]] (écosystème incomparable)
- Apple Silicon optim → MLX
- Code dynamique / debug interactif → PyTorch
- TPU avec compile XLA → [[JAX]] direct

## Pièges connus
- **TF 1 vs TF 2** : APIs très différentes, beaucoup de tutoriels online sont TF1 (à éviter)
- **Eager vs graph** : `@tf.function` compile en graph, debug devient harder
- **Keras** : Keras 2 (inclus TF) vs Keras 3 (multi-backend) — préférer Keras 3
- **GPU support** : `tensorflow` (CPU) vs `tensorflow[and-cuda]` vs Docker images officielles
- **Versionning conflits** : TF + CUDA + cuDNN + Python — matching strict
- **TFRecord** format : verbeux mais nécessaire pour pipelines tf.data

## Liens
- [[PyTorch]] — alternative dominante
- Keras (Tiangolo de Chollet) : https://keras.io/
- TFLite (mobile/edge) : https://www.tensorflow.org/lite
- TF Serving : voir Services/ML/TensorFlow Serving.md
- Docs : https://www.tensorflow.org/api_docs/python/tf
