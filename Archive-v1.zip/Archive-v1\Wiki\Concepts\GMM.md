---
galaxie: wiki
nom: Gaussian Mixture Models (GMM)
alias: [GMM, mélange gaussien, mixture of Gaussians, EM clustering]
type: concept
categorie: concept/ml
sous_categories: [clustering, probabilistic, em-algorithm, mixture, soft-clustering]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Dempster-Laird-Rubin 1977 (EM), Bishop PRML]
lecture_min: 8
created: 2026-05-19
modified: 2026-05-19
tags: [concept, ml, clustering, gmm, em, probabilistic]
---

# Gaussian Mixture Models (GMM)

## TL;DR

Modèle probabiliste de clustering : les données sont supposées générées par un **mélange de $K$ gaussiennes**, chacune avec sa moyenne, covariance, et poids. Estimer les paramètres par **algorithme EM** (Expectation-Maximization). Donne pour chaque point une **probabilité d'appartenance à chaque cluster** (soft clustering). Sélection de $K$ via **BIC/AIC**, pas elbow.

## Le problème

[[K-means]] partitionne **durement** : chaque point appartient à un seul cluster. Mais en pratique :
- Un point à la frontière de 2 clusters n'a aucune nuance — il devrait être "70% cluster A, 30% cluster B"
- Les clusters peuvent avoir des **formes elliptiques** (allongés, orientés) que K-means rate
- On veut un **modèle génératif** des données pour estimation de densité, anomalie, simulation

GMM résout ces 3 problèmes.

## L'idée

### Modèle génératif

On suppose que chaque observation $x \in \mathbb{R}^p$ est tirée :

1. Choisir un cluster $k \in \{1, \dots, K\}$ avec probabilité $\pi_k$ (poids du mélange, $\sum_k \pi_k = 1$)
2. Tirer $x \sim \mathcal{N}(\mu_k, \Sigma_k)$

**Densité du mélange** :

$$ p(x) = \sum_{k=1}^K \pi_k \cdot \mathcal{N}(x \mid \mu_k, \Sigma_k) $$

Paramètres à estimer : $\{\pi_k, \mu_k, \Sigma_k\}_{k=1}^K$.

### Algorithme EM (Expectation-Maximization)

Itère deux étapes :

**E-step** — calculer les **responsabilités** (proba a posteriori que $x_i$ vienne du cluster $k$) :

$$ \gamma_{ik} = \frac{\pi_k \cdot \mathcal{N}(x_i \mid \mu_k, \Sigma_k)}{\sum_{j=1}^K \pi_j \cdot \mathcal{N}(x_i \mid \mu_j, \Sigma_j)} $$

**M-step** — mettre à jour les paramètres en utilisant les responsabilités comme poids :

$$
\mu_k = \frac{\sum_i \gamma_{ik} x_i}{\sum_i \gamma_{ik}}, \quad
\Sigma_k = \frac{\sum_i \gamma_{ik} (x_i - \mu_k)(x_i - \mu_k)^\top}{\sum_i \gamma_{ik}}, \quad
\pi_k = \frac{1}{n}\sum_i \gamma_{ik}
$$

Répéter jusqu'à convergence de la log-vraisemblance.

### Types de covariance

- **full** : $\Sigma_k$ libre (orientations, étirements quelconques). Plus expressif, plus de paramètres.
- **tied** : tous les clusters partagent une même $\Sigma$. Moins paramètres.
- **diagonal** : $\Sigma_k$ diagonale (clusters axis-aligned). Compromis.
- **spherical** : $\Sigma_k = \sigma_k^2 I$. Équivalent K-means quand $\sigma_k$ tous égaux et $\pi_k$ uniforme.

### Sélection de $K$ — BIC/AIC

GMM est un modèle probabiliste → on peut comparer les modèles par **critères d'information** :

$$ \text{BIC} = -2 \cdot \log L + p \cdot \log n $$

Plus bas = meilleur. Pénalise la complexité (nombre de paramètres $p$). BIC plus conservateur qu'AIC.

Tester K = 1, 2, …, 15, sélectionner celui qui minimise BIC.

```python
bic_scores = []
for k in range(1, 16):
    gmm = GaussianMixture(n_components=k, covariance_type='full', random_state=0).fit(X)
    bic_scores.append(gmm.bic(X))
optimal_k = np.argmin(bic_scores) + 1
```

### Soft clustering

Pour chaque point $x_i$, GMM donne $\gamma_{i1}, \dots, \gamma_{iK}$ — proba d'appartenance à chaque cluster. Plus informatif qu'une assignation dure.

Cas d'usage :
- Détecter les points **ambigus** (max(γ) < 0.6) → frontière de clusters
- Pondérer dans un modèle downstream
- Quantifier l'incertitude

## Quand c'est utile

- Clusters **elliptiques** ou de tailles très différentes (K-means rate)
- Besoin de **proba d'appartenance** (soft assignment)
- **Anomaly detection** : log-likelihood bas = point peu probable
- **Estimation de densité** générale (avant tout autre traitement)
- Génération de données synthétiques (échantillonner depuis le modèle)
- Imputation de valeurs manquantes (multiple imputation via mixtures)

## Quand ça ne marche pas / pièges

- **Hypothèse gaussienne violée** (distributions très skewed, multimodales par cluster) → GMM rate. Bayesian Gaussian Mixture peut aider via priors.
- **Clusters non-convexes** (lunes entrelacées) → comme K-means, GMM échoue. Utiliser [[DBSCAN]].
- **Convergence vers minima locaux** : EM stochastique. Toujours `n_init=10` au moins.
- **Covariance `full` sur haute-dim** : trop de paramètres, overfitting. Utiliser `tied` ou `diagonal`.
- **Singularité** : un cluster peut "s'effondrer" sur un point unique → covariance singulière. Régulariser via `reg_covar=1e-6`.
- **Comparaison avec K-means** : GMM avec covariance spherical et πk uniformes ≈ K-means. GMM avec full = strictement plus expressif.

## Code minimal

```python
from sklearn.mixture import GaussianMixture, BayesianGaussianMixture
from sklearn.preprocessing import StandardScaler

X_std = StandardScaler().fit_transform(X)

# Sélection de K par BIC
bic_scores = []
for k in range(1, 11):
    gmm = GaussianMixture(n_components=k, covariance_type='full', random_state=0, n_init=10)
    gmm.fit(X_std)
    bic_scores.append(gmm.bic(X_std))
K = np.argmin(bic_scores) + 1
print(f"K optimal (BIC) = {K}")

# Modèle final
gmm = GaussianMixture(n_components=K, covariance_type='full', random_state=0, n_init=10).fit(X_std)
labels_hard = gmm.predict(X_std)              # cluster argmax
probas = gmm.predict_proba(X_std)              # soft assignment n × K
log_likelihood = gmm.score_samples(X_std)      # pour anomaly detection

# Anomalies : points avec faible likelihood
threshold = np.percentile(log_likelihood, 5)
anomalies = X_std[log_likelihood < threshold]

# Variante bayésienne (Dirichlet Process) — pas besoin de fixer K à l'avance
bgmm = BayesianGaussianMixture(n_components=20, weight_concentration_prior_type='dirichlet_process',
                                random_state=0).fit(X_std)
# Les composantes inutiles ont un poids ≈ 0
print(f"Composantes effectives : {(bgmm.weights_ > 0.01).sum()}")
```

## Implémentations concrètes

- `sklearn.mixture.GaussianMixture` — classique
- `sklearn.mixture.BayesianGaussianMixture` — Dirichlet Process, K auto
- [[PyMC]] — mixtures bayésiennes custom
- R : `mclust` package (référence académique, sélection covariance + K automatique)

## Pour aller plus loin

- Bishop, *Pattern Recognition and Machine Learning* (PRML) — chap. 9
- Dempster, Laird, Rubin, *Maximum Likelihood from Incomplete Data via the EM Algorithm* (JRSS-B 1977) — paper EM canonique
- **Liens internes** : [[K-means]] (cas particulier sphérique), [[DBSCAN]] (alternative non-paramétrique), [[Clustering evaluation]], [[PCA]] (souvent prétraitement)
