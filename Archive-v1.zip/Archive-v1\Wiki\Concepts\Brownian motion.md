---
galaxie: wiki
nom: Brownian motion
alias: [mouvement brownien, processus de Wiener, random walk, marche aléatoire]
type: concept
categorie: concept/probability
sous_categories: [brownian, wiener, random-walk, sde, diffusion]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Brown 1827, Bachelier 1900, Einstein 1905, Wiener 1923]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, probability, brownian, wiener]
---

# Brownian motion — mouvement brownien

## TL;DR

Processus stochastique à **temps continu** qui modélise une marche aléatoire infinitésimale. Caractérisé par : (1) trajectoires continues, (2) incréments indépendants gaussiens, (3) $W(t) - W(s) \sim \mathcal{N}(0, t-s)$. Fondation de la **finance quantitative** (Black-Scholes), des **équations différentielles stochastiques (SDE)**, et des **modèles de diffusion** modernes en deep learning génératif.

## Le problème

Modéliser un système qui évolue **en continu** sous l'effet de **bruit aléatoire** infinitésimal. Cas typiques : prix d'actifs, particules en suspension, dynamique de réseaux de neurones (large-scale limit), modèles génératifs par diffusion.

## L'idée

### Définition formelle

Un processus stochastique $\{W(t) : t \geq 0\}$ est un **mouvement brownien standard** (Wiener process) si :

1. $W(0) = 0$
2. **Incréments indépendants** : $W(t_2) - W(t_1)$ indépendant de $W(s_2) - W(s_1)$ pour intervalles disjoints
3. **Incréments gaussiens** : $W(t) - W(s) \sim \mathcal{N}(0, t - s)$
4. **Trajectoires continues** presque sûrement

### Propriétés

- $\mathbb{E}[W(t)] = 0$ pour tout $t$
- $\text{Var}(W(t)) = t$
- $\text{Cov}(W(s), W(t)) = \min(s, t)$
- Trajectoires **continues mais non-différentiables nulle part** (presque sûrement)
- Auto-similarité : $W(c t) \overset{d}{=} \sqrt{c} W(t)$ (scaling brownien)

### Construction comme limite de marches aléatoires

Le mouvement brownien est la **limite invariante** d'une marche aléatoire :

$$ S_n = \sum_{i=1}^n X_i, \quad X_i \overset{i.i.d.}{\sim} \pm 1 $$

En rescalant : $\frac{1}{\sqrt{n}} S_{\lfloor nt \rfloor} \xrightarrow{d} W(t)$ (théorème de Donsker, version fonctionnelle du TCL).

C'est l'analogue continu d'une **random walk symétrique**.

### Variantes

#### Mouvement brownien avec drift

$$ X(t) = \mu t + \sigma W(t) $$

Trajectoire moyenne $\mu t$ avec fluctuations $\sigma W(t)$. Modèle simple de prix d'actif.

#### Mouvement brownien géométrique

$$ S(t) = S_0 \exp\left(\left(\mu - \frac{\sigma^2}{2}\right) t + \sigma W(t)\right) $$

Solution de l'EDS $dS = \mu S dt + \sigma S dW$. **Modèle de Black-Scholes** pour prix d'actifs (toujours positif).

#### Pont brownien (Brownian bridge)

Mouvement brownien conditionné à $W(0) = W(T) = 0$. Utile pour interpolation, simulation conditionnelle.

#### Mouvement brownien fractionnaire

Variante avec **autocorrélation** : $\text{Var}(W^H(t) - W^H(s)) = |t - s|^{2H}$ avec $H \in (0, 1)$. Pour $H = 0.5$ → brownien standard. Pour $H > 0.5$ → corrélation positive long terme. Utilisé en finance, hydrologie.

### Équations différentielles stochastiques (SDE)

Forme générale :

$$ dX(t) = \mu(X, t) \, dt + \sigma(X, t) \, dW(t) $$

avec **drift** $\mu$ et **diffusion** $\sigma$. Résolution par calcul d'**Itô** (lemme d'Itô, intégrale stochastique).

Exemples célèbres :
- **Ornstein-Uhlenbeck** : $dX = -\theta X dt + \sigma dW$ — processus stable, retour à la moyenne
- **CIR** (Cox-Ingersoll-Ross) : $dr = a(b - r) dt + \sigma \sqrt{r} dW$ — modèle de taux d'intérêt
- **Heston** : modèle financier avec volatilité stochastique

### Modèles de diffusion en deep learning génératif

**Idée** (Ho et al. 2020 — DDPM) :
- **Forward process** : ajouter graduellement du bruit gaussien à une image, formulation SDE
- **Reverse process** : apprendre à débruiter, équivalent à une autre SDE

Score matching, classifier-free guidance, Stable Diffusion, ImageGen — toutes basées sur le brownien + son inversion.

### Score matching et SDE génératives

Forward SDE : $dx = f(x, t) dt + g(t) dW$ — ajoute bruit
Reverse SDE : $dx = [f(x, t) - g(t)^2 \nabla_x \log p_t(x)] dt + g(t) d\bar W$ — débruite

Apprendre le **score** $\nabla_x \log p_t(x)$ est l'objectif des modèles de diffusion modernes.

## Quand c'est utile

- **Finance quantitative** : Black-Scholes, options, modèles de taux
- **Modèles de diffusion** : Stable Diffusion, ImageGen, DALL-E 3 (génération d'images)
- **Score-based models** (Song et al.)
- **Bayesian deep learning** : SGD ≈ SDE → analyses théoriques (Mandt et al.)
- **Physique** : équation de Langevin, dynamique brownienne, simulations Monte-Carlo
- **Biologie** : dynamique de populations, génétique des populations (Fisher-Wright)
- **Anomaly detection** sur séries temporelles : modèle de référence

## Quand ça ne marche pas / pièges

- **Hypothèse de continuité des trajectoires** : violée par sauts (Poisson process, défauts de paiement). Utiliser Lévy processes.
- **Brownian non-différentiable** : on **ne peut pas** écrire $\frac{dW}{dt}$ au sens classique. Toujours via calcul d'Itô.
- **Itô vs Stratonovich** : deux conventions de calcul stochastique avec résultats différents pour les SDE non-linéaires. Itô est standard en ML/finance, Stratonovich en physique.
- **Discrétisation des SDE** : Euler-Maruyama est l'ordre 0 ; Milstein, Runge-Kutta stochastique ordre supérieur. Choix selon précision.
- **Modèles diffusion** : entraînement coûteux, sensible aux schedule de bruit (cosine, sigmoid)
- **Black-Scholes en réalité** : hypothèses violées (volatilité non-constante, queues lourdes). Utilisé quand même comme baseline.

## Code minimal

```python
import numpy as np
import matplotlib.pyplot as plt

# Simulation mouvement brownien standard
def simulate_brownian(T, n_steps, n_paths=1):
    dt = T / n_steps
    increments = np.random.normal(0, np.sqrt(dt), (n_paths, n_steps))
    W = np.cumsum(increments, axis=1)
    W = np.concatenate([np.zeros((n_paths, 1)), W], axis=1)
    return W  # shape (n_paths, n_steps + 1)

W = simulate_brownian(T=1, n_steps=1000, n_paths=5)
plt.plot(np.linspace(0, 1, 1001), W.T)
plt.title("Mouvement brownien")

# Mouvement brownien géométrique (Black-Scholes)
def gbm(S0, mu, sigma, T, n_steps, n_paths=1):
    W = simulate_brownian(T, n_steps, n_paths)
    t = np.linspace(0, T, n_steps + 1)
    S = S0 * np.exp((mu - 0.5 * sigma**2) * t + sigma * W)
    return S

S = gbm(S0=100, mu=0.05, sigma=0.2, T=1, n_steps=252, n_paths=100)
# 100 trajectoires de prix sur 1 an, drift 5%, volatilité 20%

# Schéma Euler-Maruyama pour SDE générale
def euler_maruyama(mu_fn, sigma_fn, X0, T, n_steps):
    dt = T / n_steps
    X = np.zeros(n_steps + 1)
    X[0] = X0
    for i in range(n_steps):
        dW = np.random.normal(0, np.sqrt(dt))
        X[i+1] = X[i] + mu_fn(X[i], i*dt) * dt + sigma_fn(X[i], i*dt) * dW
    return X

# Ornstein-Uhlenbeck : retour à la moyenne
def ou_drift(x, t, theta=1.0, mu=2.0): return theta * (mu - x)
def ou_sigma(x, t, sigma=0.5): return sigma

X_ou = euler_maruyama(ou_drift, ou_sigma, X0=0, T=10, n_steps=1000)
```

## Pour aller plus loin

- Karatzas & Shreve, *Brownian Motion and Stochastic Calculus* (2e éd. 1991) — référence
- Øksendal, *Stochastic Differential Equations* — pédagogique
- Ho, Jain, Abbeel, *Denoising Diffusion Probabilistic Models* (NeurIPS 2020) — DDPM
- Song et al., *Score-Based Generative Modeling through Stochastic Differential Equations* (ICLR 2021)
- **Liens internes** : [[Markov chains]], [[Central limit theorem]], [[MCMC]] (Langevin = SDE), [[Gradient descent]] (SGD ≈ SDE)
