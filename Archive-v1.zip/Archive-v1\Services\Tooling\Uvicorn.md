---
galaxie: dev
nom: Uvicorn
alias: [uvicorn]
categorie: tooling/server
sous_categories: [asgi, http-server, async, fastapi]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: [Hypercorn, Daphne, Granian, Gunicorn (WSGI)]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, asgi, server]
url_officiel: https://www.uvicorn.org/
url_docs: https://www.uvicorn.org/
url_repo: https://github.com/encode/uvicorn
---

# Uvicorn

## Pourquoi
Serveur **ASGI** standard pour Python — basé sur uvloop + httptools (rapides en C). C'est le serveur qui fait tourner FastAPI, Starlette, Litestar. Utilisé en prod par des milliers de services. Successeur de Gunicorn pour le monde async.

## Quand l'utiliser
- Servir [[FastAPI]] / Starlette en dev et prod
- Apps WebSocket (ASGI gère natif)
- Apps HTTP/2 (avec h2)
- Pipeline async I/O bound

## Quand NE PAS l'utiliser
- App WSGI legacy → Gunicorn + sync workers
- CPU bound → process pool, pas async
- Edge / Lambda → Mangum + Lambda runtime
- High-concurrency Rust-level → Granian (Rust-based ASGI)

## Pièges connus
- **Workers vs threads** : `--workers N` lance N processes (pour scale CPU), pas du threading (qui ne sert à rien en Python async)
- **Reload en dev** : `--reload` mais surveille seulement Python files par défaut
- **Production** : derrière Nginx/Caddy ou directement (Uvicorn gère HTTP/2)
- **Graceful shutdown** : SIGTERM attend max `--timeout-graceful-shutdown` (défaut 30s)
- **Logging** : par défaut `--log-config` Python logging, peut être surchargé
- **uvloop** : `uvicorn[standard]` l'installe automatiquement (sauf Windows où pas dispo)

## Liens
- [[FastAPI]] — combo classique
- Granian (alternative Rust) : https://github.com/emmett-framework/granian
- Docs : https://www.uvicorn.org/
- Deployment : https://www.uvicorn.org/deployment/
