---
galaxie: dev
nom: Grafana
alias: [grafana]
categorie: observability/dashboard
sous_categories: [monitoring, metrics, dashboard, visualization, alerting, lgtm]
licence: AGPL-3.0 (OSS) / Commercial (Enterprise)
licence_type: open-source
hosted: self ou cloud (Grafana Cloud)
maturite: production
langage: Go / TypeScript
clients_officiels: [http, terraform, ansible, sdk-go, sdk-python]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: ["Datadog", "Kibana", "New Relic", "Dynatrace", "Chronograf"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, observability, monitoring, metrics, dashboard]
url_officiel: https://grafana.com/
url_docs: https://grafana.com/docs/grafana/latest/
url_repo: https://github.com/grafana/grafana
---

# Grafana

## Pourquoi

Plateforme de **dashboards observability** open-source — le **standard de facto** pour visualiser metrics, logs et traces depuis 2014. Multi-datasource : Prometheus, [[Loki]], InfluxDB, Postgres, MySQL, CloudWatch, Elasticsearch, Tempo, Jaeger, Mimir, Thanos, OpenSearch (50+ datasources natifs).

Cœur de la **stack LGTM** (Loki Grafana Tempo Mimir) — la suite open-source Grafana Labs. **Grafana Alerting** unifié (depuis v8) remplace les alertes Prometheus / Loki / etc. par un système unique. Grafana Cloud (managed) et Enterprise (RBAC fin, support, plugins premium) sont les offres payantes.

**Licence AGPLv3 depuis Grafana 11+** : si tu modifies Grafana et le sers à des users externes, tu dois publier les modifs.

## Quand l'utiliser

- **Dashboards multi-sources** : visualiser Prometheus + Postgres + Loki dans une même vue
- **Stack LGTM** : Loki (logs) + Grafana (dashboards) + Tempo (traces) + Mimir (metrics scale)
- **Alertes unifiées** : Grafana Alerting (multi-datasource, routing Slack/PagerDuty)
- **Standard infra monitoring** : K8s, Postgres, Redis, app metrics
- **Combo Prometheus** : datasource par défaut, requêtes PromQL natives
- **Combo [[Langfuse]] / business metrics** : datasource Postgres direct
- **Provisioning as code** : Terraform provider, JSON files versionnés
- **Dashboards communautaires** : grafana.com/dashboards, 5000+ existants

## Quand NE PAS l'utiliser

- **Dashboards LLM-specific** → [[Langfuse]] / [[Helicone]] / LangSmith (tracing LLM dédié)
- **Setup tout-en-un sans Prometheus** : Grafana = visualisation, il te faut une datasource derrière
- **Single-pane SaaS commercial** : Datadog / New Relic / Dynatrace (plus turn-key, plus cher)
- **Logs structurés analytics massif** : Kibana (Elastic stack) historiquement plus mature pour ça (Loki moderne rattrape)
- **Pas d'équipe ops** : Grafana self-host demande maintenance → Grafana Cloud

## Pièges connus

- **Licence AGPLv3 (Grafana 11+)** : contagieuse si tu modifies et exposes → check compliance commerciale
- **Versions OSS vs Enterprise** : RBAC fin, SAML, audit avancé = Enterprise payant
- **Dashboards complexes en JSON** : export/import JSON, diff lisible dur → versionner via Grafana as Code (terraform / grizzly / grafonnet)
- **Plugins inégaux en qualité** : core OK, community varie
- **Setup auth LDAP / OIDC / SAML** verbeux : fichier `ldap.toml`, `auth.generic_oauth` à configurer
- **Variables de dashboard** : puissantes mais magiques (`$var`, `${var:csv}`) — debugging dur
- **Provisioning vs UI** : créer en UI puis exporter en JSON pour versionnage = workflow pas super
- **Time range global vs per-panel** : pièges quand un panel a son propre range
- **PromQL learning curve** : queries complexes (rate, increase, histogram_quantile) demandent du métier
- **Annotation surcharge** : si trop d'events annotations, dashboards rament
- **Grafana 10/11/12 breaking changes** : panel options renommées, vérifier upgrade notes
- **Multi-tenancy OSS limitée** : orgs OK mais RBAC fin = Enterprise

## Code minimal

```bash
# Lancer Grafana via Docker
docker run -d --name grafana \
    -p 3000:3000 \
    -e "GF_SECURITY_ADMIN_PASSWORD=admin" \
    -v grafana-storage:/var/lib/grafana \
    grafana/grafana:11.3.0
# UI : http://localhost:3000, login admin/admin
```

```yaml
# datasource provisioning (grafana/provisioning/datasources/prom.yml)
apiVersion: 1
datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
  - name: Loki
    type: loki
    access: proxy
    url: http://loki:3100
  - name: Postgres-app
    type: postgres
    url: postgres:5432
    database: app
    user: grafana_ro
    secureJsonData:
      password: $POSTGRES_RO_PASSWORD
    jsonData:
      sslmode: disable
      postgresVersion: 1500
```

```yaml
# docker-compose.yml stack LGTM minimaliste
version: "3"
services:
  prometheus:
    image: prom/prometheus:v2.55.0
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
    ports: ["9090:9090"]

  loki:
    image: grafana/loki:3.2.0
    ports: ["3100:3100"]

  grafana:
    image: grafana/grafana:11.3.0
    ports: ["3000:3000"]
    volumes:
      - ./provisioning:/etc/grafana/provisioning
      - ./dashboards:/var/lib/grafana/dashboards
    environment:
      GF_SECURITY_ADMIN_PASSWORD: admin
```

```python
# Requete API Grafana (creer dashboard programmatiquement)
import requests, json

GRAFANA_URL = "http://localhost:3000"
TOKEN = "glsa_..."   # Service Account Token

dashboard = {
    "dashboard": {
        "title": "My App",
        "panels": [{
            "id": 1, "title": "Requests/s",
            "type": "timeseries",
            "datasource": {"type": "prometheus", "uid": "prometheus-uid"},
            "targets": [{
                "expr": 'rate(http_requests_total[5m])',
                "legendFormat": "{{method}} {{status}}",
            }],
            "gridPos": {"x": 0, "y": 0, "w": 24, "h": 8},
        }],
        "refresh": "30s",
    },
    "overwrite": True,
}

response = requests.post(
    f"{GRAFANA_URL}/api/dashboards/db",
    headers={"Authorization": f"Bearer {TOKEN}"},
    json=dashboard,
)
print(response.json())
```

```yaml
# Grafana Alerting (provisioning/alerting/rules.yml)
apiVersion: 1
groups:
  - name: app-alerts
    interval: 1m
    rules:
      - uid: high-error-rate
        title: High 5xx rate
        condition: A
        data:
          - refId: A
            datasourceUid: prometheus-uid
            model:
              expr: 'sum(rate(http_requests_total{status=~"5.."}[5m])) / sum(rate(http_requests_total[5m])) > 0.05'
        for: 5m
        labels: {severity: critical}
        annotations:
          summary: "5xx rate above 5% for 5m"
```

## Liens

- Prometheus — datasource principal (metrics)
- [[Loki]] — combo logs (Grafana Labs)
- Tempo — combo traces (Grafana Labs)
- Mimir — combo Prometheus scale (Grafana Labs)
- Pyroscope — combo profiling (Grafana Labs)
- Datadog / New Relic / Dynatrace — alternatives SaaS commerciales
- Kibana — alternative (stack Elastic)
- Grafana as Code : grizzly, grafonnet, terraform-provider-grafana
- Docs : https://grafana.com/docs/grafana/latest/
- GitHub : https://github.com/grafana/grafana
