---
galaxie: wiki
nom: Imitation learning
alias: [imitation learning, behavioral cloning, BC, DAgger, GAIL, inverse RL, IRL]
type: concept
categorie: concept/ml
sous_categories: [rl, imitation, behavioral-cloning, dagger, irl, gail]
domaines: [ml-eng, ai-eng]
maturite: established
auteurs_cles: [Pomerleau 1989 (ALVINN), Ross 2011 (DAgger), Ho & Ermon 2016 (GAIL), Ng & Russell 2000 (IRL)]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, rl, imitation-learning]
---

# Imitation learning

## TL;DR

Apprendre une politique en **imitant un expert** plutôt qu'en explorant via récompenses. Trois familles : **Behavioral Cloning (BC)** — pure supervised learning sur les actions de l'expert, simple mais souffre du **compounding error** ; **DAgger** — BC interactif qui corrige le distribution shift ; **Inverse RL / GAIL** — apprendre la fonction de récompense puis faire du RL standard. En LLMs, le [[SFT]] (supervised fine-tuning) **est de la BC** sur conversations expertes. Imitation learning est souvent le **point de départ** avant RL (warm-start) ou la solution finale quand on a beaucoup de démonstrations.

## Le problème

RL classique demande des **récompenses** bien définies — souvent absentes ou mal spécifiées en pratique. Mais on a souvent :
- Des **démonstrations** d'experts (conduite humaine, chirurgie robot, conversations humaines, parties d'échecs)
- Pas de bon reward signal (qu'est-ce qu'une "bonne conversation" en chiffres ?)

**Idée** : reproduire ce que l'expert fait, sans nécessairement modéliser pourquoi.

## L'idée

### Behavioral Cloning (BC, Pomerleau 1989)

Le plus simple : entraîner $\pi_\theta(a | s)$ par **maximum likelihood** sur les paires $(s, a)$ de l'expert :

$$ \mathcal{L}_{BC}(\theta) = -\mathbb{E}_{(s, a) \sim \pi_{\text{expert}}} \log \pi_\theta(a | s) $$

C'est de la **classification / régression supervisée** classique. Si tu vois "BC" dans un papier, c'est juste ça.

**Application notable** : NVIDIA ALVINN (1989), conduite autonome par CNN sur images, premier deep IL appliqué.

#### Problème : compounding errors

BC est **myope** : chaque action est apprise indépendamment, sans comprendre la séquence. Quand le modèle est déployé :

1. Légère erreur à $t=1$ → état $s_2$ légèrement OOD
2. Le modèle voit un état un peu hors distribution → erreur plus grande à $t=2$
3. ... compound...
4. À $t=100$, état complètement hors distribution → comportement aléatoire

Formellement : erreur quadratique en $T$ (vs linéaire pour expert-supervised RL avec un bon reward).

**Démontré** par Ross & Bagnell (2010) : "BC has $O(T^2)$ regret in the worst case."

### DAgger (Dataset Aggregation, Ross 2011)

Solution au compounding error : **re-query l'expert** sur les états visités par la politique courante, ajouter au dataset.

```
D ← {(s, a) | s ~ π_expert}      # dataset initial
π ← BC(D)
pour i = 1..N :
    rollout π → trajectoires de states {s_t}
    pour chaque s_t : demander à l'expert a*_t = π_expert(s_t)
    D ← D ∪ {(s_t, a*_t)}
    π ← BC(D)                     # ré-entraîner sur dataset agrégé
```

Convergence vers une politique avec regret **$O(T)$**, optimal. Mais nécessite l'expert **online** (cher : un humain qui annote, ou un MPC qu'on peut consulter à la demande).

### Variantes interactives

- **AggreVaTe** (Ross 2014) : DAgger + signal de valeur cost-to-go de l'expert
- **HG-DAgger** : safety constraints
- **Robot learning from demonstrations** : DAgger en pratique en robotique (Drews 2017)

### Inverse Reinforcement Learning (IRL, Ng & Russell 2000)

**Approche différente** : au lieu d'imiter directement, **récupérer la fonction de récompense** que l'expert maximise implicitement, puis faire du RL standard avec elle.

**Pourquoi** : généralise mieux que BC. Un RM bien estimé permet à la politique de gérer des situations non vues dans les démonstrations.

**Difficulté** : la fonction de récompense est sous-déterminée (plusieurs récompenses expliquent les mêmes démonstrations). Solutions : **max-entropy IRL** (Ziebart 2008), **GAIL** (adversarial).

### GAIL — Generative Adversarial Imitation Learning (Ho & Ermon 2016)

**Idée GAN** appliquée à l'imitation :
- **Discriminateur** $D_\phi(s, a)$ : essaie de distinguer expert trajectories d'apprenant trajectories
- **Generateur** = politique $\pi_\theta$ : essaie de tromper $D$

$$ \min_\pi \max_D \mathbb{E}_{\pi}[\log D(s, a)] + \mathbb{E}_{\pi_E}[\log(1 - D(s, a))] $$

La politique reçoit comme reward $-\log D(s, a)$ (positif quand le discriminateur la confond avec l'expert), optimisée par TRPO/PPO.

Performance : meilleure que BC, sans nécessité d'expert online. Mais **instable** (GAN training).

**Extensions** : AIRL (récupère vraie reward), DAC (Discriminator Actor-Critic), VICE.

### Soft Q Imitation Learning (SQIL, Reddy 2020)

Trick simple : **donner reward 1 sur démonstrations expertes, 0 ailleurs**, faire du Q-learning standard. Souvent comparable à GAIL en pratique, beaucoup plus simple.

### Decision Transformer / sequence modeling

[[Offline RL]] via DT peut aussi être vu comme de l'imitation conditionnée par return. Et BC = DT sans conditioning sur return.

### Imitation learning et LLMs

**Le [[SFT]] (supervised fine-tuning) d'un LLM est de la behavioral cloning** :
- "Démonstrations" = paires (prompt, réponse) écrites par humains ou modèles plus puissants
- $\pi_\theta$ = LLM en cours d'entraînement
- Loss = cross-entropy sur next-token prediction

Pourquoi SFT seul ne suffit pas pour aligner ? Compounding errors token-by-token, et SFT ne pénalise pas les mauvaises réponses → besoin de RLHF / DPO ensuite — voir [[RLHF and DPO]].

InstructGPT, Alpaca, Vicuna, Llama-Instruct : tous commencent par du SFT (BC) avant l'alignment.

### Imitation learning et RAG / agents

**Process supervision dans les agents LLM** : on annote chaque étape d'un agent comme "bonne" ou "mauvaise", on fait du SFT sur les bonnes trajectoires. C'est de la BC sur des trajectoires d'agent.

ReAct, ToolLLM, AgentBench → datasets de "trajectoires expertes" sur tool use.

### Combinaison IL + RL

Workflow standard en robotique et LLMs :
1. **BC / SFT** initial pour bootstrap (politique vaguement compétente)
2. **RL / RLHF** pour raffiner et dépasser l'expert

Sans étape 1, RL souvent ne converge pas (exploration trop large). Sans étape 2, on est plafonné par l'expert.

## Quand c'est utile

- **Démonstrations expertes abondantes** : conduite humaine logs, conversations humaines, chirurgie robot
- **Pas de bonne récompense définissable** : "écrire une bonne réponse" = pas de formule
- **Warm-start RL** : initialiser une politique avant fine-tuning RL — comme SFT avant PPO RLHF
- **Robotique** : démonstrations kinesthésiques, teleoperation
- **Conduite autonome** : datasets immenses de conduite humaine
- **LLMs** : SFT sur instructions et conversations (ChatGPT, Claude, etc.)
- **Safety** : commencer par BC pour ne pas explorer dangereusement
- **Sample efficiency** : si tu as 100k démonstrations, BC vaut peut-être mieux que RL from scratch

## Quand ça ne marche pas / pièges

- **Compounding errors** : c'est *le* problème de BC, surtout en horizon long. Mitigation : DAgger, SQIL, augmenter dataset
- **Expert sous-optimal** : tu ne peux pas dépasser ton expert avec BC pure → besoin de RL ensuite
- **États rares mal couverts** : la politique panique sur OOD. Solution : data augmentation, ajout de bruit, DAgger
- **Distributional shift train/deploy** : démos prises avec assistance humaine ≠ déploiement seul (cas conduite autonome)
- **Annotation cost** : DAgger demande l'expert pendant le training → cher
- **GAIL instability** : training adversarial est fragile, hyperparams sensibles
- **Causal confusion** : BC peut apprendre les "fausses corrélations" (e.g. "appuie sur le frein quand tu vois un feu rouge" mais aussi "appuie quand un feu vert passe au rouge" → erreurs)
- **Reward shaping caché dans la démo** : l'expert a optimisé une certaine fonction, peut-être pas la tienne
- **Mode covering vs mode seeking** : BC (forward KL) capture toutes les modes, GAIL (reverse KL) en sélectionne une — préférable selon usage
- **IRL ambigüe** : plusieurs reward functions expliquent les mêmes données → solution non unique

## Code minimal

```python
# Behavioral Cloning pour actions discrètes
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

# states : (N, obs_dim), actions : (N,) labels
states = torch.randn(10_000, 4)
actions = torch.randint(0, 2, (10_000,))

policy = nn.Sequential(nn.Linear(4, 128), nn.ReLU(), nn.Linear(128, 2))
opt = optim.Adam(policy.parameters(), lr=1e-3)
loader = DataLoader(TensorDataset(states, actions), batch_size=64, shuffle=True)

for epoch in range(20):
    for s, a in loader:
        logits = policy(s)
        loss = nn.functional.cross_entropy(logits, a)
        opt.zero_grad(); loss.backward(); opt.step()
```

```python
# BC pour actions continues : régression sur l'action
class BCPolicy(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden=256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, act_dim),
        )
    def forward(self, x): return self.net(x)

policy = BCPolicy(obs_dim=11, act_dim=3)
opt = optim.Adam(policy.parameters(), lr=3e-4)

for epoch in range(50):
    for s, a in loader_continuous:
        pred = policy(s)
        loss = ((pred - a) ** 2).mean()    # MSE
        opt.zero_grad(); loss.backward(); opt.step()
```

```python
# DAgger : boucle itérative
import numpy as np

def dagger(env, expert_policy, learner, n_iter=10, rollout_len=500):
    D_states, D_actions = [], []

    # 1. Init dataset depuis expert pure
    for _ in range(rollout_len):
        s, _ = env.reset()
        done = False
        while not done:
            a = expert_policy(s)
            D_states.append(s); D_actions.append(a)
            s, _, term, trunc, _ = env.step(a)
            done = term or trunc

    for iteration in range(n_iter):
        # 2. Train learner sur D
        train_supervised(learner, D_states, D_actions, epochs=10)

        # 3. Rollout learner, query expert sur ses états
        for _ in range(rollout_len):
            s, _ = env.reset()
            done = False
            while not done:
                a_learner = learner.predict(s)
                a_expert = expert_policy(s)       # ← key step : DAgger query
                D_states.append(s); D_actions.append(a_expert)
                s, _, term, trunc, _ = env.step(a_learner)
                done = term or trunc

    return learner
```

```python
# GAIL principe (PPO + discriminator reward)
class Discriminator(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim + act_dim, 128), nn.Tanh(),
            nn.Linear(128, 128), nn.Tanh(),
            nn.Linear(128, 1),
        )
    def forward(self, s, a):
        return self.net(torch.cat([s, a], dim=-1))

def gail_step(disc, policy_batch, expert_batch):
    # Discriminator : distinguer expert (label 0) de policy (label 1)
    s_p, a_p = policy_batch
    s_e, a_e = expert_batch
    d_p = disc(s_p, a_p); d_e = disc(s_e, a_e)
    loss_d = (nn.functional.binary_cross_entropy_with_logits(d_p, torch.ones_like(d_p)) +
              nn.functional.binary_cross_entropy_with_logits(d_e, torch.zeros_like(d_e)))
    # Reward pour policy : -log D(s, a) (haut = ressemble à expert)
    policy_reward = -torch.log(torch.sigmoid(d_p) + 1e-8).detach()
    return loss_d, policy_reward
```

```python
# SFT = BC pour LLMs (via HuggingFace TRL)
from trl import SFTTrainer, SFTConfig
from transformers import AutoTokenizer, AutoModelForCausalLM
from datasets import load_dataset

model_id = "meta-llama/Meta-Llama-3-8B"
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype="bf16")
ds = load_dataset("HuggingFaceH4/ultrachat_200k")

config = SFTConfig(
    output_dir="./sft-llama3",
    per_device_train_batch_size=4,
    learning_rate=2e-5, num_train_epochs=1,
    max_seq_length=2048, bf16=True,
)
trainer = SFTTrainer(model=model, args=config,
                     train_dataset=ds["train_sft"], tokenizer=tokenizer)
trainer.train()
# C'est de la behavioral cloning sur des conversations expertes.
```

## Pour aller plus loin

- Pomerleau, *ALVINN: An Autonomous Land Vehicle in a Neural Network* (NeurIPS 1989)
- Ross et al., *A Reduction of Imitation Learning and Structured Prediction to No-Regret Online Learning* (DAgger, AISTATS 2011)
- Ng & Russell, *Algorithms for Inverse Reinforcement Learning* (ICML 2000)
- Ziebart et al., *Maximum Entropy Inverse Reinforcement Learning* (AAAI 2008)
- Ho & Ermon, *Generative Adversarial Imitation Learning* (NeurIPS 2016)
- Reddy et al., *SQIL: Imitation Learning via RL with Sparse Rewards* (ICLR 2020)
- Osa et al., *An Algorithmic Perspective on Imitation Learning* (FnT, 2018) — survey
- Hester et al., *Deep Q-learning from Demonstrations* (DQfD, AAAI 2018) — combo IL + RL
- **Liens internes** : [[Offline RL]], [[Reinforcement learning]], [[SFT]], [[RLHF and DPO]], [[Reward modeling]], [[Policy gradient]]
