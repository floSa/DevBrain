---
galaxie: wiki
nom: Hybrid retrieval
alias: [BM25, RRF, sparse + dense, hybrid search, SPLADE]
type: concept
categorie: concept/rag
sous_categories: [retrieval, hybrid, bm25, rrf, sparse]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Robertson 2009 (BM25), Cormack 2009 (RRF), Formal 2021 (SPLADE)]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, rag, retrieval, hybrid, bm25]
---

# Hybrid retrieval

## TL;DR

Combiner **recherche lexicale (sparse, mots-clés)** comme BM25 + **recherche sémantique (dense, embeddings)** pour avoir le meilleur des deux. **BM25** capture les **noms propres, jargon technique, exact match** que les embeddings ratent. **Dense** capture la sémantique et paraphrase. **Fusion** via **RRF (Reciprocal Rank Fusion)** ou linear weighted combination. **SPLADE** : sparse appris par neural net (compromis intéressant). Hybrid retrieval = **gain 5-15% recall** vs dense seul. Standard moderne pour RAG production (Elasticsearch, Qdrant hybrid, Weaviate, pgvector + tsvector).

## Le problème

[[embeddings]] **denses** sont sémantiquement riches mais **ratent** :
- **Noms propres** : "GPT-4o" peut être encodé loin de "GPT-4"
- **Identifiers** : numéros de série, codes
- **Jargon** : termes très spécifiques jamais vus en pretraining
- **Exact match** : "find documents mentioning XYZ-123"

À l'inverse, **BM25** est nul sur paraphrase et sémantique.

→ **Combiner les deux**.

## L'idée

### BM25 — la baseline sparse

Best Match 25 (Robertson 2009) :

$$ \text{BM25}(q, d) = \sum_{t \in q} \text{IDF}(t) \cdot \frac{f(t, d) (k_1 + 1)}{f(t, d) + k_1 (1 - b + b \frac{|d|}{\text{avgdl}})} $$

- $f(t, d)$ : fréquence du terme dans le doc
- $|d|$ : longueur du doc, normalisé par avg
- $k_1, b$ : hyperparams (typ. $k_1 = 1.5$, $b = 0.75$)
- IDF : inverse document frequency

Pénalise les termes communs, recompense les rares et fréquents dans le doc.

**Standard depuis 30 ans**. Robuste, no training, marche partout.

Implems : `rank_bm25`, Elasticsearch, OpenSearch, Lucene.

### Dense retrieval (embedding-based)

Cf. [[embeddings]] et [[RAG]]. Score = cosine similarity entre query et chunk embeddings.

### Hybrid retrieval : pourquoi ça marche

- Dense : "what is the capital of France?" matche "Paris is the political center"
- Sparse (BM25) : "find docs mentioning 'XGBoost 1.7.5'" trouve exact match

→ Recall combinaison > recall de chacun seul.

### Fusion methods

#### Reciprocal Rank Fusion (RRF, Cormack 2009)

$$ \text{RRF}(d) = \sum_{r \in \text{rankers}} \frac{1}{k + \text{rank}_r(d)} $$

avec $k = 60$ typique.

- **Robuste** : pas besoin de calibrer les scores absolus
- Standard, fonctionne bien out-of-the-box

#### Linear weighted

$$ \text{score}(d) = \alpha \cdot \text{score}_{\text{dense}}(d) + (1 - \alpha) \cdot \text{score}_{\text{sparse}}(d) $$

- Demande **normalisation** des scores (min-max, z-score)
- $\alpha$ à tuner sur eval set

#### Convex combination

Variante linear avec contraintes spécifiques.

#### Borda count

Rank-based, similar to RRF mais simpler.

### Multi-stage retrieval

```
1. BM25 retrieve top-100 (cheap, fast)
2. Dense retrieve top-100
3. Union → 150 candidats uniques
4. Rerank avec cross-encoder → top-10 final
```

Standard "two-stage" : large recall + precise rerank.

### SPLADE — learned sparse (Formal 2021)

Hybride par construction : un **neural sparse** retriever.

- Sortie : sparse vector sur le vocabulaire BERT
- Apprend les "expansion terms" (synonymes, etc.)
- Capture sémantique tout en gardant inverted index
- Compatible Elasticsearch / Qdrant sparse

**Compromis intéressant** : meilleur que BM25, moins cher que dense reranker.

### Multi-vector retrieval

#### ColBERT (Khattab 2020)

**Late interaction** : chaque token a son embedding, similarity = max-similarity token-to-token.

- Mieux que single-vector dense
- Plus de stockage
- Standard pour search à grande échelle

#### ColBERT v2

Compression + plus rapide. Standard.

#### ColPali (Faysse 2024)

Vision documents : embed des **patches d'image**. Pour PDFs sans OCR.

### Filtered hybrid

Filter sur metadata (tags, date, source) + sparse + dense :

```python
results = vector_db.search(
    query_embedding=emb,
    filter={"year": 2024, "tag": "ml"},
    use_hybrid=True
)
```

Important en production multi-tenant, multi-source.

### Choix de stack

| Stack | Strengths |
|---|---|
| **Elasticsearch / OpenSearch + kNN plugin** | BM25 natif + vector, hybrid out-of-box |
| **Qdrant** | Sparse + dense hybrid, fast |
| **Weaviate** | Hybrid natif, filter strong |
| **Pinecone hybrid** | Managed, sparse encoder support |
| **Vespa** | Mature, complex, Yahoo-grade |
| **pgvector + tsvector (Postgres)** | Combined SQL setup, simple |
| **LanceDB** | Hybrid, columnar |
| **Typesense** | Faceted + vector |

### Best practices

1. **Hybrid > pure dense** : gain souvent gratuit
2. **RRF default** : simple, robuste
3. **Tune α** sur eval set si linear
4. **Multi-stage** : BM25 wide + dense narrow → rerank
5. **SPLADE** si production cost-sensitive
6. **ColBERT / multi-vector** si query / doc complexes
7. **Filter avant** retrieval (date, source) pour scope
8. **Index BM25 + vector** sur même DB (Qdrant, ES) pour cohérence
9. **Mesurer recall@k** et **NDCG** ([[Ranking metrics]])
10. **Re-rank** ([[Reranking]]) après hybrid pour boost final

## Quand c'est utile

- **Tout RAG production** : hybrid > dense seul
- **Documentation technique** : noms d'API, versions, jargon
- **Legal / medical** : termes précis, références
- **Search avec entities** : noms propres, codes
- **Multilingue** : BM25 baseline robuste
- **Cold start** : pas besoin de train embedder
- **Numeric search** : "2025-03-15" plus facile en BM25
- **Faceted search** : metadata + content combinés

## Quand ça ne marche pas / pièges

- **Hybrid sans tuning α** : peut être pire que dense seul
- **Score scales différentes** : BM25 vs cosine — normaliser obligatoire pour linear
- **RRF k mal choisi** : $k$ trop grand → ignore rank differences
- **Dense embedder weak** : hybrid n'aide pas
- **BM25 stopwords** : par défaut, "the", "a" enlevés → "to be or not to be" cassé
- **Stemming / tokenization** : "running" vs "ran" → BM25 mal sans stemming
- **Multilingual BM25** : language detection nécessaire, langues asiatiques difficiles
- **Sparse + dense pas synchro** : si chunks changent, re-indexer les deux
- **ColBERT mémoire** : 100x plus de storage que single-vector
- **Filter pré-retrieval impossible** sur certains stacks
- **Eval set biaisé** : choisir queries qui montrent l'apport du hybrid

## Code minimal

```python
from rank_bm25 import BM25Okapi
import numpy as np

# Corpus
corpus = ["The quick brown fox", "Lazy dog jumps", "Quick foxes are smart", ...]
tokenized = [doc.lower().split() for doc in corpus]
bm25 = BM25Okapi(tokenized)

query = "quick fox"
bm25_scores = bm25.get_scores(query.lower().split())
print(bm25_scores)

# Dense embedding scores
from sentence_transformers import SentenceTransformer
embedder = SentenceTransformer("all-MiniLM-L6-v2")
doc_emb = embedder.encode(corpus)
query_emb = embedder.encode([query])
dense_scores = np.dot(doc_emb, query_emb.T).flatten()

# Reciprocal Rank Fusion
def rrf(rankings, k=60):
    """rankings: list of lists of (doc_id, score) ordered by score desc."""
    scores = {}
    for ranking in rankings:
        for rank, (doc_id, _) in enumerate(ranking, 1):
            scores[doc_id] = scores.get(doc_id, 0) + 1 / (k + rank)
    return sorted(scores.items(), key=lambda x: -x[1])

bm25_ranked = sorted(enumerate(bm25_scores), key=lambda x: -x[1])
dense_ranked = sorted(enumerate(dense_scores), key=lambda x: -x[1])

fused = rrf([bm25_ranked, dense_ranked])
print("Top RRF:", fused[:5])

# Linear combination (need normalization)
def normalize(scores):
    s = np.array(scores)
    return (s - s.min()) / (s.max() - s.min() + 1e-8)

alpha = 0.5
hybrid_scores = alpha * normalize(dense_scores) + (1 - alpha) * normalize(bm25_scores)
hybrid_ranked = sorted(enumerate(hybrid_scores), key=lambda x: -x[1])
print("Top hybrid linear:", hybrid_ranked[:5])

# Qdrant hybrid (production)
# from qdrant_client import QdrantClient
# from qdrant_client.models import Prefetch, Fusion, FusionQuery
# client = QdrantClient(":memory:")
# # Index sparse + dense
# # search with hybrid
# results = client.query_points(
#     collection_name="docs",
#     prefetch=[
#         Prefetch(query=sparse_vector, using="sparse"),
#         Prefetch(query=dense_vector, using="dense"),
#     ],
#     query=FusionQuery(fusion=Fusion.RRF),
# )

# Elasticsearch hybrid
# es.search(
#     index="docs",
#     body={
#         "query": {"match": {"content": query}},  # BM25
#         "knn": {"field": "embedding", "query_vector": query_emb, "k": 50},
#         "rank": {"rrf": {"rank_window_size": 50, "rank_constant": 20}}
#     }
# )

# LangChain EnsembleRetriever
# from langchain.retrievers import EnsembleRetriever, BM25Retriever
# from langchain_community.vectorstores import FAISS

# bm25_retriever = BM25Retriever.from_documents(docs)
# vector_retriever = FAISS.from_documents(docs, embedder).as_retriever()
# ensemble = EnsembleRetriever(
#     retrievers=[bm25_retriever, vector_retriever],
#     weights=[0.5, 0.5]
# )

# pgvector + tsvector (Postgres hybrid)
# SELECT id, content, 
#   ts_rank_cd(to_tsvector('english', content), plainto_tsquery('english', :query)) AS sparse_score,
#   1 - (embedding <=> :query_emb) AS dense_score
# FROM docs
# ORDER BY (0.5 * sparse_score + 0.5 * dense_score) DESC
# LIMIT 10;
```

## Pour aller plus loin

- Robertson, Zaragoza, *The Probabilistic Relevance Framework: BM25 and Beyond* (2009)
- Cormack et al., *Reciprocal Rank Fusion outperforms Condorcet and individual Rank Learning Methods* (SIGIR 2009)
- Formal et al., *SPLADE: Sparse Lexical and Expansion Model for First Stage Ranking* (SIGIR 2021)
- Khattab, Zaharia, *ColBERT: Efficient and Effective Passage Search via Contextualized Late Interaction over BERT* (SIGIR 2020)
- Santhanam et al., *ColBERTv2: Effective and Efficient Retrieval via Lightweight Late Interaction* (NAACL 2022)
- Faysse et al., *ColPali: Efficient Document Retrieval with Vision Language Models* (2024)
- *Anthropic Contextual Retrieval* blog — recommendation hybrid
- *Vespa, Qdrant, Weaviate docs* — production stacks
- **Liens internes** : [[RAG]], [[Advanced RAG]], [[embeddings]], [[Reranking]], [[Ranking metrics]], [[Chunking strategies]]
