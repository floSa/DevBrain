---
galaxie: wiki
nom: Data leakage
alias: [leakage, fuite de donnees, target leakage, train-test contamination]
type: concept
categorie: concept/ml-ops
sous_categories: [data-leakage, validation, ml-pipeline]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Kaufman et al. 2012]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml-ops, validation, pitfall]
---

# Data leakage

## TL;DR

**Information de la cible (ou du futur) qui fuit dans les features d'entraînement** → métriques trop belles, prod catastrophique. **Tueur silencieux** des projets ML : un modèle avec 0.99 AUC en CV qui sort 0.55 en prod est presque toujours victime de leakage. Familles : **target leakage** (feature dérivée de la cible), **temporal leakage** (utiliser du futur en TS), **train-test contamination** (preprocessing sur tout le dataset), **group leakage** (split qui mélange entités). Détecter par : feature importance suspecte, écart train/CV/prod, suspicion sur features "magiques".

## Le problème

Un modèle apprend de **patterns** dans les features. Si une feature contient (directement ou indirectement) l'information de la cible **qui ne serait pas disponible au moment de la prédiction**, le modèle apprend un raccourci qui n'existe pas en prod.

Résultat typique :
- Train accuracy 99%, Test accuracy 98% → "Excellent!"
- Déploiement → accuracy chute à 60-70%
- Investigation : leak quelque part

## L'idée

### Familles de leakage

#### 1. Target leakage (feature → target)

Une feature est dérivée (directement ou indirectement) de la cible.

**Exemples** :
- Prédire le churn avec une feature `days_since_last_login` calculée incluant la période post-churn
- Prédire la fraude avec `has_been_reviewed_by_fraud_team` (booléen mis à 1 quand fraude détectée → après le fait)
- Prédire le default credit avec `account_closed_recently` (closure souvent conséquence du default)
- Prédire la conversion avec `total_revenue_lifetime` (inclut les conversions futures)

**Détection** : feature importance étrangement élevée d'une variable suspecte, ou logique métier qui dit "cette info n'arrive qu'après".

#### 2. Temporal leakage (futur → passé)

Dans une série temporelle, utiliser des données du futur pour prédire le passé.

**Exemples** :
- Rolling mean sans `.shift(1)` → inclut le point actuel
- Standardiser sur tout le dataset (moyenne / std calculés sur train + test → fuite des stats du futur)
- KFold standard sur TS → train contient des dates après test
- Calculer un lag mal aligné (`lag_-1` = futur)

Voir [[Walk-forward CV]] pour la solution.

#### 3. Train-test contamination

Preprocessing fitté sur tout le dataset (train + test) → stats du test fuient dans le pipeline.

**Exemples** :
- `StandardScaler().fit_transform(X)` sur tout X **avant** le split → mean/std incluent test
- Imputation de NaN avec moyenne globale calculée avant split
- PCA fitté sur tout le dataset
- Sélection de features par corrélation avec target sur tout le dataset
- Target encoding sans CV interne
- **Outlier removal** basé sur les stats du test set

**Règle** : pipeline `fit` UNIQUEMENT sur train, puis `transform` sur test.

#### 4. Group leakage

Le même "groupe" (patient, user, instance) apparaît dans train ET test.

**Exemples** :
- Multiple records par patient → split random → patient en train ET test → model apprend la personne, pas la maladie
- Multiple sessions par user → split random sur sessions → fuite
- Plusieurs photos d'un même objet → train et test contiennent le même objet

**Solution** : `GroupKFold`, `LeaveOneGroupOut`, split par `user_id`.

#### 5. Leakage via duplicate / quasi-duplicate

Doublons exacts ou quasi-doublons (typo, encodage différent du même record) entre train et test.

**Exemples** :
- CIFAR / ImageNet ont eu des duplicates entre splits
- Datasets RAG : même chunk dans train embedding et test query
- Texte avec espaces/casse différentes mais sémantiquement identiques

**Solution** : déduplication agressive (hashing perceptuel pour images, MinHash pour texte).

#### 6. Leakage via leaking-time-of-day

Donner l'heure exacte de la requête comme feature peut donner indirectement la cible si la cible a une time signature (ex: fraudes nocturnes).

#### 7. ID leakage

Inclure des IDs (user_id, transaction_id) comme features → mémorise au lieu de généraliser. Surfit catastrophique.

### Cas tordus / piégeux

#### Anti-features

Features qui sembleraient innocentes mais leakent :
- **`day_of_week`** sur un dataset où certains jours n'ont jamais de label positif
- **`device_type`** où chaque device n'a qu'une classe
- **`store_id`** sur dataset où chaque store a un comportement signé

Ces features peuvent être valides en prod mais l'évaluation surestime.

#### Survivorship bias

Train set = uniquement clients qui sont restés → modèle de churn aveugle au signal d'attrition réel.

#### Selection bias dans le label

Label disponible uniquement pour les cas "déjà identifiés" → train sur sub-population, prédiction sur full pop biaisée.

#### Confounders qui leakent

Variable inobservée qui cause à la fois feature et cible. Le modèle "voit" via la feature ce qui en réalité vient du confounder. Ce n'est pas du leakage stricto sensu, mais l'effet est similaire en prod.

### Détecter le leakage

#### Symptômes typiques

1. **Train >> CV >> Test prod** : leak partout (toxic)
2. **Train ≈ CV >> Prod** : leak dans CV (split mal fait, group, temporal)
3. **Une feature avec importance énorme et inattendue** : suspect
4. **Modèle trop bon trop vite** : "this looks too good to be true"
5. **Performance qui chute à la mise en prod** : red flag

#### Pratiques diagnostiques

- **Importance permutation** : enlever feature suspecte → si AUC chute de 0.99 à 0.55, suspect
- **Train sans la feature suspecte** : voir le gap
- **Logique métier** : "Cette info est-elle disponible AU MOMENT de la prédiction en prod ?"
- **Holdout temporel strict** : test sur période distincte → exposer leak temporel
- **Group split** : split par entité → exposer group leakage
- **Shadow deploy** : run modèle sur traffic live sans serve → compare réel vs prédit

### Prévenir le leakage

#### Pipeline sklearn

Utiliser `Pipeline` + `ColumnTransformer` pour que `fit_transform` train et `transform` test soient distincts :

```python
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('imputer', SimpleImputer()),
    ('model', LogisticRegression())
])
pipeline.fit(X_train, y_train)  # scaler/imputer fit on train only
pipeline.score(X_test, y_test)  # transform with train stats
```

#### Validation appropriée

- **Tabulaire i.i.d.** : `KFold`, `StratifiedKFold`
- **Temporal** : `TimeSeriesSplit`, `Walk-forward`
- **Groupes** : `GroupKFold`, `LeaveOneGroupOut`
- **Combinaisons** : `GroupTimeSeriesSplit` custom

#### Documentation du pipeline

Pour chaque feature :
- D'où vient-elle ?
- Quand est-elle disponible (au moment de la prédiction) ?
- A-t-elle des dépendances avec la cible ?

#### Feature store discipline

Centraliser les features avec **timestamp de validité** (point-in-time correctness). Évite que le pipeline pioche une feature actualisée à $t > t_\text{predict}$.

#### Adversarial validation

Train classifier "train vs test" : si il distingue parfaitement → distribution shift ou leakage. Si AUC ~0.5 → mêmes distributions, ok.

### Best practices

1. **Toujours splitter en premier** : split est sacro-saint, le reste vient après
2. **Pipeline sklearn obligatoire** pour preprocessing
3. **Logique métier > intuition stat** : demander "est-ce que cette feature existe à T0 ?"
4. **Holdout final** : pas y toucher, n'évaluer qu'une fois en fin de projet
5. **Documenter chaque feature**
6. **Code review du feature pipeline**
7. **Backtest temporel strict** sur TS
8. **Adversarial validation** au moindre doute

## Quand c'est utile

- Connaître les types de leakage pour **les éviter activement**
- **Code review ML** : vérifier le pipeline d'autres devs
- **Investigation post-mortem** : un modèle chute en prod, diagnose
- **Compétitions** : Kaggle a des bugs de leakage célèbres
- **Audit modèle** : avant de déployer en réglementé (médical, financier)
- **Onboarding nouvelle équipe** : checklist anti-leakage

## Quand ça ne marche pas / pièges

Le leakage est lui-même un **piège**, donc ce section décrit les pièges du **diagnostic** :

- **Confondre overfitting et leakage** : overfit = mémoriser, leak = utiliser info indue. Les deux causent gap train/test mais traitements différents.
- **Adversarial validation faux positif** : si train et test sont sur périodes différentes, distribution shift naturel → AUC ~0.7 sans leakage.
- **Feature importance trompeuse** : feature légitime + corrélation forte n'est pas forcément leak.
- **Pas tester** un sub-set sans la feature suspecte → on ne sait pas si c'est la cause.
- **Croire qu'un pipeline sklearn suffit** : ne protège pas contre target leakage logique.
- **Backtest sans walk-forward** : KFold trompeur sur TS.
- **Production diffère du backtest** : feature non-disponible en prod (latency, missing) → modèle backtested avec, prod sans, écart.
- **Leakage subtil via interactions** : feature seule n'a pas leak, mais combinée avec une autre, oui.

## Code minimal

```python
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, KFold, TimeSeriesSplit, GroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression

# ============ MAUVAIS : Train-test contamination ============
X = np.random.randn(1000, 10)
y = (X[:, 0] > 0).astype(int)

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)  # ❌ fit sur tout
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.3)
# Stats de test fuitent via scaler

# ============ BON : split d'abord, puis pipeline ============
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)

pipe = Pipeline([
    ('scaler', StandardScaler()),
    ('clf', LogisticRegression())
])
pipe.fit(X_train, y_train)  # ✅ fit seulement sur train
score = pipe.score(X_test, y_test)
print(f"Score (sans leakage) = {score:.3f}")

# ============ MAUVAIS : Temporal leakage ============
df = pd.DataFrame({'date': pd.date_range('2024', periods=1000), 'y': np.random.randn(1000)})
df['rolling_mean'] = df['y'].rolling(7).mean()  # ❌ inclut le point actuel
# Devrait être :
df['rolling_mean_safe'] = df['y'].rolling(7).mean().shift(1)  # ✅

# ============ MAUVAIS : Group leakage ============
df = pd.DataFrame({'user_id': np.random.randint(0, 100, 1000),
                    'feature': np.random.randn(1000), 'target': np.random.randint(0, 2, 1000)})
# ❌ KFold random
kf = KFold(n_splits=5, shuffle=True)
# ✅ GroupKFold
gkf = GroupKFold(n_splits=5)
for train_idx, test_idx in gkf.split(df, df['target'], groups=df['user_id']):
    train_users = set(df.iloc[train_idx]['user_id'])
    test_users = set(df.iloc[test_idx]['user_id'])
    assert train_users.isdisjoint(test_users), "Group leakage!"

# ============ Détection : adversarial validation ============
# Train un classifier "train vs test" — si AUC haute, distribution shift / leak
X_combined = np.vstack([X_train, X_test])
y_combined = np.concatenate([np.zeros(len(X_train)), np.ones(len(X_test))])
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
auc = cross_val_score(RandomForestClassifier(n_estimators=100), X_combined, y_combined,
                       cv=5, scoring='roc_auc').mean()
print(f"Adversarial AUC = {auc:.3f}  (≈ 0.5 = pas de shift)")

# ============ Permutation importance pour détecter feature suspecte ============
from sklearn.inspection import permutation_importance
result = permutation_importance(pipe, X_test, y_test, n_repeats=10)
# Si une feature a importance énorme >> autres, suspecte

# ============ Temporal CV (jamais KFold sur TS!) ============
df_ts = pd.DataFrame({'date': pd.date_range('2024', periods=1000), 'y': np.random.randn(1000)})
tscv = TimeSeriesSplit(n_splits=5)
for train_idx, test_idx in tscv.split(df_ts):
    assert df_ts.iloc[train_idx]['date'].max() < df_ts.iloc[test_idx]['date'].min()
```

## Pour aller plus loin

- Kaufman, Rosset, Perlich, *Leakage in Data Mining: Formulation, Detection, and Avoidance* (KDD 2012)
- Géron, *Hands-On Machine Learning* (3e éd.) — chap. 2 pipeline
- Sklearn docs sur `Pipeline` et `ColumnTransformer`
- Kaggle write-ups célèbres sur leakage (ex: Heritage Health Prize)
- **Liens internes** : [[Cross-validation]], [[Walk-forward CV]], [[Feature engineering]], [[Time series feature engineering]], [[Data drift]]
