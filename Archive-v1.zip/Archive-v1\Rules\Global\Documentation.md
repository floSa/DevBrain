---
galaxie: dev
type: rule
domaine: docs
applicable: global
strictness: should
created: 2026-05-01
modified: 2026-05-01
tags: [rule, docs]
---

# Règle — Documentation

## Principe
Documenter le **pourquoi** plutôt que le **quoi**. Le code dit le quoi. Doc obsolète = pire que pas de doc.

## MUST

- Toute **fonction publique** (exportée d'un module/lib) a une docstring / TSDoc minimale.
- Pas de doc obsolète : si une partie de la doc contredit le code, la corriger ou la supprimer dans le même PR que le changement.
- README à jour (cf. `[[Rules/Global/README]]`).

## SHOULD

- **ADR** (Architecture Decision Records) pour les décisions structurelles : `docs/adr/0001-titre.md` au format Michael Nygard.
- **Diagrammes en Mermaid** plutôt qu'en image (versionnable, modifiable).
- Doc d'API auto-générée si possible (OpenAPI/Swagger pour HTTP, sphinx/typedoc pour libs).
- Section "Architecture" dans le README ou `docs/ARCHITECTURE.md` si non trivial.

## NICE-TO-HAVE

- Site doc dédié (mkdocs, docusaurus, vitepress) pour projets larges.
- Tutoriels pas-à-pas pour les use cases majeurs.
- Diagrammes de séquence pour les flux complexes.

## Format ADR (template)

```markdown
# ADR <NNN> : <Titre court de la décision>

Date : YYYY-MM-DD
Statut : Accepté | Proposé | Déprécié | Remplacé par <ADR>

## Contexte
Quel problème, quelles contraintes ?

## Décision
Ce qu'on a choisi de faire.

## Conséquences
Bonnes et mauvaises, à court et long terme.

## Alternatives considérées
- Option A : pourquoi rejetée
- Option B : pourquoi rejetée
```

## Anti-patterns

- **Docstrings qui paraphrasent le nom** : `def get_user(): """Get user."""` — bruit.
- **Commentaires sur le quoi** : `# Increment counter` au-dessus de `counter += 1`.
- **Doc README de 5000 lignes** sans table des matières.
- **Doc séparée du code** dans un Confluence externe que personne n'updateLLLL.

## Voir aussi

- [[Rules/Global/README]]
- [[Pattern - API REST FastAPI minimale]] — section Documentation
