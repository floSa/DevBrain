# Service — <NOM_DU_SERVICE>

<!--
Template à copier dans <projet>/services/<nom>/README.md.
Référence règle : Rules/Documentation/Database-Graph.md du DevBrain.
-->

## Rôle métier

<À REMPLIR : 2-4 lignes — quel besoin "graphe" justifie cette base.>

Exemple :
> Knowledge graph alimenté par extraction LLM depuis les documents internes. Permet les requêtes multi-hop ("trouve les concepts cités par les co-auteurs de X"). Utilisé par le moteur RAG pour enrichir le contexte au-delà du retrieval vectoriel pur.

## Ontologie — Sommets (Vertices / Nodes)

| Type | Propriétés | Cardinalité estimée | Source |
|------|-----------|---------------------|--------|
| `Person` | `id, name, email, role` | ~10k | Imports HR + extraction LLM |
| `Document` | `id, title, type, source_url, created_at` | ~100k | Uploads users |
| `Concept` | `id, label, category, embedding_vec` | ~5k | Extraction LLM |
| `<À REMPLIR>` |  |  |  |

### Détail des propriétés

#### `Person`
| Prop | Type | Obligatoire | Indexée | Description |
|------|------|-------------|---------|-------------|
| `id` | string (UUID) | ✅ | ✅ (PK) | Identifiant unique |
| `name` | string | ✅ | ✅ | Nom canonique |
| `email` | string | ❌ | ✅ (unique) | Email pro |
| `role` | enum | ❌ | ❌ | `author / reviewer / editor` |

<À REMPLIR : autres types de Vertex>

## Ontologie — Arêtes (Edges)

| Type | Source | Cible | Propriétés | Direction | Description |
|------|--------|-------|------------|-----------|-------------|
| `AUTHORED` | Person | Document | `{ date }` | dirigée | Auteur d'un doc |
| `MENTIONS` | Document | Concept | `{ confidence: float }` | dirigée | Doc cite un concept |
| `RELATED_TO` | Concept | Concept | `{ weight: float, source: enum }` | bi-dir | Lien sémantique |
| `<À REMPLIR>` |  |  |  |  |  |

### Schéma visuel

```mermaid
graph LR
  P[Person] -->|AUTHORED| D[Document]
  D -->|MENTIONS| C[Concept]
  C -->|RELATED_TO| C
```

## Stratégie d'extraction (LLM)

> Cette section est CRITIQUE si le graphe est alimenté par un LLM. Sinon, supprimer.

- **Modèle** : `<À REMPLIR : Claude Opus / GPT-4 / modèle local>`
- **Prompt** : `services/<nom>/prompts/extract_triplets.md` (versionné)
- **Schéma de sortie** : JSON Schema imposé via `tools` ou `response_format`
- **Validation** :
  - Règles automatiques : types valides, FKs cohérentes
  - Revue humaine : sample 5% par batch
- **Déduplication / canonicalisation** : matching d'entités via `services/<nom>/canonicalize.py`
- **Idempotence** : cache (doc_id, model_version) → triplets pour replay

### Exemple de prompt extraction

```markdown
Tu es un expert en extraction de connaissances.
Pour chaque triplet (Sujet, Prédicat, Objet) trouvé dans le texte,
retourne un JSON respectant le schéma suivant :
{...}

Restrictions :
- Sujets et Objets doivent être des entités présentes dans l'ontologie
- Prédicats doivent appartenir à la liste : {AUTHORED, MENTIONS, RELATED_TO}
- Confidence ∈ [0, 1]

Texte à analyser :
{document_content}
```

## Contrat d'interface

- **Langage de requête** : `<À REMPLIR : Cypher / nGQL / Gremlin>`
- **Driver** : `<À REMPLIR : neo4j-python-driver / nebula3-python>`
- **Endpoint** : `<À REMPLIR : bolt://neo4j:7687>`

### Requêtes principales du projet

```python
def get_related_concepts(concept_id: str, depth: int = 2) -> list[Concept]: ...
def get_co_authors(person_id: str) -> list[Person]: ...
def find_path(src_id: str, dst_id: str, max_depth: int = 5) -> list[Path]: ...
```

## Configuration

| Variable | Type | Défaut | Description |
|----------|------|--------|-------------|
| `NEO4J_URL` | `str` | — | bolt://... |
| `NEO4J_USER` | `str` | `neo4j` | Username |
| `NEO4J_PASSWORD` | `str` | — | Password |
| `<À REMPLIR>` |  |  |  |

## Démarrage local

```bash
docker-compose up -d neo4j
# UI : http://localhost:7474
# Default credentials : neo4j / <ton mot de passe dans .env>

# Charger l'ontologie initiale
uv run python services/<nom>/init_constraints.py
```

## Indexes & contraintes

```cypher
CREATE CONSTRAINT person_id IF NOT EXISTS FOR (p:Person) REQUIRE p.id IS UNIQUE;
CREATE CONSTRAINT document_id IF NOT EXISTS FOR (d:Document) REQUIRE d.id IS UNIQUE;
CREATE CONSTRAINT concept_id IF NOT EXISTS FOR (c:Concept) REQUIRE c.id IS UNIQUE;

CREATE INDEX person_name IF NOT EXISTS FOR (p:Person) ON (p.name);
```

## Pièges à anticiper

- **Schema-less** ≠ no schema : discipline d'équipe
- **Cypher non optimisé** sur gros graphes : utiliser `PROFILE` / `EXPLAIN`
- **Multi-hop explosif** : limiter `depth` dans les recherches
- **Extraction LLM non-déterministe** : cache + validation

## Liens

- DevBrain : [[<À REMPLIR : Neo4j / Nebula Graph>]] · [[LLM-Orchestration]]
- Règle : [[Database-Graph]]
- Doc : <URL>
- ADR ontologie : `docs/adr/<NNNN>-ontology-decisions.md`
