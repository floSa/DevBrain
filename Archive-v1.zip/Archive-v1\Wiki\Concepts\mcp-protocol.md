---
galaxie: wiki
nom: MCP Protocol
type: concept
categorie: concept/llm
sous_categories: [protocol, agents, tools, anthropic]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Anthropic]
lecture_min: 8
created: 2026-05-19
modified: 2026-05-20
tags: [concept, mcp, agents, protocol]
---

# MCP — Model Context Protocol

## TL;DR

Protocole standard (créé par Anthropic, ouvert) pour **brancher des outils** à un LLM, indépendamment du LLM utilisé. Un *MCP server* expose des outils (lire un fichier, query une DB, appeler une API) ; un *MCP client* (Claude Code, Claude Desktop, Cursor, n'importe quel agent compatible) les consomme. C'est le "USB-C des outils LLM".

## Le problème

Avant MCP, chaque agent LLM avait sa propre façon de définir/invoquer des outils :
- OpenAI : `functions` puis `tools`
- Anthropic : `tools` au format Anthropic
- LangChain : `BaseTool`
- Chaque IDE/app : son propre format de plugin

Conséquence : si tu écris un connecteur Postgres pour Claude, il ne marche pas avec Cursor ni avec Codex. Tu refais le travail.

## L'idée

```
        ┌──────────────────────┐
        │  Client MCP          │
        │  (Claude Code,       │
        │   Claude Desktop,    │
        │   Cursor, ...)       │
        └──────────┬───────────┘
                   │ stdio | HTTP/SSE
                   │ (JSON-RPC)
        ┌──────────▼───────────┐
        │  Server MCP          │   un serveur = un domaine
        │  (mcp-obsidian,      │   d'outils (vault, DB, GH, ...)
        │   mcp-github, ...)   │
        └──────────────────────┘
```

Le client négocie au démarrage : "quels outils as-tu ?" → liste de tools avec schémas JSON. Quand le LLM décide d'invoquer un outil, le client appelle le server, récupère le résultat, le passe au LLM.

Trois primitives exposables par un MCP server :
- **Tools** — fonctions appelables (read_file, query_db, send_email)
- **Resources** — fichiers/données lisibles (fichiers, URL, schémas)
- **Prompts** — templates de prompts pré-définis

## Quand c'est utile

- Tu veux qu'un même outil marche dans plusieurs agents LLM (Claude Code + Cursor + Codex)
- Tu fais une intégration spécifique à ton domaine (DevBrain → mcp-obsidian)
- Tu veux que ton équipe partage facilement des connecteurs sans framework imposé
- Tu écris un produit qui doit être "agent-ready" sans choisir le LLM

## Quand ça ne marche pas / pièges

- **Latence stdio** — chaque call MCP ajoute du round-trip, pas pour du temps réel sub-100ms
- **Pas tous les LLM le supportent encore** — Anthropic et certains open-source, mais ça s'étend
- **Sécurité** — le LLM peut invoquer un MCP avec n'importe quel paramètre. Toujours sandboxer côté server (whitelist de paths, deny-list de commandes)
- **Debugging difficile** — quand un MCP plante, l'agent ne te dit pas toujours pourquoi

## Implémentations concrètes

- [[mcp-obsidian]] — base de DevBrain, vault accès via plugin Obsidian + REST API
- [[mcp-filesystem]] — accès filesystem contrôlé
- [[mcp-github]] — opérations GitHub
- [[mcp-postgres]] — query SQL read-only
- Beaucoup d'autres : Slack, Notion, Drive, Linear, etc.

## Code minimal

```python
# 1. Écrire un MCP server custom (Python SDK)
# pip install mcp
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("my-server")

@mcp.tool()
def get_weather(city: str) -> str:
    """Get weather for a city."""
    # Real implementation
    return f"Sunny in {city}, 22°C"

@mcp.resource("config://app")
def get_config() -> str:
    """Application configuration."""
    return "{'env': 'production'}"

@mcp.prompt()
def code_review_prompt(code: str) -> str:
    """Prompt template for code review."""
    return f"Review this code for security issues:\n{code}"

if __name__ == "__main__":
    mcp.run()  # default stdio transport
```

```bash
# 2. Brancher à Claude Code (CLI)
claude mcp add my-server -- python /path/to/server.py

# Vérifier
claude mcp list
# my-server ✓ Connected

# 3. Configuration Claude Desktop (~/.config/Claude/claude_desktop_config.json)
# {
#   "mcpServers": {
#     "my-server": {
#       "command": "python",
#       "args": ["/path/to/server.py"]
#     }
#   }
# }
```

```python
# 4. Côté client : un MCP server est consommable depuis n'importe quel LLM
# Exemple avec Anthropic + MCP via les SDKs
# (Claude Code / Claude Desktop / Cursor gèrent la connexion automatiquement)

# 5. Inspecter un MCP server
# Via inspector officiel :
# npx @modelcontextprotocol/inspector python server.py
# → UI graphique pour tester les tools/resources/prompts
```

## Pour aller plus loin

- Spec officielle : https://modelcontextprotocol.io/
- Repo des servers officiels : https://github.com/modelcontextprotocol/servers
- Article Anthropic launch : https://www.anthropic.com/news/model-context-protocol
- [[_installer-un-skill]] section *MCP server* pour le côté pratique
