---
galaxie: wiki
nom: DMN Conformance Levels
alias: [conformance levels, dmn conformance, dmn-l1, dmn-l2, dmn-l3, s-feel]
type: concept
categorie: concept/business-rules
sous_categories: [dmn, conformance, levels, s-feel, feel]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [OMG]
lecture_min: 5
created: 2026-05-21
modified: 2026-05-21
tags: [concept, dmn, conformance]
---

# DMN Conformance Levels

## TL;DR

DMN définit **3 niveaux de conformance** pour les outils qui le supportent : **L1** (DRD seul, modeling sans exécution), **L2** (DRD + decision tables exécutables avec **S-FEEL** — sous-ensemble simplifié de FEEL), **L3** (tout DMN + **FEEL** complet, fonctions, contexts, etc.). Tu DOIS vérifier le niveau supporté par un outil avant adoption — un "outil DMN" peut être juste L1 (PowerPoint glorifié) ou L3 (engine complet). Camunda, Drools, Trisotech sont L3. Beaucoup d'outils enterprise s'arrêtent à L2.

## Le problème

Un éditeur dit "supporte DMN" → tu l'achètes → tu réalises qu'il ne peut **pas exécuter** tes decision tables (juste les dessiner). Ou que tes expressions FEEL avec list comprehension ne marchent pas (juste les ranges/comparateurs).

Les **conformance levels** OMG sont la grille de lecture pour éviter ce piège. Demande toujours : *"Quel niveau de conformance supporte votre outil ?"*.

## L'idée

### L1 — Decision Requirements Level

**Couvre** :
- DRD complet (decisions, input data, KS, BKM, requirements)
- Description textuelle des décisions
- Pas d'expression formelle exécutable

**Cas d'usage** :
- Phase de cadrage / analyse pure
- Communication métier sans intention d'exécuter
- Documentation à plat (PDF, Visio)

**Outils typiques** :
- Visio / Lucidchart avec stencil DMN
- draw.io
- Tous les outils L2/L3 (qui supportent L1 par construction)

**Limite** : un L1 ne peut pas tester / exécuter tes règles. C'est de la documentation, pas une décision automation platform.

### L2 — Decision Requirements + Simple Expression Logic

**Couvre L1 +** :
- Decision tables **exécutables**
- Literal expressions exécutables
- **S-FEEL** : sous-ensemble simplifié de FEEL
- Types primitifs (number, string, boolean, date, time, duration)

**S-FEEL** (Simple FEEL) inclut :
- Comparateurs : `<`, `>`, `<=`, `>=`, `=`, `!=`
- Ranges : `[a..b]`, `(a..b)`, `[a..b)`, etc.
- Listes simples (énumérations) : `"red", "green", "blue"`
- `-` (tiret) = "n'importe quoi"
- `not(...)` négation
- Arithmétique de base (+, -, *, /)
- Fonctions built-in basiques (`abs`, `min`, `max`)

**N'inclut PAS** :
- List comprehensions (`[x | x in list, condition]`)
- `if then else`
- Fonctions FEEL définies par l'utilisateur (function definition)
- BKM avec body FEEL complet
- Context (struct)
- Iterator, filter, conditional (DMN 1.4+)

**Cas d'usage** :
- 80% des decision tables métier courantes
- Outils enterprise qui veulent supporter DMN sans implémenter tout FEEL
- Maximum portabilité entre outils

**Outils typiques** : beaucoup de plateformes Business Rules historiques (FICO Blaze Advisor, IBM ODM, certains modules SAP) — leur lib FEEL est partielle.

### L3 — Full DMN

**Couvre L2 +** :
- **FEEL complet** : function definitions, contexts, list comprehensions, conditional, iterator, filter
- Tous les boxed expressions (function, context, invocation, relation, list, conditional, iterator, filter)
- BKM avec body FEEL arbitraire
- Custom types (`itemDefinition`)
- Décisions invoquables récursivement (avec garde-fous)

**Cas d'usage** :
- Decisions complexes (formules de calcul, agrégations sur listes)
- Architecture de BKM réutilisables
- ML-augmented decisions (FEEL invoque les inputs preprocessés)
- Implémentation référence du standard

**Outils typiques** :
- **Camunda 7/8** (Java) — référence
- **Red Hat KIE / Drools** (Java) — référence
- **Trisotech** (commercial) — éditeur graphique L3
- **OpenL Tablets** (Java)
- **DMN-eval-js** (TypeScript) — couverture L3 partielle
- **pyDMNrules** (Python) — couverture L2 + parts de L3

### Vérifier la conformance d'un outil

Demander :
1. **Quel niveau** ? (L1 / L2 / L3)
2. Quel **% du DMN TCK** passe ? (Technology Compatibility Kit, suite de tests OMG)
3. Quelle **version DMN** ? (1.1 / 1.2 / 1.3 / 1.4 / 1.5)
4. Quelles **boxed expressions** supportées ? (les récentes 1.4+ : iterator, filter, conditional)

Le **DMN TCK** ([github.com/dmn-tck/tck](https://github.com/dmn-tck/tck)) maintient un classement des outils par % de tests qui passent. C'est l'étalon-or pour comparer.

### Quel niveau viser pour ton projet ?

| Besoin | Niveau cible |
|---|---|
| Documentation métier statique | L1 |
| Decision tables simples exécutables | L2 |
| Logique riche (formules, listes, fonctions) | L3 |
| Conformité maximale + portabilité | L3 + check TCK |

### Évolution du standard DMN

- **DMN 1.0** (2015) : initial
- **DMN 1.1** (2016) : améliorations FEEL
- **DMN 1.2** (2019) : couleurs, refactor mineurs
- **DMN 1.3** (2020) : améliorations boxed
- **DMN 1.4** (2022) : conditional, iterator, filter boxed
- **DMN 1.5** (2023, soumis février 2023, approuvé mars 2023 par l'OMG Architecture Board) : alignement unary tests, métadonnées étendues, fix sur input data representation, namespace URI mis à jour. Version courante en 2026. Adoption progressive côté engines (Camunda en cours de support des nouveaux namespaces).

Les engines (Camunda, Drools) suivent généralement DMN 1.4 pleinement. DMN 1.5 adoption en cours.

### Compatibilité ascendante

DMN est en théorie **rétrocompatible** : un modèle DMN 1.1 doit être lisible par un engine 1.4+. En pratique, certaines features ajoutées (e.g. iterator boxed en 1.4) ne sont pas convertibles vers 1.1.

Si tu écris un modèle DMN destiné à plusieurs outils, **cible le niveau le plus bas** que tu trouves dans ton zoo (souvent L2 + DMN 1.3) pour portabilité.

## Quand c'est utile

- **Avant d'acheter un outil** : check le niveau et le score TCK
- **Avant d'écrire du FEEL avancé** : vérifier que l'engine cible le supporte
- **Pour communiquer** : "ce modèle est L3" = info technique précise pour les devs
- **Diagnostic d'erreur** : si une expression FEEL ne marche pas, peut-être que l'engine n'est pas L3

## Quand ça ne marche pas / pièges

- **"Notre outil supporte DMN"** sans préciser le niveau = drapeau rouge
- **L1 vendu comme "DMN"** : trompeur, c'est de la doc, pas une décision automation
- **Mélange de niveaux dans un projet** : si certaines décisions sont L3 et d'autres L2, le pipeline doit aligner sur le plus haut
- **Custom extensions hors standard** : Camunda a des extensions XML (`camunda:something`), valides Camunda mais non portables vers Drools
- **Versioning DMN imbriqué dans le XML** : `xmlns="https://www.omg.org/spec/DMN/20191111/MODEL/"` indique DMN 1.3, vérifier que ton outil le supporte
- **Migration L2 → L3** : pas automatique, l'équipe doit apprendre FEEL complet
- **Outil "DMN-compatible"** : marketing, demande le score TCK officiel
- **DMN 1.5 features récentes** : adoption en cours, vérifier que ton outil les implémente avant de les utiliser
- **Mix L2 + L3** dans un même fichier : autorisé en théorie, casse-tête en pratique pour les contributors L2-only

## Code minimal

### Vérifier le niveau d'un fichier DMN

Lire l'en-tête XML :

```xml
<?xml version="1.0" encoding="UTF-8"?>
<definitions
  xmlns="https://www.omg.org/spec/DMN/20191111/MODEL/"   <!-- DMN 1.3 -->
  ...
>
```

Le namespace XML indique la version DMN :
- `20151101` → 1.0
- `20160721` → 1.1
- `20180521` → 1.2
- `20191111` → 1.3
- `20211108` → 1.4
- `20240513` (ou similaire) → 1.5

Pour le niveau (L1/L2/L3) : pas d'indicateur direct dans le XML, c'est l'usage des features qui détermine le niveau effectif.

### Détecter le niveau d'un modèle

Heuristique :
- Si le modèle contient des `<encapsulatedLogic>` avec function definition body **non vide** → probablement L3
- Si le modèle utilise `<for>`, `<filter>`, `<conditional>` boxed → L3 + DMN 1.4+
- Si juste `<decisionTable>` avec ranges et énums → L2 suffit
- Si pas de `<decisionTable>` exécutable (juste DRD) → L1

### Tester un outil contre le TCK

```bash
git clone https://github.com/dmn-tck/tck.git
cd tck
# Suivre les instructions du runner spécifique à ton engine
# (Camunda runner, Drools runner, etc.)
```

Le TCK liste les tests qui passent / échouent par engine.

## Pour aller plus loin

- OMG DMN spec, section 2 (Conformance) : https://www.omg.org/spec/DMN/
- DMN TCK GitHub : https://github.com/dmn-tck/tck
- DMN TCK leaderboard (% tests passés par engine)
- Bruce Silver, *DMN Method and Style*, ch. 2 (conformance et choix d'outil)
- Comparaison outils : "Decision Management Tools Reviews" sur g2.com / TrustRadius
- **Liens internes** : [[Decision Model and Notation]], [[FEEL]], [[Decision Tables]], [[Boxed Expressions]]
