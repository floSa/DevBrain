---
galaxie: dev
nom: Weaviate
alias: [weaviate]
categorie: database/vector
sous_categories: [graphql, modules, hybrid-search, multi-tenancy]
licence: BSD-3-Clause
licence_type: open-source
hosted: both
maturite: production
langage: Go
clients_officiels: [python, ts, go, java]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Qdrant]]", "[[Milvus]]", "[[Chroma]]", "[[pgvector]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, database, vector, graphql]
url_officiel: https://weaviate.io/
url_docs: https://weaviate.io/developers/weaviate
url_repo: https://github.com/weaviate/weaviate
---

# Weaviate

## Pourquoi
Base vectorielle avec **API GraphQL native**, multi-tenancy first-class, modules pour vectorisation (text2vec-openai, text2vec-cohere, etc.) qui font l'embedding pour toi. Bon middle-ground entre simplicité et features.

## Quand l'utiliser
- Multi-tenancy fort (un namespace par client) — supporté nativement
- Tu veux que la DB gère l'embedding (pas le faire dans ton code)
- Préférence GraphQL pour requêter
- Hybrid search (BM25 + vector) avec ranking fusion
- Generative search (RAG dans la DB elle-même via modules)

## Quand NE PAS l'utiliser
- Veut tout contrôler (embedding côté app) → [[Qdrant]] ou [[Milvus]]
- Petit projet → [[Chroma]] est plus simple
- Déjà Postgres → [[pgvector]]
- GraphQL pas un atout pour l'équipe → autre option

## Pièges connus
- **Schéma à définir** : classes, properties, vectorizer — moins flexible que Qdrant côté schemaless
- **Modules vectorizers** : configurés à la classe, changement = recréation
- **GraphQL query depth** : à limiter pour éviter abus
- **Backup/restore** : pas trivial selon storage backend
- **Versions** : changements de breaking changes entre majors, lire les changelogs

## Liens
- [[Qdrant]], [[Milvus]], [[Chroma]], [[pgvector]] — alternatives
- Weaviate Cloud Services : https://console.weaviate.cloud/
- Modules : https://weaviate.io/developers/weaviate/modules
- Multi-tenancy : https://weaviate.io/developers/weaviate/concepts/data#multi-tenancy
