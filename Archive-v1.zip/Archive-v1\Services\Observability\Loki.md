---
galaxie: dev
nom: Loki
alias: [loki, grafana-loki]
categorie: observability/logs
sous_categories: [logs, grafana-labs, aggregation, logql, lgtm]
licence: AGPL-3.0
licence_type: open-source
hosted: self ou cloud (Grafana Cloud)
maturite: production
langage: Go
clients_officiels: [http, python, go]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["Elasticsearch + Kibana", "OpenSearch", "ClickHouse logs", "AWS CloudWatch Logs", "GCP Cloud Logging", "VictoriaLogs"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, observability, logs, lgtm]
url_officiel: https://grafana.com/oss/loki/
url_docs: https://grafana.com/docs/loki/latest/
url_repo: https://github.com/grafana/loki
---

# Loki

## Pourquoi

Système d'**aggregation de logs** par Grafana Labs. Philosophie inversée par rapport à Elasticsearch : **n'indexe que les labels** (k=v structurés), **pas le contenu brut**. Conséquence : **storage 10-100x moins cher** (compression + chunks sur S3/GCS), **scaling horizontal natif**, mais **pas de full-text search instantané** — les recherches grep-style sont scannées séquentiellement sur les chunks correspondant aux labels.

Cœur de la **stack LGTM** (Loki Grafana Tempo Mimir). Cible : ops/SRE qui veulent du log aggregation à grande échelle sans casser leur tirelire avec Elasticsearch. Langage de query : **LogQL** (inspirée PromQL). Combo avec **Alloy** (anciennement Promtail/Grafana Agent) côté client pour shipping de logs.

## Quand l'utiliser

- **Stack Grafana existante** : combo naturel, query depuis Grafana directement
- **Volumes logs gros** : économie disque considerable vs Elasticsearch (chunks S3)
- **Combo Kubernetes** : Alloy/Promtail DaemonSet, labels k8s natifs
- **Tail logs en live** via Grafana (Live mode)
- **Conservation longue durée** : retention 1 an+ pas chère (S3 lifecycle policies)
- **Combo LGTM** : Loki + Tempo (trace_id lien automatique) + Mimir (metrics)
- **Logs métier modérés** : pas besoin full-text search rapide
- **Multi-tenancy** : namespaces via header `X-Scope-OrgID`

## Quand NE PAS l'utiliser

- **Full-text search rapide** sur tout le contenu → Elasticsearch / OpenSearch / VictoriaLogs (vrais index)
- **Logs simples / petit volume** → cloud-native (CloudWatch Logs, GCP Cloud Logging) plus simple
- **Audit / compliance riche** : règles d'accès fines, immutability → solutions dédiées (Splunk, Datadog)
- **Pas d'équipe ops** : self-host Loki à grande échelle demande des compétences (chunks, compactor, ingesters)
- **Recherches arbitraires regex sur 1 To** : ça scannera, comptez le temps

## Pièges connus

- **Pas de full-text search rapide** : LogQL filtre les chunks correspondant aux labels, puis grep séquentiel → recherche "error" sur 100 To = long
- **Cardinality labels CRITIQUE** : un label `trace_id` = 100k valeurs = explosion d'index → règle d'or : labels = enum (env, service, severity), PAS d'IDs / timestamps / UUIDs
- **High-cardinality kill perf** : un label avec > 100k valeurs uniques → ingester OOM
- **LogQL learning curve** : `{app="api"} |= "error" | json | latency > 500ms` syntaxe spécifique
- **Setup retention / compaction** : compactor, retention par tenant, à configurer dans `loki.yml`
- **Alloy vs Promtail vs Grafana Agent** : naming confus, Alloy = nom moderne (2024+)
- **Single binary vs distributed** : config single-binary OK pour < 1 To/jour, au-delà passer en distributed mode
- **Storage backend obligatoire** : S3, GCS, Azure Blob, FS — choisir tôt
- **Loki Operator K8s** : utile mais ajoute une couche
- **Cluster auth** : pas d'auth intégrée par défaut (X-Scope-OrgID = no auth) → proxy auth devant (Nginx, oauth2-proxy)
- **Indexer v11/v12/v13 + TSDB** : versions à matcher, upgrade non trivial

## Code minimal

```yaml
# docker-compose.yml : Loki + Grafana + Alloy
version: "3"
services:
  loki:
    image: grafana/loki:3.2.0
    ports: ["3100:3100"]
    volumes:
      - ./loki-config.yaml:/etc/loki/local-config.yaml
      - loki-data:/loki
    command: -config.file=/etc/loki/local-config.yaml

  alloy:
    image: grafana/alloy:v1.4.0
    volumes:
      - ./alloy-config.alloy:/etc/alloy/config.alloy
      - /var/log:/var/log:ro
      - /var/lib/docker/containers:/var/lib/docker/containers:ro
    command: run /etc/alloy/config.alloy --server.http.listen-addr=0.0.0.0:12345

  grafana:
    image: grafana/grafana:11.3.0
    ports: ["3000:3000"]
    environment: {GF_SECURITY_ADMIN_PASSWORD: admin}

volumes:
  loki-data:
```

```yaml
# loki-config.yaml minimaliste (single-binary, filesystem storage)
auth_enabled: false

server:
  http_listen_port: 3100

common:
  ring:
    instance_addr: 127.0.0.1
    kvstore: {store: inmemory}
  replication_factor: 1
  path_prefix: /loki

schema_config:
  configs:
    - from: 2024-01-01
      store: tsdb
      object_store: filesystem
      schema: v13
      index: {prefix: index_, period: 24h}

storage_config:
  tsdb_shipper: {active_index_directory: /loki/index, cache_location: /loki/index-cache}
  filesystem: {directory: /loki/chunks}

limits_config:
  retention_period: 168h    # 7 jours
  ingestion_rate_mb: 8
  ingestion_burst_size_mb: 16

compactor:
  retention_enabled: true
  delete_request_store: filesystem
```

```alloy
// alloy-config.alloy : shipper de logs Docker -> Loki
discovery.docker "containers" {
  host = "unix:///var/run/docker.sock"
}

loki.source.docker "all" {
  host    = "unix:///var/run/docker.sock"
  targets = discovery.docker.containers.targets
  labels  = {
    job = "docker",
    env = "dev",
  }
  forward_to = [loki.write.default.receiver]
}

loki.write "default" {
  endpoint {
    url = "http://loki:3100/loki/api/v1/push"
  }
}
```

```logql
# Exemples LogQL (depuis Grafana, datasource Loki)

# 1. Tous les logs d'un service
{app="api", env="prod"}

# 2. Filtre contenu (grep)
{app="api"} |= "error"

# 3. Exclure
{app="api"} |= "error" != "expected"

# 4. Parse JSON + filtre champ
{app="api"} | json | status >= 500

# 5. Metrique : taux d'erreurs / minute
sum by (service) (rate({env="prod"} |= "error" [1m]))

# 6. Top 5 routes par volume
topk(5, sum by (route) (rate({app="api"} | json [5m])))
```

```python
# Pousser des logs depuis Python (sans Alloy)
import requests
import time

LOKI_URL = "http://localhost:3100/loki/api/v1/push"

def log(level, msg, **labels):
    payload = {
        "streams": [{
            "stream": {"app": "myapp", "level": level, **labels},
            "values": [[str(int(time.time() * 1e9)), msg]],
        }]
    }
    requests.post(LOKI_URL, json=payload)

log("info", "user signed up", user_id="42")
log("error", "payment failed", txn="abc")
```

## Liens

- [[Grafana]] — combo natif (visualisation)
- Tempo — combo tracing (Grafana Labs)
- Mimir — combo metrics scale (Grafana Labs)
- Alloy — agent client (anciennement Promtail / Grafana Agent)
- Elasticsearch / OpenSearch — alternatives full-text search
- VictoriaLogs — alternative open-source plus simple, label-based
- ClickHouse logs — alternative haute perf
- LogQL doc : https://grafana.com/docs/loki/latest/query/
- Docs : https://grafana.com/docs/loki/latest/
- GitHub : https://github.com/grafana/loki
