---
galaxie: wiki
nom: fewer-permission-prompts
type: claude-code-skill
plateforme: claude-code
categorie: skill/dev-flow
sous_categories: [permissions, settings, productivity]
auteur: Anthropic
source: claude-code natif
source_url: https://docs.claude.com/en/docs/claude-code/settings
install_cmd: 
install_doc: 
licence: 
licence_type: proprietary
domaines: [data-science, data-eng, mlops, ml-eng, ai-eng, doc]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, productivity, permissions]
---

# fewer-permission-prompts

## Pourquoi

Skill **bundled** ultra-pratique : **scanne tes transcripts récents**, identifie les commandes Bash et MCP que Claude réutilise souvent en read-only, puis te propose un allowlist priorisé à ajouter dans `.claude/settings.json`.

Résultat : moins de "Permission requested..." par session, focus sur le boulot.

Comme moi qui ai dû te demander 3 fois la permission de lancer `git status` et autres — ce skill aurait éliminé ça en proposant l'allowlist d'un coup.

## Quand l'utiliser

- Après une grosse session où tu as eu plein de prompts permissions
- Setup d'un nouveau projet : laisser tourner 1-2 sessions puis lancer ce skill pour calibrer
- Une fois par mois en hygiène

## Quand NE PAS l'utiliser

- Projet avec des contraintes sécu fortes — tu veux peut-être *garder* les prompts comme garde-fou
- Tu viens de cloner le repo — pas de transcripts à scanner

## Comment l'installer

Natif Claude Code, déclenchable via `/fewer-permission-prompts` ou "réduit les prompts permissions".

## Exemples d'usage

```
> /fewer-permission-prompts
> scanne mes 5 dernières sessions et propose-moi un allowlist
```

## Pièges connus

- Le skill ne propose que du read-only par défaut — il **ne suggérera jamais** `rm`, `push --force`, etc. (et heureusement)
- Si tu cliques "approuve tout", relis quand même l'allowlist avant. C'est ton coffre-fort.

## Liens

- Doc settings : https://docs.claude.com/en/docs/claude-code/settings
- [[claude-update-config|update-config]] (skill cousin pour éditer settings.json en général)
