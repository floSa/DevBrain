---
galaxie: dev
nom: Dask
alias: [dask, dask-distributed]
categorie: tooling/distributed-compute
sous_categories: [parallel, distributed, pandas-like, scheduler]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[Polars]]", "[[Spark]]", "[[Ray]]", Modin, polars-distributed]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, distributed, parallel]
url_officiel: https://www.dask.org/
url_docs: https://docs.dask.org/
url_repo: https://github.com/dask/dask
---

# Dask

## Pourquoi
**Parallel computing pythonic** : APIs identiques à NumPy / pandas / scikit-learn mais scale sur multi-core et cluster. Compatible avec ton code existant. Aujourd'hui souvent supplanté par [[Polars]] (rapide single-node) ou [[Ray]] (cluster). Reste utile si tu veux pandas API + scale modeste.

## Quand l'utiliser
- Pandas qui crash en mémoire → swap pour `dask.dataframe`
- Numpy arrays > RAM → `dask.array`
- ML scikit-learn parallèle (`dask-ml`)
- Embarrassingly parallel sur cluster modeste
- Migration progressive depuis pandas avant Spark

## Quand NE PAS l'utiliser
- Single-node fast → [[Polars]] (5-100x plus rapide)
- Vrai cluster big data → [[Spark]] (mature, gestion mémoire JVM)
- ML distribué moderne → [[Ray]] (Ray Tune, Ray Train, Ray Serve)
- Streaming → [[Flink]] / Spark Structured

## Pièges connus
- **Performance** : pas magique. Si pandas crash en mémoire, Dask est 5-10x plus lent que Polars equivalent
- **Scheduler** : threaded vs multiprocess vs distributed — choisir selon GIL release du code
- **Workers memory** : `--memory-limit` par worker, spill to disk auto si overflow
- **Lazy** : `.compute()` matérialise. Erreurs latentes jusque-là.
- **Imports** : `from dask import dataframe as dd`, pas `dd = pd`. Sémantique différente sur certains ops.
- **vs Modin** : Modin = drop-in pandas (un import suffit), Dask = explicite

## Liens
- [[Polars]] — alternative single-node moderne
- [[Spark]] — alternative big-data
- [[Ray]] — alternative ML distribué
- Docs : https://docs.dask.org/en/stable/
- Dask vs Spark : https://docs.dask.org/en/stable/spark.html
