---
galaxie: dev
nom: altair
alias: [altair, altair-viz]
categorie: tooling/viz
sous_categories: [visualization, grammar-of-graphics, vega-lite, python, declarative]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["plotly", "bokeh", "matplotlib", "seaborn", "ggplot2 (R)"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, viz, grammar-of-graphics, declarative]
url_officiel: https://altair-viz.github.io/
url_docs: https://altair-viz.github.io/
url_repo: https://github.com/altair-viz/altair
---

# altair

## Pourquoi

Library Python **déclarative** basée sur **Vega-Lite** (grammaire des graphiques). Au lieu de dire "trace une ligne, puis ajoute des points, puis…", tu déclares "j'ai une table, mappe `date` à x, `value` à y, colore par `category`" → Altair génère un spec Vega-Lite (JSON) qui rend dans le navigateur (HTML/SVG interactif).

Concise, lisible, composable (concatenation, layering, faceting), idéale pour **exploration data science** et **analyses académiques**. Sortie interactive native (zoom, pan, tooltips, selection cross-chart). Combo naturel avec **Streamlit** (`st.altair_chart` natif). Équivalent Python de **ggplot2 (R)** dans l'esprit.

## Quand l'utiliser

- **Analyse exploratoire** avec code propre / lisible / composable
- **Stats / data science** : composer scatter + density + boxplot en quelques lignes
- **Combo Streamlit** : altair natif, plus joli que matplotlib
- **Apprentissage grammaire des graphiques** : pédagogiquement très clair
- **Interactivité simple** : sélection brushing, cross-filter, tooltips
- **Faceting / small multiples** : `chart.facet(row='x', column='y')` trivial
- **Publication scientifique** : SVG / PNG exportable, design sobre
- **Notebooks** : rendu inline natif

## Quand NE PAS l'utiliser

- **Plots très complexes custom** → plotly / matplotlib (contrôle pixel par pixel)
- **Animation / temps réel** → bokeh / plotly (Altair n'a pas d'API anim Python)
- **Très gros volumes** (>5k points) : limit max_rows par défaut (configurable mais OK jusqu'à ~50k)
- **Embed dans app non-web** : Altair est web-first
- **Streaming / mise à jour live** : pas son fort
- **Geo viz très avancée** : Altair fait du choropleth simple, pour le reste utiliser plotly / geopandas

## Pièges connus

- **Limite 5000 rows par défaut** : `MaxRowsError` → `alt.data_transformers.disable_max_rows()` ou downsampling ou `alt.data_transformers.enable('vegafusion')`
- **JSON Vega-Lite spec parfois opaque** pour debug : erreurs Vega cryptiques
- **Moins de plugins / extensions** que plotly
- **Pas de "express" API** : tout est composé via `Chart().mark_*().encode(...)`
- **Encodings type-inference** : Altair devine le type (Q quantitatif, N nominal, O ordinal, T temporal) → erreurs subtiles si mauvais
- **Aliasing dates** : `T` (temporal) vs `O` (ordinal) sur dates a des effets visuels différents
- **Trop de mark types**: mark_line vs mark_point vs mark_area vs mark_bar à connaître
- **Vega-Lite version** lock côté navigateur (CDN) — peut casser si vega change
- **Export SVG/PNG** demande `vl-convert-python` ou `altair_saver` (selenium)
- **Pas de seaborn-style statistical layers** : kde plots, regplot manuels à composer

## Code minimal

```bash
pip install altair vega_datasets
# Optionnels : altair[all] pour tous les renderers et saver
pip install "altair[all]"
```

```python
import altair as alt
from vega_datasets import data

cars = data.cars()

# Scatter de base
chart = alt.Chart(cars).mark_point().encode(
    x="Horsepower:Q",
    y="Miles_per_Gallon:Q",
    color="Origin:N",
    tooltip=["Name", "Year", "Horsepower", "Miles_per_Gallon"],
).properties(
    title="Conso vs Puissance par origine",
    width=600, height=400,
)
chart.show()                       # ou chart.save("chart.html")
```

```python
# Layering : scatter + regression
import altair as alt

base = alt.Chart(cars).encode(x="Horsepower:Q", y="Miles_per_Gallon:Q")
points = base.mark_point()
regression = base.transform_regression(
    "Horsepower", "Miles_per_Gallon"
).mark_line(color="red")

(points + regression).properties(width=500, height=400)
```

```python
# Faceting : small multiples
alt.Chart(cars).mark_point().encode(
    x="Horsepower:Q",
    y="Miles_per_Gallon:Q",
    color="Origin:N",
).facet(
    column="Origin:N",
).resolve_scale(x="independent")
```

```python
# Interactivite : brush + crossfilter
brush = alt.selection_interval()
chart = alt.Chart(cars).mark_point().encode(
    x="Horsepower:Q",
    y="Miles_per_Gallon:Q",
    color=alt.condition(brush, "Origin:N", alt.value("lightgray")),
).add_params(brush)

bars = alt.Chart(cars).mark_bar().encode(
    x="count():Q",
    y="Origin:N",
    color="Origin:N",
).transform_filter(brush)

chart & bars                       # vertical concat
```

```python
# Bypass limite 5000 rows pour gros datasets
alt.data_transformers.disable_max_rows()
# Mieux : VegaFusion (Rust backend, scale 100k+ rows)
# pip install vegafusion[embed]
alt.data_transformers.enable("vegafusion")
```

```python
# Combo Streamlit
import streamlit as st
st.altair_chart(chart, use_container_width=True)
```

## Liens

- Vega-Lite (foundation) : https://vega.github.io/vega-lite/
- plotly / bokeh — alternatives interactives plus imperatives
- matplotlib / seaborn — alternatives statiques
- ggplot2 (R) — équivalent grammar-of-graphics
- VegaFusion — backend Rust pour scale (100k+ rows)
- Docs : https://altair-viz.github.io/
- Gallery : https://altair-viz.github.io/gallery/index.html
- GitHub : https://github.com/altair-viz/altair
