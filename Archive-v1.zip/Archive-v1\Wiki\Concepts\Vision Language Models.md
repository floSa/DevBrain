---
galaxie: wiki
nom: Vision Language Models (VLM)
alias: [VLM, LLaVA, CLIP, multimodal, GPT-4V, vision LLM]
type: concept
categorie: concept/multimodal
sous_categories: [vlm, multimodal, vision, llm]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Radford 2021 (CLIP), Liu 2023 (LLaVA), Alayrac 2022 (Flamingo)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, multimodal, vision, llm, vlm]
---

# Vision Language Models — VLM

## TL;DR

Modèles qui prennent **images + texte en input**, génèrent du texte. Architecture standard : **vision encoder** (CLIP, SigLIP) + **projector** (linear / MLP / Q-Former) + **LLM decoder**. Models : **GPT-4o/4V**, **Claude 3+ vision**, **Gemini** (native multimodal), **LLaVA** family (open), **Qwen-VL**, **InternVL**, **Molmo**, **Pixtral**, **Phi-3.5-Vision**. Tasks : **VQA**, **DocVQA**, **OCR-free document AI**, **grounding**, **captioning**, **chart/table reading**, **multi-image reasoning**. Standard 2026 : VLM intégré aux LLM frontier (Claude, GPT-4o, Gemini all native multimodal).

## Le problème

LLM textual seul ne peut pas :
- **Read** des images (logos, charts, screenshots)
- **Comprendre** documents PDF avec figures
- **Reasoner** sur multimodal (vision + texte)

→ Étendre les LLMs avec **vision input**.

## L'idée

### Architecture standard

```
[Image]
   │
   ▼
[Vision encoder]  (CLIP, SigLIP, ViT)
   │ visual features (~256 patches × 1024 dim)
   ▼
[Projector]       (linear, MLP, Q-Former)
   │ projected to LLM embedding space
   ▼
[LLM decoder]     (Llama, Qwen, etc.)
   │ + text tokens
   ▼
[Text output]
```

### Vision encoders

#### CLIP (Radford 2021)

Pre-trained par **contrastive learning** sur 400M (image, text) pairs. Vision encoder bien aligné avec texte → bon départ pour VLM.

- ViT-B/16, ViT-L/14, ViT-H/14
- 224 ou 336 input resolution
- Standard depuis 2021

#### SigLIP (Zhai 2023, Google)

CLIP variant avec **sigmoid loss** au lieu de softmax. Plus simple, plus efficace.

- SigLIP, SigLIP 2 (2024)
- Standard moderne (utilisé par Gemini, Pixtral)

#### DINOv2 (Oquab 2023)

Self-supervised, pas contrastive. Très bonnes features universal. Pas spécifiquement aligné avec texte.

### Projector

**Bridge** entre vision et LLM embedding space.

#### Linear projection

Simple `Linear(d_vision → d_llm)`. LLaVA-1 original.

#### MLP projector

`Linear → GELU → Linear`. LLaVA-1.5. **Standard moderne**.

#### Q-Former (BLIP-2)

**Querying Transformer** : Q learnable queries qui extraient l'info de l'image. Plus compressed.

#### Cross-attention (Flamingo)

Insérer cross-attention layers dans le LLM. Plus complexe mais expressif.

### Familles de VLM

#### Native multimodal

LLM entraîné from scratch sur image + text :
- **Gemini** : native multimodal
- **GPT-4o** : unified tokenizer (audio + image + text)
- **Chameleon** (Meta) : tokenize images
- **Fuyu** : pas de vision encoder séparé

Best quality, pretraining cher.

#### LLaVA-style (vision encoder + LLM frozen)

Plus simple : encoder frozen + projector + LLM (peut être fine-tuné).

Trade-off : moins puissant que native, mais beaucoup moins cher à train.

Variants : LLaVA-1, 1.5, 1.6/NeXT, LLaVA-OneVision.

#### Modèles VLM en 2026

| Famille | Modèles |
|---|---|
| **Closed frontier** | GPT-4o/4V, Claude 3+ (Haiku/Sonnet/Opus), Gemini 1.5/2.5 |
| **Open Meta** | Llama 3.2 Vision, Llama 4 (native) |
| **Open Qwen** | Qwen-VL, Qwen2-VL, Qwen2.5-VL |
| **Open DeepSeek** | DeepSeek-VL, DeepSeek-VL2 |
| **Open MS** | Phi-3.5-Vision, Phi-4-Multimodal |
| **Open Mistral** | Pixtral 12B |
| **Open InternLM** | InternVL 1-3 |
| **Open Allen** | Molmo / PixMo |
| **LLaVA family** | LLaVA-1.6, LLaVA-OneVision |
| **MiniCPM-V** | OpenBMB, small but strong |
| **CogVLM** | Tsinghua |

### Tâches

#### VQA (Visual Question Answering)

"Combien de chats dans cette image ?" → "3"

Standard tâche.

#### Document understanding

DocVQA, ChartQA, AI2D : analyse documents (PDF text, charts, diagrams).

#### OCR-free document AI

VLM lit directement le texte de l'image. Compétitif avec OCR + LLM.

#### Grounding / referring expressions

"Where is the red car?" → bounding box coordinates.

#### Image captioning

"Décris cette image" → description.

#### Visual reasoning

"Si je retire ces blocs, qu'arrive-t-il ?" → reasoning sur scenes.

#### Multi-image / multi-turn

Comparer plusieurs images, conversation référant aux images.

### Tokenization d'images

Image découpée en **patches** (typ. 14×14 ou 16×16 pixels) → chaque patch = 1 "token visuel".

Image 336×336 / 14 = 24×24 = **576 visual tokens**.

**High-resolution** : dynamic resolution (AnyRes) → tile l'image en sous-images, traite chacune.

### Performance benchmarks

- **MMMU** : multimodal reasoning, hard
- **MMBench, SEED-Bench** : general
- **DocVQA, ChartQA, AI2D** : documents
- **MathVista** : math visuel
- **POPE, HallusionBench** : hallucinations
- **MM-Vet** : capabilities
- **OCRBench** : OCR-like tasks

### Common pitfalls / failure modes

#### Hallucinations

VLM peut **inventer** objets pas dans l'image. Standard problem.

Mitigations :
- **POPE-style eval** : test hallucinations
- **Self-consistency** : multiple samples
- **Chain-of-thought** : "describe what you see step by step"

#### Resolution sensitivity

Petits détails ratés en low-res. Anyres / dynamic resolution aide.

#### OCR errors

VLM moins fiable que OCR dédié sur dense text. Combine si critical.

#### Counting

VLMs mauvais à compter > 5 objets. Known limitation.

#### Spatial reasoning

"Left of, behind" → souvent wrong.

### Best practices

1. **Choose right model** : Claude / GPT-4o frontier ; Pixtral / Qwen-VL open
2. **High-res quand utile** : details matter, use AnyRes-capable
3. **Multi-image carefully** : context window limit
4. **Prompt design** : "describe step by step", "look closely"
5. **OCR fallback** : if dense text, use dedicated OCR
6. **Verify counts** : ne pas trust > 5
7. **Eval custom** sur ton domaine (chart QA, docs, etc.)
8. **Cost watch** : images = many tokens

## Quand c'est utile

- **Document AI** : invoices, contracts, forms
- **Chart / table reading** : graphs, dashboards
- **Screenshot analysis** : bug reports, UIs
- **Medical imaging** (with caution)
- **Visual QA chatbots**
- **Content moderation** : detect harmful images
- **Accessibility** : describe images for blind users
- **E-commerce** : product image analysis
- **Surveillance / security** (with ethics)
- **Educational** : textbook diagrams

## Quand ça ne marche pas / pièges

- **Hallucinations** : objects que the model invents
- **Counting** : > 5 souvent wrong
- **Spatial reasoning** : weak
- **Text OCR** : moins fiable que OCR dedicated for dense text
- **Small text** : misses faces, small letters
- **Multi-modal alignement** : long videos hard
- **Cost** : 1 image = 500-2000 tokens
- **Latency** : vision processing + LLM = slower
- **Multi-image limit** : context window
- **Medical / legal** : NOT trust for diagnosis without expert review
- **Adversarial images** : visual prompt injection (text in image)

## Code minimal

```python
# 1. Claude Vision
import anthropic
import base64

client = anthropic.Anthropic()

def claude_vision(image_path, question):
    with open(image_path, "rb") as f:
        image_data = base64.standard_b64encode(f.read()).decode("utf-8")
    
    response = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": [
                {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": image_data}},
                {"type": "text", "text": question}
            ]
        }]
    )
    return response.content[0].text

answer = claude_vision("chart.jpg", "What is the highest bar in this chart?")

# 2. GPT-4o Vision
from openai import OpenAI
client = OpenAI()

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{
        "role": "user",
        "content": [
            {"type": "text", "text": "Describe this image"},
            {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64," + image_data}}
        ]
    }]
)

# 3. Gemini multimodal
import google.generativeai as genai
genai.configure(api_key="...")

model = genai.GenerativeModel("gemini-2.5-pro")
response = model.generate_content([
    "Describe this image",
    {"mime_type": "image/jpeg", "data": image_data}
])

# 4. LLaVA (open via Hugging Face)
from transformers import LlavaNextProcessor, LlavaNextForConditionalGeneration
import torch
from PIL import Image

processor = LlavaNextProcessor.from_pretrained("llava-hf/llava-v1.6-mistral-7b-hf")
model = LlavaNextForConditionalGeneration.from_pretrained(
    "llava-hf/llava-v1.6-mistral-7b-hf",
    torch_dtype=torch.bfloat16,
    device_map="auto"
)

image = Image.open("photo.jpg")
prompt = "[INST] <image>\nWhat is in this image? [/INST]"

inputs = processor(prompt, image, return_tensors="pt").to("cuda")
output = model.generate(**inputs, max_new_tokens=200)
print(processor.decode(output[0], skip_special_tokens=True))

# 5. Qwen2-VL (multi-image support)
from transformers import Qwen2VLForConditionalGeneration, AutoProcessor
model = Qwen2VLForConditionalGeneration.from_pretrained("Qwen/Qwen2-VL-7B-Instruct",
                                                          torch_dtype="auto", device_map="auto")
processor = AutoProcessor.from_pretrained("Qwen/Qwen2-VL-7B-Instruct")

messages = [
    {"role": "user", "content": [
        {"type": "image", "image": "image1.jpg"},
        {"type": "image", "image": "image2.jpg"},
        {"type": "text", "text": "Compare these two images"}
    ]}
]

# 6. CLIP / SigLIP for image-text similarity
from transformers import CLIPModel, CLIPProcessor

clip = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")

texts = ["a cat", "a dog", "a car"]
inputs = clip_processor(text=texts, images=image, return_tensors="pt", padding=True)
outputs = clip(**inputs)
probs = outputs.logits_per_image.softmax(dim=1)
print(probs)  # P(text | image)

# 7. SigLIP (Google, mieux que CLIP souvent)
from transformers import AutoModel, AutoProcessor
siglip = AutoModel.from_pretrained("google/siglip-so400m-patch14-384")

# 8. Image embeddings for multimodal RAG
def image_to_embedding(image, encoder):
    inputs = processor(images=image, return_tensors="pt")
    with torch.no_grad():
        features = encoder.get_image_features(**inputs)
    return features.cpu().numpy()

# Use for multimodal vector DB (ColPali, etc.)
```

## Pour aller plus loin

- Radford et al., *Learning Transferable Visual Models From Natural Language Supervision* (CLIP, ICML 2021)
- Liu et al., *Visual Instruction Tuning* (LLaVA, NeurIPS 2023)
- Alayrac et al., *Flamingo: a Visual Language Model for Few-Shot Learning* (NeurIPS 2022)
- Zhai et al., *Sigmoid Loss for Language Image Pre-Training* (SigLIP, ICCV 2023)
- Bai et al., *Qwen-VL: A Versatile Vision-Language Model for Understanding, Localization, Text Reading, and Beyond* (2023)
- Chen et al., *InternVL: Scaling up Vision Foundation Models* (CVPR 2024)
- *LLaVA* repository and family papers
- *Anthropic Vision*, *OpenAI Vision*, *Gemini* documentation
- **Liens internes** : [[Self-attention]], [[embeddings]], [[Diffusion models]], [[Speech models]], [[Transformer architectures]]
