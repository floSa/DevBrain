---
galaxie: wiki
nom: mcp-obsidian
type: mcp-server
plateforme: universel
categorie: skill/knowledge
sous_categories: [obsidian, vault, rest-api]
auteur: MarkusPfundstein (initial), Ian Sinnott (fork actif)
source: PyPI mcp-obsidian
source_url: https://github.com/MarkusPfundstein/mcp-obsidian
install_cmd: "claude mcp add devbrain --command uvx --args mcp-obsidian --env OBSIDIAN_API_KEY=<clé> --env OBSIDIAN_HOST=127.0.0.1 --env OBSIDIAN_PORT=27124"
install_doc: 
licence: MIT
licence_type: open-source
domaines: [data-science, data-eng, mlops, ml-eng, ai-eng, doc]
score: 5
status: used
mes_projets: [DevBrain]
created: 2026-05-19
modified: 2026-05-19
tags: [mcp, obsidian, devbrain]
---

# mcp-obsidian

## Pourquoi

**LE MCP server** qui fait fonctionner DevBrain. Il parle au plugin Obsidian *Local REST API & MCP Server* (voir [[INSTALL]] §6.1) via HTTPS et expose au client MCP (Claude Code, Desktop, Codex…) les outils suivants :

- `list_files_in_vault` / `list_files_in_dir`
- `read_file_content`
- `create_file` / `patch_content` / `append_to_file`
- `search_files` (search dans tout le vault)
- `get_file_metadata`

Sans lui, Claude peut lire le repo Git de DevBrain mais ne peut pas écrire dedans en respectant le format Obsidian (frontmatter, wikilinks).

## Quand l'utiliser

- **Toujours** quand tu fais tourner Claude sur DevBrain
- N'importe quel autre vault Obsidian où tu veux que l'agent puisse écrire

## Quand NE PAS l'utiliser

- Repo Markdown classique non-Obsidian → utilise [[mcp-filesystem]] direct
- Si tu veux *uniquement* lire (jamais écrire), Claude peut le faire sans MCP via lecture de fichier

## Comment l'installer

Pré-requis : plugin Obsidian *Local REST API & MCP Server* installé (cf. [[INSTALL]] §6.1) + Obsidian ouvert avec ton vault.

```bash
claude mcp add devbrain \
  --command uvx \
  --args mcp-obsidian \
  --env OBSIDIAN_API_KEY=<colle_ta_cle_ici> \
  --env OBSIDIAN_HOST=127.0.0.1 \
  --env OBSIDIAN_PORT=27124

claude mcp list   # doit afficher "devbrain ✓ Connected"
```

Voir [[INSTALL]] section 10 pour le détail complet avec captures.

## Exemples d'usage

Une fois branché, c'est invisible — tu parles à Claude normalement, il utilise les outils MCP en sous-marin :

```
> liste mes fiches Vector DB avec score≥4
> ajoute le service Polars dans la bonne catégorie
> patch la fiche Postgres pour ajouter le wikilink vers REX
```

## Pièges connus

- Si tu fermes Obsidian, le serveur HTTPS s'arrête → `claude mcp list` montre ✗.
- Le port 27124 peut être pris par autre chose (rare). Change le port dans le plugin Obsidian + dans `OBSIDIAN_PORT`.
- Certificate auto-signé : si tu utilises un client MCP autre que `mcp-obsidian`, il faut accepter le cert.

## Liens

- Repo : https://github.com/MarkusPfundstein/mcp-obsidian
- Plugin Obsidian *Local REST API & MCP Server* : https://github.com/coddingtonbear/obsidian-local-rest-api
- Guide d'install DevBrain : [[INSTALL]]
