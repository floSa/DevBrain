---
galaxie: wiki
nom: DRD - Decision Requirements Diagram
alias: [DRD, decision requirements diagram, dmn-drd, decision graph]
type: concept
categorie: concept/business-rules
sous_categories: [dmn, drd, decision-modeling, requirements, graph]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [OMG, Bruce Silver, Alan Fish]
lecture_min: 7
created: 2026-05-21
modified: 2026-05-21
tags: [concept, dmn, drd, business-rules]
---

# DRD — Decision Requirements Diagram

## TL;DR

La **vue graphique de plus haut niveau d'un modèle DMN**. Représente les **décisions** d'un domaine et leurs **dépendances** : quelle décision dépend de quelle input data, de quelle autre décision, de quel knowledge source, de quel BKM. Quatre types de nœuds (Decision, Input Data, Knowledge Source, BKM) + un type d'arc (Information Requirement). Sert de **carte mentale partagée** entre business et IT avant de plonger dans les decision tables. C'est typiquement par où on commence un projet DMN — bien avant la première règle.

## Le problème

Quand tu attaques un domaine de décision riche (assurance auto, scoring crédit, calcul prestations), tu as :
- **10-50 décisions** intriquées
- des **dizaines d'inputs** (data client, data contrat, data marché, data réglementaire)
- des **sources** d'expertise externes (norme Bâle, code des assurances, politique interne)
- des **fonctions communes** à plusieurs décisions

Sans vue d'ensemble : impossible d'expliquer le modèle, impossible de repérer les dépendances cycliques, impossible de phaser le projet. Le DRD est la **carte de territoire** avant de plonger dans les détails de chaque table.

## L'idée

### Les 4 nœuds DRD

```
┌────────────┐
│ Decision   │   rectangle   — une décision à prendre
└────────────┘                 (forme la plus importante)

┌────────────┐
│ Input Data │   ovale       — donnée d'entrée brute, non-décidée
└────────────┘                 (data client, paramètre marché)

┌────────────┐
│ Knowledge  │   "tag"       — source d'autorité externe (humain, doc, norme)
│  Source    │                 NON exécutée par le moteur — pure trace
└────────────┘

┌────────────┐
│   BKM      │   rectangle   — Business Knowledge Model
│            │   avec        — fonction réutilisable, paramétrée
└────────────┘   "coin"
```

### Le seul type d'arc : Information Requirement

Tous les liens dans un DRD sont des **flèches "a besoin de"**. Sens : "B → A" signifie *A nécessite B comme input*.

```
   Input → Decision      : decision lit cet input
   Decision → Decision   : decision aval dépend de decision amont
   BKM → Decision        : decision invoque ce BKM
   BKM → BKM             : BKM compose un autre BKM
   KS → Decision (en pointillés) : decision est encadrée par cette source
   KS → BKM (en pointillés)
```

**Pas de cycle autorisé** : le DRD est un **DAG** (Directed Acyclic Graph). Si tu as un cycle, c'est que ta modélisation est cassée (probable : tu confonds décision et processus).

### Exemple complet : éligibilité prêt immobilier

```
┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐
│ Salaire  │  │ Charges  │  │ Montant  │  │ Durée    │
│ Input    │  │ Input    │  │ demandé  │  │ demandée │
└────┬─────┘  └────┬─────┘  │ Input    │  │ Input    │
     │             │        └────┬─────┘  └────┬─────┘
     ▼             ▼             │             │
   ┌─────────────────────┐       │             │
   │ Taux d'endettement  │       │             │
   │ Decision            │       │             │
   └─────────┬───────────┘       │             │
             │                   │             │
             └─────────┬─────────┴─────────────┘
                       ▼
              ┌─────────────────────┐    ┌────────────────┐
              │ Capacité d'emprunt  │◄───┤ BKM            │
              │ Decision            │    │ formule        │
              └─────────┬───────────┘    │ banque         │
                        │                 └────────────────┘
                        ▼
              ┌─────────────────────┐    ┌─ ─ ─ ─ ─ ─ ─ ─┐
              │ Décision finale     │◄ ─ │ KS:            │
              │ Decision            │    │ HCSF norme 33% │
              └─────────────────────┘    └─ ─ ─ ─ ─ ─ ─ ─┘
```

À noter :
- **Taux d'endettement** est une sous-décision intermédiaire
- **Capacité d'emprunt** invoque un **BKM** réutilisable (formule mathématique)
- **Décision finale** est encadrée par une **Knowledge Source** (la norme HCSF) — non exécutée mais documentée

### Pourquoi commencer par le DRD ?

1. **Cadrage métier** : on parle vocabulaire, pas SQL
2. **Repérage des dépendances** : cycles, doublons, BKM réutilisables apparaissent
3. **Découpage du projet** : on phase par décision (commencer par les feuilles)
4. **Onboarding** : nouvelle personne arrive, regarde le DRD = comprend le domaine en 10 minutes
5. **Lieu de vérité** : c'est le diagram qui survit aux refacto de tables

### Niveaux d'abstraction

Pour un domaine large, plusieurs DRD imbriqués :
- **DRD global** : vue très haute, 5-10 décisions max
- **DRD par sous-domaine** : zoom sur "éligibilité", "tarification", etc.
- **DRD complet** : tous les nœuds (rarement lisible si > 30 nœuds)

Outils comme Trisotech / Camunda Modeler permettent les sous-DRD avec navigation.

### Anti-pattern fréquent

**Une seule grosse table avec 50 inputs** : c'est probablement à découper en plusieurs décisions enchaînées via le DRD. Si tu peux nommer une étape intermédiaire ("calcul du score risque", "ajustement marché"), c'est une sous-décision.

### DRD vs UML class diagram

Confusion classique. UML décrit **types et instances** (statique). DRD décrit **dépendances de calcul** (qui a besoin de quoi pour décider). Ce ne sont pas les mêmes objets — un DRD n'a pas de notions d'héritage, méthodes, ou cardinalité.

## Quand c'est utile

- **Démarrage de tout projet DMN sérieux** : commence toujours par le DRD
- **Communication métier ↔ tech** : le DRD est compréhensible par les business analysts
- **Audit** : un régulateur regarde le DRD pour vérifier que les bons inputs alimentent la décision finale
- **Refactoring** : avant de modifier une decision, regarder le DRD pour voir l'impact aval
- **Documentation vivante** : le DRD reflète l'état actuel des règles, à jour
- **Estimation projet** : compter les decisions du DRD = avoir une idée du scope
- **Découpage en sprints** : implémenter les décisions feuilles d'abord, remonter

## Quand ça ne marche pas / pièges

- **DRD avec 100+ nœuds** : illisible, à découper en sous-DRD
- **Cycle de dépendance** : indication qu'il y a un processus (boucle) déguisé en décision → revoir
- **Confondre Input Data et Decision** : "le score est-il > 0.5 ?" n'est pas un Input, c'est une Decision (avec input "score" et output booléen)
- **BKM oubliés** : si la même formule apparaît dans 3 decisions, c'est un BKM
- **Knowledge Source oubliée** : la conformité (Bâle, HCSF, RGPD) doit être attachée comme KS
- **Pas de cardinalité dans DRD** : tu ne peux pas dire "1..N" comme en UML, DMN est juste un graphe de dépendance
- **DRD figé** : équipes qui dessinent le DRD une fois et ne le maintiennent pas → divergence avec les tables réelles
- **Sur-décomposition** : 30 décisions là où 5 suffisent → cognitive load énorme sans gain
- **DRD purement décoratif** : si tu n'utilises pas un outil L2+ qui exécute, le DRD reste un PowerPoint
- **Pas d'output explicite par décision** : il faut documenter ce que retourne chaque décision (type, schéma)

## Code minimal

DRD en XML DMN (juste la partie structurelle, sans les tables) :

```xml
<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="https://www.omg.org/spec/DMN/20191111/MODEL/"
             id="loanModel" name="Loan eligibility"
             namespace="https://example.com/loan">

  <!-- Input data -->
  <inputData id="salary" name="Salary"/>
  <inputData id="charges" name="Monthly charges"/>
  <inputData id="amount" name="Requested amount"/>
  <inputData id="duration" name="Requested duration"/>

  <!-- Knowledge source -->
  <knowledgeSource id="hcsfRule" name="HCSF 33% rule"/>

  <!-- BKM -->
  <businessKnowledgeModel id="loanFormula" name="Loan capacity formula">
    <encapsulatedLogic>
      <formalParameter name="rate" typeRef="number"/>
      <formalParameter name="duration" typeRef="number"/>
      <literalExpression>
        <text>income * (1 - (1 + rate)**(-duration)) / rate</text>
      </literalExpression>
    </encapsulatedLogic>
  </businessKnowledgeModel>

  <!-- Decision intermédiaire -->
  <decision id="debtRatio" name="Debt ratio">
    <informationRequirement><requiredInput href="#salary"/></informationRequirement>
    <informationRequirement><requiredInput href="#charges"/></informationRequirement>
    <!-- decisionTable ou literalExpression ici -->
  </decision>

  <!-- Decision aval -->
  <decision id="capacity" name="Loan capacity">
    <informationRequirement><requiredDecision href="#debtRatio"/></informationRequirement>
    <informationRequirement><requiredInput href="#duration"/></informationRequirement>
    <knowledgeRequirement><requiredKnowledge href="#loanFormula"/></knowledgeRequirement>
  </decision>

  <!-- Decision finale -->
  <decision id="finalDecision" name="Final decision">
    <informationRequirement><requiredDecision href="#capacity"/></informationRequirement>
    <informationRequirement><requiredInput href="#amount"/></informationRequirement>
    <authorityRequirement><requiredAuthority href="#hcsfRule"/></authorityRequirement>
  </decision>
</definitions>
```

Visualisation : tout outil DMN compatible (Camunda Modeler, Trisotech, dmn-js) génère le DRD depuis ce XML.

## Pour aller plus loin

- Spec OMG, section "Decision Requirements Level" : https://www.omg.org/spec/DMN/
- Bruce Silver, *DMN Method and Style*, ch. 4-5 (DRD)
- Alan Fish, *Knowledge Automation: How to Implement Decision Management in Business Processes* (2012) — précurseur de la pensée DRD
- dmn-js — bibliothèque JS pour rendre un DRD : https://github.com/bpmn-io/dmn-js
- Camunda DMN Modeler — modeling visuel : https://camunda.com/download/modeler/
- **Liens internes** : [[Decision Model and Notation]], [[Decision Tables]], [[FEEL]], [[BKM - Business Knowledge Model]], [[Boxed Expressions]], [[BPMN DMN CMMN]]
