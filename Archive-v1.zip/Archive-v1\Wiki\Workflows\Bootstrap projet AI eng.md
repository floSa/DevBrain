---
galaxie: wiki
nom: Bootstrap projet AI eng
type: workflow
categorie: workflow/ai-eng
sous_categories: [bootstrap, rag, setup, project-init]
domaines: [ai-eng]
duree_estimee: 2-4h
prerequis: [uv installé, Docker installé, clé Anthropic API, repo Git neuf]
created: 2026-05-19
modified: 2026-05-19
tags: [workflow, ai-eng, bootstrap, rag]
---

# Bootstrap projet AI eng

## Quand l'utiliser

Tu démarres un projet AI engineering (RAG, agent, chatbot grounded sur docs) depuis zéro et tu veux avoir un premier POC fonctionnel en une matinée, pas en une semaine.

## Pré-requis

- [[uv]] installé (`uv --version`)
- Docker Desktop
- Clé API Anthropic (export `ANTHROPIC_API_KEY=...`)
- Postgres avec pgvector dispo (local Docker ou managed)
- Repo Git vide

## Procédure

### 1. Squelette de projet

```bash
mkdir mon-rag && cd mon-rag
git init
uv init --name mon_rag
uv add anthropic instructor langchain langchain-anthropic pgvector psycopg2-binary fastapi uvicorn pydantic-settings
uv add --dev pytest pytest-asyncio ruff
```

### 2. Copier le CLAUDE.md du DevBrain

```bash
cp ~/Documents/Projets/DevBrain/CLAUDE-project.md ./CLAUDE.md
$EDITOR CLAUDE.md   # remplace <NOM>, <TYPE=ai-app>, <STACK=Python+FastAPI+pgvector+Claude>
```

### 3. Brancher DevBrain (lecture du brain depuis le projet)

```bash
# Si pas déjà fait : ajouter le MCP devbrain à Claude Code
# Sinon, vérifier qu'il est branché :
claude mcp list   # doit montrer "devbrain ✓ Connected"
```

Voir [[mcp-obsidian]] pour le setup détaillé.

### 4. Structure minimale

```bash
mkdir -p src/mon_rag/{ingest,index,retrieve,generate,eval} tests
touch src/mon_rag/{__init__.py,config.py,api.py}
touch src/mon_rag/ingest/{loaders.py,chunker.py}
touch src/mon_rag/index/{embedder.py,store.py}
touch src/mon_rag/retrieve/retriever.py
touch src/mon_rag/generate/{prompts.py,llm.py}
touch src/mon_rag/eval/{dataset.py,metrics.py}
touch tests/conftest.py
```

Voir [[Pattern - RAG basique]] pour la justification de cette structure.

### 5. Docker Compose pour Postgres + pgvector

```yaml
# docker-compose.yml
services:
  db:
    image: pgvector/pgvector:pg16
    environment:
      POSTGRES_PASSWORD: dev
      POSTGRES_DB: rag
    ports: ["5432:5432"]
    volumes: ["pgdata:/var/lib/postgresql/data"]
volumes:
  pgdata:
```

```bash
docker compose up -d
```

### 6. Premier endpoint qui marche

Code minimum dans `src/mon_rag/api.py` :

```python
from fastapi import FastAPI
from anthropic import Anthropic

app = FastAPI()
client = Anthropic()

@app.post("/ask")
async def ask(question: str):
    resp = client.messages.create(
        model="claude-sonnet-4-7",
        max_tokens=1024,
        messages=[{"role": "user", "content": question}],
    )
    return {"answer": resp.content[0].text}
```

```bash
uv run uvicorn src.mon_rag.api:app --reload
# curl -X POST http://localhost:8000/ask -d '{"question": "Hello"}'
```

À ce stade : tu as un endpoint qui parle à Claude. Pas encore de RAG, mais une fondation.

### 7. Ingérer 1 document, embed, store

(itère sur ce point en t'inspirant de [[Pattern - RAG basique]] — chunker, embedder, store en pgvector)

### 8. Retriever + generator avec prompt caching

```python
SYSTEM = "Tu réponds en t'appuyant uniquement sur le contexte fourni. Si tu ne trouves pas, dis-le."

resp = client.messages.create(
    model="claude-sonnet-4-7",
    max_tokens=1024,
    system=[
        {"type": "text", "text": SYSTEM, "cache_control": {"type": "ephemeral"}},
    ],
    messages=[{
        "role": "user",
        "content": f"Contexte:\n{retrieved}\n\nQuestion: {question}"
    }],
)
```

Voir [[prompt-caching]].

### 9. Eval set au plus tôt

Pas de tuning sans 20-30 questions/réponses gold dans `src/mon_rag/eval/dataset.py`. Calcule la baseline (faithfulness, answer relevance) avec [[Ragas]] **avant** d'optimiser.

### 10. Outils à activer dans ce projet

- [[claude-api]] — guide les prompts caching et migrations de modèle
- [[claude-review]] — review tes PRs
- [[anthropic-xlsx|anthropic-skills:xlsx]] — utile si tu manipules des datasets en xlsx
- [[mcp-obsidian]] — lecture du DevBrain
- [[claude-update-config|update-config]] — si tu veux setter des hooks

## Checklist de fin

- [ ] `uv run pytest` passe (au moins 1 test)
- [ ] `curl /ask` répond
- [ ] Postgres + pgvector tournent dans Docker
- [ ] Un document est ingéré, chunké, embedé, stocké
- [ ] `claude mcp list` montre devbrain connecté
- [ ] CLAUDE.md du projet est personnalisé
- [ ] README.md du projet décrit comment lancer le tout
- [ ] Eval set initial (10 Q/A minimum) versionné

## Pièges courants

- **Sauter l'eval** "je ferai après". Non, fais-le maintenant — sinon tu optimiseras à l'aveugle.
- **Choisir le modèle d'embedding sans benchmark sur ton domaine** — teste 2-3 modèles sur 5 questions, pas juste OpenAI par habitude.
- **Pas de cache control dans le prompt** dès le départ → factures explosent dès le scale.
- **Pas de logging structuré** → debug RAG-qui-foire = enfer. Logge query, chunks récupérés, prompt final, réponse, à chaque appel.

## Variantes

- **Agent multi-tools** au lieu de RAG simple → utiliser [[LangGraph]] ou [[PydanticAI]]
- **Multi-provider** → ajouter [[LiteLLM]] dès le départ
- **Pas de Postgres dispo** → DuckDB + DuckDB-VSS, ou Qdrant managed

## Voir aussi

- Pattern central : [[Pattern - RAG basique]]
- Concepts : [[RAG]], [[embeddings]], [[prompt-caching]]
- Services : [[Anthropic Claude API]], [[Postgres]], [[LangChain]], [[Instructor]]
- Outils utiles : [[claude-api]], [[claude-review]]
