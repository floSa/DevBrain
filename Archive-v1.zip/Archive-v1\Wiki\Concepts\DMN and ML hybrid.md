---
galaxie: wiki
nom: DMN and ML hybrid
alias: [dmn-ml, ml-rules-hybrid, hybrid-ai, ml-augmented-rules]
type: concept
categorie: concept/business-rules
sous_categories: [dmn, hybrid-ai, ml-eng, decision-intelligence, mlops]
domaines: [ml-eng, ai-eng, data-science]
maturite: emerging
auteurs_cles: [James Taylor, Bruce Silver, Lorien Pratt]
lecture_min: 8
created: 2026-05-21
modified: 2026-05-21
tags: [concept, dmn, ml, hybrid, mlops]
---

# DMN and ML hybrid

## TL;DR

Combiner **règles métier DMN** et **modèles ML** pour des décisions opérationnelles qui exploitent **le meilleur des deux mondes** : précision prédictive du ML + auditabilité / conformité des règles. Patterns clés : (1) **ML produit une feature** (score), **DMN décide** sur cette feature + d'autres règles ; (2) **DMN orchestre** plusieurs ML models (ensemble) ; (3) **DMN définit les exceptions** que le ML ne doit pas décider seul (clients VIP, montants élevés, segments sensibles). Brique architecturale d'une stratégie de [[Decision Intelligence]].

## Le problème

ML pur :
- 🟢 Précis sur les patterns appris
- 🔴 Boîte noire (explainability limitée)
- 🔴 Drift silencieux (perf dégrade sans alerte fonctionnelle)
- 🔴 Pas auditable au cas par cas (régulateur : "expliquez cette décision")
- 🔴 Pas d'expression facile pour règles métier rares mais critiques ("client VIP toujours auto-approved")
- 🔴 Coupling fort entre features et décisions

Rules pur :
- 🟢 Auditable, explicable, conforme
- 🟢 Modifiable sans réentraînement
- 🔴 Rigide, ne s'adapte pas aux patterns subtils
- 🔴 Demande des analystes pour les ajustements fins
- 🔴 Combinatoire explose si beaucoup de variables continues

**Hybride** : ML pour les patterns subtils (score prédictif), DMN pour les règles métier explicites par-dessus.

## L'idée

### Architecture canonique

```
   [Customer data]   [Market data]   [Behavioral data]
        │                │                │
        └────────────────┼────────────────┘
                         │
                         ▼
                  [Feature pipeline]
                         │
                         ▼
                  [ML model(s)]
                         │
                         │  score / probabilité / classe
                         ▼
        ┌────────────────────────────────────┐
        │  DMN Decision                       │
        │  (combine score + business rules)   │
        └─────────────────┬───────────────────┘
                          │
                          ▼
                  ┌───────────────┐
                  │   Décision    │
                  │   + audit     │
                  └───────────────┘
```

Le score ML est **un input** parmi d'autres pour la DMN. La DMN définit comment ce score se combine aux règles métier.

### Pattern 1 — Threshold + exception rules

Le pattern le plus simple et le plus utilisé.

```feel
// Decision : crédit
| score_ml          | revenu_annuel | tier_client    | → décision        |
|-------------------|---------------|----------------|-------------------|
| > 0.9             | -             | -              | "auto_approve"    |
| [0.7..0.9]        | > 50000       | -              | "approve"         |
| [0.7..0.9]        | <= 50000      | -              | "manual_review"   |
| [0.5..0.7]        | -             | "VIP"          | "approve"         |
| [0.5..0.7]        | -             | not "VIP"      | "manual_review"   |
| < 0.5             | -             | "VIP"          | "manual_review"   |
| < 0.5             | -             | not "VIP"      | "auto_reject"     |
```

Le ML calcule le score. La DMN exprime :
- les **seuils business** (auto / review / reject)
- les **exceptions** (VIP traité différemment)
- les **garde-fous** (revenu min même si score haut)

Modifier les seuils = modifier la DMN, **pas re-entraîner le ML**. Énorme gain d'agilité.

### Pattern 2 — Ensemble de modèles via DMN

Plusieurs modèles ML votent / agrègent via DMN.

```feel
// Inputs : score_credit_xgb, score_credit_logreg, score_fraud_nn

// Étape 1 : agréger via context
let
  score_credit_avg = (score_credit_xgb + score_credit_logreg) / 2,
  is_high_fraud = score_fraud_nn > 0.85
in {
  // Étape 2 : decision table
  decision: ...   // basé sur score_credit_avg + is_high_fraud
}
```

DMN devient l'**orchestration layer** entre modèles ML, sans coder en Python.

### Pattern 3 — DMN définit les guard-rails

Le ML peut produire des décisions absurdes (out-of-distribution, biais entraînement). DMN définit des **garde-fous** :

```feel
// Decision : action_finale
| score_ml | montant     | → action                    |
|----------|-------------|-----------------------------|
| > 0.5    | < 1000      | "auto_approve" (low risk)   |
| > 0.5    | [1000..50k] | "auto_approve"              |
| > 0.5    | > 50000     | "manual_review" (always for high amounts) |
| <= 0.5   | -           | "manual_review" or "reject" |
```

Même si le ML dit "ok à 95%", **au-dessus de 50k€ tu vérifies manuellement**. Garde-fou de **bon sens** que le ML n'apprendra jamais par lui-même (sauf si tu lui apprends, mais c'est plus propre en DMN).

### Pattern 4 — DMN définit les inputs ML

Inverse : la DMN décide quel modèle invoquer, ou avec quels paramètres.

```feel
// Decision : "quel modèle utiliser"
| segment_client | → modèle_à_utiliser    |
|----------------|-------------------------|
| "B2B"          | "credit_b2b_v3"         |
| "B2C_jeune"    | "credit_b2c_young_v2"   |
| "B2C_senior"   | "credit_b2c_senior_v4"  |
```

Plusieurs modèles ML spécialisés par segment, DMN dispatche. Pratique pour **multi-tenant**, **segmentation marketing**, **A/B test de modèles**.

### Pattern 5 — Feature engineering en DMN

Pour des features simples mais business-critical, DMN remplace le feature pipeline :

```feel
// BKM : compute_features
function(customer, transactions)
{
  recency_days: today() - max([t.date | t in transactions]),
  frequency_90d: count([t | t in transactions, t.date > today() - duration("P90D")]),
  total_amount_30d: sum([t.amount | t in transactions, t.date > today() - duration("P30D")]),
  has_chargeback_12m: some t in transactions satisfies
                       t.is_chargeback and t.date > today() - duration("P12M")
}
```

Ces features sont **lisibles, auditables, modifiables** par le métier. Pas tout — mais les "RFM" simples (Recency, Frequency, Monetary) peuvent vivre en DMN.

### Pattern 6 — Shadow deployment ML

Avant d'activer le ML, le faire **tourner en parallèle** des règles existantes (shadow mode). DMN compare les outputs :

```feel
// Decision : monitoring shadow
| dec_rules | dec_ml      | → action               |
|-----------|-------------|------------------------|
| "approve" | "approve"   | "ok"                   |
| "approve" | "reject"    | "ml_disagrees_log"     |
| "reject"  | "approve"   | "ml_disagrees_log"     |
| "reject"  | "reject"    | "ok"                   |
```

Logs les désaccords pour analyse. Permet de **valider le ML sans risque** avant de l'autonomiser.

### Pattern 7 — Continuous feedback loop

Les décisions humaines (manual_review qui finit en approve/reject par un humain) alimentent un dataset pour **fine-tuner / re-entraîner le ML**. Le DMN sert d'**arbitre humain explicite** et de **collecteur de signal**.

```
ML predict → DMN decide → "manual_review"
                              ↓
                         Human reviews
                              ↓
                         Decision : approve
                              ↓
                  Logged with all features
                              ↓
                  Dataset for next training cycle
```

### Architecture practical : ML + DMN ensemble

Stack typique :

```
┌─────────────────────────────────────────────────┐
│           Feature Store ([[Feast]])              │
│  (online + offline, point-in-time correctness)  │
└─────────────────┬───────────────────────────────┘
                  │
       ┌──────────┴──────────┐
       │                     │
       ▼                     ▼
┌─────────────┐       ┌──────────────┐
│  ML Model   │       │ Business     │
│  (serving:  │       │ data         │
│  KServe,    │       │              │
│  vLLM, etc)│       │              │
└──────┬──────┘       └──────┬───────┘
       │                     │
       │  score              │ raw inputs
       │                     │
       └──────────┬──────────┘
                  │
                  ▼
           ┌────────────┐
           │ DMN Engine │
           │ (Camunda /  │
           │  Drools)   │
           └──────┬─────┘
                  │
                  ▼
            [Décision]
```

ML serving en parallèle de Feature store + DMN comme glue + audit layer.

### Anti-patterns

#### Anti-pattern 1 : règles `IF ml_score > 0.7` en Java
Re-implémenter des if/then dans le code applicatif au lieu de DMN défait l'intérêt (perte audit, perte flexibilité métier).

#### Anti-pattern 2 : DMN qui réinvente le ML
Decision table avec 200 lignes pour modéliser ce qu'un random forest fait en 50 lignes Python. Si la logique est statistique, c'est du ML, pas du DMN.

#### Anti-pattern 3 : ML qui apprend les règles
Apprendre par ML "ce client est-il VIP ?" alors que c'est une donnée business explicite — c'est une feature input, pas une prédiction.

#### Anti-pattern 4 : ML qui décide seul sur décisions critiques
Sans DMN au-dessus → pas de garde-fou, pas d'audit, pas d'exception VIP. Régulateur va râler (AI Act, Bâle).

#### Anti-pattern 5 : DMN avec score ML hardcodé
`score = 0.75` dans une decision table. Le score doit venir d'un input (calculé à chaque exécution), pas être figé.

### Lien avec le profil DS/ML/AI eng

Le pattern hybride est **la norme** dans :
- **Assurance** : tarification, anti-fraude, gestion sinistres
- **Banque** : credit scoring, KYC/AML, surveillance trading
- **E-commerce** : pricing dynamique, recommandation produit + filtres business
- **Santé** : aide au diagnostic + protocoles cliniques
- **Public** : éligibilité prestations sociales (ML pour pré-screening, règles pour décision finale)

Pour un ingé Data/ML/AI : maîtriser ce pattern hybride différencie d'un data scientist "pure ML" et te permet d'opérer sur les vrais use cases enterprise (où les régulateurs / juristes ont leur mot à dire).

## Quand c'est utile

- **Décisions opérationnelles** où ML seul est trop boîte noire
- **Conformité régulatoire** : besoin d'audit + override humain
- **Règles métier mixtes** : "ML + exceptions VIP + seuils légaux"
- **Évolution rapide des règles** : modifier DMN > re-entraîner ML
- **A/B test de modèles** : DMN dispatch
- **Shadow deployment** d'un nouveau ML
- **Ensemble de modèles** : DMN orchestre
- **Garde-fous** : ML décide rapidement, DMN bloque les cas critiques (montant > seuil)

## Quand ça ne marche pas / pièges

- **Problèmes purement perceptifs** (image, audio, NLP) : DMN n'apporte rien, ML seul
- **Décisions trading microseconde** : DMN ajoute latence — préférer code natif compilé
- **Pas de règles métier explicites** : si le métier n'a pas d'opinion, pas la peine d'ajouter DMN
- **DMN qui mémorise des cas** : 500 règles "if customer_id = X then ..." = anti-pattern, c'est de la data
- **ML qui prédit les outputs DMN** : circularité, le ML apprend à imiter les règles → autant rester en DMN
- **Pas de feature versioning** : ML appris sur features v1, DMN consomme features v2 = bug subtil
- **Audit trail manquant** : enregistrer "ML score = 0.78" sans le modèle_version → impossible à reproduire
- **DMN as bottleneck** : si DMN engine n'est pas scalable, devient SPOF — préférer engines stateless (Camunda 8) ou compiler la DMN en Java
- **Frontière unclear** entre features et décisions : si "is_vip" est calculé par ML, c'est une feature ; si c'est une donnée business stockée, c'est un input
- **Régulateur examine et trouve "ML score" sans explication** : prévoir SHAP / LIME pour expliquer le score à côté du DMN

## Code minimal

### Stack Python ML + DMN

```python
# pip install pyDMNrules scikit-learn pandas requests
import pickle
from pyDMNrules import DMN
import pandas as pd

# 1. Chargement modèle ML
with open("credit_xgb_v3.pkl", "rb") as f:
    ml_model = pickle.load(f)

# 2. Chargement DMN
dmn = DMN("credit_decision_v12.xlsx")

def decide_credit(customer: dict, request: dict) -> dict:
    # Features pour ML
    features = pd.DataFrame([{
        "age": customer["age"],
        "income": customer["income"],
        "credit_history_years": customer["credit_history_years"],
        "amount_requested": request["amount"],
        # ... 20-100 features typiques
    }])

    # Score ML
    score = float(ml_model.predict_proba(features)[0][1])

    # DMN inputs : score ML + données business
    dmn_inputs = {
        "score_ml": score,
        "income": customer["income"],
        "amount_requested": request["amount"],
        "is_vip": customer["tier"] == "VIP",
        "is_employee": customer.get("is_employee", False),
    }

    status, dmn_output = dmn.decide(dmn_inputs)

    return {
        "decision": dmn_output["decision"],
        "ml_score": score,
        "ml_model_version": "credit_xgb_v3",
        "dmn_model_version": "credit_decision_v12",
        "rules_fired": dmn_output.get("rules_fired", []),
    }
```

### Stack Java Camunda — ML score injecté comme variable BPMN

```java
// Service Task BPMN : appelle l'API ML
public class ScoreCalculationDelegate implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) {
        Map<String, Object> features = extractFeatures(execution);
        double score = mlClient.predict(features);
        execution.setVariable("score_ml", score);
    }
}

// Business Rule Task BPMN : invoque la DMN avec score_ml + autres
// (configurée dans le BPMN XML avec camunda:decisionRef="creditDecision")
// La DMN lit "score_ml" comme input, applique ses règles, retourne "decision"
```

### Eval offline d'un duo ML+DMN

```python
# Tester un dataset historique avec ML + DMN
from sklearn.metrics import classification_report

def eval_hybrid(test_set):
    predictions = []
    true_labels = []
    for row in test_set:
        result = decide_credit(row["customer"], row["request"])
        # Mapper la décision en classe binaire (pour comparer au label)
        pred = 1 if result["decision"] in ("auto_approve", "approve") else 0
        predictions.append(pred)
        true_labels.append(row["actual_outcome"])

    print(classification_report(true_labels, predictions))
    # Compare aussi : pure ML (juste seuil 0.5 sur score) vs hybride
```

### Monitoring drift hybride

```python
# Métriques à monitorer en prod
metrics = {
    "ml_score_distribution": ...,             # drift de la distribution du score ML
    "auto_approve_rate": ...,                  # part des auto-decisions
    "manual_review_rate": ...,                 # part envoyée à l'humain
    "human_override_rate": ...,                # quand humain annule la suggestion
    "rules_fired_distribution": ...,           # quelles règles tirent le plus
    "ml_rules_disagreement_rate": ...,         # shadow comparison
}
# Alertes : drift score > seuil, override_rate qui monte, etc.
```

## Pour aller plus loin

- James Taylor, *Digital Decisioning* (2019) — l'union règles+ML
- Bruce Silver, *DMN Method and Style*, chapitre sur ML integration
- Camunda blog "Integrating Machine Learning with DMN" : https://camunda.com/blog/
- Drools + KIE Server + Python ML services : pattern documenté
- Lorien Pratt, *Link* (2019) — angle Decision Intelligence
- AI Act EU (2024) — exigences décisions automatisées significatives
- **Liens internes** : [[Decision Model and Notation]], [[Decision Intelligence]], [[Explainability and decision automation]], [[Reward modeling]], [[Feast]], [[KServe]], [[MLflow]], [[Data drift]], [[Multi-armed bandits]]
