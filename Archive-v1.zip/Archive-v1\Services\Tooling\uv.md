---
galaxie: dev
nom: uv
alias: [uv, astral-uv]
categorie: tooling/package
sous_categories: [package-manager, python, rust-tooling, virtualenv]
licence: MIT OR Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Rust
clients_officiels: [cli]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: ["[[pip]]", "poetry", "Hatch", "PDM", "Rye"]
remplace: ["[[pip]]", "poetry", "virtualenv", "pyenv"]
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, tooling, python, package-manager, rust]
url_officiel: https://docs.astral.sh/uv/
url_docs: https://docs.astral.sh/uv/
url_repo: https://github.com/astral-sh/uv
---

# uv

## Pourquoi
Gestionnaire de packages Python écrit en Rust par Astral (auteurs de [[Ruff]]). 10-100x plus rapide que pip, gère aussi les versions de Python (remplace pyenv), les venvs, les lockfiles, l'exécution de tools (`uvx` = pipx). Le **défaut moderne** pour Python.

## Quand l'utiliser
- Tout projet Python neuf
- Migration depuis pip/poetry/pdm/rye (très simple, formats compatibles)
- CI/CD : install des deps en quelques secondes au lieu de minutes
- Outils en ligne de commande Python (`uvx <tool>` au lieu de `pipx install <tool>`)
- Gestion des versions Python sans pyenv

## Quand NE PAS l'utiliser
- Projet legacy fortement couplé à Poetry/PDM avec tooling custom
- Si tu ne veux qu'un usage trivial 1-fichier → `pip install` direct OK
- Workflow conda lourd avec environnements binaires non-PyPI → conda reste pertinent

## Pièges connus
- **Très jeune** : 1.0 récente, encore quelques edge cases (par ex. wheels exotiques)
- **`uv pip` vs `uv add`** : deux APIs (compat pip vs project-aware), comprendre quand utiliser quoi
- **Lockfile `uv.lock`** : à commit, format Astral propriétaire (mais `uv.lock` lisible)
- **Workspace** : support monorepo OK mais nouveau, à tester selon usage
- **Cache global** : par défaut `~/.cache/uv/`, peut grossir (à monitorer en CI)
- **Compat Python 3.13+ free-threaded** : à vérifier selon ta version

## Commandes essentielles

```bash
# Initialiser un projet
uv init monprojet

# Ajouter une dep
uv add fastapi
uv add --dev pytest ruff

# Synchroniser (équivalent install)
uv sync

# Lancer un script avec ses deps
uv run python script.py

# Lancer un outil sans l'installer (pipx-like)
uvx ruff check .

# Installer une version Python
uv python install 3.13

# Lockfile
uv lock

# Build / publish
uv build
uv publish
```

## Liens
- [[Ruff]] — autre tool Astral, super combo
- Doc complète : https://docs.astral.sh/uv/
- Migration depuis Poetry : https://docs.astral.sh/uv/guides/migration/
- Comparaison perf : https://github.com/astral-sh/uv#highlights
