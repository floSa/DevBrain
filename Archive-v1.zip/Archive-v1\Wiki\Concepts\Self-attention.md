---
galaxie: wiki
nom: Self-attention
alias: [attention, scaled dot-product, multi-head attention, MHA, transformer attention]
type: concept
categorie: concept/transformers
sous_categories: [attention, transformer, self-attention]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Vaswani et al. 2017]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, transformer, attention, llm]
---

# Self-attention

## TL;DR

**Mécanisme central des Transformers** : chaque token regarde tous les autres dans la séquence et **pondère** ce qui lui est pertinent. Chaque token génère un **query (Q)**, **key (K)**, **value (V)** ; les attention scores = $\text{softmax}(QK^\top/\sqrt{d_k})$ déterminent les poids ; la sortie = pondération des V. **Multi-head** = plusieurs attention en parallèle qui apprennent des relations différentes. Complexité $O(n^2)$ en séquence (le problème central des LLMs longs contexts). Tout le deep learning moderne (GPT, Claude, Llama, BERT, ViT, Whisper) tourne autour de ça.

## Le problème

Les RNN/LSTM traitent les séquences **séquentiellement** → lent, gradient vanishing sur longues séquences, hard à paralléliser. Comment modéliser des dépendances longue-distance **en parallèle**, sans propagation séquentielle ?

## L'idée

### Définition formelle

Pour chaque token $i$ dans la séquence, calculer une représentation comme combinaison pondérée des autres tokens :

$$ \text{Attention}(Q, K, V) = \text{softmax}\left(\frac{QK^\top}{\sqrt{d_k}}\right) V $$

avec :
- $Q \in \mathbb{R}^{n \times d_k}$ : queries (ce que je cherche)
- $K \in \mathbb{R}^{n \times d_k}$ : keys (ce que je propose)
- $V \in \mathbb{R}^{n \times d_v}$ : values (ce que je transmets)
- $n$ : longueur de séquence
- $d_k$ : dimension par head
- $\sqrt{d_k}$ : scaling pour éviter les gradients vanishing du softmax sur grandes valeurs

**Self-attention** = $Q, K, V$ viennent **tous** de la même séquence (entrée $X$ projetée).

### Projection linéaire

À partir de $X \in \mathbb{R}^{n \times d_{model}}$ :

$$ Q = X W_Q, \quad K = X W_K, \quad V = X W_V $$

avec $W_Q, W_K, W_V$ matrices apprises.

### Multi-Head Attention (MHA)

Splitter en $h$ heads, chacune calcule attention indépendamment :

$$ \text{MHA}(X) = \text{Concat}(\text{head}_1, \dots, \text{head}_h) W_O $$
$$ \text{head}_i = \text{Attention}(X W_Q^{(i)}, X W_K^{(i)}, X W_V^{(i)}) $$

Chaque head apprend des **relations différentes** : syntaxe, coréférence, position, sémantique.

### Cross-attention

$Q$ vient d'une séquence A, $K, V$ d'une séquence B → A "regarde" B. Standard en encoder-decoder (T5, BART, Whisper).

### Causal / masked attention

Pour génération **autoregressive** (GPT) : un token ne peut regarder que les tokens **précédents** :

$$ \text{Causal Mask}_{ij} = \begin{cases} 0 & j \leq i \\ -\infty & j > i \end{cases} $$

Ajouté avant softmax pour zéroter les positions futures.

### Bidirectional attention (BERT)

Pas de masque causal — token regarde tout (passé + futur). Pour modèles d'encoding (BERT, RoBERTa, DeBERTa).

### Complexité

- **Temps** : $O(n^2 d)$ — produit $QK^\top$ génère matrice $n \times n$
- **Mémoire** : $O(n^2)$ pour stocker la matrice d'attention

**Bottleneck pour contexts longs** — un context de 1M tokens = matrice de 10¹² éléments. D'où les variants efficaces (voir [[Flash Attention and efficient attention]]).

### KV cache (inférence)

En génération autoregressive, on régénère $Q$ pour le nouveau token, mais $K, V$ des tokens précédents sont **constants** → on les **cache**.

Économise $O(n^2 d) \to O(n d)$ par step.

Mémoire KV cache : $2 \cdot n \cdot \text{layers} \cdot \text{heads} \cdot d_k \cdot \text{bytes}$. Pour Llama-70B avec contexte 8K : ~20 GB. **Dominant en LLM serving**.

→ GQA / MQA réduisent la taille du cache (voir [[Flash Attention and efficient attention]]).

### Pourquoi $\sqrt{d_k}$ ?

Sans scaling, $QK^\top$ a variance $\propto d_k$. Pour grand $d_k$, softmax sature (gradients ~0). Le scaling stabilise.

### Intuition

L'attention = **soft lookup** dans une table. Plus formellement :
- $Q$ = "qu'est-ce que je cherche ?"
- $K$ = "voici de quoi je parle"
- $V$ = "voici ce que je dis"
- Score = compatibilité $Q \cdot K$
- Output = combinaison pondérée des $V$

C'est un **mécanisme d'addressage différentiable**.

### Limites

- **$O(n^2)$** : context long coûteux
- **Positional encoding nécessaire** : self-attention est invariante par permutation. Sans positional encoding, "le chat mange la souris" = "la souris mange le chat".
- **Pas de récurrence** : pas de notion de "mémoire" intrinsèque (à part le KV cache)

## Quand c'est utile

- **Tout Transformer** : GPT, Claude, Llama, Mistral, BERT, T5, Whisper, ViT, etc.
- **Tâches séquentielles** : NLP, ASR, code generation
- **Vision** : ViT, DINO, CLIP image encoder
- **Multimodal** : VLM cross-attention image ↔ texte
- **Compréhension fine** : self-attention capture les coréférences, dépendances syntaxiques
- **Génération** : autoregressive avec causal mask

## Quand ça ne marche pas / pièges

- **$O(n^2)$ explosif** : contexte > 32K → préférer Flash Attention, sliding window, Mamba, etc.
- **Position invariance** : oublier le positional encoding → modèle bag-of-words.
- **Numerical instability** : sans $\sqrt{d_k}$ ou en FP16, softmax peut overflow → utiliser softmax stable + scaling.
- **Attention sink** : tokens initiaux accaparent l'attention (StreamingLLM, Xiao 2023).
- **Lost in the middle** : modèle ignore le milieu du contexte (Liu 2023).
- **Heads redondantes** : beaucoup de heads peuvent être prunées sans perte de perf (Voita 2019).
- **Pas de mémoire long-terme** : KV cache = context window, pas mémoire persistante. Voir [[agent-loops]] / [[RAG]].
- **Causal vs bidirectional** : confondre les deux casse l'arch.

## Code minimal

```python
import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class SelfAttention(nn.Module):
    def __init__(self, d_model, n_heads):
        super().__init__()
        assert d_model % n_heads == 0
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_k = d_model // n_heads
        self.W_q = nn.Linear(d_model, d_model)
        self.W_k = nn.Linear(d_model, d_model)
        self.W_v = nn.Linear(d_model, d_model)
        self.W_o = nn.Linear(d_model, d_model)
    
    def forward(self, x, mask=None):
        B, T, _ = x.shape
        # Project + reshape to (B, n_heads, T, d_k)
        Q = self.W_q(x).view(B, T, self.n_heads, self.d_k).transpose(1, 2)
        K = self.W_k(x).view(B, T, self.n_heads, self.d_k).transpose(1, 2)
        V = self.W_v(x).view(B, T, self.n_heads, self.d_k).transpose(1, 2)
        
        # Scaled dot-product attention
        scores = Q @ K.transpose(-2, -1) / math.sqrt(self.d_k)  # (B, h, T, T)
        if mask is not None:
            scores = scores.masked_fill(mask == 0, float('-inf'))
        attn = F.softmax(scores, dim=-1)
        out = attn @ V  # (B, h, T, d_k)
        
        # Concat heads
        out = out.transpose(1, 2).contiguous().view(B, T, self.d_model)
        return self.W_o(out)

# Causal mask
def causal_mask(T):
    return torch.tril(torch.ones(T, T)).unsqueeze(0).unsqueeze(0)  # (1, 1, T, T)

# PyTorch native (mieux, utilise Flash Attention si disponible)
x = torch.randn(2, 10, 64)
attn_native = F.scaled_dot_product_attention(x, x, x, is_causal=True)

# Hugging Face usage
# from transformers import AutoModel
# model = AutoModel.from_pretrained("bert-base-uncased")
# outputs = model(input_ids, output_attentions=True)
# attentions = outputs.attentions  # tuple of (B, h, T, T) per layer

# Visualisation des heads (matplotlib + bertviz)
# from bertviz import head_view
# head_view(attention=outputs.attentions, tokens=tokens)
```

## Pour aller plus loin

- Vaswani et al., *Attention Is All You Need* (NeurIPS 2017) — paper original
- Karpathy, *Let's build GPT: from scratch, in code, spelled out* (YouTube) — implem from scratch
- Alammar, *The Illustrated Transformer* — visualisation pédagogique
- Bahdanau et al., *Neural Machine Translation by Jointly Learning to Align and Translate* (ICLR 2015) — attention pré-Transformer
- **Liens internes** : [[Positional encoding]], [[Tokenization]], [[Transformer architectures]], [[Flash Attention and efficient attention]], [[Cross-entropy]]
