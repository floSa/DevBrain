---
galaxie: dev
type: rule
domaine: web-app
applicable: type-web
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, web, app]
---

# Règles — Type de projet : Web app

## Principe
App accessible via HTTP, déployée en prod, multi-utilisateur. Healthchecks, observability, sécurité par défaut.

## MUST

- **Healthcheck endpoint** (`GET /health` ou `/healthz`) qui retourne 200 si l'app est OK, 503 sinon. Vérifie au minimum DB joignable.
- **Graceful shutdown** : SIGTERM handling, drain des requêtes en cours avant exit.
- **HTTPS en prod** (cf. [[Rules/Global/Security]]).
- **CORS configuré strictement**. Pas de `*` sur les endpoints qui touchent l'auth ou les données users.
- **Rate limiting** sur les endpoints publics (login, signup, reset password, API publique).
- **Logs structurés** (JSON en prod) — pas de `print()`.
- **Variables d'env** pour la config, pas de fichier de config en clair en prod.

## SHOULD

- **Métriques exposées** (`/metrics` Prometheus ou équivalent).
- **Distributed tracing** (OpenTelemetry) si architecture multi-services.
- **Corrélation ID** sur toutes les requêtes (header `X-Request-ID`).
- **CSP headers** + `Strict-Transport-Security` + `X-Content-Type-Options: nosniff`.
- **Tailles max** sur les uploads, body, query params.
- **Timeouts** explicites sur tout call externe.
- **Versionnement de l'API** : `/v1/...` dès le début.

## NICE-TO-HAVE

- Feature flags (Unleash, LaunchDarkly, ou maison via DB).
- Blue/green ou canary deployment.
- Circuit breakers sur les calls externes.
- Pre-prod environnement identique à la prod.

## Sections déploiement

### Conteneurisation
- Image Docker multi-stage : build → runtime minimal (alpine/distroless).
- User non-root dans le container.
- `HEALTHCHECK` directive dans le Dockerfile.

### Reverse proxy
- Caddy / Nginx / Traefik devant l'app.
- TLS termination au proxy.
- Limite de connections, timeouts.

### Observability minimale
- Logs : stdout en JSON, agrégés par Loki/Datadog/CloudWatch.
- Métriques : Prometheus scrape.
- Erreurs : Sentry ou équivalent (avec PII filtering).

## Voir aussi

- [[Rules/Global/Security]]
- [[Pattern - API REST FastAPI minimale]]
- [[FastAPI]], [[GitHub-Actions|GitHub Actions]]
