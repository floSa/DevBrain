---
galaxie: wiki
nom: LLM-as-judge
alias: [G-Eval, Prometheus, JudgeLM, MT-Bench, AlpacaEval]
type: concept
categorie: concept/llm-eval
sous_categories: [llm-as-judge, eval, llm, biases]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Zheng 2023 (MT-Bench), Liu 2023 (G-Eval)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, eval, judge]
---

# LLM-as-judge

## TL;DR

Utiliser un LLM puissant (GPT-4, Claude) pour **juger** la qualité des outputs d'autres LLMs. Modes : **pointwise** (score absolu 1-5), **pairwise** (A vs B → A meilleur), **reference-based** (vs gold) ou **reference-free**. Frameworks : **G-Eval** (Liu 2023), **Prometheus v1/v2** (open), **JudgeLM**, **PandaLM**, **MT-Bench**. **Corrélation human ~0.8** sur tâches standards mais : biais positions (préfère A vs B selon ordre), biais verbosity, biais self-enhancement (préfère son propre style). Mitigations : **order swapping**, **multiple judges**, **rubric-based**, **constitutional judge**. Standard en CI eval, RAG eval (RAGAS), Arena Hard auto.

## Le problème

Évaluer du **texte généré** est subjectif :
- Pas de ground truth pour creative
- Tester sur metrics automatiques (BLEU, ROUGE) → poor correlation
- Annotateurs humains = chers, lents

→ Utiliser un **LLM** comme juge. Scalable, fast, raisonnablement corrélé humain.

## L'idée

### Modes

#### Pointwise (scoring absolu)

```
Question: ...
Answer: ...

Score this answer on a scale of 1-5 for:
- Accuracy (1-5)
- Coherence (1-5)
- Completeness (1-5)
- Conciseness (1-5)

Output JSON.
```

Donne un **score absolu** par dimension.

#### Pairwise (comparaison A vs B)

```
Question: ...
Response A: ...
Response B: ...

Which is better, A or B?
Output: A, B, or TIE.
```

Plus simple, plus fiable pour ranking. Standard MT-Bench, AlpacaEval.

#### Reference-based

Judge a accès à la **gold answer** :

```
Reference: <gold>
Generated: ...

Compare. Same meaning? Score 1-5.
```

Plus fiable car ancrage.

#### Reference-free

Pas de gold. Juge évalue **intrinsèquement**.

Pour open-ended generation. Plus subjectif.

### Frameworks

#### G-Eval (Liu 2023)

GPT-4 judge avec **CoT** + structured prompts. Standard moderne.

```
You will be given a summary and reference.
Score the summary on these criteria (1-5):
- Coherence
- Consistency
- Fluency
- Relevance

Think step by step before scoring.
```

#### Prometheus v1, v2 (Kim 2024)

**Open-source** judge LLM, fine-tuned for evaluation.

- Prometheus-7B, Prometheus-13B
- Designed for fine-grained rubric scoring
- Compare commercial GPT-4 judge sur public benchmarks

#### JudgeLM

Open judge model.

#### PandaLM

Reproducible LLM eval framework.

#### Auto-J

13B judge model. Open.

#### Anthropic / OpenAI internal

Industry-leading models used as judge for own models.

### Biais connus

#### Position bias

Pairwise : LLM préfère often **A** (premier) ou **B** (dernier). Tendency varies par modèle.

Mitigation : **swap order**, average results.

#### Verbosity bias

Préfère **réponses longues** (correlation avec quality apparente).

Mitigation : control length, length-controlled metrics (AlpacaEval v2).

#### Self-enhancement bias

Modèle juge préfère son propre style ("Claude judges Claude" → bias).

Mitigation : juge **différent family** (GPT-4 juge Claude, et vice versa).

#### Familiarity bias

Préfère style familier des training data.

#### Confidence bias

Préfère réponses qui paraissent confidentes même si fausses.

#### Order/anchoring bias

Order des criteria affecte scoring.

### Mitigations

#### Order swapping

Pairwise : judge A vs B, puis B vs A. Average.

```python
score_AB = judge(A, B)
score_BA = judge(B, A)
final = (score_AB + (-score_BA)) / 2
```

#### Multiple judges (jury)

N judges (différents models) → vote. Réduit biais.

#### Rubric-based

Structured criteria specifiques. Plus reproducible.

```
Rubric:
- Score 5 if : factually correct AND clear AND complete
- Score 4 if : correct + clear
- Score 3 if : correct
- Score 2 if : partially correct
- Score 1 if : wrong
```

#### Constitutional judge

Donner au judge une "constitution" : règles d'évaluation.

#### Calibrated thresholds

Map scores LLM → human equivalents via small calibration set.

#### Reference-anchored

Toujours fournir une reference quand possible.

### Validation

LLM-as-judge **doit être validé** :
- Eval sur sous-set human-annoté
- Compute correlation : Pearson, Spearman
- Inter-annotator agreement (Cohen's κ, Krippendorff's α)
- Target : > 0.7 corrélation pour usable

### Use cases

#### MT-Bench (Zheng 2023)

GPT-4 juge multi-turn conversations. Standard chat eval.

#### AlpacaEval v2 (length-controlled)

GPT-4 juge vs reference (GPT-4-Turbo). Length-controlled.

#### Arena Hard

Hard subset, GPT-4 judge. Quasi-Arena cost-effective.

#### RAGAS (RAG eval)

LLM judges faithfulness, answer relevance, context precision.

#### Production sampling

Sample des prod traces → LLM judge → quality dashboard.

#### CI eval

Run LLM judge sur dataset gold → CI gate.

### Cost / latency

LLM judge = **another LLM call** → costly :
- GPT-4 judge : ~$0.05 / eval
- Claude judge : ~$0.05 / eval
- Cheap judges (Haiku, mini) : ~$0.005 / eval

Pour 10K eval : 50-500 $.

Mitigations :
- Use cheap judge (Haiku ok pour many tasks)
- Cache judge outputs
- Batch judges API

### Best practices

1. **Different family** judge (avoid self-enhancement)
2. **Order swap** for pairwise
3. **Rubric explicit** : 5 criteria specifiques
4. **Reference quand dispo**
5. **Validate** judge sur human sample (correlation)
6. **Multiple judges** for critical eval
7. **T=0** judge for reproducibility
8. **Prompt cache** judge prompt (saves cost)
9. **Mock judge outputs** in unit tests (deterministic)
10. **Track judge model version** : changes → re-baseline

## Quand c'est utile

- **Chat eval** : MT-Bench, Arena Hard
- **RAG eval** : faithfulness, relevance
- **Summarization eval** : G-Eval
- **Creative writing** : human-like proxy
- **A/B test prompts** : quality scoring
- **CI/CD** : quality regression detection
- **Continuous eval prod** : sample + judge
- **Agent eval** : trajectory quality
- **Safety eval** : harmful content detection

## Quand ça ne marche pas / pièges

- **Self-enhancement** : Claude judge Claude → biased
- **Position bias** : pairwise sans swap
- **Verbosity** : prefer long over short
- **No correlation** : judge model weak → garbage eval
- **Hallucinations in judge** : juge hallucinate scores
- **Stochasticity** : T > 0 → variance, multiple runs needed
- **Out-of-distribution tasks** : judge weak on niche
- **Cost runaway** : eval 10K with GPT-4 = $$$
- **Pas valider** : assume judge is good without check
- **Prompt sensitivity** : small prompt change → different scores
- **Single judge** : biases compound
- **Marketing claim "GPT-4 judges fairly"** : not true, biases real

## Code minimal

```python
import anthropic
client = anthropic.Anthropic()

# 1. Pointwise scoring
def pointwise_judge(question, answer, reference=None):
    ref_block = f"\nReference: {reference}" if reference else ""
    prompt = f"""You are evaluating an LLM answer.

Question: {question}
Answer: {answer}{ref_block}

Score (1-5) on:
- Accuracy: factual correctness
- Coherence: logical flow
- Completeness: covers question
- Conciseness: no fluff

Output JSON only:
{{"accuracy": int, "coherence": int, "completeness": int, "conciseness": int, "reasoning": "..."}}"""
    
    response = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=400,
        temperature=0,  # reproducibility
        messages=[{"role": "user", "content": prompt}]
    )
    import json
    return json.loads(response.content[0].text)

# 2. Pairwise with order swap
def pairwise_judge(question, A, B):
    def judge_one(first, second):
        prompt = f"""Compare these two LLM responses.

Question: {question}

Response A: {first}

Response B: {second}

Which is better overall?
Output: A, B, or TIE. Then explain in 1 sentence.

JSON: {{"winner": "A|B|TIE", "reason": "..."}}"""
        response = client.messages.create(
            model="claude-3-7-sonnet-latest",
            max_tokens=200, temperature=0,
            messages=[{"role": "user", "content": prompt}]
        )
        import json
        return json.loads(response.content[0].text)
    
    result_AB = judge_one(A, B)
    result_BA = judge_one(B, A)
    
    # Combine : if AB says A wins AND BA says B wins → real A wins (consistent)
    if result_AB["winner"] == "A" and result_BA["winner"] == "B":
        return "A"
    if result_AB["winner"] == "B" and result_BA["winner"] == "A":
        return "B"
    if result_AB["winner"] == result_BA["winner"]:
        # Inconsistent : flag
        return "INCONSISTENT"
    return "TIE"

# 3. Rubric-based
RUBRIC = """
Score 5: Factually correct + complete + clear + concise
Score 4: Correct + clear, minor omission
Score 3: Mostly correct, some unclear
Score 2: Partially correct, significant issues
Score 1: Wrong or off-topic
"""

def rubric_judge(question, answer):
    prompt = f"""Use this rubric:
{RUBRIC}

Question: {question}
Answer: {answer}

Output JSON: {{"score": int, "justification": "..."}}"""
    response = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=300, temperature=0,
        messages=[{"role": "user", "content": prompt}]
    )
    import json
    return json.loads(response.content[0].text)

# 4. Multi-judge jury
def jury_judge(question, answer, models=["claude-3-7-sonnet", "gpt-4o", "gemini-1.5-pro"]):
    scores = []
    for model in models:
        scores.append(call_judge(model, question, answer))
    return sum(scores) / len(scores)

# 5. Prometheus v2 (open judge)
# pip install prometheus-eval
# from prometheus_eval import PrometheusEval
# evaluator = PrometheusEval(model_id="prometheus-eval/prometheus-7b-v2.0")
# result = evaluator.absolute_grade(
#     instruction=question,
#     response=answer,
#     reference_answer=reference,
#     rubric=rubric
# )

# 6. G-Eval style with CoT
def g_eval(question, answer, reference):
    prompt = f"""Evaluate this answer step by step.

Question: {question}
Reference: {reference}
Answer: {answer}

Step 1: Identify key facts in reference.
Step 2: Check if answer mentions these.
Step 3: Check factual accuracy.
Step 4: Score 1-5.

Show reasoning, then output JSON: {{"score": int, "missing_facts": [...], "errors": [...]}}"""
    # ... LLM call

# 7. RAGAS (RAG eval)
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy, context_precision

# results = evaluate(
#     dataset=eval_dataset,
#     metrics=[faithfulness, answer_relevancy, context_precision]
# )
# Sous le capot : LLM-as-judge

# 8. Validate judge against human
def validate_judge(judge_fn, human_scored_dataset):
    judge_scores = []
    human_scores = []
    for example in human_scored_dataset:
        j = judge_fn(example["question"], example["answer"])
        judge_scores.append(j["score"])
        human_scores.append(example["human_score"])
    
    from scipy.stats import pearsonr, spearmanr
    p_corr, _ = pearsonr(judge_scores, human_scores)
    s_corr, _ = spearmanr(judge_scores, human_scores)
    return {"pearson": p_corr, "spearman": s_corr}

# 9. Cheap judge for sampling
def cheap_judge(question, answer):
    response = client.messages.create(
        model="claude-3-haiku-20240307",  # cheap
        max_tokens=100,
        messages=[{"role": "user", "content": f"Q: {question}\nA: {answer}\nScore 1-5:"}]
    )
    return parse_score(response.content[0].text)
```

## Pour aller plus loin

- Liu et al., *G-Eval: NLG Evaluation using GPT-4 with Better Human Alignment* (EMNLP 2023)
- Zheng et al., *Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena* (NeurIPS 2023)
- Kim et al., *Prometheus 2: An Open Source Language Model Specialized in Evaluating Other Language Models* (2024)
- *Tatsu-lab AlpacaEval* v2 (length-controlled)
- *RAGAS* documentation
- *Inspect AI* by UK AISI — solid eval framework
- *Patronus AI*, *Galileo*, *Confident AI* — commercial alternatives
- **Liens internes** : [[LLM eval metrics]], [[LLM benchmarks]], [[RAG eval]], [[Agent evaluation]]
