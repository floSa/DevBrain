---
galaxie: dev
nom: vLLM
alias: [vllm]
categorie: llm/local
sous_categories: [inference, serving, paged-attention, throughput]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python (CUDA kernels)
clients_officiels: [python, rest, openai-compat]
plateforme: [linux]
score: 
mes_projets: []
alternatives: ["[[Ollama]]", "[[TGI]]", "[[TensorRT-LLM]]", "[[SGLang]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, local, serving, gpu, inference]
url_officiel: https://docs.vllm.ai/
url_docs: https://docs.vllm.ai/en/latest/
url_repo: https://github.com/vllm-project/vllm
---

# vLLM

## Pourquoi
Serveur d'inférence LLM haute-performance. Implémente **PagedAttention** (gestion mémoire KV-cache façon OS), continuous batching, prefix caching. Le standard open-source pour servir des LLM open-weight en production avec un GPU enterprise.

## Quand l'utiliser
- Production avec GPU enterprise (A100, H100, L40S, ou même RTX 4090 pour modèles modestes)
- Throughput élevé requis (multi-utilisateurs concurrents)
- Modèles HuggingFace open-weight (Llama, Qwen, Mistral, DeepSeek…)
- Besoin d'API OpenAI-compatible (`/v1/chat/completions`, etc.)
- Quand [[Ollama]] ne tient pas la charge

## Quand NE PAS l'utiliser
- Pas de GPU NVIDIA → option limitée (support AMD ROCm en progrès, pas Mac)
- Dev local sur laptop → [[Ollama]] est 100x plus simple
- Modèles propriétaires non-HF → [[vLLM]] couvre HF principalement
- Edge / mobile → solutions dédiées (ONNX, GGUF + llama.cpp)

## Pièges connus
- **VRAM** : à dimensionner soigneusement (`gpu_memory_utilization`, `max_model_len`). Surévaluer → OOM. Sous-évaluer → throughput moindre
- **Quantizations** : AWQ, GPTQ, FP8 supportées mais avec gotchas par modèle
- **Tensor parallelism** : configurable mais nécessite GPUs identiques
- **Tool calling / structured output** : support inégal selon le modèle (vérifier "supported models")
- **Stabilité versions** : nightly vs stable, ne pas mettre `latest` en prod
- **Modèles vision/audio** : support spécifique par release, vérifier compat

## Liens
- [[Ollama]] — pour dev local rapide
- HF model compatibility : https://docs.vllm.ai/en/latest/models/supported_models.html
- Performance benchmarks : https://docs.vllm.ai/en/latest/performance/benchmarks.html
- Docker : `vllm/vllm-openai`
