---
galaxie: wiki
nom: Q-learning and DQN
alias: [Q-learning, DQN, Double DQN, Dueling DQN, Rainbow, replay buffer, target network]
type: concept
categorie: concept/ml
sous_categories: [rl, q-learning, dqn, value-based, off-policy, replay]
domaines: [ml-eng, ai-eng]
maturite: established
auteurs_cles: [Watkins 1989, Mnih 2013/2015 (DQN), Van Hasselt 2016 (Double DQN), Hessel 2018 (Rainbow)]
lecture_min: 9
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, rl, dqn, q-learning]
---

# Q-learning and DQN

## TL;DR

**Q-learning** : algorithme off-policy qui apprend $Q^*(s, a)$ directement par mise à jour TD avec la cible Bellman optimality. **DQN** = Q-learning + réseau de neurones + replay buffer + target network. Famille **value-based**, marche pour **actions discrètes**. Extensions : Double DQN (corrige l'overestimation), Dueling DQN (sépare V et A), Prioritized Replay, n-step, distributional (C51, QR-DQN). **Rainbow** combine les 7 améliorations principales. Pour actions continues → [[Policy gradient]] / SAC / TD3.

## Le problème

Sur les MDPs avec actions discrètes (Atari, jeux de plateau, recommandation), on veut :
1. Apprendre une politique optimale **sans connaître $P$** (model-free)
2. Réutiliser les samples (off-policy, replay buffer)
3. Scaler à des espaces d'états énormes (images pixels) via deep learning

Q-learning donne (1) et (2). DQN ajoute (3) via les neural nets.

## L'idée

### Q-learning tabulaire (Watkins 1989)

Mise à jour stochastique de **Bellman optimality** :

$$ Q(s, a) \leftarrow Q(s, a) + \alpha \big[ r + \gamma \max_{a'} Q(s', a') - Q(s, a) \big] $$

**Off-policy** : on apprend $Q^*$ (action $\arg\max$ greedy) tout en explorant avec ε-greedy ou autre.

**Convergence prouvée** (sous hypothèses : Robbins-Monro pour $\alpha$, toutes les paires (s,a) visitées infiniment souvent) vers $Q^*$ en tabular.

Voir [[Bellman equations]] pour le pourquoi de la mise à jour.

### SARSA — la cousine on-policy

Cible : $r + \gamma Q(s', \pmb{a'})$ où $a' \sim \pi$. Apprend $Q^\pi$, pas $Q^*$. Comportement plus conservateur (cf. cliff-walking).

### DQN — Deep Q-Network (Mnih 2013, Nature 2015)

Trois ingrédients pour faire marcher Q-learning avec un neural net qui voit les pixels :

#### 1. Function approximation
$Q_\theta(s, a)$ approximé par un CNN. Input : 4 dernières frames stacked. Output : un Q par action.

#### 2. Replay buffer
Stocker $(s, a, r, s', \text{done})$ dans une mémoire géante (1M transitions typique), échantillonner uniformément des minibatches.
- Décorrèle les samples (vs. corrélation temporelle naturelle)
- Multiplie la sample efficiency

#### 3. Target network
$Q^-_\theta$ : copie figée du Q-net, mise à jour rare (toutes les N=10000 steps, ou Polyak $\tau$).
- Stabilise la cible $r + \gamma \max_{a'} Q^-(s', a')$ qui sinon "court" avec les updates
- Sans target net, DQN diverge presque toujours

**Loss** :

$$ \mathcal{L}(\theta) = \mathbb{E}_{(s,a,r,s') \sim D} \left[ \big( r + \gamma \max_{a'} Q^-_\theta(s', a') - Q_\theta(s, a) \big)^2 \right] $$

### Améliorations DQN (Rainbow, Hessel 2018)

Sept améliorations qui s'additionnent quasiment toutes :

| Amélioration | Idée |
|---|---|
| **Double DQN** (2016) | Découple sélection et évaluation de l'action max → corrige l'overestimation par $\max$ |
| **Dueling DQN** (2016) | Architecture : $Q(s,a) = V(s) + A(s,a) - \text{moyenne}(A)$ |
| **Prioritized Replay** (2016) | Sample les transitions à fort TD error avec plus de proba |
| **n-step returns** | Cible : $r_{t+1} + \gamma r_{t+2} + \dots + \gamma^n \max_{a'} Q(s_{t+n}, a')$ |
| **Distributional (C51)** | Apprend la distribution de $Q$, pas juste la moyenne |
| **Noisy Nets** | Bruit injecté dans les poids → exploration sans ε-greedy |
| **Multi-step** combine avec les autres | |

**Rainbow** combine tout → 2-5x performance sur Atari vs DQN vanilla.

### Double DQN en détail

Le problème : $\max_a Q^-(s', a)$ surestime systématiquement (inégalité de Jensen + bruit).

Solution : utiliser le **Q-online** pour choisir l'action et le **Q-target** pour l'évaluer :

$$ y = r + \gamma \, Q^-_\theta\!\left(s', \arg\max_{a'} Q_\theta(s', a')\right) $$

Trivial à implémenter, gain quasi-gratuit. Standard depuis 2016.

### Dueling DQN

Architecture où le réseau a **deux têtes** depuis un tronc commun :
- Une tête $V(s)$
- Une tête $A(s, a)$

Et on assemble :

$$ Q(s, a) = V(s) + \Big( A(s, a) - \frac{1}{|\mathcal{A}|} \sum_{a'} A(s, a') \Big) $$

Aide quand beaucoup d'actions ont la même valeur (la valeur de l'état domine).

### Prioritized Experience Replay (PER)

Échantillonner avec proba $p_i \propto |\delta_i|^\alpha$ où $\delta_i$ est le TD error de la transition $i$. Les transitions "surprenantes" (forte erreur) sont rejouées plus souvent. Corriger le biais d'échantillonnage par importance sampling weights.

Gain typique : 2x sur Atari.

### Distributional RL (C51, Bellemare 2017)

Au lieu d'apprendre $\mathbb{E}[G_t | s, a]$ (un scalaire), apprendre **la distribution complète** $Z(s, a)$ représentée sur 51 atomes (d'où C51).

Bellman version distributionnelle :

$$ Z(s, a) \stackrel{D}{=} r + \gamma Z(s', \arg\max_{a'} \mathbb{E}[Z(s', a')]) $$

Plus d'info, meilleurs gradients, plus stable. **QR-DQN, IQN** sont des évolutions.

### Limites de DQN

- **Actions discrètes seulement** : pour continuous, DDPG/SAC
- **Sample inefficient** vs model-based, mais sans replay c'est pire
- **Hyperparam sensible** : learning rate, target update frequency, replay size, ε schedule
- **Pas de stochasticité naturelle** : politique est déterministe (greedy) ; pour exploration, faut l'ajouter explicitement
- **Function approximation + bootstrapping + off-policy = deadly triad** → divergence possible (en pratique : target net + replay + clipping = OK)

## Quand c'est utile

- **Actions discrètes** avec gros espace d'états : jeux, Atari, recommandation discrète
- **Sample efficiency comparée à on-policy** (PPO/REINFORCE) : DQN réutilise chaque transition plusieurs fois
- **Off-policy** souhaitable : tu as des logs d'une autre politique, tu veux apprendre dessus (offline RL est l'extension)
- **Baseline solide en discret** : si t'hésites entre PPO et DQN sur Atari, DQN est plus sample-efficient
- **Combine avec exploration smart** : Noisy Nets + RND fonctionne bien pour hard exploration
- **Production simple** : Q-net inférence = un forward pass + argmax

## Quand ça ne marche pas / pièges

- **Actions continues** : $\max_a Q(s, a)$ intractable → DDPG/SAC (qui sont du policy gradient déguisé)
- **Très gros espace d'actions discrètes** (>1000 actions) : argmax cher, exploration médiocre, préférer policy gradient
- **Reward sparse + exploration faible** : ε-greedy ne suffira pas, ajouter curiosité (RND, count-based)
- **Reward scaling** : magnitudes énormes → gradient instable. Clipper rewards à $[-1, 1]$ (DQN Atari) ou normaliser
- **Replay buffer trop petit** : oubli catastrophique
- **Replay buffer trop grand** : transitions très vieilles polluent
- **Target update trop lent** : apprentissage lent ; trop rapide : instable. Sweet spot ~10000 steps
- **Eval pendant training** : la politique d'eval est greedy ($\varepsilon=0$), pas la politique de comportement
- **NaN / explosion** : presque toujours = gradient pas clippé ou reward pas normalisé
- **Hyperparam transfer** : ce qui marche sur CartPole ne marche pas sur Breakout, tester sur ton env

## Code minimal

```python
# Q-learning tabulaire (FrozenLake)
import numpy as np
import gymnasium as gym

env = gym.make("FrozenLake-v1", is_slippery=False)
n_states, n_actions = env.observation_space.n, env.action_space.n
Q = np.zeros((n_states, n_actions))
alpha, gamma = 0.1, 0.99
eps_start, eps_end, eps_decay = 1.0, 0.05, 0.995
eps = eps_start

for ep in range(5000):
    s, _ = env.reset()
    done = False
    while not done:
        a = env.action_space.sample() if np.random.rand() < eps else int(Q[s].argmax())
        s2, r, term, trunc, _ = env.step(a)
        Q[s, a] += alpha * (r + gamma * Q[s2].max() - Q[s, a])
        s = s2
        done = term or trunc
    eps = max(eps_end, eps * eps_decay)

print("Politique :", Q.argmax(axis=1).reshape(4, 4))
```

```python
# DQN minimal (PyTorch) — squelette
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import random
import numpy as np

class QNet(nn.Module):
    def __init__(self, obs_dim, n_actions):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 128), nn.ReLU(),
            nn.Linear(128, 128), nn.ReLU(),
            nn.Linear(128, n_actions),
        )
    def forward(self, x): return self.net(x)

class ReplayBuffer:
    def __init__(self, cap): self.buf = deque(maxlen=cap)
    def push(self, *transition): self.buf.append(transition)
    def sample(self, n):
        batch = random.sample(self.buf, n)
        return map(lambda x: torch.tensor(np.array(x), dtype=torch.float), zip(*batch))
    def __len__(self): return len(self.buf)

def dqn_step(q, q_target, batch, gamma=0.99):
    s, a, r, s2, done = batch
    a = a.long()
    q_pred = q(s).gather(1, a.unsqueeze(1)).squeeze(1)
    with torch.no_grad():
        q_next = q_target(s2).max(dim=1).values
        target = r + gamma * q_next * (1.0 - done)
    return ((q_pred - target) ** 2).mean()
```

```python
# Double DQN target (drop-in replacement)
def double_dqn_target(q_online, q_target, s2, r, done, gamma=0.99):
    with torch.no_grad():
        next_a = q_online(s2).argmax(dim=1, keepdim=True)              # online sélectionne
        next_q = q_target(s2).gather(1, next_a).squeeze(1)             # target évalue
        return r + gamma * next_q * (1.0 - done)
```

```python
# Dueling head architecture
class DuelingQ(nn.Module):
    def __init__(self, obs_dim, n_actions):
        super().__init__()
        self.tronc = nn.Sequential(nn.Linear(obs_dim, 128), nn.ReLU())
        self.v_head = nn.Linear(128, 1)
        self.a_head = nn.Linear(128, n_actions)
    def forward(self, x):
        h = self.tronc(x)
        V = self.v_head(h)
        A = self.a_head(h)
        return V + A - A.mean(dim=1, keepdim=True)
```

```python
# Stable-Baselines3 en pratique
from stable_baselines3 import DQN
import gymnasium as gym

env = gym.make("CartPole-v1")
model = DQN(
    "MlpPolicy", env,
    learning_rate=1e-3, buffer_size=50_000, learning_starts=1_000,
    target_update_interval=500, exploration_final_eps=0.05,
    verbose=1,
)
model.learn(total_timesteps=100_000)
```

## Pour aller plus loin

- Sutton & Barto, ch. 6 *Temporal-Difference Learning*
- Watkins, *Learning from Delayed Rewards* (PhD thesis, 1989)
- Mnih et al., *Human-level control through deep reinforcement learning* (Nature 2015) — DQN
- Van Hasselt et al., *Deep RL with Double Q-learning* (AAAI 2016)
- Wang et al., *Dueling Network Architectures* (ICML 2016)
- Schaul et al., *Prioritized Experience Replay* (ICLR 2016)
- Hessel et al., *Rainbow: Combining Improvements in Deep RL* (AAAI 2018)
- Bellemare et al., *A Distributional Perspective on RL* (ICML 2017, C51)
- CleanRL DQN single-file : https://github.com/vwxyzjn/cleanrl/blob/master/cleanrl/dqn.py
- **Liens internes** : [[Bellman equations]], [[Value functions]], [[Reinforcement learning]], [[Exploration vs exploitation]], [[Policy gradient]]
