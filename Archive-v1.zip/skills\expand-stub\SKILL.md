---
name: expand-stub
description: |
  Use this skill to expand fiches that are in 'stub' state into full
  fiches. Triggers: "étoffe les stubs", "complète les stubs", "expand
  stubs", "complète le concept <nom>", "fais un pass sur mes stubs dans
  Wiki/Concepts/". Scans the requested area for status: stub, proposes
  expansion one by one (interactive), respects the format of each type
  (concept, workflow, skill, service).
---

# Skill — expand-stub

## Quand l'utiliser

L'utilisateur a créé des fiches en `status: stub` (via `process-inbox` ou manuellement) et veut maintenant les **étoffer une par une** ou par batch.

Cas typique : 1 mois plus tôt il a balancé "ACP", "AFC", "ACM" en stubs. Aujourd'hui il a 1h, il dit "étoffe mes stubs stats".

## Périmètre

Scan possible :
- `Wiki/Concepts/` (par défaut)
- `Wiki/Workflows/`
- `Wiki/Outils/`
- `Services/` (où `status: stub` n'existe pas mais `status: en-eval` peut servir de proxy si le contenu est manifestement incomplet)
- Tout le vault (sur demande explicite)

L'utilisateur peut filtrer par catégorie : "étoffe mes stubs `concept/stats`", "étoffe les stubs dans Wiki/Workflows".

## Procédure

### Étape 1 — Inventaire des stubs

Recherche tous les fichiers `.md` du périmètre demandé qui ont `status: stub` dans leur frontmatter.

Présente à l'utilisateur :

```
Stubs trouvés dans <périmètre> : N fiches

Concept/Stats (5) :
- [[ACP]]    (créé 2026-05-19, note: "réduction dim continue, lib prince")
- [[AFC]]    (créé 2026-05-19, note: "AFC pour categorical")
- [[FAMD]]   (créé 2026-05-19)
- ...

Concept/Time-series (3) :
- [[Stationnarité]]
- ...

Workflow/Data-eng (1) :
- [[Setup pgvector local]]
```

Demande :
- Tu veux tous les étoffer maintenant ? ("oui")
- Une catégorie spécifique ? ("stats")
- Un par un sur demande ? ("ACP")
- Skip pour aujourd'hui ? ("non")

### Étape 2 — Boucle par fiche

Pour chaque stub à étoffer :

**a) Lire la fiche existante**

Récupère le frontmatter (sous_categories, domaines déjà mis), le titre, et la note brute si elle existe.

**b) Étoffer le contenu selon le type**

Invoque le sub-skill correspondant en mode "compléter une fiche existante" :
- Concept → délègue à `add-wiki-concept` avec contexte "fiche existante en stub, l'enrichir en respectant le format"
- Workflow → `add-wiki-workflow` même approche
- Skill → `add-wiki-outil`
- Service → `add-service`

Le sub-skill produit un draft complet (frontmatter enrichi + corps complet) en respectant les conventions de format de son type.

**c) Demander validation**

Montre à l'utilisateur :
- Diff du frontmatter (avant/après)
- Le corps complet généré
- Les wikilinks ajoutés

Demande : "OK pour écrire ? (oui / non / modifier / skip)"

**d) Si validation, écrire**

- Patch la fiche existante (préserve `created`, met à jour `modified`)
- Change `status: stub` → `status: actif` (pour services), `status: ` (vide, pour concepts/workflows), ou `status: discovered` (pour skills si non testé)
- Retire `stub` du `tags:`

**e) Si refus, demander quoi faire**

- "modifier" → quoi spécifiquement ? L'utilisateur précise, on re-génère
- "skip" → passe au stub suivant
- "stop" → arrête la boucle

### Étape 3 — Récap final

```
✅ Étoffés : N stubs
   - X concepts
   - Y workflows
⏭️ Skippés : M
✏️ Modifiés et étoffés : P

Wikilinks créés ce pass : Q
Stubs restants dans <périmètre> : R

Prochaine étape suggérée : cross-link sur Wiki/Concepts/ pour 
détecter les liens manquants entre les nouveaux concepts.
```

## Anti-patterns à éviter

- **Vider tous les stubs sans validation** — toujours par fiche, l'utilisateur valide
- **Inventer du contenu** quand l'utilisateur n'a pas fourni de matière — préfère poser une question
- **Écraser un stub qui contient déjà des notes utilisateur** — toujours préserver les notes brutes en les intégrant
- **Oublier de retirer `stub` du `tags:` et du `status:`** quand la fiche est étoffée

## Format de la "matière de base" pour étoffer

Idéalement, l'utilisateur fournit :
- Une URL (article, doc, paper) → utiliser `defuddle` pour extraire
- Quelques bullets de notes brutes
- Le nom d'une lib/outil principal qu'on peut documenter

Si rien, demander explicitement : "donne-moi 2-3 phrases sur <nom>, ou une URL, ou je passe ?"

## Voir aussi

- `process-inbox` (créé les stubs en premier lieu)
- `add-wiki-concept`, `add-wiki-workflow`, `add-wiki-outil`, `add-service`
- `cross-link` (lancer après expand-stub pour resserrer les liens)
