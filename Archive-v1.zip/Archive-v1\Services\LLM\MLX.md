---
galaxie: dev
nom: MLX
alias: [mlx, mlx-lm, mlx-vlm]
categorie: llm/inference
sous_categories: [apple-silicon, local, metal, unified-memory, fine-tuning]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python / C++
clients_officiels: [python, swift, c++]
plateforme: [macos]
score: 4
mes_projets: []
alternatives: ["[[llama.cpp]]", "[[Ollama]]", "[[PyTorch]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, apple, local, inference, fine-tuning]
url_officiel: https://github.com/ml-explore/mlx
url_docs: https://ml-explore.github.io/mlx/
url_repo: https://github.com/ml-explore/mlx
---

# MLX

## Pourquoi

Framework ML **Apple** optimisé **Apple Silicon** (M1/M2/M3/M4). Exploite la **mémoire unifiée** : le GPU adresse toute la RAM (vs CUDA limitée à la VRAM). Conséquence pratique : un Mac M3 Max 128 Go peut faire tourner un **Llama 3 70B en 4-bit** que les RTX 4090 24 Go ne tiennent pas sans offloading lourd.

API NumPy-like (Python) + lazy evaluation + compilation Metal automatique. **mlx-lm** = wrapper LLM (chargement HF, génération, quantization, fine-tuning LoRA). Souvent **plus rapide que llama.cpp** sur M-series pour les modèles supportés, et reste le seul à faire du **fine-tuning local performant sur Mac**.

## Quand l'utiliser

- **LLM local sur Mac Apple Silicon** (chat, coding assistant offline)
- **Modèles 70B+** qui débordent VRAM CUDA mais tiennent en RAM unifiée Mac (128 Go+)
- **Fine-tuning LoRA local** sur Mac (mlx-lm lora) — quasi unique sur M-series
- **Inférence rapide** : sur M3 Max, Llama 3 8B 4-bit > 80 tok/s
- **VLM (vision)** : mlx-vlm pour Llava, Qwen-VL, Pixtral local
- **Recherche / prototypage** sur laptop sans dépendre de Linux/CUDA
- **Apple ecosystem** : Swift bindings, intégration apps macOS/iOS

## Quand NE PAS l'utiliser

- **Pas de Mac Apple Silicon** → [[llama.cpp]] / [[Ollama]] (cross-platform)
- **CUDA disponible** → [[PyTorch]] + [[vLLM]] / [[SGLang]] meilleurs sur RTX/A100/H100
- **Production server-side multi-user** → cloud APIs ou serveurs Linux GPU
- **Throughput max batch** : MLX optimisé single-user, vLLM gagne en multi-user
- **Modèles très exotiques** : couverture MLX < PyTorch

## Pièges connus

- **Mac only** : aucun support Linux/Windows ou GPU NVIDIA/AMD
- **Écosystème jeune** vs PyTorch — moins de modèles supportés natifs, conversions parfois nécessaires
- **Modèles à convertir au format MLX** : `mlx_lm.convert` ou télécharger depuis `mlx-community` sur HF
- **Quantization moins mature** : 4-bit / 8-bit OK, mais GGUF / GPTQ / AWQ pas natif
- **VRAM = RAM** : un modèle 70B 4-bit prend ~40 Go → Mac 32/64 Go saturent vite, attention au swap
- **Multi-GPU Mac inexistant** : pas de cluster, un seul Mac à la fois
- **Throughput inférieur à vLLM** en serving multi-user (pas de PagedAttention, batching limité)
- **mlx-lm vs MLX core** : ne pas confondre — MLX = framework, mlx-lm = wrapper LLM

## Code minimal

```bash
# Install (Mac Apple Silicon uniquement)
pip install mlx mlx-lm

# Inference rapide depuis HF (auto-download depuis mlx-community)
mlx_lm.generate \
    --model mlx-community/Meta-Llama-3.1-8B-Instruct-4bit \
    --prompt "Explique-moi la memoire unifiee Apple en 3 phrases." \
    --max-tokens 256

# Serveur OpenAI-compat
mlx_lm.server --model mlx-community/Mistral-7B-Instruct-v0.3-4bit --port 8080
```

```python
# API Python directe
from mlx_lm import load, generate

model, tokenizer = load("mlx-community/Meta-Llama-3.1-8B-Instruct-4bit")

prompt = tokenizer.apply_chat_template(
    [{"role": "user", "content": "Capitale du Portugal ?"}],
    tokenize=False, add_generation_prompt=True,
)

response = generate(model, tokenizer, prompt=prompt, max_tokens=128, verbose=True)
print(response)
```

```bash
# Fine-tuning LoRA local sur Mac
mlx_lm.lora \
    --model mlx-community/Mistral-7B-v0.3-4bit \
    --train --data ./data \
    --batch-size 2 --iters 1000 --lora-layers 16
```

## Liens

- [[llama.cpp]] / [[Ollama]] — alternatives cross-platform (Ollama tourne sur MLX en option sur Mac)
- [[PyTorch]] — alternative CUDA / multi-GPU
- [[vLLM]] / [[SGLang]] — alternatives server-side Linux
- mlx-lm : https://github.com/ml-explore/mlx-lm
- mlx-vlm : https://github.com/Blaizzy/mlx-vlm
- Modèles convertis : https://huggingface.co/mlx-community
- Docs : https://ml-explore.github.io/mlx/
- GitHub : https://github.com/ml-explore/mlx
