---
galaxie: wiki
nom: Projections
alias: [projections orthogonales, projection sur sous-espace, projection oblique]
type: concept
categorie: concept/linalg
sous_categories: [projections, orthogonal, oblique, subspace, least-squares]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Gauss, Gram-Schmidt]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, linalg, projections]
---

# Projections — orthogonales et obliques

## TL;DR

Opération qui "écrase" un vecteur sur un sous-espace. **Orthogonale** = le résidu (différence) est perpendiculaire au sous-espace, c'est la projection canonique. **Oblique** = autre direction. Au cœur de la **régression linéaire** (moindres carrés = projection orthogonale sur l'espace colonne de $X$), de la **PCA** (projection sur les composantes principales), et de tout calcul de "meilleure approximation dans un sous-espace".

## Le problème

Étant donné un vecteur $b$ et un sous-espace $S$ de dimension plus petite, on cherche le **vecteur $\hat b \in S$ le plus proche de $b$**. C'est la **meilleure approximation** de $b$ dans $S$.

Cas concrets :
- Régression : projeter $y$ sur l'espace engendré par les colonnes de $X$
- [[PCA]] : projeter les données sur les composantes principales
- Décomposition de signal : projeter sur des bases (Fourier, wavelets)

## L'idée

### Projection orthogonale

Pour un sous-espace $S \subset \mathbb{R}^n$ avec base orthonormée $u_1, \dots, u_k$ rassemblée dans $U = [u_1, \dots, u_k]$ :

$$ \hat b = \text{proj}_S(b) = U U^\top b $$

avec $U U^\top$ la **matrice de projection** (taille $n \times n$, rang $k$).

Si la base n'est pas orthonormée, et que $A$ engendre $S$ (colonnes de $A$) :

$$ P_A = A (A^\top A)^{-1} A^\top $$

(à condition que $A$ soit de rang plein).

### Propriétés d'une matrice de projection $P$

- **Idempotente** : $P^2 = P$ (projeter deux fois = projeter une fois)
- **Symétrique** (si projection orthogonale) : $P = P^\top$
- **Valeurs propres** : 0 ou 1 uniquement
- **Trace** $= \text{rang}(P) = \dim(S)$
- **Décomposition** : $I = P + (I - P)$, où $(I - P)$ projette sur le complément orthogonal $S^\perp$

### Le résidu

$$ b - \hat b = b - P b = (I - P) b $$

Pour projection orthogonale : le résidu est **perpendiculaire à $S$** :

$$ \langle b - \hat b, u \rangle = 0 \quad \forall u \in S $$

C'est l'**équation normale** — base des moindres carrés.

### Moindres carrés via projection

Le problème $\min_x \|Ax - b\|_2^2$ a pour solution :

$$ \hat x = (A^\top A)^{-1} A^\top b $$

et le vecteur projeté $\hat b = A \hat x = A(A^\top A)^{-1} A^\top b = P_A b$.

C'est-à-dire : la régression linéaire trouve la **projection orthogonale** de $y$ sur l'espace colonne de $X$.

### Projection oblique

Si on projette sur $S$ selon une direction non perpendiculaire (oblique), la formule générale :

$$ \hat b = U (V^\top U)^{-1} V^\top b $$

avec $U$ base de $S$ (target) et $V$ base d'un autre sous-espace définissant la direction. Apparait en :
- **PLS** (Partial Least Squares)
- **Decoupling** signal-bruit non-orthogonal
- **Économétrie** : variables instrumentales

### Gram-Schmidt — construire une base orthonormée

Pour orthogonaliser une base $v_1, \dots, v_k$ :

$$ u_k = v_k - \sum_{j=1}^{k-1} \langle v_k, u_j \rangle u_j, \quad \text{puis normaliser} $$

Numériquement instable en pratique → préférer Modified Gram-Schmidt ou Householder ([[Matrix decompositions|QR decomposition]]).

### Projection sur l'espace nul / complément orthogonal

$$ \text{proj}_{S^\perp} = I - P_S $$

Utile pour :
- Détourer un signal (retirer une composante)
- Calculer le résidu

## Quand c'est utile

- **Régression linéaire** : la solution est une projection orthogonale (cf. ci-dessus)
- **PCA** : projeter les données sur les $k$ premières composantes principales
- **Whitening** : transformer les données pour qu'elles aient covariance identité = projection + scaling
- **Algorithmes itératifs contraints** : projected gradient descent (gradient + projection sur la contrainte à chaque step)
- **Kalman filter** : updates qui sont des projections
- **Conjugate gradient** : minimise sur des sous-espaces de Krylov successifs
- **Stiefel/Grassmann manifolds** : optimisation sur l'espace des sous-espaces orthogonaux

## Quand ça ne marche pas / pièges

- **Base non-orthogonale supposée orthogonale** : formule simplifiée $U U^\top$ ne marche pas → bugs silencieux
- **Matrice $A^\top A$ singulière** (multicolinéarité) : $(A^\top A)^{-1}$ inexistante → utiliser pseudo-inverse via [[SVD]]
- **Numérique** : pour $A$ mal conditionnée, calcul direct via $(A^\top A)^{-1}$ explose la précision. Préférer [[Matrix decompositions|QR]] : $P = QQ^\top$.
- **Confusion projection vs reconstruction** : si tu projettes $b$ en dim $k$ via PCA, tu obtiens des coordonnées $k$-dim ; la reconstruction est $U \cdot $ coords en dim $n$. Les deux sont des projections (sur sous-espace en dim $n$).
- **Projection oblique sans raison** : presque toujours, projection orthogonale est ce qu'on veut. Oblique = cas spécifique justifié par contraintes domain-specific.
- **Idempotence vérifiée** : pour debug, vérifier $P \approx P^2$ et trace = rang attendu.

## Code minimal

```python
import numpy as np

# Projeter b sur l'espace engendré par les colonnes de A
A = np.random.randn(10, 3)  # 3D subspace in 10D
b = np.random.randn(10)

# Méthode 1 : projection matrix
P = A @ np.linalg.inv(A.T @ A) @ A.T
b_proj = P @ b
residual = b - b_proj
assert np.allclose(A.T @ residual, 0)  # résidu perpendiculaire à A

# Méthode 2 : via lstsq (numériquement stable)
x_hat, *_ = np.linalg.lstsq(A, b, rcond=None)
b_proj_v2 = A @ x_hat

# Méthode 3 : via QR (encore plus stable)
Q, R = np.linalg.qr(A)
b_proj_v3 = Q @ Q.T @ b  # Q a colonnes orthonormées

# Vérification : les 3 résultats sont identiques
assert np.allclose(b_proj, b_proj_v2)
assert np.allclose(b_proj, b_proj_v3)

# Lien avec régression linéaire
from sklearn.linear_model import LinearRegression
model = LinearRegression(fit_intercept=False).fit(A, b)
b_pred = model.predict(A)
assert np.allclose(b_pred, b_proj)  # même chose !

# Projection sur composantes principales (PCA)
from sklearn.decomposition import PCA
X = np.random.randn(100, 50)
pca = PCA(n_components=10).fit(X)
X_proj_pca = pca.transform(X) @ pca.components_  # reconstruction en dim 50
# C'est une projection orthogonale sur les 10 composantes
```

## Pour aller plus loin

- Strang, *Linear Algebra and Its Applications* — chap. sur orthogonalité
- Trefethen & Bau, *Numerical Linear Algebra* — lecture 6 sur projecteurs
- **Liens internes** : [[SVD]], [[PCA]], [[Eigendecomposition]], [[Matrix decompositions]], [[Vector norms]], [[Regularization]] (Ridge = projection régularisée)
