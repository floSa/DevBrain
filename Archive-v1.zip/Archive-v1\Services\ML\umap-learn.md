---
galaxie: dev
nom: umap-learn
alias: [UMAP-python, umap]
categorie: ml/framework
sous_categories: [dimensionality-reduction, visualization, non-linear, manifold]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: [scikit-learn TSNE, openTSNE, cuml UMAP]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, ml, dimensionality-reduction, visualization, umap]
url_officiel: https://umap-learn.readthedocs.io/
url_docs: https://umap-learn.readthedocs.io/en/latest/
url_repo: https://github.com/lmcinnes/umap
---

# umap-learn

## Pourquoi

Implémentation Python de référence d'**UMAP** (Uniform Manifold Approximation and Projection), méthode de **réduction de dimension non-linéaire** souvent supérieure à t-SNE en 2025-2026 : plus rapide, plus stable, préserve mieux la structure globale, et **fit/transform** réutilisable sur de nouvelles données.

Devenu standard pour visualiser des **embeddings** (texte, single-cell RNA, images) en 2D/3D.

## Quand l'utiliser

- Visualiser des **embeddings** ([[Embeddings]]) en 2D pour explorer
- Exploration de dataset inconnu : voir si des clusters naturels émergent
- Préliminaire à un clustering ([[DBSCAN]] / [[HDBSCAN]] / [[GMM]] sur l'output UMAP)
- Single-cell genomics, NLP, computer vision feature space exploration
- Tout cas où [[t-SNE and UMAP|t-SNE]] est trop lent (> 10k points)

## Quand NE PAS l'utiliser

- Tu veux préserver la **variance globale** linéaire → [[PCA]]
- Tu veux des **features stables** pour ML supervisé downstream → préfère PCA ou autoencoder
- < 1000 points → UMAP fonctionne mais ses hyperparams sont moins stables sur très petit dataset
- Tu as besoin d'**interprétabilité** des dimensions de sortie → UMAP est opaque, PCA mieux

## Pièges connus

- **`n_neighbors`** trop bas (< 5) → fragmentation excessive
- **`min_dist`** trop bas → tous les clusters s'écrasent
- **`metric`** par défaut = `euclidean`. Pour données catégorielles ou texte : utiliser `cosine` ou `hamming`
- **Reproductibilité** : `random_state=0` ne fixe pas tout (numba JIT) — pour reproductibilité stricte, configurer aussi `transform_seed`
- **Supervised UMAP** : `fit(X, y)` peut créer des séparations artificielles si y est très différent du voisinage naturel — utiliser avec prudence
- **Densité** sur la viz : la taille des clusters ne reflète **pas** leur densité réelle, comme t-SNE
- **Coût mémoire** sur très grand dataset : ~ 6 GB pour 1M points en 768-dim. Utiliser cuml UMAP (GPU) si dispo.

## Liens

- Doc officielle : https://umap-learn.readthedocs.io/
- Repo : https://github.com/lmcinnes/umap
- Paper : McInnes et al., *UMAP: Uniform Manifold Approximation and Projection* (2018)
- Concepts liés : [[t-SNE and UMAP]] (concept), [[Embeddings]], [[PCA]] (linéaire), [[K-means]] / [[DBSCAN]] / [[GMM]] (clustering sur output)
- Alternatives : `cuml.UMAP` (GPU, RAPIDS), `openTSNE` (t-SNE optimisé)
