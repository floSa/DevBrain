---
galaxie: dev
type: rule
domaine: cli
applicable: type-cli
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, cli]
---

# Règles — Type de projet : CLI

## Principe
Une CLI doit être **prévisible**, **scriptable**, **documentée**. Suivre les conventions Unix.

## MUST

- **`--help` complet** sur la commande root et chaque sous-commande.
- **Exit codes documentés** : `0` = success, `≠0` = erreur. Conventions usuelles : `1` erreur générique, `2` mauvais usage, codes spécifiques pour erreurs métier.
- **stderr pour les erreurs/logs**, **stdout pour la donnée pipeable**. Ne pas mélanger.
- **Support `--version`**.
- **Pas d'écriture interactive sans terminal** (TTY check) : si stdin/stdout est pipé, mode non-interactif.

## SHOULD

- **Configurabilité hiérarchique** : flags > variables d'env > config file > defaults.
- **Output formats** : par défaut humain, `--json` ou `--format` pour scripting.
- **Verbosity** : `-v`, `-vv`, `-vvv` ou `--quiet`.
- **Couleurs** : auto-désactivées si pas TTY ou si `NO_COLOR` env var positionnée.
- **Distribution** : `pipx` (Python), `npm install -g` (Node), binaire (Rust/Go avec PyInstaller, pkg, bun build).

## NICE-TO-HAVE

- Auto-complétion shell générée (bash, zsh, fish).
- Mode interactif rich (TUI avec textual, ratatui).
- Man page générée.

## Outils

### Python
- `typer` (basé sur Click) ou `click` directement
- `rich` pour output coloré
- Distribution : `pipx`, ou bundling avec `pyinstaller` / `nuitka`

### TypeScript / Node
- `commander` ou `yargs`
- `chalk` ou `picocolors` pour couleurs
- Distribution : `bun build --compile`, `pkg` (déprécié), Node SEA

### Rust
- `clap` (le standard de fait)

## Voir aussi

- [[Rules/Global/README]] — section Usage avec exemples CLI
- [[Pattern - CLI Python distribuable]] (à créer le moment venu)
