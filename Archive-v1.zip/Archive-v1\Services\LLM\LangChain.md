---
galaxie: dev
nom: LangChain
alias: [langchain]
categorie: llm/framework
sous_categories: [orchestration, agents, chains, rag]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python (TypeScript port disponible)
clients_officiels: [python, ts]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[LlamaIndex]]", "[[LangGraph]]", "[[Haystack]]", "[[Semantic Kernel]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, framework, rag, agents]
url_officiel: https://www.langchain.com/
url_docs: https://python.langchain.com/docs/
url_repo: https://github.com/langchain-ai/langchain
---

# LangChain

## Pourquoi
Framework historique pour orchestrer LLMs : chains, prompts, retrievers, memory, agents. L'écosystème le plus large (~700 intégrations). Standard de fait pour démarrer un projet LLM, même si controversé.

## Quand l'utiliser
- POC rapide qui combine plusieurs sources (LLM + DB + tools)
- Besoin d'intégrations rares (vendor obscur, vector store de niche)
- RAG simple à moyen
- Quand l'écosystème compte plus que la propreté du code

## Quand NE PAS l'utiliser
- Production critique → considérer [[LangGraph]] (plus contrôlable) ou code custom
- RAG pur structuré → [[LlamaIndex]] est plus focalisé
- App vraiment simple → appel direct au SDK Anthropic/OpenAI suffit
- Si on est freiné par les abstractions trop nombreuses

## Pièges connus
- **API instable historiquement** : breaking changes fréquents avant v0.3 (stable depuis ~2024)
- **Abstractions parfois opaques** : difficile de débugger un chain qui rate
- **Versioning des sub-packages** : `langchain-core`, `langchain-community`, `langchain-openai`, etc. — à pinner ensemble
- **Performance** : couches d'abstraction = overhead, à benchmarker en prod
- **Documentation** : bonne mais éparpillée entre python.langchain.com, smith.langchain.com, blog

## Liens
- [[LangGraph]] — extension pour graphes d'agents stateful
- [[LlamaIndex]] — alternative orientée RAG/data
- LangSmith (observability) : https://smith.langchain.com/
- Doc Python : https://python.langchain.com/docs/
- Doc JS : https://js.langchain.com/docs/
