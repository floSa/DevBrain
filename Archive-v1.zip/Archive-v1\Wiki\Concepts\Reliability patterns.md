---
galaxie: wiki
nom: Reliability patterns (LLM)
alias: [retries, circuit breaker, fallback, rate limit, idempotency]
type: concept
categorie: concept/llm-production
sous_categories: [reliability, production, fault-tolerance, llm-ops]
domaines: [ai-eng]
maturite: established
auteurs_cles: []
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, reliability, production]
---

# Reliability patterns (LLM)

## TL;DR

Patterns standards pour faire des apps LLM **robustes** face aux pannes : **retries** avec exponential backoff + jitter, **timeouts** per-call et total, **circuit breakers** pour éviter cascade failure, **rate limiting** (token bucket vs provider quotas), **graceful degradation** (fallback to smaller / cached / static), **idempotency** pour safety, **dead letter queues**, **multi-region failover**. Sans ces patterns, un downtime provider = downtime de ton app. Apps LLM = **stateful**, **expensive**, **flaky** → reliability extra important.

## Le problème

LLM providers ont des incidents :
- API down (Anthropic, OpenAI)
- Rate limits hit (429 errors)
- Timeouts (gros prompt = slow)
- Cost spikes (loops infinis)
- Non-deterministic outputs

→ Ton app crash si pas robuste.

## L'idée

### Retries avec exponential backoff + jitter

```python
import time, random

def retry_with_backoff(fn, max_retries=5, base_delay=1):
    for attempt in range(max_retries):
        try:
            return fn()
        except (RateLimitError, TimeoutError) as e:
            if attempt == max_retries - 1:
                raise
            delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
            time.sleep(delay)
```

- **Exponential** : 1s, 2s, 4s, 8s...
- **Jitter** : random uniform → évite herding (tous retry en même temps)
- Retry seulement sur erreurs **transient** : 429, 500, timeout
- Pas retry sur 400 (bad request) ou 401 (auth)

### Timeouts

#### Per-call timeout

Ne pas attendre infiniment. Configure timeout (e.g. 30s).

```python
import httpx
client = openai.OpenAI(http_client=httpx.Client(timeout=30.0))
```

#### Total task timeout

Pour agents multi-step : limit absolu (5 min ?).

### Circuit breakers

Si **trop d'erreurs récentes**, **stop appeler** ce provider temporarily.

```
Closed (normal) → 5 failures → Open (block all calls for X min) → Half-open (test) → Closed
```

Bibliothèque : `pybreaker`, `tenacity` patterns.

Évite cascade failure (provider down → ton app crash → tes users crash).

### Rate limiting

#### Provider rate limits

Chaque provider a des limites (RPM, TPM) :
- OpenAI : variable selon tier
- Anthropic : per minute / per day

Si dépassé → 429 error.

#### Token bucket

Pré-track usage côté client → throttle avant 429.

```python
from ratelimit import limits, sleep_and_retry

@sleep_and_retry
@limits(calls=60, period=60)  # 60 calls per minute
def call_openai(...):
    ...
```

#### Quota par user / tenant

Multi-tenant : limit per user, prevent abuse. Standard.

#### Cost budget

Limit $ per task / user / day. Kill switch.

### Graceful degradation

If primary fails :

#### Fallback to smaller model

```python
try:
    response = call_opus(query)
except RateLimitError:
    response = call_sonnet(query)
```

#### Fallback to cache

```python
try:
    response = llm_call(query)
except:
    response = cache.get(query)
```

#### Static fallback

```python
try:
    response = llm_call(query)
except:
    response = "Sorry, our service is temporarily unavailable. Please try again."
```

### Idempotency

Critical pour **side effects** :
- Same `request_id` → don't re-process
- Tools : delete, send email, transfer money

Standard pour avoid double-trigger sur retry.

```python
def safe_send_email(email, content, idempotency_key):
    if cache.exists(idempotency_key):
        return cache.get(idempotency_key)
    result = send_email(email, content)
    cache.set(idempotency_key, result, ttl=86400)
    return result
```

### Dead letter queues

Failed tasks après max retries → DLQ pour debug ultérieur. Don't lose.

### Provider failover

Multi-provider :
- Anthropic native → AWS Bedrock Anthropic → GCP Vertex Anthropic

Same model, different providers. Failover automatique.

```python
PROVIDERS = ["anthropic-native", "bedrock", "vertex"]
for provider in PROVIDERS:
    try:
        return call_provider(provider, query)
    except (HTTPError, TimeoutError):
        continue
raise RuntimeError("All providers down")
```

### Multi-region

Sensible to outages géographiques :
- Provider A US-East down → use US-West or EU

### Streaming reliability

Streaming responses peuvent break mid-stream :
- Detect via timeout sur tokens
- Resume avec context jusque là (challenging)
- Or fallback to non-streaming retry

### Tooling

#### tenacity

```python
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=10),
    retry=retry_if_exception_type((RateLimitError, TimeoutError))
)
def call_with_retry():
    ...
```

#### LiteLLM Router

Built-in fallback / retry / timeout. Standard 2026.

```python
router = Router(
    model_list=[...],
    fallbacks=[{"gpt-4o": ["claude-3-7-sonnet"]}],
    timeout=30,
    num_retries=3,
    retry_after=2,
)
```

#### Portkey

Production gateway : retries, fallbacks, load balancing, caching.

### Best practices

1. **Always timeout** : per-call + total
2. **Exponential backoff + jitter** sur retries
3. **Circuit breaker** par provider
4. **Rate limit per user** : prevent abuse
5. **Cost budget** : kill switch
6. **Fallback chain** : cheap model → cached → static
7. **Idempotency** sur side effects
8. **Audit log** : tracker fails pour learn
9. **Multi-provider** : pas single point of failure
10. **Streaming resilience** : detect breaks, fallback

## Quand c'est utile

- **Toute app LLM en prod** : downtime garanti sans
- **High availability** required (SaaS, b2b)
- **High traffic** : rate limit needed
- **Multi-tenant** : isolate failures
- **Cost-sensitive** : budgets, alerts
- **Compliance** : audit, retry policies
- **Agents** : long-running, more failure surface
- **Streaming UX** : detect / recover

## Quand ça ne marche pas / pièges

- **Retry sur 4xx** : pointless (bad request stays bad), waste of resources
- **Timeout too short** : large prompts genuinely slow → false fails
- **Retry storm** : tous les users retry simultanément → herding
- **Circuit too aggressive** : flap open/closed every minute
- **Fallback degrades quality** : user noticing
- **Idempotency miss** : double-email sent on retry
- **Multi-provider drift** : Anthropic vs Bedrock subtle differences
- **Cost runaway despite limits** : agent re-call infinitely
- **Streaming hardly resumable** : context lost mid-stream
- **Dead letter neglected** : DLQ accumulates, no one looks
- **Region failover slow** : DNS / config takes minutes

## Code minimal

```python
import time
import random
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from openai import OpenAI, RateLimitError, APIError, APITimeoutError

client = OpenAI(timeout=30.0, max_retries=0)  # disable lib retries, we do our own

# 1. Retry with exponential backoff + jitter
@retry(
    stop=stop_after_attempt(5),
    wait=wait_exponential(multiplier=1, min=2, max=60),
    retry=retry_if_exception_type((RateLimitError, APITimeoutError, APIError))
)
def llm_call(prompt):
    return client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )

# 2. Circuit breaker
class CircuitBreaker:
    def __init__(self, max_failures=5, reset_timeout=60):
        self.failures = 0
        self.last_failure = 0
        self.max = max_failures
        self.reset = reset_timeout
    
    def call(self, fn, *args, **kwargs):
        if self.failures >= self.max:
            if time.time() - self.last_failure < self.reset:
                raise RuntimeError("Circuit OPEN")
            else:
                self.failures = 0  # half-open
        try:
            result = fn(*args, **kwargs)
            self.failures = 0
            return result
        except Exception as e:
            self.failures += 1
            self.last_failure = time.time()
            raise

breaker = CircuitBreaker()
# breaker.call(llm_call, "Hello")

# 3. Rate limiting
from ratelimit import limits, sleep_and_retry

@sleep_and_retry
@limits(calls=60, period=60)  # 60 calls per minute
def rate_limited_call(...):
    return llm_call(...)

# 4. Fallback chain
def llm_with_fallback(query):
    providers = [
        ("anthropic", "claude-3-7-sonnet-latest"),
        ("bedrock", "anthropic.claude-3-7-sonnet"),
        ("openai", "gpt-4o"),
    ]
    
    for provider, model in providers:
        try:
            return call_provider(provider, model, query)
        except (RateLimitError, APITimeoutError) as e:
            print(f"Failed {provider}: {e}, trying next...")
            continue
    
    # Last resort : cached or static
    cached = cache.get(query)
    if cached:
        return cached
    return "Service temporarily unavailable."

# 5. Idempotency
def safe_action(action_name, params, idempotency_key, executor):
    if cache.exists(f"idempotency:{idempotency_key}"):
        return cache.get(f"idempotency:{idempotency_key}")
    
    result = executor(action_name, params)
    cache.set(f"idempotency:{idempotency_key}", result, ttl=86400)
    return result

# 6. LiteLLM Router avec fallback
from litellm import Router

router = Router(
    model_list=[
        {"model_name": "gpt-4o", "litellm_params": {"model": "openai/gpt-4o"}},
        {"model_name": "claude-sonnet", "litellm_params": {"model": "anthropic/claude-3-7-sonnet"}},
    ],
    fallbacks=[{"gpt-4o": ["claude-sonnet"]}],
    timeout=30,
    num_retries=3,
    retry_after=2,
    cooldown_time=30,  # circuit breaker
)

response = router.completion(
    model="gpt-4o",
    messages=[{"role": "user", "content": "..."}]
)

# 7. Streaming with timeout per token
import asyncio

async def stream_with_token_timeout(client, prompt, token_timeout=5.0):
    stream = await client.chat.completions.create(model="gpt-4o", messages=[...], stream=True)
    chunks = []
    last_token_time = time.time()
    
    async for chunk in stream:
        if time.time() - last_token_time > token_timeout:
            raise TimeoutError("Streaming stalled")
        chunks.append(chunk)
        last_token_time = time.time()
    
    return chunks

# 8. Cost budget kill switch
class CostBudget:
    def __init__(self, max_usd):
        self.spent = 0
        self.max = max_usd
    
    def check(self, estimated_cost):
        if self.spent + estimated_cost > self.max:
            raise BudgetExceeded(f"Would exceed ${self.max}")
    
    def charge(self, cost):
        self.spent += cost

# 9. Dead letter queue (simplified)
def call_with_dlq(query, dlq_queue):
    try:
        return llm_call(query)
    except Exception as e:
        dlq_queue.put({"query": query, "error": str(e), "timestamp": time.time()})
        return "Task queued for retry."
```

## Pour aller plus loin

- *AWS Builder's Library* — Circuit breakers, retries, backoff
- *LiteLLM* documentation on routing/retries/fallbacks
- *tenacity* Python library
- *Resilience4j* patterns (Java but transferable)
- Hamel Husain blogs on production LLM reliability
- *Portkey*, *Helicone* gateway features
- **Liens internes** : [[Routing and cascading]], [[Inference optimization]], [[LLM observability]], [[LLM caching]]
