---
galaxie: dev
nom: Pydantic Settings
alias: [pydantic-settings, BaseSettings]
categorie: tooling/build
sous_categories: [config, env, validation, pydantic]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[python-dotenv]]", "[[dynaconf]]", "[[hydra]]", "os.getenv()"]
remplace: ["os.getenv()", "[[python-dotenv]] (en consommation directe)"]
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, tooling, config, pydantic, env]
url_officiel: https://docs.pydantic.dev/latest/concepts/pydantic_settings/
url_docs: https://docs.pydantic.dev/latest/concepts/pydantic_settings/
url_repo: https://github.com/pydantic/pydantic-settings
---

# Pydantic Settings

## Pourquoi
Lib Pydantic dédiée à la **config typée et validée** depuis variables d'env / fichiers `.env` / secret manager. `BaseSettings` charge, parse, valide au démarrage. Le défaut moderne pour la config Python — remplace `os.getenv()` éparpillé.

## Quand l'utiliser
- **Tout projet Python sérieux** (FastAPI, scripts, libs avec config)
- Equipe qui veut un fail-fast au démarrage si var manquante
- Multi-environnements (`.env`, `.env.dev`, `.env.prod`)
- Stack qui utilise déjà Pydantic (FastAPI, SQLModel, etc.)

## Quand NE PAS l'utiliser
- Script throw-away 10 lignes → `os.getenv()` direct OK
- Workflow type Hydra (config hiérarchique YAML complexe pour ML) → [[hydra]]
- Pas de Pydantic dans le projet → ajouter Pydantic juste pour la config est valable, mais [[dynaconf]] est sans dépendance

## Pièges connus
- **Booléens depuis env** : `bool("false")` = `True` en Python pur ! Pydantic Settings gère correctement (`"false"` → `False`)
- **`SettingsConfigDict(extra="forbid")`** : à activer pour catch les typos dans `.env`
- **Secrets en clair dans `repr()`** : marquer avec `Field(repr=False)`
- **`env_file`** : chargé une seule fois à l'instanciation, pas hot-reloadé
- **Cascade de fichiers** : `env_file=(".env", ".env.local")` mais l'ordre compte
- **Validators** : `@field_validator` exécuté à l'instanciation, pas à chaque accès
- **Settings en singleton** : crée `settings = Settings()` au niveau module, pas dans une fonction (sinon réinstanciation à chaque appel)

## Pattern minimal

```python
from pydantic import Field, PostgresDsn, HttpUrl
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    # DB
    database_url: PostgresDsn
    database_pool_size: int = Field(default=10, ge=1, le=100)
    
    # APIs externes
    anthropic_api_key: str = Field(min_length=10, repr=False)
    openai_api_key: str | None = Field(default=None, repr=False)
    
    # App
    debug: bool = False
    log_level: str = Field(default="INFO", pattern="^(DEBUG|INFO|WARNING|ERROR)$")
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="forbid",
        case_sensitive=False,
    )

# Singleton — instancié au démarrage du process
settings = Settings()
```

## Pattern multi-env

```python
import os
env = os.getenv("APP_ENV", "dev")

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(".env", f".env.{env}"),  # cascade
        env_file_encoding="utf-8",
        extra="forbid",
    )
```

## Pattern secret manager (prod)

```python
class Settings(BaseSettings):
    database_url: PostgresDsn
    anthropic_api_key: str
    
    @classmethod
    def settings_customise_sources(cls, *args, **kwargs):
        # injecter une source AWS Secrets Manager / HashiCorp Vault
        return (env_settings, vault_secrets, file_secret_settings)
```

## Liens
- [[FastAPI]] — intégration native (`Depends(get_settings)`)
- [[Config-Env]] — règle doc qui impose Pydantic Settings
- [[Postgres]] — typage `PostgresDsn`
- Doc complète : https://docs.pydantic.dev/latest/concepts/pydantic_settings/
- Type adapters utiles : `PostgresDsn`, `HttpUrl`, `EmailStr`, `SecretStr`
