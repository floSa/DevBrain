---
galaxie: dev
nom: TruLens
alias: [trulens, trulens-eval]
categorie: llm/eval
sous_categories: [llm-eval, feedback-functions, observability, rag]
licence: MIT
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Ragas]]", "[[DeepEval]]", "[[Phoenix Arize]]", "[[LangSmith]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, eval, observability, rag]
url_officiel: https://www.trulens.org/
url_docs: https://www.trulens.org/docs/
url_repo: https://github.com/truera/trulens
---

# TruLens

## Pourquoi
Framework d'**eval LLM** par TruEra. Approche **feedback functions** : tu wrap ta chaîne avec `TruChain` / `TruLlama` / `TruCustom`, et TruLens enregistre chaque call et applique des évaluateurs (LLM-as-judge ou heuristiques). UI Streamlit intégrée pour comparer les versions, datasets de tests. Mix d'**eval ET observability** dans le même outil.

## Quand l'utiliser
- Pipeline RAG ou agent avec besoin de **comparer plusieurs versions** (prompt, modèle, retriever, chunking)
- Approche "feedback functions" : tu définis tes critères en code Python
- Combo eval offline + observability online dans le même outil
- Intégration native [[LangChain]], [[LlamaIndex]], NeMo Guardrails, OpenAI

## Quand NE PAS l'utiliser
- Eval RAG simple → [[Ragas]] est plus direct
- Test suite pytest-style → [[DeepEval]] est mieux ergonomé
- Tracing OTEL standard pur → [[Phoenix Arize]]
- Tu veux observability cloud managed plug-and-play → [[LangSmith]] ou [[Langfuse]]

## Pièges connus
- **UI Streamlit** : dashboard local par défaut, à exposer via reverse proxy si équipe distribuée
- **Storage** : SQLite par défaut (`default.sqlite`), [[Postgres]] pour scale
- **Coût LLM-as-judge** : feedbacks LLM = appels API, comme Ragas/DeepEval
- **Versions** : passage de `trulens-eval` → `trulens` (rebrand 2024+), import paths à mettre à jour
- **Wrapping** : `TruChain` impose un cadre, parfois friction avec code custom

## Patterns essentiels

### Feedback function basique

```python
from trulens.core import TruSession, Feedback
from trulens.providers.openai import OpenAI as fOpenAI

session = TruSession()
provider = fOpenAI()

# Définir une feedback function
f_relevance = Feedback(provider.relevance, name="Answer Relevance")
f_groundedness = Feedback(provider.groundedness_measure_with_cot_reasons,
                          name="Groundedness").on(text=...).on(...)
```

### Wrap d'une chaîne LangChain

```python
from trulens.apps.langchain import TruChain

tru_chain = TruChain(
    chain,
    app_name="rag-v1",
    app_version="1.0.0",
    feedbacks=[f_relevance, f_groundedness, f_context_relevance],
)

# Run avec recording auto
with tru_chain as recording:
    response = chain.invoke({"question": "..."})

# Voir les résultats
session.get_leaderboard()
```

### Dashboard

```python
from trulens.dashboard import run_dashboard
run_dashboard(session, port=8501)
```

## Métriques principales (RAG Triad)

| Métrique | Mesure |
|----------|--------|
| **Context Relevance** | Le contexte récupéré est-il pertinent vs question |
| **Groundedness** | La réponse s'appuie-t-elle bien sur le contexte |
| **Answer Relevance** | La réponse répond-elle à la question |

Plus :
- Toxicity, Bias, Stereotypes
- Custom feedbacks (tu écris la fonction d'éval)
- Honesty, Coherence, Sentiment

## Liens
- [[Ragas]], [[DeepEval]] — alternatives
- [[Phoenix Arize]], [[LangSmith]] — observability complémentaire
- [[LangChain]], [[LlamaIndex]] — bien intégrés
- [[Anthropic Claude API]] / [[OpenAI API]] — pour les feedback functions LLM
- Quickstart : https://www.trulens.org/getting_started/quickstarts/
- Comparatif : [[Comparatif - LLM eval et observability]]
