---
galaxie: wiki
nom: MAP estimation
alias: [MAP, maximum a posteriori, regularized MLE]
type: concept
categorie: concept/statistics
sous_categories: [map, bayesian, regularization, prior]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: []
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, statistics, map, bayesian]
---

# MAP estimation — Maximum A Posteriori

## TL;DR

Pont entre [[Maximum likelihood estimation|MLE]] et [[Bayesian inference|bayésien]] : on choisit $\hat\theta$ qui **maximise le posterior** $p(\theta | D)$ au lieu de la vraisemblance. Équivaut à MLE + un **prior** $p(\theta)$ qui régularise. **Ridge = MAP avec prior gaussien**, **Lasso = MAP avec prior Laplace**. C'est la **régularisation vue comme inférence bayésienne ponctuelle**.

## Le problème

MLE peut overfit, surtout en petite data. On veut **injecter de la connaissance préalable** (e.g. "les coefficients ne sont pas trop grands") sans passer à l'inférence bayésienne complète (coûteuse, MCMC).

## L'idée

### Définition

Par Bayes :

$$ p(\theta | D) = \frac{p(D | \theta) p(\theta)}{p(D)} \propto p(D | \theta) p(\theta) $$

L'estimateur MAP :

$$ \hat\theta_{MAP} = \arg\max_\theta p(D | \theta) p(\theta) = \arg\max_\theta [\log p(D | \theta) + \log p(\theta)] $$

= MLE + un terme de **log-prior**.

### Liens fondamentaux régularisation ↔ prior

| Prior | Régularisation équivalente | Formule |
|---|---|---|
| **Gaussien** $\mathcal{N}(0, \sigma_\theta^2 I)$ | Ridge / L2 | $\lambda \|\theta\|_2^2$ |
| **Laplace** $\text{Lap}(0, b)$ | Lasso / L1 | $\lambda \|\theta\|_1$ |
| **Elastic net** mixé | Mix L1 + L2 | $\lambda_1 \|\theta\|_1 + \lambda_2 \|\theta\|_2^2$ |
| **Plat (uniforme)** | Pas de régularisation = MLE pur | — |
| **Spike-and-slab** | Sparsité forte / sélection bayésienne | — |

Force du prior $\leftrightarrow$ force de régularisation : un prior gaussien étroit = forte régularisation.

### Exemple : régression linéaire

$y_i \sim \mathcal{N}(\beta^\top x_i, \sigma^2)$, prior $\beta \sim \mathcal{N}(0, \tau^2 I)$.

$$ -\log p(\beta | D) = \underbrace{\frac{1}{2 \sigma^2} \sum (y_i - \beta^\top x_i)^2}_{\text{MSE}} + \underbrace{\frac{1}{2 \tau^2} \|\beta\|^2}_{\text{ridge}} $$

→ minimisation = Ridge regression avec $\lambda = \sigma^2 / \tau^2$.

### MAP vs MLE vs Bayes

| | MLE | MAP | Bayes complet |
|---|---|---|---|
| Quoi | $\arg\max p(D \mid \theta)$ | $\arg\max p(\theta \mid D)$ | distribution $p(\theta \mid D)$ |
| Sortie | point | point | distribution |
| Prior | non | oui | oui |
| Quantif incertitude | via Fisher (asympt) | non native | native (posterior) |
| Coût | faible | faible | élevé (MCMC, VI) |

MAP = MLE régularisé = approximation **ponctuelle** du Bayes complet.

### Pièges philosophiques

- MAP **n'est pas invariant par reparamétrisation** : changer $\theta \to \phi = g(\theta)$ change l'estimateur MAP (à cause du Jacobian). MLE et Bayes complet le sont (sur la moyenne posterior).
- Pour des distributions multimodales, MAP donne le **mode**, qui peut être trompeur (le mode peut être loin de la masse de probabilité).

### MAP en deep learning

- **Weight decay** dans SGD = MAP gaussien
- **Dropout** = approximation bayésienne (Gal & Ghahramani 2016)
- **Early stopping** = approximation MAP empirique

### MAP itératif / EM

Pour modèles latents, MAP via EM remplace E-step par max sur posterior conditionnel + prior. Convergence vers max local du posterior.

## Quand c'est utile

- **Régularisation principielle** : choisir prior plutôt que tuner $\lambda$ par CV (justifiable théoriquement)
- **Petits échantillons** : MLE pas robuste, MAP avec prior informatif aide
- **Sparsité** : Lasso comme MAP Laplace
- **Sélection de variables** : spike-and-slab = MAP discret + continu
- **Compromis Bayes/freq** : quand MCMC trop coûteux, MAP donne un point estimate raisonnable
- **Régularisation hiérarchique** : multilevel models, partial pooling (MAP empirique)

## Quand ça ne marche pas / pièges

- **MAP n'est pas le posterior** : pour vraie quantif d'incertitude, faire Bayes complet (PyMC, Stan)
- **Non-invariance par reparamétrisation** : choisir la paramétrisation soigneusement
- **Prior mal choisi** : prior trop fort écrase les données ; trop plat = MLE
- **Modes trompeurs** : posterior multimodal → MAP unique inutile, faire MCMC
- **Empirical Bayes** : utiliser les données pour fitter le prior, puis MAP — double-comptage, attention overconfidence
- **Confusion avec Bayes** : MAP ne donne pas de barres d'erreur natives. Pour des IC, utiliser la matrice hessienne (Laplace approx).
- **Spike-and-slab discret** : optimisation NP-hard. Relaxations continues (horseshoe).

## Code minimal

```python
import numpy as np
from scipy import optimize

# MAP pour régression linéaire avec prior gaussien (Ridge)
def neg_log_posterior_ridge(beta, X, y, lambda_):
    n = len(y)
    log_lik = -0.5 * np.sum((y - X @ beta)**2)  # gaussian likelihood (σ=1)
    log_prior = -0.5 * lambda_ * np.sum(beta**2)  # gaussian prior
    return -(log_lik + log_prior)

np.random.seed(0)
X = np.random.randn(50, 10)
beta_true = np.array([1, -1, 0.5, 0, 0, 0, 0, 0, 0, 0])
y = X @ beta_true + 0.5 * np.random.randn(50)

result = optimize.minimize(neg_log_posterior_ridge, np.zeros(10), args=(X, y, 1.0))
print(f"MAP ridge: {result.x.round(2)}")

# Comparer à sklearn Ridge
from sklearn.linear_model import Ridge
print(f"sklearn  : {Ridge(alpha=1.0).fit(X, y).coef_.round(2)}")

# MAP avec prior Laplace (Lasso) — pas différentiable, sous-gradient
def neg_log_posterior_lasso(beta, X, y, lambda_):
    log_lik = -0.5 * np.sum((y - X @ beta)**2)
    log_prior = -lambda_ * np.sum(np.abs(beta))
    return -(log_lik + log_prior)

# Optimisation (L-BFGS-B marche grâce à la sous-différentiabilité)
result = optimize.minimize(neg_log_posterior_lasso, np.zeros(10),
                            args=(X, y, 1.0), method='L-BFGS-B')
print(f"MAP lasso (approx): {result.x.round(2)}")

from sklearn.linear_model import Lasso
print(f"sklearn          : {Lasso(alpha=1.0/50).fit(X, y).coef_.round(2)}")

# Approximation de Laplace : posterior gaussien autour du MAP
# Variance ≈ inverse de la hessienne au MAP
# Pour Ridge: H = X^T X + λ I
H = X.T @ X + 1.0 * np.eye(10)
cov_approx = np.linalg.inv(H)
SE = np.sqrt(np.diag(cov_approx))
print(f"SE approximée    : {SE.round(3)}")
```

## Pour aller plus loin

- Bishop, *Pattern Recognition and Machine Learning* (2006) — chap. 3 (régression bayésienne)
- Murphy, *Probabilistic ML: An Introduction* (2022) — chap. 11
- Gal & Ghahramani, *Dropout as Bayesian Approximation* (ICML 2016)
- **Liens internes** : [[Maximum likelihood estimation]], [[Bayesian inference]], [[Regularization]], [[PyMC]]
