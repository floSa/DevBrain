---
galaxie: dev
nom: Comparatif - LLM eval et observability
type: comparatif
created: 2026-05-20
modified: 2026-05-20
tags: [comparatif, llm, observability, eval]
---

# Comparatif — LLM eval & observability

> Quel outil pour quel besoin entre tracing, evals, prompt management, et leurs combos.

## Synthèse rapide

| Outil | Type | Standout | Cons |
|---|---|---|---|
| **[[Langfuse]]** | open + cloud | open MIT, self-host facile, complet | UX un peu moins polish que LangSmith |
| **[[LangSmith]]** | cloud only | UX premium, intégration LangChain native | propriétaire, cloud only, $ |
| **[[Helicone]]** | open + cloud | proxy zero-config, cache + routing | proxy = layer en plus |
| **[[Phoenix Arize]]** | open + cloud | OpenInference standard, RAG eval fort | UI moins riche |
| **[[Ragas]]** | lib eval | RAG metrics spécialisées (faithfulness, etc.) | eval lib only, pas observability |
| **[[TruLens]]** | open lib | "triad" RAG (context/groundedness/answer) | UI legacy |
| **[[DeepEval]]** | open lib | pytest-style, CI-friendly | UI moins riche |
| **Braintrust** | cloud | dataset / eval premium, expérimentation | cloud only, $ |
| **Weave (W&B)** | cloud | combo W&B classique ML + LLM | écosystème W&B nécessaire |
| **Lunary** | open + cloud | léger, prompt mgmt | moins de features |
| **Portkey** | cloud | gateway + observability + cache | proprio |
| **Galileo / Patronus / Confident** | cloud commercial | enterprise focus | $ |

## Décision par cas

### Open-source self-host
- **[[Langfuse]]** = default 2026
- **[[Phoenix Arize]]** si tu veux OpenInference / OTel

### Stack LangChain
- **[[LangSmith]]** = intégration native, UX premium
- **[[Langfuse]]** marche aussi (decorators)

### Tracing zero-config
- **[[Helicone]]** : change ton `base_url` → tout tracé
- **OpenAI Auto-cache** : juste prompt caching natif

### Eval RAG dédié
- **[[Ragas]]** : faithfulness, context precision/recall, answer relevance — le standard
- **[[TruLens]]** : framework triad
- **[[DeepEval]]** : pytest-style CI

### Pipeline complet (trace + eval + datasets)
- **[[Langfuse]]** ou **[[LangSmith]]** ou Braintrust selon budget / open / lock-in

### Routing + observability combo
- **[[Helicone]]** (proxy + obs)
- **[[LiteLLM]]** (lib router) + observability séparée

## Coûts typiques (2026)

| Tier | Langfuse | LangSmith | Helicone |
|---|---|---|---|
| Free | 50k events/mois | 5k traces/mois | 100k req/mois |
| Pro | ~$50/mois | ~$39/mois | ~$25/mois |
| Enterprise | sur devis | sur devis | sur devis |
| Self-host | gratuit (Docker) | impossible | gratuit (Docker) |

## Voir aussi

- [[LLM observability]] (concept détaillé)
- [[LLM eval metrics]] (concepts métriques)
- [[RAG eval]] (concept eval RAG)
- [[LLM-as-judge]] (concept)
