---
galaxie: wiki
nom: Model-based RL
alias: [model-based RL, MBRL, world models, Dreamer, MuZero, PlaNet, MPC, MCTS]
type: concept
categorie: concept/ml
sous_categories: [rl, model-based, world-models, planning, mcts, dreamer, muzero]
domaines: [ml-eng, ai-eng]
maturite: emerging
auteurs_cles: [Sutton 1990 (Dyna), Silver 2016 (AlphaGo), Schrittwieser 2020 (MuZero), Hafner 2019-2024 (Dreamer)]
lecture_min: 9
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, rl, model-based, world-models]
---

# Model-based RL — MBRL

## TL;DR

Au lieu d'apprendre directement la politique / valeur depuis l'expérience (model-free), **apprendre un modèle de l'environnement** $\hat{p}(s' | s, a)$ et $\hat{r}(s, a)$, puis **planifier ou rêver** dans ce modèle. Avantage majeur : **sample efficiency** — un modèle peut générer des trajectoires synthétiques infinies sans interaction réelle. Deux grandes lignées : **planning** (MCTS, MPC sur le modèle, AlphaGo / MuZero) et **world models** (réseau apprend une simulation latente, agent entraîné dedans, Dreamer / PlaNet). Considéré comme un des chemins prometteurs vers des agents généralistes.

## Le problème

Model-free RL (DQN, PPO, SAC) est notoirement **sample-inefficient** :
- Atari : 50M+ frames pour atteindre niveau humain
- MuJoCo : 1M+ steps
- Robotique réelle : impraticable, on doit passer par la simulation

L'humain n'a pas besoin de tomber 1000 fois pour apprendre à éviter un précipice — on a un **modèle mental** du monde, on l'imagine.

**Idée MBRL** : apprendre un modèle de l'environnement, l'utiliser pour planifier / s'entraîner sans interactions réelles.

## L'idée

### Structure générale

```
                  ┌────────────────────┐
                  │   ENVIRONNEMENT     │
                  │   réel (cher)       │
                  └──────────▲──────────┘
                             │
                  expérience │ politique
                  réelle     │ (peu)
                             ▼
   ┌────────────┐    apprend  ┌──────────────┐
   │  AGENT     │◄────────────│  MODÈLE      │ p̂(s'|s,a)
   │  π_θ       │             │  appris      │ r̂(s,a)
   └──────────┬─┘             └──────┬───────┘
              │                      │
              │   plan/rêve dans     │
              └──────────────────────┘
              expérience SYNTHÉTIQUE (gratuite)
```

L'agent interagit (peu) avec l'env réel, met à jour le modèle, **rêve / plan** dans le modèle pour s'entraîner massivement.

### Familles d'approches

#### 1. Dyna-style (Sutton 1990)

Le grand-père. Alterne :
- Update Q sur transitions réelles
- Update Q sur transitions imaginées par le modèle

Marche en tabular. Échec en haute dim car modèle imprécis.

#### 2. MPC / planning local (Model Predictive Control)

Pas d'apprentissage de politique. À chaque pas :
1. Avec le modèle $\hat{p}$, simuler N futures séquences d'actions sur H steps
2. Choisir l'action initiale de la meilleure séquence
3. Exécuter l'action, observer le résultat, retry

Marche bien en robotique avec modèles physiques. CEM (Cross-Entropy Method) pour optimiser sur les actions. PETS (Chua 2018), PlaNet (Hafner 2019).

#### 3. MCTS + apprentissage (AlphaGo / AlphaZero family)

**Monte Carlo Tree Search** guidé par un réseau (policy + value). À chaque move :
- Étendre l'arbre de jeu via simulation (selection UCT, expansion, evaluation, backup)
- Récupérer la meilleure action à la racine
- Le réseau (policy + value) est entraîné sur les simulations

Marche quand on a **un simulateur parfait** (échecs, Go, jeux) ou un modèle appris (MuZero).

#### 4. World Models / Dreamer (Hafner 2019-2024)

Apprendre une **simulation latente** :
- **Encoder** $\phi : o_t \to z_t$ : observations vers état latent
- **Dynamics** $z_{t+1} = f(z_t, a_t)$ : transition dans le latent
- **Decoder** $\hat{o} = g(z)$, **reward** $\hat{r} = h(z)$ : prédictions

Une fois ce monde appris, l'agent s'entraîne **entièrement dans la simulation latente** (rêve), zéro coût d'interaction réelle.

**DreamerV3 (2024)** : SOTA model-free pour beaucoup de tâches, marche sur Atari, Crafter, MuJoCo, Minecraft avec un seul set d'hyperparams.

#### 5. MuZero (Schrittwieser 2020)

**Sans modèle de transitions explicite des observations** : on apprend juste un modèle abstrait $\hat{s}_{t+1} = m(\hat{s}_t, a_t)$ dans un espace latent qui prédit la valeur et la policy. MCTS dessus.

Différence vs AlphaZero : pas besoin de connaître les règles du jeu. MuZero a battu AlphaZero sur Atari **et** maintient AlphaZero-level sur Go/Chess/Shogi.

### Avantages MBRL

- **Sample efficiency** : 10-100x moins d'interactions réelles requises (Dreamer sur Atari < 1M frames)
- **Transfer** : un modèle peut servir à plusieurs tâches
- **Planning** : raisonnement explicite sur futures, interprétable
- **Safety** : on peut tester une politique en simulation avant déploiement
- **Multi-task / curriculum** : exploration plus dirigée
- **Lifelong learning** : modèle accumule du savoir au fur et à mesure

### Limites MBRL

- **Erreur de modèle** : un modèle imparfait propage les erreurs, surtout sur long horizon. **Hallucinations** dans le rêve.
- **Compute** : entraîner le modèle + planner = plus de compute par step (mais moins de steps)
- **Hyperparam complexity** : MBRL a plus de pièces mobiles (encoder, dynamics, reward predictor, policy, critic)
- **Distribution shift** : modèle entraîné sur policy actuelle, mais on l'utilise pour entraîner une policy meilleure → décalage
- **Quand le modèle est facile à apprendre, MBRL gagne ; sinon, model-free reste compétitif**

### Choix pratique

- **Simulateur connu et bon marché** : pas besoin de MBRL, RL direct dans le simu (Isaac Gym, MuJoCo)
- **Robotique réelle, peu d'interactions** : Dreamer / DayDreamer en pratique
- **Jeu avec règles connues** : AlphaZero (MCTS + RL)
- **Jeu sans règles connues** : MuZero
- **LLMs / agents** : MBRL appliqué aux LLMs émerge (tree search guidé pour reasoning, e.g. Tree-of-Thought, MCTS-augmented agents)

### Lien avec les agents LLM

Des travaux récents appliquent du **search / planning model-based** aux LLMs :
- **Tree-of-Thought** (Yao 2023) : LLM génère plusieurs continuations, évalue, sélectionne, recurse
- **Search-augmented reasoning** : MCTS où chaque "move" est une étape de raisonnement, guidé par un value model
- **Process reward models** (PRM, voir [[Reward modeling]]) : value model qui guide la recherche

Frontière active 2024-2026, motivation derrière les "reasoning models" type o1, R1.

### Erreur de modèle et horizon

Théoriquement, l'erreur de planification grandit en $O(H^2 \epsilon)$ avec $H$ l'horizon et $\epsilon$ l'erreur du modèle. → **planifier court** (H petit), re-planifier souvent (MPC).

Astuces pratiques :
- **Ensemble de modèles** : prend la médiane / minimum pour être conservatif
- **Latent imagination** : Dreamer impose une bottleneck d'information → moins de moyens de halluciner détails irrelevants
- **Pessimism** : pénaliser les états où le modèle est incertain (overlap avec offline RL)

## Quand c'est utile

- **Sample inefficiency limitante** : robotique réelle, médical, finance
- **Tu as accès à un simulateur** mais c'est lent → apprendre un proxy plus rapide
- **Multi-task / transfer** : un modèle réutilisable
- **Safety-critical** : valider en simu avant déploiement
- **Recherche fondamentale** : MBRL est un domaine de recherche actif et stimulant
- **Reasoning LLMs** : tree search avec value model = MBRL appliqué aux agents

## Quand ça ne marche pas / pièges

- **Environnement très stochastique / complexe** : modèle dur à apprendre, MBRL n'aide pas
- **Modèle qui hallucine sur long horizon** : plan dans le rêve → politique catastrophique en vrai
- **Compute par step massif** : Dreamer/MuZero coûtent plus par step que SAC, à amortir sur sample efficiency
- **Hyperparams nombreux** : 3-4 réseaux à régler en plus de la policy
- **Distribution shift** : si on entraîne la policy à exploiter les erreurs du modèle, "model exploitation"
- **Deadlock** : le modèle a besoin d'une policy diverse pour bien apprendre, la policy a besoin d'un bon modèle → chicken-and-egg
- **Implementation complexity** : 5-10x plus de code que PPO/SAC
- **Pas de standard "qui marche partout"** : DreamerV3 s'en approche, mais reste fragile
- **Comparaisons douteuses** : papers MBRL souvent sur tâches simples ; généralisation pas claire
- **Imitation learning > MBRL si démos disponibles** : pourquoi apprendre un modèle si l'expert nous dit quoi faire ?

## Code minimal

```python
# Dyna : Q-learning + planification synthétique
import numpy as np
from collections import defaultdict

class DynaQ:
    def __init__(self, n_states, n_actions, alpha=0.1, gamma=0.99, n_planning=5):
        self.Q = np.zeros((n_states, n_actions))
        self.model = {}    # (s, a) -> (r, s')
        self.alpha, self.gamma, self.n_planning = alpha, gamma, n_planning

    def update(self, s, a, r, s2):
        # 1. Update direct (Q-learning)
        self.Q[s, a] += self.alpha * (r + self.gamma * self.Q[s2].max() - self.Q[s, a])
        # 2. Mémorise dans le modèle (déterministe : remplace)
        self.model[(s, a)] = (r, s2)
        # 3. Planification : N updates synthétiques
        for _ in range(self.n_planning):
            (s_, a_), (r_, s2_) = list(self.model.items())[np.random.randint(len(self.model))]
            self.Q[s_, a_] += self.alpha * (r_ + self.gamma * self.Q[s2_].max() - self.Q[s_, a_])
```

```python
# Cross-Entropy Method (CEM) pour planning sur un modèle continu
import numpy as np

def cem_action(model, current_obs, horizon=20, n_samples=500, top_k=50, n_iter=5):
    """
    model : f(obs, action) -> (next_obs, reward) (appris)
    Optimise une séquence d'actions sur horizon=H par CEM.
    """
    act_dim = 4
    mu = np.zeros((horizon, act_dim))
    std = np.ones((horizon, act_dim)) * 1.0

    for it in range(n_iter):
        # Sample actions séquences
        seqs = mu[None] + std[None] * np.random.randn(n_samples, horizon, act_dim)
        seqs = np.clip(seqs, -1.0, 1.0)

        # Score : simuler dans le modèle
        scores = np.zeros(n_samples)
        for i in range(n_samples):
            obs = current_obs.copy()
            total = 0.0
            for t in range(horizon):
                obs, r = model.predict(obs, seqs[i, t])
                total += (0.99 ** t) * r
            scores[i] = total

        # Top-k → ré-estimer mu, std
        elite = seqs[scores.argsort()[-top_k:]]
        mu = elite.mean(axis=0)
        std = elite.std(axis=0) + 1e-3

    return mu[0]   # première action de la séquence optimale
```

```python
# Dreamer-like : world model latent (squelette pseudo-code)
import torch
import torch.nn as nn

class WorldModel(nn.Module):
    def __init__(self, obs_dim, act_dim, z_dim=64):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(obs_dim, 256), nn.ReLU(),
                                     nn.Linear(256, z_dim))
        self.dynamics = nn.GRUCell(z_dim + act_dim, z_dim)
        self.reward_head = nn.Linear(z_dim, 1)
        self.decoder = nn.Linear(z_dim, obs_dim)

    def imagine(self, z0, policy, horizon=15):
        """Rêve : produit une trajectoire latente depuis z0 avec la policy."""
        zs, actions, rewards = [z0], [], []
        z = z0
        for _ in range(horizon):
            a = policy(z)
            z = self.dynamics(torch.cat([z, a], dim=-1), z)
            r = self.reward_head(z).squeeze(-1)
            zs.append(z); actions.append(a); rewards.append(r)
        return torch.stack(zs), torch.stack(actions), torch.stack(rewards)

# Policy / value entraînés ENTIÈREMENT dans imagine() — pas de step env réel.
```

```python
# MCTS simplifié pour un jeu connu (AlphaZero-style)
import math
import numpy as np

class Node:
    def __init__(self, prior=0.0):
        self.N = 0       # visit count
        self.W = 0.0     # total value
        self.P = prior   # prior probability
        self.children = {}

    def Q(self): return self.W / self.N if self.N else 0.0
    def U(self, parent_N, c_puct=1.5):
        return c_puct * self.P * math.sqrt(parent_N) / (1 + self.N)

def select(node, action_space):
    return max(action_space, key=lambda a: node.children[a].Q() + node.children[a].U(node.N))

# Boucle complète : selection -> expansion (via le réseau policy/value) -> backup
# Voir AlphaZero / MuZero pour les détails complets.
```

## Pour aller plus loin

- Sutton & Barto, ch. 8 *Planning and Learning with Tabular Methods* (Dyna)
- Silver et al., *Mastering the game of Go with deep neural networks and tree search* (AlphaGo, Nature 2016)
- Silver et al., *Mastering Chess and Shogi by Self-Play with a General RL Algorithm* (AlphaZero, 2017)
- Schrittwieser et al., *Mastering Atari, Go, Chess and Shogi by Planning with a Learned Model* (MuZero, Nature 2020)
- Hafner et al., *Dream to Control: Learning Behaviors by Latent Imagination* (PlaNet, 2019)
- Hafner et al., *Mastering Diverse Domains through World Models* (DreamerV3, 2024) — https://arxiv.org/abs/2301.04104
- Chua et al., *Deep Reinforcement Learning in a Handful of Trials using Probabilistic Dynamics Models* (PETS, 2018)
- Wu et al., *DayDreamer* (2022) — Dreamer sur robots réels
- Yao et al., *Tree of Thoughts* (2023) — search-based reasoning pour LLMs
- **Liens internes** : [[Reinforcement learning]], [[Markov Decision Process]], [[Value functions]], [[Policy gradient]], [[Reasoning models]], [[Multi-armed bandits]]
