---
galaxie: dev
nom: Instructor
alias: [instructor-ai]
categorie: llm/framework
sous_categories: [structured-output, pydantic, validation]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python, ts, js]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Anthropic Claude API]] (tool use natif)", outlines, marvin]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, llm, structured-output, pydantic]
url_officiel: https://python.useinstructor.com/
url_docs: https://python.useinstructor.com/
url_repo: https://github.com/instructor-ai/instructor
---

# Instructor

## Pourquoi

Wrapper léger qui force un LLM à retourner du **JSON conforme à un schéma Pydantic**. Tu définis ta classe Pydantic, tu passes le LLM (Claude, OpenAI, Ollama…), Instructor garantit que la réponse parse — avec retries si le LLM échoue.

C'est la lib **structured output** la plus populaire en 2026 quand tu veux de la sortie typée fiable sans monter une infra complexe.

## Quand l'utiliser

- Extraction de données structurées depuis du texte non structuré (CV, contrats, emails)
- API LLM qui doit retourner un schéma précis (entities, classification, function call)
- Tu veux du Pydantic + LLM sans réinventer la roue
- Prototypes : passer d'un POC text-to-JSON en 10 lignes

## Quand NE PAS l'utiliser

- Tu utilises déjà le **tool use natif** d'Anthropic ou OpenAI — c'est souvent suffisant et un layer en moins
- Sortie textuelle libre / streaming — Instructor est pour le structuré
- Très haute fréquence → la couche de validation Pydantic + retry ajoute de la latence

## Pièges connus

- Sur des schémas Pydantic très imbriqués, le LLM galère — simplifie ou découpe en étapes
- Les `Field(description="...")` sont cruciaux : c'est ce que Instructor injecte dans le prompt
- Compte les tokens : Instructor ajoute des instructions au prompt, mesure l'impact sur les coûts

## Liens

- Doc : https://python.useinstructor.com/
- Repo : https://github.com/instructor-ai/instructor
- [[Anthropic Claude API]] (tool use natif est souvent une alternative simple)
- [[PydanticAI]] (équivalent + agents)
