---
galaxie: dev
nom: Dagster
alias: [dagster]
categorie: data/orchestration
sous_categories: [assets, software-defined-assets, lineage]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Airflow]]", "[[Prefect]]", "[[Mage]]", "[[Kestra]]"]
remplace: ["[[Airflow]]"]
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, data, orchestration, etl, assets]
url_officiel: https://dagster.io/
url_docs: https://docs.dagster.io/
url_repo: https://github.com/dagster-io/dagster
---

# Dagster

## Pourquoi
Orchestrateur de pipelines data orienté **software-defined assets** : tu déclares les assets (tables, modèles, fichiers) et leurs dépendances, Dagster gère l'ordre. Lineage natif, types Python sérieux, dev experience moderne. Le concurrent ascendant d'[[Airflow]].

## Quand l'utiliser
- Nouveaux projets data engineering / ML
- Quand tu veux un modèle "asset-first" plutôt que "task-first" (lineage, freshness)
- Intégration native avec [[dbt]], [[Pandas]], [[Polars]], [[MLflow]], [[Postgres]], etc.
- Local dev expérience importante (Dagit UI)
- Type checking strict des inputs/outputs entre étapes

## Quand NE PAS l'utiliser
- Stack Airflow déjà mature → migration coûteuse, peu de gain
- Workflows non-data (CI/CD, jobs génériques) → [[Prefect]] ou outils dédiés
- Très petite scale → un cron suffit
- Équipe sans Python avancé → courbe d'apprentissage

## Pièges connus
- **Modèle assets ≠ tasks** : shift mental requis depuis Airflow
- **Resources** : abstraction puissante mais conceptuelle (DB connections, etc.)
- **Partitions** : modèle excellent mais à comprendre tôt (TimeWindow, Static, Dynamic)
- **Versions** : releases fréquentes, breaking changes possibles avant 1.x
- **Dagster Cloud (managed)** : pricing à vérifier
- **UI Dagit** : utile mais à exposer prudemment (auth)

## Liens
- [[Airflow]] — alternative historique
- [[MLflow]] — souvent combiné pour ML pipelines
- [[Postgres]] — backend metadata typique
- Dagster University (formations gratuites) : https://courses.dagster.io/
- Comparaison Airflow/Dagster : https://dagster.io/blog/airflow-vs-dagster
