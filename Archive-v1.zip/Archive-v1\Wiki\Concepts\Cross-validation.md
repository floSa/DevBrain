---
galaxie: wiki
nom: Cross-validation
alias: [validation croisée, CV, k-fold]
type: concept
categorie: concept/ml
sous_categories: [validation, k-fold, stratified, leave-one-out, model-selection]
domaines: [data-science, ml-eng, mlops]
maturite: established
auteurs_cles: [Stone 1974, Hastie-Tibshirani-Friedman]
lecture_min: 8
created: 2026-05-19
modified: 2026-05-19
tags: [concept, ml, cross-validation, validation]
---

# Cross-validation

## TL;DR

Évaluer un modèle sur un **seul split train/test** est bruité (chance du tirage). La **validation croisée** divise les données en $k$ folds, entraîne sur $k-1$ et teste sur 1, **k fois en rotation**, puis moyenne. Donne une estimation plus stable de la performance de généralisation. Plusieurs variantes selon le type de données : stratified, group, leave-one-out, time series ([[Walk-forward CV]]).

## Le problème

Avec un simple holdout (80% train / 20% test) :
- **Bruit** : un tirage chanceux peut donner un score trompeusement bon ou mauvais
- **Gâchis** : on n'utilise que 80% des données pour entraîner
- **Pas de mesure d'incertitude** : tu obtiens un seul nombre, pas une distribution

La CV résout ces 3 problèmes en moyennant sur plusieurs splits.

## L'idée

### K-Fold classique

Diviser le dataset en $k$ parts égales (folds). Pour chaque fold $i \in \{1, \dots, k\}$ :
- Train sur les $k-1$ autres folds
- Test sur le fold $i$
- Mesurer la performance

Score final : moyenne des $k$ scores. Écart-type : mesure de stabilité.

```
fold 1 : [ TEST ][ train ][ train ][ train ][ train ]
fold 2 : [ train ][ TEST ][ train ][ train ][ train ]
fold 3 : [ train ][ train ][ TEST ][ train ][ train ]
fold 4 : [ train ][ train ][ train ][ TEST ][ train ]
fold 5 : [ train ][ train ][ train ][ train ][ TEST ]
```

Choix de $k$ :
- $k=5$ ou $k=10$ : conventions standard
- $k=n$ (Leave-One-Out) : utilise chaque point comme test, coûteux mais minimal en biais
- $k=2$ : insuffisant, trop bruité

### Variantes

#### Stratified K-Fold

Pour la **classification**, on veut que chaque fold ait la **même proportion de classes** que le dataset global. Sinon, sur classes déséquilibrées, certains folds n'ont aucune instance de la classe minoritaire → score artificiellement bon ou nul.

```python
from sklearn.model_selection import StratifiedKFold
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
```

**Toujours stratified pour classification**. Par défaut dans scikit-learn pour les classifieurs.

#### Group K-Fold

Quand les données ont des **groupes** (ex. plusieurs mesures par patient, plusieurs photos du même utilisateur), un même groupe ne doit jamais être à cheval train/test → leakage. Utiliser `GroupKFold`.

#### Repeated K-Fold

Refaire le K-Fold $r$ fois avec différentes randomisations. Réduit encore le bruit. Coût × $r$.

#### Time series CV — [[Walk-forward CV]]

Pour séries temporelles, le KFold standard fuite le futur. Cf. fiche dédiée.

#### Nested CV (deux niveaux)

Pour **sélectionner les hyperparams** ET **estimer la perf** sans biais :
- Boucle externe : split train/test ($k_1$ folds)
- Boucle interne (sur le train de l'externe) : split train/val ($k_2$ folds), recherche d'hyperparams
- Évaluer sur le test de l'externe (jamais vu)

Coût : × $k_1 \cdot k_2$. Utile en publi / haut-stakes ; en pratique on simplifie souvent.

### Métriques agrégées

- **Moyenne** : performance attendue
- **Écart-type** : stabilité (un modèle avec acc 0.85 ± 0.10 est plus risqué qu'un autre à 0.83 ± 0.02)
- **Distribution complète** : utile pour test statistique de différence entre modèles

## Quand c'est utile

- **Modèles classiques** (linear, trees, gradient boosting, kernel) : KFold ou Stratified KFold
- **Sélection d'hyperparams** : `GridSearchCV`, `RandomizedSearchCV`, Optuna
- **Comparaison de modèles** : tester la significativité de la différence
- **Dataset moyen** (< 100k) : la CV est calculable. Au-delà, holdout simple suffit souvent.

## Quand ça ne marche pas / pièges

- **Données temporelles** : KFold fuite le futur → utiliser [[Walk-forward CV]]
- **Données avec groupes** (sujets, sessions) : KFold sans GroupKFold fait du leakage
- **Préprocessing fitted sur tout le dataset** : si tu standardises AVANT de splitter, le scaler "voit" le test → leakage subtil. Toujours mettre le preprocessing dans un Pipeline et le CV split englobe le tout.
- **Très petit dataset** : LOO peut être très bruité (chaque test = 1 point). KFold à 5 ou 10 préférable.
- **CV pour le pricing / haute volatilité** : variance entre folds très élevée, attention à l'interprétation.
- **Deep learning** : CV souvent **non faisable** (coût). Préfère holdout + validation set + test set, avec early stopping sur validation.

## Code minimal

```python
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

# Pipeline : preprocessing dans le pipeline pour éviter leakage
pipe = Pipeline([
    ('scaler', StandardScaler()),
    ('clf', GradientBoostingClassifier()),
])

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)
scores = cross_val_score(pipe, X, y, cv=cv, scoring='roc_auc')

print(f"AUC: {scores.mean():.3f} ± {scores.std():.3f}")
```

Avec sélection d'hyperparams :

```python
from sklearn.model_selection import GridSearchCV

grid = {
    'clf__n_estimators': [100, 200],
    'clf__max_depth': [3, 5, 7],
}
gs = GridSearchCV(pipe, grid, cv=cv, scoring='roc_auc', n_jobs=-1)
gs.fit(X, y)
print(gs.best_params_, gs.best_score_)
```

## Implémentations concrètes

- `sklearn.model_selection` : `KFold`, `StratifiedKFold`, `GroupKFold`, `LeaveOneOut`, `RepeatedKFold`, `TimeSeriesSplit`, `cross_val_score`, `cross_validate`, `GridSearchCV`, `RandomizedSearchCV`
- [[statsforecast]] / [[neuralforecast]] : `cross_validation()` natif pour time series
- [[darts]] : `backtest()`, `historical_forecasts()`
- Optuna : optimization avec CV intégrée

## Pour aller plus loin

- Hastie, Tibshirani, Friedman, *ESL* — chap. 7
- Stone, *Cross-validatory choice and assessment of statistical predictions* (1974)
- **Liens internes** : [[Bias-variance tradeoff]], [[Walk-forward CV]] (CV pour TS), [[ROC AUC]] (métrique souvent utilisée avec CV)
