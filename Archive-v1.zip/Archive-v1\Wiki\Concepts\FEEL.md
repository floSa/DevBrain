---
galaxie: wiki
nom: FEEL
alias: [feel, friendly enough expression language, s-feel, dmn-feel]
type: concept
categorie: concept/business-rules
sous_categories: [dmn, feel, expression-language, syntax]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [OMG, James Taylor, Bruce Silver]
lecture_min: 10
created: 2026-05-21
modified: 2026-05-21
tags: [concept, dmn, feel, expression-language]
---

# FEEL — Friendly Enough Expression Language

## TL;DR

**Langage d'expression standard de DMN** : c'est ce qu'on écrit dans les cellules d'une decision table, dans une literal expression, dans une fonction BKM. Conçu pour être **lisible par les business analysts** mais quand même **précis et exécutable**. Pas Turing-complet (par design) : pas de side effects, pas de mutation, pas de boucles `while`. Types primitifs (number, string, boolean, date, time, duration), types structurés (context, list, range), opérations sur listes (filter, map, sum, count...). Deux saveurs : **S-FEEL** (Simple FEEL, ranges + comparateurs basiques) pour les decision tables L2, **FEEL** complet pour L3.

## Le problème

Comment exprimer une condition métier dans une cellule de decision table ?

- Trop simple ("Java/Python embarqué") → expressif mais incompréhensible pour le métier, dangereux (side effects)
- Trop limité ("just enum + numbers") → ne permet pas d'exprimer des cas réels (intervalles, dates, listes, conditions composées)

FEEL est le **compromis OMG** : juste assez de pouvoir d'expression pour 95% des cas métier, juste assez de simplicité pour qu'un analyste l'apprenne en 1h.

## L'idée

### Types primitifs

| Type | Exemple FEEL | Notes |
|---|---|---|
| `number` | `42`, `-3.14`, `1.2e3` | décimal arbitraire (pas IEEE 754) |
| `string` | `"hello"`, `"ligne1\nligne2"` | UTF-8, échappements standard |
| `boolean` | `true`, `false` | minuscule strict |
| `date` | `date("2024-12-25")` | ISO 8601 |
| `time` | `time("14:30:00")` | HH:MM:SS |
| `date and time` | `date and time("2024-12-25T14:30:00")` | |
| `years and months duration` | `duration("P1Y6M")` | ISO 8601 duration |
| `days and time duration` | `duration("P5DT3H")` | |

### Types composites

#### Context — comme un objet

```feel
{
  name: "Alice",
  age: 35,
  address: { city: "Paris", zip: "75001" }
}
```

Accès : `customer.address.city`.

#### List

```feel
[1, 2, 3, 5, 8]
["red", "green", "blue"]
[customer1, customer2, customer3]
```

Indexation : `list[1]` (base 1, pas 0 !), `list[-1]` = dernier.

#### Range

```feel
[1..10]      // intervalle fermé [1, 10]
(0..100)     // intervalle ouvert (0, 100)
[0..100)     // semi-ouvert
```

Test d'appartenance : `5 in [1..10]` → true.

### Opérateurs

#### Logiques
```feel
true and false              // false
true or false               // true
not(x > 0)                  // négation
```

#### Comparaison
```feel
a = b           // égalité (un seul =, pas ==)
a != b
a < b, a > b, a <= b, a >= b
```

#### Arithmétique
```feel
a + b - c * d / e
a ** b          // puissance
modulo(10, 3)   // 1
```

#### Strings
```feel
"hello" + " " + "world"
string length("abc")          // 3
substring("abcdef", 2, 3)     // "bcd"
upper case("hello")
contains("foobar", "oba")     // true
matches(s, "regex", "i")      // booleen
```

#### Listes / collections
```feel
sum([1, 2, 3, 4])             // 10
count(list)
min(list), max(list)
mean(list), median(list)
distinct values(list)
sort(list)
append(list, item)
concatenate(list1, list2)
```

#### Dates
```feel
date("2024-12-25") + duration("P7D")     // 2025-01-01
date and time("2024-12-25T10:00:00") - date and time("2024-12-25T08:00:00")
                                          // duration("PT2H")
day of week(date("2024-12-25"))          // "Wednesday"
year(my_date), month(my_date)
```

### Filtrage et list comprehension

C'est la partie la plus puissante de FEEL pour les list operations.

#### Filter
```feel
[item in commandes : item.amount > 100]      // syntax avec ":"
```

#### Map (avec `for ... in ... return`)
```feel
for c in customers return c.email
```

#### Aggregations
```feel
sum([c.amount | c in commandes, c.status = "validated"])
count([u | u in users, u.subscribed = true])
```

#### `every` et `some` (quantificateurs)
```feel
every order in customer.orders satisfies order.paid = true   // tous payés
some order in customer.orders satisfies order.amount > 1000  // au moins un > 1000
```

### `if then else`

```feel
if age >= 18 then "adult" else "minor"

// Nested
if score > 0.9 then "A"
else if score > 0.7 then "B"
else if score > 0.5 then "C"
else "fail"
```

### Functions et invocation

#### Définir une fonction (en BKM)

```feel
function(amount, rate, duration)
  amount * (1 + rate) ** duration
```

#### Invoquer
```feel
calculer_taux(100000, 0.03, 20)              // positional
calculer_taux(amount: 100000, rate: 0.03, duration: 20)   // named
```

### Built-in functions essentielles

DMN définit ~75 fonctions built-in. Les plus utilisées :

| Catégorie | Functions |
|---|---|
| **Conversion** | `number(s)`, `string(n)`, `date(s)`, `boolean(s)` |
| **Strings** | `length`, `substring`, `upper case`, `lower case`, `contains`, `starts with`, `ends with`, `matches`, `replace`, `split`, `trim` |
| **Math** | `abs`, `floor`, `ceiling`, `round`, `sqrt`, `log`, `exp`, `min`, `max`, `sum`, `mean`, `median`, `stddev` |
| **Lists** | `count`, `distinct values`, `sort`, `append`, `concatenate`, `flatten`, `union`, `intersect`, `index of`, `sublist` |
| **Dates** | `day of week`, `day of year`, `month of year`, `week of year`, `year`, `month`, `day`, `now()`, `today()` |
| **Misc** | `not`, `string length`, `is defined`, `get value`, `get entries` |

### S-FEEL (Simple FEEL)

Sous-ensemble réduit pour les cellules de decision tables au niveau **L2**. Couvre :
- Comparateurs : `< > <= >= = !=`
- Ranges : `[a..b]`, `(a..b]`
- Listes simples : `"red", "green", "blue"`
- Constantes : nombres, strings, dates, durations
- `-` (tiret) = "any"
- `not(...)` négation

Pas de filter, pas de comprehension, pas d'invocation de fonction. Le 80/20 des decision tables tient en S-FEEL.

### Différences avec un langage de programmation

| FEEL | Python / Java |
|---|---|
| **Pas de mutation** : `x = ...` est une comparaison, pas une assignation | `x = ...` est assignation |
| **Pas de side effects** | Beaucoup |
| **Pas Turing-complet** : pas de while, pas de récursion arbitraire | Oui |
| **Indexation base 1** : `list[1]` est le premier | base 0 dans la plupart |
| **Décimaux exacts** : pas IEEE 754, pas de surprise float | float = IEEE 754 |
| **Espaces autorisés dans les noms** : `string length`, `day of week` | snake_case ou camelCase |
| **Date/time first-class** : opérations natives | besoin de bibliothèques |

### Saveurs et compatibilité

Implementations FEEL en 2026 :
- **Camunda DMN engine** (Java) — référence
- **Drools / kie-dmn** (Java) — référence
- **Trisotech** — moteur commercial
- **OpenL Tablets** — partiel
- **dmn-eval-js** (JavaScript) — léger
- **pyDMNrules** (Python) — couverture FEEL partielle

Le **DMN TCK** (Technology Compatibility Kit) valide l'interopérabilité. Camunda et Drools couvrent quasi 100% du TCK.

## Quand c'est utile

- **Cellules de decision tables** : 99% du FEEL utilisé en pratique
- **Literal expressions** dans le DRD : décision sans table, juste une expression
- **BKM** (functions réutilisables) : encapsuler une formule de calcul
- **Contexts** : décomposer un calcul en étapes nommées
- **List operations métier** : "tous les contrats actifs", "somme des charges > 100 €"
- **Calculs de dates** : maturité, anniversaires, périodes de validité
- **Plus expressif que SQL CASE** dans les decision tables
- **Plus sûr qu'embarquer du Python** : pas de side effects, pas de injection

## Quand ça ne marche pas / pièges

- **Logique récursive complexe** : FEEL n'est pas Turing-complet. Si ton problème exige de la vraie récursion, c'est probablement pas une décision DMN
- **Side effects requis** (loguer, appeler API) : FEEL est pur — déléguer à BPMN tasks autour
- **Mauvaise compréhension du `=`** : `x = 5` en FEEL est une **comparaison**, pas une assignation
- **Indexation base 1** : piège classique pour devs habitués au 0-indexed
- **`"a", "b"` dans une cellule** signifie "a OU b" (union), pas une liste
- **Espaces dans les noms** : `day of week` est un seul identifiant, pas 3 — ne pas le mettre dans `customer name` (qui devient un identifiant)
- **Date sans timezone** : `date and time("2024-12-25T10:00:00")` est ambigu, préfixer avec timezone : `"...+02:00"`
- **Performance sur grosses listes** : `sum([... | x in list, complex_condition(x)])` sur 1M items = lent, déléguer à SQL/Spark
- **FEEL ≠ implémentation** : un moteur peut couvrir 70% du standard → vérifier ce qui est supporté avant d'utiliser une feature
- **Pas d'IDE puissant pour FEEL** : autocomplétion souvent basique vs Java/Python IDE
- **Verbosité parfois** : `not(x > 0)` plus verbeux que `!(x > 0)` ; `count([... | ...])` plus verbeux que `len([... for ...])`

## Code minimal

### Cellule de decision table (S-FEEL)

```feel
// Input "Age"
[18..65]               // dans cet intervalle
< 25                   // strictement inférieur
not(18)                // tout sauf 18
"FR", "BE", "CH"       // dans cette liste
-                      // n'importe quelle valeur
```

### Literal expression (FEEL complet)

```feel
// Calcul de mensualité de prêt
amount * rate * (1 + rate) ** duration / ((1 + rate) ** duration - 1)
```

### Context — calcul en étapes nommées

```feel
{
  monthly_rate: annual_rate / 12,
  n_payments: duration_years * 12,
  monthly_payment:
    amount * monthly_rate / (1 - (1 + monthly_rate) ** (-n_payments)),
  total_paid: monthly_payment * n_payments,
  total_interest: total_paid - amount
}
```

### Function (BKM)

```feel
function(amount, annual_rate, duration_years)
  let
    monthly_rate = annual_rate / 12,
    n = duration_years * 12
  in
    amount * monthly_rate / (1 - (1 + monthly_rate) ** -n)
```

### Filter + map + aggregate sur une collection

```feel
// Somme des charges récurrentes > 50 €
sum([c.amount | c in customer.charges,
                c.amount > 50,
                c.frequency = "monthly"])

// Liste des emails des clients VIP non-désabonnés
[c.email | c in customers,
           c.tier = "VIP",
           not(c.unsubscribed)]

// Vérifier que tous les contrats actifs sont signés
every contract in customer.contracts
  satisfies contract.status != "active" or contract.signed = true
```

### Date arithmétique

```feel
let
  age_days = today() - customer.birth_date,
  age_years = years and months duration(customer.birth_date, today()).years
in
  if age_years >= 18 then "adult" else "minor"
```

### Strings et regex

```feel
matches(email, "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$", "i")
```

### En Python via pyDMNrules

```python
from pyDMNrules import DMN

dmn = DMN("rules.xlsx")
status, data = dmn.decide({
    "customer": {"age": 35, "income": 30000, "country": "FR"},
    "request_amount": 100000
})
print(data)
```

## Pour aller plus loin

- OMG DMN spec, section 10 (FEEL) : https://www.omg.org/spec/DMN/
- DMN TCK FEEL test cases : https://github.com/dmn-tck/tck
- Bruce Silver, *DMN Method and Style*, ch. 9-11 (FEEL en détail)
- Camunda FEEL playground : https://feel-playground.camunda.cloud/
- Red Hat KIE / Drools FEEL doc : https://docs.drools.org/
- **Liens internes** : [[Decision Model and Notation]], [[Decision Tables]], [[Boxed Expressions]], [[BKM - Business Knowledge Model]], [[DMN Conformance Levels]]
