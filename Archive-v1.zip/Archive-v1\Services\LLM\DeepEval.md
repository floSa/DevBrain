---
galaxie: dev
nom: DeepEval
alias: [deepeval]
categorie: llm/eval
sous_categories: [llm-eval, pytest, metrics, red-teaming]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Ragas]]", "[[Phoenix Arize]]", "[[TruLens]]", "[[LangSmith]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, eval, pytest]
url_officiel: https://www.confident-ai.com/
url_docs: https://docs.confident-ai.com/
url_repo: https://github.com/confident-ai/deepeval
---

# DeepEval

## Pourquoi
Framework d'éval LLM **généraliste** (pas que RAG comme [[Ragas]]). Approche **"pytest pour LLM"** : `assert_test` + métriques. Inclut RAG metrics, hallucination, bias, toxicity, custom GEval (LLM-as-judge avec critères perso), red teaming, summarization. Bonne intégration CI.

## Quand l'utiliser
- Test suite LLM en CI (style pytest) — c'est son point fort
- Eval multi-aspects (pas que RAG) : hallucination, biais, toxicité, summarization
- GEval custom : tu décris le critère en langage naturel, le LLM juge
- Benchmark sur datasets standards (MMLU, HumanEval…) via `benchmarks`
- Red teaming (jailbreaks, attaques) — module dédié

## Quand NE PAS l'utiliser
- Eval RAG ultra-spécialisée → [[Ragas]] souvent plus mature sur le sujet
- Observability prod (tracing/monitoring) → [[Phoenix Arize]] / [[LangSmith]]
- Tu veux gratuit-only → Confident AI (managed) optionnel mais des features avancées y sont

## Pièges connus
- **Coût judge** : idem [[Ragas]], LLM-as-judge = appels LLM
- **Versions** : breaking changes possibles, pinner
- **Confident AI cloud** : option payante pour tracking + dashboards
- **`@pytest.mark.deepeval`** : intégration pytest, à apprendre
- **Métriques `GEval`** : très flexibles mais à formuler avec soin (le prompt judge fait tout)
- **Async** : possible mais quelques pièges, voir doc

## Métriques notables

| Métrique | Type |
|----------|------|
| `AnswerRelevancyMetric` | Pertinence de la réponse |
| `FaithfulnessMetric` | Pour RAG |
| `HallucinationMetric` | Détecter inventions |
| `BiasMetric` / `ToxicityMetric` | Safety |
| `GEval` | Custom LLM-as-judge |
| `SummarizationMetric` | Quality summarization |

## Liens
- [[Ragas]] — alternative orientée RAG
- [[Phoenix Arize]] — pour observability
- [[OpenAI API]] / [[Anthropic Claude API]] — pour le judge
- Confident AI : https://www.confident-ai.com/
