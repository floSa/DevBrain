---
galaxie: dev
nom: ScaNN
alias: [scann]
categorie: vectordb/ann
sous_categories: [ann, google, approximate, quantization, anisotropic]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: C++ / Python
clients_officiels: [python]
plateforme: [linux]
score: 3
mes_projets: []
alternatives: ["[[Faiss]]", "[[hnswlib]]", "[[Qdrant]]", "GCP Vertex AI Matching Engine"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, vectordb, ann, google, quantization]
url_officiel: https://github.com/google-research/google-research/tree/master/scann
url_docs: https://github.com/google-research/google-research/tree/master/scann
url_repo: https://github.com/google-research/google-research
---

# ScaNN

## Pourquoi

**ANN library Google Research**, basée sur la technique **"anisotropic vector quantization"** (paper ICML 2020) : optimise la quantization en tenant compte du fait que pour le **maximum inner product search (MIPS)**, l'erreur sur la direction parallèle au vecteur compte plus que l'erreur orthogonale. Résultat : **meilleur recall à coût mémoire équivalent** vs PQ classique (Faiss).

Excellent sur les **benchmarks ANN-benchmarks** pour des catalogues très grands (100M+ vecteurs). Sous le capot de **GCP Vertex AI Matching Engine / Vector Search**. En revanche, API plus brute que Faiss/hnswlib, support Linux+x86 quasi-exclusif, et **install parfois douloureuse** (wheel manylinux only).

## Quand l'utiliser

- **Recall critique** sur very large indices (100M-1B vecteurs)
- **GCP Vertex AI Matching Engine / Vector Search** : ScaNN sous le capot, t'es déjà dessus si tu utilises Vertex
- **Research / benchmarks ANN avancé** : SOTA sur certains benchmarks publics
- **Inner product search (MIPS)** : ScaNN est conçu pour ça (vs HNSW généraliste)
- **Linux x86 / GPU** : plateforme cible primaire
- **Embeddings recommandation / ads** : use case historique Google

## Quand NE PAS l'utiliser

- **Setup rapide** → [[Faiss]] / [[hnswlib]] / [[Qdrant]] (install plus simple, doc plus claire)
- **Cross-platform** (Mac, Windows) : ScaNN essentiellement Linux x86
- **Production ops simple** → vector DB managed ([[Qdrant]] Cloud, GCP Vector Search)
- **Catalogues petits** (< 1M vecteurs) : HNSW (hnswlib) plus simple, perf équivalente ou meilleure
- **Filtering / metadata structuré** : ScaNN ne fait pas de filtering riche → vraies vector DBs
- **Pas de GCP / pas de catalogue énorme** : ScaNN apporte peu sur catalogues petits/moyens

## Pièges connus

- **API moins amicale** que Faiss / hnswlib : configurabilité élevée mais courbe d'apprentissage
- **Build / install** : wheels manylinux only, install Mac/Windows non triviale (build from source)
- **Doc clairsemée** : tutoriels limités, exemples souvent obsolètes
- **TensorFlow dependency historique** : ScaNN s'intègre bien avec TF, moins évident hors TF
- **Tree-AH (tree + asymmetric hashing)** : architecture par défaut, params nombreux (`num_leaves`, `num_leaves_to_search`, `dimensions_per_block`)
- **Build long** sur très gros catalogues : compteur de minutes/heures vs HNSW plus rapide
- **Maintenance par Google Research** : pas un produit, releases parfois en pause
- **Pas de delete / update incrémental** propre : rebuild si modifs majeures
- **GPU non standard** : moins utilisé en pratique
- **Benchmarks favorables** : à recall fixé, ScaNN gagne souvent ann-benchmarks mais en réel HNSW reste très compétitif et bien plus simple

## Code minimal

```bash
# Install (Linux x86 wheel uniquement)
pip install scann
```

```python
import scann
import numpy as np

dim = 768
n = 1_000_000

# Donnees synthetiques
np.random.seed(42)
data = np.random.normal(size=(n, dim)).astype("float32")
# Normaliser pour cosine / inner product
data /= np.linalg.norm(data, axis=1, keepdims=True)

# Builder ScaNN : tree-AH (architecture standard)
searcher = (
    scann.scann_ops_pybind.builder(data, num_neighbors=10, distance_measure="dot_product")
    .tree(
        num_leaves=2000, num_leaves_to_search=100,
        training_sample_size=250_000,
    )
    .score_ah(
        dimensions_per_block=2,
        anisotropic_quantization_threshold=0.2,
    )
    .reorder(100)
    .build()
)
```

```python
# Query
query = np.random.normal(size=(5, dim)).astype("float32")
query /= np.linalg.norm(query, axis=1, keepdims=True)

neighbors, distances = searcher.search_batched(query, leaves_to_search=150, final_num_neighbors=10)
print(neighbors.shape)        # (5, 10)
print(distances.shape)
```

```python
# Brute force (baseline pour mesurer recall)
brute = scann.scann_ops_pybind.builder(data, num_neighbors=10, distance_measure="dot_product") \
    .score_brute_force() \
    .build()

# Comparer recall ScaNN vs brute force
gt_neighbors, _ = brute.search_batched(query)
recall = np.mean([
    len(set(neighbors[i]) & set(gt_neighbors[i])) / 10
    for i in range(len(query))
])
print(f"Recall@10 = {recall:.3f}")
```

```python
# Save / Load
searcher.serialize("./scann_index")
loaded = scann.scann_ops_pybind.load_searcher("./scann_index")
```

```python
# Combo Vertex AI Vector Search (GCP managed)
# Sous le capot c'est ScaNN, mais l'API est differente :
from google.cloud import aiplatform

aiplatform.init(project="my-project", location="us-central1")
index = aiplatform.MatchingEngineIndex.create_tree_ah_index(
    display_name="my-index",
    contents_delta_uri="gs://my-bucket/embeddings/",
    dimensions=768,
    approximate_neighbors_count=150,
    distance_measure_type="DOT_PRODUCT_DISTANCE",
    leaf_node_embedding_count=500,
    leaf_nodes_to_search_percent=10,
)
```

## Liens

- [[Faiss]] — alternative multi-algo (IVF-PQ, HNSW, GPU)
- [[hnswlib]] — alternative HNSW pur, plus simple
- [[Qdrant]] / [[Weaviate]] / [[Milvus]] — vector DBs avec filtering
- GCP Vertex AI Vector Search — version managed (ScaNN sous le capot)
- Paper ScaNN : https://arxiv.org/abs/1908.10396 (ICML 2020)
- Benchmarks ANN : https://ann-benchmarks.com/
- GitHub : https://github.com/google-research/google-research/tree/master/scann
