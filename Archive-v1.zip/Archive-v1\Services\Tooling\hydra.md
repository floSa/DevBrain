---
galaxie: dev
nom: hydra
alias: [hydra, hydra-core]
categorie: tooling/config
sous_categories: [config, yaml, facebook, ml-experiments, composition, sweeps]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Pydantic]] Settings", "[[dynaconf]]", "[[python-dotenv]]", "OmegaConf direct"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, config, ml, experiments]
url_officiel: https://hydra.cc/
url_docs: https://hydra.cc/docs/intro/
url_repo: https://github.com/facebookresearch/hydra
---

# hydra

## Pourquoi

Framework de config **Meta (FAIR)** pour expérimentation ML. Trois superpouvoirs :

1. **Composition de configs YAML** : ton config est un graphe (`model`, `dataset`, `optimizer`, `trainer`) → switcher un module = changer un défaut
2. **Override CLI** : `python train.py model=resnet50 optimizer.lr=0.01 dataset.batch_size=64`
3. **Multi-runs (sweeps)** : `python train.py -m model=resnet50,vit lr=0.01,0.001` → 4 runs en parallèle (combo Optuna / Ray Tune plugins)

Construit au-dessus de **OmegaConf**. Standard de fait dans la recherche DL (Fairseq, Detectron2, PyTorch Lightning examples, MMLab) et de plus en plus en MLOps. Cible : équipes ML qui jonglent avec dizaines/centaines d'expériences et veulent **reproductibilité + composabilité**.

## Quand l'utiliser

- **Expériences ML** avec nombreuses combinaisons : modèles × datasets × optimizers × seeds
- **Multi-runs sweeps** : `-m` (multirun) avec produit cartésien ou plugin Optuna/Nevergrad
- **Override CLI propre** : remplacer un argparse spaghetti par des configs YAML composables
- **Reproductibilité** : Hydra save un snapshot de la config + working dir par run
- **Stack PyTorch Lightning** : combo très répandu
- **Stack Fairseq / Detectron2 / MMLab / TorchRec** : Hydra natif
- **Working dir par run** : chaque run dans `outputs/2026-05-20/12-34-56/` (peut être désactivé)

## Quand NE PAS l'utiliser

- **App production / web / API** → [[Pydantic]] Settings (validation typée, simple)
- **Config simple** (5-10 vars) → [[python-dotenv]] + Pydantic Settings
- **Pas besoin de composition** : Hydra = over-engineering pour un script simple
- **Multi-env classique** (dev/staging/prod) → [[dynaconf]] plus naturel
- **Stack non-Python ML** : Hydra reste très Python ML-flavored

## Pièges connus

- **Magic `@hydra.main()` decorator** : modifie le `cwd`, le logging, l'argparse → comportement parfois surprenant en debug
- **CWD changes par défaut** : Hydra `chdir` vers un dossier outputs → désactiver avec `hydra.job.chdir=false` (par défaut depuis 1.2)
- **OmegaConf concepts** à apprendre : interpolation `${other.field}`, structured configs (dataclass), missing values `MISSING`
- **Composition Defaults List** verbeuse : `defaults: - model: resnet - dataset: imagenet - _self_` peut surprendre
- **Lock-in modéré** : porter un projet Hydra-heavy ailleurs demande du travail
- **Erreurs cryptiques** : "Missing mandatory value" sans dire où, ou cycles d'interpolation
- **Pas typed-friendly natif** : structured configs (dataclass) à utiliser, sinon `DictConfig` est faiblement typé
- **Plugins sweeps externe** : Optuna / Ray plugins à installer séparément (`hydra-optuna-sweeper`)
- **Doc fragmentée** entre Hydra et OmegaConf — souvent il faut creuser les deux
- **Multi-run parallel** : `joblib` par défaut, pour scale réel utiliser `submitit` (SLURM), Ray ou Optuna plugin

## Code minimal

```bash
pip install hydra-core
# Plugins utiles
pip install hydra-optuna-sweeper hydra-submitit-launcher
```

```yaml
# conf/config.yaml
defaults:
  - model: resnet
  - dataset: imagenet
  - optimizer: adam
  - _self_

experiment_name: baseline
seed: 42

hydra:
  job:
    chdir: false        # ne pas changer le cwd
```

```yaml
# conf/model/resnet.yaml
name: resnet50
num_layers: 50
pretrained: true

# conf/model/vit.yaml
name: vit_base
patch_size: 16
pretrained: true

# conf/optimizer/adam.yaml
_target_: torch.optim.Adam
lr: 1e-3
weight_decay: 1e-4
```

```python
# train.py
import hydra
from omegaconf import DictConfig, OmegaConf
import torch
from hydra.utils import instantiate

@hydra.main(version_base=None, config_path="conf", config_name="config")
def main(cfg: DictConfig) -> None:
    print(OmegaConf.to_yaml(cfg))
    print(f"Running {cfg.experiment_name} with model={cfg.model.name}")

    # _target_ -> instantie l'objet automatiquement
    model = build_model(cfg.model)
    optimizer = instantiate(cfg.optimizer, params=model.parameters())

    # ... training loop ...

if __name__ == "__main__":
    main()
```

```bash
# Run par defaut
python train.py

# Override CLI
python train.py model=vit optimizer.lr=0.0005 seed=123

# Multi-run (sweep)
python train.py -m model=resnet,vit optimizer.lr=0.001,0.0001 seed=1,2,3
# -> 2 * 2 * 3 = 12 runs

# Avec Optuna pour search bayesien
python train.py -m hydra/sweeper=optuna optimizer.lr=interval(1e-5,1e-2)
```

```python
# Structured config (typed)
from dataclasses import dataclass
from hydra.core.config_store import ConfigStore

@dataclass
class OptimizerConfig:
    lr: float = 1e-3
    weight_decay: float = 1e-4

@dataclass
class Config:
    experiment_name: str = "baseline"
    seed: int = 42
    optimizer: OptimizerConfig = OptimizerConfig()

cs = ConfigStore.instance()
cs.store(name="base_config", node=Config)
```

## Liens

- OmegaConf — foundation de Hydra (interpolation, structured configs)
- [[Pydantic]] Settings — alternative typed pour apps prod
- [[dynaconf]] — alternative multi-env / multi-format
- [[python-dotenv]] — alternative simple .env
- PyTorch Lightning + Hydra : combo standard recherche DL
- Docs : https://hydra.cc/docs/intro/
- GitHub : https://github.com/facebookresearch/hydra
- Plugins : https://hydra.cc/docs/plugins/optuna_sweeper/
