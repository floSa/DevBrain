---
name: audit-vault
description: |
  Use this skill for periodic batch hygiene of the vault. Triggers:
  "audit du vault", "hygiene mensuelle", "audit complet", "etat du vault",
  "verifie la sante du brain", "nettoie le vault". Runs the 3-script
  pipeline (audit-vault + report-ghosts + audit-links), produces 3 reports
  in AI/audits/, and presents a priorities list. Distinct from cross-link
  which is interactive (paire-by-paire) ; this skill is read-only diagnostic.
---

# Skill — audit-vault

## Quand l'utiliser

Hygiène **périodique** du vault (mensuel typiquement). Ne modifie rien, génère **3 rapports** dans `AI/audits/` puis présente un récap priorisé à l'utilisateur. Le travail correctif se fait ensuite via :

- `cross-link` pour les wikilinks (fantômes + manquants)
- `expand-stub` pour les fiches `status: stub`
- `audit-skills` pour les `Wiki/Outils/*` à status `discovered`

Distinct de `cross-link` qui est interactif paire-par-paire ; `audit-vault` est read-only diagnostic.

## Procédure

### Étape 1 — État général du vault

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/audit-vault.ps1 -Cleanup -Force
# -> ecrit AI/audits/audit-YYYY-MM-DD.md
# -Cleanup -Force : supprime auto les fichiers 0-byte (parasites Obsidian)
```

Métriques produites :
- Nb fiches par galaxie (dev / wiki / skills / meta / aucune)
- Fiches sans frontmatter ou frontmatter incomplet
- Fiches vides / stub / normal / complet (lignes hors frontmatter)
- Sections clés manquantes pour Concepts (TL;DR, Code minimal, Pour aller plus loin)

### Étape 2 — Audit des fantômes

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/report-ghosts.ps1
# -> ecrit AI/audits/ghosts-YYYY-MM-DD.md
```

Groupés par cible inexistante avec sources et suggestion (ALIAS-FIX / A CREER / A DECIDER / FAIBLE).

### Étape 3 — Audit des liens manquants

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/audit-links.ps1
# -> ecrit AI/audits/links-audit-YYYY-MM-DD.md
```

Pour chaque fiche : candidats à wikilinker (par scoring metadata) qui ne sont pas encore wikilinkés. Score ≥ 8 par défaut.

### Étape 4 — Synthèse priorisée

Présente à l'utilisateur en récap structuré :

```
Audit du vault - <date>

STRUCTURE
  - <N> fiches totales
  - <K> sans frontmatter (à corriger)
  - <M> sans galaxie (à classer)
  - <P> fichiers 0-byte (nettoyés via -Cleanup)

WIKILINKS
  Fantômes :
    - <X> ALIAS-FIX  (corrections triviales via cross-link)
    - <Y> A CREER    (candidats à add-service / add-wiki-*)
    - <Z> A DECIDER  (cas par cas)
    - <W> FAIBLE     (probablement dewikilinker)

  Liens manquants : <N> paires à proposer via cross-link

CONTENU
  - <S> fiches status: stub à étoffer (expand-stub)
  - <D> outils Wiki/Outils status: discovered à promouvoir (audit-skills)

PROPOSITION D'ACTIONS
  1. <action prioritaire>
  2. ...
```

### Étape 5 — Suggérer next steps

Selon les résultats, propose les skills à lancer en suite :

- Si fantômes ALIAS-FIX > 0 → lance `cross-link` pour appliquer
- Si fantômes A CREER ≥ 3 ref → propose `add-service` / `add-wiki-concept` pour chacun
- Si liens manquants > 20 → lance `cross-link` par périmètre (galaxie ou catégorie)
- Si stubs > 10 → lance `expand-stub` en batch

Ne pas exécuter ces skills automatiquement — l'utilisateur valide la suite.

## Sortie attendue

3 fichiers dans `AI/audits/` (auto-écrits par les scripts) :

```
AI/audits/audit-YYYY-MM-DD.md         # etat general
AI/audits/ghosts-YYYY-MM-DD.md        # fantomes
AI/audits/links-audit-YYYY-MM-DD.md   # liens manquants
```

Récap utilisateur en réponse Claude.

## Anti-patterns à éviter

- **Modifier des fichiers** — ce skill est read-only diagnostic
- **Lancer cross-link / expand-stub en cascade automatique** — l'utilisateur valide la suite
- **Ignorer les rapports précédents** — comparer avec audit du mois dernier pour repérer les régressions

## Fréquence recommandée

- **Mensuelle** : tous les rapports
- **Après une session intensive** d'ajout de fiches (10+) : `report-ghosts` au minimum
- **Avant un commit majeur** ou push : `report-ghosts` pour confirmer 0 fantôme

## Scripts utilisés

| Script | Rôle |
|---|---|
| `AI/scripts/audit-vault.ps1` | Audit général (frontmatter, sections, 0-byte) |
| `AI/scripts/report-ghosts.ps1` | Wikilinks fantômes groupés par cible |
| `AI/scripts/audit-links.ps1` | Wikilinks manquants par fiche |

Doc consolidée : `AI/scripts/README.md`.

## Voir aussi

- `cross-link` (action interactive sur les fantômes + liens manquants détectés)
- `expand-stub` (étoffer les fiches status: stub)
- `audit-skills` (hygiène Wiki/Outils/* — focalisé sur les status discovered)
- `process-inbox` (ranger les notes brouillon avant l'audit)
