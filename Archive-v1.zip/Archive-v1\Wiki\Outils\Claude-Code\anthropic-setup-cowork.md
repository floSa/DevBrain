---
galaxie: wiki
nom: anthropic-skills:setup-cowork
type: claude-code-skill
plateforme: claude-code
categorie: skill/dev-flow
sous_categories: [team, onboarding, cowork]
auteur: Anthropic
source: anthropics/skills
source_url: https://github.com/anthropics/skills
install_cmd: claude plugin install anthropic-skills
install_doc: https://docs.claude.com/en/docs/build-with-claude/cowork
licence: MIT
licence_type: open-source
domaines: []
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, team, onboarding]
---

# anthropic-skills:setup-cowork

## Pourquoi

Skill d'**onboarding équipe Cowork** : installe les plugins matchés à ton rôle, branche tes outils (Slack, GitHub, Linear, etc.), te fait essayer un skill. C'est le "wizard" Cowork — l'équivalent d'un setup wizard d'entreprise pour Claude.

Pas pertinent en solo, gros si tu intègres une équipe qui bosse déjà sur Cowork.

## Quand l'utiliser

- Premier jour dans une équipe qui utilise Anthropic Cowork
- Quand tu changes de rôle dans une équipe et que tes outils doivent évoluer
- Onboarder un collègue : "lance `/setup-cowork` pour t'installer"

## Quand NE PAS l'utiliser

- Solo dev / freelance — Cowork c'est pour les équipes
- Tu n'as pas d'accès Cowork (offre payante)

## Comment l'installer

```bash
claude plugin install anthropic-skills
```

## Exemples d'usage

```
> /setup-cowork
> guide-moi pour l'onboarding Cowork de mon nouveau rôle "data eng"
```

## Pièges connus

- Nécessite un compte Cowork actif côté équipe
- Les plugins matchés au rôle sont définis par l'admin Cowork — tu peux pas les bypass

## Liens

- Source : https://github.com/anthropics/skills
- Doc Cowork : https://docs.claude.com/en/docs/build-with-claude/cowork
