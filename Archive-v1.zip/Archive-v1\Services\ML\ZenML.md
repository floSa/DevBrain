---
galaxie: dev
nom: ZenML
alias: [zenml]
categorie: ml/orchestration
sous_categories: [pipelines, mlops, abstraction-layer, stacks]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Kubeflow]]", "[[Metaflow]]", "[[Flyte]]", "[[Dagster]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ml, orchestration, mlops, python]
url_officiel: https://www.zenml.io/
url_docs: https://docs.zenml.io/
url_repo: https://github.com/zenml-io/zenml
---

# ZenML

## Pourquoi
Framework MLOps **portable**. Tu écris des pipelines Python avec `@step` / `@pipeline`, ZenML les exécute sur le **stack** que tu configures (local, [[Kubeflow]], [[Airflow]], Vertex, SageMaker, etc.). Idée clé : code une fois, run partout. Bonne intégration avec [[MLflow]], [[Weights & Biases]], [[Feast]], etc.

## Quand l'utiliser
- Tu veux décorrer **code ML** et **infra d'exécution**
- Migration progressive du local vers le cloud (changement de stack sans réécrire)
- Découverte MLOps sans se taper [[Kubeflow]]
- Monorepo ML avec plusieurs équipes / projets
- Bon compromis entre [[Kubeflow]] (lourd) et [[Dagster]] (généraliste data)

## Quand NE PAS l'utiliser
- Stack figé K8s avec besoins très spécifiques → [[Kubeflow]] direct
- Workflows non-ML (data pure ETL) → [[Dagster]] / [[Airflow]]
- Très petit projet → [[MLflow]] tracking seul peut suffire

## Pièges connus
- **Stack components** : abstraction puissante mais beaucoup de configs (orchestrator, artifact_store, container_registry…)
- **ZenML Server** : optionnel mais nécessaire pour collaboration / auth — déployer Postgres + serveur
- **Versions** : releases mensuelles, breaking changes possibles
- **Step caching** : par défaut activé, peut piéger (résultats stale)
- **ZenML Cloud (managed)** : nouveau, pricing à surveiller
- **Materializers** : objets Python custom → définir un materializer pour persistance

## Liens
- [[Kubeflow]], [[Metaflow]], [[Flyte]] — alternatives
- [[MLflow]] — souvent intégré pour tracking
- Stack components : https://docs.zenml.io/stack-components
- Quickstart : https://docs.zenml.io/getting-started/quickstart
