---
galaxie: wiki
nom: Tool Use
type: concept
categorie: concept/llm
sous_categories: [function-calling, tools, agents, structured-output]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Anthropic, OpenAI]
lecture_min: 7
created: 2026-05-19
modified: 2026-05-20
tags: [concept, llm, tool-use, function-calling]
---

# Tool Use — Function Calling

## TL;DR

Le LLM ne se contente pas de répondre en texte : il peut **demander à appeler une fonction** que tu as définie (lire un fichier, query une DB, envoyer un mail). Toi tu exécutes la fonction côté code, tu renvoies le résultat au LLM, il continue. C'est le mécanisme qui rend les **agents** possibles.

Le terme "tool use" est devenu standard chez Anthropic, "function calling" chez OpenAI — c'est exactement la même chose.

## Le problème

Un LLM seul ne peut que **générer du texte**. Il ne peut pas :
- Lire un fichier du système
- Faire un calcul exact (10 décimales, divisions)
- Appeler une API externe
- Modifier l'état du monde

Or pour qu'un agent serve à quelque chose, il faut bien qu'il **agisse**, pas juste qu'il parle. Tool use est la passerelle.

## L'idée

```
Toi (dev) :
1. Définis une liste d'outils (nom, description, schéma JSON des inputs)
2. Envoie au LLM : [message utilisateur] + [tools disponibles]

LLM :
3. Décide : "je dois appeler tool_X avec {a: 1, b: 'foo'}"
4. Te retourne une intention d'appel (pas du texte normal)

Toi :
5. Exécute réellement tool_X(a=1, b='foo') côté code
6. Renvoie le résultat au LLM

LLM :
7. Continue à raisonner avec le résultat. Peut appeler d'autres tools, ou répondre.
```

Exemple JSON Anthropic :

```python
tools = [{
    "name": "get_weather",
    "description": "Get the weather for a city",
    "input_schema": {
        "type": "object",
        "properties": {
            "city": {"type": "string"}
        },
        "required": ["city"]
    }
}]

# Le LLM peut décider de retourner :
# {"type": "tool_use", "name": "get_weather", "input": {"city": "Paris"}}
```

## Quand c'est utile

- **Agent** qui doit interagir avec le monde (DBs, APIs, filesystem)
- **Code execution** : un tool `python_eval` pour faire des calculs exacts
- **Structured output via tool use** : forcer un format de sortie en définissant un tool fictif (alternative à [[Instructor]])
- **Multi-step reasoning** : le LLM enchaîne des tool calls pour résoudre un problème complexe
- **MCP** : le protocole [[mcp-protocol|MCP]] est essentiellement une standardisation du tool use

## Quand ça ne marche pas / pièges

- **Trop d'outils** (>20) → le LLM se perd, oublie certains, choisit le mauvais. Hiérarchise (un tool "main" qui dispatch).
- **Descriptions floues** → le LLM ne sait pas quand l'invoquer. Soigne la description comme tu soignerais une docstring publique.
- **Schémas JSON laxistes** → le LLM hallucine des paramètres. Force `required` et types stricts.
- **Pas de validation côté code** → le LLM peut envoyer des inputs valides JSON-wise mais invalides métier. Toujours valider (Pydantic, etc.).
- **Boucles infinies** sur des agents mal cadrés → toujours un `max_steps`.
- **Coût** : chaque tool call = un round-trip LLM. Sur 10 steps, tu paies 10× la conversation.

## Implémentations concrètes

- [[Anthropic Claude API]] — `tools` param dans `messages.create`
- [[LangGraph]] / [[PydanticAI]] — abstractions agent par-dessus tool use
- [[Instructor]] — utilise tool use en interne pour le structured output
- [[mcp-protocol]] — standardise le tool use cross-LLM

## Code minimal

```python
# 1. Tool use Anthropic — round-trip complet
import anthropic
client = anthropic.Anthropic()

tools = [{
    "name": "get_weather",
    "description": "Get current weather for a city",
    "input_schema": {
        "type": "object",
        "properties": {
            "city": {"type": "string", "description": "City name, e.g. 'Paris'"},
            "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]}
        },
        "required": ["city"]
    }
}]

# Mock implementation
def execute_tool(name, args):
    if name == "get_weather":
        return f"22°C in {args['city']}"
    return f"Unknown tool: {name}"

# Premier appel : le LLM peut décider d'invoquer le tool
messages = [{"role": "user", "content": "What's the weather in Paris?"}]
response = client.messages.create(
    model="claude-3-7-sonnet-latest",
    max_tokens=1024,
    tools=tools,
    messages=messages,
)

# Inspecter la réponse
if response.stop_reason == "tool_use":
    # Le LLM veut appeler un tool
    messages.append({"role": "assistant", "content": response.content})
    
    tool_results = []
    for block in response.content:
        if block.type == "tool_use":
            result = execute_tool(block.name, block.input)
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": block.id,
                "content": result,
            })
    
    # Renvoyer les résultats au LLM
    messages.append({"role": "user", "content": tool_results})
    
    # Le LLM finit avec une réponse texte
    final = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=1024,
        tools=tools,
        messages=messages,
    )
    print(final.content[0].text)
    # → "The weather in Paris is 22°C."

# 2. Forced tool use (utile pour structured output)
response = client.messages.create(
    model="claude-3-7-sonnet-latest",
    max_tokens=1024,
    tools=tools,
    tool_choice={"type": "tool", "name": "get_weather"},  # force ce tool
    messages=[{"role": "user", "content": "Paris ?"}]
)

# 3. OpenAI function calling (équivalent)
from openai import OpenAI
client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    tools=[{
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "...",
            "parameters": tools[0]["input_schema"],
        }
    }],
    messages=[{"role": "user", "content": "Weather in Paris?"}]
)

# 4. Validation Pydantic des args
from pydantic import BaseModel, ValidationError

class WeatherArgs(BaseModel):
    city: str
    unit: str = "celsius"

def safe_execute(name, args):
    if name == "get_weather":
        try:
            validated = WeatherArgs(**args)
            return execute_tool(name, validated.model_dump())
        except ValidationError as e:
            return f"Invalid args: {e}"
    return f"Unknown tool: {name}"

# Pour un agent multi-tool : voir [[Agent patterns]] et [[Tool use patterns]]
```

## Pour aller plus loin

- Doc Anthropic tool use : https://docs.claude.com/en/docs/build-with-claude/tool-use
- Concept lié : [[agent-loops]] (comment enchaîner les tool calls)
- Concept lié : [[mcp-protocol]] (l'écosystème standardisé)
