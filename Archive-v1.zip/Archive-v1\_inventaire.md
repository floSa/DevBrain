# Inventaire du réservoir v1

> Généré par `AI/scripts/list_reservoir.py`. Ne pas éditer à la main.
> 393 pages v1 conservées comme **référence** (hors brain v2).
> Pour recréer un sujet au format v2 : demander au skill `enrichir-brain`.

## Bugs
- REX - Postgres

## Patterns
- Comparatif - Bases vectorielles
- Comparatif - LLM eval et observability
- Comparatif - ML orchestration
- Comparatif - Orchestrateurs data
- Pattern - Agent ReAct
- Pattern - API REST FastAPI minimale
- Pattern - CLI Python distribuable
- Pattern - Forecasting production
- Pattern - LLM Eval setup
- Pattern - Pipeline ELT moderne
- Pattern - RAG basique
- Pattern - SaaS multi-tenant

## Rules/Documentation
- Config-Env
- Database-Graph
- Database-Relational
- Database-Vector
- Document-Processing
- Index
- LLM-Orchestration
- Orchestration-Data
- Project-README
- README - Service
- Storage-Object
- Tests

## Rules/Global
- Code-style
- Documentation
- Git
- README
- Security
- Tests

## Rules/Types
- CLI
- Data-pipeline
- Library
- ML-pipeline
- Web-app

## Services/Data
- Airflow
- Apache Iceberg
- Argo Workflows
- Avro
- BigQuery
- Dagster
- dbt
- Docling
- Flink
- Great Expectations
- Kestra
- LlamaParse
- Mage
- Marker
- Parquet
- pdfplumber
- Polars
- Prefect
- PyMuPDF
- Snowflake
- Temporal
- Unstructured

## Services/Databases
- CockroachDB
- DuckDB
- MongoDB
- MySQL
- Nebula Graph
- Neo4j
- Postgres
- Redis
- SQLite

## Services/Decision
- Camunda
- Drools
- OpenL Tablets
- pyDMNrules

## Services/DevOps
- Docker
- GitHub-Actions

## Services/Frameworks
- FastAPI

## Services/LLM
- Anthropic Claude API
- AutoGen
- Azure OpenAI
- Cohere API
- CrewAI
- DeepEval
- DSPy
- Google Gemini API
- Haystack
- Helicone
- Instructor
- LangChain
- Langfuse
- LangGraph
- LangSmith
- LiteLLM
- llama.cpp
- LlamaIndex
- LM Studio
- Mistral API
- MLX
- Ollama
- OpenAI API
- Phoenix Arize
- PydanticAI
- Ragas
- Semantic Kernel
- SGLang
- TensorRT-LLM
- text-generation-webui
- TGI
- TruLens
- vLLM

## Services/ML
- Aim
- ArviZ
- BentoML
- CatBoost
- ClearML
- Comet
- darts
- fanalysis
- Feast
- Flyte
- hdbscan
- HuggingFace
- Hyperopt
- JAX
- KServe
- Kubeflow
- lifelines
- LightGBM
- Metaflow
- MLflow
- Neptune
- neuralforecast
- NVIDIA Triton
- Optuna
- prince
- Prophet
- PyMC
- PyTorch
- Ray
- Ray Serve
- Ray Tune
- scikit-learn
- Seldon Core
- statsforecast
- statsmodels
- TensorFlow
- TensorFlow Serving
- TorchServe
- umap-learn
- Weights & Biases
- XGBoost
- ZenML

## Services/Observability
- Grafana
- Loki

## Services/Storage
- AWS S3
- Cloudflare R2
- MinIO

## Services/Tooling
- Alembic
- altair
- bokeh
- CuPy
- Dask
- dynaconf
- hydra
- matplotlib
- Modin
- numpy
- pandas
- pingouin
- pip
- plotly
- Polars
- Prince
- Pydantic
- Pydantic Settings
- pytest
- python-dotenv
- Ruff
- scipy.stats
- seaborn
- Spark
- SQLAlchemy
- statsmodels
- testcontainers
- uv
- Uvicorn

## Services/UI
- Dash
- Gradio
- Shiny for Python
- Streamlit

## Services/VectorDB
- Annoy
- Chroma
- Faiss
- hnswlib
- Milvus
- pgvector
- Qdrant
- ScaNN
- Weaviate

## Wiki
- _guide
- _installer-un-skill
- Roadmap
- Roadmap-AI

## Wiki/Concepts
- A-B testing
- Actor-Critic methods
- Adam optimizer
- Advanced RAG
- Agent evaluation
- Agent memory
- Agent patterns
- agent-loops
- AI security
- ARIMA SARIMA
- Autocorrelation
- Bayesian inference
- Bellman equations
- Bias-variance tradeoff
- BKM - Business Knowledge Model
- Bootstrap
- Boxed Expressions
- BPMN DMN CMMN
- Brownian motion
- CA
- Calibration
- Central limit theorem
- Chain-of-Thought
- Chi-squared tests
- Chunking strategies
- Classification metrics
- Clustering evaluation
- Code and math benchmarks
- Concentration inequalities
- Confidence intervals
- Context engineering
- Convexity
- Cross-entropy
- Cross-validation
- CUPED
- Data drift
- Data leakage
- DBSCAN
- Decision Intelligence
- Decision Model and Notation
- Decision Tables
- Decoding strategies
- Diffusion models
- Distillation
- DMN and ML hybrid
- DMN Conformance Levels
- DRD - Decision Requirements Diagram
- Eigendecomposition
- embeddings
- Ensembling
- Explainability and decision automation
- Exploration vs exploitation
- Exponential smoothing
- FAMD
- Feature engineering
- FEEL
- Flash Attention and efficient attention
- Forecasting framing
- Forecasting metrics
- Generalization bounds
- GMM
- GPA
- Gradient descent
- GRPO
- Guardrails
- HCPC
- Hierarchical forecasting
- Hybrid retrieval
- Hypothesis testing
- Image generation
- Imbalanced classification
- Imitation learning
- Inference optimization
- Intermittent demand
- Jailbreaking and defenses
- Jensen-Shannon divergence
- K-means
- KL divergence
- Learning rate schedules
- LLM benchmarks
- LLM caching
- LLM eval metrics
- LLM observability
- LLM-as-judge
- Loss landscape and saddle points
- MAP estimation
- Markov chains
- Markov Decision Process
- Matrix decompositions
- Matrix products
- Maximum likelihood estimation
- MCA
- MCMC
- mcp-protocol
- MFA
- Missing data
- Mixture of Experts
- Model-based RL
- Multi-agent systems
- Multi-armed bandits
- Multiple testing correction
- Mutual information
- Newton & quasi-Newton
- No Free Lunch theorem
- Offline RL
- PAC learning
- PCA
- PEFT
- Perplexity
- PGA
- Poisson process
- Policy gradient
- Positional encoding
- PPO
- Projections
- Prompt engineering
- Prompt injection
- prompt-caching
- Q-learning and DQN
- Quantization
- Query transformations
- Rademacher complexity
- RAG
- RAG eval
- Ranking metrics
- Reasoning models
- Regression metrics
- Regularization
- Reinforcement learning
- Reliability patterns
- Reranking
- Reward modeling
- Reward shaping and hacking
- RL for LLMs
- RLHF and DPO
- ROC AUC
- Routing and cascading
- Scaling laws
- Self-attention
- SFT
- Shannon entropy
- Small Language Models
- Speculative decoding
- Speech models
- State Space Models
- Stationarity
- Structured outputs
- SVD
- Synthetic data generation
- t-SNE and UMAP
- t-test and ANOVA
- Time series anomaly detection
- Time series feature engineering
- Tokenization
- Tool use patterns
- tool-use
- Transformer architectures
- Value functions
- VC dimension
- Vector norms
- Video generation
- Vision Language Models
- Walk-forward CV
- Wasserstein distance

## Wiki/Outils/CLI-Tools
- uv

## Wiki/Outils/Claude-Code
- anthropic-consolidate-memory
- anthropic-docx
- anthropic-pdf
- anthropic-pptx
- anthropic-setup-cowork
- anthropic-skill-creator
- anthropic-xlsx
- claude-api
- claude-fewer-permission-prompts
- claude-init
- claude-keybindings-help
- claude-loop
- claude-review
- claude-schedule
- claude-security-review
- claude-simplify
- claude-update-config

## Wiki/Outils/MCP-Servers
- mcp-filesystem
- mcp-github
- mcp-obsidian
- mcp-obsidian - reference outils
- mcp-postgres

## Wiki/Outils/Obsidian
- kepano-defuddle
- kepano-obsidian-skills

## Wiki/Workflows
- Bootstrap projet AI eng
- Debug pipeline data
- Evaluer un modele forecast
- Evaluer un systeme LLM
