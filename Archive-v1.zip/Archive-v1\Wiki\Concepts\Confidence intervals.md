---
galaxie: wiki
nom: Confidence intervals
alias: [intervalle de confiance, IC, CI, IC95%]
type: concept
categorie: concept/stats
sous_categories: [confidence-interval, uncertainty, estimation, bootstrap, frequentist]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Neyman 1937]
lecture_min: 7
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, confidence-interval, uncertainty]
---

# Confidence intervals

## TL;DR

Un IC à 95% pour un paramètre $\theta$ est un intervalle $[L, U]$ calculé sur les données tel que **sur des répétitions infinies de l'expérience, 95% des IC contiendraient la vraie valeur de $\theta$**. Plus informatif qu'une p-value : indique la **précision** de l'estimation. Méthodes : analytique (gaussien, $t$, etc.), **bootstrap** (universel), bayésien (intervalles de crédibilité).

## Le problème

Tu rapportes "la conversion est de 12%". OK mais c'est combien de précis ? 12% ± 0.5% ou 12% ± 5% ? C'est la même décision business radicalement différente.

La p-value ne te dit que "significativement différent de X ou pas". Elle ne dit pas **à quel point** ton estimation est précise.

## L'idée

### Interprétation correcte

Un IC95% pour $\theta$ se lit :
> "Si on refait l'expérience un grand nombre de fois et qu'on calcule l'IC à chaque fois selon la même procédure, 95% des intervalles contiendront la vraie valeur de $\theta$."

❌ **Faux** : "Il y a 95% de chance que $\theta$ soit dans cet intervalle." (interprétation bayésienne, valide pour les **intervalles de crédibilité** uniquement)

❌ **Faux** : "95% des données sont dans cet intervalle." (c'est la définition d'un intervalle de prédiction)

✅ **Vrai** : L'IC95% est une zone de valeurs "plausibles" pour $\theta$ étant donné les données — sans probabilité formelle attribuable.

### Lien avec hypothesis testing

Un IC95% **contient toutes les valeurs $\theta_0$ pour lesquelles on ne rejette pas $H_0: \theta = \theta_0$ à $\alpha = 0.05$**.

→ Si l'IC à 95% ne contient pas 0 pour une différence, c'est équivalent à dire qu'on rejette $H_0:$ diff = 0 au seuil 5%. **L'IC contient plus d'information** que la p-value.

### Méthodes

#### Gaussien (Wald)

Pour $\bar X$ et $n$ grand :

$$ \text{IC}_{95\%}(\mu) = \bar X \pm 1.96 \cdot \frac{s}{\sqrt{n}} $$

Suppose normalité asymptotique (TCL). Marche bien pour $n \geq 30$ et statistiques régulières.

#### t-Student

Pour $\bar X$ et $n$ petit avec données normales :

$$ \text{IC}_{95\%}(\mu) = \bar X \pm t_{n-1, 0.975} \cdot \frac{s}{\sqrt{n}} $$

Le quantile $t_{n-1, 0.975}$ remplace 1.96 (plus large pour petit $n$).

#### Proportions (Wilson, Wald, Clopper-Pearson)

Pour une proportion $\hat p = k/n$ :

- **Wald (naïf)** : $\hat p \pm 1.96 \sqrt{\hat p(1-\hat p)/n}$. Mauvais aux extrêmes (proba > 1 ou < 0).
- **Wilson** : forme corrigée, **toujours préférée à Wald** (préfère `statsmodels.stats.proportion.proportion_confint`)
- **Clopper-Pearson** : exact, conservateur, pour petits $n$

#### Bootstrap

Universel, marche pour toute statistique. Voir [[Bootstrap]] section "Intervalle de confiance".

#### Intervalle de crédibilité (bayésien)

Avec un prior, on calcule la distribution a posteriori et on en extrait l'intervalle [2.5%, 97.5%] des percentiles. C'est l'**intervalle de crédibilité** — interprétation directe en probabilité ("95% de chance que $\theta$ soit dans"). Voir [[PyMC]].

### Largeur de l'IC

Largeur ≈ $2 \times 1.96 \times SE \propto 1/\sqrt{n}$. Pour **diviser la largeur par 2**, il faut **4× plus de données**. C'est ce qui sous-tend les calculs de **taille d'échantillon**.

### Couverture

La proportion réelle d'IC qui contiennent la vraie valeur doit être proche du **niveau nominal** (95%). Pour des méthodes asymptotiques sur petit $n$, la couverture peut être plus faible. Tester par simulation si besoin de garantie.

### IC pour métriques ML

**Toujours rapporter un IC** quand on évalue un modèle :
- Bootstrap d'une métrique (AUC, accuracy)
- Cross-validation : moyenne ± écart-type sur les folds (ou IC95% si normalité raisonnable)
- IC pour la **différence de performance** entre 2 modèles (DeLong test pour AUC, McNemar pour accuracy)

## Quand c'est utile

- Rapporter une estimation avec sa précision (recommandé partout)
- Décisions business sous incertitude
- Comparaison de modèles ML
- Validation d'une mesure terrain
- Quand la p-value seule est trompeuse (large $n$ + effet trivial significatif)

## Quand ça ne marche pas / pièges

- **Mauvaise interprétation** comme proba bayésienne — fréquentiste = sur **répétitions de l'expérience**
- **Wald sur proportion extrême** ($\hat p$ proche de 0 ou 1) → intervalle invalide. Utiliser Wilson.
- **Hypothèses violées** (normalité, indépendance) → IC mal calibré. [[Bootstrap]] plus robuste.
- **IC + multiple testing** : si plusieurs IC sont rapportés sans correction, le **niveau de confiance simultané** est plus bas que 95%. Voir [[Multiple testing correction]].
- **IC pour ratio ou produit** : pas le même que somme/différence — utiliser méthode delta ou bootstrap
- **Confusion avec interval de prédiction** : IC = pour la moyenne / paramètre ; prédiction = pour une **nouvelle observation**. La seconde est toujours plus large.

## Code minimal

```python
from scipy import stats
import numpy as np

data = np.array([...])

# IC analytique sur la moyenne (t-distribution)
ic = stats.t.interval(0.95, len(data)-1, loc=data.mean(), scale=stats.sem(data))
print(f"Mean = {data.mean():.3f}, IC95% = ({ic[0]:.3f}, {ic[1]:.3f})")

# IC bootstrap sur la médiane
res = stats.bootstrap((data,), np.median, confidence_level=0.95, 
                      n_resamples=10000, method='BCa', random_state=0)
print(f"Median IC95% = ({res.confidence_interval.low:.3f}, "
      f"{res.confidence_interval.high:.3f})")

# IC pour proportion (Wilson)
from statsmodels.stats.proportion import proportion_confint
low, high = proportion_confint(count=42, nobs=100, alpha=0.05, method='wilson')
print(f"Proportion IC95% = ({low:.3f}, {high:.3f})")
```

## Implémentations concrètes

- `scipy.stats` : `t.interval`, `norm.interval`, `bootstrap`
- `statsmodels.stats.proportion.proportion_confint` (Wilson, Clopper-Pearson, etc.)
- `pingouin` : interfaces unifiées avec effect sizes
- R : `t.test`, `prop.test`, `binom.test`, package `boot`

## Pour aller plus loin

- Neyman, *Outline of a theory of statistical estimation based on the classical theory of probability* (1937)
- Greenland et al., *Statistical tests, P values, confidence intervals, and power* (2016)
- **Liens internes** : [[Hypothesis testing]], [[Bootstrap]], [[Multiple testing correction]], [[ROC AUC]] (IC sur AUC via DeLong ou bootstrap)
