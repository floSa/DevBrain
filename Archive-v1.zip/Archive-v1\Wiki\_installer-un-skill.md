---
galaxie: wiki
type: wiki-guide
created: 2026-05-19
modified: 2026-05-19
tags: [wiki, skills, install, howto]
---

# Installer un skill — procédure par famille

> Procédure pratique. Pour la théorie (qu'est-ce qu'un skill, comment c'est rangé) → [[_guide]].

Avant de toucher à quoi que ce soit, regarde le champ `type` de la fiche skill que tu veux installer. Il dicte la procédure.

---

## 1. Claude Code skill (`type: claude-code-skill`)

Deux sous-cas selon que le skill est officiel Anthropic ou communautaire/perso.

### 1.a — Skill officiel Anthropic (`anthropic-skills:*`)

Ces skills viennent en pack via le plugin **Anthropic Skills**.

```bash
# Une fois pour toutes
claude plugin install anthropic-skills
```

Après quoi `anthropic-skills:xlsx`, `anthropic-skills:pdf`, etc. sont auto-chargés selon le contexte.

Vérifie avec `claude plugin list` puis dans une session : tape `/help` ou attends un trigger naturel (mention d'un `.xlsx` p.ex.).

### 1.b — Skill communautaire ou perso

Soit le skill est un **plugin marketplace** :

```bash
claude plugin install <owner>/<repo>
```

Soit c'est un skill standalone à poser localement :

```bash
mkdir -p ~/.claude/skills/<nom-du-skill>
# colle SKILL.md (et les scripts si y'en a) dans ce dossier
```

Pour DevBrain, les skills custom sont déjà dans `AI/skills/` du repo — l'agent les trouve automatiquement quand `claude` est lancé depuis la racine du vault.

### Test rapide
```bash
claude
> Liste-moi les skills disponibles.
```

---

## 2. Obsidian skill (`type: obsidian-skill`)

Les skills Obsidian de kepano sont en fait des **prompts/règles** qui apprennent au Claude la syntaxe Obsidian. Ils s'installent comme n'importe quel skill Claude Code :

```bash
npx skills add kepano/obsidian-skills
npx skills add kepano/defuddle
```

Ils sont passifs : ils n'ajoutent pas de commande, ils enrichissent la connaissance de l'agent sur Obsidian (wikilinks, callouts, Bases, frontmatter Templater).

Tu les actives une fois — ils s'appliquent ensuite à toutes tes sessions qui parlent d'Obsidian.

---

## 3. MCP server (`type: mcp-server`)

Un MCP server est un binaire/script qui expose des outils à l'agent via le **Model Context Protocol**. Trois étapes :

```bash
# 1. Ajouter le server à Claude Code
claude mcp add <nom> \
  --command <commande> \
  --args <args> \
  --env CLE=valeur

# 2. Vérifier
claude mcp list
# devrait afficher "<nom>  ✓ Connected"

# 3. Tester depuis une session
claude
> Liste les outils disponibles via le MCP <nom>.
```

Exemples concrets : voir les fiches [[mcp-obsidian]] (utilisé par DevBrain), [[mcp-filesystem]], [[mcp-github]].

> 💡 Le MCP n'est **pas un skill au sens strict** — c'est un compagnon d'agent. Mais on le range ici par commodité (même réflexe : "comment j'installe ce truc").

---

## 4. CLI tool (`type: cli-tool`)

Un outil shell classique : `gh`, `jq`, `ripgrep`, `lazygit`, etc.

Procédure générique :

```bash
# Windows
winget install <nom>           # ou
scoop install <nom>            # ou
choco install <nom>

# macOS
brew install <nom>

# Linux
apt install <nom>              # ou
dnf install <nom>              # selon la distro
```

La fiche skill précise la commande exacte dans `install_cmd`.

---

## Après l'install — toujours mettre à jour la fiche

Quand tu as installé et testé un skill :

1. Passe `status: discovered` → `status: tested` (ou `used` si tu l'as adopté en routine).
2. Mets une note dans `score` (1-5).
3. Date `modified`.
4. Ajoute une ligne dans la section *Exemples d'usage* avec ta vraie commande.

Comme ça la fiche reste vivante et ton historique avec ce skill est traçable.

---

## Désinstaller

```bash
# Claude Code plugin
claude plugin remove <nom>

# MCP server
claude mcp remove <nom>

# CLI tool : apt/brew/winget remove selon le cas
```

Et passe `status: abandoned` dans la fiche (ne supprime pas le fichier — la trace est utile si tu reviens dessus dans 6 mois).
