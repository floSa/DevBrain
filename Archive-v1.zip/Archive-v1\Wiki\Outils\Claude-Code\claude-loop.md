---
galaxie: wiki
nom: loop
type: claude-code-skill
plateforme: claude-code
categorie: skill/dev-flow
sous_categories: [recurring, polling, monitoring]
auteur: Anthropic
source: claude-code natif
source_url: https://docs.claude.com/en/docs/claude-code
install_cmd: 
install_doc: 
licence: 
licence_type: proprietary
domaines: [mlops, ai-eng, data-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, monitoring, polling]
---

# loop

## Pourquoi

Skill **bundled** qui **relance un prompt ou une commande slash à intervalle régulier**. Soit tu donnes l'intervalle (`/loop 5m /babysit-prs`), soit tu laisses le modèle s'auto-paciner.

Cas d'usage MLops/AI : monitorer un long training, polling d'un job CI, vérification périodique d'un état.

## Quand l'utiliser

- "Check le déploiement toutes les 5 min jusqu'à ce qu'il soit live"
- "Vérifie le statut de mon training run toutes les 30s"
- "Tourne `/babysit-prs` en boucle"
- Surveillance ad-hoc sans setup CI/CD lourd

## Quand NE PAS l'utiliser

- Tâche réellement récurrente sur le long terme → utilise plutôt [[claude-schedule|schedule]] (cron)
- Tâche one-shot — pas besoin de loop, demande directement
- Polling à très haute fréquence (<60s) → préfère un script dédié

## Comment l'installer

Natif Claude Code. Invocation : `/loop [interval] [prompt-ou-skill]`.

## Exemples d'usage

```
> /loop 5m vérifie le déploiement de mon API et notifie-moi quand healthy
> /loop /review-prs
> /loop          # mode dynamique : Claude choisit l'intervalle
```

## Pièges connus

- Le loop consomme du contexte/tokens à chaque tick — coût qui s'accumule sur les longues boucles
- Pas adapté à un truc qui doit tourner sur 24h+ — passe à [[claude-schedule|schedule]] (cron-style)

## Liens

- Doc Claude Code : https://docs.claude.com/en/docs/claude-code
- [[claude-schedule|schedule]] (alternative pour les tâches longues / cron)
