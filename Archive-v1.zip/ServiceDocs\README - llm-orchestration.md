# Service — <NOM_DU_SERVICE>

<!--
Template à copier dans <projet>/services/<nom>/README.md.
Référence règle : Rules/Documentation/LLM-Orchestration.md du DevBrain.
-->

## Rôle métier

<À REMPLIR : 2-4 lignes — quelle chaîne / agent LLM ce service implémente.>

Exemple :
> Agent conversationnel RAG : classifie l'intent, fait du retrieval Qdrant si pertinent, génère la réponse via Claude Sonnet, valide via guardrails. Orchestré par LangGraph avec checkpointing Postgres.

## Flux de données — cycle d'une requête

```mermaid
sequenceDiagram
  participant User
  participant API
  participant Classifier
  participant Retriever
  participant Generator
  participant Validator
  
  User->>API: POST /chat (query)
  API->>API: Auth + rate limit
  API->>Classifier: classify_intent(query) [LLM #1]
  alt needs_rag
    Classifier->>Retriever: retrieve(query)
    Retriever-->>Classifier: top-k chunks
  end
  Classifier->>Generator: generate(query, ctx) [LLM #2]
  Generator->>Validator: check guardrails
  Validator-->>API: response
  API-->>User: streamed answer
```

| Étape | Modèle | Provider | Latence cible | Coût/req |
|-------|--------|----------|---------------|----------|
| classify_intent | Claude Haiku | Anthropic | < 500ms | $0.0003 |
| retrieve | bge-m3 | HF local | < 100ms | $0 |
| generate | Claude Sonnet | Anthropic | < 3s | $0.005 |
| validate | guardrails-ai | local | < 50ms | $0 |

## Gestion des prompts (CRITIQUE)

> **Aucun prompt hardcodé dans le code.** Tous extraits dans des fichiers versionnés.

Localisation : `services/<nom>/prompts/`

```
services/<nom>/prompts/
├── system_classify_intent.md         # v1.2.0
├── system_generate_answer.md         # v2.0.1
├── tool_extract_entities.md          # v1.0.0
└── README.md                          # changelog des prompts
```

### Convention de prompt

```yaml
# services/<nom>/prompts/system_classify_intent.md
---
name: system_classify_intent
version: 1.2.0
target_model: claude-haiku-4-5
output_format: json_schema
input_vars: [user_query]
description: Classifie l'intent d'une requête en {rag, direct, tool_use}
test_cases:
  - input: "Comment ça marche ?"
    expected_output: {"intent": "rag"}
---

Tu es un classifier d'intent. Pour la requête utilisateur ci-dessous,
détermine si elle nécessite :
- "rag"        : recherche dans la base documentaire
- "direct"     : réponse directe (small talk, math simple)
- "tool_use"   : appel d'un outil externe

Retourne du JSON strict : {"intent": "rag" | "direct" | "tool_use"}

Requête : {user_query}
```

### Métriques par prompt

| Prompt | Version | Coût moyen | Latence p95 | Taux d'erreur |
|--------|---------|------------|-------------|---------------|
| system_classify_intent | 1.2.0 | $0.0003 | 480ms | 0.5% |
| system_generate_answer | 2.0.1 | $0.005 | 2.8s | 1.2% |

## Graphe d'agents (si LangGraph)

```mermaid
stateDiagram-v2
  [*] --> classify
  classify --> retrieve: needs_rag
  classify --> generate: direct
  retrieve --> generate
  generate --> validate
  validate --> [*]: ok
  validate --> generate: retry (max 1)
  validate --> [*]: blocked
```

### Nœuds (states)

| Nœud | Inputs | Outputs | Description |
|------|--------|---------|-------------|
| `classify` | `query` | `intent` | LLM call #1 |
| `retrieve` | `query` | `chunks: list` | Vector search |
| `generate` | `query, chunks` | `draft_answer` | LLM call #2 |
| `validate` | `draft_answer` | `final_answer | retry_signal` | Guardrails |

### Tools mis à disposition de l'agent

```python
@tool
def search_documents(query: str, top_k: int = 10) -> list[Doc]:
    """Search the knowledge base."""
    ...

@tool
def get_user_profile(user_id: str) -> Profile:
    """Fetch user profile."""
    ...
```

### Persistance d'état

- **Checkpointer** : `<À REMPLIR : memory / SQLite / Postgres / Redis>`
- **TTL des sessions** : `<24h>`
- **Schéma de l'état** : `services/<nom>/state.py`

## Modèles utilisés

| Étape | Modèle primaire | Fallback | Stratégie |
|-------|-----------------|----------|-----------|
| Classification | Claude Haiku | GPT-4.1-mini | Si Anthropic down |
| Embedding | bge-m3 (local) | text-embedding-3-small | Si modèle local indispo |
| Génération | Claude Sonnet | GPT-4.1 | Si Anthropic down |

## Observability

- **Tracing** : `<À REMPLIR : Phoenix Arize / LangSmith / Langfuse>`
- **Standard** : OpenTelemetry (via `openinference-instrumentation-*`)
- **Dashboard** : `<URL>`
- **Métriques tracked** :
  - Latence par étape
  - Tokens consommés (input + output) par requête
  - Coût par requête / par user / par jour
  - Taux d'erreur par étape
  - Cache hit rate (prompt caching)

## Configuration

| Variable | Type | Défaut | Description |
|----------|------|--------|-------------|
| `ANTHROPIC_API_KEY` | `str` | — | API Anthropic (`Field(repr=False)`) |
| `OPENAI_API_KEY` | `str | None` | `None` | Fallback (`Field(repr=False)`) |
| `LLM_TIMEOUT_S` | `int` | `30` | Timeout par appel |
| `LLM_MAX_RETRIES` | `int` | `3` | Retries sur 5xx |
| `PROMPT_CACHE_ENABLED` | `bool` | `true` | Activer prompt caching Anthropic |
| `<À REMPLIR>` |  |  |  |

## Coût mensuel estimé

| Volume | Coût/req | Total/mois |
|--------|----------|------------|
| 100k req x 0.005$ | — | $500 |
| Avec prompt cache (-80%) | — | $100 |

**Alerte budget** configurée à $200/mois.

## Eval pipeline

Voir `tests/eval/` (cf. règle [[Tests]]).

- **Framework** : `<À REMPLIR : Ragas / DeepEval / TruLens>`
- **Métriques minimum** : faithfulness ≥ 0.85, answer_relevancy ≥ 0.80, context_precision ≥ 0.75
- **Run** : nightly + sur PR si changement prompt

## Tests

```bash
# Tests unitaires (mocks LLM)
uv run pytest tests/unit/llm/

# Tests d'intégration (vrais appels API, hors-CI ou avec budget)
uv run pytest tests/integration/test_pipeline.py -m integration

# Eval qualité
uv run pytest tests/eval/test_rag_quality.py
```

## Pièges à anticiper

- **Prompts hardcodés** : interdits
- **`temperature` non fixée** : reproductibilité tests
- **`max_tokens` sous-évalué** : réponses tronquées
- **Pas de timeout** : coûts dérapent
- **Pas de fallback de modèle** : un provider HS = app HS
- **Cache prompt non activé** ([[Anthropic Claude API]]) : -80% de coût loupé

## Liens

- DevBrain : [[<À REMPLIR : LangChain / LangGraph / LlamaIndex>]] · [[Anthropic Claude API]] · [[OpenAI API]]
- Règle : [[LLM-Orchestration]]
- Eval : [[Ragas]] / [[DeepEval]] / [[TruLens]]
- Observability : [[Phoenix Arize]] / [[LangSmith]] / [[Langfuse]]
- Prompts changelog : `services/<nom>/prompts/CHANGELOG.md`
