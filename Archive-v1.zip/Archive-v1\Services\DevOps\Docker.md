---
galaxie: dev
nom: Docker
alias: [docker, docker-engine, docker-compose]
categorie: devops/container
sous_categories: [container, image, compose, oci]
licence: Apache-2.0 (engine) / proprietary (Desktop)
licence_type: open-source
hosted: self
maturite: production
langage: Go
clients_officiels: [cli, python, ts, go]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["Podman", "containerd", "nerdctl", "Buildah"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, devops, container, docker]
url_officiel: https://www.docker.com/
url_docs: https://docs.docker.com/
url_repo: https://github.com/moby/moby
---

# Docker

## Pourquoi
Le standard de fait des containers. **Build** (Dockerfile), **run** (containers), **share** (Docker Hub / registry privés). **Compose** pour les stacks multi-services en local. Standard OCI image format → portable partout (Kubernetes, ECS, etc.).

## Quand l'utiliser
- Quasi tout projet en 2026 (dev, CI, prod)
- Reproductibilité : "ça marche sur ma machine" → Docker
- Stacks locaux multi-services (app + DB + cache) → Docker Compose
- Base image pour le déploiement K8s
- CI : caching de builds, tests isolés

## Quand NE PAS l'utiliser
- Très petit script Python solo → [[uv]] + venv suffit
- Tu veux daemon-less / rootless → Podman
- Edge / fortes contraintes mémoire → solutions plus light (firecracker, etc.)

## Pièges connus
- **Image size** : multi-stage builds + base alpine/distroless pour rester < 200MB
- **`.dockerignore`** : à maintenir comme `.gitignore`, sinon contexte build énorme
- **Layer caching** : ordonner Dockerfile du moins changeant au plus changeant
- **Volumes vs bind mounts** : volumes = managed, bind = mappage filesystem hôte
- **Docker Desktop** : payant pour entreprises > 250 employés, alternatives Podman Desktop / Rancher Desktop
- **`latest` tag** : à éviter en prod, pin versions
- **Healthchecks** : à définir dans Dockerfile/compose
- **Networks** : par défaut bridge, comprendre user-defined networks pour multi-services
- **GPU** : `--gpus all` + nvidia-container-toolkit côté host

## Patterns essentiels

### Multi-stage build Python

```dockerfile
FROM python:3.12-slim AS builder
WORKDIR /app
RUN pip install uv
COPY pyproject.toml uv.lock .
RUN uv sync --frozen --no-dev

FROM python:3.12-slim
WORKDIR /app
COPY --from=builder /app/.venv .venv
COPY src/ src/
ENV PATH="/app/.venv/bin:$PATH"
CMD ["python", "-m", "src.main"]
```

### docker-compose.yml minimal

```yaml
services:
  app:
    build: .
    ports: ["8000:8000"]
    depends_on: [db]
    environment:
      DATABASE_URL: postgresql://user:pass@db:5432/app
  db:
    image: postgres:16-alpine
    volumes: [db-data:/var/lib/postgresql/data]
    environment:
      POSTGRES_PASSWORD: pass
volumes:
  db-data:
```

## Liens
- Podman — alternative rootless / daemon-less
- [[GitHub-Actions]] — CI qui consomme Docker
- [[Postgres]] / [[MinIO]] — services typiques en compose
- Docker Hub : https://hub.docker.com/
- Best practices : https://docs.docker.com/build/building/best-practices/
