---
galaxie: dev
nom: Unstructured
alias: [unstructured, unstructured-io]
categorie: data/document
sous_categories: [pdf, docx, html, extraction, rag, multi-format]
licence: Apache-2.0 (Core), Proprietaire (API/Platform)
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python, api]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Docling]]", "[[Marker]]", "[[LlamaParse]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, document, rag, ingestion]
url_officiel: https://unstructured.io/
url_docs: https://docs.unstructured.io/
url_repo: https://github.com/Unstructured-IO/unstructured
---

# Unstructured

## Pourquoi

Lib Python d'extraction de contenu **structuré** depuis 25+ formats : PDF, DOCX, PPTX, XLSX, HTML, emails (EML/MSG), images (avec OCR), Markdown. Standard de fait pour **ingestion RAG multi-format** : sort des `Element`s typés (`Title`, `NarrativeText`, `ListItem`, `Table`, `Image`, etc.) facilement chunkables et metadata-enriched.

Vs Marker / Docling (PDF spécialisés) : Unstructured est **multi-format** — pratique quand tu ingestes un mix de docs hétérogènes.

## Quand l'utiliser

- **Pipeline RAG sur formats variés** (PDF + DOCX + HTML + emails dans la même ingestion)
- **Extraction structurée** : titres, tables détectées comme éléments séparés
- **Chunking element-aware** : `chunk_by_title()` respecte la structure documentaire
- **Cloud API** (managed) pour scale sans gérer modèles ML local
- **Pipeline ingestion modulaire** : Unstructured a un système de connecteurs (S3, Notion, Confluence, etc.)
- Stack [[LangChain]] / [[LlamaIndex]] : intégration `UnstructuredFileLoader` directe

## Quand NE PAS l'utiliser

- **PDF only avec qualité maximum** → [[Marker]] / [[Docling]] (spécialisés PDF, souvent meilleur sur tables / équations)
- **Stack [[LlamaIndex]] strict** → [[LlamaParse]] intégré
- **Simple : juste texte propre** → `tika-python` / `textract` plus léger
- **Production self-host budget GPU limité** : strategy `hi_res` nécessite GPU pour throughput décent
- **Licence Apache stricte** : OK ! (Core est Apache 2.0). Platform / API = commerciale.

## Pièges connus

- **Performance variable selon `strategy`** :
  - `fast` : PDFMiner pur, rapide mais qualité limitée sur PDFs complexes
  - `hi_res` : YOLOv8 + Tesseract, lent (CPU) mais qualité bien meilleure
  - `ocr_only` : forcer OCR (PDFs scannés)
  - `auto` : décide selon contenu
- **Deps lourdes** : poppler, tesseract, libreoffice (DOCX), nltk data → docker image recommandé
- **API cloud payante** : ~$1-5 par 1000 pages selon plan
- **Versions API breaking** : v0.x rapide, pin version recommandé
- **Mémoire** : `hi_res` strategy charge modèles (~2 GB RAM)
- **Tables → HTML par défaut** : à convertir si tu veux Markdown
- **Elements pas toujours bien typés** : Title vs NarrativeText ambiguous sur PDFs mal layoutés

## Code minimal

```python
# pip install "unstructured[all-docs]"  # tous formats
# pip install "unstructured[pdf]"        # PDF only (plus léger)
from unstructured.partition.auto import partition
from unstructured.chunking.title import chunk_by_title

# Partition (extraction) : marche sur tous formats
elements = partition(filename="document.pdf", strategy="hi_res")

# Inspecter les types d'éléments
for el in elements[:10]:
    print(type(el).__name__, ":", str(el)[:80])
# Title : "Introduction"
# NarrativeText : "Lorem ipsum dolor sit amet..."
# Table : "<table>...</table>"
# ListItem : "First item"

# Chunking smart (respecte structure)
chunks = chunk_by_title(
    elements,
    max_characters=1500,
    new_after_n_chars=1000,
    combine_text_under_n_chars=500,
)

for chunk in chunks[:3]:
    print(chunk.metadata.filename, "::", chunk.metadata.page_number)
    print(chunk.text[:200])
    print("---")

# Avec metadata enrichies pour RAG
for chunk in chunks:
    doc = {
        "content": chunk.text,
        "metadata": {
            "source": chunk.metadata.filename,
            "page": chunk.metadata.page_number,
            "type": type(chunk).__name__,
        }
    }
    # → embed + push to vector DB

# API cloud (sans gérer modèles local)
# import unstructured_client
# client = unstructured_client.UnstructuredClient(api_key_auth="...")
# response = client.general.partition(...)

# Avec LangChain
# from langchain_community.document_loaders import UnstructuredFileLoader
# loader = UnstructuredFileLoader("doc.pdf", mode="elements", strategy="hi_res")
# docs = loader.load()
```

## Liens

- [[Docling]] — alt IBM (PDF strong)
- [[Marker]] — alt ML PDF haute fidélité
- [[LlamaParse]] — cloud LLM-friendly
- [[RAG]] / [[Chunking strategies]] (concepts)
- [[LangChain]] / [[LlamaIndex]] — intégrations natives
- Docs : https://docs.unstructured.io/
- Platform (managed) : https://unstructured.io/platform
- GitHub : https://github.com/Unstructured-IO/unstructured
