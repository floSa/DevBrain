---
galaxie: wiki
nom: Evaluer un modele forecast
type: workflow
categorie: workflow/data-science
sous_categories: [forecasting, eval, time-series, backtest, metrics]
domaines: [data-science, ml-eng, mlops]
duree_estimee: 1-2h pour un setup initial
prerequis: [série temporelle propre, modèle candidat, ~50 points minimum]
created: 2026-05-19
modified: 2026-05-19
tags: [workflow, forecasting, eval, time-series]
---

# Évaluer un modèle de forecast

## Quand l'utiliser

Tu as entraîné un modèle de forecasting ([[Prophet]], [[statsforecast]], [[neuralforecast]], [[darts]]) et tu veux **savoir s'il est meilleur qu'une baseline naïve** et qu'un challenger. Sans ça, tu navigues à vue.

À faire **avant** de mettre en production, et **régulièrement après** (drift detection).

## Pré-requis

- Série temporelle complète, idéalement quelques centaines de points minimum (50 = strict minimum)
- Au moins 2 modèles à comparer (toujours inclure une baseline naïve)
- Horizon de prédiction défini (1 jour, 7 jours, 30 jours, etc.)

## Procédure

### 1. Définir le contexte d'évaluation

Avant tout, fixer :
- **Horizon** $h$ : combien de points à prédire (1, 7, 30, etc.) ?
- **Fréquence** : journalier, hebdo, mensuel ?
- **Une métrique principale** : MAE, RMSE, MASE ou autre selon le métier
- **Métriques secondaires** : 2-3 max, pour cross-check
- **Tolérance acceptable** : à quel niveau l'erreur est-elle acceptable pour le business ?

### 2. Constituer les baselines obligatoires

Sans baseline, ton modèle est imprécis dans l'absolu. Toujours inclure :

| Baseline | Quoi |
|---|---|
| **Naïve** | $\hat y_{t+h} = y_t$ — la dernière valeur reste |
| **Seasonal naïve** | $\hat y_{t+h} = y_{t+h-s}$ — même point l'année/semaine dernière |
| **Moving average** | $\hat y_{t+h} = $ moyenne des $k$ derniers points |
| **Drift** | extrapolation linéaire des deux extrémités |

Ton modèle DOIT battre la naïve. Sinon, soit la série est trop bruitée pour être prévue, soit le modèle est mal calibré.

### 3. Choisir et appliquer le schéma de validation

[[Walk-forward CV]] obligatoire — pas de KFold sur TS.

Configurer :
- **Fenêtre initiale d'entraînement** ($n_0$, typique : 50-200 points selon volume)
- **Pas** ($\Delta$) entre deux origines (1 si possible, plus si trop coûteux)
- **Horizon** $h$ par origine
- **Expanding** ou **sliding** window ?

Exemple avec [[statsforecast]] :
```python
from statsforecast import StatsForecast
from statsforecast.models import AutoARIMA, Naive, SeasonalNaive

models = [
    AutoARIMA(season_length=7),
    Naive(),
    SeasonalNaive(season_length=7),
]
sf = StatsForecast(models=models, freq='D')

cv_df = sf.cross_validation(
    df=df,
    h=7,                  # horizon
    n_windows=20,          # 20 origines d'évaluation
    step_size=1,
)
```

### 4. Calculer les métriques par origine puis agréger

Métriques classiques :

| Métrique | Formule | Quand l'utiliser |
|---|---|---|
| **MAE** | $\frac{1}{n}\sum\|y - \hat y\|$ | échelle de la série, robuste |
| **RMSE** | $\sqrt{\frac{1}{n}\sum(y-\hat y)^2}$ | pénalise gros écarts |
| **MAPE** | $\frac{1}{n}\sum\|y-\hat y\|/\|y\|$ × 100 | **invalide si y peut être 0** |
| **MASE** | MAE / MAE(baseline naïve) | absolu : < 1 = mieux que naïve |
| **sMAPE** | symétrique, voir doc | controversé, alternative MAPE |
| **MSE** | $\frac{1}{n}\sum(y-\hat y)^2$ | dérivable, utile pour optim |

**Toujours rapporter MASE** : c'est la seule métrique qui se lit dans l'absolu ("mon modèle est 30% meilleur que naïve").

Agréger sur les origines : **moyenne** ET **écart-type**. Un modèle peut être bon en moyenne mais très instable.

### 5. Test statistique de différence

Pour décider si modèle A vaut mieux que modèle B (au sens statistique) :

**Diebold-Mariano test** : compare les erreurs des deux modèles, $H_0$ : "même précision".

```python
from scipy import stats
import numpy as np

errors_A = np.abs(forecast_A - actual)
errors_B = np.abs(forecast_B - actual)
diff = errors_A - errors_B

t_stat, p_value = stats.ttest_1samp(diff, 0)
# p < 0.05 → différence significative
```

### 6. Visualiser

Toujours produire :
- Plot **série + forecast** sur la dernière origine
- Plot **distribution des erreurs** par modèle (boxplot)
- Plot **erreur par horizon** (les modèles dégradent souvent avec $h$)
- Plot **erreurs dans le temps** (détecter si erreur augmente = concept drift)

### 7. Documenter dans un fichier d'historique

Versionne un `eval-history.md` ou `.csv` :

```
| Date       | Commit  | Modèle           | MASE | RMSE | MAE | Notes |
|------------|---------|------------------|------|------|-----|-------|
| 2026-05-19 | abc1234 | AutoARIMA        | 0.78 | 24.3 | 18  | baseline |
| 2026-05-20 | def5678 | Prophet          | 0.65 | 21.1 | 16  | + holidays |
| 2026-05-21 | ghi9012 | NHITS            | 0.52 | 17.8 | 14  | DL, GPU 30min |
```

## Checklist de fin

- [ ] Baselines naïve + seasonal naïve testées
- [ ] Au moins 10 origines d'évaluation (idéalement 20+)
- [ ] MASE rapportée (lecture absolue)
- [ ] Moyenne ET écart-type des métriques
- [ ] Test Diebold-Mariano si choix entre 2 modèles serré
- [ ] Plot erreur par horizon + erreur dans le temps
- [ ] Historique versionné

## Pièges courants

- **MAPE sur série avec zéros ou valeurs très petites** → diverge. Utiliser MASE
- **Une seule origine d'évaluation** = pas assez statistique
- **Pas de baseline** : un modèle "qui marche" peut être moins bon qu'une moyenne mobile
- **Comparer Recursive vs Multi-output sans contrôler** ([[Forecasting framing]]) → pommes vs poires
- **Optimiser sur la métrique de validation** sans test out-of-sample final → over-fitting au CV
- **Ignorer l'écart-type** : un modèle avec MASE moyenne 0.5 ± 0.4 est risqué vs 0.6 ± 0.1

## Variantes

- **Forecasting probabiliste** : tu prédis aussi des intervalles → utiliser pinball loss, CRPS au lieu de MAE
- **Hiérarchie de séries** (ventes par produit → catégorie → total) → réconciliation, voir `hierarchicalforecast` (Nixtla)
- **Forecasting en haute fréquence** (intraday) → métriques adaptées (poids différents selon heure)

## Voir aussi

- Concepts : [[Walk-forward CV]], [[Forecasting framing]], [[Stationarity]], [[Autocorrelation]]
- Services : [[Prophet]], [[statsforecast]], [[neuralforecast]], [[darts]], [[statsmodels]]
- Workflows parallèles : [[Evaluer un systeme LLM]] (logique d'éval cousine)
