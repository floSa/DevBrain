---
galaxie: dev
nom: Annoy
alias: [annoy]
categorie: vectordb/ann
sous_categories: [ann, approximate, spotify, trees, read-only, mmap]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production (mature, maintenance modeste)
langage: C++ / Python
clients_officiels: [python, c++, lua, go, rust]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[Faiss]]", "[[hnswlib]]", "[[Qdrant]]", "[[Weaviate]]", "ScaNN"]
remplace: []
remplace_par: ["[[hnswlib]]"]
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, vectordb, ann, python]
url_officiel: https://github.com/spotify/annoy
url_docs: https://github.com/spotify/annoy#readme
url_repo: https://github.com/spotify/annoy
---

# Annoy

## Pourquoi

Library **ANN (Approximate Nearest Neighbors)** par **Spotify**, basée sur des **arbres aléatoires** (random projection forests). Historiquement utilisée pour le système de recommandation musicale Spotify (similar tracks).

Propriété clé : l'index est **read-only après build**, **memory-mapped** (`mmap`) — plusieurs processes peuvent partager le même fichier index sans le charger en RAM, parfait pour des workers serving multi-instance. Aujourd'hui largement supplanté par **HNSW** (hnswlib, Faiss IndexHNSW) qui offre meilleur recall à latence équivalente, mais Annoy reste utilisé pour son **simplicité** et son **modèle mmap** unique.

## Quand l'utiliser

- **Index read-only** : build une fois, query massivement après (recsys offline → serving)
- **Memory-mapped** : multi-process serving sans dupliquer la RAM
- **Catalogue stable** : librairie de chansons / produits / docs immutable
- **Simple à intégrer** : 5 lignes de Python, 1 fichier index
- **Embeddings produits e-commerce** : catalogue stable, lookups rapides
- **Pas besoin de filtering metadata** : juste KNN brut
- **Multi-language** : C++, Python, Go, Lua, Rust, Node

## Quand NE PAS l'utiliser

- **Updates fréquentes** : rebuild complet à chaque add → HNSW (hnswlib, Qdrant) supporte add incrémental
- **Filtering structuré** (where metadata) → vraies vector DBs ([[Qdrant]] / [[Weaviate]] / [[Milvus]])
- **High recall sur low latency** : HNSW typiquement meilleur sur la courbe recall/latency
- **Production moderne** : préférer [[hnswlib]] (HNSW pur) ou [[Faiss]] (multi-algo, GPU)
- **Très haute dimensionnalité** (> 1500) : HNSW scale mieux
- **Maintenance active requise** : Annoy en mode maintenance, releases rares

## Pièges connus

- **Pas d'add après build** : `add_item` puis `build(n_trees)` puis read-only → tout rebuild si nouveaux items
- **n_trees trade-off** : plus d'arbres = meilleur recall, build plus long, fichier plus gros
- **Performance moins bonne que HNSW** : Annoy `recall@10` typiquement 5-10% sous HNSW à même latence
- **Pas de filtering** : si tu as besoin de "KNN parmi items de catégorie X", pas natif
- **Maintenance modeste** : releases rares, Spotify déplace certaines équipes vers Voyager (leur lib successeur)
- **Sérialisation explicite** : `save("index.ann")` + `load("index.ann")` à gérer
- **Vecteurs taille fixe** : déclarer `f = 512` à la création, pas changeable
- **Single-thread query par défaut** : threading possible mais build single-threaded
- **Pas de quantization** : INT8 / PQ pas supporté natif → Faiss mieux pour très gros catalogues
- **Voyager** (Spotify 2023+) — successeur en HNSW : envisager pour nouveaux projets

## Code minimal

```bash
pip install annoy
```

```python
from annoy import AnnoyIndex
import numpy as np

# Build l'index
f = 128                                       # dimension des vecteurs
t = AnnoyIndex(f, metric="angular")           # angular | euclidean | dot | hamming | manhattan

np.random.seed(42)
n_items = 10_000
for i in range(n_items):
    v = np.random.normal(size=f)
    t.add_item(i, v)

t.build(n_trees=50, n_jobs=-1)                # plus de trees = recall meilleur, plus lent
t.save("index.ann")                           # serialise sur disque
```

```python
# Loading + query (process serving, memory-mapped)
from annoy import AnnoyIndex

t = AnnoyIndex(128, metric="angular")
t.load("index.ann")                            # mmap, pas tout charge en RAM

# KNN
query = np.random.normal(size=128)
ids, distances = t.get_nns_by_vector(query, n=10, include_distances=True)
print(list(zip(ids, distances)))

# KNN depuis un item existant (similar items)
similar = t.get_nns_by_item(42, n=10)
print(similar)

# Search avec search_k : plus haut = meilleur recall, plus lent
ids = t.get_nns_by_vector(query, n=10, search_k=10_000)
```

```python
# On-disk build (pour catalogues > RAM)
t = AnnoyIndex(128, "angular")
t.on_disk_build("huge_index.ann")              # build directement sur disque
for i in range(100_000_000):
    t.add_item(i, np.random.normal(size=128).astype("float32"))
t.build(50)
```

```python
# Multi-process serving : mmap partage entre workers
# Process 1
from annoy import AnnoyIndex
t = AnnoyIndex(128, "angular")
t.load("index.ann")     # mmap

# Process 2 (sur la meme machine)
t2 = AnnoyIndex(128, "angular")
t2.load("index.ann")    # partage la meme RAM (pages OS)
```

## Liens

- [[Faiss]] — alternative principale (multi-algo, GPU, quantization)
- [[hnswlib]] — alternative HNSW pur (recall meilleur)
- ScaNN — alternative Google (search optimisée)
- [[Qdrant]] / [[Weaviate]] / [[Milvus]] — vraies vector DBs (avec filtering)
- Voyager — successeur Spotify (HNSW-based) : https://github.com/spotify/voyager
- Benchmarks ann : https://ann-benchmarks.com/
- GitHub : https://github.com/spotify/annoy
