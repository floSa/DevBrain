---
galaxie: dev
nom: Prophet
alias: [fbprophet, facebook-prophet]
categorie: ml/framework
sous_categories: [forecasting, time-series, additive-model, business-friendly]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python, r]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[statsforecast]]", "[[neuralforecast]]", "[[darts]]", "[[statsmodels]]"]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, time-series, forecasting, prophet]
url_officiel: https://facebook.github.io/prophet/
url_docs: https://facebook.github.io/prophet/docs/quick_start.html
url_repo: https://github.com/facebook/prophet
---

# Prophet

## Pourquoi

Forecasting **additive model** créé par Meta : tendance + saisonnalité multiple + effets jours fériés + outliers, ajusté en Stan (bayésien). Conçu pour être **robuste avec peu de tuning**, lisible par des analystes non-stats, gère bien les séries business avec patterns hebdomadaires/annuels et jours fériés.

C'est typiquement le **premier modèle à essayer** sur une nouvelle série quand on n'a pas envie d'apprendre ARIMA et qu'on cherche un baseline raisonnable.

## Quand l'utiliser

- Séries business (ventes, traffic, demande) avec saisonnalité forte + hebdo + annuelle
- Jours fériés / événements à intégrer facilement
- Baseline rapide avant d'investiguer des modèles plus sophistiqués
- Présentation à des stakeholders non-techniques (graphes interprétables avec composantes séparées)

## Quand NE PAS l'utiliser

- Performances brutes sur benchmarks → souvent battu par [[statsforecast]] AutoARIMA et [[neuralforecast]] récents
- Très haute fréquence (intraday) → pas son terrain de jeu
- Séries avec dynamique complexe non-additive (interactions multiplicatives) → modèles ML/DL ou STL+ARIMA
- Volume très grand (> 10M points) → trop lent, Stan ne scale pas

## Pièges connus

- **Le nom "Prophet"** est trompeur : ce n'est pas une prophétie magique, c'est un modèle additif assez classique
- Tendance par défaut : "linéaire" — sur des données très non-linéaires, il faut activer la tendance "logistic" et fournir un cap
- Pas de gestion native de l'auto-régression (lag de la série elle-même) → contrairement à ARIMA, il ne capte pas les patterns "ça augmente parce que ça vient d'augmenter"
- Saisonnalité par défaut = "additive". Pour de la saisonnalité qui croît avec le niveau, passer en "multiplicative"
- **Hyperparams par défaut** sont conservateurs : `changepoint_prior_scale` (par défaut 0.05) à monter pour des séries avec ruptures de tendance

## Liens

- Doc officielle : https://facebook.github.io/prophet/
- Repo : https://github.com/facebook/prophet
- Paper : Taylor & Letham, *Forecasting at Scale* (2018)
- Concepts liés : [[Stationarity]], [[Walk-forward CV]], [[Forecasting framing]]
- Alternatives : [[statsforecast]], [[neuralforecast]], [[darts]]
