---
galaxie: wiki
nom: Value functions
alias: [V function, Q function, advantage, GAE, fonctions de valeur, value estimation]
type: concept
categorie: concept/ml
sous_categories: [rl, value, q-function, advantage, gae, critic]
domaines: [ml-eng, ai-eng]
maturite: established
auteurs_cles: [Bellman, Watkins, Schulman 2016 (GAE)]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, rl, value]
---

# Value functions

## TL;DR

Trois objets : $V^\pi(s)$ (valeur d'un état sous $\pi$), $Q^\pi(s, a)$ (valeur d'une paire état-action), $A^\pi(s, a) = Q^\pi(s, a) - V^\pi(s)$ (advantage, "combien mieux que la moyenne"). Toutes liées par les [[Bellman equations]]. Le **critic** d'un algo actor-critic estime ces fonctions ; le **bootstrapping** TD propage l'info plus vite que Monte Carlo. **GAE** (Generalized Advantage Estimation) interpole entre les deux et est utilisé partout en deep RL (PPO, SAC).

## Le problème

Pour décider quelle action prendre, l'agent a besoin de savoir **à quel point chaque option est bonne**. Deux questions :

1. *"Si je suis cette politique depuis cet état, combien je rapporte ?"* → $V^\pi(s)$
2. *"Si je joue cette action puis suis cette politique, combien je rapporte ?"* → $Q^\pi(s, a)$

La différence $Q - V$ donne **l'avantage** d'une action sur la moyenne. C'est ce signal que les policy gradients aiment exploiter (variance réduite).

## L'idée

### Définitions formelles

**Fonction de valeur d'état** :

$$ V^\pi(s) = \mathbb{E}_\pi \left[\sum_{t=0}^{\infty} \gamma^t r_{t+1} \,\Big|\, s_0 = s \right] $$

**Fonction action-valeur** :

$$ Q^\pi(s, a) = \mathbb{E}_\pi \left[\sum_{t=0}^{\infty} \gamma^t r_{t+1} \,\Big|\, s_0 = s, a_0 = a \right] $$

**Lien V-Q** :

$$ V^\pi(s) = \sum_a \pi(a|s) \, Q^\pi(s, a) = \mathbb{E}_{a \sim \pi(\cdot|s)} [Q^\pi(s, a)] $$

**Avantage** :

$$ A^\pi(s, a) = Q^\pi(s, a) - V^\pi(s) $$

$A^\pi > 0$ : l'action $a$ est meilleure que la moyenne sous $\pi$ ; $A^\pi < 0$ : pire. **Par construction $\mathbb{E}_{a \sim \pi}[A^\pi(s, a)] = 0$**.

### Comment estimer V et Q ?

#### 1. Monte Carlo (sans bootstrap)

Échantillonne un épisode complet jusqu'à terminal, calcule le retour réel $G_t$, met à jour :

$$ V(s_t) \leftarrow V(s_t) + \alpha (G_t - V(s_t)) $$

**Pros** : non biaisé, simple. **Cons** : variance énorme (épisodes longs), pas applicable en continu sans cut-off.

#### 2. Temporal Difference (TD-0, bootstrap)

Utilise une estimation de $V$ comme cible :

$$ V(s_t) \leftarrow V(s_t) + \alpha \big[ \underbrace{r_{t+1} + \gamma V(s_{t+1})}_{\text{TD target}} - V(s_t) \big] $$

**Pros** : variance plus faible, propage l'info pas à pas, online. **Cons** : biaisé si $V$ pas convergé (bootstrap sur soi-même).

#### 3. n-step TD

Compromis : utiliser n récompenses réelles puis bootstrapper :

$$ G_t^{(n)} = r_{t+1} + \gamma r_{t+2} + \dots + \gamma^{n-1} r_{t+n} + \gamma^n V(s_{t+n}) $$

$n = 1$ → TD-0, $n = \infty$ → Monte Carlo.

#### 4. TD(λ) et eligibility traces

Moyenne pondérée géométrique de toutes les n-step :

$$ G_t^\lambda = (1 - \lambda) \sum_{n=1}^{\infty} \lambda^{n-1} G_t^{(n)} $$

$\lambda = 0$ → TD-0, $\lambda = 1$ → Monte Carlo. Tune le trade-off biais-variance.

### GAE — Generalized Advantage Estimation (Schulman 2016)

Pour estimer **l'avantage** dans un policy gradient, on construit le TD residual :

$$ \delta_t = r_{t+1} + \gamma V(s_{t+1}) - V(s_t) $$

Puis on somme avec un facteur $\lambda$ :

$$ \hat A_t^{GAE(\gamma, \lambda)} = \sum_{l=0}^{\infty} (\gamma \lambda)^l \delta_{t+l} $$

- $\lambda = 0$ : $\hat A_t = \delta_t$ (one-step, faible variance, biaisé)
- $\lambda = 1$ : $\hat A_t = G_t - V(s_t)$ (Monte Carlo, sans biais, variance haute)
- **$\lambda = 0.95$** : compromis standard, utilisé par **PPO**

GAE est l'estimateur d'avantage par défaut dans tout le deep RL moderne.

### Le critic dans actor-critic

Dans A2C/PPO/SAC :
- **Actor** $\pi_\theta(a | s)$ : la politique, optimisée par policy gradient — voir [[Policy gradient]]
- **Critic** $V_\phi(s)$ : estime $V^\pi$, fournit la baseline pour calculer l'avantage

Le critic est entraîné par régression sur les retours :

$$ \mathcal{L}_{\text{critic}}(\phi) = \mathbb{E} \big[ (V_\phi(s_t) - V_t^{\text{target}})^2 \big] $$

avec $V_t^{\text{target}}$ qui peut être $G_t$, $r + \gamma V_\phi(s')$, ou un GAE return.

### Q-learning vs SARSA (différence subtile mais importante)

- **SARSA** (on-policy) : cible = $r + \gamma Q(s', \pmb{a'})$ où $a' \sim \pi$
- **Q-learning** (off-policy) : cible = $r + \gamma \max_{a'} Q(s', a')$

Q-learning estime $Q^*$ (politique optimale gloutonne) même si l'agent explore. SARSA estime $Q^\pi$ (la politique courante, ε-greedy). Sur le *cliff-walking* classique de S&B, SARSA prend une route sûre, Q-learning prend la route optimale risquée — comportements différents.

### Double Q-learning (mitigation de l'overestimation)

$\max_a Q(s', a)$ surestime systématiquement en présence de bruit (inégalité de Jensen). Solution : deux Q nets, l'un sélectionne l'action, l'autre l'évalue :

$$ \text{target} = r + \gamma \, Q_B\!\left(s', \arg\max_{a'} Q_A(s', a')\right) $$

Utilisé dans Double DQN, TD3, SAC.

### Target network

Dans DQN, la cible $r + \gamma \max_{a'} Q(s', a')$ bouge à chaque pas (Q s'auto-référence). On gèle une copie $Q_{\text{target}}$ qu'on met à jour rarement (toutes les N steps, ou en moyenne mobile $\tau$-Polyak). Stabilise.

### Décomposition de l'avantage : dueling networks

Architecture qui sépare explicitement V et A dans le réseau :

$$ Q(s, a) = V(s) + A(s, a) - \frac{1}{|\mathcal{A}|} \sum_{a'} A(s, a') $$

Dueling DQN. Aide quand beaucoup d'actions ont la même valeur.

## Quand c'est utile

- **Lire un papier RL** : tout est exprimé en termes de V, Q, A, GAE
- **Choisir entre value-based et policy-based** : Q-learning vs PPO selon le problème
- **Régler $\lambda$ et $\gamma$ dans PPO/SAC** : impact direct sur biais-variance
- **Diagnostiquer une instabilité** : variance des avantages, divergence du critic, overestimation
- **Comprendre le critic dans RLHF** : la value head du PPO RLHF estime $V^\pi$
- **Estimer un baseline en MAB / bandit contextual** : régression sur la valeur attendue

## Quand ça ne marche pas / pièges

- **Variance Monte Carlo** : sur épisodes longs, $G_t$ a une variance massive → toujours préférer TD/GAE
- **Biais TD** : si $V$ initial est mauvais, propage longtemps avant correction
- **Function approximation + bootstrapping + off-policy = deadly triad** : peut diverger (voir [[Bellman equations]])
- **Overestimation par $\max$** : surestimation systématique → Double Q
- **Critic mal entraîné** : si $V_\phi$ est faux, l'avantage GAE est faux, le policy gradient pointe au mauvais endroit
- **Reward scaling** : magnitude des récompenses → magnitude de V → instabilité gradient. Normaliser ou clipper
- **Discount γ très proche de 1** : V devient énorme, gradients instables ; γ très petit = vue très court-terme
- **Confusion V vs Q dans le code** : grep `value_net` et vérifier ce qu'il prend en entrée (état seul = V, état+action = Q)
- **Confondre "logits du critic" avec "avantage"** : le critic sort V, l'avantage se calcule après avec les rewards

## Code minimal

```python
# Estimation Monte Carlo de V^π (tabular)
import numpy as np
from collections import defaultdict

V = defaultdict(float)
counts = defaultdict(int)
gamma = 0.99

for episode in episodes:                       # liste de (s, a, r) tuples
    G = 0.0
    for s, a, r in reversed(episode):
        G = r + gamma * G                       # retour cumulé arrière
        counts[s] += 1
        V[s] += (G - V[s]) / counts[s]          # moyenne incrémentale
```

```python
# TD(0) — update online
def td_update(V, s, r, s_next, done, alpha=0.1, gamma=0.99):
    target = r if done else r + gamma * V[s_next]
    V[s] += alpha * (target - V[s])
    return V
```

```python
# GAE pour PPO
import torch

def compute_gae(rewards, values, dones, gamma=0.99, lam=0.95):
    """
    rewards, values, dones : tensors (T,)
    values doit inclure V(s_T) en position T (bootstrap final)
    """
    T = rewards.size(0)
    advantages = torch.zeros(T)
    gae = 0.0
    for t in reversed(range(T)):
        delta = rewards[t] + gamma * values[t + 1] * (1.0 - dones[t]) - values[t]
        gae = delta + gamma * lam * (1.0 - dones[t]) * gae
        advantages[t] = gae
    returns = advantages + values[:T]            # cible pour le critic
    return advantages, returns
```

```python
# Critic loss + advantage normalisation (PPO style)
import torch.nn.functional as F

advantages, returns = compute_gae(rewards, values, dones)
advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

critic_loss = F.mse_loss(critic(states), returns)
# Le policy loss utilise advantages — voir [[Policy gradient]]
```

```python
# Double DQN target (atténue surestimation)
def double_dqn_target(q_online, q_target, rewards, next_states, dones, gamma=0.99):
    with torch.no_grad():
        next_actions = q_online(next_states).argmax(dim=1, keepdim=True)
        next_q = q_target(next_states).gather(1, next_actions).squeeze(1)
        target = rewards + gamma * next_q * (1.0 - dones.float())
    return target
```

## Pour aller plus loin

- Sutton & Barto, ch. 3 (value functions), 6 (TD), 7 (n-step), 12 (eligibility traces)
- Schulman et al., *High-Dimensional Continuous Control Using Generalized Advantage Estimation* (2016, GAE) — https://arxiv.org/abs/1506.02438
- Mnih et al., *Human-level control through deep reinforcement learning* (DQN, Nature 2015)
- Van Hasselt et al., *Deep Reinforcement Learning with Double Q-learning* (2016)
- Wang et al., *Dueling Network Architectures for Deep Reinforcement Learning* (2016)
- **Liens internes** : [[Bellman equations]], [[Markov Decision Process]], [[Policy gradient]], [[Reinforcement learning]]
