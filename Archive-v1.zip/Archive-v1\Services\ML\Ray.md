---
galaxie: dev
nom: Ray
alias: [ray, raylib]
categorie: ml/distributed
sous_categories: [distributed, parallel, ml-ops, scheduler]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python (C++ core)
clients_officiels: [python, java]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Dask]]", "[[Spark]]", multiprocessing, Modal, Anyscale (managed Ray)]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, distributed, ray]
url_officiel: https://www.ray.io/
url_docs: https://docs.ray.io/
url_repo: https://github.com/ray-project/ray
---

# Ray

## Pourquoi
**Distributed compute framework** général pour Python. Stack ML complet : Ray Core (tasks/actors), Ray Tune (HP search), Ray Train (distributed training), Ray Serve (model serving), Ray Data (data loading). Standard moderne pour ML cluster (OpenAI utilise Ray pour ChatGPT training).

## Quand l'utiliser
- Hyperparameter tuning distribué ([[Ray Tune]]) — voir aussi [[Optuna]]
- Distributed training PyTorch / JAX
- Reinforcement Learning (RLlib)
- Model serving multi-replica ([[Ray Serve]])
- Pipeline ML cluster (data → train → serve)
- Migration de multiprocessing vers cluster

## Quand NE PAS l'utiliser
- Petite scale single-machine → multiprocessing / asyncio
- Big data ETL pur (pas ML) → [[Spark]]
- Single-node DataFrame → [[Polars]]
- Inférence LLM seule → [[vLLM]] direct
- Apps web → [[FastAPI]] + workers Uvicorn

## Pièges connus
- **Memory pinning** : `ray.put()` pour share objets entre workers (zero-copy)
- **Actors** : stateful, ne pas en abuser (préfère stateless tasks quand possible)
- **Cluster setup** : `ray up` configs YAML, ou Kubernetes via KubeRay
- **Versions** : Ray évolue vite, ratés de compat possibles entre Ray Tune et autres libs
- **Dashboard** : utile pour debug, monitor `localhost:8265`
- **Anyscale** (managed) : pratique mais cher, lock-in

## Liens
- [[Ray Tune]] — hyperparameter search
- [[Ray Serve]] (existe déjà ?) — model serving
- [[Dask]] / [[Spark]] — alternatives
- Docs : https://docs.ray.io/en/latest/
- Anyscale (managed) : https://www.anyscale.com/
