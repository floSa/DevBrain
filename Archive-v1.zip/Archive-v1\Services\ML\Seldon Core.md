---
galaxie: dev
nom: Seldon Core
alias: [seldon, seldon-core]
categorie: ml/serving
sous_categories: [serving, kubernetes, cncf, mlops, inference-graphs]
licence: BSL (v2) / Apache-2.0 (v1)
licence_type: source-available
hosted: self
maturite: production
langage: Python / Go
clients_officiels: [python, http, grpc]
plateforme: [linux]
score: 3
mes_projets: []
alternatives: ["[[KServe]]", "[[BentoML]]", "[[Ray Serve]]", "[[NVIDIA Triton]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, serving, kubernetes, mlops]
url_officiel: https://www.seldon.io/
url_docs: https://docs.seldon.io/
url_repo: https://github.com/SeldonIO/seldon-core
---

# Seldon Core

## Pourquoi

Plateforme de **model serving Kubernetes-native**. Multi-framework (sklearn, XGBoost, PyTorch, TensorFlow, ONNX, HuggingFace, MLflow, Triton). Différenciateur clé : **inference graphs** — chaîner plusieurs modèles + transformers + routers + ensembles via une CRD `SeldonDeployment`, avec **A/B testing**, **shadow deployment**, **multi-armed bandit** natifs.

Concurrent direct de **KServe** : Seldon est historiquement plus avancé sur les graphs complexes, KServe (incubation CNCF) est plus simple et plus actif côté communauté. **Seldon v2 (2023+)** = nouvelle architecture (Core 2) plus modulaire, sépare **scheduler** + **pipeline** mais **passe sous licence BSL** (source-available, non-OSI) → conscient avant adoption commerciale.

## Quand l'utiliser

- **Stack Kubernetes existante** : Seldon assume K8s, profite de tout l'écosystème
- **Inference graphs complexes** : A/B test, shadow traffic, ensemble, router, transformer chain
- **Multi-framework hosting** sur un seul cluster
- **CRD-driven** : Seldon Deployment YAML versionné GitOps
- **Monitoring intégré** : Prometheus metrics, Grafana dashboards, distributed tracing
- **Combo Triton backend** : Seldon orchestre, Triton sert les modèles GPU
- **Drift / outlier detection** : Alibi Detect intégration (autre projet Seldon)
- **Explainability** : intégration Alibi pour SHAP / LIME / counterfactuals

## Quand NE PAS l'utiliser

- **Pas de K8s** → [[BentoML]] / [[Ray Serve]] / cloud managed (SageMaker, Vertex)
- **Single model simple** : [[NVIDIA Triton]] / TorchServe / TF Serving plus directs
- **LLM serving** → [[vLLM]] / [[TGI]] / [[SGLang]] dédiés
- **Licence permissive obligatoire** : Seldon Core v2 = BSL (source-available, non-OSI) → vérifier compliance
- **Petite équipe sans plateforme K8s** : Seldon assume une équipe SRE/MLOps en place

## Pièges connus

- **Licence BSL (Seldon Core v2)** : non-OSI, restrictions commerciales (pas de SaaS rebrandé). v1 reste Apache-2.0 mais en mode maintenance
- **Setup K8s lourd** : selon version, Istio / Knative requis (v1), v2 plus léger
- **Apprentissage CRDs** : SeldonDeployment v1 vs Model/Pipeline v2 → API différentes
- **Migration v1 → v2 non triviale** : architecture refactorée, doc parfois en retard
- **Cold start** : modèles loaded à la demande peuvent prendre 30s+
- **Resource limits** par défaut serrés : ajuster requests/limits ou OOM
- **Inference graphs debugging dur** : tracing OK mais graphs profonds = casse-tête
- **Multi-cluster** : pas natif, à orchestrer soi-même
- **Documentation v2** parfois en retard sur le code

## Code minimal

```bash
# Install (Helm) - exemple v2
helm install seldon-core-v2-crds seldon-charts/seldon-core-v2-crds -n seldon-mesh --create-namespace
helm install seldon-core-v2 seldon-charts/seldon-core-v2-setup -n seldon-mesh
```

```yaml
# Seldon Core v2 : Model + Pipeline
apiVersion: mlops.seldon.io/v1alpha1
kind: Model
metadata:
  name: iris-rf
  namespace: seldon-mesh
spec:
  storageUri: "gs://seldon-models/scv2/samples/mlserver_1.6.0/iris-sklearn"
  requirements:
    - sklearn
  memory: 100Mi
---
apiVersion: mlops.seldon.io/v1alpha1
kind: Pipeline
metadata:
  name: iris-pipeline
  namespace: seldon-mesh
spec:
  steps:
    - name: iris-rf
  output:
    steps:
      - iris-rf
```

```yaml
# Seldon Core v1 (legacy) : SeldonDeployment avec A/B test
apiVersion: machinelearning.seldon.io/v1
kind: SeldonDeployment
metadata:
  name: iris-ab
spec:
  predictors:
    - name: model-a
      traffic: 70
      graph:
        name: classifier
        implementation: SKLEARN_SERVER
        modelUri: gs://.../model-a
    - name: model-b
      traffic: 30
      graph:
        name: classifier
        implementation: SKLEARN_SERVER
        modelUri: gs://.../model-b
```

```python
# Client : appel HTTP au gateway Seldon
import requests

response = requests.post(
    "http://seldon-mesh.seldon-mesh:8080/v2/models/iris-rf/infer",
    json={
        "inputs": [{
            "name": "predict", "shape": [1, 4], "datatype": "FP32",
            "data": [[5.1, 3.5, 1.4, 0.2]],
        }],
    },
)
print(response.json())
```

## Liens

- [[KServe]] — alternative CNCF, plus simple et actif
- [[BentoML]] / [[Ray Serve]] — alternatives non-K8s natifs
- [[NVIDIA Triton]] — backend GPU often combined
- Alibi / Alibi Detect — projets Seldon pour explainability / drift detection
- MLServer — backend Seldon (runtime modèle multi-framework)
- Docs : https://docs.seldon.io/
- GitHub : https://github.com/SeldonIO/seldon-core
