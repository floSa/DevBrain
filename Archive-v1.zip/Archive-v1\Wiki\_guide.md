---
galaxie: wiki
type: wiki-guide
created: 2026-05-19
modified: 2026-05-19
tags: [wiki, skills, guide]
---

# Outils — c'est quoi, à quoi ça sert

> Page d'index du pilier *Wiki/Outils*. Pour la procédure d'installation détaillée → [[_installer-un-skill]].

## Définition

Un **skill** est un bout de comportement réutilisable qu'on greffe à un agent (Claude Code, Claude Desktop, Codex…) ou à un outil (Obsidian, l'éditeur, le shell). Concrètement c'est :

- un dossier (ou un repo) contenant un `SKILL.md` + parfois du code,
- chargé par l'agent à la demande, qui suit ses instructions pour la durée d'une tâche.

C'est l'unité atomique de la spécialisation : au lieu de re-prompt à chaque fois "lis les .xlsx avec openpyxl en respectant ces conventions", tu installes `anthropic-skills:xlsx` une fois et l'agent applique le bon comportement quand le contexte le déclenche.

## Les 4 familles à connaître

| Famille | Plateforme | Format | Exemple |
|---|---|---|---|
| **Claude Code skill** | `claude` CLI | dossier dans `~/.claude/skills/` ou plugin marketplace | `anthropic-skills:xlsx`, `claude-api`, `review` |
| **Obsidian skill** *(kepano)* | Obsidian | repo `kepano/obsidian-skills` | wikilinks, callouts, Bases, Canvas |
| **MCP server** | tout agent compatible MCP | binaire/script qui parle le protocole MCP | `mcp-obsidian`, `mcp-filesystem`, `mcp-github` |
| **CLI tool** | shell | binaire système | `gh`, `jq`, `ripgrep`, `lazygit` |

> ⚠️ On les regroupe ici sous le mot "skill" par commodité (c'est l'idée commune : *bout greffable*), mais techniquement seuls les deux premiers sont des "skills" au sens strict d'Anthropic / kepano. Les MCP et CLI sont des compagnons d'agent — on les classe ici parce que c'est le même réflexe : "j'ai vu un truc cool, je veux pouvoir le retrouver et savoir comment l'installer".

## Comment c'est rangé dans le brain

```
Wiki/
├── _guide.md                          ← cette page (skills)
├── _installer-un-skill.md             ← procédure d'install par famille
├── Outils/                            ← MA BOÎTE À OUTILS
│   ├── Claude-Code/
│   ├── Obsidian/
│   ├── MCP-Servers/
│   └── CLI-Tools/
├── Concepts/                          ← MES NOTIONS À RETROUVER VITE
│   ├── RAG.md
│   ├── prompt-caching.md
│   ├── mcp-protocol.md
│   └── embeddings.md
├── Workflows/                         ← MES PROCÉDURES STEP-BY-STEP
│   └── (en construction)
└── Comparatif - Outils.base           ← vue tableau filtrée
```

**Trois axes complémentaires** :
- **Outils/** — "comment j'installe et utilise ce truc"
- **Concepts/** — "qu'est-ce que c'est et quand ça sert" (notions)
- **Workflows/** — "comment j'enchaîne ces trucs ensemble" (procédures)

Une fiche skill = un fichier markdown avec frontmatter dense (cf. [[Wiki-Outil]]). Champs notables :

- `status: discovered | tested | used | abandoned` — ton historique avec ce skill
- `score: 1-5` — ta note après usage réel (vide si pas encore testé)
- `domaines: [data-science, mlops, ai-eng, ...]` — où il te sert
- `install_cmd` — pour copier-coller direct

C'est requêtable via Bases : "skills testés score≥4 pour MLops", "skills découverts non-encore-testés", etc.

## Workflow d'enrichissement

Tu peux ajouter un skill au wiki de 3 façons :

1. **À la main** : ouvre Templater (`Ctrl+P → Templater: Create new note from template`), choisis `Wiki-Skill`, remplis.
2. **Via Claude (en mode build)** : "ajoute le skill XYZ que je viens de voir ici : <url ou nom>". L'agent crée la fiche en respectant le template.
3. **Inbox** : pose un lien brut dans `Inbox/`, dis "traite mon inbox", il rangera et créera la fiche.

## Ce que le mode build/projet ignore par défaut

- **Mode build** : peut lire `Wiki/` mais n'écrit que sur demande explicite.
- **Mode project** : ignore `Wiki/` complètement — pas pertinent quand on bosse sur un projet client.

Règles exactes dans [[CLAUDE]] / [[CLAUDE-build]].
