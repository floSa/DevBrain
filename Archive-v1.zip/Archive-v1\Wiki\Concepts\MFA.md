---
galaxie: wiki
nom: Multiple Factor Analysis (MFA)
alias: [MFA, AFM, Analyse Factorielle Multiple]
type: concept
categorie: concept/stats
sous_categories: [factor-analysis, multi-table, groups, mixed-data]
domaines: [data-science]
maturite: established
auteurs_cles: [Escofier & Pagès 1990, Pagès 2014]
lecture_min: 10
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, mfa, factor-analysis, multi-block]
---

# Multiple Factor Analysis (MFA)

## TL;DR

Analyse factorielle pour des données structurées en **groupes de variables** (ex. plusieurs blocs de mesures sur les mêmes individus). Équilibre l'influence de chaque groupe pour que **aucun ne domine la PCA globale**, puis fait une analyse factorielle commune. C'est la méthode pour traiter des données *multi-tableaux* avec individus communs.

## Le problème

On a $K$ groupes de variables sur les mêmes $n$ individus :

$$ X = [X_1 \mid X_2 \mid \dots \mid X_K] $$

avec $X_k$ comportant $p_k$ variables (continues ou catégorielles, mais on parle ici du cas continu). Faire une PCA brute sur la concaténation $X$ pose problème :

- Un groupe **avec plus de variables** ou **avec une forte variance** *écrase* les autres.
- On veut un compromis : chaque groupe contribue de manière équilibrée.

Cas typique : analyse sensorielle (jury × descripteurs), où chaque jury évalue les mêmes produits sur ses propres critères.

## L'idée

### Étape 1 — PCA séparée par groupe

Pour chaque groupe $X_k$, faire une PCA et noter la première valeur propre $\lambda_1^{(k)}$.

### Étape 2 — Pondération

Diviser chaque groupe par sa première valeur propre :

$$ X_k^{\text{pondéré}} = \frac{X_k}{\sqrt{\lambda_1^{(k)}}} $$

Cela rend chaque groupe **comparable** : la variance de la première composante est maintenant 1 dans tous les groupes.

### Étape 3 — PCA globale

Concaténer les groupes pondérés et appliquer une PCA standard :

$$ X^{\text{global}} = [X_1^{\text{pondéré}} \mid \dots \mid X_K^{\text{pondéré}}] $$

Les composantes principales du tableau global = **compromis** entre les structures de chaque groupe.

### Étape 4 — Représentations spécifiques

MFA fournit plusieurs sorties :

- **Individus dans l'espace global** (compromis tous groupes)
- **Individus partiels** : projection vue par chaque groupe → trajectoire des individus selon les groupes
- **Variables** dans le plan factoriel
- **Groupes** comme entités : coordonnées du groupe dans l'espace global, contributions

### Mesure de la cohérence inter-groupes : RV

Le **coefficient RV** entre groupes $k$ et $l$ mesure leur similarité globale :

$$ RV(X_k, X_l) = \frac{\mathrm{Tr}(W_k W_l)}{\sqrt{\mathrm{Tr}(W_k^2) \mathrm{Tr}(W_l^2)}}, \quad W_k = X_k X_k^\top $$

$RV \in [0,1]$ : 0 = groupes orthogonaux, 1 = identiques. Permet de détecter les groupes redondants ou aberrants.

### Variante : MFA pour groupes mixtes

Si un groupe contient des variables catégorielles, on applique une MCA (pondérée par sa première valeur propre) au lieu d'une PCA. Idem pour groupes mixtes : FAMD locale.

## Quand c'est utile

- **Analyse sensorielle** : plusieurs juges, mêmes produits
- **Multi-omics** : transcriptome + protéome + métabolome sur mêmes patients
- **Évaluations multi-critères** : plusieurs blocs de notes sur mêmes individus
- **Données longitudinales** organisées par temps (chaque temps = un groupe)
- Quand tu hésites à concaténer naïvement plusieurs tables

## Quand ça ne marche pas / pièges

- **Groupes très déséquilibrés en taille** ($p_1 = 50$, $p_2 = 2$) → la pondération MFA limite mais ne supprime pas le déséquilibre
- **Trop de groupes** (>10) → plan groupes illisible
- **Groupes hautement corrélés** → on regarde si certains font redondance (RV proche de 1)
- **Confusion avec STATIS** : STATIS donne plus de poids aux groupes "consensus", MFA équilibre. À choisir selon objectif.
- **Variables supplémentaires** : un groupe entier peut être déclaré supplémentaire (illustré sur les axes mais ne contribuant pas à leur définition).

## Code minimal

```python
import prince

# groups : dict {'group_name': [list of column names]}
groups = {
    'sensoriel':  ['fruité', 'acide', 'amer'],
    'chimique':   ['pH', 'sucre', 'tanin'],
    'consommateur': ['note_globale', 'achat_intention'],
}

mfa = prince.MFA(n_components=2, n_iter=10).fit(df, groups=groups)

mfa.plot(df, groups=groups)
print(mfa.eigenvalues_summary)
print(mfa.group_contributions_)
```

## Implémentations concrètes

- [[prince]] — `prince.MFA`
- R : `FactoMineR::MFA` (référence académique, plus de variantes)
- `MOFA+` (Multi-Omics Factor Analysis) — alternative bayésienne, généralisation MFA

## Pour aller plus loin

- Pagès, *Multiple Factor Analysis by Example Using R* (2014)
- Husson, Lê, Pagès — *Analyse de données avec R*
- **Liens internes** : [[PCA]] (cas 1 groupe), [[MCA]] (groupes catégoriels), [[FAMD]] (variables mixtes dans un seul groupe), [[GPA]] (alternative pour aligner plusieurs configurations)
