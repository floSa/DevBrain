---
galaxie: wiki
nom: Roadmap DS/ML
type: roadmap
categorie: wiki/roadmap
domaines: [data-science, ml-eng, ai-eng, mlops, data-eng]
created: 2026-05-20
modified: 2026-05-20
tags: [roadmap, ds, ml, reference, checklist]
---

# Roadmap DS/ML — Carte de compétences

> Document de référence — **carte exhaustive** des compétences attendues d'un Data Scientist / ML Engineer expert. Sert de checklist de révision et de boussole pour identifier ce qui est déjà documenté dans le brain vs ce qui reste à creuser.
>
> **Ce n'est pas une page d'apprentissage** : juste les noms d'algos/concepts/outils. Pour la pédagogie, va voir les fiches dédiées dans `Wiki/Concepts/` (chaque fiche explique un concept en profondeur, avec maths LaTeX et code minimal).
>
> **Convention de wikilinks** : au fil du temps, les items déjà documentés en fiche dédiée sont wikilinkés ici (PCA, RAG, Bootstrap, etc.). Pour explorer directement un concept : recherche via `Ctrl+O`.
>
> **Filtrer du graph view** : si le graph devient trop chargé, ajoute `-tag:#roadmap` ou `-path:Wiki/Roadmap` dans tes filtres (cf. `INSTALL.md` §11.5).
>
> **Mise à jour** : ce document s'enrichit au fil de tes apprentissages. Date initiale : 2026-05-20.

---



---

## 1. FONDAMENTAUX

### 1.1 Algèbre linéaire
- Vecteurs & espaces vectoriels
  - Base, dimension, rang
  - Indépendance linéaire
  - Espace nul, espace colonne
- Matrices
  - Opérations (somme, produit, transposée)
  - Inverse, pseudo-inverse (Moore-Penrose)
  - Trace, déterminant
  - Matrices spéciales (symétrique, orthogonale, définie positive, diagonale, triangulaire, creuse)
- Produits
  - Scalaire / dot product
  - Hadamard (élément-par-élément)
  - Kronecker
  - Tensoriel / outer
- Normes
  - L0, L1, L2, L∞
  - Frobenius
  - Nucléaire (somme valeurs singulières)
  - Mahalanobis
- Décompositions
  - SVD (Singular Value Decomposition)
  - Eigendecomposition (valeurs/vecteurs propres)
  - QR
  - LU
  - Cholesky
  - Schur
  - Polar
- Projections
  - Orthogonale
  - Oblique
  - Sur sous-espace
- Tensors
  - Notation Einstein
  - Décomposition CP, Tucker

### 1.2 Calcul différentiel & analyse
- Dérivées
  - Partielles
  - Directionnelles
- Gradient
- Jacobienne
- Hessienne
- Règle de la chaîne
- Différentiation automatique
  - Forward mode
  - Reverse mode (backprop)
- Séries de Taylor
- Convergence
- Intégrales (notions pour proba continues)

### 1.3 Optimisation
- Convexité
  - Fonctions convexes / concaves
  - Ensembles convexes
  - Sous-différentiel
- Conditions d'optimalité
  - KKT (Karush-Kuhn-Tucker)
  - Lagrangien
  - Dualité (forte/faible)
- Méthodes 1er ordre
  - Gradient descent (batch, SGD, mini-batch)
  - Momentum
  - Nesterov accelerated gradient
  - Adagrad
  - RMSprop
  - Adadelta
  - Adam, AdamW, AdaMax, Nadam
  - LARS, LAMB
  - Lion, Sophia
- Méthodes 2nd ordre
  - Newton-Raphson
  - Quasi-Newton (BFGS, L-BFGS)
  - Gauss-Newton
  - Levenberg-Marquardt
  - Natural gradient
- Optimisation contrainte
  - Lagrangien augmenté
  - Méthode de pénalité / barrière
  - Méthode du point intérieur
  - ADMM
  - Projected gradient
- Non-différentiable
  - Sous-gradient
  - Proximal methods
  - Coordinate descent
- Stochastique
  - SGD et variantes
  - Variance reduction (SVRG, SAGA)
- Bayésienne
  - Gaussian Process surrogate
  - Acquisition functions (EI, UCB, PI)
- Méta-heuristiques
  - Recuit simulé
  - Algorithmes génétiques
  - PSO (Particle Swarm Optimization)
  - Differential Evolution
  - CMA-ES
- Optimisation linéaire / convexe
  - Simplex
  - Interior point
- Programmation entière
  - Branch & bound
  - Cutting planes

### 1.4 Probabilités
- Variables aléatoires
  - Discrètes
  - Continues
  - Mixtes
- Distributions discrètes
  - Bernoulli, Binomiale
  - Poisson
  - Géométrique, Binomiale négative
  - Hypergéométrique
  - Multinomiale, Categorical
- Distributions continues
  - Uniforme
  - Normale (univariée, multivariée)
  - Log-normale
  - Exponentielle
  - Gamma, Inverse-Gamma
  - Bêta
  - Dirichlet
  - Student-t
  - Chi²
  - Fisher
  - Weibull, Pareto, Cauchy
  - Laplace
- Moments
  - Espérance, variance
  - Skewness, kurtosis
  - Fonction génératrice des moments
  - Fonction caractéristique
- Théorèmes
  - Loi des grands nombres (faible, forte)
  - Théorème central limite
  - Théorème de Bayes
  - Inégalités (Markov, Chebyshev, Jensen, Hoeffding, Chernoff)
- Conditionnement
  - Probabilité conditionnelle
  - Indépendance
  - Indépendance conditionnelle
- Processus stochastiques
  - Chaînes de Markov (discrètes, continues)
  - Processus de Poisson
  - Brownian motion
  - Processus gaussiens
- MCMC
  - Metropolis-Hastings
  - Gibbs sampling
  - Hamiltonian Monte Carlo (HMC)
  - NUTS
  - Variational inference

### 1.5 Statistiques
- Statistiques descriptives
  - Tendance centrale (moyenne, médiane, mode)
  - Dispersion (variance, écart-type, IQR, MAD)
  - Forme (skewness, kurtosis)
  - Quantiles
- Estimation
  - Estimateurs (biais, variance, MSE, consistance)
  - MLE (Maximum Likelihood Estimation)
  - MAP (Maximum A Posteriori)
  - MoM (Method of Moments)
  - Intervalles de confiance
- Tests d'hypothèses
  - Erreur type I / II
  - Puissance
  - p-value
  - Tests paramétriques
    - t-test (one/two-sample, paired)
    - z-test
    - ANOVA (one-way, two-way, repeated measures)
    - ANCOVA, MANOVA
    - F-test
  - Tests non-paramétriques
    - Mann-Whitney U
    - Wilcoxon signed-rank
    - Kruskal-Wallis
    - Friedman
    - Chi² (independence, goodness-of-fit)
    - Fisher's exact test
    - McNemar
  - Tests de normalité
    - Shapiro-Wilk
    - Kolmogorov-Smirnov
    - Anderson-Darling
    - Jarque-Bera
    - QQ-plot
- Bootstrap & resampling
  - Bootstrap percentile
  - BCa bootstrap
  - Jackknife
  - Permutation tests
- Tests multiples
  - Bonferroni
  - Holm-Bonferroni
  - Benjamini-Hochberg (FDR)
  - Šidák
- Bayésien
  - Priors (informatifs, non-informatifs, conjugués)
  - Posteriors
  - Bayes factors
  - Credible intervals
  - Posterior predictive checks
- A/B testing
  - Sample size calculation
  - Sequential testing
  - Multi-armed bandits
  - CUPED (variance reduction)
- Théorie de la décision
  - Risque bayésien
  - Minimax
  - Utility theory

### 1.6 Théorie de l'information
- Entropie de Shannon
- Entropie conditionnelle
- Entropie jointe
- Entropie croisée
- Divergence KL (Kullback-Leibler)
- Divergence Jensen-Shannon
- Distance de Wasserstein (Earth Mover's)
- Information mutuelle
- Information mutuelle normalisée
- Perplexité
- Coding (Huffman, arithmétique)
- Channel capacity

### 1.7 Théorie de l'apprentissage
- Biais-variance tradeoff
- Erreur d'entraînement vs test
- Risque empirique vs vrai
- Capacité d'un modèle
- VC dimension
- Rademacher complexity
- PAC learning
- PAC-Bayes
- Bornes de généralisation
- No Free Lunch theorem
- Stabilité algorithmique
- Concentration inequalities

---

## 2. PROGRAMMATION & OUTILS

### 2.1 Python
- Core
  - Types built-in (list, dict, set, tuple, frozenset)
  - collections (Counter, defaultdict, OrderedDict, namedtuple, deque)
  - itertools (chain, product, permutations, combinations, groupby)
  - functools (partial, reduce, lru_cache, wraps, singledispatch)
  - operator
  - heapq, bisect
- Avancé
  - Type hints (typing, generics, Protocol, TypeVar)
  - Décorateurs
  - Context managers (with, contextlib)
  - Generators & coroutines
  - Iterators
  - Metaclasses
  - Descriptors
  - Dataclasses, attrs, Pydantic
- Concurrence
  - threading
  - multiprocessing
  - asyncio
  - concurrent.futures
  - GIL (compréhension)
- Performance
  - Cython
  - Numba (JIT)
  - PyPy
  - profiling (cProfile, line_profiler, memory_profiler, py-spy)
- Packaging
  - pip, Poetry, uv, Hatch, PDM
  - setuptools, build
  - PyPI publishing
  - venv, conda

### 2.2 R
- Base R
- tidyverse
  - dplyr
  - ggplot2
  - tidyr
  - purrr
  - readr
  - stringr
  - lubridate
- data.table
- caret
- tidymodels
- Shiny
- R Markdown / Quarto

### 2.3 SQL
- Bases
  - SELECT, WHERE, GROUP BY, HAVING, ORDER BY
  - DISTINCT, LIMIT
- Joins
  - INNER, LEFT, RIGHT, FULL OUTER
  - CROSS, SELF
  - LATERAL / CROSS APPLY
- Sous-requêtes
  - Corrélées, non-corrélées
  - EXISTS, IN, ANY/ALL
- CTE (Common Table Expressions)
  - Récursives
- Window functions
  - ROW_NUMBER, RANK, DENSE_RANK
  - LAG, LEAD
  - SUM/AVG OVER (PARTITION BY ... ORDER BY ...)
  - NTILE
  - FIRST_VALUE, LAST_VALUE
- Pivot / Unpivot / CROSSTAB
- Set operations (UNION, INTERSECT, EXCEPT)
- Optimisation
  - Index (B-tree, hash, GIN, GiST, BRIN)
  - Query plans (EXPLAIN ANALYZE)
  - Partitionnement
  - Statistiques
- Dialectes
  - PostgreSQL
  - MySQL / MariaDB
  - SQL Server (T-SQL)
  - Oracle (PL/SQL)
  - [[BigQuery]]
  - [[Snowflake]]
  - Redshift
  - SQLite
  - DuckDB
  - ClickHouse
  - Spark SQL

### 2.4 Autres langages
- Scala (Spark)
- Julia (calcul scientifique)
- C++ / Rust (performance, bindings)
- Java (Hadoop, Kafka)
- Go (services)
- JavaScript / TypeScript (viz, dashboards)
- Bash / Shell scripting

### 2.5 Manipulation de données
- NumPy
  - ndarray, dtypes
  - Broadcasting
  - Vectorization
  - Fancy indexing
  - Linalg, random, fft
- Pandas
  - Series, DataFrame
  - Indexing (loc, iloc, at, iat)
  - GroupBy (agg, transform, apply, filter)
  - Pivot, melt, stack, unstack
  - Merge, concat, join
  - Time-based indexing & resampling
  - Categorical, sparse types
  - Méthodes string (`.str`), dates (`.dt`)
  - Performance (eval, query)
- Polars (lazy, expressions)
- Dask (out-of-core, distributed)
- Modin
- Vaex
- PyArrow / Parquet / ORC / Feather
- DuckDB (in-process OLAP)
- cuDF (RAPIDS, GPU)

### 2.6 Visualisation
- Matplotlib
  - Figures, axes, subplots
  - Colormaps, styles
  - Animations
- Seaborn (statistical viz)
- Plotly (interactive)
- Bokeh
- Altair (Vega-Lite)
- HoloViews / hvPlot
- Plotnine (ggplot pour Python)
- D3.js
- Outils BI
  - Tableau
  - Power BI
  - Looker
  - Metabase
  - Superset
- Apps & dashboards
  - Streamlit
  - Dash
  - Gradio
  - Panel
  - Voilà

### 2.7 Frameworks ML/DL
- scikit-learn
  - Estimators, Transformers
  - Pipeline, ColumnTransformer
  - FeatureUnion
  - GridSearchCV, RandomizedSearchCV
- Gradient Boosting
  - XGBoost
  - LightGBM
  - CatBoost
  - HistGradientBoosting (sklearn)
- PyTorch
  - Tensors, autograd
  - nn.Module, nn.functional
  - DataLoader, Dataset, Sampler
  - Optimizers, schedulers
  - PyTorch Lightning
  - Ignite
  - torchvision, torchaudio, torchtext
- TensorFlow / Keras
  - tf.data
  - Keras Functional & Sequential API
  - tf.function, autograph
  - TensorFlow Hub
- JAX
  - jit, vmap, pmap, grad
  - Flax
  - Haiku
  - Optax
- Hugging Face
  - Transformers
  - Datasets
  - Tokenizers
  - Accelerate
  - PEFT
  - TRL
  - Diffusers
  - Evaluate
- Inference optimization
  - ONNX, ONNX Runtime
  - TensorRT
  - OpenVINO
  - TorchScript
  - TFLite, Core ML
  - vLLM, TGI (LLMs)

### 2.8 Big Data
- Spark
  - RDD, DataFrame, Dataset
  - Spark SQL
  - MLlib
  - Structured Streaming
  - Catalyst optimizer, Tungsten
  - PySpark
- Hadoop ecosystem
  - HDFS
  - MapReduce
  - YARN
  - Hive
  - HBase
- Streaming
  - Kafka
  - Pulsar
  - [[Flink]]
  - Spark Streaming
  - Apache Beam
- Distributed compute
  - Dask
  - Ray
  - Modin

### 2.9 Cloud
- AWS
  - S3, EC2, Lambda
  - SageMaker
  - EMR, Glue, Athena
  - Redshift
  - Bedrock
- GCP
  - GCS, Compute Engine
  - BigQuery
  - Vertex AI
  - Dataflow, Dataproc
  - Pub/Sub
- Azure
  - Blob Storage
  - Azure ML
  - Synapse Analytics
  - Databricks on Azure
- Databricks
- Snowflake
- HuggingFace Inference / Spaces

### 2.10 Versioning & Reproductibilité
- Git
  - Branching, merging, rebasing
  - Workflows (Git Flow, trunk-based)
- Git LFS
- DVC (Data Version Control)
- Experiment tracking
  - MLflow
  - Weights & Biases
  - Neptune.ai
  - Comet ML
  - ClearML
  - Aim
- Config management
  - Hydra
  - OmegaConf
  - YAML / TOML
- Environnements
  - Conda
  - venv
  - virtualenv
  - Poetry, uv, Pipenv
  - Docker
- Seed management (random, numpy, torch, tf)

### 2.11 Dev tools & qualité
- IDE
  - VS Code
  - PyCharm
  - Jupyter / JupyterLab / Notebook
  - Marimo
  - Colab, Kaggle Notebooks
- Linters & formatters
  - ruff
  - black
  - isort
  - flake8
  - pylint
  - mypy
  - pyright
- Testing
  - pytest
  - unittest
  - hypothesis (property-based)
  - mock
  - tox, nox
  - coverage.py
- Pre-commit hooks
- Documentation
  - Sphinx
  - MkDocs
  - Read the Docs
  - Docstrings (Google, NumPy, reST)

---

## 3. DOMAINES & TYPES DE PROBLÈMES ML

### 3.1 Apprentissage supervisé

#### 3.1.1 Régression

##### Algorithmes linéaires
- OLS (Ordinary Least Squares)
- Ridge (L2)
- Lasso (L1)
- ElasticNet (L1 + L2)
- Régression polynomiale
- Régression isotonique
- LARS (Least Angle Regression)
- LARS-Lasso
- OMP (Orthogonal Matching Pursuit)
- Quantile regression
- Huber regression
- Theil-Sen estimator
- RANSAC
- GLM (Generalized Linear Models)
  - Gamma, Tweedie, Poisson regression

##### Algorithmes bayésiens
- Bayesian Ridge
- ARD (Automatic Relevance Determination)
- Gaussian Process Regression
- Bayesian Linear Regression
- BART (Bayesian Additive Regression Trees)

##### Arbres & ensembles
- Decision Tree Regressor
- Random Forest Regressor
- Extra Trees Regressor
- Gradient Boosting Regressor
- XGBoost
- LightGBM
- CatBoost
- NGBoost (probabilistic)

##### Kernel-based
- SVR (Support Vector Regression)
- ν-SVR
- Kernel Ridge Regression

##### Instance-based
- KNN Regressor (uniform, distance-weighted)

##### Neuronaux
- MLP Regressor
- TabNet
- FT-Transformer
- NODE
- SAINT
- TabPFN

##### Métriques
- MAE (Mean Absolute Error)
- MedAE (Median Absolute Error)
- MSE / RMSE
- RMSLE (Root Mean Squared Log Error)
- R², R² ajusté
- MAPE / sMAPE / WAPE
- MASE (Mean Absolute Scaled Error)
- Explained variance
- Max error
- Pinball / Quantile loss
- Huber loss
- Log-cosh loss
- D² scores (Tweedie, pinball, absolute error)

##### Hypothèses & diagnostics (linéaires)
- Linéarité
- Indépendance des résidus (Durbin-Watson)
- Homoscédasticité (Breusch-Pagan, White)
- Normalité résidus (Shapiro, QQ-plot, JB)
- Multicolinéarité (VIF, condition number)
- Endogénéité
- Influence (Cook's distance, leverage)

##### Techniques spécifiques
- Transformations target (log, Box-Cox, Yeo-Johnson, sqrt)
- Robust regression (M-estimators)
- Quantile regression pour intervalles
- Régression isotonique (calibration)
- Conformal prediction (intervalles)

##### Pièges
- Extrapolation hors domaine
- Outliers
- Heteroscedasticity ignorée
- Variables omises / confounders
- Data leakage temporelle

#### 3.1.2 Classification

##### Linéaires
- Régression logistique
  - Binaire
  - Multinomiale (softmax)
  - Ordinale
- LDA (Linear Discriminant Analysis)
- QDA (Quadratic Discriminant Analysis)
- Perceptron
- Passive Aggressive

##### Probabilistes
- Naive Bayes
  - Gaussian NB
  - Multinomial NB
  - Bernoulli NB
  - Complement NB
  - Categorical NB

##### Kernel-based
- SVM
  - Linéaire
  - RBF
  - Polynomial
  - Sigmoid
  - Custom kernels
- ν-SVM

##### Instance-based
- KNN (uniform, distance, ball tree, KD-tree)
- Radius Neighbors

##### Arbres & ensembles
- Decision Tree
- Random Forest
- Extra Trees
- Gradient Boosting (sklearn)
- XGBoost, LightGBM, CatBoost
- AdaBoost
- Stacking (avec méta-learner)
- Blending
- Voting (hard / soft)

##### Neuronaux
- MLP Classifier
- TabNet
- FT-Transformer
- NODE
- SAINT
- TabPFN

##### Stratégies multi-classes
- One-vs-Rest (OvR)
- One-vs-One (OvO)
- Error-Correcting Output Codes (ECOC)

##### Métriques
- Confusion matrix
- Accuracy
- Balanced Accuracy
- Precision, Recall, F1
- F-beta score
- ROC AUC
- PR AUC (Average Precision)
- Log Loss / Cross-entropy
- Matthews Correlation Coefficient (MCC)
- Cohen's Kappa
- Hamming loss
- Top-k accuracy
- Brier score
- Multi-class averaging
  - Macro
  - Micro
  - Weighted
  - Samples (multi-label)

##### Calibration
- Platt scaling
- Isotonic regression
- Temperature scaling
- Beta calibration
- Reliability diagrams
- Expected Calibration Error (ECE)
- Maximum Calibration Error (MCE)

##### Déséquilibre de classes
- Resampling
  - SMOTE
  - SMOTE variants (Borderline, SVM-SMOTE, K-Means SMOTE)
  - ADASYN
  - Random oversampling / undersampling
  - Tomek links
  - Edited Nearest Neighbors (ENN)
  - NearMiss (1, 2, 3)
  - Cluster centroids
- Class weights
- Cost-sensitive learning
- Threshold moving
- Focal loss
- Class-balanced loss
- Anomaly detection framing
- Decision threshold optimization

##### Multi-label
- Binary Relevance
- Classifier Chains
- Label Powerset
- ML-KNN
- BR+, RAkEL

#### 3.1.3 Learning to Rank
- Approches
  - Pointwise (régression sur scores)
  - Pairwise
    - RankNet
    - RankSVM
    - LambdaRank
  - Listwise
    - LambdaMART
    - ListNet
    - ListMLE
    - SoftRank
- Métriques
  - NDCG@k
  - MAP
  - MRR
  - Precision@k, Recall@k
  - ERR (Expected Reciprocal Rank)
- Implémentations
  - XGBoost (rank:pairwise, rank:ndcg)
  - LightGBM (lambdarank)
  - TF-Ranking
  - allRank

### 3.2 Apprentissage non supervisé

#### 3.2.1 Clustering

##### Centroides
- K-Means
- K-Means++
- Mini-Batch K-Means
- K-Medoids (PAM, CLARA, CLARANS)
- K-Modes (catégoriel)
- K-Prototypes (mixte)
- Fuzzy C-Means

##### Hiérarchique
- Agglomératif
  - Single linkage
  - Complete linkage
  - Average linkage
  - Ward linkage
  - Centroid linkage
- Divisif (DIANA)
- BIRCH

##### Densité
- DBSCAN
- HDBSCAN
- OPTICS
- Mean Shift
- DENCLUE

##### Distribution
- GMM (Gaussian Mixture Model)
- Bayesian GMM (Variational)
- Dirichlet Process Mixture

##### Graphes
- Spectral clustering
- Affinity Propagation
- Markov Clustering
- Communautés (Louvain, Leiden, Girvan-Newman)

##### Deep clustering
- Deep Embedded Clustering (DEC)
- IDEC
- SCAN
- DeepCluster

##### Métriques internes
- Silhouette score
- Calinski-Harabasz
- Davies-Bouldin
- Dunn index
- Inertia / WCSS
- Gap statistic

##### Métriques externes
- Adjusted Rand Index (ARI)
- Normalized Mutual Information (NMI)
- Adjusted Mutual Information (AMI)
- Fowlkes-Mallows
- Homogeneity, Completeness, V-measure
- Purity

##### Choix du nombre de clusters
- Elbow method
- Silhouette analysis
- Gap statistic
- BIC / AIC (GMM)

#### 3.2.2 Réduction de dimension

##### Linéaire
- PCA (Principal Component Analysis)
- Kernel PCA
- Sparse PCA
- Incremental PCA
- Probabilistic PCA
- Truncated SVD / LSA
- Factor Analysis
- ICA (Independent Component Analysis)
- NMF (Non-negative Matrix Factorization)
- LDA (Linear Discriminant Analysis - supervisé)
- Random Projections (Gaussian, Sparse)
- CCA (Canonical Correlation Analysis)
- PLS (Partial Least Squares)

##### Non-linéaire / Manifold
- t-SNE
- UMAP
- Isomap
- LLE (Locally Linear Embedding)
- Modified LLE, Hessian LLE
- Laplacian Eigenmaps
- MDS (Multi-Dimensional Scaling, metric & non-metric)
- Diffusion Maps
- TriMap
- PaCMAP
- LargeVis

##### Autoencoders
- Vanilla AE
- Denoising AE
- Sparse AE
- Contractive AE
- VAE (Variational Autoencoder)
- β-VAE
- VQ-VAE

##### Métriques
- Variance expliquée
- Reconstruction error
- Trustworthiness
- Continuity
- Stress (MDS)
- Distance preservation

#### 3.2.3 Détection d'anomalies

##### Statistiques
- Z-score / Modified Z-score
- IQR (Interquartile Range)
- Grubbs test
- Dixon's Q test
- Mahalanobis distance
- Elliptic Envelope

##### Densité
- LOF (Local Outlier Factor)
- COF (Connectivity-based)
- LoOP (Local Outlier Probabilities)
- INFLO

##### Distance
- KNN-based outlier detection
- KNN average distance

##### Isolation
- Isolation Forest
- Extended Isolation Forest
- iNNE
- LODA

##### One-class
- One-Class SVM
- SVDD (Support Vector Data Description)

##### Probabilistes
- GMM (low likelihood)
- HBOS (Histogram-Based)
- ABOD (Angle-Based)

##### Reconstruction
- PCA reconstruction error
- Autoencoders
- VAE
- GAN-based (AnoGAN, GANomaly, f-AnoGAN)

##### Deep
- DeepSVDD
- DAGMM
- DROCC

##### Time series anomaly detection
- Twitter AnomalyDetection (S-H-ESD)
- Prophet residuals
- LSTM autoencoder
- Matrix Profile

##### Métriques
- Precision@k, Recall@k
- ROC AUC
- PR AUC
- F1 sur seuil optimal

#### 3.2.4 Règles d'association
- Apriori
- FP-Growth
- ECLAT
- Métriques
  - Support
  - Confidence
  - Lift
  - Conviction
  - Leverage

### 3.3 Semi-supervisé & Self-supervised

#### 3.3.1 Semi-supervisé classique
- Self-training
- Co-training
- Tri-training
- Label propagation
- Label spreading
- Pseudo-labeling
- Transductive SVM
- Generative models (GMM + EM)

#### 3.3.2 Semi-supervisé deep
- Consistency regularization
  - Π-Model
  - Temporal Ensembling
  - Mean Teacher
  - Virtual Adversarial Training (VAT)
- MixMatch
- ReMixMatch
- FixMatch
- FlexMatch
- UDA (Unsupervised Data Augmentation)
- Noisy Student

#### 3.3.3 Self-supervised - vision
- Pretext tasks
  - Rotation prediction
  - Jigsaw
  - Colorization
  - Inpainting
- Contrastive
  - SimCLR
  - MoCo (v1/v2/v3)
  - BYOL
  - SwAV
  - DINO, DINOv2
  - Barlow Twins
  - VICReg
- Masked image modeling
  - MAE (Masked Autoencoder)
  - BEiT
  - SimMIM
  - I-JEPA

#### 3.3.4 Self-supervised - NLP
- Masked Language Modeling (MLM)
- Causal Language Modeling (CLM)
- Next Sentence Prediction
- Permuted Language Modeling (XLNet)
- Replaced Token Detection (ELECTRA)
- Span corruption (T5)

### 3.4 Apprentissage par renforcement

#### Concepts
- MDP (Markov Decision Process)
- POMDP (Partially Observable)
- States, actions, rewards
- Policy (déterministe, stochastique)
- Value function V(s)
- Q-function Q(s,a)
- Advantage A(s,a)
- Bellman equations
- Discount factor γ
- Returns (Monte Carlo, TD, n-step, λ-return)
- On-policy vs off-policy
- Model-based vs model-free
- Exploration vs exploitation
  - ε-greedy
  - Softmax / Boltzmann
  - UCB (Upper Confidence Bound)
  - Thompson sampling
  - Noisy networks

#### Value-based
- Q-learning
- SARSA, Expected SARSA
- DQN
- Double DQN
- Dueling DQN
- Prioritized Experience Replay
- Rainbow DQN
- Distributional RL
  - C51
  - QR-DQN
  - IQN

#### Policy-based
- REINFORCE
- Actor-Critic
- A2C / A3C
- TRPO (Trust Region Policy Optimization)
- PPO (Proximal Policy Optimization)
- Continuous control
  - DDPG (Deep Deterministic Policy Gradient)
  - TD3 (Twin Delayed DDPG)
  - SAC (Soft Actor-Critic)

#### Model-based
- Dyna-Q
- World Models
- MuZero
- AlphaZero
- Dreamer (v1, v2, v3)
- PlaNet

#### Multi-armed bandits
- ε-greedy
- UCB1
- Thompson Sampling
- LinUCB (contextual)
- Contextual bandits

#### RLHF & alignement
- Reward modeling
- PPO-RLHF
- DPO (Direct Preference Optimization)
- IPO, KTO, ORPO
- Constitutional AI / RLAIF

#### Imitation learning
- Behavioral Cloning
- DAgger
- Inverse RL
- GAIL (Generative Adversarial Imitation Learning)
- AIRL

#### Offline RL
- BCQ (Batch-Constrained Q-Learning)
- CQL (Conservative Q-Learning)
- IQL (Implicit Q-Learning)
- Decision Transformer
- Trajectory Transformer

#### Multi-agent RL
- Independent learners
- Centralized training, decentralized execution
- MADDPG
- QMIX
- COMA

### 3.5 NLP (Natural Language Processing)

#### 3.5.1 Préprocessing
- Tokenization
  - Word-level
  - Character-level
  - Subword
    - BPE (Byte-Pair Encoding)
    - WordPiece
    - SentencePiece
    - Unigram
    - Byte-level BPE (GPT-2)
- Normalisation
  - Lowercasing
  - Unicode (NFC, NFD, NFKC, NFKD)
  - Accent stripping
  - Punctuation handling
- Stop words removal
- Stemming
  - Porter
  - Snowball
  - Lancaster
- Lemmatization
- POS tagging
- NER (Named Entity Recognition)
- Dependency parsing
- Constituency parsing
- Coreference resolution
- Sentence segmentation

#### 3.5.2 Représentations
- Bag-of-Words
- TF-IDF
- N-grams (uni, bi, tri, character n-grams)
- LSA / LSI
- LDA (Latent Dirichlet Allocation - topic modeling)
- PLSA
- BM25
- Word embeddings statiques
  - Word2Vec (CBOW, Skip-gram, negative sampling)
  - GloVe
  - FastText (subword embeddings)
- Contextual embeddings
  - ELMo
  - BERT-family
- Sentence embeddings
  - Sentence-BERT (SBERT)
  - Universal Sentence Encoder (USE)
  - SimCSE
  - E5, BGE, GTE
  - InstructOR

#### 3.5.3 Architectures
- N-gram models
- HMM (Hidden Markov Models)
- CRF (Conditional Random Fields)
- RNN, LSTM, GRU, BiLSTM
- Seq2Seq + attention (Bahdanau, Luong)
- Convolutional (TextCNN, ByteNet)
- Transformers
  - Encoder-only
    - BERT
    - RoBERTa
    - ALBERT
    - DistilBERT, TinyBERT
    - DeBERTa (v1/v2/v3)
    - ELECTRA
    - XLNet
    - ERNIE
  - Decoder-only
    - GPT (1, 2, 3, 4)
    - LLaMA (1, 2, 3)
    - Mistral / Mixtral
    - Falcon
    - MPT
    - Phi (1.5, 2, 3)
    - Gemma
    - Qwen
    - Claude
  - Encoder-decoder
    - T5, mT5, FLAN-T5, UL2
    - BART, mBART
    - Pegasus
    - MarianMT
  - Multilingues
    - XLM-R
    - mBERT
    - BLOOM
  - Long-context
    - Longformer
    - BigBird
    - Reformer
    - Performer
    - LongT5
  - Efficient attention
    - Linformer
    - Synthesizer
    - Flash Attention (v1/v2/v3)
    - Mamba / State Space Models

#### 3.5.4 Tâches NLP
- Text classification
  - Sentiment analysis
  - Intent detection
  - Topic classification
  - Spam detection
  - Toxicity / hate speech
- Sequence labeling
  - NER
  - POS
  - Chunking
- Question Answering
  - Extractive (SQuAD-style)
  - Abstractive
  - Open-domain QA
  - Multi-hop QA
  - Conversational QA
- Summarization
  - Extractive (TextRank, LexRank)
  - Abstractive
  - Long-document
  - Query-focused
  - Multi-document
- Translation (NMT)
- Paraphrasing
- Text generation
  - Decoding
    - Greedy
    - Beam search
    - Sampling (top-k, top-p / nucleus, temperature)
    - Contrastive search
    - Speculative decoding
- Dialogue / chatbots
- Semantic Textual Similarity (STS)
- Natural Language Inference (NLI)
- Information Retrieval
  - Sparse (BM25, TF-IDF)
  - Dense (DPR, ANCE)
  - Hybrid
- Information Extraction
  - Relation extraction
  - Event extraction
  - Open IE

#### 3.5.5 LLMs - travail avec
- Fine-tuning
  - Full fine-tuning
  - PEFT (Parameter-Efficient Fine-Tuning)
    - LoRA
    - QLoRA
    - DoRA
    - Adapters
    - Prefix tuning
    - Prompt tuning
    - P-Tuning (v1, v2)
    - IA³
- Prompt engineering
  - Zero-shot
  - Few-shot / in-context learning
  - Chain-of-Thought (CoT)
  - Self-consistency
  - Tree-of-Thought (ToT)
  - Graph-of-Thought
  - ReAct
  - Reflexion
  - Self-refine
- RAG (Retrieval-Augmented Generation)
  - Chunking (fixed, semantic, recursive, agentic)
  - Embedding models
  - Vector stores
    - FAISS
    - Pinecone
    - Weaviate
    - Qdrant
    - Milvus
    - Chroma
    - pgvector
  - Hybrid search (BM25 + dense)
  - Re-ranking (cross-encoders, ColBERT)
  - HyDE (Hypothetical Document Embeddings)
  - Multi-query, query decomposition
  - GraphRAG
  - Self-RAG, CRAG
  - Evaluation (RAGAS, ARES)
- Alignement
  - SFT (Supervised Fine-Tuning)
  - RLHF
  - DPO, IPO, KTO, ORPO, SimPO
  - Constitutional AI
- Quantization
  - GPTQ
  - AWQ
  - GGUF / llama.cpp
  - bitsandbytes (8-bit, 4-bit)
  - SmoothQuant
- Distillation (teacher-student)
- Agents
  - Function calling / tool use
  - ReAct
  - Planning agents
  - Multi-agent (AutoGen, CrewAI)
  - LangChain, LangGraph
  - LlamaIndex
- Serving LLMs
  - vLLM
  - TGI (Text Generation Inference)
  - TensorRT-LLM
  - llama.cpp / Ollama
  - SGLang
  - LMDeploy

#### 3.5.6 Métriques NLP
- Génération
  - BLEU
  - ROUGE (1, 2, L)
  - METEOR
  - CHRF, CHRF++
  - BERTScore
  - BLEURT
  - COMET
  - MoverScore
- Modèles de langue
  - Perplexity
  - Bits-per-character
- Classification : Accuracy, F1
- QA : Exact Match, F1
- Code : Pass@k
- Benchmarks LLM
  - MMLU
  - HellaSwag
  - ARC (Easy / Challenge)
  - TruthfulQA
  - BIG-Bench, BBH
  - GSM8K, MATH
  - HumanEval, MBPP
  - LMSys Arena (Elo)
  - AlpacaEval, MT-Bench

### 3.6 Computer Vision

#### 3.6.1 Préprocessing & augmentation
- Resizing, cropping (center, random, five-crop, ten-crop)
- Normalisation (per-channel mean/std, ImageNet stats)
- Color jitter (brightness, contrast, saturation, hue)
- Géométrique
  - Flip (H/V)
  - Rotation
  - Translation
  - Shear
  - Perspective
  - Elastic transform
- Régularisation visuelle
  - Cutout
  - Random Erasing
  - CutMix
  - MixUp
  - Mosaic (YOLO)
- Auto-augmentation
  - AutoAugment
  - RandAugment
  - TrivialAugment
  - AugMix
- Filtres / classique
  - Gaussian blur
  - Median, Bilateral
  - Sobel, Canny, Laplacian
  - Morphologie (dilatation, érosion, opening, closing)
- Bibliothèques : Albumentations, torchvision.transforms, Kornia, imgaug

#### 3.6.2 Features classiques
- HOG (Histogram of Oriented Gradients)
- SIFT
- SURF
- ORB
- BRIEF, BRISK
- LBP (Local Binary Patterns)
- Haar features
- Bag of Visual Words
- Fisher Vectors
- VLAD

#### 3.6.3 Architectures CNN
- LeNet-5
- AlexNet
- VGG (16, 19)
- GoogLeNet / Inception (v1-v4)
- ResNet (18, 34, 50, 101, 152)
- ResNeXt
- Wide ResNet
- DenseNet
- Xception
- MobileNet (v1, v2, v3)
- ShuffleNet
- EfficientNet (v1, v2)
- RegNet
- ConvNeXt (v1, v2)
- NFNet
- Modules
  - Skip connections
  - Bottleneck
  - Depthwise separable convolution
  - Squeeze-and-Excitation (SE)
  - CBAM (attention)

#### 3.6.4 Architectures Transformer
- ViT (Vision Transformer)
- DeiT
- Swin Transformer (v1, v2)
- BEiT
- MAE (Masked Autoencoders)
- ConvNeXt (hybride)
- CoAtNet
- DINO, DINOv2
- CLIP, OpenCLIP, SigLIP
- Hybrides (MaxViT, MobileViT)

#### 3.6.5 Tâches
- Classification d'images
- Détection d'objets
  - One-stage
    - YOLO (v1 → v10+)
    - SSD
    - RetinaNet (Focal loss)
    - FCOS
    - EfficientDet
  - Two-stage
    - R-CNN
    - Fast R-CNN
    - Faster R-CNN
    - Cascade R-CNN
  - Transformer
    - DETR
    - Deformable DETR
    - DINO (detection)
    - RT-DETR
    - Grounding DINO (open-vocabulary)
- Segmentation
  - Sémantique
    - FCN
    - U-Net (et variantes : Attention U-Net, U-Net++, Swin-UNet)
    - SegNet
    - DeepLab (v1, v2, v3, v3+)
    - PSPNet
    - SegFormer
    - Mask2Former (sem)
  - Instance
    - Mask R-CNN
    - YOLACT
    - SOLO, SOLOv2
  - Panoptique
    - Panoptic FPN
    - Mask2Former
  - Foundation
    - SAM (Segment Anything Model)
    - SAM 2
    - SEEM
- Pose estimation
  - OpenPose
  - HRNet
  - AlphaPose
  - DensePose
  - MediaPipe Pose
- Estimation de profondeur
  - MiDaS
  - DPT
  - ZoeDepth
  - Depth Anything (v1/v2)
- Optical flow
  - FlowNet
  - PWC-Net
  - RAFT
  - GMFlow
- Tracking (MOT)
  - SORT
  - DeepSORT
  - ByteTrack
  - BoT-SORT
  - StrongSORT
  - OC-SORT
- OCR
  - Tesseract
  - PaddleOCR
  - EasyOCR
  - TrOCR
  - DocTR
- Face recognition
  - FaceNet
  - DeepFace
  - ArcFace
  - CosFace
  - SphereFace
- Génération d'images
  - GANs
    - DCGAN
    - WGAN, WGAN-GP
    - Progressive GAN
    - StyleGAN (v1, v2, v3, XL)
    - BigGAN
    - Pix2Pix
    - CycleGAN
    - StarGAN
  - VAEs
  - Flow-based
    - RealNVP
    - Glow
  - Diffusion
    - DDPM
    - DDIM
    - Score-based (NCSN)
    - Latent Diffusion / Stable Diffusion (v1.5, 2, XL, 3)
    - Imagen
    - DALL-E (1, 2, 3)
    - Midjourney
    - ControlNet
    - LoRA pour diffusion
    - Consistency Models
  - Auto-regressive (Parti, DALL-E 1)
- Super-resolution
  - SRCNN
  - SRGAN
  - ESRGAN
  - Real-ESRGAN
  - SwinIR
- Image-to-image
  - Pix2Pix
  - CycleGAN
  - InstructPix2Pix
- Style transfer (Gatys, AdaIN, fast style transfer)
- Multi-modal (vision-language)
  - CLIP, SigLIP
  - BLIP, BLIP-2
  - LLaVA (v1, v1.5, NeXT)
  - Flamingo
  - GPT-4V
  - Qwen-VL
  - InternVL
  - Idefics

#### 3.6.6 Métriques
- Classification : Accuracy, top-k
- IoU (Intersection over Union) / Jaccard
- mAP (mean Average Precision)
  - mAP@0.5
  - mAP@0.5:0.95 (COCO)
- Segmentation
  - mIoU
  - Dice coefficient
  - Pixel accuracy
  - Boundary F1
- Image quality
  - PSNR
  - SSIM, MS-SSIM
  - LPIPS
- Génération
  - FID (Fréchet Inception Distance)
  - Inception Score
  - KID
  - CLIP score
  - HPS (Human Preference Score)
- Tracking
  - MOTA, MOTP
  - IDF1
  - HOTA

### 3.7 Séries temporelles

#### 3.7.1 Concepts
- Stationnarité (forte, faible / covariance)
- Tendance (deterministic, stochastic)
- Saisonnalité (additive, multiplicative)
- Résidus / bruit
- Autocorrélation (ACF)
- Autocorrélation partielle (PACF)
- Bruit blanc
- Marche aléatoire
- Intégration, ordre d'intégration I(d)
- Cointégration
- Causalité de Granger
- Heteroscédasticité conditionnelle

#### 3.7.2 Tests
- Stationnarité
  - ADF (Augmented Dickey-Fuller)
  - KPSS
  - Phillips-Perron
  - Zivot-Andrews (avec break)
- Autocorrélation
  - Ljung-Box
  - Box-Pierce
- Normalité résidus
  - Jarque-Bera
  - Shapiro-Wilk
- Hétéroscédasticité
  - ARCH-LM test
- Saisonnalité
  - QS test
  - Friedman test

#### 3.7.3 Décomposition
- Additive vs multiplicative
- Classical (moving averages)
- STL (Seasonal-Trend with LOESS)
- X-11 / X-12-ARIMA / X-13ARIMA-SEATS
- Hodrick-Prescott filter
- Wavelets
- EMD (Empirical Mode Decomposition)
- SSA (Singular Spectrum Analysis)
- MSTL (Multiple Seasonal-Trend)

#### 3.7.4 Modèles statistiques
- AR(p)
- MA(q)
- ARMA(p,q)
- ARIMA(p,d,q)
- SARIMA(p,d,q)(P,D,Q,s)
- SARIMAX (avec exogènes)
- VAR (Vector AR)
- VARMA, VECM
- Exponential Smoothing
  - Simple (SES)
  - Holt (linear trend)
  - Holt-Winters (avec saisonnalité)
  - ETS (Error-Trend-Seasonal)
- State Space Models
  - Structural Time Series
  - Kalman filter / smoother
- Theta method
- TBATS / BATS
- Prophet
- NeuralProphet
- GARCH, EGARCH, GJR-GARCH (volatilité)

#### 3.7.5 Modèles ML/DL
- Reduction à régression (lags, rolling)
  - Linéaire (avec features de lag)
  - Random Forest
  - Gradient Boosting (XGBoost, LightGBM, CatBoost)
- RNN family
  - RNN
  - LSTM
  - GRU
  - Bidirectional
- Seq2Seq (encoder-decoder)
- WaveNet (dilated convolutions)
- Temporal Convolutional Networks (TCN)
- DeepAR (probabilistic, RNN)
- DeepState (state space + DL)
- Transformer-based
  - Temporal Fusion Transformer (TFT)
  - Informer
  - Autoformer
  - FEDformer
  - PatchTST
  - iTransformer
  - Crossformer
- N-BEATS
- N-HiTS
- TimesNet
- TiDE
- Foundation models
  - TimeGPT
  - Chronos
  - Lag-Llama
  - Moirai
  - TimesFM

#### 3.7.6 Tâches
- Forecasting
  - Univariate / multivariate
  - Single-step / multi-step
  - Stratégies multi-step
    - Direct
    - Recursive
    - DirRec
    - MIMO
  - Point forecasting
  - Probabilistic forecasting (intervalles, quantiles, distribution)
- Anomaly detection
- Classification de séries
- Imputation
- Change point detection (PELT, BOCPD, Binary Segmentation)
- Clustering de séries (DTW, soft-DTW)

#### 3.7.7 Feature engineering
- Lag features (t-1, t-2, ..., t-k)
- Rolling statistics (mean, std, min, max, median, skew, kurtosis)
- Expanding window stats
- Differences (1ère, 2nde, saisonnière)
- Date features
  - Year, month, day, week
  - Day of week, day of year
  - Quarter, semester
  - Is weekend, is holiday
  - Working days
- Cyclical encoding (sin/cos pour heure, jour, mois)
- Fourier features (saisonnalité)
- Wavelet features
- Auto-extraction
  - tsfresh
  - tsfel
  - Catch22

#### 3.7.8 Validation
- Train/test temporel
- Time Series Split (sklearn)
- Expanding window CV
- Rolling / sliding window CV
- Blocked CV
- Walk-forward validation
- Out-of-time

#### 3.7.9 Métriques
- Point forecasts
  - MAE, MSE, RMSE
  - MAPE, sMAPE, WAPE
  - MASE (scale-free)
  - MdAPE
  - ME (Mean Error - bias)
- Probabilistic forecasts
  - Pinball / Quantile loss
  - CRPS (Continuous Ranked Probability Score)
  - Coverage (PI coverage probability)
  - Winkler score / Interval score
  - Log-likelihood
- Ranking
  - SPI (Skill Score)

### 3.8 Systèmes de recommandation

#### Approches
- Collaborative filtering
  - Memory-based
    - User-based KNN
    - Item-based KNN
  - Model-based
    - Matrix Factorization (SVD)
    - SVD++
    - ALS (Alternating Least Squares)
    - NMF
    - Implicit MF (iALS)
    - Factorization Machines (FM)
    - Field-aware FM (FFM)
- Content-based
- Hybrid (linear combination, switching, feature combination)
- Deep learning
  - Neural Collaborative Filtering (NCF)
  - AutoRec
  - Wide & Deep
  - DeepFM, xDeepFM
  - DCN (Deep & Cross Network)
  - DLRM
  - Two-tower models
  - Mixture-of-Experts
- Graph-based
  - PinSage
  - NGCF
  - LightGCN
  - KGAT (Knowledge Graph)
- Sequence / Session-based
  - GRU4Rec
  - SASRec
  - BERT4Rec
  - SR-GNN
- Contextual
  - Contextual bandits (LinUCB)
- Knowledge-graph-based

#### Cold start
- Content features
- Demographic features
- Cross-domain transfer
- Meta-learning
- Hybrid bootstrapping
- Bandits exploration

#### Métriques
- Prédiction de notes
  - RMSE, MAE
- Top-N recommendation
  - Precision@k, Recall@k, F1@k
  - MAP@k
  - MRR
  - NDCG@k
  - HR@k (Hit Rate)
- Au-delà de l'accuracy
  - Coverage (catalog, user)
  - Diversity (intra-list)
  - Novelty
  - Serendipity
  - Personalization
  - Popularity bias
  - Fairness

#### Évaluation
- Offline vs online
- Counterfactual evaluation
- A/B testing
- Interleaving

### 3.9 Graph ML

#### Concepts
- Représentations
  - Adjacency matrix
  - Edge list
  - Adjacency list
  - Sparse formats (COO, CSR)
- Types de graphes
  - Dirigé / non-dirigé
  - Pondéré / non-pondéré
  - Bipartite
  - Multi-graph
  - Hyper-graph
  - Dynamique / temporel
  - Hétérogène
- Mesures de centralité
  - Degree
  - Betweenness
  - Closeness
  - Eigenvector
  - Katz
  - PageRank
  - HITS
- Algorithmes classiques
  - BFS, DFS
  - Plus court chemin (Dijkstra, Bellman-Ford, Floyd-Warshall, A*)
  - MST (Kruskal, Prim)
  - Max flow / min cut
  - Connected components
  - Strongly connected components

#### Embeddings de graphes
- DeepWalk
- Node2Vec
- LINE
- Struc2Vec
- SDNE
- HARP
- Graph2Vec (graphes entiers)

#### GNN
- Spectral
  - Spectral GCN
  - ChebNet
- Spatial
  - GCN (Kipf & Welling)
  - GraphSAGE (mean, max, LSTM aggregators)
  - GAT (Graph Attention Network)
  - GATv2
  - GIN (Graph Isomorphism Network)
  - MPNN (Message Passing NN)
  - APPNP
- Relational
  - R-GCN
  - CompGCN
- Temporal
  - TGN (Temporal Graph Network)
  - TGAT
  - DyRep
- Hétérogène
  - HAN (Heterogeneous Attention)
  - HGT (Heterogeneous Graph Transformer)
  - HetGNN
- Graph Transformers
  - Graphormer
  - GraphGPS
- Pooling
  - Global (sum, mean, max)
  - Hierarchical (DiffPool, SAGPool, TopK)

#### Tâches
- Node classification
- Link prediction
- Graph classification / regression
- Community detection
- Knowledge graph completion
- Graph generation
- Graph alignment / matching

#### Frameworks
- PyTorch Geometric (PyG)
- DGL (Deep Graph Library)
- NetworkX
- igraph
- StellarGraph
- Spektral

### 3.10 Causal inference

#### Cadres
- Potential outcomes (Rubin)
- Structural Causal Models (Pearl)
- DAGs (Directed Acyclic Graphs)
- do-calculus
- Identification, identifiability

#### Concepts
- Treatment, outcome, covariates
- ATE (Average Treatment Effect)
- ATT, ATU
- CATE (Conditional ATE)
- ITE (Individual TE)
- Confounding
- Mediation
- Moderation
- Selection bias
- Collider bias
- Simpson's paradox

#### Méthodes observationnelles
- Propensity Score
  - Matching (1:1, k:1, caliper)
  - Stratification
  - IPW (Inverse Probability Weighting)
  - Doubly Robust estimation
  - TMLE (Targeted Maximum Likelihood)
- Regression adjustment
- Instrumental Variables (IV)
- Regression Discontinuity (sharp, fuzzy)
- Difference-in-Differences (DiD)
- Synthetic Control
- G-methods / G-formula

#### ML pour causal
- Causal Forests
- BART (Bayesian Additive Regression Trees)
- Meta-learners (S-, T-, X-, R-, DR-learners)
- Double/Debiased Machine Learning
- Causal Trees
- Uplift modeling
  - Class Transformation
  - Uplift Random Forest
  - Causal KNN

#### Bibliothèques
- DoWhy
- EconML
- CausalML
- causalnex
- pyAgrum

### 3.11 Survival analysis
- Concepts
  - Censoring (right, left, interval)
  - Truncation
  - Hazard function
  - Survival function
  - Cumulative hazard
- Méthodes non-paramétriques
  - Kaplan-Meier estimator
  - Nelson-Aalen estimator
  - Log-rank test
- Semi-paramétriques
  - Cox Proportional Hazards
  - Stratified Cox
  - Time-varying covariates
- Paramétriques
  - Exponential, Weibull, Log-Normal, Log-Logistic
  - AFT (Accelerated Failure Time)
- ML / Deep
  - Random Survival Forest
  - GBM Survival
  - DeepSurv
  - DeepHit
  - SurvTRACE
- Compétition de risques
- Multi-state models
- Métriques
  - Concordance index (C-index)
  - Time-dependent ROC
  - Brier score
  - IBS (Integrated Brier Score)
  - IPCW

### 3.12 Speech / Audio
- Préprocessing
  - Sampling rate, mono/stereo
  - Spectrogrammes (STFT)
  - Mel-spectrogrammes
  - MFCC (Mel-Frequency Cepstral Coefficients)
  - Filter banks
- Tâches
  - ASR (Automatic Speech Recognition)
  - TTS (Text-to-Speech)
  - Speaker identification / verification
  - Speaker diarization
  - Voice cloning
  - Audio classification (UrbanSound, ESC-50)
  - Music information retrieval
  - Audio source separation
- Architectures
  - DeepSpeech (v1, v2)
  - LAS (Listen, Attend, Spell)
  - Tacotron (1, 2)
  - WaveNet
  - WaveGlow, HiFi-GAN
  - Conformer
  - Wav2Vec 2.0
  - HuBERT
  - Whisper
  - SeamlessM4T
  - Bark, Tortoise, XTTS, Suno
- Métriques
  - WER (Word Error Rate)
  - CER (Character Error Rate)
  - MOS (Mean Opinion Score)
  - PESQ, STOI (qualité)

### 3.13 Tabular Deep Learning
- TabNet
- NODE (Neural Oblivious Decision Ensembles)
- FT-Transformer
- SAINT
- TabTransformer
- AutoInt
- DCN-V2
- DANets
- TabPFN (foundation model petites tables)
- Entity embeddings pour catégorielles

---

## 4. TECHNIQUES TRANSVERSES

### 4.1 Feature engineering

#### 4.1.1 Variables numériques
- Scaling
  - StandardScaler (z-score)
  - MinMaxScaler
  - MaxAbsScaler
  - RobustScaler (median/IQR)
  - Normalizer (L1/L2 norm par sample)
  - PowerTransformer
    - Box-Cox (positives)
    - Yeo-Johnson (toutes valeurs)
  - QuantileTransformer (uniform, normal)
- Binning / Discrétisation
  - Equal-width (uniform)
  - Equal-frequency (quantile)
  - K-means binning
  - Decision tree binning
  - Optimal binning (WOE-based)
- Transformations
  - Log, log1p
  - Sqrt
  - Reciprocal
  - Square
- Polynomial features
- Interactions (multiplicatives)
- Outliers
  - Capping / Winsorization
  - Clipping
  - Removal

#### 4.1.2 Variables catégorielles
- Encodings
  - One-Hot Encoding
  - Dummy encoding
  - Label / Ordinal Encoding
  - Binary Encoding
  - BaseN Encoding
  - Hashing trick (FeatureHasher)
  - Target Encoding / Mean Encoding
    - K-fold target encoding
    - Smoothed target encoding
    - Leave-One-Out
  - CatBoost encoding (ordered)
  - James-Stein Encoding
  - M-estimator Encoding
  - Frequency / Count encoding
  - WOE (Weight of Evidence)
  - Helmert, Sum, Backward Difference, Polynomial (contrasts)
- Embeddings catégoriels (deep)
- Rare categories handling (group as "Other")
- High cardinality treatment

#### 4.1.3 Texte
- (Voir section NLP 3.5.1 et 3.5.2)
- Features simples
  - Longueur (chars, mots)
  - Nombre de stop words
  - Nombre de majuscules
  - Sentiment scores
  - Language detection
  - Lisibilité (Flesch, etc.)

#### 4.1.4 Date & temps
- Composantes
  - Année, mois, jour, semaine, trimestre
  - Day of week, day of year
  - Hour, minute
  - Is weekend, is holiday
  - Is business day
  - Season
- Cyclical encoding (sin/cos pour mois, heure, etc.)
- Time since / time until events
- Durations (entre 2 dates)
- Time-of-day buckets
- Lag/lead features
- Rolling aggregates

#### 4.1.5 Géospatial
- Coordonnées → grids
  - Geohash
  - H3 (Uber)
  - S2 (Google)
  - Quadkey
- Distances
  - Haversine (great circle)
  - Manhattan / Euclidean
  - Travel time / distance (APIs)
- Clustering géographique (DBSCAN sur lat/lon)
- Density features (KDE)
- POI (Points of Interest) features
- Reverse geocoding (pays, ville, code postal)
- Spatial joins

#### 4.1.6 Images / vidéos / audio
- Voir sections CV (3.6) et Speech (3.12)

#### 4.1.7 Sélection de features
- Filter (univarié, statistique)
  - Variance threshold
  - Corrélations (Pearson, Spearman, Kendall)
  - Chi² (catégorielles)
  - ANOVA F-test
  - Mutual Information
  - Information gain
- Wrapper (avec modèle)
  - Recursive Feature Elimination (RFE, RFECV)
  - Sequential Feature Selection (forward, backward, floating)
  - Genetic algorithms
- Embedded (intégré au modèle)
  - L1 (Lasso) regularization
  - Tree-based feature importance
  - SHAP-based selection
- Hybrides
  - Boruta
  - mRMR (minimum Redundancy Maximum Relevance)
  - ReliefF
  - Stability selection
- Permutation importance

#### 4.1.8 Création de features
- Domain knowledge features
- Aggregations (group-by counts, sums, means)
- Ratios, différences
- Polynomial / interaction features
- Cluster-based features
- PCA-based features
- Target-leakage avoidance

### 4.2 Données manquantes

#### Mécanismes (Rubin)
- MCAR (Missing Completely At Random)
- MAR (Missing At Random)
- MNAR (Missing Not At Random)

#### Détection / analyse
- Patterns de missingness
- Test de Little (MCAR)
- Heatmaps de missingness

#### Imputation simple
- Mean
- Median
- Mode
- Constant (0, -1, "Unknown")
- Forward fill / Backward fill
- Linear interpolation
- Spline interpolation

#### Imputation par modèle
- KNN Imputer
- Iterative Imputer (MICE - Multiple Imputation by Chained Equations)
- MissForest
- Datawig (deep)
- SoftImpute
- Matrix completion

#### Multiple imputation
- Multiple imputed datasets → pooling

#### Stratégies complémentaires
- Missing indicator (variable binaire)
- Modèles tolérants au missing (XGBoost, LightGBM, CatBoost)
- Suppression (listwise, pairwise) — quand pertinent

### 4.3 Validation

#### Schémas de split
- Hold-out (train/val/test)
- K-Fold
- Stratified K-Fold
- Repeated K-Fold
- Leave-One-Out (LOO)
- Leave-P-Out (LPO)
- Group K-Fold
- Stratified Group K-Fold
- Time Series Split
- Expanding window
- Rolling window
- Blocked CV
- Nested CV (model selection + assessment)
- Purged & Embargoed CV (finance)

#### Considérations
- Stratification (cibles, groupes)
- Leakage prevention
  - Temporal
  - Group / cluster
  - Feature leakage
- Out-of-distribution validation
- Out-of-time validation
- Train/serve skew

### 4.4 Hyperparameter tuning

#### Recherches naïves
- Grid Search
- Random Search
- Halving variants (Successive Halving)
  - HalvingGridSearchCV
  - HalvingRandomSearchCV

#### Bayesian optimization
- Gaussian Process surrogate (scikit-optimize)
- TPE (Tree-structured Parzen Estimator)
  - Optuna
  - Hyperopt
- SMAC

#### Bandit-based / Multi-fidelity
- Hyperband
- BOHB (Bayesian + Hyperband)
- ASHA (Async Successive Halving)
- PBT (Population-Based Training)

#### Évolutionnaires
- Genetic algorithms (DEAP)
- CMA-ES
- Differential Evolution

#### Multi-objective
- NSGA-II
- Optuna multi-objective

#### Outils
- Optuna
- Ray Tune
- KerasTuner
- Hyperopt
- scikit-optimize
- Ax / BoTorch
- Vizier

#### AutoML
- Auto-sklearn
- TPOT
- H2O AutoML
- AutoGluon
- FLAML
- PyCaret
- Vertex AI AutoML
- SageMaker Autopilot
- AutoKeras
- NAS (Neural Architecture Search)

### 4.5 Régularisation
- L1 (Lasso)
- L2 (Ridge / weight decay)
- ElasticNet
- Group Lasso
- Sparse Group Lasso
- Dropout
  - Standard
  - Spatial / 2D
  - Variational
  - Concrete
  - DropConnect
  - DropPath / Stochastic Depth
- Early stopping
- Data augmentation
- Label smoothing
- Mixup / CutMix
- Weight decay (AdamW)
- Gradient clipping (norm, value)
- Noise injection (input, weights)
- Knowledge distillation (as regularization)
- Maxout
- Batch / Layer normalization (regularization effect)

### 4.6 Ensembles
- Bagging
  - Bootstrap Aggregating
  - Pasting (sans remise)
  - Random Subspaces (features)
  - Random Patches
- Boosting
  - AdaBoost (SAMME, SAMME.R)
  - Gradient Boosting (Friedman)
  - XGBoost
  - LightGBM
  - CatBoost
  - HistGradientBoosting
  - NGBoost (probabilistic)
- Stacking
  - Multi-niveau
  - Out-of-fold predictions
- Blending (sur hold-out)
- Voting
  - Hard voting
  - Soft voting (probabilités)
- Snapshot Ensembles
- Bayesian Model Averaging
- Mixture of Experts

### 4.7 Interprétabilité / XAI

#### Modèles intrinsèquement interprétables
- Linear / logistic regression (coefficients)
- Decision trees
- Rule-based (RuleFit, Skope-rules)
- GAMs (Generalized Additive Models)
- EBM (Explainable Boosting Machine)
- Decision Sets

#### Global (post-hoc)
- Feature importance
  - Gini / Mean Decrease Impurity
  - Permutation importance
  - Drop-column importance
- Partial Dependence Plots (PDP)
- ICE (Individual Conditional Expectation) plots
- ALE (Accumulated Local Effects)
- Functional ANOVA
- Surrogate models (global)
- Sensitivity analysis (Sobol)

#### Local (post-hoc)
- LIME
- SHAP
  - TreeSHAP
  - KernelSHAP
  - DeepSHAP / GradientSHAP
  - LinearSHAP
  - SamplingSHAP
- Anchors
- Counterfactuals
  - Wachter
  - DiCE
  - MACE
- Surrogate models (local)

#### Deep learning spécifique
- Saliency maps
- Grad-CAM, Grad-CAM++, Score-CAM
- Integrated Gradients
- SmoothGrad
- DeepLIFT
- Layer-wise Relevance Propagation (LRP)
- Attention visualization
- Activation maximization
- Concept Activation Vectors (TCAV)
- Probing classifiers
- Feature visualization (Olah et al.)

#### Évaluation des explications
- Fidélité
- Stabilité / robustesse
- Sparsity
- Comprehensibility

### 4.8 Apprentissage incrémental / online
- SGD `partial_fit` (sklearn)
- Hoeffding Trees / VFDT
- Adaptive Random Forest
- River (library)
- Incremental PCA
- Online K-Means
- BERT-like online distillation
- Concept drift detection
  - DDM (Drift Detection Method)
  - EDDM
  - ADWIN
  - Page-Hinkley
  - KSWIN
  - HDDM (A, W)
- Drift adaptation strategies
  - Retraining
  - Ensemble update
  - Weighted training

### 4.9 Transfer / Multi-task / Meta learning

#### Transfer learning
- Feature extraction (freeze backbone)
- Fine-tuning (full, partial)
- Progressive unfreezing
- Discriminative learning rates
- Domain adaptation
  - DANN (Domain Adversarial)
  - CORAL
  - MMD-based
  - ADDA
- Domain generalization

#### Multi-task learning
- Hard parameter sharing
- Soft parameter sharing
- Cross-stitch networks
- MMoE (Multi-gate Mixture-of-Experts)
- PLE (Progressive Layered Extraction)
- Task balancing
  - GradNorm
  - Dynamic Weight Average
  - Uncertainty weighting

#### Meta-learning
- Metric-based
  - Siamese Networks
  - Matching Networks
  - Prototypical Networks
  - Relation Networks
- Optimization-based
  - MAML (Model-Agnostic)
  - Reptile
  - FOMAML
- Model-based
  - SNAIL
  - Memory-Augmented NN

#### Few-shot / Zero-shot
- Prompt-based
- N-way K-shot
- ProtoNet variants
- Zero-shot via embeddings (CLIP, etc.)

### 4.10 Active learning
- Stratégies de sélection
  - Uncertainty sampling
    - Least confident
    - Margin sampling
    - Entropy
  - Query by Committee (QBC)
  - Expected Model Change
  - Expected Error Reduction
  - Density-weighted
  - BALD (Bayesian Active Learning by Disagreement)
  - Core-Set
- Pool-based vs stream-based
- Outils : modAL, ALiPy

### 4.11 Federated Learning (notion)
- Horizontal / vertical FL
- FedAvg, FedProx, FedSGD
- Personalization

### 4.12 Privacy-preserving ML (notion)
- Differential Privacy (DP-SGD)
- Federated learning
- Secure multi-party computation
- Homomorphic encryption
- Synthetic data

---

## 5. DEEP LEARNING (transverse)

### 5.1 Architectures de base
- MLP / Fully Connected
- CNN
  - Convolution (1D, 2D, 3D)
  - Padding (valid, same, causal)
  - Stride
  - Dilated / atrous
  - Depthwise / pointwise / separable
  - Transposed convolution / deconvolution
  - Pooling (max, avg, global, adaptive)
- RNN / LSTM / GRU / BiRNN
- Transformer
  - Self-attention
  - Multi-head attention
  - Cross-attention
  - Positional encoding
    - Sinusoidal
    - Learned
    - Relative (T5, Shaw)
    - RoPE (Rotary)
    - ALiBi
- Autoencoders (et variantes — voir 3.2.2)
- GANs (voir 3.6.5)
- Diffusion models (voir 3.6.5)
- Energy-Based Models
- Normalizing Flows (RealNVP, Glow, MAF, IAF)
- Neural ODEs / Continuous Normalizing Flows
- Capsule Networks
- Mixture of Experts (MoE)
  - Sparse MoE
  - Switch Transformer
  - Mixtral

### 5.2 Composants

#### Activations
- Sigmoid
- Tanh
- ReLU
- Leaky ReLU
- PReLU (Parametric)
- RReLU (Randomized)
- ELU
- SELU
- GELU
- Swish / SiLU
- Mish
- Softplus
- Softmax / log-softmax
- Maxout
- GLU (Gated Linear Unit)
- SwiGLU, GeGLU, ReGLU

#### Normalisations
- Batch Normalization
- Layer Normalization
- Group Normalization
- Instance Normalization
- Local Response Normalization
- Weight Normalization
- Spectral Normalization
- RMSNorm
- Switchable Normalization

#### Loss functions
- Régression
  - MSE / L2
  - MAE / L1
  - Huber
  - Log-Cosh
  - Quantile / Pinball
- Classification
  - Cross-Entropy
  - Binary Cross-Entropy
  - Focal Loss
  - Asymmetric Loss
  - Label Smoothing CE
  - Class-balanced loss
- Métrique / Embedding
  - Contrastive Loss
  - Triplet Loss
  - Quadruplet Loss
  - N-Pair Loss
  - NT-Xent (SimCLR)
  - InfoNCE
  - ArcFace, CosFace, SphereFace
  - Center Loss
  - Lifted Structure Loss
- Distillation
  - KL Divergence
  - Soft targets CE
- Ranking
  - Pairwise hinge
  - ListMLE
  - NDCG-based
- Segmentation
  - Dice loss
  - Tversky loss
  - Focal Tversky
  - Lovász
  - Boundary loss

#### Initializations
- Xavier / Glorot (uniform, normal)
- He / Kaiming (uniform, normal)
- LeCun
- Orthogonal
- Identity
- Truncated Normal

### 5.3 Optimisation de l'entraînement

#### Learning rate schedules
- Step decay
- Exponential decay
- Cosine annealing
- Cosine warm restarts (SGDR)
- Warmup (linear, constant)
- Polynomial decay
- 1cycle / OneCycle (Smith)
- ReduceLROnPlateau
- LR Finder (Cyclical LR)

#### Precision & efficiency
- Mixed precision (FP16, BF16)
- Gradient accumulation
- Gradient checkpointing (activation recomputation)
- TF32 (Ampere+)
- 8-bit optimizers (bitsandbytes)

#### Distributed training
- Data Parallel (DP, DDP)
- Model Parallel
- Pipeline Parallel (GPipe, PipeDream)
- Tensor Parallel (Megatron)
- 3D Parallelism
- ZeRO (Stage 1, 2, 3)
- FSDP (Fully Sharded Data Parallel)
- Sequence parallelism
- Frameworks
  - DeepSpeed
  - FairScale
  - Accelerate
  - Megatron-LM
  - Colossal-AI

### 5.4 Techniques avancées
- Curriculum learning
- Self-distillation
- Knowledge distillation (response, feature, relation)
- Pruning
  - Magnitude pruning
  - Structured (channels, filters, heads)
  - Lottery Ticket Hypothesis
  - SNIP, GraSP
  - Iterative Magnitude Pruning
- Quantization
  - Post-Training Quantization (PTQ)
  - Quantization-Aware Training (QAT)
  - INT8 / INT4 / FP8
  - Dynamic vs static
- Neural Architecture Search
  - DARTS
  - ENAS
  - NASNet
  - EfficientNet (compound scaling)
  - Once-for-All
- Hypernetworks
- Continual / lifelong learning
  - EWC (Elastic Weight Consolidation)
  - LwF (Learning without Forgetting)
  - GEM, A-GEM
  - Experience replay
- Test-time training / adaptation
- Data-centric AI
  - Data Cleaning
  - Cleanlab
  - Snorkel (weak supervision)

### 5.5 Génération & modélisation profonde
- GANs
  - Modes d'entraînement (training tricks)
  - WGAN, WGAN-GP
  - Mode collapse
  - Spectral Normalization
- VAE family
- Diffusion
  - Forward process
  - Reverse process
  - Score matching
  - Classifier-free guidance
- Autoregressive (PixelCNN, ImageGPT)
- Flow-based

### 5.6 Multi-modal
- Fusion strategies
  - Early
  - Late
  - Hybrid
  - Cross-attention
- Aligned embeddings
  - CLIP
  - ALIGN
  - SigLIP
- VLMs (Vision-Language Models)
  - LLaVA, LLaVA-NeXT
  - BLIP-2
  - Flamingo
  - Idefics
  - InternVL
- Audio-Language (AudioCLIP, CLAP)
- Text-Speech-Vision

---

## 6. MLOps & PRODUCTION

### 6.1 Pipeline ML

#### Data engineering
- ETL / ELT patterns
- Data ingestion (batch, streaming, CDC)
- Data lake / warehouse / lakehouse
- Data formats (Parquet, ORC, Avro, Arrow, Delta, Iceberg, Hudi)
- Schema evolution
- Data lineage

#### Feature stores
- Feast
- Tecton
- Hopsworks
- Vertex AI Feature Store
- SageMaker Feature Store
- Databricks Feature Store
- Concepts
  - Online vs offline store
  - Point-in-time correctness
  - Feature views
  - Feature serving

#### Orchestration
- Airflow (DAGs, operators, sensors, XCom)
- Prefect
- Dagster
- Luigi
- Kubeflow Pipelines
- Argo Workflows
- Metaflow
- Flyte
- ZenML

#### Data validation & quality
- Great Expectations
- Pandera
- Pydantic
- TFDV (TensorFlow Data Validation)
- Deequ
- Soda
- Monte Carlo / OpenLineage

### 6.2 Tracking & expérimentation
- MLflow
  - Tracking
  - Projects
  - Models
  - Registry
- Weights & Biases (W&B)
- Neptune.ai
- Comet ML
- ClearML
- Aim
- TensorBoard
- Model registry concepts
  - Versioning
  - Staging (Dev/Staging/Prod)
  - Lineage
  - Approval workflows

### 6.3 Déploiement

#### Patterns
- Batch inference
- Online / real-time serving
- Streaming inference
- Edge / on-device
- Embedded inference
- Hybrid (lambda)

#### Stratégies de release
- Shadow deployment / dark launch
- A/B testing
- Canary release
- Blue-Green deployment
- Multi-armed bandit deployment
- Feature flags / gradual rollout
- Champion-challenger

#### Serving stacks
- TorchServe
- TensorFlow Serving
- Triton Inference Server (NVIDIA)
- BentoML
- Ray Serve
- KServe (KFServing)
- Seldon Core
- FastAPI / Flask / Starlette
- Vertex AI Endpoints
- SageMaker Endpoints
- Azure ML Endpoints
- Hugging Face Inference Endpoints / Spaces
- vLLM, TGI (LLMs)
- Modal, Replicate, RunPod (serverless GPU)

#### Optimisation pour l'inférence
- Format conversion (ONNX)
- Compilation
  - TensorRT
  - OpenVINO
  - TorchScript
  - torch.compile (TorchInductor)
  - XLA (JAX/TF)
- Mobile / edge
  - TFLite
  - Core ML
  - ONNX Runtime Mobile
  - PyTorch Mobile / ExecuTorch
- Quantization, pruning, distillation (voir 5.4)
- Batching
  - Static
  - Dynamic
  - Continuous (vLLM)
- KV cache (LLMs)

### 6.4 Monitoring

#### Service-level
- Latency (p50, p95, p99)
- Throughput (QPS, RPS)
- Error rate
- Availability / uptime
- Saturation (CPU, GPU, mem)

#### Data quality
- Schema validation
- Null rates
- Range checks
- Cardinality
- Duplicates

#### Data drift
- Statistical tests
  - KS test
  - Chi² test
  - Population Stability Index (PSI)
- Distributional distances
  - Wasserstein
  - Jensen-Shannon
  - Energy distance
  - MMD

#### Concept drift
- Performance degradation tracking
- Real label availability
- Proxy metrics

#### Model-specific
- Prediction drift (distribution des outputs)
- Confidence drift
- Feature attribution drift (SHAP)
- Embedding drift
- OOD / Outlier detection
- Calibration drift

#### Tools
- Evidently
- WhyLabs
- Arize
- Fiddler
- Aporia
- NannyML
- Deepchecks
- Robust Intelligence
- Prometheus + Grafana (infra)
- ELK / OpenSearch (logs)

### 6.5 Infrastructure & DevOps

#### Containerisation
- Docker
  - Dockerfile, multi-stage builds
  - Image optimization
  - Docker Compose
- Podman
- containerd

#### Orchestration
- Kubernetes
  - Pods, Deployments, Services, Ingress
  - StatefulSets, DaemonSets, Jobs, CronJobs
  - Helm charts
  - Operators
  - HPA / VPA (autoscaling)
- Knative
- Nomad

#### Infrastructure as Code
- Terraform
- Pulumi
- CloudFormation (AWS)
- ARM / Bicep (Azure)
- Crossplane

#### CI/CD
- GitHub Actions
- GitLab CI
- Jenkins
- CircleCI
- Argo CD (GitOps)
- Flux

#### Secrets & config
- Vault (HashiCorp)
- AWS Secrets Manager
- GCP Secret Manager
- Kubernetes Secrets
- SOPS

#### Observabilité infra
- Prometheus + Grafana
- Datadog, New Relic
- OpenTelemetry
- Jaeger / Zipkin (tracing)
- ELK / OpenSearch / Loki (logs)

#### Coût
- FinOps
- Spot / preemptible instances
- Right-sizing
- GPU utilization monitoring

### 6.6 Bonnes pratiques

#### Reproductibilité
- Versioning du code (git)
- Versioning des données (DVC, LakeFS)
- Versioning des modèles (MLflow Registry)
- Versioning des environnements (Docker, requirements lock)
- Seed management
- Capture de toutes les configs

#### Testing
- Unit tests (fonctions, classes)
- Integration tests (pipelines)
- Data tests
  - Schema
  - Statistical assumptions
  - Distribution
- Model tests
  - Invariance tests (changement non pertinent → même prédiction)
  - Directional tests (changement attendu → direction attendue)
  - Minimum Functionality Tests (MFT)
  - Behavioral testing (CheckList)
- Pre-deployment tests (load, regression)
- Smoke tests post-deploy

#### Documentation
- README, CONTRIBUTING
- Model Cards
- Datasheets for Datasets
- Architecture Decision Records (ADR)
- Runbooks / playbooks
- Postmortems

#### Code quality
- Code reviews
- Coding standards
- Static analysis
- Logging structuré (JSON)
- Tracing
- Idempotence
- Graceful degradation
- Rollback strategies
- Circuit breakers
- Rate limiting
- Retries with backoff

#### Sécurité (ops)
- Least privilege (IAM)
- Network policies
- Image scanning
- Dependency scanning (SCA)
- SAST / DAST
- Model security
  - Adversarial robustness
  - Model extraction
  - Membership inference
  - Data poisoning detection

#### Cycle de vie
- CRISP-DM
- MLOps lifecycle (CRISP-ML(Q))
- Continuous Training (CT)
- Trigger-based retraining
  - Calendar
  - Performance-based
  - Drift-based
  - Volume-based
- Shadow models
- Feedback loops

---

*Fin du document.*
