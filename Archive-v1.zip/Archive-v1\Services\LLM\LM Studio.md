---
galaxie: dev
nom: LM Studio
alias: [lmstudio, lm-studio]
categorie: llm/local
sous_categories: [local, gui, desktop, gguf, mlx, openai-compat]
licence: Propriétaire (gratuit usage perso, commercial sur demande)
licence_type: proprietary
hosted: self
maturite: production
langage: TypeScript / Electron
clients_officiels: [python, typescript, cli]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Ollama]]", "[[llama.cpp]]", "[[text-generation-webui]]", "Jan"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, local, gui, desktop]
url_officiel: https://lmstudio.ai/
url_docs: https://lmstudio.ai/docs
url_repo: https://github.com/lmstudio-ai
---

# LM Studio

## Pourquoi

Application desktop (Mac/Windows/Linux) pour **télécharger, gérer et faire tourner des LLMs locaux** avec une GUI très polish. Browse HuggingFace, télécharge des GGUF en un clic, chat local, serveur **OpenAI-compatible** sur port 1234 pour brancher tes apps dev.

Sous le capot : **llama.cpp** (toutes plateformes) + **MLX** (Mac Apple Silicon, sélectionnable runtime). Cible : **développeurs et power users** qui veulent du local-first sans CLI ni Docker. Concurrent direct d'**Ollama** mais avec GUI au lieu de CLI-first.

## Quand l'utiliser

- **Première install LLM local** : UX la plus accessible du marché
- **Tester des modèles GGUF** sans configurer llama.cpp à la main
- **Hoster une API OpenAI-compat locale** pour brancher Cursor, Continue, scripts Python
- **Mac Apple Silicon** : MLX engine intégré (plus rapide que llama.cpp sur M-series)
- **Démo / présentation** : interface chat polish, multimodal, embeddings
- **Power user non-dev** : recherche, journalistes, devs front qui veulent du local
- **Comparer rapidement plusieurs modèles** : load/unload depuis la UI

## Quand NE PAS l'utiliser

- **Production serveur multi-user** → [[vLLM]] / [[SGLang]] / [[TGI]] / [[Ollama]]
- **Scripts CLI / CI / headless** → [[Ollama]] (CLI-first, daemon léger) ou [[llama.cpp]] direct
- **Multi-user concurrent** : LM Studio mono-user par design, batching limité
- **Reproductible / IaC** : pas pensé pour Docker/Kubernetes, install GUI
- **Open-source strict** : LM Studio est closed-source (gratuit perso, commercial négocié)

## Pièges connus

- **App pas open-source** : closed-source, gratuit usage personnel, **commercial requiert licence** (négociée)
- **Pas designed for headless server** : tourne comme app desktop, pas idéal en service systemd
- **Update modèles via UI** : moins reproductible qu'un `ollama pull mistral` versionné en Dockerfile
- **Quantizations confuses** : Q4_K_M, Q5_K_S, Q8_0... LM Studio les expose tous, choisir selon RAM
- **Context window setup** : par défaut souvent trop court, à ajuster dans les paramètres modèle
- **GPU offload** : nombre de layers GPU à régler à la main selon VRAM (auto pas toujours optimal)
- **CLI `lms` jeune** : existe (lms server start, lms load) mais moins riche qu'Ollama
- **Pas de modèles non-GGUF/MLX** : pas de support natif AWQ / GPTQ / EXL2 (utiliser text-generation-webui ou vLLM)

## Code minimal

```bash
# 1. Télécharger l'app sur https://lmstudio.ai/
# 2. Dans la GUI : chercher "llama-3.1-8b-instruct" → download
# 3. Onglet "Developer" → Start Server (port 1234 par défaut)

# CLI (optionnel)
lms server start
lms ls                          # liste les modeles installes
lms load llama-3.1-8b-instruct  # charge en memoire
```

```python
# Client Python OpenAI-compat (n'importe quel SDK OpenAI marche)
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:1234/v1",
    api_key="lm-studio",  # ignore mais requis
)

response = client.chat.completions.create(
    model="llama-3.1-8b-instruct",  # nom tel qu'il apparait dans LM Studio
    messages=[
        {"role": "system", "content": "Tu reponds en francais, concis."},
        {"role": "user", "content": "Qu'est-ce que la memoire unifiee Apple ?"},
    ],
    temperature=0.3,
)
print(response.choices[0].message.content)

# Embeddings (si modele embedding charge dans LM Studio)
emb = client.embeddings.create(
    model="nomic-embed-text-v1.5",
    input=["hello world", "bonjour le monde"],
)
print(len(emb.data[0].embedding))
```

## Liens

- [[Ollama]] — alternative CLI-first, plus déployable serveur
- [[llama.cpp]] — backend low-level utilisé par LM Studio
- [[MLX]] — engine Mac alternatif (LM Studio l'expose en option)
- [[text-generation-webui]] — alternative open-source GUI plus riche
- Jan — alternative full open-source desktop (https://jan.ai)
- Docs : https://lmstudio.ai/docs
- Modèles : https://huggingface.co/models?library=gguf
