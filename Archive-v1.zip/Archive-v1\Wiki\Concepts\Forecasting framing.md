---
galaxie: wiki
nom: Forecasting framing
alias: [Time series forecasting framing, Direct vs Recursive forecasting]
type: concept
categorie: concept/time-series
sous_categories: [forecasting, direct, recursive, multi-step]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Bontempi et al. 2012, Taieb 2014]
lecture_min: 9
created: 2026-05-19
modified: 2026-05-19
tags: [concept, time-series, forecasting, framing]
---

# Forecasting framing — comment formuler un problème de prévision multi-horizon

## TL;DR

Quand on veut prédire **plusieurs points dans le futur** ($h=2, 3, \dots, H$), il y a au moins 4 façons de formuler le problème : **Recursive**, **Direct**, **DirRec**, **Multi-output**. Chacune a ses avantages, sa complexité et son biais. Le choix dépend de l'horizon, du modèle, et de la corrélation entre les sorties.

## Le problème

Tu as une série $X_1, \dots, X_T$ et tu veux prédire $X_{T+1}, X_{T+2}, \dots, X_{T+H}$ ($H$ points = "horizon").

Comment **entraîner** ton modèle pour ça ? Plusieurs frames possibles, qui produisent des résultats différents en termes de :
- **Biais** vs **variance**
- **Coût d'entraînement** (1 modèle ou $H$ modèles ?)
- **Coût d'inférence** (1 appel ou $H$ appels ?)
- **Accumulation d'erreur** dans les longs horizons

## L'idée

### 1. Recursive (itératif, "one-step + feedback")

Entraîner **un seul modèle** $f$ pour prédire $\hat X_{T+1}$ à partir de $X_1, \dots, X_T$.
Pour prédire $X_{T+2}$ : utiliser **la prédiction** $\hat X_{T+1}$ comme entrée. Et ainsi de suite.

```
T+1 :  f(X_1, ..., X_T)            → \hat X_{T+1}
T+2 :  f(X_1, ..., X_T, \hat X_{T+1})  → \hat X_{T+2}
T+3 :  f(X_1, ..., X_T, \hat X_{T+1}, \hat X_{T+2}) → \hat X_{T+3}
...
```

✅ Un seul modèle, simple
❌ **Accumulation d'erreur** : à chaque step, l'erreur précédente est injectée. Pire en horizon long.
❌ Distribution d'entrée différente entre entraînement (vraies valeurs) et inférence (prédictions) → biais

### 2. Direct (un modèle par horizon)

Entraîner $H$ modèles indépendants $f_1, f_2, \dots, f_H$, chacun spécialisé pour un horizon :

$$ f_h : (X_1, \dots, X_T) \mapsto \hat X_{T+h}, \quad h = 1, \dots, H $$

✅ Pas d'accumulation d'erreur
✅ Chaque modèle optimisé pour son horizon
❌ $H$ modèles à entraîner (coût × $H$)
❌ Pas de cohérence entre les horizons (les prédictions ne respectent pas forcément la dynamique de la série — ex. valeurs incohérentes)

### 3. DirRec (Direct + Recursive)

Combinaison : pour prédire $X_{T+h}$, entraîner $f_h$ qui prend en entrée $X_1, \dots, X_T, \hat X_{T+1}, \dots, \hat X_{T+h-1}$. Les prédictions précédentes nourrissent les modèles suivants, mais chacun est dédié à son horizon.

✅ Compromis raisonnable entre Direct et Recursive
❌ Hérite des inconvénients de chaque approche

### 4. Multi-output (MIMO, vector forecasting)

Un seul modèle $f$ qui prédit **tout d'un coup** :

$$ f : (X_1, \dots, X_T) \mapsto (\hat X_{T+1}, \hat X_{T+2}, \dots, \hat X_{T+H}) $$

Implémentation typique : sortie multi-dimensionnelle (sklearn `MultiOutputRegressor`, NN avec layer de sortie de taille $H$).

✅ Cohérence interne (le modèle voit toutes les sorties ensemble, peut apprendre leurs corrélations)
✅ Pas d'accumulation d'erreur stricto sensu
✅ Coût entraînement = 1 modèle
❌ Plus difficile à optimiser (multi-objectif)
❌ Pas adapté si $H$ est très grand (output explose)

### Comparaison synthétique

| Méthode | # modèles | Cohérence sorties | Accumulation erreur | Coût |
|---|---|---|---|---|
| Recursive | 1 | implicite (séquentielle) | ⚠️ oui, croît avec $h$ | bas |
| Direct | $H$ | ❌ aucune | ✅ non | × $H$ |
| DirRec | $H$ | partielle | partielle | × $H$ |
| Multi-output | 1 | ✅ par construction | ✅ non | bas |

### Choix pragmatique

- **Petit horizon** (1-7), modèle simple → **Recursive** (rapide, suffisant)
- **Grand horizon** (>30), précision critique → **Direct** ou **Multi-output**
- **Modèle deep learning** (LSTM, TFT, DeepAR, Transformer) → **Multi-output** naturel, c'est ce que font ces archis
- **ARIMA classique** → Recursive par construction
- **Prophet** → fournit un Multi-output naturel
- **Gradient boosting** (XGBoost, LightGBM) → typiquement Direct (un modèle par horizon)

## Quand c'est utile

- Tout problème de **multi-step forecasting** : ventes mensuelles à 12 mois, prix énergie à 24h, charge serveur à 1 semaine
- Comparer des modèles concurrents en équilibrant le framing (apples-to-apples)
- Optimiser la précision sur des horizons critiques (ex. court terme prioritaire vs long terme indicatif)

## Quand ça ne marche pas / pièges

- **Comparer Recursive vs Direct sans contrôler** → pas équitable. Bien préciser dans les rapports.
- **MIMO mal calibré** : si la fonction de loss est juste une moyenne MSE sur les $H$ sorties, le modèle peut négliger un horizon spécifique
- **Direct sans rééchantillonnage** : tu te retrouves avec un dataset différent par modèle (target shifté), attention aux fuites
- **Recursive avec injection des prédictions sans bruit** : surconfiance, à comparer avec injection des vraies valeurs (vu en entraînement)

## Code minimal

```python
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor

# Soit X la série, on veut prédire H=5 points à partir des P=10 derniers
P, H = 10, 5

# Construire (X_lagged, Y_multi) — Multi-output
def make_dataset(ts, P, H):
    X, Y = [], []
    for t in range(P, len(ts) - H + 1):
        X.append(ts[t-P:t])
        Y.append(ts[t:t+H])
    return np.array(X), np.array(Y)

X, Y = make_dataset(ts, P, H)

# 1. RECURSIVE — 1 modèle, on prédit X[t+1] puis on l'utilise comme input
model = GradientBoostingRegressor().fit(X, Y[:, 0])  # train sur 1-step
# inference : on appelle model() en boucle, en injectant les preds

# 2. DIRECT — H modèles, un par horizon
models_direct = [GradientBoostingRegressor().fit(X, Y[:, h]) for h in range(H)]

# 3. MULTI-OUTPUT — un seul modèle multi-sortie
from sklearn.multioutput import MultiOutputRegressor
model_mimo = MultiOutputRegressor(GradientBoostingRegressor()).fit(X, Y)
```

Frameworks haut niveau qui gèrent ça pour toi : [[darts]], [[statsforecast]], [[neuralforecast]].

## Pour aller plus loin

- Bontempi, Ben Taieb, Le Borgne, *Machine learning strategies for time series forecasting* (2012) — review canonique
- Taieb, *Machine Learning Strategies for Time Series Forecasting* (thèse, 2014)
- Hyndman, *Forecasting: Principles and Practice* (FPP3) — chap. multi-step
- **Liens internes** : [[Stationarity]], [[Autocorrelation]], [[Walk-forward CV]]
