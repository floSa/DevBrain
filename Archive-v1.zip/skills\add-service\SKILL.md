---
name: add-service
description: |
  Use this skill when the user wants to add a new service/technology fiche
  to the DevBrain. Triggers: "ajoute le service", "ajoute une fiche pour",
  "nouvelle fiche service", "documente <techno>", or when user provides a
  URL of a tool's homepage and asks to add it. Generates a fiche compliant
  with the standardized frontmatter schema in Services/<Categorie>/<Nom>.md.
---

# Skill — add-service

## Quand l'utiliser

L'utilisateur veut créer une **nouvelle fiche Service** dans `Services/`. Cas typiques :
- Documente une lib / un outil / un framework qu'il vient de découvrir
- Fournit une URL de doc / GitHub à transformer en fiche standard
- Veut ajouter un service à comparer dans un Comparatif

Distinct de :
- `add-wiki-outil` (outil personnel dans `Wiki/Outils/`, pas un composant projet)
- `update-service` (modifier une fiche existante)
- `add-pattern` (formaliser une stack complète, pas un service unique)

## Pré-requis vault

Mode build. Périmètre `Services/` uniquement.

## Procédure

### Étape 1 — Identifier
1. Demande le nom canonique du service (ex: "Postgres" pas "PostgreSQL Database").
2. Cherche dans le brain si la fiche existe déjà : `Services/**/<nom>*.md`.
   Si oui, propose de la modifier au lieu d'en créer une nouvelle.

### Étape 2 — Catégoriser
Catégorie = `<domaine>/<sous-domaine>` selon la taxonomie autorisée :
- `database/{relational, document, keyvalue, vector, timeseries, graph}`
- `framework/{backend, frontend, fullstack, mobile}`
- `language/general | runtime`
- `devops/{ci, iac, container, orchestration}`
- `llm/{api, local, framework}`
- `auth | storage`
- `observability/{log, metric, trace}`
- `tooling/{lint, format, build, test}`

Si aucune ne convient, demande à l'utilisateur avant d'inventer.

### Étape 3 — Pré-remplir
Si l'utilisateur a fourni l'URL de la home, utilise le skill `defuddle`
(kepano) pour extraire :
- url_officiel, url_docs, url_repo
- licence (chercher la mention)
- langage (souvent dans la home / About)
- maturité (heuristique : "production-ready" vs "alpha")

Sinon, demande les éléments manquants.

### Étape 3bis — Repérer les fiches qui mentionnent déjà ce nom (via `find-connexes.ps1`)

**Avant** d'écrire la fiche, scanne le vault pour voir qui parle déjà du service. Ces fiches devront être mises à jour (wikilinks) après création.

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/find-connexes.ps1 -Name "<Nom>"
```

Note la liste sortie en [FAIBLE] (mentions sans wikilink) : ce sont les pages que `add-wikilinks.ps1` va patcher à l'étape 8.

### Étape 4 — Générer la fiche
Charge `Templates/Service.md`, remplis le frontmatter complet, génère le
corps en 5 sections fixes :

1. **Pourquoi** (2-3 lignes synthèse)
2. **Quand l'utiliser** (3-5 bullets)
3. **Quand NE PAS l'utiliser** (avec wikilinks vers alternatives)
4. **Pièges connus** (vide ou liste si tu as l'info, sinon laisser à
   compléter via REX au fur et à mesure)
5. **Liens** (Patterns liés, autres Services connexes, doc officielle)

### Étape 5 — Wikilinker (via `discover-links.ps1`)

**Toujours utiliser le script** :

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/discover-links.ps1 \
    -Title "<Nom>" \
    -Categorie "<Categorie/SousCategorie>" \
    -Domaines "<csv>" \
    -SousCategories "<csv>" \
    -Tags "<csv>" \
    -Galaxie dev \
    -TopN 15
```

L'option `-Galaxie dev` limite aux fiches DEV (Services, Patterns, Rules). Ajouter le top WIKI séparément si pertinent (concepts liés).

**Workflow** :
1. Lance le script avec les metadata pressentis
2. Trie les candidats :
   - **Alternatives** (même `categorie:`, même rôle) → frontmatter `alternatives: [...]`
   - **Compléments** (utilisés ensemble) → section "Liens"
   - **Concepts liés** (relancer sans `-Galaxie dev`) → section "Liens"
3. Confirme avec l'utilisateur avant d'écrire

**Reverse linking** : si la nouvelle fiche est une alternative à un service existant, propose d'ajouter `<nouveauService>` dans le frontmatter `alternatives:` de cet existant.

### Étape 6 — Demander confirmation
Avant écriture, montre la fiche complète à l'utilisateur. Liste explicitement :
- catégorie choisie
- alternatives détectées
- score (laisser vide si l'utilisateur n'a pas dit)

### Étape 7 — Écrire
Path : `Services/<Categorie>/<Nom>.md`. Pas de sous-note tant que le contenu
tient en 1 page.

### Étape 8 — Audit post-création (via `find-connexes.ps1`)

**Après** l'écriture, audit la fiche pour repérer les wikilinks fantômes que tu viens d'introduire (cibles inexistantes) :

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/find-connexes.ps1 -Path "Services/<Categorie>/<Nom>.md"
```

La section "Wikilinks fantomes DANS la cible" liste les `[[Y]]` à corriger : créer `Y`, dewikilinker, ou rediriger vers un alias existant.

### Étape 9 — Propager les wikilinks dans le vault (via `add-wikilinks.ps1`)

Wikilinke la **première mention bare** de la nouvelle fiche dans toutes les autres fiches du vault (celles repérées à l'étape 3bis) :

```bash
# 1. Dry-run pour valider
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "<Nom>" -All

# 2. Appliquer
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "<Nom>" -All -Apply
```

Évite d'écrire dans les zones frontmatter / code blocks / inline code. N'agit que sur la 1ère occurrence par fichier (les suivantes peuvent être ajoutées à la main si pertinent).

### Étape 10 — Vérification finale

Relance `report-ghosts.ps1` pour confirmer 0 nouveau fantôme :

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/report-ghosts.ps1
```

## Format frontmatter (rappel strict)

```yaml
---
nom: <Name>
alias: []
categorie: <domain>/<sub>
sous_categories: []
licence: 
licence_type: open-source | source-available | proprietary
hosted: self | managed | both
maturite: production | beta | experimental | deprecated
langage: 
clients_officiels: []
plateforme: []
score: 
mes_projets: []
alternatives: []
remplace: []
remplace_par: []
created: <YYYY-MM-DD>
modified: <YYYY-MM-DD>
status: actif
tags: [service, ...]
url_officiel: 
url_docs: 
url_repo: 
---
```

## Anti-patterns à éviter
- Ne pas inventer un score si l'utilisateur n'a pas testé
- Ne pas mettre `production` si la doc dit "beta"
- Ne pas créer la fiche dans `Services/Misc/` ; demande la catégorie
- Ne pas oublier le champ `galaxie: dev` dans le frontmatter
- Ne pas sortir du périmètre `Services/` (les outils perso vont dans Wiki/Outils/)

## Voir aussi

- `update-service` (patcher une fiche existante)
- `compare-services` (créer un Comparatif après ajout de plusieurs services)
- `log-bug` (logger un REX si découverte d'un bug pendant l'usage)
- `add-pattern` (formaliser une stack qui utilise ce service)
