---
galaxie: dev
nom: Faiss
alias: [faiss]
categorie: database/vector
sous_categories: [library, in-memory, gpu, ann-algorithms]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: C++ (Python bindings)
clients_officiels: [python, c++]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Qdrant]]", "[[Chroma]]", "[[hnswlib]]", "[[Annoy]]", "[[ScaNN]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, library, vector, faiss, ann]
url_officiel: https://github.com/facebookresearch/faiss
url_docs: https://github.com/facebookresearch/faiss/wiki
url_repo: https://github.com/facebookresearch/faiss
---

# Faiss

## Pourquoi
**Bibliothèque** d'indexation vectorielle de Meta (FAIR). Pas un serveur — une lib C++/Python qu'on appelle dans son code. Référence académique pour les algos ANN (HNSW, IVF, PQ, OPQ). Ce qui tourne sous le capot de [[LangChain]] FAISS, et beaucoup d'autres.

## Quand l'utiliser
- Tu veux **un index en RAM** dans ton process Python, pas un serveur séparé
- Recherche vectorielle dans un notebook / script offline
- Performance maximale + contrôle total de l'algo
- GPU disponible (faiss-gpu)
- Briques de base d'un système custom (réécrire ton propre vector store)

## Quand NE PAS l'utiliser
- App multi-process / multi-server → besoin d'un serveur ([[Qdrant]] / [[Weaviate]])
- Filtrage métier (par catégorie, user, etc.) en plus du vector search → c'est pénible avec Faiss pur
- Persistance ACID → Faiss = save/load via fichier, pas de transactions
- Updates fréquents avec deletes → certains index Faiss sont mauvais en delete

## Pièges connus
- **Choix de l'index** : `IndexFlatL2` (exact mais lent), `IndexHNSWFlat` (rapide, défaut moderne), `IndexIVFPQ` (compressé, large scale) — choisir avec soin
- **GPU index ≠ CPU index** : copies entre devices à gérer
- **Threading** : pas de parallélisme natif, à orchestrer
- **No metadata** : Faiss stocke seulement les vecteurs et IDs, le reste est à toi (DB séparée typique)
- **Versioning des index** : aucun garde-fou, à toi de gérer
- **`IndexFlatIP` ≠ cosine** : normaliser les vecteurs avant si tu veux du cosine

## Liens
- [[Qdrant]], [[Chroma]] — alternatives serveur (utilisent Faiss-like algos)
- Wiki Faiss (très bonne ref) : https://github.com/facebookresearch/faiss/wiki
- FAISS index factory : https://github.com/facebookresearch/faiss/wiki/The-index-factory
- Tuto LangChain FAISS : https://python.langchain.com/docs/integrations/vectorstores/faiss/
