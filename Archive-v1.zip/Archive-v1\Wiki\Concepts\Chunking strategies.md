---
galaxie: wiki
nom: Chunking strategies
alias: [chunking, document splitting, semantic chunking, late chunking, propositions]
type: concept
categorie: concept/rag
sous_categories: [chunking, rag, retrieval, document-processing]
domaines: [ai-eng]
maturite: established
auteurs_cles: []
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, rag, chunking, llm]
---

# Chunking strategies

## TL;DR

Découper un document en **morceaux (chunks)** indexés indépendamment pour [[RAG]]. Décision **critique** sur la qualité du retrieval : trop petit = perte de contexte, trop grand = pollution. Familles : **fixed-size** (char/token + overlap, default sklearn-like), **recursive character splitting** (LangChain), **sentence/paragraph-based** (NLTK, spaCy), **semantic chunking** (embedding similarity break), **document-structure-aware** (markdown headers, code AST), **late chunking** (Jina, embed whole doc d'abord), **agentic** (LLM décide), **propositions** (atomic facts). Toujours **inclure metadata** par chunk (source, page, section) pour citation et filtering.

## Le problème

Documents longs (PDF 100 pages, articles long, codebase) ne rentrent pas dans context. Embeddings ont des limites (8K tokens typiquement). Solution : **split en chunks**, embed chacun, retrieve les pertinents.

**Mais** : comment splitter ? Couper en plein milieu d'une phrase casse la sémantique. Couper trop large dilue le signal. Choix critique pour la qualité finale du [[RAG]].

## L'idée

### Fixed-size (basic baseline)

**Par tokens** (préféré) ou caractères :

```
chunks = [text[i:i+SIZE] for i in range(0, len(text), SIZE - OVERLAP)]
```

- **chunk_size** : 256-512 tokens typique
- **overlap** : 10-20% du chunk_size (préserve continuité)

Pros : simple, prévisible.
Cons : coupe au milieu de phrases / paragraphs.

### Recursive character splitting (LangChain)

Essayer séparateurs **en cascade** : `["\n\n", "\n", ". ", " ", ""]`. Premier qui produit chunks ≤ chunk_size.

```python
from langchain.text_splitter import RecursiveCharacterTextSplitter
splitter = RecursiveCharacterTextSplitter(
    chunk_size=500, chunk_overlap=50,
    separators=["\n\n", "\n", ". ", " ", ""]
)
```

Standard pragmatique. Pas parfait mais bon ratio simplicité/qualité.

### Sentence-based

Split par phrases (NLTK, spaCy, sentence-splitter). Puis grouper en chunks ≤ size.

```python
from nltk.tokenize import sent_tokenize
sentences = sent_tokenize(text)
# Greedy group sentences into chunks
```

Pros : ne casse jamais une phrase.
Cons : phrases longues → chunks variables.

### Paragraph-based

Split sur `\n\n`. Bon pour articles, blog posts.

### Document-structure-aware

#### Markdown headers

Garder l'hiérarchie en metadata :

```python
from langchain.text_splitter import MarkdownHeaderTextSplitter
splitter = MarkdownHeaderTextSplitter(
    headers_to_split_on=[("#", "h1"), ("##", "h2"), ("###", "h3")]
)
```

Chaque chunk hérite des headers comme metadata → utile pour citation et filtering.

#### HTML

BeautifulSoup pour extraire sections sémantiques (`<article>`, `<section>`).

#### Code

Split par **AST** (functions, classes, methods). Standard pour code search RAG.

```python
from langchain.text_splitter import RecursiveCharacterTextSplitter, Language
splitter = RecursiveCharacterTextSplitter.from_language(language=Language.PYTHON,
                                                          chunk_size=500)
```

### Semantic chunking

#### Embedding similarity break

Embedder phrase par phrase, calculer cosine entre consécutives, **couper où la similarité chute** (changement de topic).

```python
# Pseudo-algo
embeddings = embed(sentences)
distances = [1 - cos(embeddings[i], embeddings[i+1]) for i in range(len(sentences)-1)]
# Threshold = 95th percentile des distances
breakpoints = [i for i, d in enumerate(distances) if d > threshold]
```

LangChain / LlamaIndex implem standards. **Meilleur** que fixed-size pour topical coherence.

#### Greedy semantic

Build chunk by adding sentences while semantic similarity reste haute.

### Late chunking (Jina, 2024)

**Innovation récente** :

1. Embedder le **document entier** d'abord (avec un long-context embedder)
2. **Découper les embeddings token-par-token**
3. Pooler les embeddings de chunk après

Préserve le **contexte global** dans les embeddings.

- Demande un long-context embedder (Jina v3, 8K)
- Mieux que chunk → embed (chunk perd contexte global)

### Agentic chunking

LLM décide où couper :

```
"Split this document into self-contained chunks of meaningful content.
Each chunk should be readable without surrounding context."
```

- Coûteux (1 LLM call per doc)
- Bonne qualité
- Standard pour high-value docs (legal, scientific)

### Propositions / Atomic facts (Chen 2023, Dense X)

Décomposer chaque paragraphe en **propositions atomiques** :

```
Paragraph: "Paris is the capital of France. It has 2M inhabitants."
Propositions:
1. "Paris is the capital of France."
2. "Paris has 2M inhabitants."
```

Granularité fine → matchs précis. Mais perd contexte.

### Hierarchical (parent-child)

Indexer **deux niveaux** :
- **Small chunks** (sentences) pour matching précis
- **Large chunks** (paragraphs) pour context retrieval

Retrieve sur small, return large. **Parent Document Retriever** (LangChain).

### Sliding window

Comme fixed-size avec overlap mais window glisse à intervals fixes. Variante : multi-resolution (plusieurs window sizes).

### Considérations

#### Chunk size — combien de tokens ?

- **256 tokens** : très précis, mais perte de contexte
- **512 tokens** : sweet spot pour RAG question-answering (most common)
- **1024 tokens** : bon pour contexte large (summarization)
- **2048+ tokens** : moins de chunks, meilleur global understanding

À tuner empiriquement sur ton eval set.

#### Overlap

- **0** : pas d'overlap → risque de perdre info en bordure
- **10-20%** : standard (50-100 tokens si chunk 512)
- **50%+** : reduces "edge effects" mais double les chunks

#### Metadata par chunk

Toujours stocker :
- `source` : nom du document, URL
- `page` ou `section` : pour citation
- `chunk_id`, `position`
- `prev_chunk_id`, `next_chunk_id` (pour contextual retrieval)
- Tags / categories pour filtering

### Contextual Retrieval (Anthropic 2024)

**Innovation 2024** :
1. Pour chaque chunk, demander à un LLM de générer un **chunk-level context** :

```
"This chunk is from section X about Y. It discusses Z."
```

2. **Prepend** ce contexte au chunk avant d'embedder
3. Indexer le chunk **avec son contexte**

Combine avec **prompt caching** (cache le doc entier, génère contexte pour chaque chunk → cheap).

**Résultat** : -49% de retrieval errors (Anthropic blog).

### Tableau récapitulatif

| Stratégie | Complexité | Qualité | Use case |
|---|:-:|:-:|---|
| Fixed-size | trivial | basic | baseline |
| Recursive char | low | medium | LangChain default |
| Sentence-based | low | medium | text général |
| Markdown headers | low | high (structured) | docs, wikis |
| Code AST | medium | high | code search |
| Semantic | medium | high | topical coherence |
| Late chunking | medium | very high | long ctx embedder dispo |
| Agentic | high | very high | high-value docs |
| Propositions | high | high (precise) | fact extraction |
| Hierarchical | medium | very high | RAG général |
| Contextual Retrieval | medium | very high | **moderne 2026** |

### Best practices

1. **Start with recursive char + markdown-aware** : 80% du temps suffit
2. **Eval set** : test retrieval@k sur differents chunk sizes
3. **Metadata** : ne PAS oublier (source, position)
4. **Chunk size 512 tokens** + **overlap 50** : default sain
5. **Code → AST splitting** non-negotiable
6. **Long doc + budget LLM** : Contextual Retrieval (Anthropic)
7. **Semantic chunking** si data non-structuré (web scrapes)
8. **Hierarchical** : essayer Parent Document Retriever
9. **Test reranking** ([[Reranking]]) — peut compenser bad chunking
10. **Avoid chunks too small** (<100 tok) : noise, peu de signal

## Quand c'est utile

- **Tout système RAG** : choisir la stratégie selon use case
- **Doc structuré (markdown, HTML)** : structure-aware split
- **Codebase** : AST-based pour code search
- **PDFs scientifiques** : sections + figures + tables (loader sophistiqué)
- **Wiki / KB** : markdown headers preserve hierarchy
- **Customer docs** : agentic ou contextual retrieval
- **Audio / video** (after transcript) : sentence-based, temporal
- **Multimodal docs** : text + images (ColPali, Vision-RAG)

## Quand ça ne marche pas / pièges

- **Chunk size fixe sans overlap** : key info en bordure perdue
- **Overlap trop élevé** : redondance, indexing 2x plus cher
- **Pas de metadata** : impossible de citer, filter, debug
- **Chunk size mismatched** avec embedder context : truncation silencieuse
- **Semantic chunking sur very short docs** : peu de coupures, useless
- **Code par lignes** vs AST : `def foo()` séparé de son `return` → bug retrieval
- **Tokens vs chars** : counter en char donne chunks variables en tokens (selon langue)
- **PDF chunking sur raw text** : sans layout-aware loader, formules / tables cassés
- **Hierarchical mal implémenté** : parent doc trop large → context window overflow
- **Re-indexing à chaque chunk strategy change** : coûteux, planifier
- **Propositions explosent** le nombre de chunks → recall up mais cost up

## Code minimal

```python
# 1. Recursive character splitter
from langchain_text_splitters import RecursiveCharacterTextSplitter

splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50,
    length_function=len,
    separators=["\n\n", "\n", ". ", " ", ""]
)

chunks = splitter.create_documents([long_text])
for c in chunks[:3]:
    print(c.page_content[:100], "...")

# 2. Markdown header splitter (preserve structure)
from langchain_text_splitters import MarkdownHeaderTextSplitter

md_splitter = MarkdownHeaderTextSplitter(
    headers_to_split_on=[("#", "h1"), ("##", "h2"), ("###", "h3")],
    strip_headers=False  # garder headers dans content
)
md_chunks = md_splitter.split_text(markdown_text)

# 3. Code splitter (AST-ish)
from langchain_text_splitters import RecursiveCharacterTextSplitter, Language
py_splitter = RecursiveCharacterTextSplitter.from_language(
    language=Language.PYTHON, chunk_size=500
)
code_chunks = py_splitter.split_text(python_code)

# 4. Semantic chunking (LangChain experimental)
from langchain_experimental.text_splitter import SemanticChunker
from langchain_openai import OpenAIEmbeddings

sem_splitter = SemanticChunker(
    OpenAIEmbeddings(),
    breakpoint_threshold_type="percentile",
    breakpoint_threshold_amount=95
)
sem_chunks = sem_splitter.create_documents([text])

# 5. Sentence-based with greedy grouping
import nltk
nltk.download('punkt')
from nltk.tokenize import sent_tokenize

def chunk_by_sentences(text, max_tokens=500):
    sentences = sent_tokenize(text)
    chunks = []
    current = ""
    for s in sentences:
        if len(current) + len(s) < max_tokens * 4:  # rough char/token
            current += " " + s
        else:
            chunks.append(current.strip())
            current = s
    chunks.append(current.strip())
    return chunks

# 6. Contextual Retrieval (Anthropic-style)
import anthropic
client = anthropic.Anthropic()

def add_chunk_context(doc, chunk):
    response = client.messages.create(
        model="claude-3-haiku-20240307",
        max_tokens=100,
        system="Provide brief context (1-2 sentences) for this chunk to help with retrieval.",
        messages=[{
            "role": "user",
            "content": [
                {"type": "text", "text": f"<document>{doc}</document>",
                 "cache_control": {"type": "ephemeral"}},  # Cache the doc!
                {"type": "text", "text": f"<chunk>{chunk}</chunk>\n\nContext:"}
            ]
        }]
    )
    return response.content[0].text + "\n\n" + chunk

# 7. Late chunking (Jina v3 supports)
# Requires long-context embedder
# 1. Embed whole doc (8K tokens supported)
# 2. Pool token embeddings to chunk embeddings

# 8. Hierarchical (Parent Document Retriever)
from langchain.retrievers import ParentDocumentRetriever
parent_splitter = RecursiveCharacterTextSplitter(chunk_size=2000)
child_splitter = RecursiveCharacterTextSplitter(chunk_size=400)
# retriever = ParentDocumentRetriever(
#     vectorstore=vs, docstore=docstore,
#     child_splitter=child_splitter, parent_splitter=parent_splitter
# )

# 9. Metadata enrichment example
chunks_with_meta = []
for i, chunk in enumerate(chunks):
    chunks_with_meta.append({
        "content": chunk,
        "metadata": {
            "source": "my_doc.pdf",
            "page": detect_page(chunk),
            "chunk_id": i,
            "total_chunks": len(chunks),
            "section": detect_section(chunk),
        }
    })
```

## Pour aller plus loin

- Anthropic, *Contextual Retrieval* (blog 2024) — état de l'art moderne
- *LangChain Text Splitters* documentation
- *LlamaIndex* node parsers documentation
- Günther et al., *Jina Embeddings v3 with Late Chunking* (2024)
- Chen et al., *Dense X Retrieval: What Retrieval Granularity Should We Use?* (propositions, 2023)
- *RAG From Scratch* (LangChain, YouTube series)
- **Liens internes** : [[RAG]], [[Advanced RAG]], [[embeddings]], [[Hybrid retrieval]], [[Reranking]]
