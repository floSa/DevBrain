---
galaxie: wiki
nom: Tool use patterns
alias: [function calling, tool calls, computer use, MCP, tool retrieval]
type: concept
categorie: concept/agents
sous_categories: [tool-use, function-calling, mcp, computer-use, agents]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Schick 2023 (Toolformer)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, agents, tool-use, function-calling]
---

# Tool use patterns

## TL;DR

Donner aux LLM la capacité d'**appeler des fonctions** : web search, code execution, DB queries, APIs. Pattern : (1) **tool definition** (schema JSON), (2) **LLM choisit** tool + args, (3) **exécution** côté code, (4) **tool result** renvoyé au LLM, (5) LLM continue. Variantes : **single call**, **parallel calls** (faster), **sequential** (dépendances), **computer use** (screenshots → mouse/keyboard). **MCP** (Model Context Protocol) standardise les serveurs de tools. Évaluation : **tool-call accuracy**, **argument correctness**, **trajectory eval**. Au cœur des agents modernes ([[Agent patterns]]).

## Le problème

Un LLM ne peut **rien faire** par lui-même : pas accès web, files, DB, code execution. Comment lui donner ces capacités tout en gardant le contrôle ?

## L'idée

### Format function calling

```python
tools = [{
    "name": "get_weather",
    "description": "Get current weather for a city",
    "input_schema": {
        "type": "object",
        "properties": {
            "city": {"type": "string"},
            "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]}
        },
        "required": ["city"]
    }
}]
```

LLM output :
```json
{
  "name": "get_weather",
  "input": {"city": "Paris", "unit": "celsius"}
}
```

App :
1. Parse tool call
2. Execute `get_weather("Paris", "celsius")` → 18°C
3. Renvoie au LLM : `{"type": "tool_result", "content": "18°C"}`
4. LLM continue avec cette info

### Variants

#### Single tool call

Un call par turn. Simple.

#### Parallel tool calls

LLM appelle **plusieurs tools simultanément** (e.g. 3 web searches sur 3 topics). App exécute en parallèle.

```json
[
  {"name": "search", "input": {"query": "A"}},
  {"name": "search", "input": {"query": "B"}},
  {"name": "search", "input": {"query": "C"}}
]
```

Standard OpenAI, Anthropic. **Gain latency** important.

#### Sequential tool calls

Dépendance entre tools (output A → input B). LLM appelle A, attend, puis B.

#### Nested / dependent calls

Tool A retourne un ID → Tool B utilise cet ID.

#### Forced tool choice

Forcer le modèle à appeler un tool spécifique (e.g. structured output via tool).

```python
tool_choice = {"type": "tool", "name": "extract_user"}
```

#### Required vs optional

Le LLM **peut** ne pas appeler de tool si pas pertinent (sauf si forced).

### Tools courants

#### Web search

- **Tavily** : API search optimisée LLM
- **Exa** : search neural
- **Brave Search API** : alternative privacy-first
- **Serper, You.com, Perplexity Sonar** : alternatives
- **DuckDuckGo Search** : free

#### Code execution

- **Python sandbox** : Pyodide (browser), E2B, Modal sandboxes, Daytona, Riza
- **Code interpreter** (OpenAI managed)
- **Anthropic code execution tool** (managed)

#### File system

- Read/write files, list directories
- MCP filesystem server standard

#### Database

- Postgres MCP server
- SQL execution
- Read-only safety

#### Web scraping

- **Firecrawl** : LLM-friendly scraping
- **Jina Reader** : URL → clean markdown
- **ScrapeGraph** : LLM-driven scraping
- **Browser Use** : agentic browser

#### Computer use

LLM avec **screenshots** + **mouse/keyboard** :
- **Anthropic Computer Use** (Claude Sonnet 3.5+ native)
- **OpenAI Operator** / Computer-using Agent
- **WebVoyager** : web-focused

```python
tools = [{
    "type": "computer_20241022",  # Anthropic
    "name": "computer",
    "display_width_px": 1024,
    "display_height_px": 768
}]
```

Actions : `screenshot`, `left_click`, `type`, `key`, `mouse_move`.

#### Custom REST APIs

Tout endpoint API peut être wrappé en tool.

### MCP — Model Context Protocol (Anthropic 2024)

Voir [[mcp-protocol]].

**Standard ouvert** pour tools :
- **MCP servers** : exposent des tools, resources, prompts
- **MCP clients** : Claude Desktop, Claude Code, Cursor, etc.
- **Transports** : stdio, SSE, HTTP

Écosystème croissant : MCP filesystem, postgres, github, slack, etc.

Avantage : **portable** entre LLMs / clients. Tools réutilisables.

### Tool retrieval

Si **trop de tools** (100+) :

1. **Embed all tool descriptions** in vector DB
2. À chaque query, retrieve top-K relevant tools
3. Pass K (10-20) au LLM

Évite de surcharger le context window. Standard pour agents avec bibliothèques de tools.

### Best practices tool design

#### Tool schemas

- **Descriptions claires** : LLM utilise pour décider
- **Param descriptions** : "city: ISO 3166 country code OR city name"
- **Enums** quand applicable
- **Required** marqué correctement
- **Examples** dans description

#### Tool granularity

- **Trop atomic** (read_byte, write_byte) : LLM se perd
- **Trop large** (do_everything) : LLM hésite
- **Sweet spot** : actions logiques métier (search, get_user, send_email)

#### Idempotence

Tools doivent être **idempotent** quand possible (peuvent être retried).

#### Error handling

Tool fail → renvoyer **error message lisible** au LLM, qu'il puisse adapter.

```python
{"type": "tool_result", "content": "Error: city not found", "is_error": true}
```

#### Side effects

Marquer clairement les tools avec **side effects** (write DB, send email, delete file). Considérer **human-in-the-loop** pour ces.

### Evaluation tool use

#### Tool-call accuracy

% des calls où le bon tool est sélectionné.

#### Argument correctness

% des args corrects (type + valeur).

#### Trajectory eval

Sur multi-step : la séquence d'actions est-elle optimale ?

Benchmarks : **BFCL** (Berkeley Function Calling Leaderboard), **τ-bench** (Tau-bench), **ToolBench**.

### Best practices

1. **Tool descriptions soignées** : LLM lit attentivement
2. **Schema strict** : Pydantic / JSON Schema, validation
3. **Limite #tools** : >50 → tool retrieval
4. **Parallel tool calls** : enable quand possible (gain latency)
5. **Error handling propre** : LLM doit pouvoir adapter
6. **Test edge cases** : args invalides, tools failed
7. **Sandbox code execution** : NEVER exec untrusted in prod
8. **Audit log** : tracer chaque tool call
9. **Cost monitor** : tools peuvent coûter ($)
10. **MCP pour réutilisabilité**

## Quand c'est utile

- **Tout agent** : tool use est la base
- **Chatbots augmentés** : web search, calculation
- **Code generation** : exec / test code
- **Data tasks** : SQL queries, file processing
- **Workflow automation** : email, calendar, jira
- **Computer use tasks** : forms, complex UIs
- **Multi-step research** : search → read → synthesize
- **Customer support** : query DB, escalate, etc.

## Quand ça ne marche pas / pièges

- **Tool hallucinations** : LLM appelle `nonexistent_function()`
- **Wrong args** : type mismatch, missing required
- **Tool descriptions confusantes** : LLM hésite ou rate
- **Trop de tools** : LLM perdu, accuracy chute
- **Pas de error handling** : 1 fail = full loop crash
- **Side effects sans HITL** : DELETE production data
- **Infinite loops** : tool retry boucle
- **Code execution unsafe** : RCE possible si pas sandbox
- **Tools peu fiables** : API timeouts → agent stuck
- **Cost runaway** : 100 tool calls = $$$
- **Parallel calls sur dépendants** : LLM appelle B avant A finit → fail
- **Computer use latence** : screenshots + reasoning = slow

## Code minimal

```python
import anthropic
client = anthropic.Anthropic()

# 1. Define tools
tools = [
    {
        "name": "get_weather",
        "description": "Get current weather for a city",
        "input_schema": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
                "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]}
            },
            "required": ["city"]
        }
    },
    {
        "name": "search_web",
        "description": "Search the web for information",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"]
        }
    }
]

# 2. Tool implementations
def execute_tool(name, args):
    if name == "get_weather":
        # Real API call
        return f"18°C in {args['city']}"
    elif name == "search_web":
        # Tavily, etc.
        return f"Search results for: {args['query']}"
    return f"Unknown tool: {name}"

# 3. Tool use loop
def chat_with_tools(user_msg, max_iter=10):
    messages = [{"role": "user", "content": user_msg}]
    
    for i in range(max_iter):
        response = client.messages.create(
            model="claude-3-7-sonnet-latest",
            max_tokens=1024,
            tools=tools,
            messages=messages
        )
        
        if response.stop_reason == "end_turn":
            return response.content[0].text
        
        if response.stop_reason == "tool_use":
            # Add assistant turn
            messages.append({"role": "assistant", "content": response.content})
            
            # Execute all tool_use blocks (parallel possible)
            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    result = execute_tool(block.name, block.input)
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": result
                    })
            
            messages.append({"role": "user", "content": tool_results})
    
    return "Max iterations reached"

print(chat_with_tools("What's the weather in Paris?"))

# 4. Computer Use (Anthropic)
computer_tools = [
    {
        "type": "computer_20241022",
        "name": "computer",
        "display_width_px": 1280,
        "display_height_px": 800
    },
    {
        "type": "bash_20241022",
        "name": "bash"
    }
]

# response = client.messages.create(
#     model="claude-3-5-sonnet-20241022",
#     tools=computer_tools,
#     messages=[{"role": "user", "content": "Open Firefox and search for AI news"}],
#     betas=["computer-use-2024-10-22"]
# )

# 5. OpenAI function calling
from openai import OpenAI
client = OpenAI()

tools_openai = [{
    "type": "function",
    "function": {
        "name": "get_weather",
        "description": "Get weather",
        "parameters": {
            "type": "object",
            "properties": {"city": {"type": "string"}},
            "required": ["city"]
        }
    }
}]

response = client.chat.completions.create(
    model="gpt-4o",
    tools=tools_openai,
    messages=[{"role": "user", "content": "Weather in Tokyo?"}]
)

# 6. MCP (Model Context Protocol)
# Voir [[mcp-protocol]] pour détails
# Serveur MCP : expose tools, resources, prompts via stdio/SSE
# Claude Desktop / Cursor / Claude Code consomme nativement

# 7. Tool retrieval (>100 tools)
from sentence_transformers import SentenceTransformer
import numpy as np

embedder = SentenceTransformer("all-MiniLM-L6-v2")
all_tools = [...]  # 200 tools
tool_descs = [t["description"] for t in all_tools]
tool_embs = embedder.encode(tool_descs)

def retrieve_tools(query, k=10):
    query_emb = embedder.encode(query)
    scores = np.dot(tool_embs, query_emb)
    top_k = np.argsort(scores)[-k:][::-1]
    return [all_tools[i] for i in top_k]

# Usage : retrieved_tools = retrieve_tools("send an email"); pass to LLM

# 8. Validation des tool calls
from pydantic import BaseModel, ValidationError

class WeatherArgs(BaseModel):
    city: str
    unit: str = "celsius"

def safe_execute(name, args):
    try:
        validated = WeatherArgs(**args)
        return f"{get_weather(validated.city, validated.unit)}"
    except ValidationError as e:
        return f"Invalid args: {e}"
```

## Pour aller plus loin

- Schick et al., *Toolformer: Language Models Can Teach Themselves to Use Tools* (NeurIPS 2023)
- Yao et al., *ReAct* (ICLR 2023)
- Anthropic, *Tool use with Claude* documentation
- OpenAI, *Function calling* documentation
- *Model Context Protocol* (MCP) specification
- Berkeley, *BFCL Leaderboard* — function calling benchmark
- Tau-bench paper — tool use eval
- *Anthropic Computer Use* announcement (Oct 2024)
- **Liens internes** : [[tool-use]], [[mcp-protocol]], [[Agent patterns]], [[agent-loops]], [[Structured outputs]], [[Agent evaluation]]
