---
galaxie: wiki
nom: <% tp.file.title %>
type: 
plateforme: 
categorie: skill/
sous_categories: []
auteur: 
source: 
source_url: 
install_cmd: 
install_doc: 
licence: 
licence_type: open-source
domaines: []
score: 
status: discovered
mes_projets: []
created: <% tp.date.now("YYYY-MM-DD") %>
modified: <% tp.date.now("YYYY-MM-DD") %>
tags: [skill]
---

# <% tp.file.title %>

## Pourquoi

(2-3 lignes — ce que ce skill fait, en quoi il est utile pour moi)

## Quand l'utiliser

- 

## Quand NE PAS l'utiliser

- 

## Comment l'installer

```bash
# colle la commande d'install ici
```

Voir aussi : [[_installer-un-skill]] pour la procédure générale par type.

## Exemples d'usage

```
# 1-2 invocations courtes typiques
```

## Pièges connus

- 

## Liens

- Source : 
- Doc : 
