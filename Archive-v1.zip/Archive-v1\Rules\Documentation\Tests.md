---
galaxie: dev
type: rule
domaine: documentation
applicable: global
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, documentation, tests, pytest, testcontainers, eval]
---

# Règle — Stratégie de tests et assurance qualité

## Principe (1 phrase)
Un projet sérieux a **trois niveaux de tests** : unitaires (isolation logique), intégration (containers éphémères), et — pour les systèmes IA — **eval LLM-as-judge** (Ragas, DeepEval, TruLens).

## MUST

### 1. Tests unitaires (pytest)

**Objectif** : tester la logique métier interne **sans appels réseau réels**.

- Framework : **`pytest`** (avec `pytest-asyncio` pour le async)
- **Mocker** systématiquement les APIs externes (LLM, DBs, APIs tierces) avec `unittest.mock`, `pytest-mock`, ou `responses`
- Tests **rapides** : la suite unitaire entière doit tourner en < 60 secondes
- **Coverage cible** : `> 70%` sur la logique métier (pas la glue / configs)
- **Pas de side effects** entre tests (pas d'état partagé, pas d'ordre requis)
- Convention de nommage : `tests/unit/test_<module>.py`

```python
# Exemple : mocker un appel LLM
def test_classify_intent(mocker):
    mock_client = mocker.Mock()
    mock_client.messages.create.return_value = Mock(content=[Mock(text="rag")])
    
    result = classify_intent("ma question", client=mock_client)
    
    assert result == "rag"
    mock_client.messages.create.assert_called_once()
```

### 2. Tests d'intégration (testcontainers)

**Objectif** : valider la communication réelle entre composants, sur un environnement éphémère.

- Outil : **[[testcontainers]]** Python (préféré) ou `docker-compose -f docker-compose.test.yml`
- Démarre des containers réels : Postgres, Redis, Qdrant, MinIO, etc.
- Cleanup automatique en fin de test
- Convention : `tests/integration/test_<feature>.py`
- Marquer pour exclure du run unitaire : `@pytest.mark.integration`
- CI : run séparément (plus lent), peut tourner sur PR ou nightly

```python
# Exemple : testcontainers Postgres
import pytest
from testcontainers.postgres import PostgresContainer

@pytest.fixture(scope="session")
def postgres():
    with PostgresContainer("postgres:16") as pg:
        yield pg.get_connection_url()

def test_user_creation(postgres):
    # ici on a une vraie DB, on insère, on vérifie, le container disparaît après
    ...
```

Containers types fréquents :
- `PostgresContainer`
- `RedisContainer`
- `MinioContainer` (ou `S3Container`)
- `QdrantContainer` (custom via `DockerContainer`)
- `KafkaContainer`

### 3. Évaluation IA — LLM-as-a-Judge (si système RAG/LLM)

**Objectif** : mesurer **mathématiquement** la qualité des réponses du système IA.

Frameworks supportés :
- **[[Ragas]]** — spécialisé RAG (faithfulness, context_precision/recall, answer_relevancy)
- **[[DeepEval]]** — généraliste, pytest-style (`assert_test`)
- **[[TruLens]]** — feedback functions, observability + eval

**Métriques minimum à tracker** (RAG) :
- **Faithfulness** : la réponse est-elle fidèle au contexte récupéré
- **Answer Relevancy** : la réponse est-elle pertinente vs la question
- **Context Precision** : les chunks pertinents sont-ils en tête du retrieval
- **Context Recall** : tous les chunks utiles sont-ils récupérés (besoin d'un ground truth)

**Workflow** :
- Dataset d'eval versionné dans `tests/eval/dataset.json`
- Run d'eval en CI sur dataset d'eval (rapide, < 5 min) + nightly sur dataset complet
- Comparaison vs baseline : alerter si dégradation > 5% sur une metric clé

```python
# Exemple Ragas (simplifié)
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy, context_precision

def test_rag_quality(eval_dataset):
    results = evaluate(
        dataset=eval_dataset,
        metrics=[faithfulness, answer_relevancy, context_precision],
    )
    assert results["faithfulness"] >= 0.85
    assert results["answer_relevancy"] >= 0.80
```

## SHOULD

- **Tests E2E** (end-to-end) sur les workflows critiques (login → action → assertion)
- **Tests de charge** (locust, k6) pour les APIs publiques
- **Tests de régression** sur les outputs LLM "golden" (test cases dont la réponse attendue est figée)
- **Property-based testing** (`hypothesis`) sur la logique métier complexe
- **Coverage `> 85%`** sur la logique métier critique (pas un objectif aveugle)

## NICE

- **Mutation testing** (`mutmut`, `cosmic-ray`) pour valider la qualité des tests
- **Snapshot testing** pour les outputs structurés
- **Performance regression tests** : asserter que les latences ne dégradent pas

## Structure recommandée

```
mon-projet/
├── tests/
│   ├── unit/                    ← rapides, mockés
│   │   ├── test_classify.py
│   │   └── ...
│   ├── integration/             ← testcontainers
│   │   ├── test_db.py
│   │   ├── test_qdrant.py
│   │   └── ...
│   ├── eval/                    ← LLM eval
│   │   ├── dataset.json         ← ground truth (versionné !)
│   │   ├── test_rag_quality.py
│   │   └── ...
│   ├── e2e/                     ← optionnel
│   │   └── ...
│   └── conftest.py              ← fixtures partagées
├── pyproject.toml               ← config pytest
└── .github/workflows/
    ├── tests-unit.yml           ← run sur tout PR
    ├── tests-integration.yml    ← run sur PR vers main
    └── tests-eval.yml           ← nightly
```

## Pièges classiques

- **Tests qui dépendent de l'ordre** → flaky
- **Tests qui dépendent du réseau** → flaky (mock ou containers)
- **Coverage 100% comme objectif** → on teste les getters, pas la logique
- **Pas de cleanup containers** → docker plein
- **Eval LLM non-déterministe** : `temperature=0` du judge + cache nécessaires
- **Dataset d'eval qui dérive** : à versionner et review comme du code
- **Tests qui ne plantent jamais** : un test qui passe toujours est suspect

## Outils recommandés

- `pytest`, `pytest-asyncio`, `pytest-mock`, `pytest-cov`
- [[testcontainers]] Python
- `httpx-mock` ou `responses` (HTTP mocks)
- [[Ragas]], [[DeepEval]], [[TruLens]] (eval LLM)
- `hypothesis` (property-based)

## Voir aussi

- [[README - Service]] — chaque service décrit comment il est testé
- [[Config-Env]] — `.env.test` pour les tests d'intégration
- `Rules/Global/Tests.md` — règles globales de tests (cf. règle parente s'il existe)
- [[testcontainers]], [[Ragas]], [[DeepEval]], [[TruLens]] — fiches Services
