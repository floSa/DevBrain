---
galaxie: dev
nom: Flyte
alias: [flyte, flytekit]
categorie: ml/orchestration
sous_categories: [kubernetes-native, typed, pipelines, scalable]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Go (Python SDK)
clients_officiels: [python, java, ts]
plateforme: [linux]
score: 
mes_projets: []
alternatives: ["[[Kubeflow]]", "[[ZenML]]", "[[Metaflow]]", "[[Airflow]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ml, orchestration, kubernetes, typed]
url_officiel: https://flyte.org/
url_docs: https://docs.flyte.org/
url_repo: https://github.com/flyteorg/flyte
---

# Flyte

## Pourquoi
Plateforme MLOps **K8s-native** créée chez Lyft. **Types stricts** Python sur les inputs/outputs (vrai compile-time check), versioning automatique, exécution distribuée, caching agressif, multi-tenancy enterprise. Très solide en prod, moins de hype que Kubeflow.

## Quand l'utiliser
- Stack K8s avec besoin de pipelines ML/data très fiables
- Importance forte des types et de la reproductibilité
- Multi-tenant grosse scale (équipes multiples isolées)
- Workflows longue durée (jours/semaines) avec checkpointing
- Caching de tasks coûteux (résultats partagés)

## Quand NE PAS l'utiliser
- Pas de K8s → setup lourd
- Equipe "DS-first" sans devops → [[Metaflow]] / [[ZenML]] sont plus accessibles
- Workflows simples → [[Dagster]] / [[Prefect]] suffisent

## Pièges connus
- **Installation** : Flyte sandbox pour dev OK, prod nécessite K8s + Postgres + S3
- **Plugins** : nombreux (Spark, Ray, Dask, MPI…) mais à configurer
- **Types Python** : `@task` vérifie les types runtime — à respecter
- **Versioning** : chaque modif de code = nouvelle version, à comprendre
- **Caching** : agressif par défaut, désactiver si tâches non-déterministes
- **Union (managed)** : société commerciale derrière Flyte, offre cloud
- **flytekit vs flytectl** : SDK Python vs CLI

## Liens
- [[Kubeflow]], [[Metaflow]], [[ZenML]] — alternatives
- Union.ai (managed) : https://www.union.ai/
- Plugins : https://docs.flyte.org/en/latest/flytesnacks/integrations.html
- Quickstart : https://docs.flyte.org/en/latest/quickstart_guide.html
