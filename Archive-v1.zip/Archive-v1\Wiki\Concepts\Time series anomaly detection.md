---
galaxie: wiki
nom: Time series anomaly detection
alias: [TS anomaly, outlier detection, change point, novelty, drift]
type: concept
categorie: concept/time-series
sous_categories: [anomaly-detection, change-point, outlier, time-series]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Tukey, Twitter (Seasonal-Hybrid ESD), Microsoft (SR), Facebook (Prophet)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, time-series, anomaly-detection, monitoring]
---

# Time series anomaly detection

## TL;DR

Détecter dans une série temporelle des **points anormaux** (spike, dip), des **change points** (changement de régime), ou de la **drift** (dérive lente). Trois familles : **statistique** (z-score, IQR, Tukey, ESD, EWMA), **basée modèle** (résidus d'ARIMA/Prophet, STL decomposition + 3-sigma), **ML/DL** (Isolation Forest, autoencoders, LSTM-based). Cas d'usage : monitoring infrastructure, fraud detection, manufacturing quality, anomalies métriques produit. Standard chez Microsoft (SR-CNN), Twitter (AnomalyDetection), Meta (Prophet outliers).

## Le problème

Comment détecter qu'un point dans une série est **anormal** en tenant compte :
- De la **tendance**
- De la **saisonnalité**
- Des **dépendances temporelles**
- De la **distribution** sous-jacente
- Sans trop de **faux positifs** ?

Et distinguer :
- **Point anomaly** : 1 point isolé
- **Contextual anomaly** : normal en absolu, anormal en contexte
- **Change point** : changement de régime (mean, variance shift)
- **Drift** : évolution lente

## L'idée

### 1. Méthodes statistiques simples

#### Z-score / 3-sigma

$$ |z_t| = \left|\frac{y_t - \mu}{\sigma}\right| > 3 $$

- Suppose distribution gaussienne stationnaire
- Inutilisable directement sur série avec tendance / saisonnalité
- Application : **sur les résidus** après décomposition

#### IQR / Tukey fence

$$ y_t \notin [Q_1 - 1.5 \cdot \text{IQR}, Q_3 + 1.5 \cdot \text{IQR}] $$

- Robust aux outliers (vs z-score)
- Idem : sur résidus

#### ESD (Extreme Studentized Deviate)

Generalized ESD test (Rosner 1983) : détecte jusqu'à $k$ outliers avec test itératif. **Seasonal Hybrid ESD** (Twitter) : applique ESD sur résidus après STL decomposition. Très utilisé.

#### Moving average / EWMA

$$ z_t = \frac{y_t - \bar y_t^{w}}{\sigma_t^w} $$

avec rolling window. EWMA (exponentially weighted) : poids exponentiels.

Standard pour **control charts** industriels (Shewhart, EWMA chart, CUSUM).

### 2. Decomposition-based

Décomposer la série en **trend + seasonality + remainder**, détecter sur **remainder**.

Méthodes de décomposition :
- **STL** (Seasonal-Trend decomposition using LOESS, Cleveland 1990)
- **MSTL** (multi-saisons)
- **X-11, SEATS** (méthodes officielles, INSEE)
- **Prophet** decomposition

Puis : 3-sigma / IQR / ESD sur le remainder.

### 3. Model-based (résidus de forecast)

Fitter un modèle (ARIMA, Prophet, ETS, LSTM), puis :

$$ \varepsilon_t = y_t - \hat y_t $$

Anomalie si $|\varepsilon_t|$ > seuil (e.g. 3-sigma sur les résidus, ou hors intervalle de prédiction).

**Avantage** : capture trend + saisonnalité naturellement.

Prophet implem directement : tout point hors `yhat_lower`/`yhat_upper` = potential anomaly.

### 4. Distance-based

#### k-NN distance

Pour chaque point, distance au k-ième plus proche voisin. Outliers = grandes distances.

#### LOF (Local Outlier Factor)

Comparer densité locale à celle des voisins. Robuste à la densité variable.

### 5. Isolation Forest

Liu et al. (2008). Construire un ensemble d'arbres qui **isolent** chaque point. Les outliers sont isolés en peu de splits.

- Standard, marche bien en haute dim
- Pas spécifique TS mais utile sur features temporelles (lags, rolling stats)

### 6. Autoencoders / Deep Learning

#### Reconstruction-based

Train autoencoder pour reconstruire des fenêtres normales. Erreur de reconstruction grande → anomalie.

- LSTM autoencoder
- Transformer autoencoder
- Conv-AE pour multi-variate

#### Forecasting-based (DL)

LSTM / Transformer forecaster → résidus → anomalie.

#### Adversarial (GAN, VAE)

GAN-based anomaly detection (AnoGAN, USAD). Standard en research.

### 7. Spectral / signal processing

#### SR (Spectral Residual, Microsoft 2019)

Algorithme de la vision par ordinateur appliqué aux TS :
1. FFT de la série
2. Spectral residual = log spectrum - moving average
3. Inverse FFT → saliency map
4. Threshold pour anomalies

Standard chez Microsoft (Azure Anomaly Detector). Rapide et efficace.

#### Wavelet transform

Décomposer en fréquences, anomalies dans certaines bandes.

### 8. Change point detection

Différent des outliers : **changement de distribution** persistant.

#### CUSUM (Cumulative Sum)

$$ S_t = \max(0, S_{t-1} + (y_t - \mu_0 - k)) $$

Alarme si $S_t > h$. Standard, robuste.

#### Bayesian Online Changepoint Detection (Adams & MacKay 2007)

Probabilité de changepoint à chaque instant. État de l'art.

#### Pelt, Binseg (ruptures library)

Algos pour offline change point detection sur batch.

#### Page-Hinkley

Pour monitoring streaming.

### Anomaly types — récap

| Type | Description | Méthode |
|---|---|---|
| **Point anomaly** | 1 point isolé | z-score sur résidus, IF |
| **Contextual** | normal en absolu, anormal en contexte | model-based (forecast residuals) |
| **Collective** | séquence anormale | autoencoder window-based |
| **Change point** | shift de régime | CUSUM, BOCD, ruptures |
| **Drift** | évolution lente | EWMA, KS test sur fenêtres |

### Évaluation

Sur dataset labelisé :
- **Precision / Recall / F1** sur anomalies
- **Range-based F1** (Tatbul et al. 2018) : récompense detection même partielle d'un range
- **Point-adjust F1** : si une anomalie dans un range est détectée, tout le range compte (controversé : trop généreux)
- **AUROC / AUPRC** sur scores d'anomalie

**Benchmarks** : UCR, NAB (Numenta), MSL (NASA), SMD.

### Best practices

1. **Toujours décomposer** d'abord : si saisonnalité présente, 3-sigma direct est inutile
2. **Définir clairement** : point anomaly vs change point vs drift — méthodes différentes
3. **Threshold business** : sensitivity (recall) vs noise (faux positifs) — coût asymétrique
4. **Cold start** : les premiers points sont des "anomalies" car peu de data — masquer
5. **Évaluation labelisée difficile** : anomalies par définition rares, label coûteux
6. **Online vs offline** : streaming demande algos incrémentaux (BOCD, Page-Hinkley)
7. **Multi-variate** : corrélations entre métriques importantes (e.g. CPU + memory monté simultanément)

## Quand c'est utile

- **Monitoring infrastructure** : Datadog, New Relic alerts
- **Fraud detection** : transactions anormales, behavioral patterns
- **Manufacturing QC** : control charts, defect rates
- **Application monitoring** : latence p99, error rate
- **IoT / sensors** : équipement défaillant
- **Cybersecurity** : intrusion detection, baseline déviations
- **Business metrics** : DAU/MAU drops, revenue spikes
- **Network traffic** : DDoS, anomalies
- **Medical** : ECG anomalies, sepsis prediction

## Quand ça ne marche pas / pièges

- **Saisonnalité ignorée** : weekend → "anomalie" tous les samedis. Décomposer d'abord.
- **Concept drift** : la "normalité" évolue → modèle vieillit, faux positifs. Recalibrer périodiquement.
- **Évents rares** : trop peu pour modéliser → tout devient "anomaly".
- **Concept anomaly subtile** : un drift lent passe sous 3-sigma. Utiliser CUSUM ou EWMA.
- **Faux positifs** : trop d'alarmes = alarmes ignorées. Calibrer threshold business.
- **Confondre point anomaly et noise** : sur série bruyante, séparer outlier vs noise extrême
- **Train-test contamination** : entraîner sur data avec anomalies → modèle apprend à les "reconstruire". Cleaner train d'abord.
- **Évaluation sans label** : benchmarks artificiels souvent peu réalistes. Validation difficile.
- **Univarié sur multi-var** : corrélations importantes loupées en univarié. Multi-var demande méthodes dédiées.
- **Range-based vs point-based metrics** : pas comparables, préciser dans reports.

## Code minimal

```python
import numpy as np
import pandas as pd
from statsmodels.tsa.seasonal import STL
from sklearn.ensemble import IsolationForest

# Setup : série journalière avec saisonnalité + 3 anomalies
np.random.seed(0)
t = np.arange(365)
y = 50 + 10 * np.sin(2 * np.pi * t / 30) + np.random.normal(0, 2, 365)
y[100] = 200  # spike
y[200] = -50  # dip
y[300] = 150  # spike

# 1. Décomposition STL + 3-sigma sur résidus
stl = STL(pd.Series(y), period=30).fit()
residuals = stl.resid
threshold = 3 * residuals.std()
anomalies_stl = np.abs(residuals) > threshold
print(f"STL+3σ: {anomalies_stl.sum()} anomalies détectées")
print(f"  Positions: {np.where(anomalies_stl)[0]}")

# 2. Isolation Forest sur features rolling
df = pd.DataFrame({'y': y})
df['rolling_mean'] = df['y'].rolling(7).mean()
df['rolling_std'] = df['y'].rolling(7).std()
df['lag_1'] = df['y'].shift(1)
df = df.dropna()

iso = IsolationForest(contamination=0.01, random_state=0)
df['anomaly_iso'] = iso.fit_predict(df) == -1
print(f"IF: {df['anomaly_iso'].sum()} anomalies détectées")

# 3. Prophet (decomposition + intervalles)
# from prophet import Prophet
# df_p = pd.DataFrame({'ds': pd.date_range('2024-01-01', periods=365), 'y': y})
# m = Prophet(interval_width=0.99)
# m.fit(df_p)
# forecast = m.predict(df_p)
# anomalies_prophet = (df_p['y'] < forecast['yhat_lower']) | (df_p['y'] > forecast['yhat_upper'])

# 4. CUSUM pour change points
def cusum(y, target=None, k=0.5, h=5):
    if target is None:
        target = y.mean()
    n = len(y)
    s_pos = np.zeros(n)
    s_neg = np.zeros(n)
    for i in range(1, n):
        s_pos[i] = max(0, s_pos[i-1] + (y[i] - target - k))
        s_neg[i] = min(0, s_neg[i-1] + (y[i] - target + k))
    return s_pos, s_neg

s_pos, s_neg = cusum(y, target=50, k=2, h=10)
cp = np.where((s_pos > 10) | (s_neg < -10))[0]
print(f"CUSUM: {len(cp)} alertes")

# 5. ruptures pour offline change point detection
import ruptures as rpt
model = rpt.Pelt(model="rbf").fit(y)
change_points = model.predict(pen=10)
print(f"Pelt: changepoints à positions {change_points[:-1]}")

# 6. ESD test pour outliers multiples
from scipy import stats
def gesd(y, alpha=0.05, max_outliers=5):
    """Generalized ESD test."""
    outliers = []
    y_work = y.copy().astype(float)
    for i in range(max_outliers):
        mean = np.nanmean(y_work)
        std = np.nanstd(y_work, ddof=1)
        residuals = np.abs(y_work - mean) / std
        idx = np.nanargmax(residuals)
        R = residuals[idx]
        n = (~np.isnan(y_work)).sum()
        t = stats.t.ppf(1 - alpha / (2 * n), n - 2)
        crit = ((n - 1) * t) / np.sqrt((n - 2 + t**2) * n)
        if R > crit:
            outliers.append(idx)
            y_work[idx] = np.nan
        else:
            break
    return outliers

print(f"ESD: outliers aux positions {gesd(y, max_outliers=10)}")
```

## Pour aller plus loin

- Chandola, Banerjee, Kumar, *Anomaly Detection: A Survey* (ACM CSUR 2009) — référence
- Aggarwal, *Outlier Analysis* (Springer 2017) — bible
- Twitter AnomalyDetection R/Python — Seasonal Hybrid ESD
- Microsoft *Time-Series Anomaly Detection Service at Microsoft* (KDD 2019) — SR-CNN
- Numenta, *NAB benchmark* — datasets et metrics
- Adams & MacKay, *Bayesian Online Changepoint Detection* (2007)
- **Liens internes** : [[Stationarity]], [[Autocorrelation]], [[ARIMA SARIMA]], [[Data drift]], [[Time series feature engineering]]
