---
galaxie: wiki
nom: Generalization bounds
alias: [bornes de généralisation, generalization gap, PAC-Bayes bounds, uniform convergence]
type: concept
categorie: concept/learning-theory
sous_categories: [generalization, bounds, uniform-convergence, pac-bayes, double-descent]
domaines: [ml-eng]
maturite: established
auteurs_cles: [Vapnik, Bartlett, McAllester, Belkin]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, learning-theory, generalization-bounds]
---

# Generalization bounds — bornes de généralisation

## TL;DR

Inégalités théoriques de la forme **$R_{\text{test}}(h) \leq R_{\text{train}}(h) + \text{complexity}(\mathcal{H}, n)$** : majorent l'erreur de test en fonction de l'erreur d'entraînement plus une "pénalité de complexité". 3 grandes familles : **VC bounds** (Vapnik), **Rademacher bounds** (Bartlett), **PAC-Bayes** (McAllester). Pour DL sur-paramétré, les bornes classiques sont **vacuous** — d'où le mystère "**double descent**" et la recherche actuelle.

## Le problème

Un modèle apprend sur $n$ échantillons. Son erreur de train est $\hat R$. Quelle erreur attendre sur des données neuves ? Quelle confiance ?

Les bornes de généralisation formalisent cette question et fournissent des **garanties théoriques** (souvent lâches).

## L'idée

### Cadre général

$$ R(h) \leq \hat R(h) + \text{terme de complexité}(\mathcal{H}, n, \delta) $$

avec probabilité $\geq 1 - \delta$ sur le tirage de l'échantillon. Le terme de complexité dépend de :
- **Classe d'hypothèses** $\mathcal{H}$ (sa "richesse")
- **Taille d'échantillon** $n$ (décroît typiquement en $1/\sqrt{n}$)
- **Confiance souhaitée** $1 - \delta$

### Famille 1 — VC bounds

Cf. [[VC dimension]]. Forme typique :

$$ R(h) \leq \hat R(h) + O\left(\sqrt{\frac{\text{VC}(\mathcal{H}) \log n}{n}}\right) $$

**Avantages** : universelles, simples.
**Inconvénients** : pessimistes, vacuous pour NN modernes.

### Famille 2 — Rademacher bounds

Cf. [[Rademacher complexity]]. Forme :

$$ R(h) \leq \hat R(h) + 2 \mathfrak{R}_n(\mathcal{H}) + O\left(\sqrt{\frac{\log(1/\delta)}{n}}\right) $$

**Avantages** : data-dependent, plus tight que VC.
**Inconvénients** : encore lâche pour NN sur-paramétrés.

### Famille 3 — PAC-Bayes

Cf. [[PAC learning]]. Pour un prior $P$ et un posterior $Q$ sur $\mathcal{H}$ :

$$ \mathbb{E}_{h \sim Q}[R(h)] \leq \mathbb{E}_{h \sim Q}[\hat R(h)] + \sqrt{\frac{D_{\text{KL}}(Q \| P) + \log(1/\delta)}{2n}} + o(1) $$

**Bornes non-vacuous pour DL** quand $P$ est bien choisi (e.g. distribution à l'initialisation, $Q$ autour des poids appris). Dziugaite-Roy 2017 : premières bornes non-vacuous sur MNIST avec NN.

### Famille 4 — Norm-based (Bartlett-Foster-Telgarsky)

Pour les NN, bornes basées sur produit des normes des matrices de poids :

$$ R(h) \lesssim \hat R(h) + \frac{\prod_l \|W_l\|}{\sqrt{n}} \cdot O(\text{depth}) $$

Plus pertinent que VC pour NN — explique pourquoi weight decay aide la généralisation.

### Famille 5 — Information-theoretic

Xu-Raginsky 2017, Russo-Zou 2016 : la généralisation est bornée par l'**information mutuelle** entre les poids appris et les données :

$$ \mathbb{E}[R - \hat R] \leq \sqrt{\frac{\sigma^2 I(W ; S)}{2n}} $$

avec $W$ poids, $S$ échantillon. Intuition : si le modèle "absorbe" peu d'info sur les données spécifiques, il généralise.

### Double descent — la grosse anomalie

Les bornes classiques disent : capacité ↗ → généralisation ↘.

Mais en pratique, **double descent** (Belkin 2019, Nakkiran 2020) :

```
test error
 ↑                  ↑
 |                 / \
 |                /   \________
 |               /              \
 |              ↗   plateau     ↘ descente moderne
 |   classical /                    \
 |   "U curve"                       ↘
 |__/_________________________________→
    sous-paramétré | interpolation | sur-paramétré
                     threshold
```

**Phase 1** (sous-paramétré) : U-shape classique (bias-variance)
**Phase 2** (interpolation, capacity = n) : pic d'erreur — la classe est trop "juste" pour interpoler
**Phase 3** (sur-paramétré) : **erreur redescend** !

Explications :
- Implicit bias de SGD vers solutions à norme minimale
- Loss landscape "amical" en sur-paramétré
- Phénomène de "feature learning" qui sépare bonnes/mauvaises features

→ Les bornes classiques **n'expliquent pas** cette phase 3. Recherche actuelle très active.

### Pourquoi les NN généralisent malgré tout

Hypothèses qui s'accumulent :
1. **Implicit regularization** de SGD (minimum norm solutions)
2. **Margin maximisation** (comme SVM)
3. **Norme des poids contrôlée** par init + weight decay
4. **Mutual information faible** entre poids et données spécifiques
5. **Architectures à biais inductifs forts** (convolutions, attention, skip connections)

Aucune théorie unifiée. Chaque framework explique une partie.

## Quand c'est utile

- **Audit ML / certification** : fournir des garanties théoriques
- **Justifier la régularisation** : weight decay réduit la borne via norm-based bound
- **Comprendre pourquoi le DL marche** : avoir les bonnes intuitions sans tomber dans la pensée magique
- **Choisir entre modèles à risque empirique égal** : préférer celui avec complexité plus basse
- **Diagnostic d'overfitting** : grand gap $R - \hat R$ → modèle trop complexe pour les données

## Quand ça ne marche pas / pièges

- **Bornes vacuous** (≥ 1) sur DL non régularisé → inutiles pour conclure
- **Choix du prior** PAC-Bayes critique : un prior "facile" donne bornes lâches
- **Ne pas confondre** borne théorique avec erreur empirique sur held-out — la borne est une certitude probabiliste, le test empirique une estimation
- **Distribution shift** : aucune borne classique ne couvre ça. Domain adaptation est un domaine à part.
- **Application pratique limitée** : la plupart des bornes restent théoriques. Cross-validation reste l'outil empirique principal.
- **Double descent ignoré** : croire encore au "U-curve" classique pour expliquer le DL → manque la moitié de l'histoire

## Code minimal

```python
import numpy as np
import matplotlib.pyplot as plt

# Illustration double descent — Belkin et al.
# Polynomial de degré croissant sur peu de points
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

np.random.seed(0)
n = 30
X = np.random.uniform(-1, 1, n).reshape(-1, 1)
y = np.sin(np.pi * X.ravel()) + 0.1 * np.random.randn(n)

X_test = np.linspace(-1, 1, 100).reshape(-1, 1)
y_test = np.sin(np.pi * X_test.ravel())

train_errs, test_errs = [], []
degrees = list(range(1, 50))
for d in degrees:
    poly = PolynomialFeatures(degree=d, include_bias=False)
    X_poly = poly.fit_transform(X)
    X_test_poly = poly.transform(X_test)
    
    # Avec min-norm solution (pseudo-inverse, ~SGD biased)
    w, *_ = np.linalg.lstsq(X_poly, y, rcond=None)
    
    train_err = mean_squared_error(y, X_poly @ w)
    test_err = mean_squared_error(y_test, X_test_poly @ w)
    train_errs.append(train_err)
    test_errs.append(test_err)

plt.figure(figsize=(8, 4))
plt.semilogy(degrees, train_errs, label='train')
plt.semilogy(degrees, test_errs, label='test')
plt.axvline(n, color='gray', ls='--', label='n (interpolation threshold)')
plt.xlabel('Polynomial degree (capacity)')
plt.ylabel('MSE (log)')
plt.legend()
# Observer le pic à degré ~ n, puis la descente
```

## Pour aller plus loin

- Vapnik, *The Nature of Statistical Learning Theory* (1995) — référence VC bounds
- Bartlett & Mendelson, *Rademacher and Gaussian Complexities: Risk Bounds and Structural Results* (JMLR 2002)
- McAllester, *PAC-Bayesian Model Averaging* (COLT 1999)
- Belkin et al., *Reconciling modern machine-learning practice and the classical bias-variance trade-off* (PNAS 2019) — double descent
- Nakkiran et al., *Deep Double Descent: Where Bigger Models and More Data Hurt* (2020)
- **Liens internes** : [[VC dimension]], [[PAC learning]], [[Rademacher complexity]], [[No Free Lunch theorem]], [[Bias-variance tradeoff]], [[Regularization]]
