---
galaxie: dev
nom: CatBoost
alias: [cb, Categorical Boosting]
categorie: ml/framework
sous_categories: [gradient-boosting, supervised, tabular, categorical, yandex]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: C++
clients_officiels: [python, r, java]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[XGBoost]]", "[[LightGBM]]"]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, ml, gradient-boosting, supervised, tabular, yandex]
url_officiel: https://catboost.ai/
url_docs: https://catboost.ai/docs/
url_repo: https://github.com/catboost/catboost
---

# CatBoost

## Pourquoi

Gradient boosting de **Yandex** spécialisé sur le **traitement natif et de qualité des variables catégorielles**. Différences principales avec [[XGBoost]] et [[LightGBM]] :
- **Target encoding ordered** (innovation CatBoost) : encoding catégoriel sans target leakage, en ligne ordonnée → meilleurs résultats out-of-the-box sur datasets riches en catégoriel
- **Symmetric trees** par défaut (arbres équilibrés, oblique) → plus stables, prédictions plus rapides en inference
- **Bonnes valeurs par défaut** : nécessite très peu de tuning pour avoir un baseline solide
- **GPU** mature

Souvent **le meilleur sur datasets avec beaucoup de catégoriel** ou texte features.

## Quand l'utiliser

- **Beaucoup de catégoriel haute cardinalité** (city, product_id, user_id…)
- Tu veux un baseline ultra-rapide sans tuning
- Texte features ([[CatBoost]] gère natif avec embeddings simples)
- Pipeline avec multi-types : continu + catégoriel + texte
- Compétitions ML avec catégoriel dominant
- Inference temps réel critique (symmetric trees très rapides)

## Quand NE PAS l'utiliser

- Datasets 100% continus → [[XGBoost]] ou [[LightGBM]] sont équivalents et plus communs
- Très gros datasets (≥10M lignes) sur CPU → [[LightGBM]] souvent plus rapide en entraînement
- Tu connais déjà XGBoost et le catégoriel est minoritaire → effort de migration injustifié
- Documentation et communauté plus petites qu'XGBoost (compromis)

## Pièges connus

- **`cat_features`** doit être passé explicitement à `fit()` — sinon les colonnes catégorielles sont traitées comme numériques (catastrophe)
- **Index de colonne vs nom** : `cat_features=['country']` ou `cat_features=[5]`, pas mélange
- **Très petit dataset** : ordered boosting overhead → CatBoost moins compétitif que LightGBM
- **Memory hungry** sur catégoriel haute cardinalité — surveiller la RAM
- **API tricky** : `Pool` object recommandé pour gros datasets (vs DataFrame direct), apprentissage à faire
- **GPU** beaucoup plus rapide mais bloquant pour le debugging → développer en CPU, déployer en GPU
- **Pas de `early_stopping` par défaut** dans certaines APIs — toujours setter `od_type='Iter'` + `od_wait`

## Liens

- Doc officielle : https://catboost.ai/docs/
- Repo : https://github.com/catboost/catboost
- Paper : Prokhorenkova et al., *CatBoost: unbiased boosting with categorical features* (NeurIPS 2018)
- Concepts liés : [[Ensembling]] (boosting), [[Bias-variance tradeoff]], [[Regularization]], [[Cross-validation]]
- Alternatives : [[XGBoost]] (référence historique), [[LightGBM]] (vitesse pure)
- [[Optuna]] (tuning hyperparams)
