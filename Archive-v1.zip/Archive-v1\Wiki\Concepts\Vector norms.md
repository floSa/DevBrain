---
galaxie: wiki
nom: Vector norms
alias: [normes vectorielles, L1, L2, L-infinity, Frobenius, nuclear, Mahalanobis]
type: concept
categorie: concept/linalg
sous_categories: [norms, l1, l2, frobenius, mahalanobis]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: []
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, linalg, norms]
---

# Vector norms — Normes vectorielles et matricielles

## TL;DR

Mesures de **"taille"** d'un vecteur ou d'une matrice. Choix omniprésent en ML : **L2** (euclidienne) par défaut, **L1** pour sparse / robustesse, **L∞** pour max, **Frobenius** pour matrices générales, **Mahalanobis** pour distance pondérée par covariance. Le choix de norme **change radicalement** le comportement (Ridge vs Lasso, KNN, optimisation).

## Le problème

"Combien grand est ce vecteur ?" Plusieurs réponses raisonnables selon le contexte :
- "Somme des valeurs absolues" → L1
- "Magnitude euclidienne" → L2
- "Plus grande coordonnée" → L∞

Chacune a des propriétés différentes (géométrie, dérivabilité, robustesse) qui dictent son usage.

## L'idée

### Famille des normes $L_p$

Pour un vecteur $x \in \mathbb{R}^n$ et $p \geq 1$ :

$$ \|x\|_p = \left( \sum_{i=1}^n |x_i|^p \right)^{1/p} $$

Cas particuliers :

| Norme | Formule | Boule unité |
|---|---|---|
| **L₁** (Manhattan, taxicab) | $\sum_i \|x_i\|$ | losange |
| **L₂** (Euclidienne) | $\sqrt{\sum_i x_i^2}$ | cercle |
| **L∞** (Chebyshev, max) | $\max_i \|x_i\|$ | carré |
| **L₀** (∗ pas une vraie norme) | nombre d'éléments non-nuls | (non-convexe) |

### Propriétés d'une norme

Une norme satisfait :
1. **Positivité** : $\|x\| \geq 0$, $\|x\| = 0 \Leftrightarrow x = 0$
2. **Homogénéité** : $\|\alpha x\| = |\alpha| \|x\|$
3. **Inégalité triangulaire** : $\|x + y\| \leq \|x\| + \|y\|$

L₀ viole l'homogénéité (donc pas une vraie norme), mais utilisée par abus de langage.

### Inégalités utiles

- **Cauchy-Schwarz** : $|x^\top y| \leq \|x\|_2 \|y\|_2$
- **Hölder** : $|x^\top y| \leq \|x\|_p \|y\|_q$ avec $1/p + 1/q = 1$
- **Équivalences** : $\|x\|_\infty \leq \|x\|_2 \leq \|x\|_1 \leq \sqrt{n} \|x\|_2 \leq n \|x\|_\infty$

### Normes matricielles

Pour $A \in \mathbb{R}^{m \times n}$ :

#### Frobenius

$$ \|A\|_F = \sqrt{\sum_{i,j} A_{ij}^2} = \sqrt{\text{tr}(A^\top A)} = \sqrt{\sum_i \sigma_i^2} $$

Norme L₂ "appliquée à la matrice aplatie". La plus utilisée en pratique.

#### Spectrale (L₂ matricielle, induite)

$$ \|A\|_2 = \sigma_1 = \max_{\|x\|=1} \|Ax\|_2 $$

= la plus grande valeur singulière. Mesure le "stretch maximum" de la transformation.

#### Nucléaire (trace norm)

$$ \|A\|_* = \sum_i \sigma_i $$

Somme des valeurs singulières. Utilisée pour **régularisation de rang faible** (matrix completion, Netflix challenge).

#### L₁ matricielle (induite)

$$ \|A\|_1 = \max_j \sum_i |A_{ij}| $$

Maximum de la somme par colonne.

### Distance de Mahalanobis

Distance euclidienne **pondérée par la covariance** :

$$ d_M(x, y) = \sqrt{(x - y)^\top \Sigma^{-1} (x - y)} $$

avec $\Sigma$ la matrice de covariance. Tient compte des **corrélations entre features** : 2 points proches sur un axe de faible variance sont "plus distants" que 2 points éloignés sur un axe de forte variance.

Cas particulier : si $\Sigma = I$, $d_M = $ distance euclidienne L₂.

Très utilisée en :
- Détection d'outliers
- Test du $\chi^2$ (Mahalanobis² $\sim \chi^2_n$ pour gaussienne)
- Classification (QDA)

## Quand c'est utile

| Norme | Cas d'usage typique |
|---|---|
| **L₁** | Lasso (sélection de features), robust regression, distance Manhattan en grid worlds, anomaly detection |
| **L₂** | Ridge regression, MSE loss, distance euclidienne pour KNN/clustering, weight decay |
| **L∞** | Adversarial robustness (perturbations bornées par L∞), worst-case bounds |
| **Frobenius** | Reconstruction error (matrix factorization), weight regularization en NN |
| **Nucléaire** | Matrix completion, low-rank constraints (relaxation convexe de rank) |
| **Mahalanobis** | Outlier detection multivariate, classification gaussienne |

## Quand ça ne marche pas / pièges

- **L₁ non-différentiable en 0** : subgradient methods ou proximal pour optim. Pas trivial mais standard.
- **L₂ amplifie les outliers** : remplace par L₁ ou Huber loss si robustesse souhaitée
- **L∞ très sensible aux valeurs extrêmes** : peu informatif sur les vecteurs typiques
- **Curse of dimensionality** : en haute dim, toutes les distances Lp deviennent **similaires** (concentration). Lp avec p < 1 peut mieux différencier mais n'est plus une norme.
- **Mahalanobis avec $\Sigma$ singulière** : pas inversible → utiliser pseudo-inverse ou régulariser ($\Sigma + \varepsilon I$)
- **Standardisation oubliée** : si features d'échelles très différentes, distances dominées par les features à grande variance. Toujours standardiser avant calcul de distance.
- **Confusion L₂ norme vs L₂ distance** : la **norme** est sur un vecteur ; la **distance L₂** entre deux points est $\|x - y\|_2$. Souvent confondues.

## Code minimal

```python
import numpy as np
from scipy.spatial.distance import mahalanobis, pdist

x = np.array([3, 4, -1])

# Normes Lp
print(f"L1   = {np.linalg.norm(x, ord=1):.3f}")   # 8.0
print(f"L2   = {np.linalg.norm(x, ord=2):.3f}")   # 5.099
print(f"Linf = {np.linalg.norm(x, ord=np.inf):.3f}")  # 4.0
print(f"L0   = {np.count_nonzero(x)}")             # 3 (pas une vraie norme)

# Normes matricielles
A = np.random.randn(5, 5)
print(f"Frobenius = {np.linalg.norm(A, ord='fro'):.3f}")
print(f"Spectrale = {np.linalg.norm(A, ord=2):.3f}")
print(f"Nucléaire = {np.linalg.norm(A, ord='nuc'):.3f}")

# Mahalanobis
X = np.random.randn(100, 5)
mu = X.mean(axis=0)
cov_inv = np.linalg.inv(np.cov(X.T))
x_test = np.array([1, 1, 1, 1, 1])
d_mahal = mahalanobis(x_test, mu, cov_inv)
print(f"Distance Mahalanobis: {d_mahal:.3f}")

# Régularisation Ridge (L2) vs Lasso (L1)
from sklearn.linear_model import Ridge, Lasso
ridge = Ridge(alpha=1.0)  # min || y - Xw ||² + α ||w||²
lasso = Lasso(alpha=1.0)  # min || y - Xw ||² + α ||w||₁
```

## Pour aller plus loin

- Strang, *Linear Algebra and Its Applications*
- Bertsekas, *Convex Optimization*
- **Liens internes** : [[SVD]] (donne valeurs singulières → normes matricielles), [[Eigendecomposition]], [[Regularization]] (Ridge/Lasso/ElasticNet), [[K-means]] / [[DBSCAN]] (utilisent des distances)
