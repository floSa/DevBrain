---
galaxie: wiki
nom: Prompt engineering
alias: [CoT, ToT, ReAct, self-consistency, self-refine, few-shot, prompting]
type: concept
categorie: concept/llm-inference
sous_categories: [prompting, cot, react, reasoning, llm]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Wei 2022 (CoT), Yao 2023 (ToT/ReAct), Wang 2023 (self-consistency)]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, prompting, reasoning]
---

# Prompt engineering

## TL;DR

Techniques pour **guider un LLM** sans fine-tuning. Familles : **base** (zero-shot, few-shot, role, format spec), **reasoning** ([[Chain-of-Thought]], ToT, self-consistency), **agentic** (ReAct, PAL/PoT, ART), **auto-amélioration** (self-refine, reflexion, self-critique), **optim auto** (APE, OPRO, DSPy). Standard moderne : commencer simple (clear instruction + format spec), ajouter CoT pour reasoning, sortir vers structured outputs ([[Structured outputs]]) ou agents ([[agent-loops]]) selon complexité. Bonne prompt > mauvais model. Plus on monte en gamme de model (Claude Opus, GPT-5), moins on a besoin de tricks — mais reasoning + few-shot restent gold standard.

## Le problème

Un LLM brut est puissant mais **non-spécifique**. Comment lui faire faire une tâche précise, fiable, format-conforme, sans fine-tuning ?

## L'idée

### Bases

#### Zero-shot

Juste poser la question :

```
Translate to French: "Hello world"
```

Marche pour tâches communes que le modèle a vues en pretraining.

#### Few-shot / in-context learning

Donner $k$ exemples (typ. 3-10) avant la vraie tâche :

```
EN: Hello → FR: Bonjour
EN: Thank you → FR: Merci
EN: Good morning → FR: Bon matin
EN: How are you? → FR:
```

**Powerful** : le modèle apprend le format, le style, des patterns nouveaux **sans retrain**.

#### Role prompting

```
You are an expert mathematician. Solve this problem step by step.
Problem: ...
```

Met le modèle dans un "mindset". Effet modéré, parfois utile.

#### System prompts

Section dédiée pour instructions persistantes :
- Role / persona
- Format de sortie attendu
- Contraintes (longueur, ton, refus de certains sujets)
- Tools disponibles

```
System: You are a helpful assistant. Respond in JSON.
User: What's the capital of France?
```

#### Format spec & delimiters

Encourager structure via **delimiters** (XML, triple quotes, JSON) :

```
<task>Summarize this article</task>
<article>...</article>
<output_format>
  - 3 bullet points
  - Max 50 words each
</output_format>
```

Anthropic recommande **XML tags**. OpenAI : triple quotes / sections markdown.

### Reasoning techniques

#### Chain-of-Thought (CoT, Wei 2022)

Forcer le modèle à **raisonner étape par étape** avant de répondre :

```
Q: Roger has 5 tennis balls. He buys 2 more cans, each with 3 balls. How many now?
A: Let me think step by step.
- Started with 5 balls
- Bought 2 cans × 3 balls = 6 balls
- Total : 5 + 6 = 11 balls
```

**Zero-shot CoT** : "Let's think step by step" (Kojima 2022).

**Few-shot CoT** : examples avec reasoning explicit.

Boost massif sur math, reasoning. **GSM8K**, MATH gains de 20-30 pts.

#### Self-Consistency (Wang 2023)

Sample $N$ CoT chains, vote majoritaire sur la réponse finale. Boost reasoning de 5-10 pts.

```python
answers = [llm(prompt, T=0.7) for _ in range(10)]
final = Counter([extract_answer(a) for a in answers]).most_common(1)[0][0]
```

#### Tree-of-Thoughts (ToT, Yao 2023)

Explorer **plusieurs branches** de reasoning, évaluer chacune, choisir la meilleure (DFS/BFS).

- Pour problèmes complexes (game of 24, puzzles)
- Plus coûteux que CoT
- Bénéfice marginal sur tasks moyennes

#### Skeleton-of-Thought / Plan-and-Solve

Outline first, then fill in detail :

```
1. Write outline
2. Develop each section
```

Bon pour réponses longues structurées.

#### Least-to-Most

Décomposer en sous-problèmes plus simples, résoudre du plus simple au plus complexe.

#### Step-back prompting

Avant de répondre, **abstraire** le problème :

```
Step back: What's the general principle here?
Then: Apply to specific case.
```

Améliore reasoning.

### Tool / Agent prompting

#### ReAct (Yao 2023)

Boucle **Reason + Act** :

```
Thought: I need to find X.
Action: search("X")
Observation: ...
Thought: Now I know X. I need Y.
Action: ...
...
Final Answer: ...
```

Voir [[agent-loops]].

#### PAL / PoT (Program-Aided / Program-of-Thought)

Au lieu de raisonner en texte, **écrire du Python** :

```
Q: Compute (47 * 23 + 11) / 5
A: 
```python
result = (47 * 23 + 11) / 5
```
```

Exécuter le code → réponse. Bypasse les erreurs arithmétiques du LLM.

### Auto-amélioration

#### Self-Refine (Madaan 2023)

Modèle critique sa propre réponse, puis révise :

```
1. Initial answer
2. Critique : qu'est-ce qui pourrait être mieux ?
3. Revised answer
```

#### Reflexion (Shinn 2023)

Pour agents : après échec, le modèle **réfléchit** à ce qui a mal tourné, mémorise pour la prochaine fois.

#### Self-Discover (Zhou 2024)

Modèle découvre lui-même la **structure de reasoning** appropriée pour la tâche.

#### Self-Verification (Weng 2022)

Modèle vérifie sa propre réponse en re-résolvant le problème depuis le résultat.

### Defense / Robustness

#### Sandwich defense

Mettre les **instructions** avant ET après le user input pour contrer prompt injection.

#### Spotlighting (Hines 2024)

Marquer le user input avec un délimiteur spécial unique, instruct le modèle de ne pas l'exécuter comme instruction.

#### Constitutional prompting

Inclure une "constitution" dans le system prompt qui guide / limite le comportement.

### Auto-optimisation de prompts

#### APE (Automatic Prompt Engineer, Zhou 2023)

LLM génère plusieurs prompts candidats, évalue chacun sur a dataset, retourne le meilleur.

#### OPRO (Optimization by PROmpting, Yang 2023)

LLM optimise ses propres prompts via gradient descent verbalisé.

#### DSPy (Khattab 2023)

**Compiler de prompts** : programmer un pipeline modulaire (Signatures + Modules), DSPy **optimise** automatiquement (MIPRO, BootstrapFewShot).

```python
class QA(dspy.Signature):
    """Answer a question."""
    question = dspy.InputField()
    answer = dspy.OutputField()

qa = dspy.ChainOfThought(QA)
qa(question="What's the capital?")
```

Standard moderne pour LLM apps complexes.

### Best practices

#### Anthropic Claude

- **XML tags** pour structurer
- **Examples** dans `<example>...</example>` tags
- **Prefill assistant** : forcer début de réponse (`<answer>`) pour faciliter parsing
- **Long context** : place document AVANT instruction
- **Chain of thought** : `<thinking>` tags

#### OpenAI GPT-4/5

- **System prompt** persistant
- **Markdown** ou JSON pour structure
- **Function calling** pour tool use
- **Few-shot** dans le system ou comme messages

#### Reasoning models (o1, R1)

- **Pas de CoT explicite** : modèle pense déjà internally
- **Prompt court et direct**
- **T=0 souvent suffisant**
- **Reasoning effort** : low / medium / high

### Strategy générale

```
1. Test zero-shot → souvent suffit
2. Si fail : ajouter format spec + role
3. Si encore : few-shot 3-5 examples
4. Si reasoning hard : CoT
5. Si tools needed : ReAct ou agent loop
6. Si format strict : Structured outputs (voir [[Structured outputs]])
7. Si production : DSPy ou prompt versioning
```

### Best practices générales

1. **Clear instruction** > clever prompt
2. **Format spec explicite** : "Return JSON with keys: ..."
3. **Examples > description** : montrer plutôt qu'expliquer
4. **Chain-of-Thought** pour reasoning : massive boost
5. **Self-consistency** pour critical tasks : 5-10 samples + vote
6. **Iterate empirically** : eval set + tune
7. **Version prompts** (Langfuse, LangSmith)
8. **Test edge cases** : input malformé, adversarial
9. **Test multi-model** : prompt qui marche sur GPT-4 ≠ Claude
10. **Caching prompts** : voir [[prompt-caching]]

## Quand c'est utile

- **MVP rapide** : prompt suffit pour 70% des cas
- **Non-recurring tasks** : moins cher que fine-tune
- **Exploration** : iterate fast sans GPU
- **Reasoning tasks** : CoT, self-consistency boost massif
- **Production simple** : structured output + clear instruction
- **Multi-step workflows** : ReAct, agents
- **Few-shot adaptation** : nouvelle tâche sans data
- **A/B testing** : multiple prompts in production

## Quand ça ne marche pas / pièges

- **Over-engineering** : trop de "tricks" peuvent dégrader. Test sans.
- **CoT sur small models** : peut hurt (model pas capable de reason longtemps)
- **Reasoning models + CoT explicit** : redondant, peut hurt
- **Few-shot biased** : examples non-représentatifs → biais
- **Order sensitivity** : few-shot order affecte output
- **Lost in the middle** : info au milieu du context ignorée (Liu 2023)
- **Prompt injection** : user input peut hijack instructions
- **Hallucinations** : pas résoluble par prompt seul, need RAG / tools
- **Math errors** : CoT aide mais pas magique. Utiliser PAL / code interpreter.
- **Prompt drift** : OpenAI/Anthropic models update, prompts régressent. Versionner et re-tester.
- **Eval set bias** : optimiser sur small eval set ≠ generalize
- **Token cost CoT** : long thinking = expensive

## Code minimal

```python
import anthropic
client = anthropic.Anthropic()

# 1. Zero-shot
def zero_shot(question):
    return client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=200,
        messages=[{"role": "user", "content": question}]
    ).content[0].text

# 2. Few-shot
def few_shot(question, examples):
    user_content = "\n\n".join([f"Q: {q}\nA: {a}" for q, a in examples])
    user_content += f"\n\nQ: {question}\nA:"
    return client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=200,
        messages=[{"role": "user", "content": user_content}]
    ).content[0].text

# 3. CoT
def cot(question):
    return client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=500,
        messages=[{
            "role": "user",
            "content": f"{question}\n\nLet's think step by step."
        }]
    ).content[0].text

# 4. Self-consistency
def self_consistent(question, n=10):
    answers = []
    for _ in range(n):
        response = client.messages.create(
            model="claude-3-7-sonnet-latest",
            max_tokens=300,
            temperature=0.7,
            messages=[{"role": "user", "content": f"{question}\n\nThink step by step. Final answer in <answer></answer> tags."}]
        )
        # Extract <answer>...</answer>
        text = response.content[0].text
        import re
        match = re.search(r"<answer>(.*?)</answer>", text)
        if match:
            answers.append(match.group(1).strip())
    
    from collections import Counter
    return Counter(answers).most_common(1)[0][0]

# 5. XML structuring (Anthropic style)
def xml_prompt(article):
    prompt = f"""<task>Summarize this article in 3 bullets.</task>

<article>
{article}
</article>

<output_format>
- Bullet 1: ...
- Bullet 2: ...
- Bullet 3: ...
</output_format>"""
    
    return client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=300,
        messages=[{"role": "user", "content": prompt}]
    ).content[0].text

# 6. Self-Refine
def self_refine(question, n_iter=2):
    answer = zero_shot(question)
    for _ in range(n_iter):
        critique_prompt = f"Question: {question}\n\nDraft answer: {answer}\n\nCritique this answer and improve it."
        answer = zero_shot(critique_prompt)
    return answer

# 7. DSPy
import dspy
dspy.configure(lm=dspy.LM("anthropic/claude-3-7-sonnet-latest"))

class MathSolver(dspy.Signature):
    """Solve math problems step by step."""
    problem = dspy.InputField()
    answer: int = dspy.OutputField()

solver = dspy.ChainOfThought(MathSolver)
result = solver(problem="If a train travels 60 mph for 3 hours, how far?")
print(result.answer)  # 180

# Compile (optimize prompts automatically)
# train_set = [...]
# optimizer = dspy.MIPROv2(metric=accuracy)
# compiled_solver = optimizer.compile(solver, trainset=train_set)
```

## Pour aller plus loin

- Wei et al., *Chain-of-Thought Prompting Elicits Reasoning in Large Language Models* (NeurIPS 2022)
- Kojima et al., *Large Language Models are Zero-Shot Reasoners* (NeurIPS 2022) — "Let's think step by step"
- Yao et al., *Tree of Thoughts: Deliberate Problem Solving with Large Language Models* (NeurIPS 2023)
- Wang et al., *Self-Consistency Improves Chain of Thought Reasoning in Language Models* (ICLR 2023)
- Madaan et al., *Self-Refine: Iterative Refinement with Self-Feedback* (NeurIPS 2023)
- Khattab et al., *DSPy: Compiling Declarative Language Model Calls into Self-Improving Pipelines* (ICLR 2024)
- *Anthropic Prompt Engineering Guide*
- *OpenAI Prompt Engineering Best Practices*
- **Liens internes** : [[Structured outputs]], [[agent-loops]], [[Context engineering]], [[tool-use]], [[Reasoning models]]
