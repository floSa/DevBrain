---
galaxie: meta
nom: Inbox
type: meta-doc
created: 2026-05-20
modified: 2026-05-20
tags: [meta]
---

# Inbox DevBrain

> Brain-dump. Balance ici tout ce que tu veux ajouter au brain sans réfléchir au rangement. Quand tu es prêt, dis "**traite mon Inbox**" et l'agent (skill `process-inbox`) propose une destination pour chaque item.

## Comment ça marche

**1. Balance les sujets ici.** Format libre, mais idéalement :

```
- [ ] <Nom court> (<type>) — <1 phrase de contexte ou note clé>
```

Types reconnus :
- `service` → finira dans `Services/<Cat>/`
- `concept` → finira dans `Wiki/Concepts/`
- `workflow` → finira dans `Wiki/Workflows/`
- `skill` → finira dans `Wiki/Outils/<sous-dossier>/`
- `pattern` → finira dans `Patterns/`
- `idée` (vague) → l'agent te demandera de préciser

**2. Quand tu veux processer, dis :** *"traite mon Inbox"*

L'agent :
1. Parcourt les items non-cochés (`- [ ]`)
2. Pour chacun, propose : type, catégorie, fiche à créer
3. Te demande validation
4. Crée la fiche (skill `add-service` / `add-wiki-concept` / `add-wiki-workflow` / `add-wiki-outil` selon type)
5. Coche l'item (`- [x]`) et ajoute un lien vers la fiche créée

**3. Tu peux aussi laisser des items vagues** — l'agent te poussera à préciser plutôt que d'inventer.

---

## À ranger / compléter

> Les items du jour mèneront ce système au feu pour la première fois.

### Stats / Data science

- [x] **ACP / PCA** (concept) — réduction dim continue → [[PCA]]
- [x] **AFC / CA** (concept) — analyse factorielle correspondance pour categorical → [[CA]]
- [x] **ACM / MCA** (concept) — AFC multiple (>2 variables categorielles) → [[MCA]]
- [x] **FAMD** (concept) — Factor Analysis of Mixed Data, cat+continu → [[FAMD]]
- [x] **MFA** (concept) — Multiple Factor Analysis (groupes de variables) → [[MFA]]
- [x] **GPA** (concept) — Generalized Procrustes Analysis, alignement multi-tables → [[GPA]]
- [x] **PGA** (concept) — Principal Geodesic Analysis, PCA sur variétés → [[PGA]]
- [x] **HCPC** (concept) — Hierarchical Clustering on Principal Components → [[HCPC]]
- [x] **prince** (service Python) — équivalent FactoMineR R, ACP/AFC/ACM/FAMD → [[prince]] *(stub)*
- [x] **fanalysis** (service Python) — alternative à prince → [[fanalysis]] *(stub)*
- [x] **statsmodels** (service Python) — stats classiques (régressions, tests, GLM, mixed models) → [[statsmodels]]

### Time series

- [x] **Stationnarité** (concept) — ADF test, KPSS, prérequis à ARIMA → [[Stationarity]]
- [x] **Autocorrélation** (concept) — ACF, PACF, comprendre les lags → [[Autocorrelation]]
- [x] **Walk-forward CV** (concept) — pourquoi pas de KFold sur TS → [[Walk-forward CV]]
- [x] **Forecasting framing** (concept) — direct vs recursive vs DirRec → [[Forecasting framing]]
- [x] **Prophet** (service Python) — Meta, additive model robuste → [[Prophet]]
- [x] **statsforecast** (service Python) — Nixtla, ARIMA/ETS ultra-rapides → [[statsforecast]]
- [x] **neuralforecast** (service Python) — Nixtla, DL pour TS → [[neuralforecast]]
- [x] **darts** (service Python) — framework unifié, statistical + ML + DL → [[darts]]
- [x] **Eval modèle forecast** (workflow) — métriques (MAPE, MASE, sMAPE), backtest, holdout → [[Evaluer un modele forecast]]

---

### Réduction dim & clustering (vague V5, ajoutée 2026-05-19)

- [x] **t-SNE and UMAP** (concept) — réduction non-linéaire pour viz → [[t-SNE and UMAP]]
- [x] **K-means** (concept) — partitionnement, k-means++, elbow → [[K-means]]
- [x] **DBSCAN** (concept) — densité, HDBSCAN, gestion bruit → [[DBSCAN]]
- [x] **GMM** (concept) — mélange gaussien, EM, soft clustering → [[GMM]]
- [x] **Clustering evaluation** (concept) — silhouette, DB, CH, ARI, NMI → [[Clustering evaluation]]
- [x] **umap-learn** (service) — implémentation Python UMAP → [[umap-learn]]
- [x] **hdbscan** (service) — implémentation Python HDBSCAN → [[hdbscan]]

### Stats inférentielle (vague V4, ajoutée 2026-05-19)

- [x] **Hypothesis testing** (concept) — H0/H1, type I/II, puissance, p-value → [[Hypothesis testing]]
- [x] **t-test and ANOVA** (concept) — paramétrique vs non-paramétrique, post-hoc Tukey → [[t-test and ANOVA]]
- [x] **Chi-squared tests** (concept) — adéquation, indépendance, homogénéité, Fisher, McNemar → [[Chi-squared tests]]
- [x] **Bootstrap** (concept) — IC universel, BCa, permutation tests → [[Bootstrap]]
- [x] **Multiple testing correction** (concept) — FWER (Bonferroni/Holm) vs FDR (BH) → [[Multiple testing correction]]
- [x] **Confidence intervals** (concept) — interprétation, Wilson, bootstrap CI → [[Confidence intervals]]
- [x] **PyMC** (service) — inférence bayésienne probabiliste → [[PyMC]]
- [x] **lifelines** (service) — analyse de survie, Cox, Kaplan-Meier → [[lifelines]]

### ML supervisé classique (vague V3, ajoutée 2026-05-19)

- [x] **Bias-variance tradeoff** (concept) — décomposition de l'erreur, double descent → [[Bias-variance tradeoff]]
- [x] **Cross-validation** (concept) — KFold, stratified, nested CV, pièges → [[Cross-validation]]
- [x] **Regularization** (concept) — Ridge, Lasso, ElasticNet, weight decay, dropout → [[Regularization]]
- [x] **Ensembling** (concept) — bagging, boosting, stacking → [[Ensembling]]
- [x] **ROC AUC** (concept) — courbe + AUC + PR curve pour déséquilibré → [[ROC AUC]]
- [x] **Calibration** (concept) — Platt, isotonic, temperature scaling → [[Calibration]]
- [x] **XGBoost** (service) — référence historique gradient boosting → [[XGBoost]]
- [x] **LightGBM** (service) — vitesse, Microsoft → [[LightGBM]]
- [x] **CatBoost** (service) — catégoriel natif, Yandex → [[CatBoost]]

### Théorie de l'information (vague V6, ajoutée 2026-05-20)

- [x] **Shannon entropy** (concept) — entropie, codage, lien ML → [[Shannon entropy]]
- [x] **Cross-entropy** (concept) — loss standard classification → [[Cross-entropy]]
- [x] **KL divergence** (concept) — divergence relative, asymétrie → [[KL divergence]]
- [x] **Jensen-Shannon divergence** (concept) — symétrisation KL → [[Jensen-Shannon divergence]]
- [x] **Wasserstein distance** (concept) — earth mover's, WGAN → [[Wasserstein distance]]
- [x] **Mutual information** (concept) — MI, feature selection → [[Mutual information]]
- [x] **Perplexity** (concept) — métrique LM, exp de cross-entropy → [[Perplexity]]

### Algèbre linéaire pour ML (vague V7, ajoutée 2026-05-20)

- [x] **SVD** (concept) — décomposition universelle, low-rank → [[SVD]]
- [x] **Eigendecomposition** (concept) — vecteurs propres, lien PCA → [[Eigendecomposition]]
- [x] **Vector norms** (concept) — L1/L2/Linf, lien régularisation → [[Vector norms]]
- [x] **Matrix decompositions** (concept) — LU, QR, Cholesky → [[Matrix decompositions]]
- [x] **Matrix products** (concept) — outer/inner/Hadamard/Kronecker → [[Matrix products]]
- [x] **Projections** (concept) — orthogonale, lien OLS → [[Projections]]

### Optimisation (vague V8, ajoutée 2026-05-20)

- [x] **Gradient descent** (concept) — vanilla, momentum, mini-batch → [[Gradient descent]]
- [x] **Adam optimizer** (concept) — adaptive learning rates → [[Adam optimizer]]
- [x] **Newton & quasi-Newton** (concept) — BFGS, L-BFGS → [[Newton & quasi-Newton]]
- [x] **Convexity** (concept) — convexes vs non-convexes, NN landscape → [[Convexity]]
- [x] **Learning rate schedules** (concept) — warmup, cosine, decay → [[Learning rate schedules]]
- [x] **Loss landscape and saddle points** (concept) — minima plats, saddles → [[Loss landscape and saddle points]]

### Théorie de l'apprentissage (vague V9, ajoutée 2026-05-20)

- [x] **VC dimension** (concept) — capacité d'un classifieur → [[VC dimension]]
- [x] **PAC learning** (concept) — probably approximately correct → [[PAC learning]]
- [x] **No Free Lunch theorem** (concept) — pas de meilleur algo universel → [[No Free Lunch theorem]]
- [x] **Rademacher complexity** (concept) — bornes de généralisation data-dependent → [[Rademacher complexity]]
- [x] **Generalization bounds** (concept) — VC/PAC/PAC-Bayes/Rademacher → [[Generalization bounds]]

### Probabilités fondamentales (vague V10, ajoutée 2026-05-20)

- [x] **Markov chains** (concept) — propriété de Markov, transition matrix, stationary dist → [[Markov chains]]
- [x] **Poisson process** (concept) — taux constant, inter-arrivées exp → [[Poisson process]]
- [x] **Brownian motion** (concept) — Wiener, SDE, lien diffusion models → [[Brownian motion]]
- [x] **Central limit theorem** (concept) — Lindeberg-Lévy, Berry-Esseen → [[Central limit theorem]]
- [x] **Concentration inequalities** (concept) — Markov/Chebyshev/Hoeffding/Bernstein → [[Concentration inequalities]]
- [x] **MCMC** (concept) — Metropolis-Hastings, Gibbs, HMC, NUTS → [[MCMC]]

### Stats avancée / expérimentation (vague V11, ajoutée 2026-05-20)

- [x] **Maximum likelihood estimation** (concept) — Fisher info, asymptotic normality → [[Maximum likelihood estimation]]
- [x] **MAP estimation** (concept) — prior + likelihood, lien Ridge/Lasso → [[MAP estimation]]
- [x] **Bayesian inference** (concept) — posterior, conjugate, hierarchical → [[Bayesian inference]]
- [x] **A/B testing** (concept) — RCT, MDE/power, SRM, HTE → [[A-B testing]]
- [x] **CUPED** (concept) — variance reduction, pre-experiment covariate → [[CUPED]]
- [x] **Multi-armed bandits** (concept) — ε-greedy, UCB, Thompson → [[Multi-armed bandits]]

### Métriques d'évaluation (vague V12, ajoutée 2026-05-20)

- [x] **Regression metrics** (concept) — MSE/RMSE/MAE/MAPE/R²/Huber/Quantile → [[Regression metrics]]
- [x] **Classification metrics** (concept) — Precision/Recall/F1/MCC/Brier → [[Classification metrics]]
- [x] **Forecasting metrics** (concept) — MASE/WAPE/CRPS/Pinball/Coverage → [[Forecasting metrics]]
- [x] **Ranking metrics** (concept) — P@k/R@k/MRR/MAP/NDCG → [[Ranking metrics]]
- [x] **LLM eval metrics** (concept) — BLEU/ROUGE/BERTScore/LLM-as-judge/RAGAS → [[LLM eval metrics]]

### Time series approfondi (vague V13, ajoutée 2026-05-20)

- [x] **ARIMA & SARIMA** (concept) — Box-Jenkins, ACF/PACF identification → [[ARIMA SARIMA]]
- [x] **Exponential smoothing** (concept) — ETS taxonomie, Holt-Winters → [[Exponential smoothing]]
- [x] **Hierarchical forecasting** (concept) — reconciliation MinT → [[Hierarchical forecasting]]
- [x] **Intermittent demand** (concept) — Croston/SBA/TSB → [[Intermittent demand]]
- [x] **TS anomaly detection** (concept) — STL+3σ, CUSUM, BOCD, SR-CNN → [[Time series anomaly detection]]
- [x] **TS feature engineering** (concept) — lags, rolling, calendar, Fourier → [[Time series feature engineering]]

### Data quality & production ML (vague V14, ajoutée 2026-05-20)

- [x] **Data leakage** (concept) — target/temporal/group/contamination → [[Data leakage]]
- [x] **Data drift** (concept) — covariate/concept shift, PSI/KS/MMD → [[Data drift]]
- [x] **Imbalanced classification** (concept) — SMOTE/class weight/threshold → [[Imbalanced classification]]
- [x] **Feature engineering** (concept) — encoding/scaling/binning/target enc → [[Feature engineering]]
- [x] **Missing data** (concept) — MCAR/MAR/MNAR, MICE/KNN imputation → [[Missing data]]

### Transformers & architectures (vague V15, ajoutée 2026-05-20)

- [x] **Self-attention** → [[Self-attention]]
- [x] **Positional encoding** (RoPE/ALiBi) → [[Positional encoding]]
- [x] **Tokenization** (BPE/SentencePiece) → [[Tokenization]]
- [x] **Transformer architectures** → [[Transformer architectures]]
- [x] **Flash Attention & efficient attention** → [[Flash Attention and efficient attention]]
- [x] **Mixture of Experts** → [[Mixture of Experts]]
- [x] **State Space Models** (Mamba/RWKV) → [[State Space Models]]

### LLM training & adaptation (vague V16, ajoutée 2026-05-20)

- [x] **SFT** → [[SFT]]
- [x] **RLHF & DPO** → [[RLHF and DPO]]
- [x] **PEFT** (LoRA/QLoRA) → [[PEFT]]
- [x] **Quantization** → [[Quantization]]
- [x] **Scaling laws** → [[Scaling laws]]
- [x] **Distillation** → [[Distillation]]

### Inference & prompt engineering (vague V17, ajoutée 2026-05-20)

- [x] **Decoding strategies** → [[Decoding strategies]]
- [x] **Speculative decoding** → [[Speculative decoding]]
- [x] **Prompt engineering** → [[Prompt engineering]]
- [x] **Structured outputs** → [[Structured outputs]]
- [x] **Context engineering** → [[Context engineering]]
- [x] **Inference optimization** → [[Inference optimization]]

### RAG avancé (vague V18, ajoutée 2026-05-20)

- [x] **Chunking strategies** → [[Chunking strategies]]
- [x] **Hybrid retrieval** → [[Hybrid retrieval]]
- [x] **Reranking** → [[Reranking]]
- [x] **Query transformations** → [[Query transformations]]
- [x] **Advanced RAG architectures** → [[Advanced RAG]]

### Agents (vague V19, ajoutée 2026-05-20)

- [x] **Agent patterns** → [[Agent patterns]]
- [x] **Tool use patterns** → [[Tool use patterns]]
- [x] **Agent memory** → [[Agent memory]]
- [x] **Multi-agent systems** → [[Multi-agent systems]]
- [x] **Agent evaluation** → [[Agent evaluation]]

### Multimodal AI (vague V20, ajoutée 2026-05-20)

- [x] **Vision Language Models** → [[Vision Language Models]]
- [x] **Diffusion models** → [[Diffusion models]]
- [x] **Image generation** → [[Image generation]]
- [x] **Speech models** (ASR/TTS) → [[Speech models]]
- [x] **Video generation** → [[Video generation]]

### LLM production (vague V21, ajoutée 2026-05-20)

- [x] **LLM observability** → [[LLM observability]]
- [x] **Guardrails** → [[Guardrails]]
- [x] **LLM routing & cascading** → [[Routing and cascading]]
- [x] **Reliability patterns** → [[Reliability patterns]]
- [x] **LLM caching** → [[LLM caching]]

### LLM evaluation (vague V22, ajoutée 2026-05-20)

- [x] **LLM benchmarks** (MMLU-Pro/GPQA) → [[LLM benchmarks]]
- [x] **Code & math benchmarks** (HumanEval/SWE-Bench) → [[Code and math benchmarks]]
- [x] **LLM-as-judge** → [[LLM-as-judge]]
- [x] **RAG eval** (RAGAS) → [[RAG eval]]

### AI safety & security (vague V23, ajoutée 2026-05-20)

- [x] **Prompt injection** → [[Prompt injection]]
- [x] **Jailbreaking & defenses** → [[Jailbreaking and defenses]]
- [x] **AI security** → [[AI security]]

### Frontier & advanced (vague V24, ajoutée 2026-05-20)

- [x] **Small Language Models** (Phi/Gemma/SmolLM) → [[Small Language Models]]
- [x] **Reasoning models** (o1/R1) → [[Reasoning models]]
- [x] **Synthetic data generation** → [[Synthetic data generation]]
- [x] **Chain-of-Thought** → [[Chain-of-Thought]]

## Traité — historique

> Quand un item est coché et la fiche créée, il bascule ici avec le lien.

(à archiver au fil des `process-inbox` quand le user le décide)
