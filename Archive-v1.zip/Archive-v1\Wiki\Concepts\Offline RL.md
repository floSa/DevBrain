---
galaxie: wiki
nom: Offline RL
alias: [offline RL, batch RL, BCQ, CQL, IQL, AWR, behavior cloning]
type: concept
categorie: concept/ml
sous_categories: [rl, offline-rl, batch-rl, distribution-shift, conservative]
domaines: [ml-eng, ai-eng, data-science]
maturite: emerging
auteurs_cles: [Levine 2020 (survey), Fujimoto 2019 (BCQ), Kumar 2020 (CQL), Kostrikov 2022 (IQL)]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, rl, offline-rl, batch-rl]
---

# Offline RL — Batch RL

## TL;DR

Apprendre une politique uniquement depuis un **dataset fixe** d'interactions passées, **sans pouvoir interagir** avec l'environnement pendant l'entraînement. Cadre crucial en pratique : on a des logs (recommendation, médical, dialogue, conduite autonome) mais déployer une politique exploratoire est trop risqué/coûteux. **Problème central** : distribution shift — la politique apprise voudra prendre des actions hors du dataset, dont les Q values sont fantaisistes. **Algorithmes phares** : **BCQ, CQL, IQL, AWR, TD3+BC**. Cousins : [[Imitation learning]] (apprendre la politique directement) et offline DPO (utilisé en RLHF).

## Le problème

En RL classique (online), l'agent interagit en boucle avec l'environnement : try → observe → update → try. Mais dans le monde réel :

- **Médical** : impossible de tester des politiques de traitement sur des vrais patients
- **Conduite autonome** : explorer = accidents
- **Recommendation** : exposer un user à du contenu random coûte des conversions
- **LLM RLHF** : la collecte de feedback humain est très chère
- **Robotique** : interactions limitées par usure / temps

Solution : utiliser des **logs existants** $\mathcal{D} = \{(s_i, a_i, r_i, s'_i)\}$ générés par une politique de comportement $\pi_b$ (souvent inconnue, mixed, voire suboptimale).

## L'idée

### Le distribution shift problem

Si on applique Q-learning sur $\mathcal{D}$ naïvement :

$$ Q(s, a) \leftarrow Q(s, a) + \alpha [r + \gamma \max_{a'} Q(s', a') - Q(s, a)] $$

Le $\max_{a'}$ peut sélectionner une action **jamais vue** dans le dataset → $Q(s', a')$ est une **extrapolation arbitraire** du réseau, souvent surestimée. La politique apprise pousse vers ces "fantasmes", divergence.

C'est le **problème central** de l'offline RL et ce qui motive tous les algos.

### Trois familles de solutions

#### 1. Policy constraint (rester proche de la politique de comportement)

Contraindre $\pi_\theta$ à ne pas s'écarter trop de $\pi_b$ :

$$ \pi_\theta(a|s) \approx \pi_b(a|s) \quad \text{(au sens KL, TV, ou support)} $$

- **BCQ** (Fujimoto 2019) : générer des actions "vraisemblables" via un VAE entraîné sur $\mathcal{D}$, restreindre $\max_{a'}$ à ce support
- **TD3+BC** (Fujimoto 2021) : TD3 + terme de behavior cloning dans la loss policy

#### 2. Value penalty (pénaliser les Q overestimés)

Décourager le Q-net de prédire des valeurs hautes hors-distribution :

- **CQL** (Conservative Q-Learning, Kumar 2020) : ajouter une régularisation qui minimise $\log \sum_a \exp Q(s, a)$ tout en maximisant $Q(s, a_{\mathcal{D}})$ → Q est conservatif là où on n'a pas vu de data

#### 3. Implicit policy (éviter le max problématique)

- **IQL** (Implicit Q-Learning, Kostrikov 2022) : ne jamais faire `max_a Q(s, a)` ; à la place, utiliser l'**expectile regression** sur $V$ pour estimer $V \approx \max_a Q$ uniquement dans le support. **Élégant, performant, standard 2022+**.

### Comparatif algos

| Algo | Idée | Pros | Cons |
|---|---|---|---|
| **BC** ([[Imitation learning]]) | clone $\pi_b$ par MLE | simple, pas de Q | n'améliore pas $\pi_b$ |
| **BCQ** | restreint actions au support VAE | théorie propre | VAE à entraîner, complexe |
| **CQL** | Q conservatif | populaire, flexible | tuning critique de α |
| **IQL** | expectile $V$, evite max | simple, robuste, **default 2022+** | suppose dataset assez diverse |
| **AWR / AWAC** | weighted regression vers $\pi_b$ | stable | suboptimal vs IQL/CQL |
| **TD3+BC** | TD3 + BC term | simple, efficace continu | tuning λ entre TD3 et BC |
| **DT** (Decision Transformer) | sequence modeling, conditioning on return | offline + scalable | besoin de "return-to-go" cibles |
| **Trajectory Transformer** | autoregressive trajectories | flexible | inference cher |

### Decision Transformer (DT, Chen 2021)

Reformule l'offline RL comme un **problème de séquence** : étant donné $(R_t, s_t)$ (return-to-go), prédire $a_t$. C'est juste du SFT sur trajectoires conditionnées par le return désiré.

Au déploiement : choisir un return élevé, et autoregresser. Marche étonnamment bien sur D4RL.

Limite : généralise mal aux returns hors-distribution. Et nécessite des trajectoires complètes pour calculer le return-to-go.

### Offline RL vs imitation learning

| Aspect | Imitation Learning | Offline RL |
|---|---|---|
| Données | trajectoires "expertes" | logs quelconques (mixed quality) |
| Objectif | imiter $\pi_b$ | trouver $\pi^* \ge \pi_b$ |
| Méthode | MLE / regression | TD avec contrainte |
| Quand utiliser | $\pi_b$ est ~ optimal | $\pi_b$ est moyen, suboptimal |

Souvent on combine : init avec BC, puis offline RL pour améliorer.

### Eval offline (le piège #2)

**Évaluer une politique offline est dur**. On ne peut pas la déployer sans risque. Trois approches :

1. **Eval online (online holdout)** : déployer sur un petit % de trafic. Standard mais coûteux.
2. **Off-Policy Evaluation (OPE)** : estimer $J(\pi_\theta)$ depuis les logs via Importance Sampling, Doubly Robust, Fitted Q-Eval — biaisé sur petits datasets, variance énorme avec long horizon.
3. **Simulator** : si on a un simulateur fidèle, déployer dedans. Sim-to-real reste un problème ouvert.

OPE est un domaine de recherche à part entière. Sans bonne OPE, **on déploie en aveugle**.

### Offline → Online (fine-tuning)

Workflow pratique : pré-entraîner offline (CQL/IQL), puis **fine-tuner online** avec quelques interactions réelles. Souvent appelé **offline-to-online RL**. Boost massif vs pure offline.

Mais attention : passage offline → online introduit du distribution shift, instabilité possible. Algos dédiés (Cal-QL, Off2OnRL).

### Liens avec le RLHF / DPO

**DPO est offline RL pour les LLMs** :
- Dataset fixe de paires de préférences
- Pas d'interaction (pas de génération online)
- Objectif : maximiser reward implicite tout en restant proche du SFT (KL constraint via le ref model)

C'est pour ça que DPO est plus simple que PPO RLHF : pas de problème online d'exploration, mais aussi pas d'adaptation à la policy en cours → motiver iterative DPO (Tulu 3, Llama 3).

## Quand c'est utile

- **Logs disponibles, déploiement coûteux** : médical, finance, recommendation
- **Sécurité** : robotique critique, conduite autonome
- **RLHF** : DPO est un cas particulier d'offline RL
- **Bootstrap** : init d'une politique avant fine-tuning online
- **Benchmarking** : comparer politiques sans déployer
- **Données déjà collectées** : ré-utiliser des datasets existants (D4RL, robotique batch)
- **Multi-task** : un seul dataset, plusieurs tâches, transfert

## Quand ça ne marche pas / pièges

- **Dataset trop narrow** : si $\pi_b$ couvre seulement quelques actions / régions, impossible d'apprendre mieux
- **Distribution shift sévère** : politique apprise demande des actions très différentes → extrapolation cassée
- **Pas de récompenses positives dans $\mathcal{D}$** : signal nul → garbage in / garbage out
- **OPE peu fiable** : on n'a pas de bonne mesure de succès offline → déploiement à l'aveugle
- **Hyperparams fragiles** : $\alpha$ de CQL, $\tau$ d'IQL — sensibilité grande, défaut à tester en sweep
- **Long horizon** : la variance des Importance Sampling est exponentielle en T → IS quasi inutile
- **Dataset bias** : $\pi_b$ a évité certaines actions pour de mauvaises raisons → l'algo les évite aussi
- **Reward shaping caché** : si la "récompense" du log est mal définie, on optimise n'importe quoi
- **Comparaisons douteuses** : papers comparent sur D4RL avec splits standards mais reproductibilité fragile, beaucoup de variance entre seeds

## Code minimal

```python
# Offline RL avec d3rlpy (lib dédiée Python)
# pip install d3rlpy
import d3rlpy
from d3rlpy.dataset import MDPDataset
import numpy as np

# Construire un dataset depuis des logs
N = 100_000
observations = np.random.rand(N, 4).astype("float32")
actions = np.random.randint(0, 2, N)
rewards = np.random.rand(N).astype("float32")
terminals = np.random.rand(N) < 0.01
dataset = MDPDataset(observations, actions, rewards, terminals)

# CQL pour discret
cql = d3rlpy.algos.DiscreteCQLConfig(
    learning_rate=3e-4, batch_size=256, alpha=1.0,    # alpha = force conservative
).create(device="cuda")
cql.fit(dataset, n_steps=100_000, evaluators={"environment": d3rlpy.metrics.EnvironmentEvaluator(env)})

# IQL pour continu
iql = d3rlpy.algos.IQLConfig(
    actor_learning_rate=3e-4, critic_learning_rate=3e-4,
    batch_size=256, expectile=0.7, weight_temp=3.0,
).create(device="cuda")
iql.fit(dataset, n_steps=500_000)
```

```python
# IQL principe (PyTorch pseudo-code)
import torch
import torch.nn.functional as F

def expectile_loss(diff, tau=0.7):
    """diff = V(s) - Q(s, a) ; tau > 0.5 -> expectile au-dessus."""
    weight = torch.where(diff > 0, tau, 1 - tau)
    return (weight * diff ** 2).mean()

def iql_step(actor, critic_q1, critic_q2, value, batch, tau=0.7, beta=3.0, gamma=0.99):
    s, a, r, s2, done = batch
    with torch.no_grad():
        target_q = torch.min(critic_q1(s, a), critic_q2(s, a))
    # 1. V régression vers Q via expectile
    v = value(s)
    v_loss = expectile_loss(target_q - v, tau)

    # 2. Q régression vers cible TD utilisant V
    with torch.no_grad():
        next_v = value(s2)
        td_target = r + gamma * next_v * (1 - done)
    q1_loss = F.mse_loss(critic_q1(s, a), td_target)
    q2_loss = F.mse_loss(critic_q2(s, a), td_target)

    # 3. Policy : weighted regression (advantage-weighted)
    with torch.no_grad():
        adv = target_q - v
        weight = torch.exp(beta * adv).clamp(max=100.0)
    actor_loss = -(weight * actor.log_prob(s, a)).mean()

    return v_loss, q1_loss + q2_loss, actor_loss
```

```python
# CQL principe (continu, ajouté au DDPG/SAC standard)
def cql_penalty(q_net, s, actions_sampled_uniform, alpha=1.0):
    """
    Régularisation CQL : minimise log Σ_a exp Q(s,a) - Q(s, a_data)
    Q hors-distribution = pénalisé.
    """
    q_data = q_net(s, a_data)                                 # batch ((B,))
    q_sampled = q_net(s.unsqueeze(1).expand(-1, K, -1),
                      actions_sampled_uniform)                # (B, K)
    logsumexp_q = q_sampled.logsumexp(dim=1) - torch.log(torch.tensor(K))
    return alpha * (logsumexp_q - q_data).mean()
```

```python
# Decision Transformer : SFT conditionné sur return-to-go
import torch
from transformers import GPT2Config, GPT2Model

class DecisionTransformer(torch.nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_size=128, max_length=20):
        super().__init__()
        self.return_emb = torch.nn.Linear(1, hidden_size)
        self.obs_emb = torch.nn.Linear(obs_dim, hidden_size)
        self.act_emb = torch.nn.Linear(act_dim, hidden_size)
        self.transformer = GPT2Model(GPT2Config(
            n_embd=hidden_size, n_layer=3, n_head=4, n_positions=max_length * 3,
        ))
        self.act_head = torch.nn.Linear(hidden_size, act_dim)

    def forward(self, returns_to_go, states, actions):
        # Sequence (R_0, s_0, a_0, R_1, s_1, a_1, ...)
        r_emb = self.return_emb(returns_to_go.unsqueeze(-1))
        s_emb = self.obs_emb(states)
        a_emb = self.act_emb(actions)
        stacked = torch.stack((r_emb, s_emb, a_emb), dim=2).flatten(1, 2)
        out = self.transformer(inputs_embeds=stacked).last_hidden_state
        # Predire l'action à partir de la position correspondant à s_t
        action_preds = self.act_head(out[:, 1::3])
        return action_preds
```

```python
# OPE (Off-Policy Evaluation) : importance sampling basique
import torch

def importance_sampling_estimator(log_pi_target, log_pi_behavior, rewards):
    """
    log_pi_target : (T,)   politique cible
    log_pi_behavior : (T,) politique de comportement (du log)
    Très haute variance, à utiliser avec précaution.
    """
    log_ratio = log_pi_target - log_pi_behavior   # cumulative en pratique
    weights = log_ratio.cumsum(dim=0).exp().clamp(max=1e4)
    return (weights * rewards).sum().item()

# Variantes plus solides : Doubly Robust, Fitted Q Evaluation, MAGIC
```

## Pour aller plus loin

- Levine et al., *Offline Reinforcement Learning: Tutorial, Review, and Perspectives* (2020) — la référence : https://arxiv.org/abs/2005.01643
- Fujimoto et al., *Off-Policy Deep RL without Exploration* (BCQ, 2019)
- Kumar et al., *Conservative Q-Learning* (CQL, NeurIPS 2020)
- Kostrikov et al., *Offline RL with Implicit Q-Learning* (IQL, ICLR 2022)
- Chen et al., *Decision Transformer: RL via Sequence Modeling* (NeurIPS 2021)
- Janner et al., *Trajectory Transformer* (NeurIPS 2021)
- D4RL benchmark : https://github.com/Farama-Foundation/D4RL
- d3rlpy library : https://github.com/takuseno/d3rlpy
- Lange et al., *Batch Reinforcement Learning* (handbook chapter, 2012)
- **Liens internes** : [[Imitation learning]], [[Reinforcement learning]], [[Value functions]], [[Q-learning and DQN]], [[RLHF and DPO]], [[Data leakage]]
