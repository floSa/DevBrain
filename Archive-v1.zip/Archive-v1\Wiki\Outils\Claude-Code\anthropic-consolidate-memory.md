---
galaxie: wiki
nom: anthropic-skills:consolidate-memory
type: claude-code-skill
plateforme: claude-code
categorie: skill/meta
sous_categories: [memory, claude-md, refactor]
auteur: Anthropic
source: anthropics/skills
source_url: https://github.com/anthropics/skills
install_cmd: claude plugin install anthropic-skills
install_doc: https://docs.claude.com/en/docs/build-with-claude/skills
licence: MIT
licence_type: open-source
domaines: [ai-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, meta, memory]
---

# anthropic-skills:consolidate-memory

## Pourquoi

Passe en revue tes **fichiers de mémoire** (`CLAUDE.md`, `CLAUDE-build.md`, et autres docs lues à chaque session) pour : fusionner les duplications, corriger les faits périmés, élaguer l'index. Hyper utile sur DevBrain qui accumule de la doc dans plusieurs `CLAUDE-*.md`.

## Quand l'utiliser

- Après un gros refactor du brain (ex. renaming d'une taxonomie)
- Quand le `CLAUDE.md` devient trop long (>500 lignes) et touffu
- Une fois par trimestre, pour la maintenance hygiénique
- Quand tu remarques que Claude répète des erreurs liées à de la doc périmée

## Quand NE PAS l'utiliser

- Juste après une modification ciblée (la doc est encore fraîche)
- Sur des fichiers de mémoire que tu viens d'écrire (laisse-les vivre)

## Comment l'installer

```bash
claude plugin install anthropic-skills
```

Voir [[_installer-un-skill]].

## Exemples d'usage

```
> consolide mes fichiers CLAUDE-* — il y a des redondances
> audit CLAUDE.md et CLAUDE-build.md, fusionne ce qui peut l'être
```

## Pièges connus

- Le skill propose des fusions mais te laisse valider — pas d'écriture aveugle
- Sur DevBrain spécifiquement, attention à préserver la frontière strict entre `CLAUDE.md` (routeur) et `CLAUDE-build.md` (contexte build)

## Liens

- Source : https://github.com/anthropics/skills
