---
galaxie: wiki
nom: Rademacher complexity
alias: [Rademacher complexity, complexité de Rademacher, empirical Rademacher]
type: concept
categorie: concept/learning-theory
sous_categories: [rademacher, complexity, generalization-bound, data-dependent]
domaines: [ml-eng]
maturite: established
auteurs_cles: [Koltchinskii-Panchenko 2000, Bartlett-Mendelson 2002]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, learning-theory, rademacher, generalization]
---

# Rademacher complexity

## TL;DR

Mesure **data-dependent** de la capacité d'une classe d'hypothèses — alternative plus fine que [[VC dimension]]. Quantifie à quel point une classe peut "matcher du bruit aléatoire" sur un échantillon donné. Donne des **bornes de généralisation plus tight** que les bornes VC, en particulier en haute dim. Utilisée pour analyser SVM, boosting, NN.

## Le problème

VC dim est **worst-case** sur la distribution. En pratique, on a un dataset spécifique, et la complexité utile varie. Rademacher complexity est **data-dependent** : elle dépend du dataset particulier, donnant des bornes plus pertinentes.

## L'idée

### Variables de Rademacher

Soient $\sigma_1, \dots, \sigma_n$ i.i.d. avec $\mathbb{P}(\sigma_i = +1) = \mathbb{P}(\sigma_i = -1) = 1/2$. Ce sont des "labels aléatoires".

### Empirical Rademacher complexity

Pour un échantillon $S = (x_1, \dots, x_n)$ et une classe d'hypothèses $\mathcal{H}$ (ou de fonctions de loss $\mathcal{G}$) :

$$ \hat \mathfrak{R}_S(\mathcal{H}) = \mathbb{E}_\sigma \left[ \sup_{h \in \mathcal{H}} \frac{1}{n} \sum_{i=1}^n \sigma_i h(x_i) \right] $$

Intuition : "à quel point la meilleure hypothèse de $\mathcal{H}$ peut corréler avec du bruit aléatoire sur cet échantillon".

### Rademacher complexity (théorique)

$$ \mathfrak{R}_n(\mathcal{H}) = \mathbb{E}_S[\hat \mathfrak{R}_S(\mathcal{H})] $$

Moyenne sur les échantillons. Plus pratique pour les bornes théoriques.

### Borne de généralisation

Avec proba $\geq 1 - \delta$, pour tout $h \in \mathcal{H}$ :

$$ R(h) \leq \hat R(h) + 2 \mathfrak{R}_n(\mathcal{H}) + 3 \sqrt{\frac{\log(2/\delta)}{2n}} $$

**Comparaison à VC** : Rademacher est souvent **strictement meilleure** que la borne VC. Elle s'adapte à la distribution réelle des données.

### Propriétés clés

- **Monotonie** : $\mathfrak{R}(\mathcal{H}_1) \leq \mathfrak{R}(\mathcal{H}_2)$ si $\mathcal{H}_1 \subseteq \mathcal{H}_2$
- **Concentration** : $\hat \mathfrak{R}_S$ se concentre autour de $\mathfrak{R}_n$
- **Composition Lipschitz** : pour $\phi$ L-Lipschitz, $\mathfrak{R}(\phi \circ \mathcal{H}) \leq L \cdot \mathfrak{R}(\mathcal{H})$ (lemma de Talagrand)

### Exemples

#### Classe linéaire bornée

Pour $\mathcal{H} = \{x \mapsto w^\top x : \|w\| \leq B\}$ avec $\|x\| \leq R$ :

$$ \mathfrak{R}_n(\mathcal{H}) \leq \frac{BR}{\sqrt{n}} $$

Pas de dépendance explicite en dimension ! C'est pour ça que les SVM marchent bien en très haute dim quand $B$ et $R$ sont bornés.

#### Combinaisons convexes (boosting)

Pour $\mathcal{H}$ enveloppe convexe de $\mathcal{H}_0$ :

$$ \mathfrak{R}(\mathcal{H}) = \mathfrak{R}(\mathcal{H}_0) $$

Permet d'analyser AdaBoost, gradient boosting.

#### Neural networks

Bornes basées sur la **norme des poids** plutôt que le nombre :

$$ \mathfrak{R}_n(\text{NN}) \lesssim \frac{\prod_l \|W_l\|}{\sqrt{n}} \cdot O(\text{depth}) $$

(Bartlett-Foster-Telgarsky 2017). Beaucoup plus tight pour les NN sur-paramétrés que VC.

### Avantages vs VC

| Aspect | VC dim | Rademacher |
|---|---|---|
| Type | Worst-case sur distribution | Data-dependent |
| Calcul | Combinatoire, NP-hard | Échantillonnage Monte Carlo possible |
| Bornes | Souvent lâches | Souvent plus tight |
| Pour NN modernes | Vacuous | Mieux (mais encore lâche) |
| Estimation empirique | Non | Oui (échantillonner $\sigma$) |

### Estimation empirique

Contrairement à VC dim, on peut **calculer** une approximation de $\hat \mathfrak{R}_S$ :

```
Pour k=1 à K (typiquement K=20-100):
    Tirer σ aléatoirement
    Calculer sup_h (1/n) Σ σ_i h(x_i) — i.e. minimiser une loss bidon
    Stocker
Moyenner → estimation de Rademacher
```

Utile pour diagnostiquer la complexité effective d'un modèle sur ses données.

## Quand c'est utile

- **Bornes théoriques** plus tight que VC pour SVM, boosting, neural nets
- **Justification des architectures NN** : profondeur vs largeur, normes des poids
- **Analyse de la régularisation** : weight decay réduit la norme → réduit Rademacher → meilleure généralisation théorique
- **Choix entre modèles** : à risque empirique égal, préférer celui à Rademacher complexity plus basse
- **Estimation empirique** sur un dataset spécifique

## Quand ça ne marche pas / pièges

- **Calcul exact** difficile (sup intractable en général). Approximation par échantillonnage.
- **Encore lâche pour NN très sur-paramétrés** : nouvelles bornes (PAC-Bayes, mutual info) plus tight
- **Choix de la classe** : si $\mathcal{H}$ est trop large (toutes les fonctions), Rademacher vaut $1/2$ et la borne est vacuous
- **Bornes pessimistes** : Rademacher est un sup → peut être dominé par hypothèses "extrêmes" pas pertinentes pour l'algo
- **Dépendance à la mesure de loss** : Rademacher sur la classe de loss peut différer de celle sur la classe d'hypothèses
- **Confusion avec Gaussian complexity** : variante similaire avec $\sigma \sim \mathcal{N}(0, 1)$ au lieu de Rademacher. Mêmes propriétés à constante près.

## Code minimal

```python
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler

# Estimation empirique de Rademacher pour classe linéaire bornée
def empirical_rademacher_linear(X, n_samples=50, B=1.0):
    """Approximation de l'empirical Rademacher complexity pour {w^T x : ||w|| ≤ B}."""
    n, d = X.shape
    X_std = StandardScaler().fit_transform(X)
    
    rademachers = []
    for _ in range(n_samples):
        sigma = np.random.choice([-1, 1], size=n)
        # sup_{||w|| ≤ B} (1/n) Σ σ_i w^T x_i = (B/n) || Σ σ_i x_i ||
        score = (B / n) * np.linalg.norm(X_std.T @ sigma)
        rademachers.append(score)
    
    return np.mean(rademachers)

# Exemple
X = np.random.randn(100, 50)
R = empirical_rademacher_linear(X, B=1.0)
print(f"Rademacher (≈) = {R:.4f}")
# Théorique : B * sqrt(tr(X^T X) / n^2) ≈ B / sqrt(n) si X iso
print(f"Borne théorique : {1.0 / np.sqrt(100):.4f}")
```

## Pour aller plus loin

- Bartlett & Mendelson, *Rademacher and Gaussian Complexities* (JMLR 2002)
- Mohri, Rostamizadeh, Talwalkar, *Foundations of Machine Learning* — chap. 3
- Bartlett, Foster, Telgarsky, *Spectrally-normalized margin bounds for neural networks* (NIPS 2017) — Rademacher pour NN
- **Liens internes** : [[VC dimension]], [[PAC learning]], [[No Free Lunch theorem]], [[Regularization]] (weight decay réduit Rademacher)
