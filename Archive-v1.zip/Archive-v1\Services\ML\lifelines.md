---
galaxie: dev
nom: lifelines
alias: [lifelines-py, survival-analysis-python]
categorie: ml/framework
sous_categories: [survival-analysis, kaplan-meier, cox, time-to-event]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: [scikit-survival, R-survival, pysurvival]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, ml, survival-analysis, time-to-event]
---

# lifelines

## Pourquoi

Bibliothèque Python de référence pour l'**analyse de survie** (time-to-event analysis) : modéliser le **temps avant qu'un événement se produise** (décès, churn, panne, défaut de paiement) en gérant correctement les **données censurées** (sujets qui sortent de l'étude avant l'événement).

C'est la lib à prendre quand tes données ne sont pas "classification binaire" mais "combien de temps avant l'événement" — un cadre fondamentalement différent du ML supervisé classique.

## Quand l'utiliser

- **Churn prediction** : durée avant qu'un client résilie (au-delà de "va-t-il churn ?")
- **Médical** : survie après diagnostic, temps avant récidive
- **Fiabilité industrielle** : temps avant panne d'un équipement
- **Crédit** : temps avant défaut de paiement
- **Marketing** : temps avant conversion / réengagement
- Tout problème où tu as un **outcome temporel** et de la **censure** (certains sujets observés sans qu'on ait vu l'événement)

## Quand NE PAS l'utiliser

- **Pas de censure** : tu as observé l'événement pour tous → régression simple sur le temps
- Très haute dimensionnalité avec interactions complexes → [[XGBoost]] avec target = temps (perd la sémantique survival mais peut marcher)
- **Très grand dataset** + besoin de scalabilité → scikit-survival ou implémentation custom
- Tu n'as pas la **date d'origine** claire pour chaque sujet

## Modèles principaux disponibles

- **Kaplan-Meier estimator** : courbe de survie empirique, non-paramétrique
- **Nelson-Aalen** : hazard cumulé non-paramétrique
- **Cox Proportional Hazards** : modèle semi-paramétrique le plus utilisé, coefficients interprétables comme hazard ratios
- **Accelerated Failure Time (AFT)** : alternative au Cox avec interprétation en temps multiplicatif
- **Parametric models** : Exponential, Weibull, Log-logistic, Log-normal
- **Stratified Cox** : Cox avec strates (effets non-proportionnels par groupe)
- **Time-varying Cox** : covariables qui changent dans le temps

## Pièges connus

- **Censure mal codée** : convention `event=1` si l'événement a eu lieu, `0` sinon. Inverser = catastrophe.
- **Tester l'hypothèse de proportionnalité** du Cox (`check_assumptions()`) — sinon utiliser Cox stratifié ou time-varying
- **Time zero** mal défini : si tu mélanges des sujets avec différentes dates d'entrée, attention au left-truncation
- **Confusion avec classification** : prédire "va churn dans 30 jours ?" est un problème de classification, pas survival. Survival = "combien de temps avant ?"
- **Compétitivité** : sur très gros dataset, `scikit-survival` est plus rapide et mieux intégré sklearn
- **Visualisations** : matplotlib direct, pas toujours esthétique. Customiser au besoin.

## Liens

- Doc officielle : https://lifelines.readthedocs.io/
- Repo : https://github.com/CamDavidsonPilon/lifelines
- *Survival Analysis: A Self-Learning Text* (Kleinbaum & Klein) — pédagogique
- Concepts liés : [[Hypothesis testing]], [[Confidence intervals]], [[Bias-variance tradeoff]]
- Alternatives : `scikit-survival` (intégré sklearn), R `survival` (référence académique)
