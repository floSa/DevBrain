---
galaxie: wiki
nom: update-config
type: claude-code-skill
plateforme: claude-code
categorie: skill/dev-flow
sous_categories: [settings, hooks, permissions]
auteur: Anthropic
source: claude-code natif
source_url: https://docs.claude.com/en/docs/claude-code/settings
install_cmd: 
install_doc: https://docs.claude.com/en/docs/claude-code/settings
licence: 
licence_type: proprietary
domaines: [data-science, data-eng, mlops, ml-eng, ai-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, settings, config]
---

# update-config

## Pourquoi

Skill **bundled** pour modifier proprement `.claude/settings.json` (et `settings.local.json`). Gère les permissions Bash/WebFetch, les hooks, les env vars. Surtout utile pour les **comportements automatisés** ("à chaque commit fais X", "avant de toucher Y rappelle-moi Z") qui passent forcément par les hooks `settings.json`, pas par la mémoire de Claude.

C'est le skill à invoquer dès que tu te dis "j'aimerais que Claude fasse X automatiquement".

## Quand l'utiliser

- Ajouter une permission sans ouvrir `settings.json` à la main
- Configurer un hook (PreToolUse, PostToolUse, Stop, etc.)
- Définir une env var côté projet
- Déboguer un hook qui ne se déclenche pas

## Quand NE PAS l'utiliser

- Simple changement de thème ou de modèle → utilise `/config` direct
- Permission one-shot que tu peux accepter au prompt — pas la peine de coder

## Comment l'installer

Natif Claude Code, déclenchable via `/update-config` ou simplement "configure mon settings.json pour...".

## Exemples d'usage

```
> ajoute une permission pour git push origin main
> mets un hook Stop qui m'affiche une notif quand Claude finit
> avant chaque écriture dans Services/, rappelle-moi de checker que je suis 
  en mode build
```

## Pièges connus

- Pas autorisé à modifier ses propres permissions sans confirmation explicite (sécurité)
- Les hooks sont en bash/shell — sur Windows, attention au PowerShell vs bash

## Liens

- Doc settings : https://docs.claude.com/en/docs/claude-code/settings
- Doc hooks : https://docs.claude.com/en/docs/claude-code/hooks
- [[claude-fewer-permission-prompts|fewer-permission-prompts]] (skill cousin qui automatise l'ajout de permissions)
