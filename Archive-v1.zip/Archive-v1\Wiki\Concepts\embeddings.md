---
galaxie: wiki
nom: Embeddings
type: concept
categorie: concept/llm
sous_categories: [vector, semantic, representation, retrieval]
domaines: [ai-eng, ml-eng, data-science]
maturite: established
auteurs_cles: [Mikolov 2013, Reimers 2019, OpenAI, Cohere]
lecture_min: 8
created: 2026-05-19
modified: 2026-05-20
tags: [concept, llm, embeddings, vector]
---

# Embeddings

## TL;DR

Transformer un objet (texte, image, audio) en **vecteur dense** de N flottants (typiquement 384-3072 dimensions) tel que la **proximité géométrique** (cosine similarity) reflète la **proximité sémantique**. C'est la fondation du retrieval moderne et du RAG.

## Le problème

Recherche "classique" (BM25, TF-IDF) compare des mots-clés exacts. Conséquences :
- "voiture" ne matche pas "automobile" (synonymes)
- "Combien coûte X ?" ne matche pas "prix de X" (paraphrases)
- Pas de proximité conceptuelle ("Paris" vs "France")

On veut une représentation où **le sens** compte, pas les caractères.

## L'idée

```
"Postgres c'est lent sur des jointures complexes"
              │
              ▼  modèle embedding (BERT, OpenAI ada, Cohere, ...)
              │
              ▼
[0.142, -0.83, 0.51, ..., 0.07]    ← vecteur 1536-dim
```

Deux textes proches sémantiquement → vecteurs proches géométriquement (cosine sim ≈ 1).
Textes opposés → vecteurs orthogonaux ou opposés.

Une fois tout indexé en vector DB, *rechercher* = embedding de la query + top-k voisins.

## Quand c'est utile

- **RAG** — récupérer les chunks pertinents (voir [[RAG]])
- **Semantic search** — moteur de recherche qui comprend les intentions
- **Clustering** — grouper des textes similaires (e-mails, tickets, papers)
- **Détection de doublons** quasi-identiques (deduplication corpus)
- **Recommandation** — "des contenus comme celui-ci"
- **Classification zero-shot** — class proche en embedding = class probable

## Quand ça ne marche pas / pièges

- **Modèles génériques sur domaine spécialisé** — embeddings OpenAI sur du jargon médical/juridique → résultats moyens. Fine-tune ou prends un modèle domain-specific
- **Chunks de mauvaise taille** — 200 tokens (trop court, perd le contexte) vs 2000 (trop long, embedding "moyen" peu spécifique)
- **Embeddings multi-lingues mal alignés** — vérifier que ton modèle traite ton mix de langues
- **Coût de re-embed** — si tu changes de modèle, tout est à re-indexer
- **Curse of dimensionality** — au-delà de quelques M de vecteurs, les approximations (HNSW, IVF) deviennent obligatoires
- **Embeddings != compréhension** — proches en sens ne veut pas dire "même réponse" : la sortie LLM grounded reste nécessaire

## Implémentations concrètes

**Modèles d'embedding :**
- OpenAI `text-embedding-3-small / -large` (génériques, payants)
- Cohere `embed-v3` (multi-lingue performant)
- Voyage AI `voyage-large-2` (souvent meilleur que OpenAI sur des benchmarks)
- Hugging Face `sentence-transformers/*` (open source, self-hostable)
- `BAAI/bge-*` — top open-source sur MTEB benchmark

**Vector DBs :**
- [[Postgres]] avec pgvector — souvent suffisant à <10M vecteurs
- Qdrant, Weaviate, Milvus, Pinecone — dédiés vector, scale

## Code minimal

```python
# 1. Modèle open-source (sentence-transformers + BGE)
from sentence_transformers import SentenceTransformer
import numpy as np

embedder = SentenceTransformer("BAAI/bge-base-en-v1.5")
texts = [
    "Postgres est lent sur les grosses jointures",
    "PostgreSQL souffre de perfs sur les jointures multiples",  # paraphrase
    "Le ciel est bleu",                                          # off-topic
]
embeddings = embedder.encode(texts, normalize_embeddings=True)
# shape (3, 768) avec L2-normalisé

# Cosine similarity = dot product (car normalisé)
sim_01 = float(embeddings[0] @ embeddings[1])  # paraphrase → haut
sim_02 = float(embeddings[0] @ embeddings[2])  # off-topic → bas
print(f"Paraphrase : {sim_01:.3f}, Off-topic : {sim_02:.3f}")

# 2. OpenAI API
from openai import OpenAI
client = OpenAI()
response = client.embeddings.create(
    model="text-embedding-3-small",
    input=texts,
)
emb_openai = np.array([d.embedding for d in response.data])

# 3. Asymmetric (query vs doc, BGE/E5/Voyage style)
query_emb = embedder.encode(["how fast is postgres?"], normalize_embeddings=True,
                              prompt_name="query")  # certains modèles ont des prompts différents

# 4. Matryoshka : truncate dimensions sans perte massive
# text-embedding-3-large : 3072 dims, peut être tronqué à 256
truncated = embeddings[:, :128]  # garder seulement 128 dims
truncated = truncated / np.linalg.norm(truncated, axis=1, keepdims=True)  # re-normaliser

# 5. Quantization binary (-1/+1 sur chaque dim)
# Mémoire ÷32, vitesse ×4-40 avec Hamming distance
binary = (embeddings > 0).astype(np.uint8)
# Stocker en bitset, recherche via XOR/popcount

# 6. Stockage + recherche : FAISS (in-memory, fast)
import faiss
index = faiss.IndexFlatIP(embeddings.shape[1])  # exact, inner product
index.add(embeddings.astype("float32"))

q_emb = embedder.encode(["postgres performance"], normalize_embeddings=True)
scores, idx = index.search(q_emb.astype("float32"), k=2)
print(idx)  # indices des top-2
```

## Pour aller plus loin

- MTEB benchmark : https://huggingface.co/spaces/mteb/leaderboard (comparatif des modèles)
- Concept lié : [[RAG]]
- "All you need is text embeddings" : https://huggingface.co/blog/mteb
