---
galaxie: wiki
nom: kepano/obsidian-skills
type: obsidian-skill
plateforme: claude-code
categorie: skill/knowledge
sous_categories: [obsidian, wikilinks, frontmatter, bases]
auteur: Steph Ango (kepano, CEO Obsidian)
source: kepano/obsidian-skills
source_url: https://github.com/kepano/obsidian-skills
install_cmd: npx skills add kepano/obsidian-skills
install_doc: 
licence: MIT
licence_type: open-source
domaines: [data-science, data-eng, mlops, ml-eng, ai-eng, doc]
score: 
status: tested
mes_projets: [DevBrain]
created: 2026-05-19
modified: 2026-05-19
tags: [skill, obsidian, knowledge-base]
---

# kepano/obsidian-skills

## Pourquoi

Skill **fondamental** quand l'agent travaille avec un vault Obsidian (comme DevBrain). Il apprend à Claude la **syntaxe Obsidian** native : wikilinks `[[X]]`, callouts `> [!note]`, frontmatter (Properties), Bases (`.base`), Canvas, Templater.

Sans lui, Claude écrit du markdown générique qui ne tire pas parti d'Obsidian (pas de wikilinks → pas de graphe, pas de frontmatter → pas de Bases queryable).

## Quand l'utiliser

- **Toujours** quand tu bosses sur DevBrain ou tout autre vault Obsidian
- Tu veux que Claude crée des fiches qui s'intègrent à ton vault existant
- Tu veux que les comparatifs `.base` se remplissent tout seuls

## Quand NE PAS l'utiliser

- Projet markdown qui n'est PAS un vault Obsidian (Hugo, MkDocs, GitHub README) → le skill peut ajouter des wikilinks invalides

## Comment l'installer

```bash
npx skills add kepano/obsidian-skills
```

Voir [[_installer-un-skill]] section *Obsidian skill*.

## Exemples d'usage

Le skill est passif — pas de commande. Il s'active quand tu mentionnes Obsidian / un vault / un `.md` du vault :

```
> ajoute une fiche pour le service Polars dans Services/Languages/
# Claude crée le .md avec frontmatter conforme + wikilinks corrects
```

## Pièges connus

- Le skill suit les conventions Obsidian *standard*, pas tes conventions DevBrain spécifiques — ces dernières sont dans `CLAUDE.md` et `CLAUDE-build.md`.

## Liens

- Repo : https://github.com/kepano/obsidian-skills
- Obsidian docs : https://help.obsidian.md/
