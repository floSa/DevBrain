---
galaxie: dev
nom: Kubeflow
alias: [kubeflow, kfp, kubeflow-pipelines]
categorie: ml/orchestration
sous_categories: [kubernetes-native, pipelines, training-operators]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python (Go infra)
clients_officiels: [python, cli]
plateforme: [linux]
score: 
mes_projets: []
alternatives: ["[[Flyte]]", "[[ZenML]]", "[[Metaflow]]", "[[Dagster]]", "[[Airflow]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ml, orchestration, kubernetes, pipelines]
url_officiel: https://www.kubeflow.org/
url_docs: https://www.kubeflow.org/docs/
url_repo: https://github.com/kubeflow/kubeflow
---

# Kubeflow

## Pourquoi
Plateforme MLOps **native Kubernetes**. Suite complète : Pipelines (KFP), Notebooks, Training Operators (TFJob, PyTorchJob), Katib (hyperopt), KServe (serving), Model Registry. Le standard quand l'entreprise est full-K8s et veut tout intégrer.

## Quand l'utiliser
- Stack data/ML déjà sur Kubernetes
- Multi-tenant (namespaces, profiles)
- Besoin d'un écosystème complet vs lib Python isolée
- Equipe ops qui sait gérer K8s
- Cloud providers managés : GCP Vertex Pipelines (compat KFP), AWS SageMaker via KServe

## Quand NE PAS l'utiliser
- Pas de K8s → over-engineering massif → [[ZenML]], [[Metaflow]], [[Flyte]]
- Petit projet / petite équipe → coût ops > bénéfice
- Tu veux juste des pipelines Python simples → [[Dagster]] / [[Prefect]]

## Pièges connus
- **Installation** : non-trivial (Istio, cert-manager, dex…), utiliser **deployKF** ou distribs (Charmed, Arrikto, EzKF)
- **Versioning composants** : Kubeflow ≠ KFP ≠ Training Operators, à coordonner
- **KFP v1 → v2** : refactor majeur (modèle composants, IR), migrer
- **Dependencies size** : containers de pipelines vite gros
- **Auth / multi-tenancy** : Profiles, à comprendre dès le début
- **Notebooks** : option mais Jupyter Hub plus mature pour ce besoin seul
- **GPU scheduling** : taints/tolerations + NVIDIA device plugin

## Liens
- [[Flyte]], [[ZenML]], [[Metaflow]] — alternatives ML orchestration
- KServe (serving K8s) : https://kserve.github.io/website/
- Katib (hyperopt) : https://www.kubeflow.org/docs/components/katib/
- KFP SDK : https://kubeflow-pipelines.readthedocs.io/
- Vertex AI Pipelines (compat KFP) : https://cloud.google.com/vertex-ai/docs/pipelines/introduction
