---
galaxie: dev
nom: neuralforecast
alias: [nixtla-neuralforecast]
categorie: ml/framework
sous_categories: [forecasting, time-series, deep-learning, nbeats, tft, deepar]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[darts]]", "[[Prophet]]", "[[statsforecast]]"]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, time-series, forecasting, deep-learning, nixtla]
url_officiel: https://nixtlaverse.nixtla.io/neuralforecast/
url_docs: https://nixtlaverse.nixtla.io/neuralforecast/
url_repo: https://github.com/Nixtla/neuralforecast
---

# neuralforecast

## Pourquoi

Sœur DL de [[statsforecast]] dans la stack Nixtla. Implémente les architectures **deep learning state-of-the-art** pour forecasting : N-BEATS, N-HiTS, TFT (Temporal Fusion Transformer), DeepAR, PatchTST, TimeMixer, plus une douzaine d'autres. API unifiée pandas/polars (long format), cross-validation walk-forward intégrée.

Quand tu veux du DL sur séries temporelles sans monter une infra Lightning custom, c'est le choix par défaut en 2025-2026.

## Quand l'utiliser

- Beaucoup de séries (transfer learning entre séries possible : un seul modèle pour mille SKU)
- Patterns complexes (saisonnalités multiples, interactions, covariables exogènes)
- Quand statistical (ARIMA, ETS, Prophet) plafonne en performance
- Forecasting probabiliste (intervalles de confiance, quantiles)
- Tu fais de la recherche / veille sur les archis TS (N-HiTS, PatchTST, TimeMixer, etc.)

## Quand NE PAS l'utiliser

- Une seule série de quelques centaines de points → DL overkill, [[statsforecast]] ou [[Prophet]]
- Pas de GPU → entraînement très lent pour les gros modèles (TFT, PatchTST)
- Besoin d'**interprétabilité** (qui pèse dans la prédiction) → DL = boîte noire, [[Prophet]] mieux
- Production sur infra contrainte mémoire → certains modèles consomment beaucoup

## Pièges connus

- Format long obligatoire (`unique_id`, `ds`, `y`, plus optionnellement les covariables)
- **Tuning** crucial : les valeurs par défaut sont raisonnables mais souvent sub-optimales — toujours benchmark avec [[Walk-forward CV]]
- GPU recommandé dès que tu sors de N-BEATS basique
- Reproductibilité : random seeds globales nécessaires pour benchmarks fiables (`pytorch_lightning.seed_everything(...)`)

## Liens

- Doc officielle : https://nixtlaverse.nixtla.io/neuralforecast/
- Repo : https://github.com/Nixtla/neuralforecast
- Concepts liés : [[Forecasting framing]] (souvent Multi-output natif), [[Walk-forward CV]]
- Suite Nixtla : [[statsforecast]] (statistical), `mlforecast` (ML)
- Alternatives : [[darts]] (couvre statistical + ML + DL dans une seule API)
