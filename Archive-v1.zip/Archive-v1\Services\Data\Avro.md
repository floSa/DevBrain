---
galaxie: dev
nom: Avro
alias: [avro, apache-avro]
categorie: data/format
sous_categories: [serialization, schema, streaming, kafka]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Java
clients_officiels: [python (fastavro, avro), java, c, c++, c#, go]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["Protocol Buffers", "JSON", "Parquet (analytique)"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, format, streaming, avro]
url_officiel: https://avro.apache.org/
url_docs: https://avro.apache.org/docs/current/
url_repo: https://github.com/apache/avro
---

# Avro

## Pourquoi

Format de **sérialisation row-based** avec schéma JSON intégré. Standard de fait dans l'écosystème **Kafka / Confluent Schema Registry** : compact, binaire, **schema-evolution natif** (forward / backward / full compat). Aussi utilisé en data warehouses (Hadoop legacy, Hive) pour les workloads row-oriented.

Vs Parquet : Parquet = columnar, optimal analytique. Avro = row-based, optimal streaming / row-by-row ingestion.

## Quand l'utiliser

- **Streaming Kafka / Pulsar / Kinesis** avec Schema Registry (compatibilité forward/backward gérée)
- **Échange système-à-système typé** (vs JSON non-typé)
- **Storage row-based** pour ingestion sequentielle
- **Schema evolution** propre (renommer champs via aliases, ajouter avec defaults)
- Combo Kafka Connect / Debezium / Confluent Cloud

## Quand NE PAS l'utiliser

- **Analytique columnar** → [[Parquet]] (10-100x plus rapide en analytique)
- **Échange humain-lisible** → JSON (debug, configs)
- **Sans schéma stable** → Protocol Buffers / MessagePack
- **gRPC** → Protobuf (intégration native)
- **Volumes massifs analytiques** → Parquet ou Iceberg

## Pièges connus

- **Schema mgmt critique** : breaking changes (ajout sans default, suppression non-aliased) cassent les consumers en streaming
- **Outils SQL peu performants** vs Parquet : Hive / Spark / Trino lisent Avro mais analytique sera lent
- **Lib Python `avro` standard** : très lente. **Toujours préférer `fastavro`** (10-100x).
- **Schema Registry** = service critique : indispo → pas de produce / consume
- **Confluent format vs Apache format** : Confluent wrap avec magic byte + schema ID, pas portable directement
- **Logical types** (decimal, date, timestamp-millis) : support inégal entre langages
- **Nested types** : possibles mais alourdissent le schema

## Code minimal

```python
# fastavro : implementation Python rapide
# pip install fastavro
from fastavro import writer, reader, parse_schema

schema = {
    "doc": "User event",
    "name": "UserEvent",
    "namespace": "com.example",
    "type": "record",
    "fields": [
        {"name": "user_id", "type": "long"},
        {"name": "event_type", "type": {"type": "enum",
                                          "name": "EventType",
                                          "symbols": ["CLICK", "VIEW", "PURCHASE"]}},
        {"name": "ts_ms", "type": "long", "logicalType": "timestamp-millis"},
        # Schema evolution: nouveau champ avec default
        {"name": "session_id", "type": ["null", "string"], "default": None},
    ],
}
parsed_schema = parse_schema(schema)

records = [
    {"user_id": 1, "event_type": "CLICK", "ts_ms": 1700000000000, "session_id": "abc"},
    {"user_id": 2, "event_type": "VIEW",  "ts_ms": 1700000010000},  # session_id default
]

with open("events.avro", "wb") as f:
    writer(f, parsed_schema, records)

with open("events.avro", "rb") as f:
    for record in reader(f):
        print(record)

# Avec Kafka + Confluent Schema Registry (confluent-kafka-python)
# from confluent_kafka import Producer
# from confluent_kafka.schema_registry import SchemaRegistryClient
# from confluent_kafka.schema_registry.avro import AvroSerializer
# sr_client = SchemaRegistryClient({"url": "http://schema-registry:8081"})
# serializer = AvroSerializer(sr_client, schema_str=json.dumps(schema))
# producer = Producer({"bootstrap.servers": "kafka:9092"})
# producer.produce(topic="events", value=serializer(record, ctx))
```

## Liens

- [[Parquet]] — columnar alternative pour analytique
- **fastavro** : https://github.com/fastavro/fastavro
- **Confluent Schema Registry** : https://docs.confluent.io/platform/current/schema-registry/index.html
- **Protocol Buffers** (Google, alt) : https://protobuf.dev/
- Apache Avro spec : https://avro.apache.org/docs/current/specification/
