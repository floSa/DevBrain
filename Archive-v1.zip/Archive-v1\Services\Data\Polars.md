---
galaxie: dev
nom: Polars
alias: [polars-rs, polars-python]
categorie: data/transformation
sous_categories: [dataframe, columnar, lazy, rust]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Rust
clients_officiels: [python, rust, nodejs, r]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: [pandas, modin, dask, "[[DuckDB]]"]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, data, dataframe, performance]
url_officiel: https://pola.rs/
url_docs: https://docs.pola.rs/
url_repo: https://github.com/pola-rs/polars
---

# Polars

## Pourquoi

DataFrame library écrite en **Rust** (avec bindings Python), conçue pour la perf et la mémoire. Versus pandas : 5-30× plus rapide sur la plupart des opérations, supporte le **lazy evaluation** (plan d'exécution optimisé), syntaxe expressive, multithreading natif.

C'est l'alternative pandas qui s'impose en 2025-2026 pour les workloads où pandas commence à montrer ses limites (mémoire, monothreading, opérations chaînées coûteuses).

## Quand l'utiliser

- Dataset trop gros pour pandas (>1GB en RAM) mais pas assez pour passer à Spark
- Pipelines avec beaucoup d'opérations chaînées (groupby, join, agg) — le lazy mode brille
- Tu écris du code data en équipe et tu veux des types stricts (Polars rejette les ambiguïtés type que pandas tolère)
- Interop avec [[DuckDB]] / Arrow / Parquet

## Quand NE PAS l'utiliser

- Code legacy énorme en pandas — la migration coûte cher
- Stack data sciences avec scikit-learn/XGBoost — pandas reste plus directement supporté (mais Polars rattrape via `.to_pandas()`)
- Notebook d'exploration rapide : la verbosité Polars est parfois plus longue que `df[df.col > 5]`

## Pièges connus

- API ressemble à pandas mais diffère : `select`, `with_columns`, `filter` au lieu de l'indexation par crochets
- Le lazy mode (`.lazy()`) impose un mental model différent — tu dois appeler `.collect()` à la fin
- Certaines libs ML/stat ne savent pas encore parler Polars natif → `.to_pandas()` ou `.to_numpy()` en sortie

## Liens

- Doc : https://docs.pola.rs/
- Repo : https://github.com/pola-rs/polars
- [[DuckDB]] (combinaison fréquente : Polars pour la transfo, DuckDB pour le SQL)
- [[Parquet]]
