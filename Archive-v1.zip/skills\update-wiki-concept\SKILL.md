---
name: update-wiki-concept
description: |
  Use this skill to patch an existing concept fiche in Wiki/Concepts/.
  Triggers: "modifie le concept", "patch <nom concept>", "mets à jour
  le concept <nom>", "enrichis ma fiche <concept>", or when the user
  brings new material (URL, note, paper) to integrate into an existing
  concept. Preserves the rest of the fiche, updates 'modified:' date.
---

# Skill — update-wiki-concept

## Quand l'utiliser

L'utilisateur veut **enrichir ou corriger** un concept existant dans `Wiki/Concepts/`, pas en créer un nouveau. Exemples :
- "Ajoute la référence au paper X dans la fiche [[RAG]]"
- "Le piège Y manque dans [[PCA]]"
- "Mets à jour [[Embeddings]] avec la nouvelle section sur les sparse encoders"

Différent de `add-wiki-concept` (création) ou `expand-stub` (passer un stub à fiche complète).

## Pré-requis vault

Mode wiki. Périmètre `Wiki/Concepts/` uniquement.

## Procédure

1. **Localiser** la fiche : `Wiki/Concepts/<Nom>.md`. Si nom ambigu, demander.
2. **Lire** le frontmatter + corps actuel.
3. **Identifier la section** à patcher (TL;DR, Le problème, L'idée, Quand utile, Pièges, Implémentations, Pour aller plus loin).
4. **Demander à l'utilisateur** le contenu à ajouter/modifier :
   - Sous quelle forme : ajout (append à une section), remplacement (rewrite), ou correction ponctuelle ?
   - Si URL ou note brute fournie, propose une réécriture intégrée.
5. **Préserver** ce qui n'est pas touché — pas de rewrite intégral.
6. **Mettre à jour** `modified:` à la date du jour dans le frontmatter.
7. **Wikilinker** les nouvelles références (si un nouveau concept est cité, vérifier qu'il existe ; sinon proposer un stub).
8. **Montrer le diff** à l'utilisateur avant écriture.
9. **Écrire** après validation.

## Anti-patterns à éviter

- **Rewrite complet** de la fiche pour un petit ajout → patch ciblé, préserve la voix existante
- **Oublier `modified:`** dans le frontmatter
- **Wikilinks fantômes** → cf. `cross-link` après gros enrichissement
- **Sortir du périmètre** Wiki/Concepts/

## Voir aussi

- `add-wiki-concept` (création)
- `expand-stub` (stub → fiche complète)
- `cross-link` (audit des liens après modifs)
