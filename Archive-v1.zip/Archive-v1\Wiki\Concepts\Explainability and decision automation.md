---
galaxie: wiki
nom: Explainability and decision automation
alias: [explainability, XAI, audit-decision, AI-act, GDPR-article-22, decision-explanation]
type: concept
categorie: concept/business-rules
sous_categories: [xai, explainability, audit, gdpr, ai-act, dmn, ml-eng]
domaines: [ml-eng, ai-eng, data-science]
maturite: emerging
auteurs_cles: [Marco Tulio Ribeiro (LIME), Scott Lundberg (SHAP), EU AI Act, CNIL]
lecture_min: 9
created: 2026-05-21
modified: 2026-05-21
tags: [concept, explainability, xai, dmn, audit, regulation]
---

# Explainability and decision automation

## TL;DR

Pour qu'une **décision automatisée** soit acceptable (légalement, éthiquement, opérationnellement), elle doit être **explicable** : pouvoir dire *pourquoi cette décision a été prise pour ce cas spécifique*. Deux familles d'approches : (1) **explicabilité by design** — utiliser des modèles intrinsèquement lisibles (règles DMN, decision trees simples, régression linéaire) ; (2) **explicabilité post-hoc** — appliquer des techniques (SHAP, LIME, counterfactuals) sur des boîtes noires (deep learning, gradient boosting). En decision automation hybride **DMN + ML**, la DMN apporte naturellement l'explication "règle" et SHAP/LIME explique le score ML. Contexte régulatoire : **RGPD Article 22**, **EU AI Act** (2024), **Bâle / MIFID** côté finance.

## Le problème

Une décision automatisée refuse un crédit, un poste, une admission, un remboursement, une libération conditionnelle. Trois questions :

1. **L'individu** demande : *"Pourquoi moi, pourquoi maintenant ?"*
2. **Le régulateur** demande : *"Votre système discrimine-t-il ?"*
3. **L'opérationnel** demande : *"Si je voulais que cette décision change, que faudrait-il modifier ?"*

Sans explicabilité, tu ne peux répondre à aucune des trois. Et la régulation impose maintenant des **droits à l'explication** sur les décisions automatisées significatives.

## L'idée

### Cadre régulatoire

#### RGPD — Article 22 (UE, 2018)

*"La personne concernée a le droit de ne pas faire l'objet d'une décision fondée exclusivement sur un traitement automatisé, y compris le profilage, produisant des effets juridiques la concernant ou l'affectant de manière significative."*

Exceptions : si nécessaire au contrat, si autorisé par loi, si consentement explicite. Mais même dans ces cas, **droit à information significative** sur la logique sous-jacente + **intervention humaine** + **contester la décision**.

#### EU AI Act (2024, application progressive 2025-2027)

Classe les systèmes IA en **4 niveaux de risque** :
- **Inacceptable** (interdit) : social scoring, manipulation cognitive
- **Haut risque** : recrutement, crédit, justice, santé, infrastructures critiques → **obligations strictes** (documentation, transparence, supervision humaine, robustesse, audit)
- **Limité** : chatbots, deepfakes → obligations de transparence
- **Minimal** : tout le reste → encouragements

Pour le **haut risque** (où vivent la plupart des décisions automatisées) : explainability est **obligatoire**, pas optionnelle.

#### Sectoriel

- **Bâle (banque)** : modèles de risque crédit doivent être documentés, testés, défendables (FRB SR 11-7 aux US)
- **MIFID II (finance EU)** : algorithmes de trading doivent être documentés
- **FDA (santé US)** : IA médicale → "Good Machine Learning Practice"
- **CNIL (FR)** : pratiques d'audit IA

### Explicabilité by design — modèles intrinsèquement explicables

#### Decision rules (DMN, BRMS)

L'explication est **la règle qui a tiré** :

```
Décision : refused
Raison :
  Règle r4 (Decision table "Eligibility") a matché :
    age in [25..65] AND income < 15000
    → "refused"
```

L'explication est **trivialement lisible** par un humain. Le régulateur n'a pas besoin de SHAP : la règle EST l'explication. Voir [[Decision Tables]].

#### Decision trees / random forests "shallow"

Un arbre de décision peu profond (< 10 niveaux) est lisible : *"Tu as été classé X parce que feature1 > seuil1 ET feature2 < seuil2 ET ..."*. Les random forests "shallow" + visualisation arbre par arbre fonctionnent.

#### Régression linéaire / logistique

Coefficient par feature → contribution explicite. *"Ton score = +0.5 (income) - 0.3 (debt) + 0.2 (history) + ..."*. Très lisible si features bien choisies.

#### Modèles additifs (GAMs, EBM)

**Generalized Additive Models** (e.g. **Explainable Boosting Machine** de Microsoft, library `interpret`) : contribution par feature visible, presque aussi performant qu'un XGBoost sur tabulaire, vraiment explicable.

#### Trade-off perf vs explicabilité

En 2026, sur la plupart des problèmes tabulaires métier, un **GAM ou XGBoost shallow + SHAP** est compétitif avec deep learning et infiniment plus explicable.

### Explicabilité post-hoc — pour boîtes noires

Pour des modèles complexes (deep learning, gradient boosting profond), techniques après-coup :

#### SHAP — SHapley Additive exPlanations (Lundberg 2017)

Basé sur théorie des jeux (valeurs de Shapley). Pour une prédiction donnée, calcule la **contribution de chaque feature** au score, de façon **mathématiquement cohérente** (axiomes d'efficience, symétrie, additivité).

```
Prediction score : 0.78
SHAP values :
  + income       : +0.20  (high income → augmente acceptance)
  + history_yrs  : +0.15  (long history → augmente)
  + has_house    : +0.08  (homeowner → augmente)
  - debt_ratio   : -0.12  (high debt → diminue)
  - recent_loan  : -0.05
  base value      : 0.52
                  -----
                  = 0.78
```

#### LIME — Local Interpretable Model-agnostic Explanations (Ribeiro 2016)

Approximation locale : autour d'une prédiction, entraîne un **modèle simple** (linear) qui mimique le comportement de la boîte noire **dans ce voisinage**. Le modèle simple est lisible.

Plus rapide que SHAP mais moins théoriquement fondé. Bon pour debugging interactif.

#### Counterfactual explanations

*"Si ton income était de 35000 au lieu de 25000, ta décision serait 'approve'."*

Plus actionnable pour l'individu. Frameworks : **DiCE** (Microsoft Research), **alibi** (Seldon).

#### Anchors

*"Aussi longtemps que income > 30000, ta décision restera 'approve' (95% des cas similaires)."*. Règles avec couverture explicite.

#### Saliency maps (vision)

Pour images : surligner les pixels qui contribuent (Grad-CAM, Integrated Gradients). Moins applicable au tabulaire métier.

### Pattern hybride DMN + ML explainable

Architecture cible :

```
Inputs
  ↓
ML Model (score) + SHAP (raisons du score)
  ↓
DMN Decision (applique règles métier sur score + autres inputs)
  ↓
Décision finale + audit complet :
  - quelles règles ont tiré
  - quel score ML
  - quelles features ML ont contribué le plus
  - si manual_review : raison de la suggestion
```

Avantage : **double explication**. Le régulateur ou l'individu voit *"refusé parce que règle r4 a matché (score ML 0.45 < seuil 0.5, et income < 15k)"* + *"les features ML qui ont pesé sur le 0.45 sont : recent_chargebacks (-0.20), short_history (-0.10), high_debt_ratio (-0.08)"*.

### Audit trail structure

Pour chaque décision, stocker :

```json
{
  "decision_id": "dec_xyz",
  "timestamp": "2026-05-21T14:32:11Z",
  "subject": {"customer_id": "C-12345"},
  "inputs": {"...": "raw inputs"},
  "ml": {
    "model_id": "credit_v3.2",
    "model_version_hash": "abc...",
    "score": 0.78,
    "shap_values": {"income": 0.20, "history": 0.15, ...},
    "top_contributing_features": ["income", "history", "debt"]
  },
  "rules": {
    "dmn_model_version": "v12",
    "decision_table_id": "credit_decision",
    "rules_fired": ["r2", "r5"],
    "hit_policy": "UNIQUE",
    "human_readable_explanation": "score ML > 0.7 et income > 50k -> approve"
  },
  "human_review": null,
  "outcome": "approve",
  "downstream_action": "loan_offer_456"
}
```

Retenu **N années** selon réglementation sectorielle (7 ans typique banque).

### Recours humain

Article 22 RGPD + AI Act imposent un **droit à intervention humaine**. Architecture :

```
[Décision automatisée] → [Notification à l'individu]
                              │
                              ├── accepte → fin
                              └── conteste
                                    ↓
                              [Review humaine]
                                    ↓
                  ├── confirme la décision auto
                  └── override (avec justification)
                                    ↓
                              [Outcome enregistré + dataset retraining]
```

DMN + BPMN orchestrent ce flow naturellement.

### Biais et fairness

Explicabilité ≠ fairness. Un système peut être **expliqué** et **discriminatoire**. Outils complémentaires :

- **Disparate impact analysis** : taux d'approbation par groupe (genre, ethnie, âge)
- **Fairness metrics** : equal opportunity, demographic parity, predictive parity
- **Frameworks** : **Aequitas**, **AIF360** (IBM), **Fairlearn** (Microsoft)

DMN aide à **identifier les règles discriminatoires explicites** (e.g. "if gender = 'female' then ..." — illégal). ML peut introduire des **discriminations implicites** via features corrélées (e.g. code postal corrélé à ethnie).

### Outils et bibliothèques

| Outil | Type | Notes |
|---|---|---|
| **SHAP** (`shap` Python) | Post-hoc | référence, intègre XGBoost / LGBM / DL |
| **LIME** (`lime` Python) | Post-hoc | rapide, debug interactif |
| **DiCE** (`dice-ml`) | Counterfactuals | actionnable pour individu |
| **alibi** (`alibi`) | Multi-méthodes | Seldon, prod-ready |
| **EBM** (`interpret`) | By design | GAM SOTA, Microsoft |
| **AIF360** | Fairness | IBM, audit biais |
| **Fairlearn** | Fairness | Microsoft |
| **Aequitas** | Audit | University of Chicago |
| **What-If Tool** | Exploration | Google, visuel |
| **Captum** | DL | PyTorch, pour DL |

Côté DMN : tous les engines (Camunda, Drools) ont un **mode debug** qui trace les règles tirées → explication native.

## Quand c'est utile

- **Toute décision automatisée à impact significatif** (article 22 RGPD)
- **Systèmes IA haut-risque** (EU AI Act)
- **Finance / assurance** : justification crédit, sinistres, fraude
- **Recrutement** : justifier rejet candidature
- **Santé** : aide à diagnostic doit être justifiable
- **Justice prédictive** : COMPAS controversé → exigence explicabilité
- **B2B contractuel** : SLA peut exiger explainability dans le contrat
- **Trust interne** : équipes ops adoptent mieux un système qu'elles comprennent

## Quand ça ne marche pas / pièges

- **Explainability sans audit organisé** : SHAP en log mais jamais relu → théâtre conformité
- **SHAP sur features non-interprétables** : si tes features sont des embeddings (256 dim float), SHAP donne `embed_42: +0.05` → inutile pour humain
- **Confondre explainability et causality** : SHAP montre **contribution au modèle**, pas **cause réelle** dans le monde
- **Modèle "explainable" trop simple** : sacrifier 20% d'accuracy pour explainability peut être contre-productif → utiliser GAM/EBM qui balancent bien
- **Anchors / counterfactuals sur espaces continus haute dim** : combinatoirement coûteux, perf médiocre
- **Bias confirmé par explainability** : un système explicable mais discriminatoire est pire (tu n'as plus l'excuse "boîte noire") → audit fairness séparé
- **Explication aux experts vs aux individus** : SHAP/LIME OK pour data scientist, illisible pour client → besoin de "human-readable summary" généré
- **Trade-off perf vs explainability** : pas toujours réel (GAMs/EBM compétitifs sur tabulaire) — vérifier avant de céder à la complexité
- **Régulateur veut "explication globale"** vs technique SHAP "explication locale" : besoin des deux (PDP + ICE plots pour global)
- **Explicabilité ≠ transparence du code** : montrer le code source du modèle ≠ expliquer une décision (open-source ML reste boîte noire pour utilisateur lambda)

## Code minimal

### SHAP sur un modèle XGBoost

```python
import xgboost as xgb
import shap
import pandas as pd

model = xgb.XGBClassifier()
model.fit(X_train, y_train)

# Explainer
explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X_test)

# Plot global (importance moyenne par feature)
shap.summary_plot(shap_values, X_test)

# Explication individuelle (waterfall)
shap.waterfall_plot(explainer.expected_value, shap_values[0], X_test.iloc[0])

# Top-3 features contributives pour un cas spécifique
def top_contributors(shap_vals_row, feature_names, top_n=3):
    pairs = sorted(zip(feature_names, shap_vals_row), key=lambda x: abs(x[1]), reverse=True)
    return pairs[:top_n]

print(top_contributors(shap_values[0], X_test.columns))
# [('income', 0.20), ('debt_ratio', -0.12), ('history_years', 0.15)]
```

### Couplage SHAP + DMN

```python
def decide_with_audit(customer, request):
    # 1. Score ML + SHAP
    features = build_features(customer, request)
    score = float(model.predict_proba(features)[0][1])
    shap_vals = explainer.shap_values(features)[0]
    top_factors = sorted(
        zip(features.columns, shap_vals),
        key=lambda x: abs(x[1]), reverse=True
    )[:5]

    # 2. DMN avec score comme input
    dmn_inputs = {"score_ml": score, "income": customer["income"], "is_vip": customer.get("vip", False)}
    status, dmn_out = dmn.decide(dmn_inputs)

    # 3. Audit complet
    audit_record = {
        "decision_id": generate_id(),
        "decision": dmn_out["decision"],
        "ml_score": score,
        "ml_top_factors": [{"feature": f, "shap_value": float(v)} for f, v in top_factors],
        "dmn_rules_fired": dmn_out.get("rules_fired", []),
        "human_readable": generate_explanation(dmn_out, top_factors),
        "timestamp": now_iso(),
        "model_versions": {"ml": "v3.2", "dmn": "v12"},
    }
    audit_db.insert(audit_record)

    return {**dmn_out, "audit_id": audit_record["decision_id"]}

def generate_explanation(dmn_out, top_factors):
    rules_str = ", ".join(dmn_out.get("rules_fired", []))
    factors_str = ", ".join(f"{f} ({'+' if v > 0 else ''}{v:.2f})" for f, v in top_factors[:3])
    return f"Décision: {dmn_out['decision']}. Règles: {rules_str}. Facteurs ML clés: {factors_str}."
```

### EBM (modèle by-design explicable, Microsoft)

```python
from interpret.glassbox import ExplainableBoostingClassifier
from interpret import show

ebm = ExplainableBoostingClassifier()
ebm.fit(X_train, y_train)
ebm.score(X_test, y_test)   # souvent comparable à XGBoost

# Visualisation interactive (global + local)
ebm_global = ebm.explain_global()
show(ebm_global)            # graphes par feature, lisibles

ebm_local = ebm.explain_local(X_test[:5], y_test[:5])
show(ebm_local)             # contribution par feature pour chaque cas
```

### Counterfactuals avec DiCE

```python
import dice_ml

d = dice_ml.Data(dataframe=df_train, continuous_features=['income', 'age'],
                 outcome_name='approved')
m = dice_ml.Model(model=ml_model, backend='sklearn')
exp = dice_ml.Dice(d, m)

# Pour un cas refusé, générer 3 contrefactuels qui seraient acceptés
query_instance = X_test.iloc[[0]]
counterfactuals = exp.generate_counterfactuals(query_instance,
                                               total_CFs=3,
                                               desired_class="opposite")
counterfactuals.visualize_as_dataframe()
# -> "si income était 45000 au lieu de 28000, et debt_ratio < 0.3, la décision serait approve"
```

### Audit fairness avec Fairlearn

```python
from fairlearn.metrics import demographic_parity_difference, equal_opportunity_difference

y_pred = model.predict(X_test)

# Sur attribut sensible (e.g. genre)
dp_diff = demographic_parity_difference(y_test, y_pred, sensitive_features=X_test["gender"])
eo_diff = equal_opportunity_difference(y_test, y_pred, sensitive_features=X_test["gender"])

print(f"Demographic parity gap: {dp_diff:.3f}")
print(f"Equal opportunity gap:  {eo_diff:.3f}")
# Alerter si > seuil acceptable
```

## Pour aller plus loin

- Christoph Molnar, *Interpretable Machine Learning* (2022) — la bible open : https://christophm.github.io/interpretable-ml-book/
- Lundberg & Lee, *A Unified Approach to Interpreting Model Predictions* (SHAP, NeurIPS 2017)
- Ribeiro et al., *"Why Should I Trust You?" Explaining the Predictions of Any Classifier* (LIME, KDD 2016)
- EU AI Act (texte officiel) : https://artificialintelligenceact.eu/
- CNIL — recommandations IA : https://www.cnil.fr/fr/intelligence-artificielle
- Google PAIR — *People + AI Guidebook* : https://pair.withgoogle.com/
- O'Neil, *Weapons of Math Destruction* (2016) — fondation éthique
- **Liens internes** : [[Decision Model and Notation]], [[DMN and ML hybrid]], [[Decision Intelligence]], [[Decision Tables]], [[AI security]], [[Guardrails]], [[Data drift]], [[Bias-variance tradeoff]], [[Calibration]]
