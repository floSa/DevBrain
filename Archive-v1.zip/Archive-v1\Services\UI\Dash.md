---
galaxie: dev
nom: Dash
alias: [dash, plotly-dash]
categorie: ui/dashboard
sous_categories: [dashboard, plotly, web-app, python, reactive]
licence: MIT
licence_type: open-source
hosted: self ou cloud (Plotly Enterprise)
maturite: production
langage: Python
clients_officiels: [python, r, julia]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[Streamlit]]", "[[Gradio]]", "[[Shiny for Python]]", "Panel", "Solara"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ui, dashboard, python, reactive]
url_officiel: https://dash.plotly.com/
url_docs: https://dash.plotly.com/
url_repo: https://github.com/plotly/dash
---

# Dash

## Pourquoi

Framework dashboard Python par **Plotly**. Apps web **full Python** : layout déclaré en Python (composants React sous le capot), interactivité via **callbacks réactifs** (`@callback(Output(...), Input(...))`). Aucun JS à écrire côté app, le rendu est React+Flask servi par le framework.

Positionnement : **dashboards analytics entreprise**, plus structuré que Streamlit, plus puissant pour apps complexes (multi-pages, layouts custom, state management). Combo natif avec [[plotly]]. **Dash Enterprise** (payant) ajoute Snapshot Engine, App Manager, scaling. Le pattern callback est plus rigide que Streamlit mais scale mieux pour des apps de 5000+ lignes.

## Quand l'utiliser

- **Dashboards analytics complexes** : multi-page, layouts grid/tabs, sidebars
- **Combo [[plotly]]** : intégration native, charts interactifs
- **Apps métier internes** Python-only (data analysts, BI)
- **State management explicite** : `dcc.Store` pour partager données entre callbacks
- **Multi-page apps** : routing natif via `dash.register_page`
- **Plotly Enterprise existant** : Dash Enterprise = upgrade naturel
- **Apps > 1000 lignes** : structure de callbacks scale mieux que script Streamlit linéaire
- **Composants riches** : Dash Mantine, Dash AG Grid, Dash Cytoscape

## Quand NE PAS l'utiliser

- **App rapide < 100 lignes** → [[Streamlit]] / [[Gradio]] (1 page, prototype)
- **UI mobile-first** : Dash possible mais pas son fort
- **LLM / Chat UI** → [[Gradio]] / Chainlit (composants ChatInterface natifs)
- **R / Shiny equivalent** → [[Shiny for Python]] plus moderne
- **Très peu de logique réactive** : Streamlit plus simple
- **Sans Plotly** : sans charts plotly, Dash perd son avantage clé

## Pièges connus

- **Callback pattern à apprendre** : `Input`, `Output`, `State`, prevent_initial_call, callback context — courbe initiale
- **State management plus dur que Streamlit** : pas de variable globale magique, utiliser `dcc.Store`
- **Pas de hot-reload aussi smooth** que Streamlit (mais existe : `app.run(debug=True)`)
- **Dash Enterprise payant** pour Snapshot, App Manager, Kubernetes Manager (4-5 chiffres / an)
- **Composants React custom** : créer un composant ad-hoc demande dev React + plotly tooling
- **Layout statique** vs dynamique : layouts changeants doivent être renvoyés par callback
- **Multi-output callbacks** : possibles mais syntaxe lourde
- **Long callbacks** : pour ops > 30s, `background callbacks` avec Celery / DiskCache (config supplémentaire)
- **Cold start lent** sur apps avec beaucoup de pages : `prevent_initial_call=True` partout
- **CSS custom** : possible mais demande de connaître Bootstrap / Mantine

## Code minimal

```bash
pip install dash
# Avec composants riches :
pip install dash-bootstrap-components dash-mantine-components dash-ag-grid
```

```python
# app.py : Dash minimal
from dash import Dash, dcc, html, Input, Output, callback
import plotly.express as px
import pandas as pd

df = px.data.gapminder().query("year == 2007")

app = Dash(__name__)

app.layout = html.Div([
    html.H1("Gapminder 2007", style={"textAlign": "center"}),
    dcc.Dropdown(
        id="continent",
        options=[{"label": c, "value": c} for c in df["continent"].unique()],
        value="Europe",
        clearable=False,
    ),
    dcc.Graph(id="bubble"),
])

@callback(Output("bubble", "figure"), Input("continent", "value"))
def update_bubble(continent):
    sub = df[df["continent"] == continent]
    fig = px.scatter(sub, x="gdpPercap", y="lifeExp", size="pop",
                     color="country", hover_name="country", log_x=True,
                     size_max=60)
    return fig

if __name__ == "__main__":
    app.run(debug=True)
```

```python
# Multi-page app
# app.py
from dash import Dash, html, dcc, page_container, page_registry

app = Dash(__name__, use_pages=True)
app.layout = html.Div([
    html.Nav([dcc.Link(p["name"], href=p["path"]) for p in page_registry.values()]),
    page_container,
])

# pages/home.py
import dash
from dash import html
dash.register_page(__name__, path="/")
layout = html.Div([html.H1("Home")])

# pages/analytics.py
import dash
from dash import html
dash.register_page(__name__, path="/analytics")
layout = html.Div([html.H1("Analytics")])
```

```python
# State management avec dcc.Store
from dash import Dash, dcc, html, Input, Output, State, callback, ALL

app = Dash(__name__)
app.layout = html.Div([
    dcc.Store(id="cart", data=[]),
    dcc.Input(id="item", type="text"),
    html.Button("Add", id="add-btn"),
    html.Ul(id="cart-list"),
])

@callback(
    Output("cart", "data"),
    Input("add-btn", "n_clicks"),
    State("item", "value"), State("cart", "data"),
    prevent_initial_call=True,
)
def add_to_cart(_clicks, item, cart):
    if not item:
        return cart
    return cart + [item]

@callback(Output("cart-list", "children"), Input("cart", "data"))
def render_cart(cart):
    return [html.Li(it) for it in cart]
```

```python
# Background callback pour ops longues
from dash import Dash, DiskcacheManager, CeleryManager
import diskcache

cache = diskcache.Cache("./cache")
background_callback_manager = DiskcacheManager(cache)
app = Dash(__name__, background_callback_manager=background_callback_manager)

@callback(
    Output("result", "children"),
    Input("submit", "n_clicks"),
    background=True,
    running=[(Output("submit", "disabled"), True, False)],
)
def long_job(_):
    import time; time.sleep(20)
    return "Done !"
```

## Liens

- [[Streamlit]] — alternative plus simple pour prototypes
- [[Gradio]] — alternative LLM / ML demos
- [[Shiny for Python]] — alternative inspirée R/Shiny
- Panel — alternative basée Bokeh
- Solara — alternative React-like
- [[plotly]] — combo natif (charts interactifs)
- Dash Bootstrap Components / Mantine / AG Grid — bibliothèques de composants
- Docs : https://dash.plotly.com/
- GitHub : https://github.com/plotly/dash
