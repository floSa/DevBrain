---
galaxie: wiki
nom: Reasoning models
alias: [o1, o3, DeepSeek-R1, GRPO, test-time compute, long CoT, PRM]
type: concept
categorie: concept/llm-families
sous_categories: [reasoning, o1, r1, test-time-compute, llm]
domaines: [ai-eng]
maturite: emerging
auteurs_cles: [DeepSeek 2025 (R1), OpenAI (o1, o3)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, reasoning, frontier]
---

# Reasoning models

## TL;DR

**Paradigme 2024+** : modèles qui **"pensent"** longuement avant de répondre, via **Chain-of-Thought interne**. **OpenAI o1, o3, o4** ; **DeepSeek-R1, R1-Zero, R1-Distill** ; **Qwen QwQ / QvQ, Qwen 3 thinking** ; **Anthropic extended thinking** (Sonnet/Opus 3.7+) ; **Gemini Thinking** ; **Kimi K1.5, K2** (Moonshot). Concepts clés : **Process Reward Models (PRM)**, **Outcome Reward Models (ORM)**, **GRPO** (DeepSeek, RL pur sur math/code), **Long CoT generation** (10K-100K tokens), **search at inference** (MCTS, beam over thoughts). **Test-time compute scaling** : nouveau levier, plus de "thinking tokens" = meilleur. Domine AIME, MATH, GPQA, SWE-Bench. Cher (10-100x normal LLM) mais qualité massive sur reasoning.

## Le problème

LLMs standards bons à **System 1** (intuition, completion) mais **mauvais System 2** (reasoning long, multi-step, math).

→ Comment leur donner du **temps de réflexion** ? Pas plus de params, mais plus de **inference compute**.

## L'idée

### Core idea — Test-time compute

Au lieu de scaler les params (Chinchilla), scaler **le compute à l'inférence** :
- Sample plus de tokens (long CoT)
- Search over multiple chains (Tree-of-Thoughts)
- Sample multiple, vote (self-consistency)
- Use process reward model to guide

**Loi** : performance reasoning ↗ avec log(test-time compute).

### OpenAI o1 family (Sep 2024 - 2025)

- **o1-preview** → **o1** → **o1-pro** → **o3** → **o3-mini** → **o4-mini** → **o4**

Characteristics :
- **Long internal thinking** before answering (hidden from user)
- 10K-100K hidden thinking tokens typical
- **State-of-the-art** sur AIME, MATH, GPQA
- **Coût** : 10-100x un GPT-4o normal
- **Latency** : 5s - 5min per response

Use cases : math, science, code, planning.

API param : `reasoning_effort` (low / medium / high).

### DeepSeek-R1 (Jan 2025)

**Open-source competitor à o1**. Recipe published.

#### R1-Zero

**Pure RL** (pas de SFT). RL avec **verifiable rewards** (math correct / code passes tests) sur DeepSeek-V3 base.

→ Emergent CoT : modèle apprend à long CoT par lui-même.

#### R1

R1-Zero + SFT + RLHF (alignement). Polished.

Performance : comparable à o1 sur reasoning benches.

#### R1-Distill

Distillation R1 traces → small models (Llama 8B, Qwen 7B, etc.).

Boost massif. **Standard open-source moderne** pour reasoning models small.

### GRPO (Group Relative Policy Optimization)

Innovation DeepSeek pour reasoning RL (cf. [[RLHF and DPO]]) :
- Pas de critic (value model)
- Group de samples par prompt, baseline = moyenne du groupe
- Memory / compute reduits

Standard pour reasoning RL post-2024.

### Anthropic extended thinking

Claude Sonnet 3.7, Opus 4+ : tag `<thinking>` visible.

```
<thinking>
Step 1 : I need to compute...
Step 2 : Then...
</thinking>

Final answer : 42
```

User peut voir le reasoning. Plus transparent.

API param : `thinking_budget` (tokens dédié au thinking).

### Gemini Thinking

Google Gemini 2.0 / 2.5 thinking mode. Similar concept.

### Qwen 3 thinking modes

Switchable : "instant" mode vs "thinking" mode dans le même model.

### Kimi K1.5, K2

Moonshot (chinois) - reasoning models open competitive.

### Marco-o1, Skywork-o1

Open alternatives variées.

### Concepts clés

#### Chain-of-Thought as training signal

Plus que prompt-time. Trained sur traces de reasoning.

#### Long CoT generation

10K-100K tokens of internal thinking. Way more than normal CoT.

#### Process Reward Models (PRM)

Reward chaque step du reasoning :

$$ r_t = \text{PRM}(\text{state}_t, \text{step}_t) $$

vs **Outcome Reward Model (ORM)** : only reward final answer.

PRM = guidance fine-grained, but train PRM is hard.

#### Verifiable rewards

Pour math : answer correct or not (binary).
Pour code : tests pass or not.

→ Don't need PRM. Train RL on outcome.

R1-Zero showed pure RL with verifiable works.

#### Search at inference

- **MCTS** : Monte Carlo Tree Search over reasoning steps
- **Beam search** sur thoughts
- **LATS** (Language Agent Tree Search)
- **Best-of-N** sampling

Plus de search → meilleur. Coût exploser.

#### Self-consistency

Sample N reasoning chains, vote majoritaire. Boost sans RL.

#### Reflexion / self-critique

Modèle critique son own reasoning, révise.

### Trade-offs

| Reasoning model | Normal LLM |
|---|---|
| Best on math/code/science | OK on simple tasks |
| 10-100x cost | Cheap |
| 5s - 5min latency | <1s |
| Hidden thinking | Direct response |
| Specialized | General-purpose |
| Bad on creative writing | OK |
| Slow user interaction | Real-time chat |

### Use cases idéaux

- **Math problems**
- **Scientific reasoning** (GPQA-style)
- **Code generation hard** (SWE-Bench)
- **Multi-step planning**
- **Olympiad / competition style**
- **Strategic decisions**
- **Theorem proving**
- **Complex debugging**

### Use cases mauvais

- **Casual chat**
- **Quick Q&A**
- **Creative writing**
- **Real-time agents**
- **Cost-sensitive apps**
- **Simple instructions**

### Patterns d'usage

#### Direct call

```python
response = openai.chat.completions.create(
    model="o1-preview",
    messages=[{"role": "user", "content": "Solve this..."}]
)
```

Pas de system prompt (early o1). Variants relaxant ça.

#### Cascade : normal → reasoning

```python
response_fast = call_llm("claude-3-7-sonnet", query)
if confidence_low(response_fast):
    response_slow = call_llm("o3", query)
```

#### Hybrid : tool + reasoning

Reasoning model + tools = strong agents (Claude Code, Devin, OpenAI deep research).

### Inference-time scaling laws

Plus de compute = meilleur, log-linear :
- 1K thinking tokens → score A
- 10K → A + 10%
- 100K → A + 15% (diminishing)

Pareto curve : balance perf vs cost.

### Distillation reasoning

R1-Distill : distill reasoning traces → smaller model. Excellent results.

→ Permet "small reasoning models" : Qwen-R1-Distill 7B competitive avec GPT-4o sur math.

### Best practices

1. **Use reasoning model pour reasoning** : math, code, planning
2. **Standard LLM pour le reste** : chat, summarize, etc.
3. **Cascade** : essayer cheap first
4. **Mesurer ROI** : cost vs perf gain
5. **Reasoning effort tune** : low / medium / high
6. **Async UX** : long latency → progress indicator
7. **Cache responses** : reasoning expensive
8. **Distilled R1 / Qwen** pour cost-conscious
9. **Open R1 distill** pour self-host
10. **Combine avec tools** : agents reasoning + actions

## Quand c'est utile

- **Math / scientific problems**
- **Code generation hard** (Devin-style)
- **Multi-step planning**
- **Research assistants**
- **Theorem proving**
- **Complex code review**
- **Strategic / decision support**
- **Olympiad-style problems**
- **Long-horizon agents**
- **Reasoning RL training**

## Quand ça ne marche pas / pièges

- **Quick chat** : overkill, slow, expensive
- **Creative writing** : structure-driven thinking can hurt
- **Real-time** : latency too high
- **Cost** : 10-100x normal LLM
- **Hallucinations still happen** : reasoning ≠ correct
- **Bad on common sense** : sometimes worse than smaller models (overthinking)
- **Tools missing** : early o1 no function calling, fixed later
- **System prompt early o1** : not allowed, fixed later
- **R1 base safety** : open weights → variable safety
- **Confidence calibration** : reasoning models can be overconfident
- **Over-reasoning simple problems** : "2+2" devient long thinking

## Code minimal

```python
# 1. OpenAI o3
from openai import OpenAI
client = OpenAI()

response = client.chat.completions.create(
    model="o3-mini",
    messages=[
        {"role": "user", "content": "If 2x + 3 = 11, what is x?"}
    ],
    reasoning_effort="medium"  # low / medium / high
)
print(response.choices[0].message.content)
# Internal reasoning hidden. Output : "x = 4"

# Get reasoning tokens (count, not content)
print(response.usage.completion_tokens_details.reasoning_tokens)

# 2. DeepSeek-R1 (open via HF ou DeepSeek API)
from openai import OpenAI
client = OpenAI(api_key="...", base_url="https://api.deepseek.com")

response = client.chat.completions.create(
    model="deepseek-reasoner",  # R1
    messages=[{"role": "user", "content": "..."}]
)
print(response.choices[0].message.reasoning_content)  # Full CoT!
print(response.choices[0].message.content)

# 3. Anthropic extended thinking
import anthropic
client = anthropic.Anthropic()

response = client.messages.create(
    model="claude-opus-4-7-latest",
    max_tokens=8192,
    thinking={"type": "enabled", "budget_tokens": 16000},
    messages=[{"role": "user", "content": "Solve this hard problem..."}]
)
# response.content contains both thinking_block + text_block

for block in response.content:
    if block.type == "thinking":
        print("THINKING:", block.thinking)
    elif block.type == "text":
        print("ANSWER:", block.text)

# 4. R1-Distill (open, local)
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

model_id = "deepseek-ai/DeepSeek-R1-Distill-Qwen-7B"
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.bfloat16, device_map="auto")

messages = [{"role": "user", "content": "What is the derivative of x^3 - 5x^2 + 3?"}]
prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
inputs = tokenizer(prompt, return_tensors="pt").to("cuda")

output = model.generate(**inputs, max_new_tokens=2048, temperature=0.6, top_p=0.95)
print(tokenizer.decode(output[0], skip_special_tokens=True))
# Will show <think>...</think> tags + final answer

# 5. Self-consistency on reasoning
def self_consistent_reason(query, n=10):
    answers = []
    for _ in range(n):
        response = call_reasoning_llm(query)
        answer = extract_final_answer(response)
        answers.append(answer)
    from collections import Counter
    return Counter(answers).most_common(1)[0][0]

# 6. Cascade : normal → reasoning
def smart_cascade(query):
    fast = call_llm("claude-3-7-sonnet", query)
    if needs_reasoning(query, fast):
        return call_llm("o3", query)
    return fast

def needs_reasoning(query, response):
    # Heuristic : math, multi-step, low confidence
    if any(kw in query.lower() for kw in ["solve", "prove", "compute", "calculate"]):
        return True
    if "I'm not sure" in response:
        return True
    return False

# 7. GRPO training (sketch)
# Use TRL GRPOTrainer
from trl import GRPOTrainer, GRPOConfig

# config = GRPOConfig(
#     output_dir="./grpo-output",
#     num_train_epochs=1,
#     per_device_train_batch_size=4,
#     num_generations=8,  # group size
# )

def verifiable_reward(completion, ground_truth):
    answer = extract_answer(completion)
    return 1.0 if answer == ground_truth else 0.0

# trainer = GRPOTrainer(model=model, reward_funcs=[verifiable_reward], args=config, ...)
# trainer.train()
```

## Pour aller plus loin

- OpenAI, *Learning to Reason with LLMs* (o1 blog 2024)
- DeepSeek-AI, *DeepSeek-R1: Incentivizing Reasoning Capability in LLMs via Reinforcement Learning* (2025)
- Shao et al., *DeepSeekMath* (2024) — GRPO original
- Anthropic, *Claude 3.7 Sonnet with extended thinking* (2025)
- Lightman et al., *Let's Verify Step by Step* (OpenAI 2023) — PRM
- Yao et al., *Tree of Thoughts* (NeurIPS 2023)
- Snell et al., *Scaling LLM Test-Time Compute Optimally can be More Effective than Scaling Model Parameters* (2024)
- *R1-Distill* models on HuggingFace
- **Liens internes** : [[Chain-of-Thought]], [[RLHF and DPO]] (GRPO), [[Scaling laws]], [[Prompt engineering]], [[Distillation]]
