---
galaxie: wiki
nom: uv
type: cli-tool
plateforme: cli
categorie: skill/dev-flow
sous_categories: [python, package-manager, env]
auteur: Astral (créateurs de Ruff)
source: astral-sh/uv
source_url: https://github.com/astral-sh/uv
install_cmd: "powershell -c \"irm https://astral.sh/uv/install.ps1 | iex\"   # Windows | curl -LsSf https://astral.sh/uv/install.sh | sh   # Unix"
install_doc: https://docs.astral.sh/uv/getting-started/installation/
licence: MIT
licence_type: open-source
domaines: [data-science, data-eng, mlops, ml-eng, ai-eng]
score: 5
status: used
mes_projets: [DevBrain]
created: 2026-05-19
modified: 2026-05-19
tags: [cli, python, package-manager]
---

# uv

## Pourquoi

**Le** remplaçant moderne de pip + virtualenv + pip-tools + pyenv, écrit en Rust par Astral. 10-100× plus rapide que pip, gère les environnements virtuels et les versions de Python automatiquement. Utilisé partout dans l'écosystème Anthropic/MCP (notamment `uvx mcp-obsidian` dans DevBrain).

Si tu fais du Python en 2026 et que tu n'as pas encore basculé, fais-le. C'est l'install la plus rentable de l'année.

## Quand l'utiliser

- **Tout projet Python** : init, run, install, lock
- Lancer un script Python sans créer d'environnement (`uvx`)
- Lancer un outil one-shot (`uvx mcp-obsidian`, `uvx ruff check`, etc.)
- Gérer plusieurs versions de Python sur la même machine

## Quand NE PAS l'utiliser

- Projet legacy avec un Pipfile / poetry / conda déjà bien rodé → migration possible mais à coût
- Conda specifique pour des binaires scientifiques rares non-PyPI (vieux ABI, etc.)

## Comment l'installer

```powershell
# Windows PowerShell
irm https://astral.sh/uv/install.ps1 | iex
```

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Voir [[_installer-un-skill]] section *CLI tool*.

## Exemples d'usage

```bash
# Nouveau projet
uv init mon-projet
cd mon-projet
uv add fastapi pandas

# Lancer un script
uv run script.py

# Lancer un outil sans installer
uvx ruff check .
uvx mcp-obsidian  # ce que fait DevBrain

# Gérer Python lui-même
uv python install 3.12
uv python pin 3.12
```

## Pièges connus

- Les `requirements.txt` legacy sont supportés mais pas l'idéal — passe à `pyproject.toml` + `uv.lock` quand tu peux
- Sur Windows, les chemins très longs (>260 chars) posent parfois problème → active long-paths dans la registry

## Liens

- Doc officielle : https://docs.astral.sh/uv/
- Repo : https://github.com/astral-sh/uv
