---
galaxie: wiki
nom: Ensembling
alias: [ensemble methods, bagging, boosting, stacking, blending]
type: concept
categorie: concept/ml
sous_categories: [bagging, boosting, stacking, random-forest, gradient-boosting]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Breiman 1996 (Bagging), Freund-Schapire 1997 (AdaBoost), Friedman 2001 (GBM)]
lecture_min: 10
created: 2026-05-19
modified: 2026-05-19
tags: [concept, ml, ensembling, bagging, boosting]
---

# Ensembling

## TL;DR

Combiner plusieurs modèles pour obtenir une prédiction plus robuste qu'un seul. 3 familles principales : **bagging** (entraîner en parallèle sur des bootstraps, moyenner — réduit la variance, ex. Random Forest), **boosting** (entraîner en séquence, chaque modèle corrige les erreurs du précédent — réduit le biais, ex. [[XGBoost]] / [[LightGBM]] / [[CatBoost]]), **stacking** (un méta-modèle apprend à combiner les prédictions). Tous gagnent en moyenne sur un modèle unique, c'est le **free lunch** du ML supervisé.

## Le problème

Un modèle unique a ses faiblesses :
- Choisit une représentation/structure parmi plusieurs candidates raisonnables
- Sensible au tirage train (variance)
- Peut être biaisé sur certains motifs des données

L'ensembling exploite l'**incorrelation** entre modèles : leurs erreurs sont (partiellement) indépendantes, donc en les combinant on en réduit l'effet net.

## L'idée

### Bagging — Bootstrap Aggregating

1. Tirer $B$ **bootstraps** (échantillons avec remise) du dataset
2. Entraîner $B$ modèles "de base" indépendamment, un par bootstrap
3. Prédiction finale : **moyenne** (régression) ou **vote majoritaire** (classification)

**Effet** : si les $B$ modèles ont une variance individuelle $\sigma^2$ et que leurs erreurs sont **partiellement décorrélées** (corrélation $\rho < 1$), la variance de l'ensemble est :

$$ \mathrm{Var}_{\text{ens}} = \rho \sigma^2 + \frac{1 - \rho}{B} \sigma^2 $$

Pour $B \to \infty$ et $\rho < 1$, la variance tend vers $\rho \sigma^2$ — strictement inférieure à $\sigma^2$.

**Random Forest** = bagging d'arbres + **randomisation des features** à chaque split (pour décorréler les arbres).

### Boosting

Au lieu d'entraîner en parallèle, on entraîne **en séquence**. À chaque itération $t$ :
1. Le modèle $f_t$ se concentre sur les exemples **mal prédits** par l'ensemble $\sum_{s<t} f_s$
2. Soit en repondérant les exemples (AdaBoost)
3. Soit en fittant le **gradient de la loss** par rapport à la prédiction courante (Gradient Boosting)

Prédiction finale : somme pondérée :

$$ F(x) = \sum_{t=1}^T \eta \cdot f_t(x) $$

avec $\eta$ le **learning rate** (typiquement 0.01-0.3).

**Gradient Boosting** est le framework dominant en 2025-2026 : [[XGBoost]], [[LightGBM]], [[CatBoost]]. Différences entre les 3 : voir leurs fiches.

**Effet** : réduit le **biais** (à l'inverse du bagging qui réduit la variance). Au prix d'un risque d'overfit si pas de régularisation / early stopping.

### Stacking

1. Entraîner $K$ modèles **différents** (linéaire, RF, XGBoost, NN…)
2. Récupérer leurs prédictions **out-of-fold** (via CV) sur le train
3. Entraîner un **méta-modèle** (souvent régression linéaire ou XGBoost simple) qui prend ces $K$ prédictions en entrée et produit la prédiction finale

Le méta-modèle apprend à **pondérer** les modèles selon leur compétence sur différentes régions des données.

**Variantes** :
- **Blending** : version simple avec un holdout au lieu de CV
- **Multi-level** : empiler plusieurs couches de stacking (rare, coûteux)

### Bagging vs Boosting vs Stacking — comparatif

| Critère | Bagging | Boosting | Stacking |
|---|---|---|---|
| Parallélisable | ✅ oui | ❌ séquentiel | partiellement |
| Réduit | Variance | Biais | Les deux |
| Risque overfit | Faible | Modéré (sans régul) | Élevé si mal calibré |
| Tuning | Peu d'hyperparams | Beaucoup (η, depth, n_estim, regs) | Méta-modèle à choisir |
| Exemples | Random Forest, ExtraTrees | XGBoost, LightGBM, CatBoost | Compétitions Kaggle |
| Effort | Bas | Moyen | Élevé |

### Cas particuliers et nuances

- **Out-of-Bag (OOB) error** : sur Random Forest, ~37% des points ne sont jamais tirés dans un bootstrap → on peut les utiliser comme test "gratuit" pour estimer l'erreur sans CV séparée
- **Feature importance** : disponible nativement dans Random Forest et boosting (SHAP, gain, split, permutation)
- **Diversité** : ensembling marche d'autant mieux que les modèles sont **différents**. Empiler 3 XGBoost à params proches n'apporte rien.

## Quand c'est utile

- **Toujours** tester un Gradient Boosting comme baseline en supervisé tabulaire
- Compétitions / haute précision recherchée : stacking apporte typiquement 1-3% supplémentaires
- Problèmes avec haute variance individuelle : Random Forest stabilise

## Quand ça ne marche pas / pièges

- **Données très structurées** (images, texte, audio) : préférer un modèle dédié (CNN, Transformer) — l'ensembling de modèles tabulaires sur ces données est pertinent uniquement après extraction de features
- **Boosting sans early stopping** : overfit silencieux
- **Stacking sans CV-OOF** : leakage massif (le méta-modèle voit les prédictions du modèle entraîné sur les mêmes données qu'il prédit)
- **Trop d'arbres** dans RF : pas d'effet après ~100-500, juste du coût en mémoire
- **Confondre boosting et stacking** : ce sont des paradigmes différents
- **Interprétabilité** : un ensemble est moins interprétable qu'un modèle simple. Outils : SHAP, LIME, PDP.

## Code minimal

```python
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier
from sklearn.model_selection import cross_val_score

# Bagging
rf = RandomForestClassifier(n_estimators=500, n_jobs=-1, random_state=0)

# Boosting
xgb = XGBClassifier(n_estimators=500, learning_rate=0.05, max_depth=6,
                    early_stopping_rounds=20, random_state=0)

# Stacking
stack = StackingClassifier(
    estimators=[
        ('rf', RandomForestClassifier(n_estimators=200)),
        ('xgb', XGBClassifier(n_estimators=200)),
        ('lr', LogisticRegression(max_iter=1000)),
    ],
    final_estimator=LogisticRegression(),
    cv=5,
    n_jobs=-1,
)

for name, model in [('RF', rf), ('XGB', xgb), ('Stack', stack)]:
    scores = cross_val_score(model, X, y, cv=5, scoring='roc_auc')
    print(f"{name}: AUC = {scores.mean():.3f} ± {scores.std():.3f}")
```

## Implémentations concrètes

- `sklearn.ensemble` : `RandomForestClassifier/Regressor`, `GradientBoostingClassifier/Regressor`, `StackingClassifier/Regressor`, `VotingClassifier`
- [[XGBoost]], [[LightGBM]], [[CatBoost]] — les trois grands gradient boosting
- `mlxtend` — bonnes utilitaires stacking
- `darts` / `statsforecast` / `neuralforecast` — ensembling natif pour time series

## Pour aller plus loin

- Breiman, *Bagging predictors* (1996) et *Random Forests* (2001) — papers fondateurs
- Friedman, *Greedy function approximation: a gradient boosting machine* (2001) — paper canonique
- Hastie, Tibshirani, Friedman, *ESL* — chap. 10 et 15
- Wolpert, *Stacked generalization* (1992) — paper original stacking
- **Liens internes** : [[Bias-variance tradeoff]] (explique pourquoi ça marche), [[Cross-validation]] (utilisée pour stacking et hyperparam tuning), [[XGBoost]] / [[LightGBM]] / [[CatBoost]]
