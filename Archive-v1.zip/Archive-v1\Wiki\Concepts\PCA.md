---
galaxie: wiki
nom: Principal Component Analysis (PCA)
alias: [PCA, ACP, Analyse en Composantes Principales]
type: concept
categorie: concept/stats
sous_categories: [factor-analysis, dimensionality-reduction, svd, continuous]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Pearson 1901, Hotelling 1933]
lecture_min: 10
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, pca, factor-analysis]
---

# Principal Component Analysis (PCA)

## TL;DR

Étant donné un nuage de points dans $\mathbb{R}^p$, on cherche les **directions orthogonales qui maximisent la variance**. Projection sur les k premières directions = compression linéaire optimale au sens de la variance résiduelle minimisée. Le calcul revient à **diagonaliser la matrice de covariance** (ou faire la **SVD de la matrice centrée**).

## Le problème

Données $X \in \mathbb{R}^{n \times p}$ : $n$ individus, $p$ variables continues. Quand $p$ est grand et les variables corrélées, on veut :
- **Visualiser** en 2D-3D
- **Compresser** sans perdre trop d'information
- **Décorréler** pour des modèles downstream (regression, clustering)
- Identifier des **axes de variation latents** ("ce qui distingue les individus")

## L'idée

### Géométriquement

On cherche un sous-espace de dimension $k < p$ tel que la **projection orthogonale** des points sur ce sous-espace minimise l'erreur quadratique de reconstruction. De manière équivalente, elle **maximise la variance** des points projetés.

### Algébriquement

Soit $X$ centrée (chaque colonne moyenne 0). On note la matrice de covariance empirique :

$$ S = \frac{1}{n-1} X^\top X $$

$S$ est symétrique semi-définie positive → décomposition spectrale :

$$ S = V \Lambda V^\top $$

avec $\Lambda = \mathrm{diag}(\lambda_1 \geq \lambda_2 \geq \dots \geq \lambda_p \geq 0)$ et $V = [v_1, \dots, v_p]$ orthogonale.

**Les composantes principales** sont $Z = XV$. La $j$-ème composante $z_j = X v_j$ a pour variance $\lambda_j$.

### Via SVD (numériquement préférable)

$$ X = U \Sigma V^\top $$

avec $\Sigma = \mathrm{diag}(\sigma_1, \dots, \sigma_p)$ et $\lambda_j = \sigma_j^2 / (n-1)$.
Les **scores** $Z = U \Sigma$, les **loadings** $V$.

### Variance expliquée

La fraction de variance expliquée par les $k$ premiers axes :

$$ \tau_k = \frac{\sum_{j=1}^k \lambda_j}{\sum_{j=1}^p \lambda_j} $$

Critère de choix de $k$ : viser $\tau_k \geq 0.7$ à 0.9 selon contexte, OU **scree plot** (coude des $\lambda_j$).

### Standardisation : centrer ET réduire ?

- **Centrer seulement** (covariance PCA) : utile quand toutes les variables sont dans la même unité (ex. pixels d'image)
- **Centrer + réduire** (correlation PCA) : indispensable quand unités différentes (ex. taille en cm + poids en kg) — sinon la variable à grande variance écrase les autres

## Quand c'est utile

- Visualisation 2D/3D d'un dataset multi-dimensionnel
- Pré-traitement avant clustering (réduit le bruit, accélère)
- Détection d'outliers (points loin dans le sous-espace principal)
- Compression d'images, embeddings
- Préliminaire à des méthodes plus complexes (factor analysis, MFA…)

## Quand ça ne marche pas / pièges

- **Variables non-continues** → utiliser [[MCA]] ou [[FAMD]]
- **Relations non-linéaires** → t-SNE, UMAP, ou kernel PCA
- **Variables sur des échelles très différentes sans normalisation** → résultats dominés par la variable à grande variance
- **Outliers extrêmes** → tirent les axes ; envisager une PCA robuste
- **Interprétabilité** : les composantes principales sont des **combinaisons linéaires** des variables originales, pas toujours lisibles. Toujours regarder les **loadings** ($V$) pour interpréter.
- **Confusion variance / information** : une PCA maximise la variance, ce n'est pas toujours synonyme de l'information utile pour la tâche downstream (cf. supervised PCA, LDA pour classification).

## Code minimal

```python
import numpy as np
from sklearn.decomposition import PCA

# Standardiser
X_std = (X - X.mean(axis=0)) / X.std(axis=0)

pca = PCA(n_components=2).fit(X_std)
scores = pca.transform(X_std)        # individus dans le plan principal
loadings = pca.components_.T          # contribution variable → axe
explained = pca.explained_variance_ratio_   # [τ_1, τ_2]
```

Avec [[prince]] (école française, plus de diagnostics) :

```python
from prince import PCA
pca = PCA(n_components=2, rescale_with_std=True).fit(df)
pca.plot(df)   # biplot direct
```

## Implémentations concrètes

- `sklearn.decomposition.PCA` — la baseline
- [[prince]] — façon française, fournit cos², contributions, qualités de représentation
- `numpy.linalg.svd` — si tu veux contrôler chaque détail
- `scipy.linalg.eigh` — diagonalisation symétrique efficace

## Pour aller plus loin

- Variante robuste aux outliers : Robust PCA (Candès, 2011)
- Variante non-linéaire : kernel PCA, autoencoder
- Variante parcimonieuse : Sparse PCA (Zou, 2006)
- **Liens internes** : [[CA]] (équivalent pour categorical), [[MCA]] (extension >2 categorical), [[FAMD]] (mix continu/catégoriel), [[MFA]] (groupes de variables), [[embeddings]] (alternative apprise)
- Pages Husson/Pagès "Analyse de données avec R" — référence francophone
