---
galaxie: dev
nom: MySQL
alias: [mysql, mariadb]
categorie: database/relational
sous_categories: [oltp, sql, acid]
licence: GPL v2 / commercial
licence_type: open-source
hosted: both
maturite: production
langage: C++
clients_officiels: [python, ts, go, rust, java, ruby, php]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[Postgres]]", "[[SQLite]]", "[[CockroachDB]]", MariaDB]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, database, sql, oltp]
url_officiel: https://www.mysql.com/
url_docs: https://dev.mysql.com/doc/
url_repo: https://github.com/mysql/mysql-server
---

# MySQL

## Pourquoi
Base relationnelle la plus déployée historiquement (LAMP, WordPress, Drupal). Aujourd'hui souvent supplantée par Postgres pour les nouveaux projets, mais reste massive en legacy. MariaDB = fork community-driven.

## Quand l'utiliser
- Stack existante MySQL (legacy, CMS)
- Hébergeurs mutualisés qui ne proposent que MySQL
- Replication master-slave simple
- Workloads OLTP simples avec ORM standard

## Quand NE PAS l'utiliser
- Nouveau projet greenfield → [[Postgres]] (meilleur sur tous les axes : JSON, types, extensions, conformance SQL)
- Données analytiques → ClickHouse / [[DuckDB]]
- Multi-master/multi-region → [[CockroachDB]] / Spanner
- Vector search → [[Postgres]] + pgvector

## Pièges connus
- **Conformance SQL incomplète** : NULL handling étrange, GROUP BY laxiste (avant 5.7), pas de FULL OUTER JOIN
- **Storage engines** : InnoDB seulement (MyISAM legacy, à éviter)
- **Replication** : statement-based vs row-based — choisir row-based
- **utf8 vs utf8mb4** : `utf8` est en réalité 3-byte UTF-8 (pas d'emojis). Toujours utiliser `utf8mb4`
- **GTID vs binlog-position** : préférer GTID pour replication moderne
- **MariaDB drift** : fork divergent, certaines features incompatibles MySQL 8+

## Liens
- [[Postgres]] — alternative recommandée pour nouveaux projets
- [[CockroachDB]] — pour scale-out
- MariaDB : https://mariadb.org/
- Docs MySQL : https://dev.mysql.com/doc/
