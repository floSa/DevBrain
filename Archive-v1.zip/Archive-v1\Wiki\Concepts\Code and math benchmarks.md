---
galaxie: wiki
nom: Code & math benchmarks
alias: [HumanEval, SWE-Bench, GSM8K, MATH, AIME, LiveCodeBench, BigCodeBench]
type: concept
categorie: concept/llm-eval
sous_categories: [benchmarks, code, math, reasoning, llm-eval]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Chen 2021 (HumanEval), Cobbe 2021 (GSM8K), Hendrycks 2021 (MATH)]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, eval, code, math, benchmarks]
---

# Code & math benchmarks

## TL;DR

**Code** : **HumanEval / MBPP** (saturé), **BigCodeBench** (realistic, libraries), **LiveCodeBench** (anti-contamination), **SWE-Bench Verified** (real GitHub issues, gold standard), **Aider polyglot**, **CodeContests**. **Math** : **GSM8K** (saturé), **MATH**, **AIME** (olympiad), **FrontierMath** (hardest), **MathVista** (multimodal), **Putnam-Bench**. Theorem proving : **minif2f**, **ProofNet**. Reasoning models (o1, R1, R2) dominent maths/code 2025-2026. Code agents (Claude Code, Devin, Aider) sur **SWE-Bench Verified** = standard. **pass@k** = métrique typique.

## Le problème

Code et math = **verifiable** (tests passent ou pas, réponse correcte ou pas). Idéal pour benchmarks objectifs. Hard pour LLMs sans reasoning, easier avec reasoning models.

## L'idée

### Code benchmarks

#### HumanEval (Chen 2021, OpenAI)

164 problems Python. Docstring → function body.

```python
def has_close_elements(numbers, threshold):
    """ Check if any two numbers are closer than threshold """
    # → model writes this
```

Tests : passe les unit tests ?

- **pass@k** : probability that ≥1 of k samples passes
- **State 2026** : top models pass@1 ~92%
- **Saturé**

#### HumanEval+

Augmented avec plus de tests. Discriminative again.

#### MBPP (Mostly Basic Python Problems)

974 problems plus simples. Standard avec HumanEval.

#### MBPP+

Augmented.

#### BigCodeBench (Zhuo 2024)

1140 tasks, function calls realistic (sklearn, numpy, etc.). Multi-step.

- **Active** : top models ~50-60%
- Mieux que HumanEval pour realistic

#### LiveCodeBench (Jain 2024)

Problems after model cutoff → **anti-contamination**.

#### CodeContests (DeepMind)

Codeforces problems. Plus dur.

#### APPS

Curated coding challenges.

#### SWE-Bench (Jimenez 2024)

**Real GitHub issues** à fixer dans codebases existants. Test = patch passes original tests.

Variants :
- **SWE-Bench Lite** : 300, simpler
- **SWE-Bench Verified** : 500, human-validated (cleanest), **gold standard 2026**
- **SWE-Bench Multimodal** : avec screenshots UI
- **SWE-Bench Full** : 2294 issues

State 2026 : Claude Sonnet 3.7 / Opus 4 ~70%+ SWE-Bench Verified. Devin / Claude Code / Codex publish leaderboards.

#### Aider polyglot benchmark

Multi-language code edits. Realistic agent task.

#### ClassEval

Class-level Python code generation.

#### DS-1000

Data science (pandas, numpy, etc.).

#### MultiPL-E

HumanEval translated to 18 languages.

#### CRUX-Eval

Code understanding : predict input → output (no exec).

#### CodeForces ELO

Le ranking compétitif. Top models ~1800-2100 ELO.

#### HumanEvalPack

Multi-task : explain, repair, document, translate code.

### Math benchmarks

#### GSM8K (Cobbe 2021)

Grade-school math word problems.

```
Q: Janet has 5 apples. She buys 3 more, eats 2. How many does she have?
A: 5 + 3 - 2 = 6 apples
```

- **Saturé** : top models 96%+
- Required CoT to get there

#### MATH (Hendrycks 2021)

Compétition math : algebra, geometry, number theory, etc. 12500 problems.

- **Active** : ~75-90% top models
- Standard mid-tier

#### AIME (American Invitational Mathematics Examination)

Hard olympiad. Designed for top high school students.

- **AIME 2024, AIME 2025** : released recently
- **Standard pour reasoning models** : o1, o3, R1, R2
- Top reasoning models ~80-95%

#### AMC

American Math Competition. Step before AIME.

#### Olympiad benchmarks

- **IMO** : International Math Olympiad
- **PutnamBench** : College-level
- **FrontierMath** : hardest, designed to last

#### TheoremQA

Theorem-based QA.

#### MathBench

Comprehensive math.

#### ProofNet, minif2f

Formal theorem proving (Lean, Coq).

#### MathVista

**Multimodal math** : diagrams, charts. Pour VLMs.

#### MGSM (Multilingual GSM)

GSM8K en 10 langues.

#### OpenAI MATH-500

500 problems from MATH, standard subset.

### Reasoning chain benchmarks

#### MMLU-Pro

Reasoning required vs MMLU multi-choice. Voir [[LLM benchmarks]].

#### GPQA Diamond

PhD-level science reasoning.

#### Humanity's Last Exam (HLE)

3000 expert questions.

### Métriques

#### pass@k (Codex paper)

$$ \text{pass@k} = \mathbb{E}\left[1 - \binom{n - c}{k} / \binom{n}{k}\right] $$

avec $n$ samples par problème, $c$ corrects. Probabilité qu'au moins 1 des $k$ samples passe les tests.

- **pass@1** : strict, 1 essai
- **pass@10** : avec retries

#### Accuracy

Math : exact match sur réponse finale.

#### Maj@k (majority voting)

Sample N, vote majoritaire → boost.

#### Reward-weighted vote

Vote pondéré par confidence du modèle.

#### Test set vs verifiable

- **Verifiable** : exec tests, math automated → objective
- **Verifier model** : judge approach (mathematically wrong but answer right ?)

### Reasoning model performance (2026)

Models comme o1, o3, R1, R2, Gemini Thinking :
- AIME 2024 : 80-95%
- MATH-500 : 95%+
- SWE-Bench Verified : 70%+
- LiveCodeBench : 80%+
- GPQA Diamond : 80%+

Vs non-reasoning :
- Sonnet 3.7 : MATH 80%, AIME ~40%
- GPT-4o : MATH 75%, AIME ~30%

→ Difference massive sur reasoning-heavy.

### Test-time compute scaling

Pour reasoning models, plus de "thinking" = meilleur :
- 1K thinking tokens → score A
- 10K → score A+10%
- 100K → score A+15% (diminishing)

Trade-off compute vs perf.

### Contamination

#### LiveCodeBench

Problems après training cutoff → anti-contamination.

#### Private test sets

Anthropic, OpenAI internal hold-out.

#### Memorization detection

Compare exact match vs paraphrased.

### Best practices

1. **SWE-Bench Verified** = code agent gold standard
2. **AIME / MATH / HumanEval** = math/code basics
3. **Multi-bench** : single bench misleading
4. **pass@1** for production (not pass@10 unless retries OK)
5. **Compare iso-temperature** : T=0 for deterministic
6. **Live benchmarks** for fresh signal
7. **Per-language** for code (HumanEval Python only)
8. **Watch saturation** : HumanEval 90%+ → move to BigCodeBench
9. **Track compute too** : tokens / cost per problem
10. **Cross-validate** with custom eval set

## Quand c'est utile

- **Choose code-specific model** : DeepSeek-Coder vs Qwen-Coder vs Claude
- **Choose math model** : reasoning models
- **Track frontier** : o3 vs Claude Opus 4 vs Gemini 2.5
- **Eval fine-tuned models** : check no regression
- **Research papers** : standard reporting
- **CI/CD** : LLM upgrade gate
- **Code agents** : SWE-Bench leaderboard

## Quand ça ne marche pas / pièges

- **HumanEval saturé** : no signal anymore
- **GSM8K saturé** : same
- **Contamination** : pre-training has the problems
- **Single-language** (Python) : doesn't reflect polyglot needs
- **No real-world complexity** : HumanEval ≠ real codebase
- **Math benchmarks ≠ math reasoning** : tricks vs deep understanding
- **pass@k inflated** : models with retries ≠ production
- **Compute / cost ignored** : 100x compute → SOTA score, not useful
- **Multi-language drift** : MultiPL-E translated, not native
- **Theorem proving** : niche, peu utilisable production
- **Olympiad answers leak** : online solutions

## Code minimal

```python
# 1. HumanEval (via lm-eval-harness)
# python -m lm_eval --model hf --tasks humaneval \
#     --model_args pretrained=meta-llama/Meta-Llama-3-8B-Instruct \
#     --batch_size 1

# 2. HumanEval Python from scratch
from datasets import load_dataset
import signal
import multiprocessing as mp

def run_with_timeout(code, test, timeout=5):
    """Exec code + tests in sandbox."""
    def target(queue):
        try:
            exec(code)  # WARNING : never exec untrusted in prod
            exec(test)
            queue.put("PASS")
        except Exception as e:
            queue.put(f"FAIL: {e}")
    
    queue = mp.Queue()
    p = mp.Process(target=target, args=(queue,))
    p.start()
    p.join(timeout)
    if p.is_alive():
        p.terminate()
        return "TIMEOUT"
    return queue.get() if not queue.empty() else "FAIL"

def humaneval(model):
    dataset = load_dataset("openai_humaneval")
    correct = 0
    for problem in dataset["test"]:
        completion = model(problem["prompt"])
        result = run_with_timeout(problem["prompt"] + completion, problem["test"])
        if result == "PASS":
            correct += 1
    return correct / len(dataset["test"])

# 3. SWE-Bench
# pip install swebench
# from swebench.harness.run_evaluation import main as run_swe
# Multi-step : agent produces patch → apply → run tests

# 4. GSM8K
def gsm8k_eval(model):
    dataset = load_dataset("gsm8k", "main")["test"]
    correct = 0
    for problem in dataset:
        response = model(problem["question"] + "\n\nLet's think step by step.")
        # Extract answer (e.g. "#### 42")
        import re
        answer_match = re.search(r"####\s*(-?\d+)", response)
        gold_match = re.search(r"####\s*(-?\d+)", problem["answer"])
        if answer_match and gold_match and answer_match.group(1) == gold_match.group(1):
            correct += 1
    return correct / len(dataset)

# 5. MATH eval
def math_eval(model, n_samples=100):
    dataset = load_dataset("hendrycks/competition_math")["test"][:n_samples]
    correct = 0
    for problem in dataset:
        response = model(problem["problem"])
        # Extract from \boxed{}
        import re
        pred = re.search(r"\\boxed\{([^}]+)\}", response)
        gold = re.search(r"\\boxed\{([^}]+)\}", problem["solution"])
        if pred and gold and pred.group(1).strip() == gold.group(1).strip():
            correct += 1
    return correct / n_samples

# 6. pass@k
import math
def pass_at_k(test_results, n, k):
    """test_results : list of bool per sample of one problem"""
    c = sum(test_results)
    if n - c < k:
        return 1.0
    return 1 - math.comb(n - c, k) / math.comb(n, k)

# 7. Aider polyglot
# https://github.com/Aider-AI/aider
# aider --benchmark polyglot --model claude-3-7-sonnet-latest

# 8. LiveCodeBench
# https://livecodebench.github.io/
# Live updates with new problems → anti-contamination

# 9. Self-consistency for boost reasoning
def self_consistent_math(model, problem, n=10):
    answers = []
    for _ in range(n):
        response = model(problem + "\n\nThink step by step.", temperature=0.7)
        ans = extract_answer(response)
        answers.append(ans)
    from collections import Counter
    return Counter(answers).most_common(1)[0][0]

# 10. Sandbox for safe code execution
# E2B, Modal, Daytona for production
# Never exec untrusted code directly
```

## Pour aller plus loin

- Chen et al., *Evaluating Large Language Models Trained on Code* (HumanEval, 2021)
- Cobbe et al., *Training Verifiers to Solve Math Word Problems* (GSM8K, 2021)
- Hendrycks et al., *Measuring Mathematical Problem Solving With the MATH Dataset* (NeurIPS 2021)
- Jimenez et al., *SWE-bench* (ICLR 2024)
- Jain et al., *LiveCodeBench* (2024)
- *BigCode* (HuggingFace) — BigCodeBench
- *Aider polyglot* repository
- DeepSeek-R1 paper — math/code with RL
- OpenAI o1, o3 technical reports
- **Liens internes** : [[LLM benchmarks]], [[Agent evaluation]], [[Reasoning models]], [[LLM eval metrics]]
