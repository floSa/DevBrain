---
galaxie: dev
type: rule
domaine: git
applicable: global
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, git]
---

# Règle — Git

## Principe
Commits atomiques, messages clairs, branches courtes, pas de secret committé.

## MUST

- **Commits atomiques** : un commit = un changement logique cohérent.
- **Messages au présent impératif** : "Add user auth", pas "Added" ni "Adds".
- **Pas de secret committé**. `.env`, clés, tokens — exclus via `.gitignore`. Vérifier avec `git-secrets` ou équivalent.
- **`.gitignore` couvre** : `.env`, `node_modules/`, `__pycache__/`, build artifacts, fichiers OS.
- **Pas de `git push --force` sur `main`** sauf incident majeur, et avec accord de tous les collaborateurs.
- **Pas de `git commit --no-verify`** sauf justification documentée — les hooks pre-commit sont là pour une raison.

## SHOULD

- **Format Conventional Commits** : `feat:`, `fix:`, `chore:`, `docs:`, `refactor:`, `test:`, `perf:`.
- **Branches** : `feature/<court>`, `fix/<court>`, `chore/<court>`. Pas de `dev-john`, pas de `wip-test`.
- **PR < 400 lignes diff**. Au-delà, splitter (sauf cas évident : génération auto, lockfile).
- **Rebase plutôt que merge** dans les feature branches avant PR. Garder `main` linéaire si possible.
- **Tag les releases** avec SemVer : `v1.2.3`. Annotated tags (`-a`).

## NICE-TO-HAVE

- **Signed commits** avec GPG/SSH (`commit.gpgsign=true`).
- **Hooks pre-commit** via `pre-commit` (Python) ou Husky (Node) : lint, format, tests rapides.
- **PR template** dans `.github/PULL_REQUEST_TEMPLATE.md`.

## Exemples

### Bon

```
feat(auth): add password reset endpoint

- POST /auth/reset-password
- Email with JWT token, 1h expiry
- Rate-limit 3/hour per IP

Closes #42
```

```
fix(api): handle null user_id in /me endpoint

Returned 500 instead of 401 when token was malformed.
```

### Mauvais

```
WIP
```

```
fixed bugs and other things
```

```
update
```

## Exceptions

- Hotfix critique en prod : message minimal accepté, mais commit doit rester atomique.
- Squash merge sur PR multi-commits non logiques : OK si les commits intermédiaires étaient bruts (WIP, fixup).
- Force-push : sur **branches feature** uniquement, jamais sur main/master/develop.

## Voir aussi

- [[GitHub-Actions|GitHub Actions]] — CI qui consomme ces règles
- [[Rules/Global/Security]] — section secrets
