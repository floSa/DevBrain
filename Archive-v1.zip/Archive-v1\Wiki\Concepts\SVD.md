---
galaxie: wiki
nom: SVD (Singular Value Decomposition)
alias: [SVD, décomposition en valeurs singulières]
type: concept
categorie: concept/linalg
sous_categories: [svd, decomposition, low-rank, pseudo-inverse]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Beltrami 1873, Sylvester 1889, Eckart-Young 1936]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, linalg, svd]
---

# SVD — Singular Value Decomposition

## TL;DR

Décomposition **universelle** : toute matrice $A \in \mathbb{R}^{m \times n}$ s'écrit $A = U \Sigma V^\top$ où $U, V$ sont orthogonales et $\Sigma$ diagonale (valeurs singulières). Outil le plus polyvalent de l'algèbre linéaire : sous-tend [[PCA]], low-rank approximation, pseudo-inverse Moore-Penrose, recommandation par factorisation, débruitage, compression.

## Le problème

On veut un outil **général** pour décomposer une matrice quelconque (rectangulaire, non-carrée, singulière) en composants interprétables. Contrairement à l'eigendecomposition qui ne marche que pour les matrices carrées et symétriques (ou diagonalisables), la SVD existe pour **toute matrice réelle**.

## L'idée

### Définition

Soit $A \in \mathbb{R}^{m \times n}$. La SVD est :

$$ A = U \Sigma V^\top $$

avec :
- $U \in \mathbb{R}^{m \times m}$ orthogonale (vecteurs singuliers gauches)
- $V \in \mathbb{R}^{n \times n}$ orthogonale (vecteurs singuliers droits)
- $\Sigma \in \mathbb{R}^{m \times n}$ diagonale, valeurs $\sigma_1 \geq \sigma_2 \geq \dots \geq \sigma_r > 0 = \sigma_{r+1} = \dots$ où $r = \text{rang}(A)$

### Interprétation géométrique

$A$ transforme la sphère unité en un ellipsoïde. Les valeurs singulières $\sigma_i$ sont les **demi-axes de l'ellipsoïde**, et $u_i, v_i$ sont les directions.

```
  v_i  →  σ_i u_i
  (input direction)  →  (output direction × stretch)
```

### Variantes

#### SVD complète vs économique

- **Complète** : $U$ carrée $m \times m$, $V$ carrée $n \times n$. Stocke des zéros inutiles.
- **Économique (thin SVD)** : $U \in \mathbb{R}^{m \times r}$, $\Sigma \in \mathbb{R}^{r \times r}$, $V \in \mathbb{R}^{n \times r}$ avec $r = \min(m, n)$ ou $\text{rang}(A)$. Plus pratique.

#### Truncated SVD

Garder seulement les $k$ premières valeurs singulières :

$$ A_k = U_k \Sigma_k V_k^\top, \quad k < r $$

Théorème d'**Eckart-Young** : $A_k$ est la **meilleure approximation de rang $k$** au sens des normes Frobenius et spectrale :

$$ \|A - A_k\|_F = \sqrt{\sum_{i=k+1}^r \sigma_i^2}, \quad \|A - A_k\|_2 = \sigma_{k+1} $$

### Lien avec eigendecomposition

- Vecteurs singuliers de droite $V$ = vecteurs propres de $A^\top A$
- Vecteurs singuliers de gauche $U$ = vecteurs propres de $A A^\top$
- $\sigma_i = \sqrt{\lambda_i}$ où $\lambda_i$ sont les valeurs propres de $A^\top A$

Pour $A$ symétrique semi-définie positive, SVD et eigendecomposition coïncident (à un signe près).

### Pseudo-inverse Moore-Penrose

$$ A^+ = V \Sigma^+ U^\top $$

où $\Sigma^+$ inverse les $\sigma_i$ non-nuls et garde les zéros. Permet de **résoudre des systèmes mal-posés** $Ax = b$ avec $A$ non-carrée ou singulière :

- Si $A$ inversible : $A^+ = A^{-1}$
- Sinon : $A^+ b$ est la solution de norme minimale du problème des moindres carrés

### Stabilité numérique

La SVD est **la décomposition la plus stable numériquement**. À utiliser de préférence à l'eigendecomposition quand c'est possible. Coût : $O(\min(m, n) \cdot mn)$ pour SVD complète.

## Quand c'est utile

- **PCA** = SVD sur la matrice centrée (cf. [[PCA]])
- **Low-rank approximation** : compression d'images, débruitage
- **Latent Semantic Analysis (LSA)** : SVD sur matrice TF-IDF → topics latents
- **Collaborative filtering** : SVD ou variantes (SVD++, MF) pour recommandation
- **Pseudo-inverse** : régression linéaire mal posée, contrôle de robots
- **Détermination du rang** : compter les $\sigma_i > $ seuil
- **Conditionnement** : $\kappa(A) = \sigma_1 / \sigma_r$ — indique si une matrice est mal conditionnée
- **LoRA** (Low-Rank Adaptation) : adapter un grand modèle en n'apprenant que des updates de rang faible

## Quand ça ne marche pas / pièges

- **Coût mémoire/calcul** sur grandes matrices : SVD complète est $O(mn \min(m,n))$. Pour `m, n > 10000` → utiliser truncated SVD (`scipy.sparse.linalg.svds`, sklearn `TruncatedSVD`, randomized SVD).
- **Signe non-déterminé** : $U \Sigma V^\top = (-U) \Sigma (-V)^\top$. Pour la reproductibilité, fixer une convention (ex. premier élément non-nul positif).
- **Matrices très denses en haute dimension** : la SVD complète sature mémoire. Préférer **randomized SVD** (Halko-Martinsson-Tropp 2011).
- **Sparse matrices** : SVD dense la détruit en mémoire. Utiliser variantes sparse.
- **Confusion avec eigendecomposition** : SVD existe toujours, eigendecomp pas toujours. Sur matrices symétriques SDP les deux coïncident.
- **Choix de $k$ pour truncated** : pas de méthode universelle. Critères : variance expliquée, scree plot, ou cross-validation sur tâche downstream.

## Code minimal

```python
import numpy as np
from scipy.linalg import svd
from sklearn.decomposition import TruncatedSVD

A = np.random.randn(100, 50)

# SVD complète (lapack via scipy)
U, s, Vt = svd(A, full_matrices=False)  # économique
print(f"Singular values: {s[:5]}...")
print(f"Reconstruction error: {np.linalg.norm(A - U @ np.diag(s) @ Vt):.2e}")

# Pseudo-inverse via SVD
A_pinv = np.linalg.pinv(A)
# == Vt.T @ np.diag(1/s) @ U.T

# Low-rank approximation (rang k)
k = 10
A_k = U[:, :k] @ np.diag(s[:k]) @ Vt[:k, :]
relative_error = np.linalg.norm(A - A_k) / np.linalg.norm(A)
print(f"Approx rang {k}: erreur relative = {relative_error:.3f}")

# Pour grandes matrices ou sparse — randomized SVD
from sklearn.utils.extmath import randomized_svd
U_rand, s_rand, Vt_rand = randomized_svd(A, n_components=10, random_state=0)

# sklearn TruncatedSVD (utilisé en LSA)
svd_model = TruncatedSVD(n_components=10).fit_transform(A)
```

## Pour aller plus loin

- Trefethen & Bau, *Numerical Linear Algebra* (1997) — chap. 4-5
- Halko, Martinsson, Tropp, *Finding Structure with Randomness* (2011) — randomized SVD
- *The Singular Value Decomposition* (3Blue1Brown YouTube) — visualisation
- **Liens internes** : [[PCA]], [[Eigendecomposition]], [[Vector norms]], [[Matrix decompositions]]
