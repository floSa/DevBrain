---
galaxie: wiki
nom: GRPO
alias: [GRPO, Group Relative Policy Optimization, DeepSeek-R1, R1-Zero]
type: concept
categorie: concept/llm-training
sous_categories: [rl, grpo, ppo, llm, reasoning, deepseek, verifiable-rewards]
domaines: [ai-eng, ml-eng]
maturite: emerging
auteurs_cles: [Shao et al. 2024 (DeepSeekMath), DeepSeek-R1 paper 2025]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, rl, grpo, reasoning]
---

# GRPO — Group Relative Policy Optimization

## TL;DR

Variante de [[PPO]] introduite par **DeepSeek (Shao et al. 2024)** pour entraîner des **reasoning models** type R1. Différence principale : **pas de critic / value model**. À la place, on échantillonne $G$ réponses pour le même prompt, on calcule un **avantage relatif** dans le groupe (z-score sur les récompenses). Économise la moitié de la mémoire (un seul modèle au lieu de policy + value), et marche très bien avec des **récompenses vérifiables** (math correct, code passe les tests). C'est la recette derrière **DeepSeek-R1** (et l'inspiration de beaucoup de reasoning models open source 2024-2026).

## Le problème

PPO RLHF classique demande quatre modèles en mémoire :
1. **Policy** π_θ : le LLM qu'on entraîne
2. **Reference** π_ref : SFT model frozen
3. **Reward model** r_φ : entraîné sur préférences
4. **Critic / value head** : estime V_φ(s)

Sur des LLMs 70B+, c'est très coûteux. Et le critic est notoirement **dur à entraîner** sur du texte (gros bruit, signaux retardés). **Idée GRPO** : se passer du critic en estimant l'avantage **par comparaison entre samples du même prompt** — exactement comme un humain juge "cette réponse est meilleure que celle-là".

## L'idée

### Setup

Pour chaque prompt $q$ du batch :
1. Échantillonner **$G$ réponses** $\{o_1, o_2, \dots, o_G\}$ avec la politique courante $\pi_{\theta_{\text{old}}}$
2. Calculer une **récompense** $r_i$ pour chaque $o_i$ (verifiable ou RM)
3. Calculer l'**avantage relatif** :

$$ \hat A_i = \frac{r_i - \text{mean}(\{r_1, \dots, r_G\})}{\text{std}(\{r_1, \dots, r_G\}) + \epsilon} $$

C'est une **z-score normalisation** : on récompense les réponses au-dessus de la moyenne du groupe, on pénalise celles en dessous.

### Objectif

À chaque token $t$ de la réponse $o_i$, on applique un objectif PPO-style clippé, en utilisant $\hat A_i$ comme avantage :

$$ \mathcal{L}^{\text{GRPO}}(\theta) = \mathbb{E}_{q, \{o_i\}} \frac{1}{G} \sum_{i=1}^{G} \frac{1}{|o_i|} \sum_{t=1}^{|o_i|} \min\Big( r_t^{(i)} \hat A_i, \; \text{clip}(r_t^{(i)}, 1 - \epsilon, 1 + \epsilon) \hat A_i \Big) - \beta \cdot \text{KL}(\pi_\theta \| \pi_{\text{ref}}) $$

avec $r_t^{(i)} = \pi_\theta(o_{i,t} | q, o_{i,<t}) / \pi_{\theta_{\text{old}}}(o_{i,t} | q, o_{i,<t})$.

**Important** : l'avantage est **constant sur tous les tokens de la même réponse** (pas de credit assignment par token via un critic). C'est une approximation qui s'avère fonctionner.

### Différences vs PPO

| Aspect | PPO | GRPO |
|---|---|---|
| Critic / value | $V_\phi(s)$ entraîné par TD | aucun |
| Estimateur d'avantage | GAE (variance-reduced) | z-score dans le groupe |
| Mémoire | 4 modèles | 3 modèles (pas de critic) |
| Per-token reward | possible (clip par token, avantage variable) | avantage constant sur la réponse |
| Sample efficiency | meilleure (TD bootstrap) | dépend de G |
| Stabilité | éprouvée | bonne empiriquement, mais moins de théorie |

### Verifiable rewards

GRPO brille avec des récompenses **objectives** :

- **Maths** : on extrait la réponse finale, on compare au ground truth → reward = 1 ou 0
- **Code** : exécuter les tests unitaires → reward = fraction tests passants
- **Structured output** : valider que la sortie matche un schéma JSON / regex
- **Multi-step reasoning** : reward intermédiaire à chaque étape correcte

Pas besoin de reward model neural → **pas de reward hacking sur le RM**, juste un vérificateur déterministe.

### R1 et R1-Zero

DeepSeek-R1-Zero (2025) : **GRPO pur sur math/code sans SFT préalable**. Surprise : le modèle apprend **émergement** à raisonner (chain-of-thought, self-correction, backtracking) juste depuis un signal verifiable binaire. *"Aha moments"* visibles dans les traces.

R1 (la version finale) : pipeline plus complet — SFT léger sur quelques exemples CoT, puis GRPO massif, puis distillation vers des modèles plus petits.

C'est devenu le **template pour l'entraînement de reasoning models open source** (Qwen-QwQ, Kimi-K1.5, etc.).

### Reward shaping pour GRPO

Pour stabiliser et accélérer :
1. **Format reward** : reward bonus si la réponse suit le format (e.g. `<think>...</think><answer>...</answer>`)
2. **Length penalty** : décourager les réponses trop longues
3. **Correctness reward** : le signal principal (math/code)
4. **Process reward** (optional) : reward intermédiaire sur chaque étape de raisonnement

DeepSeek-R1 combine format + correctness rewards. Process rewards plus complexes (PRM) ont été abandonnés pour R1 (trop coûteux).

### KL penalty

Comme PPO RLHF, on ajoute $-\beta \cdot \text{KL}(\pi_\theta \| \pi_{\text{ref}})$ pour ne pas trop diverger du SFT. Mais $\beta$ est typiquement plus bas en GRPO (0.01-0.04 vs 0.05-0.2 PPO RLHF) — l'objectif vérifiable est moins susceptible de hacking.

### Choix de $G$ (taille de groupe)

- $G$ trop petit (2-4) : avantage z-score instable, peu de signal
- $G$ très grand (64+) : coût compute énorme
- Sweet spot : **$G = 8..16$**

Plus $G$ grand, plus la baseline est précise → meilleur gradient (à coût compute supérieur).

## Quand c'est utile

- **Reasoning fine-tuning** : math, code, science, multi-step
- **Récompenses verifiables** disponibles : pas besoin de RM neural
- **Économie compute** : un modèle de moins que PPO
- **Open-source LLM training** : recette battle-tested R1
- **Pas envie de coder un critic** : le critic value head de PPO est un casse-tête sur LLMs
- **Multiple candidates par prompt** déjà dans le pipeline : GRPO réutilise cette structure

## Quand ça ne marche pas / pièges

- **Reward signal trop sparse** : si $G$ réponses sont toutes "fausses" (reward = 0), l'avantage est dégénéré → augmenter $G$, ajuster difficulty, ajouter format rewards
- **Toutes réponses identiques** : si la politique est trop déterministe (température basse), pas de diversité → reward variance = 0, signal mort. Sample à T ≥ 0.7
- **Pas de credit assignment par token** : l'avantage constant ignore qu'un token spécifique a fait la différence → moins fin que PPO + GAE
- **Hyperparams encore en exploration** : G, β, ε, KL coef pas standardisés comme PPO
- **Reward hacking subtil sur verifiable** : modèle apprend à formater le bon answer sans vrai reasoning (e.g. dump tous les nombres possibles dans `<answer>` tags). Mitigation : format rewards stricts, eval out-of-distribution
- **Compute coût élevé pour G grand** : 8-16x plus de sampling vs SFT
- **Sample inefficient** : on-policy strict, on jette les samples après l'update (pas de replay)
- **KL estimation imprécise** : sur LLMs, KL exacte coûte cher → approximations (Schulman approx) parfois biaisées
- **Process rewards casse-tête** : si tu veux récompenser des étapes intermédiaires, PRM (Process Reward Model) compliqué et fragile

## Code minimal

```python
# Squelette GRPO (pseudo-code)
import torch
import torch.nn.functional as F

def grpo_step(policy, ref_policy, tokenizer, prompts, reward_fn,
              G=8, kl_coef=0.04, clip_eps=0.2, lr=1e-6):
    opt = torch.optim.Adam(policy.parameters(), lr=lr)

    for prompt in prompts:
        # 1. Sample G réponses pour ce prompt
        responses = []
        old_log_probs_list = []
        for _ in range(G):
            with torch.no_grad():
                resp, lp = sample_response(policy, prompt, temperature=0.9)
            responses.append(resp)
            old_log_probs_list.append(lp)

        # 2. Calculer rewards (verifiable)
        rewards = torch.tensor([reward_fn(prompt, r) for r in responses])

        # 3. Avantages groupes (z-score)
        advantages = (rewards - rewards.mean()) / (rewards.std() + 1e-8)

        # 4. Update PPO-style clippé
        for resp, lp_old, adv in zip(responses, old_log_probs_list, advantages):
            lp_new = compute_log_probs(policy, prompt, resp)
            lp_ref = compute_log_probs(ref_policy, prompt, resp)

            ratio = (lp_new - lp_old).exp()
            surr1 = ratio * adv
            surr2 = ratio.clamp(1 - clip_eps, 1 + clip_eps) * adv
            policy_loss = -torch.min(surr1, surr2).mean()

            # KL approx (Schulman approximator k3)
            kl = (lp_ref - lp_new).exp() - (lp_ref - lp_new) - 1
            kl_loss = kl.mean()

            loss = policy_loss + kl_coef * kl_loss
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(policy.parameters(), 0.5)
            opt.step()
```

```python
# Reward function verifiable pour maths
import re

def math_reward(prompt, response, ground_truth):
    """Renvoie 1.0 si réponse correcte, 0.0 sinon. Bonus format."""
    # Check format <think>...</think><answer>...</answer>
    format_ok = bool(re.search(
        r"<think>.*?</think>\s*<answer>.*?</answer>",
        response, re.DOTALL,
    ))
    fmt_reward = 0.1 if format_ok else 0.0

    # Extraire la réponse finale
    m = re.search(r"<answer>(.*?)</answer>", response, re.DOTALL)
    if not m:
        return fmt_reward
    answer = m.group(1).strip()

    # Comparer (numériquement si possible)
    try:
        correct = abs(float(answer) - float(ground_truth)) < 1e-6
    except ValueError:
        correct = answer == ground_truth

    return 1.0 + fmt_reward if correct else fmt_reward
```

```python
# Reward function verifiable pour code (exécution sandbox)
import subprocess

def code_reward(prompt, response, test_cases, timeout=5):
    """response = code Python, test_cases = liste de (input, expected_output)"""
    # Extract code depuis <code> ... </code>
    m = re.search(r"```python\n(.*?)```", response, re.DOTALL)
    if not m:
        return 0.0
    code = m.group(1)

    passing = 0
    for inp, expected in test_cases:
        try:
            full = code + f"\nresult = solve({inp})\nprint(result)"
            out = subprocess.run(
                ["python", "-c", full],
                capture_output=True, timeout=timeout, text=True,
            )
            if out.stdout.strip() == str(expected):
                passing += 1
        except Exception:
            pass
    return passing / len(test_cases)
```

```python
# En pratique : TRL GRPOTrainer (HuggingFace, 2024+)
from trl import GRPOTrainer, GRPOConfig
from transformers import AutoModelForCausalLM, AutoTokenizer

model_id = "Qwen/Qwen2.5-7B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype="bf16")

config = GRPOConfig(
    output_dir="./grpo-qwen",
    per_device_train_batch_size=4,
    num_generations=8,                  # G
    max_completion_length=2048,
    learning_rate=1e-6,
    beta=0.04,                           # KL coef
    epsilon=0.2,                         # clip
    bf16=True, num_train_epochs=1,
)

def reward_fn(completions, prompts, **kwargs):
    return [math_reward(p, c, gt) for p, c, gt in zip(prompts, completions, kwargs["ground_truths"])]

trainer = GRPOTrainer(
    model=model, args=config,
    tokenizer=tokenizer,
    train_dataset=math_dataset,
    reward_funcs=[reward_fn],
)
trainer.train()
```

## Pour aller plus loin

- Shao et al., *DeepSeekMath: Pushing the Limits of Mathematical Reasoning in Open Language Models* (2024) — GRPO introduit : https://arxiv.org/abs/2402.03300
- DeepSeek-AI, *DeepSeek-R1: Incentivizing Reasoning Capability in LLMs via Reinforcement Learning* (2025) — https://arxiv.org/abs/2501.12948
- Kimi-K1.5, Tulu 3, OpenReasoner-Zero — papers contemporains R1
- TRL GRPO docs : https://huggingface.co/docs/trl/grpo_trainer
- *Reasoning models* (Concepts/Reasoning models.md dans ce wiki)
- **Liens internes** : [[PPO]], [[Policy gradient]], [[RLHF and DPO]], [[Reward modeling]], [[Reasoning models]], [[Reinforcement learning]]
