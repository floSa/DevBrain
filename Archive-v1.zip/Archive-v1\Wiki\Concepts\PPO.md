---
galaxie: wiki
nom: PPO
alias: [PPO, Proximal Policy Optimization, clipped PPO, PPO-Clip]
type: concept
categorie: concept/ml
sous_categories: [rl, ppo, policy-gradient, on-policy, trust-region, rlhf]
domaines: [ml-eng, ai-eng]
maturite: established
auteurs_cles: [Schulman 2017 (PPO), Schulman 2015 (TRPO), Engstrom 2020 (implementation matters)]
lecture_min: 9
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, rl, ppo, rlhf]
---

# PPO — Proximal Policy Optimization

## TL;DR

**L'algo deep RL le plus utilisé** depuis 2017. On-policy actor-critic avec un objectif **clippé** sur le ratio $\pi_\theta / \pi_{\theta_{\text{old}}}$ : si une mise à jour pousse la politique trop loin de l'ancienne, le gradient s'annule. Simple à implémenter, robuste, scaling propre. C'est l'algo derrière **RLHF** dans InstructGPT / ChatGPT, **OpenAI Five (Dota 2)**, et la majorité des papers deep RL appliqué. Standard de fait avec SAC pour continu.

## Le problème

Vanilla policy gradient (REINFORCE) a une variance énorme. A2C ajoute un critic. Mais sur des updates trop grands, la politique peut s'effondrer (catastrophic step). **TRPO** (Trust Region Policy Optimization, Schulman 2015) résout ça avec une contrainte KL, mais c'est lourd à implémenter (conjugate gradient, line search). **PPO** : la même idée, **en remplaçant la contrainte KL par un clip** sur le ratio de probabilités. Triviale à coder, presque aussi performante.

## L'idée

### Le ratio de probabilités

À chaque update, on définit :

$$ r_t(\theta) = \frac{\pi_\theta(a_t | s_t)}{\pi_{\theta_{\text{old}}}(a_t | s_t)} $$

C'est le ratio entre nouvelle et ancienne politique sur la transition $t$. Au début d'une update (épochs PPO), $r_t = 1$ ; au fur et à mesure, $r_t$ s'éloigne de 1.

### L'objectif clippé

$$ \mathcal{L}^{\text{CLIP}}(\theta) = \mathbb{E}_t \left[ \min\Big( r_t(\theta) \hat A_t, \; \text{clip}(r_t(\theta), 1 - \epsilon, 1 + \epsilon) \hat A_t \Big) \right] $$

avec $\epsilon = 0.2$ typique. Le **min** prend le pessimiste des deux versions.

**Comportement** :
- Si $\hat A_t > 0$ et $r_t > 1 + \epsilon$ : on a déjà beaucoup poussé dans la bonne direction, on **arrête** (gradient nul)
- Si $\hat A_t < 0$ et $r_t < 1 - \epsilon$ : on a déjà beaucoup réduit cette action, on arrête
- Sinon : gradient policy gradient classique

Visuellement :

```
L^CLIP                  L^CLIP
   │                       │
A>0│       ___             │            
   │      /                │            ___
   │     /                 │           /
   │____/                  │__________/
   └─────────────────► r   └─────────────────► r
     1-ε  1  1+ε            1-ε  1  1+ε
                                      A<0
```

C'est ce qu'on appelle un **pessimistic / lower bound** sur l'objectif TRPO : on est sûr de ne pas trop dévier.

### L'algo complet PPO

```
pour itération = 1..N :
    # 1. Collecter
    pour T pas avec π_θ_old :
        observer s, jouer a, recevoir r, s'
        stocker (s, a, r, s', log π_θ_old(a|s))
    # 2. Calculer GAE et returns
    avantages = compute_gae(rewards, values, dones, γ, λ)
    returns = avantages + values
    avantages = (avantages - mean) / (std + 1e-8)   # normalisation
    # 3. K époques d'optimisation sur le batch
    pour k = 1..K époques :
        pour mini-batch dans batch :
            r_t = exp(log π_θ - log π_θ_old)
            L_CLIP = min(r_t * Â, clip(r_t, 1-ε, 1+ε) * Â).mean()
            L_V = MSE(V_φ, returns)
            L_H = entropie(π).mean()
            loss = -L_CLIP + c_v * L_V - c_e * L_H
            opt.step()
    θ_old ← θ
```

**Hyperparams typiques (continuous, Atari)** :
- $\gamma = 0.99$, $\lambda = 0.95$
- $\epsilon = 0.2$
- $K = 4..10$ époques
- batch size = 2048..4096 transitions
- mini-batch 64..256
- learning rate $3 \times 10^{-4}$ avec decay linéaire
- $c_v = 0.5$, $c_e = 0.0..0.01$
- gradient clipping global norm = 0.5

### PPO et GAE

PPO utilise quasi-systématiquement **GAE (λ = 0.95)** pour l'estimation de l'avantage — voir [[Value functions]]. C'est ce qui rend PPO sample-efficient malgré le caractère on-policy.

### PPO en RLHF

Pour l'alignement des LLMs (InstructGPT, ChatGPT, Claude original) :
- **Politique** π_θ : le LLM en cours de tuning
- **Reference** π_ref : le SFT model, frozen
- **Reward model** r_φ : entraîné séparément sur préférences humaines
- **Critic / value head** : ajoutée au LLM pour estimer V

Modification de l'objectif : on ajoute une **pénalité KL** vers π_ref :

$$ \mathcal{L}^{\text{RLHF}}_t = \mathcal{L}^{\text{CLIP}}_t - \beta \cdot \text{KL}(\pi_\theta(\cdot | s) \| \pi_{\text{ref}}(\cdot | s)) $$

Pour éviter le **reward hacking** : la politique s'éloigne du modèle SFT seulement si le reward le justifie.

Voir [[RLHF and DPO]] pour le contexte complet.

### Variantes / extensions

- **PPO-Penalty** : version originale avec pénalité KL adaptative (rarement utilisée)
- **PPO-Clip** : la version standard, c'est elle qu'on appelle "PPO" en pratique
- **Recurrent PPO** : politique RNN pour POMDP / partial observability
- **Multi-discrete actions** : action factorisée sur dimensions indépendantes
- **PPO + auxiliary tasks** : prédire l'inverse dynamics, RND, etc. en heads supplémentaires
- **DD-PPO** (decentralized distributed) : passage à 64+ GPUs pour Habitat / robotique

### Implementation matters

Engstrom et al. (2020) ont montré que **les détails d'implémentation** comptent plus que l'algorithme abstrait. Liste des "code-level optimizations" :

1. **Value function clipping** (parfois utile, parfois non)
2. **Reward scaling / normalization** (running mean+std)
3. **Observation normalization**
4. **Gradient global clipping** (norm 0.5)
5. **Orthogonal weight initialization** + biases = 0
6. **Adam epsilon** = 1e-5 (default 1e-8 cause des soucis)
7. **Tanh squashing** pour bounded actions
8. **Learning rate annealing** linéaire
9. **GAE λ** = 0.95
10. **Mini-batch advantage normalization** (pas global)

Sans ces détails, PPO marche mal. Avec, il marche partout. C'est pour ça qu'utiliser **Stable-Baselines3** ou **CleanRL** plutôt que coder from scratch est presque toujours la bonne idée.

## Quand c'est utile

- **Algo généraliste** : si tu ne sais pas quoi prendre, PPO d'abord
- **Continuous control** : robotique, MuJoCo, Isaac Gym
- **Discret moyen** : Atari, jeux 2D
- **RLHF / alignment** : le PPO d'InstructGPT/ChatGPT
- **Multi-agent (auto-play)** : OpenAI Five (Dota 2), AlphaStar dérivés
- **Curriculum learning** : on-policy s'adapte vite à un env qui change
- **Hyperparams transférables** : ce qui marche sur CartPole tend à marcher ailleurs (vs SAC plus sensible)

## Quand ça ne marche pas / pièges

- **Sample inefficient** : on-policy → chaque sample utilisé K époques mais jeté ensuite. Pour problèmes coûteux à sampler, préférer SAC (off-policy)
- **K époques trop élevées** : le ratio $r_t$ devient extrême, le clip ne suffit plus → instabilité (typique K=10 OK, K=80 catastrophe)
- **Batch trop petit** : variance trop haute, signal noyé
- **Avantage non normalisé** : magnitudes explosent → KL diverge
- **KL réelle non monitorée** : le clip n'impose pas une KL bornée, juste une bornée par transition. Mesurer KL réelle, alerter si > 0.02
- **Reward magnitudes incohérents** : si reward varie sur 5 ordres de grandeur, normaliser
- **Exploration nulle** : sans bonus d'entropie, la politique peut converger vers une action déterministe trop tôt
- **Value function clipping mal utilisé** : la litt est mixed, parfois ça aide, parfois non. Toggle et mesurer
- **PPO sur RLHF** : reward hacking si KL penalty trop bas, modèle stuck si trop haut → β à 0.05-0.2 typique
- **Multi-GPU non-trivial** : vrai distributed PPO demande IS correction subtile

## Code minimal

```python
# Cœur de PPO : l'objectif clippé (PyTorch)
import torch

def ppo_loss(logits_new, logits_old, actions, advantages, old_log_probs, eps=0.2):
    """
    logits_new : sortie du policy net courant
    logits_old : pre-computed lors de la collecte
    """
    from torch.distributions import Categorical
    dist = Categorical(logits=logits_new)
    log_probs = dist.log_prob(actions)
    entropy = dist.entropy().mean()

    ratio = (log_probs - old_log_probs).exp()
    surr1 = ratio * advantages
    surr2 = ratio.clamp(1 - eps, 1 + eps) * advantages
    actor_loss = -torch.min(surr1, surr2).mean()

    # KL approximation (pour monitoring)
    with torch.no_grad():
        approx_kl = (old_log_probs - log_probs).mean()
    return actor_loss, entropy, approx_kl
```

```python
# Boucle PPO complète (squelette)
import torch
import torch.nn.functional as F
from torch.distributions import Categorical

def ppo_update(model, opt, batch, eps=0.2, K_epochs=4, c_v=0.5, c_e=0.01):
    states, actions, old_log_probs, advantages, returns = batch
    advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

    for _ in range(K_epochs):
        for mb in minibatches(states, actions, old_log_probs, advantages, returns):
            s, a, lp_old, adv, ret = mb
            logits, V = model(s)
            dist = Categorical(logits=logits)
            lp = dist.log_prob(a)
            ratio = (lp - lp_old).exp()

            surr1 = ratio * adv
            surr2 = ratio.clamp(1 - eps, 1 + eps) * adv
            actor_loss = -torch.min(surr1, surr2).mean()
            critic_loss = F.mse_loss(V, ret)
            entropy = dist.entropy().mean()

            loss = actor_loss + c_v * critic_loss - c_e * entropy
            opt.zero_grad(); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)
            opt.step()
```

```python
# En pratique : Stable-Baselines3
from stable_baselines3 import PPO
import gymnasium as gym

env = gym.make("BipedalWalker-v3")
model = PPO(
    "MlpPolicy", env,
    learning_rate=3e-4, n_steps=2048, batch_size=64,
    n_epochs=10, gamma=0.99, gae_lambda=0.95, clip_range=0.2,
    ent_coef=0.0, vf_coef=0.5, max_grad_norm=0.5,
    verbose=1,
)
model.learn(total_timesteps=1_000_000)
model.save("ppo_bipedal")
```

```python
# RLHF PPO via TRL (Hugging Face)
from trl import PPOTrainer, PPOConfig, AutoModelForCausalLMWithValueHead
from transformers import AutoTokenizer

config = PPOConfig(
    learning_rate=1.4e-5, batch_size=128, mini_batch_size=16,
    ppo_epochs=4, init_kl_coef=0.05, target_kl=0.1, gamma=1.0,
)
tokenizer = AutoTokenizer.from_pretrained("meta-llama/Meta-Llama-3-8B-Instruct")
model = AutoModelForCausalLMWithValueHead.from_pretrained("meta-llama/Meta-Llama-3-8B-Instruct")
# ref_model est créé automatiquement par PPOTrainer
# reward_model : à entraîner séparément, voir [[Reward modeling]]
trainer = PPOTrainer(config, model, tokenizer=tokenizer)
# trainer.step(queries, responses, rewards)  -> dans une boucle
```

## Pour aller plus loin

- Schulman et al., *Proximal Policy Optimization Algorithms* (2017) — https://arxiv.org/abs/1707.06347
- Schulman et al., *Trust Region Policy Optimization* (ICML 2015)
- Engstrom et al., *Implementation Matters in Deep Policy Gradients* (ICLR 2020) — https://arxiv.org/abs/2005.12729
- Andrychowicz et al., *What Matters In On-Policy RL?* (ICLR 2021)
- *The 37 Implementation Details of PPO* (Huang 2022) — https://iclr-blog-track.github.io/2022/03/25/ppo-implementation-details/
- CleanRL PPO single-file : https://github.com/vwxyzjn/cleanrl/blob/master/cleanrl/ppo.py
- TRL PPO (HuggingFace) : https://huggingface.co/docs/trl/ppo_trainer
- Ouyang et al., *Training language models to follow instructions with human feedback* (InstructGPT, 2022) — PPO appliqué aux LLMs
- **Liens internes** : [[Policy gradient]], [[Actor-Critic methods]], [[Value functions]], [[RLHF and DPO]], [[Reward modeling]], [[GRPO]]
