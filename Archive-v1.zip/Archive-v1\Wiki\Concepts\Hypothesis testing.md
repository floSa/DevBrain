---
galaxie: wiki
nom: Hypothesis testing
alias: [tests d'hypothèse, test statistique, p-value, type I error, type II error]
type: concept
categorie: concept/stats
sous_categories: [hypothesis-testing, p-value, type-i-error, power, statistical-inference]
domaines: [data-science]
maturite: established
auteurs_cles: [Fisher, Neyman-Pearson]
lecture_min: 10
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, hypothesis-testing, p-value]
---

# Hypothesis testing

## TL;DR

Cadre formel pour décider si un effet observé sur des données est **réel ou dû au hasard**. On pose une hypothèse nulle $H_0$ ("aucun effet"), on calcule la probabilité d'observer des données aussi extrêmes que les nôtres **si $H_0$ était vraie** = la **p-value**. Si elle est sous un seuil $\alpha$ (typique 0.05), on **rejette $H_0$**. Attention : la p-value n'est PAS la probabilité que $H_0$ soit vraie.

## Le problème

Tu observes une différence entre deux groupes (ex. nouvelle landing page convertit 12% vs ancienne 10%). Cette différence est-elle **réelle** ou simplement le bruit du tirage ? Faut-il déployer la nouvelle version ?

Sans cadre formel, on ne sait pas si 2 points d'écart est significatif sur 100 utilisateurs (probablement pas) ou sur 100 000 (probablement oui).

## L'idée

### Vocabulaire

- **$H_0$ — hypothèse nulle** : "il n'y a pas d'effet" / "les groupes sont identiques". Par défaut.
- **$H_1$ — hypothèse alternative** : "il y a un effet". Ce que tu cherches à montrer.
- **Statistique de test** : un nombre calculé sur les données, dont la distribution sous $H_0$ est connue (ex. $t$, $\chi^2$, $F$, $Z$).
- **p-value** : $P(\text{stat} \geq \text{observed} \mid H_0)$ — proba d'observer des données aussi extrêmes, **sous l'hypothèse nulle**.
- **Seuil $\alpha$** : risque de **type I** qu'on accepte. Typique : 0.05. Décidé **avant** de regarder les données.
- **Puissance $1 - \beta$** : probabilité de détecter un vrai effet quand il existe. Typique cible : 0.80.

### Décision

- Si p-value $< \alpha$ → **on rejette $H_0$** (effet significatif)
- Si p-value $\geq \alpha$ → **on ne peut pas rejeter $H_0$** (pas d'évidence d'effet, mais pas "absence d'effet" prouvée)

### Types d'erreurs

|  | $H_0$ vraie | $H_0$ fausse |
|---|---|---|
| On rejette $H_0$ | **Erreur type I** (faux positif) | OK ✅ |
| On ne rejette pas | OK ✅ | **Erreur type II** (faux négatif) |

- **Type I** : controlé par $\alpha$ (0.05 = 5% de chance de crier au loup à tort)
- **Type II** : contrôlé par la **puissance** = $1 - \beta$, dépend de la taille d'échantillon, de l'effet réel, et de $\alpha$

### Calcul de puissance et taille d'échantillon

Avant l'expérience : décider la taille d'échantillon $n$ pour détecter un effet **d'une certaine ampleur** avec puissance souhaitée.

$$ n = f(\text{effect size}, \alpha, \text{power}) $$

Outils : `statsmodels.stats.power`, `pingouin.power_*`, calculs analytiques pour certains tests.

### Tests paramétriques vs non-paramétriques

**Paramétriques** : hypothèses sur la distribution (normalité souvent)
- [[t-test and ANOVA|t-test, ANOVA]], régression linéaire, F-test

**Non-paramétriques** : aucune hypothèse de loi
- Wilcoxon (= Mann-Whitney pour 2 groupes indépendants)
- Kruskal-Wallis (= ANOVA non-paramétrique)
- [[Bootstrap]] (universel)

Quand utiliser non-paramétrique : petites tailles, distributions clairement non-normales, données ordinales.

### Tests à une queue vs deux queues

- **Deux queues** : $H_1 : \mu \neq \mu_0$. Par défaut, prudent.
- **Une queue** : $H_1 : \mu > \mu_0$ (ou $<$). Plus puissant mais à justifier **avant** l'expérience (pas après avoir vu les données).

### Confusions fréquentes — mésusages de la p-value

❌ "p = 0.04 → 96% de chance que $H_1$ soit vraie" — **FAUX**. La p-value est conditionnelle à $H_0$, pas une proba sur $H_1$.

❌ "p = 0.06 → pas d'effet" — **FAUX**. p-value > $\alpha$ = absence d'évidence, pas évidence d'absence.

❌ "**p-hacking** : essayer 20 tests, garder celui avec p < 0.05" — **FAUX**, viole la logique fréquentiste (cf. [[Multiple testing correction]]).

❌ "**HARKing** (Hypothesizing After the Results are Known)" : formuler $H_1$ après avoir vu les données. Inflation massive du type I.

❌ Confusion **significativité statistique** vs **importance pratique** : avec $n$ énorme, une différence triviale (0.1%) peut être "significative". Toujours rapporter aussi la **taille d'effet** (Cohen's d, OR, etc.) et un [[Confidence intervals|intervalle de confiance]].

## Quand c'est utile

- A/B testing
- Comparaison de moyennes (effets d'un traitement, performance de modèles)
- Tests d'indépendance ([[Chi-squared tests]])
- Validation d'hypothèses scientifiques
- Sciences biomédicales, sciences sociales, marketing analytique

## Quand ça ne marche pas / pièges

- **Tests multiples** sans correction → faux positifs (cf. [[Multiple testing correction]])
- **Hypothèses sur la loi violées** (normalité avec données très skewed) → résultat faux. Utiliser non-paramétrique ou [[Bootstrap]].
- **Échantillon trop petit** → puissance faible, ne pas conclure "pas d'effet"
- **Échantillon trop grand** → tout devient significatif. Privilégier taille d'effet et [[Confidence intervals]].
- **Cas tests "fishing" ou exploratoires** → préférer modélisation bayésienne ou validation croisée.
- **Outliers et données non independants** : la plupart des tests supposent l'indépendance. Données pairées → test pairé (paired t-test, Wilcoxon signé).

## Code minimal

```python
from scipy import stats

# t-test pour 2 groupes indépendants
result = stats.ttest_ind(group_a, group_b)
print(f"t={result.statistic:.3f}, p={result.pvalue:.4f}")

# Calcul de puissance
from statsmodels.stats.power import TTestIndPower
analysis = TTestIndPower()
n_required = analysis.solve_power(effect_size=0.5, alpha=0.05, power=0.80)
print(f"n required per group: {n_required:.0f}")
```

## Implémentations concrètes

- `scipy.stats` — tests classiques (ttest, chi2, f, ks, wilcoxon, mannwhitneyu, kruskal…)
- `statsmodels.stats` — puissance, taille d'échantillon, intervalles de confiance robustes
- `pingouin` — interface plus pédagogique, effect sizes inclus
- R : `t.test`, `chisq.test`, `wilcox.test`, package `pwr` (puissance)

## Pour aller plus loin

- *Statistical Inference* (Casella & Berger) — référence académique
- Greenland et al., *Statistical tests, P values, confidence intervals, and power: a guide to misinterpretations* (2016)
- Wasserstein et al., *The ASA Statement on p-Values: Context, Process, and Purpose* (American Statistician 2016)
- **Liens internes** : [[t-test and ANOVA]], [[Chi-squared tests]], [[Bootstrap]], [[Confidence intervals]], [[Multiple testing correction]]
