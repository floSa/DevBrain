---
galaxie: dev
type: rule
domaine: library
applicable: type-library
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, library, package]
---

# Règles — Type de projet : Library

## Principe
Lib = code que **d'autres** utilisent. Stabilité, versionnement strict, doc complète, tests sur les versions de runtime supportées.

## MUST

- **Versionnement sémantique strict** (SemVer). `MAJOR.MINOR.PATCH`.
- **CHANGELOG.md** tenu à jour à chaque release. Format Keep a Changelog.
- **API publique 100% documentée** (docstrings, TSDoc).
- **Pas de side-effects à l'import**. Importer la lib ne doit rien démarrer/écrire/connecter.
- **Tests sur toutes les versions de runtime supportées** (matrix CI).
- **Licence claire** dans le repo (LICENSE file).
- **Pas de dépendance lourde imposée** : si possible, deps optionnelles via extras (`pip install monpkg[extra]`).

## SHOULD

- **Coverage > 90%** sur la lib (hors examples).
- **Tests d'intégration** dans les versions amont (pytest plugin pour PG, etc.).
- **Type hints / TSDoc complets**, vérifiés par `mypy --strict` ou `pyright strict`.
- **Examples** dans un dossier `examples/`.
- **CI publish automatique** sur tag (PyPI, npm, crates.io).
- **Changelog généré** ou maintenu via outil (towncrier, changesets).

## NICE-TO-HAVE

- Site doc dédié (mkdocs, docusaurus, typedoc-published).
- Benchmarks publiés et reproductibles.
- API stability badge (alpha / beta / stable) en haut du README.

## Versionnement (SemVer)

- **PATCH** : bugfix, pas de breaking change ni nouvelle feature publique
- **MINOR** : nouvelle feature, rétrocompatible
- **MAJOR** : breaking change

Pré-1.0 : breaking changes sur **MINOR** acceptables (mais documentés). Au-delà de 1.0, **MAJOR** strict pour breaking.

## Anti-patterns

- Pousser une 1.0.0 sans engagement de stabilité.
- Casser l'API en PATCH.
- "Pas le temps de faire le CHANGELOG" — c'est exactement ça la lib.
- Side-effect au import : `import monpkg` qui démarre un thread, ouvre une socket, écrit un fichier.
- Lib qui impose ses choix : logging configuré globalement, locale changée, etc.

## Voir aussi

- [[Rules/Global/README]] — README spécifique lib
- [[Rules/Global/Tests]] — coverage cible plus exigeante
- [[Rules/Global/Documentation]] — API docs
