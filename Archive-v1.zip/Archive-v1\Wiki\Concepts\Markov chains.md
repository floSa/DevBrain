---
galaxie: wiki
nom: Markov chains
alias: [chaînes de Markov, processus markovien, transition matrix, stationary distribution]
type: concept
categorie: concept/probability
sous_categories: [markov-chains, stochastic-process, transition, stationary, ergodic]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Markov 1906]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, probability, markov, stochastic-process]
---

# Markov chains — chaînes de Markov

## TL;DR

Processus stochastique où **le futur ne dépend que du présent**, pas du passé : $P(X_{t+1} | X_t, X_{t-1}, \dots) = P(X_{t+1} | X_t)$. Caractérisée par une **matrice de transition**. Fondation de plein de choses : PageRank, MCMC, HMMs, RL (MDP), modèles de langue n-gram. Comprendre la **distribution stationnaire** et l'**ergodicité** est central.

## Le problème

Beaucoup de systèmes évoluent dans le temps : météo (jour à jour), pages web visitées, mots dans une phrase, états d'un agent RL. On veut un modèle **simple** mais **puissant** pour ces dynamiques. La propriété de Markov capture beaucoup de cas réalistes avec un minimum d'hypothèses.

## L'idée

### Définition

Une chaîne de Markov à temps discret sur un espace d'états $\mathcal{S}$ satisfait :

$$ P(X_{t+1} = j \mid X_t = i, X_{t-1} = i_{t-1}, \dots) = P(X_{t+1} = j \mid X_t = i) = P_{ij} $$

La distribution future ne dépend que de l'**état actuel**. C'est la **propriété de Markov** (memoryless).

### Matrice de transition

Pour $|\mathcal{S}| = n$ états :

$$ P \in \mathbb{R}^{n \times n}, \quad P_{ij} \geq 0, \quad \sum_j P_{ij} = 1 \, \forall i $$

$P$ est **stochastique** (lignes somment à 1).

### Évolution de la distribution

Si $\pi_t \in \mathbb{R}^n$ est la distribution au temps $t$ :

$$ \pi_{t+1} = \pi_t P $$

En $k$ étapes : $\pi_{t+k} = \pi_t P^k$.

### Distribution stationnaire

$\pi^*$ est **stationnaire** si :

$$ \pi^* P = \pi^* $$

$\pi^*$ est un **vecteur propre à gauche** de $P$ associé à la valeur propre 1.

**Théorème fondamental** (chaîne irréductible apériodique) : $\pi^*$ existe, est unique, et $\pi_t \to \pi^*$ quel que soit l'état initial.

### Propriétés clés

- **Irréductible** : on peut aller de tout état à tout autre (graphe connexe)
- **Apériodique** : pas de cycle obligatoire (pgcd des longueurs de boucles = 1)
- **Récurrente positive** : on revient toujours à chaque état en temps fini moyen
- **Ergodique** : irréductible + apériodique + récurrente positive → théorèmes limites

### Theorème ergodique

Pour une chaîne ergodique :

$$ \frac{1}{T} \sum_{t=1}^T f(X_t) \xrightarrow{T \to \infty} \mathbb{E}_{\pi^*}[f(X)] $$

= **moyennes temporelles convergent vers moyennes spatiales selon $\pi^*$**. Justification théorique de [[MCMC]].

### Calcul de $\pi^*$

3 méthodes :
1. **Résoudre $\pi P = \pi, \sum \pi_i = 1$** : système linéaire
2. **Eigendecomposition** de $P^\top$ : $\pi^*$ = vecteur propre associé à $\lambda = 1$
3. **Itération de puissance** : appliquer $P$ jusqu'à convergence

### Reversibilité (detailed balance)

Une chaîne est **réversible** si $\pi^*_i P_{ij} = \pi^*_j P_{ji}$ (detailed balance). Condition suffisante (pas nécessaire) pour que $\pi^*$ soit stationnaire. C'est ce qu'exploitent les algos MCMC.

### Chaînes en temps continu

Variante avec sauts à des instants $T_1 < T_2 < \dots$ tirés selon un [[Poisson process]]. Caractérisée par une **matrice génératrice** $Q$ avec $Q_{ij}$ taux de transition $i \to j$.

### Hidden Markov Models (HMM)

Variante où l'état $X_t$ est **caché** ; on observe $Y_t \sim p(y | X_t)$. Algorithmes classiques :
- **Forward-Backward** : marginal de $X_t$ sachant tout $Y$
- **Viterbi** : MAP de la séquence d'états
- **Baum-Welch** : EM pour apprendre les paramètres

Utilisés en speech recognition (avant DL), parts-of-speech tagging, bioinformatique.

## Quand c'est utile

- **PageRank** : Google original = vecteur propre à gauche de la matrice de transition du graphe web
- **MCMC** : construire une chaîne de Markov dont la distribution stationnaire est la cible (cf. [[MCMC]])
- **Reinforcement Learning** : MDP est un Markov chain avec actions et rewards
- **Modèles de langue n-gram** : $P(w_t | w_{t-1})$ (bi-gram) ou $P(w_t | w_{t-1}, w_{t-2})$ (tri-gram)
- **Génération de texte simple** (avant les LLMs)
- **Simulations de file d'attente, biologie, finance**
- **Analyse de comportement utilisateur** sur un site (transitions entre pages)

## Quand ça ne marche pas / pièges

- **Propriété de Markov fausse** : si le futur dépend vraiment du passé lointain (long-range dependencies), les LSTMs/Transformers font mieux
- **Espace d'états énorme** : $n^2$ entrées dans $P$ — irréaliste pour $n > 10^4$. Approximations ou structures sparse.
- **Non-stationnaire dans le temps** : la matrice $P$ varie → chaîne **non-homogène**, plus difficile à analyser
- **Convergence lente** vers $\pi^*$ : si la **vitesse de mixing** est faible (deuxième valeur propre proche de 1)
- **Apériodicité supposée à tort** : chaîne périodique (ex. damier 2-coloriable) n'a pas $\pi$ unique au sens limite
- **MCMC sur chaîne mal conçue** : converge lentement ou pas du tout vers la cible

## Code minimal

```python
import numpy as np

# Météo simple : 2 états (Pluvieux, Ensoleillé)
P = np.array([
    [0.7, 0.3],  # P(P→P)=0.7, P(P→E)=0.3
    [0.4, 0.6],  # P(E→P)=0.4, P(E→E)=0.6
])

# Itération : distribution au jour t
pi_0 = np.array([1.0, 0.0])  # commencer par pluvieux
for t in range(20):
    pi_t = pi_0 @ np.linalg.matrix_power(P, t)
    # converge vers (4/7, 3/7) ≈ (0.571, 0.429)

# Distribution stationnaire via eigendecomp
eigvals, eigvecs = np.linalg.eig(P.T)  # vecteurs à gauche = eigvec de P^T
stationary_idx = np.argmin(np.abs(eigvals - 1.0))
pi_star = np.real(eigvecs[:, stationary_idx])
pi_star /= pi_star.sum()
print(f"π* = {pi_star}")  # ≈ [0.571, 0.429]

# Vérification : π* P = π*
assert np.allclose(pi_star @ P, pi_star)

# Simulation d'une trajectoire
def simulate_chain(P, n_steps, start=0):
    n_states = len(P)
    states = [start]
    for _ in range(n_steps):
        states.append(np.random.choice(n_states, p=P[states[-1]]))
    return states

traj = simulate_chain(P, 1000)
# Frequence empirique converge vers π* (ergodicité)
from collections import Counter
counts = Counter(traj)
freqs = np.array([counts[i] for i in range(2)]) / len(traj)
print(f"Empirical: {freqs}")  # ≈ π*
```

## Pour aller plus loin

- Norris, *Markov Chains* (1997) — référence pédagogique
- Levin, Peres, Wilmer, *Markov Chains and Mixing Times* (2e éd. 2017) — gratuit
- **Liens internes** : [[MCMC]], [[Poisson process]], [[Eigendecomposition]] (pour distribution stationnaire), [[Brownian motion]]
