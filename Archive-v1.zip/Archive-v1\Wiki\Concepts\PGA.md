---
galaxie: wiki
nom: Principal Geodesic Analysis (PGA)
alias: [PGA, Analyse en Géodésiques Principales]
type: concept
categorie: concept/stats
sous_categories: [factor-analysis, manifold, riemannian, shape, dimensionality-reduction]
domaines: [data-science, ml-eng]
maturite: emerging
auteurs_cles: [Fletcher et al. 2004, Sommer et al.]
lecture_min: 12
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, pga, manifold, riemannian, geometry]
---

# Principal Geodesic Analysis (PGA)

## TL;DR

Extension de [[PCA]] aux données qui vivent sur une **variété riemannienne** (sphère, espace de formes, matrices définies positives, groupes de Lie) plutôt que dans un espace euclidien. L'idée : remplacer les *droites* (PCA) par des **géodésiques** sur la variété. Utilisé en analyse de formes, imagerie médicale (DTI), et plus récemment en analyse d'embeddings.

## Le problème

PCA suppose un espace **euclidien** : on calcule moyenne arithmétique, distance L2, projection sur des droites. Mais beaucoup de données vivent naturellement sur des espaces courbes :

- **Formes anatomiques** (landmarks 3D) : l'espace des formes (après alignement) n'est pas euclidien
- **Tenseurs DTI** (Diffusion Tensor Imaging) : matrices symétriques définies positives, espace courbe
- **Rotations** (SO(3)) : groupe de Lie
- **Distributions de probabilité** : espace de Wasserstein
- **Embeddings normalisés** : sur la sphère unité

Sur ces espaces, faire une PCA "à plat" donne des résultats absurdes (moyennes hors variété, projections qui sortent de la variété).

## L'idée

### Variété et espace tangent

Une **variété riemannienne** $M$ est un espace localement euclidien mais globalement courbe (penser : surface d'une sphère).

En chaque point $p \in M$, on a un **espace tangent** $T_p M$ — un espace vectoriel "approximant" $M$ près de $p$.

Deux opérations clés :
- **Application exponentielle** $\exp_p : T_p M \to M$ — "déplacer le long d'une géodésique" depuis $p$ dans la direction du vecteur tangent
- **Application logarithmique** $\log_p : M \to T_p M$ — l'inverse local

### Moyenne intrinsèque (Karcher mean)

La moyenne arithmétique n'a pas de sens sur $M$. À la place, on définit le **Karcher mean** $\bar p$ comme le minimiseur de la variance géodésique :

$$ \bar p = \arg \min_{q \in M} \sum_i d^2_M(q, x_i) $$

où $d_M$ est la distance géodésique. Solution itérative.

### PGA proprement dit

1. Calculer le Karcher mean $\bar p$ des données $\{x_i\}$
2. Mapper chaque $x_i$ dans l'espace tangent : $v_i = \log_{\bar p}(x_i) \in T_{\bar p} M$
3. Faire une **PCA classique** sur les $v_i$ (l'espace tangent est euclidien !)
4. Les **composantes principales** sont les directions $u_1, \dots, u_k$ dans $T_{\bar p} M$
5. Les **géodésiques principales** sur $M$ sont $\gamma_j(t) = \exp_{\bar p}(t \cdot u_j)$ — courbes sur la variété

### Variante exacte vs linéarisée

- **PGA linéarisée** (Fletcher 2004) : faire la PCA dans l'espace tangent au Karcher mean. Approximation locale, simple.
- **PGA exacte** (Sommer 2010) : minimiser exactement la variance résiduelle sur la variété. Coûteux mais plus juste loin de la moyenne.

### Reconstruction et fraction de variance

- Coordonnées d'un point : $(s_1, \dots, s_k) = (\langle v_i, u_1 \rangle, \dots)$
- Reconstruction : $\hat x_i = \exp_{\bar p}(\sum_j s_j u_j)$
- Variance expliquée : analogue PCA, mais dans l'espace tangent

## Quand c'est utile

- **Morphométrie 3D** : shape spaces (Kendall, Bookstein), atlas anatomique
- **Imagerie médicale** : DTI (Diffusion Tensor Imaging), où chaque voxel est une matrice 3×3 SDP
- **Analyse de réseaux** : matrices d'adjacence comme points sur une variété
- **Embeddings normalisés** : si tous tes vecteurs sont sur la sphère unité ($\|v\| = 1$), PGA sphérique est plus rigoureux que PCA brute
- **Trajectories sur variétés** : analyse de mouvement, robotique

## Quand ça ne marche pas / pièges

- **Variété mal identifiée** : si tes données vivent en fait en euclidien, PGA = PCA. Inutile.
- **Karcher mean coûteux** sur grands datasets ou variétés complexes
- **Linéarisation trop forte** : si les données ont un grand spread géodésique, l'approximation tangente est mauvaise — passer à PGA exacte
- **Outils en Python plus rares** que les méthodes classiques. Souvent en R, Matlab, ou code custom.
- **Interprétation** : plus subtile qu'en PCA. La "première composante" est une géodésique, pas une droite — sa visualisation demande l'effort.

## Code minimal (cas sphérique)

```python
import numpy as np
from scipy.linalg import svd

# Données sur la sphère unité
X = np.random.randn(100, 3)
X /= np.linalg.norm(X, axis=1, keepdims=True)

# 1. Karcher mean (itératif)
mu = X.mean(axis=0); mu /= np.linalg.norm(mu)
for _ in range(50):
    # log map sphérique : log_mu(x) = (x - <x,mu>mu) * angle / sin(angle)
    cos_d = X @ mu
    angle = np.arccos(np.clip(cos_d, -1, 1))
    tangent = (X - cos_d[:, None] * mu)
    tangent_norm = np.linalg.norm(tangent, axis=1, keepdims=True)
    tangent_normalized = np.where(tangent_norm > 1e-9, tangent / tangent_norm, 0)
    log_X = angle[:, None] * tangent_normalized
    grad = log_X.mean(axis=0)
    if np.linalg.norm(grad) < 1e-8: break
    # exp map : exp_mu(v) = cos(|v|) mu + sin(|v|) v/|v|
    g_norm = np.linalg.norm(grad)
    mu = np.cos(g_norm) * mu + np.sin(g_norm) * grad / g_norm

# 2. Mapper en espace tangent
cos_d = X @ mu
angle = np.arccos(np.clip(cos_d, -1, 1))
tangent = X - cos_d[:, None] * mu
log_X = angle[:, None] * (tangent / (np.linalg.norm(tangent, axis=1, keepdims=True) + 1e-9))

# 3. PCA en espace tangent
log_X_centered = log_X - log_X.mean(axis=0)
U, S, Vt = svd(log_X_centered, full_matrices=False)
# Vt : composantes principales géodésiques
```

Pour des variétés sérieuses : packages [`geomstats`](https://geomstats.github.io/), `pyriemann`.

## Implémentations concrètes

- `geomstats` (Python) — bibliothèque la plus complète pour la géométrie riemannienne et le PGA
- `pyriemann` (Python) — focalisé sur les matrices SDP, classification riemannienne
- R : `shapes` package pour la morphométrie

## Pour aller plus loin

- Fletcher et al., *Principal Geodesic Analysis for the Study of Nonlinear Statistics of Shape* (IEEE TMI, 2004) — le paper fondateur
- Pennec, *Statistical Computing on Manifolds: From Riemannian Geometry to Computational Anatomy* (2008)
- Sommer, *Geometric Aspects of Statistical Learning on Manifolds* (PhD)
- **Liens internes** : [[PCA]] (cas euclidien), [[embeddings]] (cas où PGA peut être pertinent si embeddings normalisés), [[GPA]] (alignement pré-traitement souvent utilisé avant PGA en morphométrie)
