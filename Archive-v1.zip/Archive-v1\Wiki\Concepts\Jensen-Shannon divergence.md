---
galaxie: wiki
nom: Jensen-Shannon divergence
alias: [JS divergence, JSD, divergence de Jensen-Shannon]
type: concept
categorie: concept/info-theory
sous_categories: [js-divergence, symmetric, distance, kl-symmetrization]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Jensen, Shannon, Lin 1991]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, info-theory, js, divergence]
---

# Jensen-Shannon divergence

## TL;DR

**Symétrisation** de la [[KL divergence]] : on prend la moyenne $m = (p+q)/2$ et on calcule $\frac{1}{2}[D_{\text{KL}}(p \| m) + D_{\text{KL}}(q \| m)]$. Toujours **finie**, **symétrique**, **bornée par $\log 2$**. Sa racine carrée est même une **vraie métrique**. Utilisée pour comparer des distributions sans les pathologies de la KL pure.

## Le problème

La [[KL divergence]] a 3 défauts pratiques :

1. **Asymétrique** : $D_{\text{KL}}(p \| q) \neq D_{\text{KL}}(q \| p)$ → on doit choisir une direction
2. **Non-bornée** : peut valoir $+\infty$ si les supports sont disjoints
3. **Pas une vraie distance** (inégalité triangulaire violée)

Pour comparer deux distributions de manière "neutre" (sans préférer un ordre), il faut une mesure qui contourne ces 3 problèmes.

## L'idée

### Définition

Soit $m = \frac{p + q}{2}$ la **distribution moyenne**. La JS divergence :

$$ D_{\text{JS}}(p, q) = \frac{1}{2} D_{\text{KL}}(p \| m) + \frac{1}{2} D_{\text{KL}}(q \| m) $$

### Propriétés

- **Symétrique** : $D_{\text{JS}}(p, q) = D_{\text{JS}}(q, p)$
- **Bornée** : $0 \leq D_{\text{JS}}(p, q) \leq \log 2 \approx 0.693$ (en nats)
- **Toujours finie** (puisque $m$ couvre les supports de $p$ et $q$)
- **Nulle ssi $p = q$**
- **$\sqrt{D_{\text{JS}}}$ est une vraie métrique** (Jensen-Shannon distance)

### Interprétation

$D_{\text{JS}}(p, q)$ peut s'interpréter comme la **réduction d'incertitude** quand on apprend de quelle source (p ou q) provient un échantillon :

$$ D_{\text{JS}}(p, q) = H(m) - \frac{1}{2}[H(p) + H(q)] $$

Si $p$ et $q$ sont identiques, savoir l'origine n'apporte rien → $D_{\text{JS}} = 0$.
Si $p$ et $q$ sont disjointes, l'origine est parfaitement identifiable → $D_{\text{JS}} = \log 2$.

### Variantes pondérées

Plus généralement, avec poids $\pi_1 + \pi_2 = 1$ :

$$ D_{\text{JS}}^{(\pi)}(p, q) = \pi_1 D_{\text{KL}}(p \| m) + \pi_2 D_{\text{KL}}(q \| m), \quad m = \pi_1 p + \pi_2 q $$

Cas standard $\pi_1 = \pi_2 = 0.5$.

## Quand c'est utile

- **Comparer 2 distributions** sans préférence d'ordre (vs KL qui force forward/reverse)
- **Supports disjoints** ou quasi-disjoints (KL infinie, JS finie)
- **GANs** : la fonction de perte du GAN original (Goodfellow 2014) minimise une JS divergence entre vraie distribution et générée
- **Détection de drift** plus robuste que KL (toujours bornée)
- **Clustering de distributions** : tu peux faire un dendrogramme basé sur JS distance
- **Comparaison de topic models** (LDA distributions) ou de modèles de langue

## Quand ça ne marche pas / pièges

- **GAN saturation** : le gradient de la JS s'évanouit quand les distributions ne se chevauchent pas — c'est pourquoi WGAN (avec [[Wasserstein distance]]) est plus stable pour entraîner les GANs
- **Coût computationnel** : calcule 2 KL au lieu d'une (impact faible mais réel sur grand $N$)
- **Confusion avec JS distance** : la JS divergence n'est pas une métrique, seule sa racine carrée l'est
- **JS pondéré asymétrique** : si on choisit $\pi_1 \neq \pi_2$, on perd la symétrie. À utiliser que si on a une raison forte.
- **Distributions continues** : implémentation moins directe (estimation densité non-paramétrique nécessaire)

## Code minimal

```python
import numpy as np
from scipy.spatial.distance import jensenshannon
from scipy.stats import entropy

p = np.array([0.5, 0.3, 0.2])
q = np.array([0.4, 0.4, 0.2])

# JS distance (racine de JS divergence — c'est une métrique)
js_dist = jensenshannon(p, q, base=2)  # entre 0 et 1
js_div = js_dist ** 2

# Implémentation manuelle pour comprendre
m = 0.5 * (p + q)
js_manual = 0.5 * entropy(p, m, base=2) + 0.5 * entropy(q, m, base=2)
print(f"JSD = {js_manual:.4f}")

# PyTorch pour deep learning
import torch
import torch.nn.functional as F

def js_divergence(p, q):
    """p, q : tensors normalisés (sum=1) sur dernière dim"""
    m = 0.5 * (p + q)
    return 0.5 * F.kl_div(m.log(), p, reduction='batchmean') \
         + 0.5 * F.kl_div(m.log(), q, reduction='batchmean')
```

## Pour aller plus loin

- Lin, *Divergence Measures Based on the Shannon Entropy* (IEEE Trans. Inf. Theory 1991)
- Endres & Schindelin, *A new metric for probability distributions* (2003) — JS distance est métrique
- Goodfellow et al., *Generative Adversarial Networks* (2014) — usage en GANs
- **Liens internes** : [[KL divergence]], [[Shannon entropy]], [[Wasserstein distance]], [[Cross-entropy]]
