---
galaxie: wiki
nom: Chi-squared tests
alias: [chi², chi-carré, test du chi², χ², independence test, goodness-of-fit]
type: concept
categorie: concept/stats
sous_categories: [chi-squared, categorical, independence, goodness-of-fit, contingency]
domaines: [data-science]
maturite: established
auteurs_cles: [Pearson 1900]
lecture_min: 7
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, chi-squared, categorical]
---

# Chi-squared tests — tests du χ²

## TL;DR

Famille de tests pour **données catégorielles**. 3 usages principaux : (1) **adéquation** (goodness-of-fit) — comparer une distribution observée à une distribution théorique ; (2) **indépendance** — deux variables catégorielles sont-elles indépendantes ? ; (3) **homogénéité** — plusieurs populations ont-elles la même distribution catégorielle ?

Toutes reposent sur la même statistique : la **somme des écarts au carré entre observé et attendu**, divisée par l'attendu.

## Le problème

- Le dé est-il **équilibré** ? (adéquation à uniforme)
- Profession et préférence politique sont-elles **indépendantes** ? (indépendance)
- Le taux de souscription est-il **homogène** entre 3 régions ? (homogénéité)

Toutes des questions sur des **données comptées** (effectifs par catégorie), pas continues.

## L'idée

### Statistique du $\chi^2$

Soit $O_i$ les effectifs observés et $E_i$ les effectifs attendus sous $H_0$, pour $k$ catégories :

$$ \chi^2 = \sum_{i=1}^k \frac{(O_i - E_i)^2}{E_i} $$

Sous $H_0$, et si $E_i$ est suffisamment grand (≥ 5 typiquement), $\chi^2$ suit une loi du chi-carré avec $df$ degrés de liberté.

### 1. Test d'adéquation (goodness-of-fit)

**Question** : la distribution observée correspond-elle à une distribution théorique attendue ?

Exemple : 1000 lancers de dé donnent (171, 165, 159, 168, 173, 164). On attend 1000/6 ≈ 166.67 par face.

$df = k - 1$

```python
from scipy.stats import chisquare
observed = [171, 165, 159, 168, 173, 164]
expected = [1000/6] * 6
chi2, p = chisquare(observed, f_exp=expected)
```

### 2. Test d'indépendance

**Question** : deux variables catégorielles sont-elles indépendantes ?

Format : tableau de contingence $r \times c$.

Effectifs attendus sous indépendance :

$$ E_{ij} = \frac{(\text{somme ligne } i) \cdot (\text{somme colonne } j)}{n} $$

$df = (r-1)(c-1)$

```python
from scipy.stats import chi2_contingency
table = [[40, 60], [50, 50]]   # 2 lignes × 2 colonnes
chi2, p, df, expected = chi2_contingency(table)
```

C'est le test sous-jacent à toute [[CA]] (Correspondence Analysis).

### 3. Test d'homogénéité

Structurellement identique au test d'indépendance, mais la **question diffère** : on fixe la marge ligne (échantillons indépendants par groupe), et on teste si la distribution des colonnes est la même entre groupes.

Calcul identique au test d'indépendance.

### Effect size — Cramér's V

Le $\chi^2$ dépend du nombre d'observations. Pour une mesure indépendante de $n$ :

$$ V = \sqrt{\frac{\chi^2}{n \cdot \min(r-1, c-1)}} $$

$V \in [0, 1]$ : 0 = indépendance, 1 = association parfaite.

### Conditions de validité

- **$E_i \geq 5$ pour chaque cellule** (règle de Cochran). Sinon :
  - Fusionner des catégories adjacentes
  - Utiliser le **test exact de Fisher** (table 2×2 surtout)
  - Utiliser un test bootstrap
- **Indépendance des observations** — critique. Pas valable sur données pairées (utiliser McNemar pour 2×2 pairée).
- **Variables nominales ou ordinales** — pour ordinales avec ordre, préférer tests dédiés (Kruskal-Wallis, Cochran-Armitage).

### Tests apparentés

| Cas | Test |
|---|---|
| 2×2 pairée (avant/après catégoriel) | **McNemar test** |
| Tableau 2×2 avec petits effectifs | **Fisher's exact test** |
| Tendance dans tableau ordinal | **Cochran-Armitage** |
| 3 groupes ou plus, indépendants, ordinaux | **Kruskal-Wallis** (ranks) |

## Quand c'est utile

- A/B testing avec outcome catégoriel (clic / pas clic)
- Détection d'association entre 2 variables catégorielles
- Validation d'un modèle de distribution (uniforme, Poisson, etc.) sur des fréquences
- Pré-traitement avant [[CA]] / [[MCA]]
- Évaluation classifier multi-classe (analyse des erreurs)

## Quand ça ne marche pas / pièges

- **Effectifs attendus < 5** dans plus de 20% des cellules → résultats peu fiables
- **Données pairées** traitées comme indépendantes → utiliser McNemar
- **Variables ordinales** traitées comme nominales → perte de puissance (utiliser test ordinal)
- **Tester un grand tableau de contingence** → si significatif, identifier les cellules contributives (résidus standardisés)
- **Confusion direction de l'association** : le $\chi^2$ dit s'il y a association, pas dans quel sens. Regarder les résidus + la table de contingence.

## Code minimal

```python
from scipy import stats
import pandas as pd

# Test d'indépendance sur DataFrame
ct = pd.crosstab(df['var1'], df['var2'])
chi2, p, df_stat, expected = stats.chi2_contingency(ct)
print(f"χ² = {chi2:.3f}, p = {p:.4f}, df = {df_stat}")

# Résidus standardisés (cellules contributives)
residuals = (ct - expected) / np.sqrt(expected)
print(residuals)   # |z| > 1.96 = cellule contributive

# Cramér's V
import numpy as np
n = ct.sum().sum()
r, c = ct.shape
V = np.sqrt(chi2 / (n * min(r-1, c-1)))
print(f"Cramér's V = {V:.3f}")

# Fisher exact (table 2x2)
oddsr, p_fisher = stats.fisher_exact([[a, b], [c, d]])

# McNemar (pairée)
from statsmodels.stats.contingency_tables import mcnemar
result = mcnemar([[a, b], [c, d]], exact=True)
```

## Implémentations concrètes

- `scipy.stats` : `chisquare`, `chi2_contingency`, `fisher_exact`, `power_divergence`
- `statsmodels.stats.contingency_tables` : Table2x2, mcnemar, mh_chi2_*
- `pingouin.chi2_independence` — interface plus complète (Cramér's V inclus)
- R : `chisq.test`, `fisher.test`, `mcnemar.test`

## Pour aller plus loin

- Agresti, *Categorical Data Analysis* (3e éd. 2013) — référence
- **Liens internes** : [[Hypothesis testing]], [[CA]], [[MCA]], [[Multiple testing correction]] (si tableau RxC analysé cellule par cellule)
