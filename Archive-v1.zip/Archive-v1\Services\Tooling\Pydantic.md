---
galaxie: dev
nom: Pydantic
alias: [pydantic, pydantic-v2]
categorie: tooling/validation
sous_categories: [validation, types, serialization, schema]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: [attrs, dataclasses, msgspec, marshmallow]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, validation, types]
url_officiel: https://docs.pydantic.dev/
url_docs: https://docs.pydantic.dev/latest/
url_repo: https://github.com/pydantic/pydantic
---

# Pydantic

## Pourquoi
Bibliothèque #1 de **validation de données** en Python, basée sur les type hints. Validate input, parse JSON, sérialiser API responses — le tout type-safe. Utilisée par [[FastAPI]], LangChain, OpenAI SDK, Anthropic SDK, et la quasi-totalité des libs LLM modernes. Pydantic v2 (Rust core) est 5-50x plus rapide que v1.

## Quand l'utiliser
- Schémas d'API (request/response) — combo naturel avec [[FastAPI]]
- Configuration apps (avec `pydantic-settings` pour env vars)
- Validation de JSON / YAML / dicts non-typés
- Sérialisation cross-format (JSON, dict, model)
- LLM Structured Outputs (via Instructor, OpenAI parse) — voir [[Structured outputs]]
- Pipelines data — types stricts en frontière

## Quand NE PAS l'utiliser
- Performance ultra-critique parsing 100k+/s → msgspec (plus rapide, moins de features)
- Validation simple sans dépendance → `dataclasses` + manuel
- JSON Schema pur → utiliser jsonschema directement

## Pièges connus
- **v1 → v2 breaking changes** : APIs renommées (`parse_obj` → `model_validate`, `dict()` → `model_dump()`, etc.)
- **Validation des fields** : `@field_validator` (v2) vs `@validator` (v1)
- **Config** : `class Config:` (v1) vs `model_config = ConfigDict(...)` (v2)
- **Mutability defaults** : `Field(default_factory=list)`, pas `= []`
- **Discriminated unions** : pratique mais syntaxe à connaître (`Field(discriminator='type')`)
- **Performance JSON** : `model_dump_json()` plus rapide que `json.dumps(model.model_dump())`

## Liens
- [[FastAPI]] — utilise Pydantic en interne
- [[Instructor]] — LLM structured outputs Pydantic-based
- [[Structured outputs]] (concept)
- Docs v2 : https://docs.pydantic.dev/latest/
- Migration v1→v2 : https://docs.pydantic.dev/latest/migration/
