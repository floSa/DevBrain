---
galaxie: dev
type: project
nom: <% tp.file.title %>
status: actif
type_projet: 
stack: []
created: <% tp.date.now("YYYY-MM-DD") %>
modified: <% tp.date.now("YYYY-MM-DD") %>
tags: [project]
---

# Projet — <% tp.file.title %>

## Objectif

## Type
<CLI | Web app | Library | ML pipeline | Data pipeline>

## Stack

Voir aussi : 

## Statut

- Démarré le : 
- Phase actuelle : 

## Liens

- Repo : 
- Bugs : [[Bugs]]
- Decisions : [[Decisions]]
- Stack : [[Stack]]
