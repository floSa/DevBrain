---
galaxie: wiki
nom: ROC AUC
alias: [ROC, AUC, ROC AUC, courbe ROC, area under curve]
type: concept
categorie: concept/ml
sous_categories: [classification, metrics, threshold, evaluation, imbalanced]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Green-Swets 1966 (théorie du signal), Hanley-McNeil 1982]
lecture_min: 9
created: 2026-05-19
modified: 2026-05-19
tags: [concept, ml, metrics, classification, roc, auc]
---

# ROC AUC — Receiver Operating Characteristic, Area Under Curve

## TL;DR

Métrique d'évaluation pour **classification binaire** indépendante du seuil. La **courbe ROC** trace le **taux de vrais positifs** (TPR) en fonction du **taux de faux positifs** (FPR) à mesure que le seuil de décision varie. L'**AUC** (area under curve) résume la courbe en un nombre : $0.5$ = aléatoire, $1.0$ = parfait. Interprétable comme la **probabilité que le modèle rang un positif au-dessus d'un négatif tiré au hasard**.

## Le problème

Un classifieur retourne souvent un **score** (probabilité, marge) ; on en tire une décision binaire via un **seuil** (par défaut 0.5). Mais :
- Le seuil 0.5 est rarement optimal (déséquilibre, coûts asymétriques)
- L'**accuracy** dépend du seuil et peut être trompeuse (classe majoritaire à 95% → 95% d'accuracy en prédisant toujours la classe majoritaire)
- On veut comparer **modèles** indépendamment du seuil choisi

La ROC et l'AUC s'affranchissent du seuil.

## L'idée

### Définitions

Pour un seuil $t$ donné, on classe positif si score $\geq t$.

| | Réel positif | Réel négatif |
|---|---|---|
| **Prédit positif** | TP (true positive) | FP (false positive) |
| **Prédit négatif** | FN (false negative) | TN (true negative) |

- **TPR** (sensitivity, recall) = $\frac{TP}{TP + FN}$ — fraction des positifs réels que le modèle attrape
- **FPR** (1 - specificity) = $\frac{FP}{FP + TN}$ — fraction des négatifs réels que le modèle classe à tort comme positifs

### Courbe ROC

En faisant varier $t$ de $+\infty$ à $-\infty$, on trace tous les couples $(\text{FPR}(t), \text{TPR}(t))$ dans le plan unité :

```
TPR
1 |          *  *  *  *
  |       *
  |    *        ← bonne courbe ROC (proche du coin haut-gauche)
  | *
  |*
0 +-------- ----- FPR
  0              1
```

- Coin haut-gauche $(0, 1)$ : classifieur parfait
- Diagonale $y = x$ : aléatoire
- Sous la diagonale : pire qu'aléatoire (inverser les prédictions !)

### AUC — Area Under Curve

$$ \text{AUC} = \int_0^1 \text{TPR}(\text{FPR}^{-1}(x)) \, dx $$

**Interprétation probabiliste** : AUC = $P(\text{score}(X^+) > \text{score}(X^-))$ où $X^+, X^-$ sont tirés au hasard parmi les positifs et négatifs réels. Autrement dit : si je tire un + et un - au hasard, quelle est la proba que le modèle leur attribue le bon ordre ?

| AUC | Interprétation |
|---|---|
| 1.0 | Parfait |
| 0.9 | Excellent |
| 0.8 | Bon |
| 0.7 | Acceptable, à améliorer |
| 0.6 | Faible |
| 0.5 | Aléatoire |
| < 0.5 | Inversé (un soucis de signe ou label) |

### Précision vs Recall — Précision-Recall (PR) AUC

Pour **classes très déséquilibrées** (1% de positifs en fraude par exemple), la ROC peut être trompeusement optimiste car les FP sont noyés dans l'océan de TN. La courbe **Précision-Recall** est plus informative :

- Précision = $\frac{TP}{TP + FP}$ — fraction des prédictions positives qui sont correctes
- Recall = TPR

**PR-AUC** est préférable quand :
- Déséquilibre fort (>1:20)
- Le coût d'un FP est élevé (fraude, médical)
- On se fiche des vrais négatifs (information retrieval)

### Optimiser le seuil

Quand on doit prendre une décision, l'AUC ne suffit pas — il faut **choisir un seuil**. Méthodes :
- **Youden's J** : maximiser TPR - FPR
- **F1** : maximiser harmonique précision/recall (équilibré)
- **Coût** : minimiser $c_{FP} \cdot \text{FP} + c_{FN} \cdot \text{FN}$ si les coûts sont connus
- **Recall fixé** (ex. "je veux capter 95% des cas") : minimiser FPR sous contrainte TPR ≥ 0.95

## Quand c'est utile

- Comparaison de modèles indépendamment du seuil
- Hyperparam tuning par CV avec `scoring='roc_auc'`
- Médical, fraude, classification binaire en général
- Communication aux stakeholders ("notre modèle attrape 80% des cas avec 10% de faux positifs")

## Quand ça ne marche pas / pièges

- **Multi-classes** : AUC se généralise mal. Utiliser **macro-AUC** (moyenne par classe vs reste) ou **OvR** ; alternativement, métrique différente (top-k accuracy, F1 macro)
- **Classes très déséquilibrées** : PR-AUC plus informatif que ROC-AUC
- **Score mal calibré** : un modèle peut avoir un excellent AUC mais des probabilités non calibrées (toutes proches de 0.5 ou aux extrêmes). Vérifier avec [[Calibration]].
- **AUC sans IC** : sur petit dataset, l'AUC est bruité — toujours rapporter IC95% (bootstrap)
- **Confondre TPR avec accuracy** : ce sont des choses différentes
- **Modèle inutilisable malgré bon AUC** : si la classe minoritaire est sous-représentée, AUC=0.9 peut quand même donner 80% de FP en valeur absolue

## Code minimal

```python
from sklearn.metrics import roc_curve, roc_auc_score, auc, precision_recall_curve
import matplotlib.pyplot as plt

# Score (proba ou marge) renvoyé par le modèle
y_score = model.predict_proba(X_test)[:, 1]
y_true = y_test

# ROC
fpr, tpr, thresholds = roc_curve(y_true, y_score)
auc_value = roc_auc_score(y_true, y_score)

plt.plot(fpr, tpr, label=f'AUC = {auc_value:.3f}')
plt.plot([0, 1], [0, 1], '--', label='aléatoire')
plt.xlabel('FPR'); plt.ylabel('TPR'); plt.legend()

# Pour classes déséquilibrées : PR curve
precision, recall, _ = precision_recall_curve(y_true, y_score)
pr_auc = auc(recall, precision)
```

## Implémentations concrètes

- `sklearn.metrics` : `roc_auc_score`, `roc_curve`, `precision_recall_curve`, `average_precision_score`
- `cross_val_score(scoring='roc_auc')` direct
- `sklearn.calibration` : calibration des probas si AUC bon mais probas mauvaises

## Pour aller plus loin

- Hanley & McNeil, *The meaning and use of the area under a receiver operating characteristic (ROC) curve* (1982) — paper canonique
- Saito & Rehmsmeier, *The Precision-Recall Plot Is More Informative than the ROC Plot When Evaluating Binary Classifiers on Imbalanced Datasets* (PLOS ONE 2015)
- **Liens internes** : [[Calibration]], [[Cross-validation]], [[XGBoost]] / [[LightGBM]] / [[CatBoost]]
