---
galaxie: wiki
nom: Diffusion models
alias: [DDPM, DDIM, classifier-free guidance, latent diffusion, score matching]
type: concept
categorie: concept/multimodal
sous_categories: [diffusion, generative, image, video, multimodal]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Ho 2020 (DDPM), Song 2021 (SDE), Rombach 2022 (Latent Diffusion)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, multimodal, diffusion, generative]
---

# Diffusion models

## TL;DR

Famille de modèles **génératifs** qui apprennent à **débruiter** progressivement du bruit gaussien pour produire des images / vidéos / audio. **Forward process** : ajout incrémental de bruit. **Reverse process** : débruitage appris (U-Net ou DiT). Variants : **DDPM** (full sampling), **DDIM** (déterministe, plus rapide), **score-based / SDE** (formulation continue). **Classifier-Free Guidance (CFG)** : levier majeur de qualité prompt-to-image. **Latent diffusion** (Stable Diffusion) : opère sur latents VAE → 8x plus rapide. **DiT** (Diffusion Transformer) : architecture moderne (SD3, FLUX). **Distillation** (LCM, Lightning, Turbo) : 1-4 steps au lieu de 50. Standard pour [[Image generation]], video, et bientôt audio.

## Le problème

Générer des **images photoréalistes** depuis du texte demandait avant des GANs (instables, mode collapse). Comment **modèle stable, expressive, controllable** ?

## L'idée

### Forward process (noising)

Ajout progressif de **bruit gaussien** sur $T$ steps :

$$ q(x_t | x_{t-1}) = \mathcal{N}(x_t; \sqrt{1 - \beta_t} \cdot x_{t-1}, \beta_t I) $$

Au bout de $T$ steps (typ. 1000), $x_T \approx \mathcal{N}(0, I)$ (bruit pur).

### Reverse process (denoising) — appris

Le modèle apprend à inverser :

$$ p_\theta(x_{t-1} | x_t) = \mathcal{N}(x_{t-1}; \mu_\theta(x_t, t), \Sigma_\theta(x_t, t)) $$

**Trick** (Ho 2020) : au lieu de prédire $\mu_\theta$, prédire le **bruit $\varepsilon$** ajouté. Simple, stable.

Loss training :

$$ L = \mathbb{E}_{t, x_0, \varepsilon} \|\varepsilon - \varepsilon_\theta(x_t, t)\|^2 $$

avec $x_t = \sqrt{\bar\alpha_t} x_0 + \sqrt{1 - \bar\alpha_t} \varepsilon$.

→ MSE simple sur prédiction du bruit. Robuste.

### Architectures

#### U-Net (original)

Encoder-decoder convolutionnel avec skip connections. Standard SD1, SD2.

#### DiT (Diffusion Transformer, Peebles 2023)

Transformer architecture. Scale comme les LLMs. **Standard moderne** : SD3, FLUX, Sora.

#### MMDiT (Multi-Modal DiT)

Variant pour combiner text + image dans le même Transformer. SD3.

### Latent Diffusion (Rombach 2022)

**Critical insight** : opérer en **latent space** d'un VAE au lieu d'image space.

```
Image 512×512×3 → VAE encoder → Latent 64×64×4 (8x réduction)
                                    │
                                Diffusion training (sur latents)
                                    │
Latent 64×64×4 → VAE decoder → Image 512×512×3
```

- **8x speedup** vs pixel-space diffusion
- Standard depuis 2022 : Stable Diffusion, SDXL, SD3, FLUX

### Schedulers (samplers)

Pendant inference, on simule le reverse process. Différents algos :

| Sampler | Steps typiques | Notes |
|---|---|---|
| **DDPM** | 1000 | full, lent |
| **DDIM** | 50 | déterministe, rapide |
| **DPM-Solver / ++** | 20 | high quality fast |
| **Euler, Euler Ancestral** | 25-30 | classique webui |
| **Heun** | 30-50 | stable |
| **UniPC** | 8-15 | very efficient |
| **LCM** | 4 | Latent Consistency Models |
| **Lightning, Turbo** | 1-8 | one-step distilled |
| **Consistency Models** | 1 | true one-step |

Modern : DPM++ 2M Karras, Euler, UniPC populaires.

### Classifier-Free Guidance (CFG, Ho 2022)

**Levier qualité majeur**. Pendant inference, calculer **deux predictions** :

$$ \varepsilon_{guided} = \varepsilon_{uncond} + w \cdot (\varepsilon_{cond} - \varepsilon_{uncond}) $$

avec $w$ guidance scale (typ. 5-15).

- $w = 1$ : pas de guidance
- $w$ high : prompt strict, mais artifacts
- Standard pour text-to-image

**Negative prompts** : ce qu'on veut éviter (e.g. "blurry, low quality").

### Training stages

```
1. Train VAE (encode/decode images to/from latent)
2. Train diffusion on latents (sur dataset de paires (image, caption))
3. Optional : fine-tune (LoRA, DreamBooth, ControlNet)
4. Optional : distill (LCM, Lightning) pour few-step
```

### Distillation pour acceleration

#### LCM (Latent Consistency Models)

4 steps au lieu de 50. Standard.

#### LCM-LoRA

LoRA qui rend un model existant fast.

#### SDXL Turbo / Lightning

1-4 steps adversarial distillation.

#### Hyper-SD

State of the art distillation moderne.

#### Consistency Models (Song 2023)

True one-step generation.

### Modèles image notables (2026)

| Modèle | Type | Notes |
|---|---|---|
| **SD 1.5** | UNet LDM | classique, beaucoup de LoRAs |
| **SDXL** | UNet LDM | base solide |
| **SDXL Turbo / Lightning** | distilled | fast |
| **SD3 / 3.5** | MMDiT | text rendering |
| **FLUX.1** (Schnell/Dev/Pro) | DiT | SOTA open 2024 |
| **FLUX.1 Kontext** | DiT | édition d'images |
| **DALL-E 3** | OpenAI closed | |
| **Midjourney v6/v7** | closed | aesthetic |
| **Imagen 3, 4** | Google | |
| **Ideogram** | text rendering++ | |
| **GPT-Image-1 / Nano Banana** | OpenAI / Google | |
| **HiDream** | open 2025 | |

### Control / fine-tuning

#### LoRA

PEFT pour personalize (style, character). Voir [[PEFT]].

#### DreamBooth

Fine-tune sur few images (3-5) du sujet → reproduit.

#### Textual Inversion

Apprend un new embedding pour concept. Léger.

#### ControlNet

Conditionner sur **canny edges, depth, pose, segmentation**, etc.

```
[prompt] + [pose skeleton] → ControlNet → image avec cette pose
```

Standard pour précision (architecture, character poses, etc.).

#### IP-Adapter

Conditionner sur **image** (style transfer, identity preservation).

#### InstantID, PuLID

Identity preservation : 1 photo → personne reproduite dans nouvelles scenes.

### Vidéo

Diffusion étendu au temporel :
- Sora, Veo, Runway, Pika, Kling, Luma
- HunyuanVideo, Mochi, LTX, Wan (open)
- AnimateDiff (image→vidéo via LoRA)

### Audio

- MusicGen, Stable Audio, Lyria, Suno
- TTS : XTTS, F5-TTS, Tortoise

### Lien avec score matching

Diffusion = **score matching** (apprendre $\nabla_x \log p(x)$). Voir [[Brownian motion]] (SDE formulation continue).

Reverse SDE = denoising guidé par score appris.

## Quand c'est utile

- **Image generation** : marketing, design, creative
- **Image editing** : inpaint, outpaint, style transfer
- **Character / brand consistency** : LoRAs, DreamBooth
- **Architectural / product design** : ControlNet (poses, scenes)
- **Vidéo generation** : marketing, animation
- **Music** : pre-production
- **TTS** : voice acting, accessibility
- **Augmentation data** : synthetic images for ML
- **Research** : score matching, generative modeling

## Quand ça ne marche pas / pièges

- **Text rendering** : faible sauf SD3+, Ideogram, FLUX
- **Counting** : "5 cats" → souvent 3 ou 7
- **Hands** : digits wrong, infamous problem
- **Faces** : mediocre sans LoRA/IP-Adapter
- **Compositional** : "A on top of B" hard
- **Photorealism** : trop "diffusion-y", AI-look
- **Slow without distillation** : 30 steps × 1s = lent
- **Mode collapse** sur fine-tune small dataset
- **DreamBooth overfitting** : forget base
- **CFG too high** : artifacts, oversaturation
- **Watermarks** : modèles peuvent reproduire watermarks training data
- **Copyrights** : data legal grey area

## Code minimal

```python
# 1. Diffusers (Hugging Face) — text-to-image
from diffusers import StableDiffusionPipeline, DiffusionPipeline
import torch

pipe = DiffusionPipeline.from_pretrained("stabilityai/stable-diffusion-xl-base-1.0",
                                         torch_dtype=torch.float16).to("cuda")
image = pipe("A serene landscape with mountains").images[0]
image.save("output.png")

# 2. FLUX.1
pipe = DiffusionPipeline.from_pretrained("black-forest-labs/FLUX.1-dev",
                                         torch_dtype=torch.bfloat16).to("cuda")
image = pipe("A red cat sitting on a chair", num_inference_steps=50).images[0]

# 3. Image-to-image
from diffusers import StableDiffusionImg2ImgPipeline
pipe = StableDiffusionImg2ImgPipeline.from_pretrained(...).to("cuda")
output = pipe(prompt="anime style", image=init_image, strength=0.7)

# 4. ControlNet (depth-conditioned)
from diffusers import StableDiffusionControlNetPipeline, ControlNetModel
controlnet = ControlNetModel.from_pretrained("lllyasviel/control_v11f1p_sd15_depth",
                                              torch_dtype=torch.float16)
pipe = StableDiffusionControlNetPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5", controlnet=controlnet, torch_dtype=torch.float16
).to("cuda")
image = pipe("A castle on a hill", image=depth_map).images[0]

# 5. LoRA loading
pipe.load_lora_weights("./my-style-lora.safetensors")
image = pipe("A landscape in <my-style> style").images[0]

# 6. LCM (Latent Consistency Models) — 4 steps
from diffusers import LCMScheduler
pipe.scheduler = LCMScheduler.from_config(pipe.scheduler.config)
pipe.load_lora_weights("latent-consistency/lcm-lora-sdxl")
image = pipe("...", num_inference_steps=4, guidance_scale=1.0).images[0]
# Très rapide !

# 7. SDXL Turbo (1 step)
from diffusers import AutoPipelineForText2Image
pipe = AutoPipelineForText2Image.from_pretrained("stabilityai/sdxl-turbo",
                                                  torch_dtype=torch.float16).to("cuda")
image = pipe("portrait", num_inference_steps=1, guidance_scale=0.0).images[0]

# 8. Negative prompt
image = pipe("A beautiful landscape",
             negative_prompt="blurry, low quality, ugly").images[0]

# 9. Classifier-Free Guidance (CFG)
image = pipe("A cat", guidance_scale=7.5).images[0]  # default 7.5
image = pipe("A cat", guidance_scale=15.0).images[0]  # strict to prompt, may artifacts

# 10. Custom training : DreamBooth (5 images of your dog)
# accelerate launch train_dreambooth.py \
#   --pretrained_model_name_or_path="runwayml/stable-diffusion-v1-5" \
#   --instance_data_dir="./my_dog" \
#   --instance_prompt="a photo of sks dog" \
#   --output_dir="./my-dog-model"

# 11. Score-based / SDE formulation (theoretical)
# dx = f(x, t) dt + g(t) dW (forward)
# dx = [f(x, t) - g(t)^2 ∇_x log p_t(x)] dt + g(t) dW̃ (reverse)
# Learn ∇_x log p_t(x) = score
```

## Pour aller plus loin

- Ho, Jain, Abbeel, *Denoising Diffusion Probabilistic Models* (NeurIPS 2020) — DDPM
- Song et al., *Denoising Diffusion Implicit Models* (ICLR 2021) — DDIM
- Song et al., *Score-Based Generative Modeling through Stochastic Differential Equations* (ICLR 2021)
- Rombach et al., *High-Resolution Image Synthesis with Latent Diffusion Models* (CVPR 2022) — Stable Diffusion
- Peebles, Xie, *Scalable Diffusion Models with Transformers* (DiT, ICCV 2023)
- Ho, Salimans, *Classifier-Free Diffusion Guidance* (NeurIPS Workshop 2022)
- Esser et al., *Scaling Rectified Flow Transformers for High-Resolution Image Synthesis* (SD3, ICML 2024)
- Luo et al., *Latent Consistency Models* (2023)
- *Diffusers* (Hugging Face) — library standard
- **Liens internes** : [[Brownian motion]], [[Image generation]], [[Video generation]], [[Speech models]], VAE / autoencoder (latent space)
