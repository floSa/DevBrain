---
galaxie: dev
type: rule
domaine: tests
applicable: global
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, tests, qa]
---

# Règle — Tests

## Principe
Tests unitaires sur la **logique métier**, tests d'intégration sur les **boundaries** (API, DB, externe). Pas de test pour faire du chiffre.

## MUST

- **Tests unitaires** sur toute fonction métier non triviale.
- **Tests d'intégration** sur les boundaries : endpoints HTTP, accès DB, appels externes (mockés ou containers).
- **Pas de tests qui dépendent de l'ordre d'exécution** (utiliser fixtures isolées).
- **Pas de tests qui dépendent du réseau réel** en CI (mock ou testcontainers).
- **CI fail = merge bloqué** sur main/master.
- **Coverage** mesurée et reportée. Cible *par défaut* : **>70% sur la logique métier** (pas la glue).

## SHOULD

- **>85% coverage** sur la logique métier critique (paiements, auth, calcul).
- **Tests rapides** : suite complète < 60s en local pour 95% des projets.
- **Naming explicite** : `test_<fonction>_<scenario>_<résultat_attendu>`.
- **Arrange / Act / Assert** clairement séparés.
- **Fixtures** plutôt que setup/teardown éparpillé.
- **Tests E2E** sur les parcours critiques (auth, paiement, upload).
- **Tests régressifs** quand un bug est fixé (cf. `[[Rules/Global/Documentation]]` ADR).

## NICE-TO-HAVE

- **Mutation testing** (mutmut, stryker) pour vérifier la qualité des tests.
- **Property-based testing** (hypothesis, fast-check) sur les fonctions pures complexes.
- **Snapshot testing** pour les outputs structurés volumineux.
- **Performance tests** sur les endpoints critiques.

## Anti-patterns

- **Tests qui testent l'implémentation** (ex: `assert mock.called_with(internal_arg)`) — ils cassent au moindre refactor sans bug réel.
- **Tests sur les frameworks** (ne pas tester que SQLAlchemy fait des SELECT — c'est leur boulot).
- **Tests "smoke" qui passent toujours** : `assert function() is not None` n'apporte rien.
- **Coverage chasing** : 100% coverage ≠ qualité. Préférer "coverage utile".

## Outils par stack

### Python
- `pytest` + `pytest-asyncio` + `pytest-cov`
- `hypothesis` pour property-based
- `testcontainers` pour DB/Redis/Kafka en intégration

### TypeScript / Node
- `vitest` (préféré) ou `jest`
- `playwright` pour E2E web
- `msw` pour mock HTTP

### Rust
- `cargo test` + `proptest` + `insta`

## Voir aussi

- [[Rules/Types/Library]] — coverage cible plus exigeante
- [[Pattern - API REST FastAPI minimale]] — exemple de structure tests
