---
galaxie: dev
nom: matplotlib
alias: [matplotlib, plt]
categorie: tooling/viz
sous_categories: [plotting, static, foundation]
licence: PSF-based
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[plotly]]", "[[seaborn]]", "[[altair]]", "[[bokeh]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, tooling, viz, plotting]
url_officiel: https://matplotlib.org/
url_docs: https://matplotlib.org/stable/
url_repo: https://github.com/matplotlib/matplotlib
---

# matplotlib

## Pourquoi
La lib de plotting historique Python. Statique (PNG/PDF/SVG), API très flexible, fondation de **seaborn** et de la plupart des wrappers viz. Indispensable pour la publication scientifique, rapports, intégrations notebook.

## Quand l'utiliser
- Plots statiques pour rapports / papers
- Backend de seaborn ou autres libs higher-level
- Customisation fine (axes, ticks, légendes complexes)
- Intégration dans une CI qui produit des images

## Quand NE PAS l'utiliser
- Plots interactifs (zoom, hover, dashboard) → [[plotly]], [[bokeh]]
- Web embeds → [[plotly]] ou [[altair]]
- Quick-and-dirty exploratoire avec belle esthétique → seaborn (qui utilise matplotlib)

## Pièges connus
- **API duale** : pyplot (state-machine MATLAB-like) vs OO (Figure/Axes) — utiliser OO en prod
- **Backends** : Agg (non-interactif), Qt5Agg, etc. — sources de pénibilité hors notebook
- **Performance** : lent sur > 100k points, préférer scatter avec rasterized=True ou autre lib
- **Tight layout** : `plt.tight_layout()` ou `constrained_layout=True` pour éviter labels coupés
- **Colormaps** : `viridis` defaut moderne (perceptuellement uniforme), éviter `jet`

## Liens
- [[plotly]] — alternative interactive
- [[pandas]] : intégration `df.plot()` utilise matplotlib par défaut
- seaborn : wrapper de haut niveau (fiche à créer si tu utilises)
- Cheatsheets : https://matplotlib.org/cheatsheets/
