---
galaxie: wiki
nom: Multi-agent systems
alias: [multi-agent, AutoGen, CrewAI, debate, society of mind]
type: concept
categorie: concept/agents
sous_categories: [multi-agent, debate, hierarchical, agents]
domaines: [ai-eng]
maturite: emerging
auteurs_cles: [Du 2023 (debate), Wu 2023 (AutoGen)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, agents, multi-agent, llm]
---

# Multi-agent systems

## TL;DR

Plusieurs agents LLM **collaborent** sur une tâche complexe. Topologies : **hierarchical** (manager + workers), **network/mesh**, **sequential**, **parallel**, **group chat / debate**. Rôles : Planner, Researcher, Coder, Critic, Executor, Aggregator. Frameworks : **AutoGen** (MS), **CrewAI**, **LangGraph multi-agent**, **MetaGPT**, **Camel**, **Swarm** (OpenAI). Gains : **specialization** boost qualité ; **debate** améliore reasoning. Cons : **complexity**, **cost multiplied** (N agents = N×cost), **coordination overhead**. Standard chez : assistants de coding (Devin), research agents, content pipelines.

## Le problème

Single agent peut être :
- **Mauvais en multi-step** : oublie le plan
- **Mono-expertise** : pas spécialisé tout
- **Biaisé** : un seul point de vue
- **Slow sur tâches paralles** : sequential par défaut

→ **Plusieurs agents** peuvent collaborer / débattre / spécialiser.

## L'idée

### Topologies

#### Hierarchical (manager-workers)

```
            [Manager Agent]
                  │
        ┌─────────┼─────────┐
        ▼         ▼         ▼
   [Worker A] [Worker B] [Worker C]
```

Manager :
- Décompose la tâche
- Délègue à workers
- Synthétise les outputs

Workers :
- Spécialisés (researcher, coder, etc.)
- Reportent au manager

Standard pour tasks complexes. AutoGen, CrewAI.

#### Sequential

```
[Agent A] → [Agent B] → [Agent C] → [Output]
```

Chacun build sur le précédent. Pipeline.

Use case : research → write → edit → publish.

#### Parallel

```
              ┌→ [Agent A]
[Task] → split┼→ [Agent B] → aggregate → [Output]
              └→ [Agent C]
```

Parallel runs pour aspects différents.

#### Network / mesh

Tous les agents peuvent parler à tous. Plus dynamique mais coordination harder.

#### Group chat / debate

Agents postent dans un **forum**, voient tout, prennent la parole quand veulent (ou par moderator).

```
Agent A : "I propose X"
Agent B : "Disagree, here's Y"
Agent A : "Counter-argument..."
Moderator : "Consensus?"
```

Du et al. 2023 : améliore reasoning vs single LLM.

### Rôles communs

| Rôle | Tâche |
|---|---|
| **Planner** | Décompose en sub-tasks |
| **Researcher** | Search / gather info |
| **Coder** | Write code |
| **Critic / Reviewer** | Évalue, donne feedback |
| **Executor** | Run code, call tools |
| **Aggregator / Synthesizer** | Combine outputs |
| **Moderator** | Direct conversation flow |
| **Judge** | Pick best output |
| **Memory keeper** | Maintain shared state |

### Patterns courants

#### Debate (Du 2023, Madaan 2024)

N agents argumentent différemment. Améliore reasoning vs single LLM (~5-10% sur math/reasoning).

```
Round 1 : tous donnent answer
Round 2 : voient autres answers, peuvent updater
Round 3 : final consensus
```

#### Self-refine multi-agent

Agent A génère, Agent B critique, Agent A révise.

#### Hierarchical task decomposition

Manager → sub-tasks → spawned workers → merge.

#### Reflective dialogue

Same agent multiple personas / temperatures, voit ses outputs alternatifs.

### Communication patterns

#### Broadcast

Un agent parle à tous.

#### Direct messaging

Agent A → Agent B uniquement.

#### Shared blackboard

Espace partagé que tous voient (à la React state). Standard.

#### Round-robin

Chacun parle son tour.

#### Auctioned / Bidding

Agents "bid" pour prendre une task (rare).

### Frameworks

#### AutoGen (Microsoft)

- ConversableAgent abstraction
- Group chat avec moderator
- Code execution intégrée
- AutoGen Studio (UI)

#### CrewAI

- Rôles, goals, tools
- Sequential / hierarchical tasks
- Simple, opinionated
- Active community

#### LangGraph multi-agent

- StateGraph permet multi-agent flows
- Plus flexible, low-level
- Supervisor pattern, swarm

#### MetaGPT

- Software engineering oriented
- Roles : product manager, architect, engineer, QA

#### Swarm (OpenAI, experimental)

- Handoffs entre agents
- Minimaliste

#### Camel

- Role-playing pour tasks créatives

#### ChatDev

- Multi-agent software development

#### Phidata / Agno

- Workflow + agent abstractions

### Pros / Cons

**Pros** :
- **Specialization** : meilleurs résultats par rôle
- **Reasoning boost** via debate
- **Parallel execution** possible
- **Modular** : easy to add/remove agents
- **Robustness** : 1 fail ≠ tout échoue

**Cons** :
- **Cost multiplied** : 5 agents = 5x LLM calls
- **Latency** : sequential adds, even parallel a coordination
- **Complexity** : debug harder
- **Coordination overhead** : agents qui se contredisent
- **Coupling vs simplicity** : souvent 1 agent + bonne prompt = aussi bien

### Quand multi vs single agent

| Single suffit | Multi-agent justifié |
|---|---|
| Simple task | Complex, decomposable |
| Single expertise | Multiple expertises needed |
| Cost-sensitive | Quality-critical |
| Speed-critical | OK with latency |
| Debug hard sinon | Quality > debug ease |
| Linear workflow | Branching, debate |

### Best practices

1. **Justify multi-agent** : show better than single
2. **Clear roles** : pas de role overlap
3. **Termination conditions** : éviter loops
4. **Cost budget** par task
5. **Moderator** si group chat
6. **Eval multi-agent specifically** : compare vs single
7. **Observability** : trace chaque agent's contribution
8. **Sandboxing** par agent
9. **Memory shared** vs per-agent : décider
10. **Start simple** : 2 agents, ajouter si besoin

### Pièges

- **Echo chamber** : tous les agents agree par défaut → pas de débat utile
- **Sycophancy spirale** : agents valident mutuellement
- **Coordination collapse** : pas de moderator → chaos
- **Cost runaway** : agents talk forever
- **Memory pollution** : shared state contaminée
- **Role bleed** : "Coder" commence à faire research aussi
- **Eval imbiased** : multi-agent better sur eval mais worse en prod

## Quand c'est utile

- **Software engineering** : MetaGPT, ChatDev, Devin
- **Research** : multi-perspective synthesis
- **Content creation** : writer + editor + reviewer
- **Strategic decisions** : multiple POV debate
- **Long-horizon planning** : decompose
- **Quality > speed** : willing to pay more
- **Modular workflows** : easier to extend
- **Educational** : tutor + student + grader

## Quand ça ne marche pas / pièges

- **Tasks simples** : single + good prompt souvent OK
- **Cost-sensitive prod** : 5x cost rarely 5x value
- **Latency-critical** : multi-agent slower
- **Debug nightmare** : interactions complexes
- **Eval missing** : "feels better" ≠ better
- **Same model tous** : pas de vraie diversité → debate inutile
- **Pas de termination** : conversations infinies
- **Sycophancy** : LLMs tendent à agree → faux débat
- **Coordination layer fragile** : single point of failure
- **Memory contamination** : shared state buggy
- **Role overlap** : 2 agents font la même chose

## Code minimal

```python
# 1. AutoGen
from autogen import AssistantAgent, UserProxyAgent, GroupChat, GroupChatManager

llm_config = {"model": "gpt-4o", "api_key": "..."}

assistant = AssistantAgent(name="assistant", llm_config=llm_config)
user_proxy = UserProxyAgent(name="user_proxy", code_execution_config={"work_dir": "./"})

# Single turn
user_proxy.initiate_chat(assistant, message="Write a Python script to sort a list")

# Multi-agent group chat
planner = AssistantAgent(name="planner", llm_config=llm_config,
                          system_message="You plan tasks.")
coder = AssistantAgent(name="coder", llm_config=llm_config,
                       system_message="You write code.")
critic = AssistantAgent(name="critic", llm_config=llm_config,
                        system_message="You review code.")

group = GroupChat(agents=[planner, coder, critic, user_proxy], messages=[], max_round=10)
manager = GroupChatManager(groupchat=group, llm_config=llm_config)
user_proxy.initiate_chat(manager, message="Build a CLI tool that...")

# 2. CrewAI
# from crewai import Agent, Task, Crew, Process

# researcher = Agent(
#     role="Senior Researcher",
#     goal="Find latest AI trends",
#     backstory="...",
#     tools=[search_tool],
#     llm=llm
# )

# writer = Agent(
#     role="Tech Writer",
#     goal="Write engaging articles",
#     backstory="...",
#     llm=llm
# )

# research_task = Task(description="Research AI trends 2026", agent=researcher)
# write_task = Task(description="Write article based on research", agent=writer)

# crew = Crew(agents=[researcher, writer], tasks=[research_task, write_task],
#             process=Process.sequential)
# result = crew.kickoff()

# 3. LangGraph multi-agent (Supervisor pattern)
from langgraph.graph import StateGraph, END
from typing import TypedDict, Literal

class State(TypedDict):
    task: str
    messages: list
    next_agent: str

def supervisor(state):
    # LLM decides next agent
    decision = llm.invoke(f"Task: {state['task']}\nMessages: {state['messages']}\nNext: planner, coder, critic, or FINISH?")
    return {"next_agent": decision.content}

def planner_node(state):
    plan = llm.invoke(f"Plan: {state['task']}")
    return {"messages": state["messages"] + [{"agent": "planner", "content": plan.content}]}

def coder_node(state):
    code = llm.invoke(f"Code based on plan: {state['messages'][-1]}")
    return {"messages": state["messages"] + [{"agent": "coder", "content": code.content}]}

def critic_node(state):
    review = llm.invoke(f"Review: {state['messages'][-1]}")
    return {"messages": state["messages"] + [{"agent": "critic", "content": review.content}]}

graph = StateGraph(State)
graph.add_node("supervisor", supervisor)
graph.add_node("planner", planner_node)
graph.add_node("coder", coder_node)
graph.add_node("critic", critic_node)

graph.set_entry_point("supervisor")
graph.add_conditional_edges(
    "supervisor",
    lambda s: s["next_agent"],
    {"planner": "planner", "coder": "coder", "critic": "critic", "FINISH": END}
)
# planner → back to supervisor, etc.

# 4. Manual debate
def debate(question, llm, n_agents=3, n_rounds=3):
    history = []
    for round_n in range(n_rounds):
        for agent_n in range(n_agents):
            context = "\n".join([f"Agent {h['agent']}: {h['content']}" for h in history])
            response = llm.invoke(
                f"You are Agent {agent_n+1}. Question: {question}\n"
                f"Debate so far:\n{context}\n\n"
                f"Your turn (provide reasoning):"
            )
            history.append({"agent": agent_n+1, "round": round_n, "content": response.content})
    
    consensus = llm.invoke(f"Debate:\n{history}\n\nConsensus:")
    return consensus

# 5. Self-refine multi-agent
def self_refine(task, llm, n_iter=3):
    output = llm.invoke(f"Task: {task}")
    for i in range(n_iter):
        critique = llm.invoke(f"Critique this output: {output.content}")
        output = llm.invoke(f"Original: {task}\nDraft: {output.content}\nCritique: {critique.content}\n\nImproved:")
    return output
```

## Pour aller plus loin

- Wu et al., *AutoGen: Enabling Next-Gen LLM Applications via Multi-Agent Conversation* (2023)
- Du et al., *Improving Factuality and Reasoning in Language Models through Multiagent Debate* (ICML 2024)
- Hong et al., *MetaGPT: Meta Programming for A Multi-Agent Collaborative Framework* (ICLR 2024)
- *CrewAI*, *AutoGen*, *LangGraph* documentation
- Anthropic, *Building effective agents* — when to use multi-agent
- *Phidata*, *Swarm*, *Camel* documentation
- **Liens internes** : [[Agent patterns]], [[Agent memory]], [[Tool use patterns]], [[Agent evaluation]]
