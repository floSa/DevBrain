---
galaxie: dev
nom: dbt
alias: [dbt, dbt-core, dbt-cloud]
categorie: data/transformation
sous_categories: [sql, transformation, modeling, data-warehouse]
licence: Apache-2.0 (Core), Proprietaire (Cloud)
licence_type: open-source
hosted: both
maturite: production
langage: Python (SQL templating with Jinja)
clients_officiels: [python (CLI)]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: [SQLMesh, Dataform (Google), Coalesce, Spark SQL natif]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, transformation, sql, dbt]
url_officiel: https://www.getdbt.com/
url_docs: https://docs.getdbt.com/
url_repo: https://github.com/dbt-labs/dbt-core
---

# dbt

## Pourquoi
**Transform layer** moderne pour data warehouses. SQL + Jinja + DAG. Standard de facto pour data modeling (warehouse) : [[Snowflake]], [[BigQuery]], Redshift, Databricks, [[Postgres]], [[DuckDB]]. Brille en "Analytics Engineering" : transforme du raw vers data marts, avec tests, docs, lineage.

## Quand l'utiliser
- Modeling SQL dans warehouse (Snowflake, BigQuery, Redshift)
- Tests data (`dbt test` — uniqueness, not null, accepted_values, custom)
- Documentation + lineage auto-générés
- Modèles incremental (matériaux re-calculés vs incrementaux)
- Macros pour DRY SQL
- CI/CD data avec dbt deps

## Quand NE PAS l'utiliser
- ETL Python avec transformations complexes → [[Prefect]] / [[Dagster]]
- Streaming → kSQL, [[Flink]] SQL, Materialize
- Pas de warehouse SQL → dbt n'est pas un outil orchestration
- Petite scale → SQL views natifs suffisent
- Real-time analytics → ClickHouse + dbt-clickhouse (OK mais limited)

## Pièges connus
- **dbt Core vs Cloud** : Core (CLI/CI) gratuit, Cloud (UI, scheduling, IDE) payant
- **Adapters** : un par warehouse (`dbt-snowflake`, `dbt-postgres`, etc.) — versions à matcher
- **Incremental models** : `unique_key` + `is_incremental()` macro — sous-utilisé
- **Tests** : `dbt test` runs SQL queries. Coûteux sur gros volumes — limiter en `--select`
- **Macros vs Models** : ne pas tout macro-er, ça devient illisible
- **dbt build** vs `dbt run` + `dbt test` : préférer `build` qui fait les deux dans le bon ordre
- **Snapshots** : SCD type 2 utile mais a son propre formalisme

## Liens
- [[Postgres]] / [[DuckDB]] — warehouses supportés
- [[Prefect]] / [[Dagster]] — orchestration au-dessus de dbt
- SQLMesh (alternative) : https://sqlmesh.com/
- Docs : https://docs.getdbt.com/
- Pricing Cloud : https://www.getdbt.com/pricing
