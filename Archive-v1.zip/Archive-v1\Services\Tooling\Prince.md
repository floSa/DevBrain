---
galaxie: dev
nom: Prince
alias: [prince]
categorie: tooling/stats
sous_categories: [multivariate, factor-analysis, pca, mca, famd]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[scikit-learn]] (PCA seulement)", "FactoMineR (R)"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, tooling, stats, multivariate, dimensionality-reduction]
url_officiel: https://maxhalford.github.io/prince/
url_docs: https://github.com/MaxHalford/prince
url_repo: https://github.com/MaxHalford/prince
---

# Prince

## Pourquoi
Lib Python de Max Halford pour **analyse factorielle multivariée** : PCA, MCA (catégoriel), CA (correspondances), FAMD (mixte numérique+catégoriel), MFA (multiple factor analysis), GPA. C'est l'équivalent Python de `FactoMineR` (R). Indispensable quand tu fais de la **statistique exploratoire à la française**.

## Quand l'utiliser
- PCA avec interprétation (loadings, contributions, qualités de représentation)
- **MCA** sur données catégorielles (questionnaires, sondages)
- **FAMD** sur datasets mixtes (numériques + catégoriels)
- Plots biplots / graphiques d'individus + variables
- Quand [[scikit-learn]].PCA est trop pauvre côté outputs interprétatifs

## Quand NE PAS l'utiliser
- Juste un PCA basique pour réduire la dim avant ML → [[scikit-learn]] suffit
- Très gros datasets (> qq millions de lignes) → solutions distribuées
- Tu veux du UMAP / t-SNE non-linéaire → autres libs

## Pièges connus
- **API en évolution** : versions récentes ont reformaté certaines sorties
- **Plots** : intégration matplotlib/altair selon version, vérifier la doc
- **Mémoire** : MCA sur tables disjonctives complètes peut exploser sur beaucoup de modalités
- **Compat scikit-learn** : Estimators-like mais pas 100% compat pipelines
- **Documentation** : repo GitHub plus à jour que la page officielle

## Liens
- [[scikit-learn]] — pour PCA "ML-pur"
- [[pandas]] — entrée typique
- FactoMineR (R) : https://factominer.free.fr/ — référence du domaine
- Cookbook Prince : https://github.com/MaxHalford/prince#readme
