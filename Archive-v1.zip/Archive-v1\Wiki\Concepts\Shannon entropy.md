---
galaxie: wiki
nom: Shannon entropy
alias: [entropie de Shannon, entropie, information content]
type: concept
categorie: concept/info-theory
sous_categories: [entropy, information, shannon, uncertainty]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Shannon 1948]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, info-theory, entropy, shannon]
---

# Shannon entropy

## TL;DR

Mesure de **l'incertitude** d'une variable aléatoire discrète. Une variable très prévisible a une entropie basse, une variable totalement aléatoire a une entropie maximale. Unité : **bits** (log₂) ou **nats** (logₑ). Fondation de la théorie de l'information, omniprésente en ML (cross-entropy, mutual information, model selection, attention…).

## Le problème

On veut quantifier "à quel point une variable aléatoire est imprévisible" — ou de manière équivalente, "combien d'information un échantillon de cette variable apporte". Intuitions à formaliser :

- Tirage à pile/face équilibré : 1 bit d'info par tirage.
- Tirage à pile/face truqué (P(pile) = 0.99) : presque 0 bit — on s'attend à pile.
- Variable uniforme sur 8 valeurs : 3 bits par tirage (= log₂ 8).

L'entropie de Shannon est la mesure canonique qui satisfait ces intuitions.

## L'idée

### Définition

Pour une variable aléatoire discrète $X$ prenant les valeurs $x_1, \dots, x_n$ avec probabilités $p_i = P(X = x_i)$ :

$$ H(X) = -\sum_{i=1}^n p_i \log_2 p_i $$

(par convention $0 \log 0 = 0$). Unité : **bits** avec $\log_2$, **nats** avec $\ln$.

### Propriétés clés

- **Non-négativité** : $H(X) \geq 0$
- **Maximum à l'uniforme** : $H(X) \leq \log_2 n$, atteint quand $p_i = 1/n$ pour tout $i$
- **Minimum au certain** : $H(X) = 0$ si une seule valeur a probabilité 1
- **Concavité** en $p$ : mélanger des distributions augmente l'entropie
- **Additivité** pour variables indépendantes : $H(X, Y) = H(X) + H(Y)$ si $X \perp Y$

### Interprétations

1. **Surprise moyenne** : $-\log_2 p_i$ est la "surprise" de l'événement $x_i$ (rare → grande surprise). $H(X)$ est la surprise moyenne.

2. **Longueur de code optimale** : nombre moyen de bits par symbole nécessaires pour coder $X$ (théorème de codage de Shannon). Borne inférieure atteinte par le **codage de Huffman**.

3. **Incertitude** : combien de questions binaires en moyenne il faut poser pour deviner la valeur de $X$.

### Cas continu — entropie différentielle

Pour $X$ continue de densité $f(x)$ :

$$ h(X) = -\int f(x) \log f(x) \, dx $$

⚠️ Attention : peut être **négative** (contrairement au cas discret). Pas une vraie mesure d'incertitude — surtout utile pour des comparaisons relatives (cf. [[KL divergence]]).

### Lien avec d'autres mesures

- [[Cross-entropy]] : $H(p, q) = H(p) + D_{\text{KL}}(p \| q)$
- [[KL divergence]] : $D_{\text{KL}}(p \| q) = \sum_i p_i \log(p_i/q_i)$
- [[Mutual information]] : $I(X; Y) = H(X) - H(X | Y)$
- Entropie conditionnelle : $H(X | Y) = \sum_y P(Y=y) H(X | Y=y)$

## Quand c'est utile

- **Loss en classification** : la cross-entropy (équivalente à NLL) est dérivée de l'entropie
- **Décision tree splits** : critère information gain = baisse d'entropie après split
- **Mesure de désordre** d'un dataset (équilibre des classes, diversité)
- **Régularisation** d'attention (encourage entropie haute = attention diffuse) ou inverse (entropie basse = focalisée)
- **Active learning** : sélectionner les points où le modèle est incertain (entropie haute des prédictions)
- **Mutual information** pour feature selection

## Quand ça ne marche pas / pièges

- **Variable continue** : utiliser entropie différentielle avec prudence (peut être négative, dépend du choix d'unités)
- **Estimation sur échantillon** : l'estimateur naïf $-\sum \hat p_i \log \hat p_i$ avec $\hat p_i = n_i / N$ est **biaisé** sur petit échantillon (sous-estime). Estimateurs corrigés : Miller-Madow, NSB, Chao-Shen.
- **Confusion bits vs nats** : impact sur les comparaisons inter-papers
- **Entropie maximale** comme prior bayésien (MaxEnt) : intuition séduisante mais sensible au choix de la mesure de référence
- **Variables avec support très grand** : $\log_2 n$ croît, mais ce n'est pas forcément une bonne échelle de comparaison entre datasets

## Code minimal

```python
import numpy as np
from scipy.stats import entropy

# Distribution discrète
p = np.array([0.5, 0.25, 0.25])
H = entropy(p, base=2)  # base=2 → bits, base=None → nats
print(f"H = {H:.3f} bits")  # 1.5

# Entropie d'un dataset (sur target)
from collections import Counter
counts = Counter(y_train)
probs = np.array(list(counts.values())) / len(y_train)
H_data = entropy(probs, base=2)

# Cas équilibré binaire vs déséquilibré
print(entropy([0.5, 0.5], base=2))   # 1.0 (max pour 2 classes)
print(entropy([0.9, 0.1], base=2))   # 0.469
print(entropy([1.0, 0.0], base=2))   # 0.0 (certain)
```

## Pour aller plus loin

- Shannon, *A Mathematical Theory of Communication* (Bell System Technical Journal 1948) — paper fondateur
- Cover & Thomas, *Elements of Information Theory* (2e éd., 2006) — référence
- MacKay, *Information Theory, Inference, and Learning Algorithms* (gratuit en ligne)
- **Liens internes** : [[Cross-entropy]], [[KL divergence]], [[Mutual information]], [[Perplexity]]
