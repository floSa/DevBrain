---
name: add-pattern
description: |
  Use this skill to create a new architectural pattern in Patterns/.
  Triggers: "ajoute un pattern", "documente le pattern <X>", "écris un
  pattern pour <archi>", "formalise la stack <Y>". For comparison tables,
  use compare-services instead (creates a .base). For patterns, this
  creates a .md fiche with Context → Decisions → Stack → Pitfalls.
---

# Skill — add-pattern

## Quand l'utiliser

L'utilisateur veut **formaliser une décision architecturale réutilisable** comme `Pattern - <nom>.md`. Exemples :
- "Ajoute un pattern pour RAG basique" → [[Pattern - RAG basique]]
- "Documente ma stack standard FastAPI" → [[Pattern - API REST FastAPI minimale]]
- "Pattern pour orchestration ML batch"

Différent de `compare-services` (qui crée un `.base` de comparaison) ou `add-rule` (qui crée une contrainte). Un pattern est une **recette stack-complète** avec contexte d'application.

## Pré-requis vault

Mode build. Périmètre `Patterns/` (fichiers `.md` uniquement, les `.base` sont créés par `compare-services`).

## Procédure

### 1. Vérifier la non-duplication

Cherche `Patterns/Pattern - <nom>*.md`. Si existe, propose update.

### 2. Identifier le contexte

Un pattern n'est PAS générique. Il s'applique à un **contexte précis** : taille de projet, charge attendue, contraintes, type d'usage. Faire formuler le contexte par l'utilisateur en 1-2 phrases.

### 3. Identifier les services clés

Lister les fiches `Services/` qui composent la stack du pattern. Si un service n'a pas de fiche, proposer de la créer d'abord via `add-service`.

### 4. Frontmatter

```yaml
---
galaxie: dev
type: pattern
contexte: <description précise du contexte d'application en 1-2 phrases>
created: <YYYY-MM-DD>
modified: <YYYY-MM-DD>
services_cles: ["[[Service A]]", "[[Service B]]", "[[Service C]]"]
projets_appliques: []
tags: [pattern, <domain-court>]
---
```

### 5. Corps en 5 sections fixes

```markdown
# Pattern — <Nom>

## Contexte
(quand l'appliquer, contraintes implicites)

## Stack
- **<rôle>** : [[Service]] — raison du choix
- ...

## Structure de projet
```tree
projet/
├── ...
```

## Décisions clés

### 1. <décision>
(détail + code/conf si utile)

### 2. <décision>
...

## Pièges (vu en projets)
- 

## Voir aussi
- Services : [[X]], [[Y]]
- Patterns liés : [[Pattern - Z]]
- Règles applicables : [[Rules/Types/X]]
```

### 5bis. Repérer les fiches qui mentionnent déjà ce pattern (via `find-connexes.ps1`)

**Avant** d'écrire, scanne le vault pour voir qui parle déjà du sujet :

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/find-connexes.ps1 -Name "Pattern - <nom>"
```

Note les fiches en [FAIBLE] (mentions bare) — à wikilinker à l'étape 8.

### 6. Wikilinker (via `discover-links.ps1`)

**Toujours utiliser le script** :

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/discover-links.ps1 \
    -Title "Pattern - <nom>" \
    -Categorie "pattern/<famille>" \
    -Domaines "<csv>" \
    -SousCategories "<csv>" \
    -Tags "<csv>" \
    -TopN 20
```

Un pattern référence beaucoup de fiches (services + concepts + rules + patterns cousins) → `TopN` élevé.

**Workflow** :
1. Lance le script
2. Catégorise le top par type :
   - **Patterns parents/cousins** (`Pattern - X` minimale ↔ multi-tenant) → section dédiée
   - **Services clés** → frontmatter `services_cles:` + section
   - **Rules à appliquer** (`Rules/Types/Web-app`, etc.) → section "Règles applicables"
   - **Concepts qui underlie** → section "Concepts"
   - **REX** liés si pièges issus d'expérience
3. Si une fiche service manque, **créer la fiche d'abord** (anti-pattern : pattern qui dépend de fiches inexistantes)

**Reverse linking** : pour les patterns cousins identifiés, propose d'ajouter une mention `[[Pattern - <nouveau>]]` dans leur section "Patterns liés".

### 7. Demander validation puis écrire

Path : `Patterns/Pattern - <nom>.md`. Naming : titre lisible avec espaces, pas de slug.

### 8. Audit post-création + propagation des wikilinks

Après écriture, exécute la chaîne d'hygiène :

```bash
# Détecte les wikilinks fantômes introduits dans la nouvelle fiche
powershell -ExecutionPolicy Bypass -File AI/scripts/find-connexes.ps1 -Path "Patterns/Pattern - <nom>.md"

# Patche la 1ère mention bare du pattern dans le reste du vault (dry-run puis apply)
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "Pattern - <nom>" -All
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "Pattern - <nom>" -All -Apply

# Vérification finale : 0 fantôme attendu
powershell -ExecutionPolicy Bypass -File AI/scripts/report-ghosts.ps1
```

## Anti-patterns à éviter

- **Pattern sans contexte précis** → "Pattern - Microservices" sans dire pour quel volume, c'est vide
- **Pas de services_cles** → impossible de naviguer
- **Pas de Décisions clés argumentées** → c'est juste un dump de stack
- **Pattern qui dépend de fiches services inexistantes** — créer les fiches d'abord
- **Sortir du périmètre Patterns/**

## Voir aussi

- `add-service` (créer les services référencés en prérequis)
- `compare-services` (pour les `.base` de comparaison, distincts)
- `propose-stack` (utilise les patterns en mode projet)
