---
name: doc-service
description: |
  Use this skill when the user wants to document a service integrated in
  their current project (mode PROJET). Triggers: "documente le service X",
  "ajoute la doc pour X dans mon projet", "audit la doc de mon service Y",
  "génère le README de mon service Z". Generates a services/<nom>/README.md
  from Templates/ServiceDocs/ (DevBrain via MCP), pre-fills from the Service
  fiche, and leaves <À REMPLIR> placeholders for project-specific details.
---

# Skill — doc-service

## Quand l'utiliser

En **mode PROJET** (Claude lancé dans un dossier de projet, pas dans le DevBrain), quand tu intègres un nouveau service ou veux auditer la doc existante d'un service.

## Procédure (génération initiale)

### Étape 1 — Identifier le service

Demande / déduis :
- **Nom du service** (ex: "Qdrant", "Postgres", "Docling")
- **Chemin local dans le projet** (ex: `services/qdrant/`, `services/db/`)

Si ambigu → demande.

### Étape 2 — Trouver la fiche dans le DevBrain

Via MCP :
```
mcp__devbrain__search "<nom>"
mcp__devbrain__get_file_contents "Services/<categorie>/<nom>.md"
```

Note la **catégorie** du frontmatter (`categorie: database/vector`).

### Étape 3 — Mapper catégorie → template

| Catégorie devbrain | Template |
|--------------------|----------|
| `database/relational` | `Templates/ServiceDocs/README - database-relational.md` |
| `database/vector` | `Templates/ServiceDocs/README - database-vector.md` |
| `database/graph` | `Templates/ServiceDocs/README - database-graph.md` |
| `database/document`, `database/keyvalue`, `database/timeseries`, `database/warehouse` | `README - generic.md` (pour l'instant) |
| `storage` | `README - storage-object.md` |
| `data/orchestration`, `ml/orchestration` | `README - orchestration-data.md` |
| `llm/framework` | `README - llm-orchestration.md` |
| `data/parsing` | `README - document-processing.md` |
| Autre | `README - generic.md` |

Si la catégorie n'a pas de mapping → utilise `README - generic.md`.

### Étape 4 — Récupérer le template

```
mcp__devbrain__get_file_contents "Templates/ServiceDocs/<template>"
```

### Étape 5 — Récupérer la règle correspondante

Pour la mention dans le README généré et l'audit ultérieur :
```
mcp__devbrain__get_file_contents "Rules/Documentation/<regle>.md"
```

### Étape 6 — Pré-remplir le template

Depuis la fiche Service, pré-remplir :
- **Nom du service** (titre, mentions)
- **URL doc officielle** (`url_docs` du frontmatter)
- **Wikilinks DevBrain** : `[[<Service>]]`, `[[REX - <Service>]]` (vérifier si REX existe)
- **Pièges connus** : copier la section "Pièges connus" de la fiche Service en pointer
- **Règle référencée** : ajouter la mention `Référence règle : [[<Regle>]]` en haut

Pour les autres champs (`<À REMPLIR>`), **ne pas inventer** :
- Si la fiche Service ne donne pas l'info → laisser `<À REMPLIR>`
- Préciser à l'utilisateur quels champs sont à compléter

### Étape 7 — Écrire le fichier dans le projet

Path : `<dossier_projet>/services/<nom>/README.md`

- Si le dossier n'existe pas, le créer
- Si `README.md` existe déjà → demander à l'utilisateur (overwrite vs merge vs skip)

### Étape 8 — Synthèse à l'utilisateur

Liste :
- Fichier créé : `services/<nom>/README.md`
- Template utilisé : `<template>`
- Règle référencée : `<regle>`
- **Champs à compléter manuellement** (liste des `<À REMPLIR>` détectés)
- Suggestion de prochaine action : *"complète la section Rôle métier puis on continue"*

## Procédure (audit d'un README existant)

Quand l'utilisateur dit *"audit la doc de mon service X"* :

### Étape 1 — Lire le README existant
```
Read services/<nom>/README.md
```

### Étape 2 — Identifier le type via la fiche DevBrain
(Comme étapes 2-3 ci-dessus.)

### Étape 3 — Charger la règle
```
mcp__devbrain__get_file_contents "Rules/Documentation/<regle>.md"
```

### Étape 4 — Comparer

Pour chaque section **MUST** de la règle :
- Présente dans le README ? ✅
- Absente ou incomplète ? ❌ — la lister explicitement

Idem pour **SHOULD** (signal, pas bloquant) et **NICE** (info).

### Étape 5 — Rapport

Format :

```markdown
## Audit — services/<nom>/README.md

Règle appliquée : Rules/Documentation/<regle>.md

### MUST manquants ou incomplets (bloquant)
- [ ] <section X> : <quoi manque>
- [ ] ...

### SHOULD à considérer
- [ ] ...

### NICE
- ...
```

Demande si tu corriges les MUST automatiquement (avec confirmation) ou si l'utilisateur les complète.

## Anti-patterns

- Inventer des valeurs (modèle d'embedding, dimension, etc.) si non documentées dans la fiche Service
- Écrire dans le DevBrain (Services/, Rules/, etc.) — interdit en mode PROJET, sauf `Bugs/REX - <Service>.md` via skill `log-bug`
- Ignorer les `<À REMPLIR>` — toujours les lister à l'utilisateur en synthèse
- Overwrite un README existant sans demander

## Voir aussi

- `Rules/Documentation/` (toutes les règles)
- `Templates/ServiceDocs/` (tous les templates)
- Skill `log-bug` (workflow connexe : log de bug pendant un projet)
- Skill `propose-stack` (workflow amont : choisir un service)
