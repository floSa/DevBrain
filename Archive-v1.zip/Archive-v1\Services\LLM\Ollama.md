---
galaxie: dev
nom: Ollama
alias: [ollama]
categorie: llm/local
sous_categories: [inference, gguf, quantization]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Go
clients_officiels: [python, ts, rest]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[LM Studio]]", "[[vLLM]]", "[[llama.cpp]]", "[[text-generation-webui]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, local, inference]
url_officiel: https://ollama.com/
url_docs: https://github.com/ollama/ollama/tree/main/docs
url_repo: https://github.com/ollama/ollama
---

# Ollama

## Pourquoi
Le moyen le plus simple de faire tourner un LLM en local. Une commande (`ollama run llama3`), Modelfile pour customisation, API REST OpenAI-compatible. Bibliothèque de modèles GGUF prêts à l'emploi. Parfait pour dev et POC offline.

## Quand l'utiliser
- Dev offline / sans coût API
- POC RAG / agent en local avant d'aller en cloud
- App qui doit tourner offline (desktop, edge)
- Tester rapidement un modèle open-weight (Llama, Qwen, Mistral, Gemma…)
- Gpu modeste (M1/M2 Mac, RTX 3060+) où vLLM est over-kill

## Quand NE PAS l'utiliser
- Production avec haute concurrence → [[vLLM]] (throughput bien meilleur)
- Modèles non-GGUF (formats spéciaux) → llama.cpp direct ou [[vLLM]]
- Besoin de batching avancé / quantizations spécifiques → solutions plus low-level
- GPU enterprise (A100, H100) avec scaling → vLLM ou TGI

## Pièges connus
- **Throughput limité** : single-request, pas de batching natif efficace
- **Default `num_ctx`=2048** : tronque les longs contextes silencieusement, à override
- **Modèles téléchargés** : stockés dans `~/.ollama/models/` (volumineux, prévoir la place)
- **API non strictement OpenAI** : la plupart des SDK marchent, mais certains champs (logprobs, tool_calls structurés) divergent
- **Concurrence** : `OLLAMA_NUM_PARALLEL` à régler explicitement
- **Modelfile** : héritage docker-like, sympa mais pas toujours nécessaire

## Liens
- [[vLLM]] — alternative production-ready
- [[LM Studio]] — alternative GUI
- Bibliothèque modèles : https://ollama.com/library
- API doc : https://github.com/ollama/ollama/blob/main/docs/api.md
- Modelfile reference : https://github.com/ollama/ollama/blob/main/docs/modelfile.md
