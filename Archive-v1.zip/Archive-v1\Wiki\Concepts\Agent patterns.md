---
galaxie: wiki
nom: Agent patterns
alias: [ReAct, Plan-and-Execute, Reflexion, LATS, agent loops, workflow patterns]
type: concept
categorie: concept/agents
sous_categories: [agents, react, planning, llm]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Yao 2023 (ReAct), Shinn 2023 (Reflexion), Anthropic 2024]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, agents, llm, workflow]
---

# Agent patterns

## TL;DR

Architectures pour faire **exécuter des tâches autonomement** par un LLM. Distinction Anthropic : **workflow** (paths prédéfinis) vs **agent** (LLM dirige dynamiquement). Patterns workflow : **prompt chaining**, **routing**, **parallelization**, **orchestrator-workers**, **evaluator-optimizer**. Patterns agentic : **ReAct** (Reason + Act), **Plan-and-Execute**, **Reflexion** (memory), **LATS** (tree search), **hierarchical agents**. Standard 2026 : workflows quand possible (plus prévisibles), agents quand vraiment nécessaire (exploratoire, open-ended). Différence cost / qualité énorme : un agent peut faire 10x plus d'appels qu'un workflow.

## Le problème

LLM standalone = chatbot. Pour vraiment **agir** (call APIs, search web, exécuter code, manipuler files), on ajoute **tools** ([[tool-use]]). Mais comment **orchestrer** plusieurs steps, decisions, memory ?

## L'idée

### Workflows vs Agents (Anthropic 2024)

#### Workflow

- **LLMs et tools orchestrés via paths prédéfinis** par le développeur
- Plus prévisible, debuggable, moins cher
- **Recommandé** quand le pipeline est known

#### Agent

- **LLM dirige dynamiquement** son propre process (decisions, tool calls)
- Plus flexible, plus puissant
- Plus cher, plus risqué (boucles infinies, hallucination tools)
- **Recommandé** seulement quand vraiment nécessaire

→ **"Start with the simplest solution"** (Anthropic).

### Workflow patterns (Anthropic)

#### 1. Prompt chaining

Séquence linéaire de LLM calls, chaque step prend l'output du précédent :

```
[Input] → LLM step 1 → LLM step 2 → LLM step 3 → [Output]
```

Use case : génération en plusieurs étapes (outline → sections → polish).

#### 2. Routing

LLM classifie l'input, route vers le bon handler :

```
[Input] → [Classifier LLM] → ┬→ Handler A (simple Q&A)
                              ├→ Handler B (code task)
                              └→ Handler C (data analysis)
```

Use case : multi-purpose chatbot, customer support.

#### 3. Parallelization

Plusieurs LLMs en parallèle :

- **Sectioning** : diviser la task en sous-tasks indépendantes
- **Voting** : N runs identiques pour robustesse

```
                ┌→ LLM A ─┐
[Input] → split ┼→ LLM B ─┼→ aggregate → [Output]
                └→ LLM C ─┘
```

Use case : multi-aspect analysis, content moderation (parallel checks).

#### 4. Orchestrator-workers

Un LLM orchestrator décompose, des LLMs workers exécutent :

```
[Input] → [Orchestrator] → spawns [Worker 1, Worker 2, ...] → [Synthesize]
```

Plus dynamique que parallelization fixe. Use case : research, code generation multi-file.

#### 5. Evaluator-optimizer

Loop : générer → évaluer → réviser :

```
[Generate] ⇄ [Evaluate]
   │             │
   └─revise─────┘
```

Use case : code generation avec tests, refinement de réponses.

### Agentic patterns

#### ReAct (Yao 2023)

**Reason + Act loop** :

```
Thought: I need to find X.
Action: search("X")
Observation: result from tool
Thought: Based on result, I need Y.
Action: ...
...
Final Answer: ...
```

- Standard simple, mature
- Interleave reasoning et tool calls
- LLM continue jusqu'à `Final Answer`

#### Plan-and-Execute / Plan-and-Solve

1. **Plan** : LLM génère un plan complet d'abord
2. **Execute** : exécute step par step

```
Plan:
1. Search X
2. Analyze results
3. Compute Y
4. Compare to baseline
5. Report

Execute step 1: ...
Execute step 2: ...
```

- Plus structuré que ReAct
- Évite les boucles infinies (steps known à l'avance)
- Replan si step fail

#### Reflexion (Shinn 2023)

ReAct + **memory of past failures** :

```
Trial 1 : fail
  → Reflect : "I failed because... Next time I should..."
  → Store reflection in memory
Trial 2 : use reflection
  → Better outcome
```

- Pour tâches où retry possible (code, games)
- Verbal reinforcement learning

#### LATS — Language Agent Tree Search (Zhou 2024)

Combine ReAct + **Monte Carlo Tree Search** :
- Explore multiple branches d'actions
- Backtrack si échec
- Evaluate via reward model
- Best path = answer

- Plus performant que ReAct sur problèmes complexes
- Plus coûteux (multi-branch)

#### ToT-based agents

Tree-of-Thoughts pour reasoning + actions. Explore plusieurs paths.

### Hierarchical agents

Manager agent qui délègue à sub-agents :

```
[Manager Agent]
  ├─[Researcher Agent] (gather info)
  ├─[Coder Agent] (write code)
  └─[Reviewer Agent] (check work)
```

- Specialization → meilleurs résultats
- Mais coordinarion overhead
- Cf. AutoGen, CrewAI, MetaGPT

### Society of Mind / Debate

Plusieurs agents avec **rôles** débattent :

```
Agent A : "Solution X is best"
Agent B : "I disagree, here's why..."
Agent A : "Counter-argument..."
...
Moderator : "Consensus: ..."
```

Améliore reasoning sur problèmes complexes. Du Yin 2023.

### Code agents (Devin-style)

Agents spécialisés en software engineering :
- ReAct + code execution sandbox
- File manipulation
- Git operations
- Long-horizon planning

Standard : Claude Code, Cursor, Cline, Aider.

### Web agents

Agents qui naviguent le web :
- Computer use (screenshots + clicks)
- Browser automation (Playwright)
- DOM-based actions

Cf. Anthropic Computer Use, OpenAI Operator, WebVoyager, BrowserBase.

### Tool retrieval (sélection dynamique)

Si **trop de tools** (>50), embedded chacun, retrieve les pertinents :

```
1. Get available tools (1000+)
2. Embed query, search top-K tools
3. Pass K tools to LLM
```

### Considerations production

#### Failure modes

- **Infinite loops** : agent retrieve la même chose 10x
- **Tool hallucinations** : LLM "imagine" un tool qui n'existe pas
- **Cost runaway** : agent fait 100 calls $$$
- **Tool misuse** : mauvais args
- **Output hallucinations** : final answer not grounded in tool results

#### Mitigations

- **Max iterations** : limite stricte (e.g. 10 steps)
- **Tool schema validation** ([[Structured outputs]])
- **Cost budget per task** : kill switch
- **Human-in-the-loop** : approval gates pour actions critiques
- **Sandboxing** : code execution isolée
- **Output validation** : verify against tool results

#### State management

Agents = stateful. Need :
- **Memory** ([[Agent memory]])
- **Durable execution** : Temporal, Inngest, LangGraph checkpointing
- **Resume from failure**
- **Audit trail**

### Standard frameworks

| Framework | Strengths |
|---|---|
| **LangGraph** | StateGraph, cycles, checkpointing, HITL |
| **OpenAI Agents SDK** | Tightly integrated, function calling native |
| **Anthropic Claude Agent SDK** | Native tool use, Computer Use |
| **AutoGen** (MS) | Multi-agent debates, conversation flow |
| **CrewAI** | Multi-agent with roles |
| **smolagents** (HF) | Code-as-action, lightweight |
| **DSPy** | Declarative pipelines, optimization |
| **LlamaIndex Agents** | RAG-first |
| **Pydantic AI** | Type-safe, Pydantic-based |

### Choisir le pattern

| Use case | Pattern |
|---|---|
| Simple Q&A | None (just LLM) |
| Multi-step generation known | Prompt chaining |
| Classification + handler | Routing |
| Multi-aspect analysis | Parallelization |
| Dynamic decomposition | Orchestrator-workers |
| Iterative refinement | Evaluator-optimizer |
| Tool use exploration | ReAct |
| Long horizon plan | Plan-and-Execute |
| Reuse past failures | Reflexion |
| Hard problems | LATS / ToT agents |
| Multiple expertises | Hierarchical / Multi-agent |
| Software eng | Code agents (Claude Code, Cursor) |
| Web tasks | Computer use / Web agents |

### Best practices

1. **Workflow first**, agent only when needed
2. **Limit iterations** : max 10-20 steps
3. **Validate tool calls** : schema + retry on invalid
4. **Cost / step budget**
5. **Eval rigoureusement** ([[Agent evaluation]]) : success rate, steps, cost
6. **Observability** : trace every step (Langfuse, LangSmith)
7. **Sandboxing** pour code execution
8. **Human-in-the-loop** for critical / irreversible actions
9. **Memory management** : voir [[Agent memory]]
10. **Test failure modes** : red team your agent

## Quand c'est utile

- **Software engineering** : Claude Code, Cursor, Aider
- **Research / analysis** : multi-step gathering
- **Customer support** : routing + handlers
- **Data extraction** : structured output workflow
- **Web automation** : booking, scraping
- **Code generation iterative** : evaluator-optimizer
- **Multi-modal analysis** : vision + reasoning
- **Personal assistants** : multi-tool integration

## Quand ça ne marche pas / pièges

- **Simple tasks** : agent overkill, slower + expensive
- **Critical safety actions** : agents peuvent faire des actions inattendues
- **Tools peu fiables** : agent re-retry indéfiniment
- **Long horizon planning** : LLMs faibles sur plans de 50+ steps
- **State explosion** : memory grows, context window overflow
- **Cost monitoring absent** : agent runs away
- **Eval missing** : "ça marche" ≠ ça marche en prod
- **Multi-agent overhead** : 5 agents = 5x cost, pas toujours 5x quality
- **Hallucinated tools** : LLM appelle `non_existent_function()`
- **Tool output parsing fail** : agent stuck sur erreur de parsing
- **No human-in-the-loop sur actions $$$** : DELETE database par accident

## Code minimal

```python
# 1. ReAct via LangGraph
from langgraph.prebuilt import create_react_agent
from langchain_anthropic import ChatAnthropic
from langchain_community.tools import DuckDuckGoSearchRun

llm = ChatAnthropic(model="claude-3-7-sonnet-latest")
tools = [DuckDuckGoSearchRun()]
agent = create_react_agent(llm, tools)

response = agent.invoke({"messages": [("user", "Latest news about LLMs?")]})

# 2. Plan-and-Execute manual
def plan_and_execute(query, tools, llm):
    # Plan
    plan = llm.invoke(f"Make a plan to answer: {query}\n\nSteps:")
    steps = parse_steps(plan.content)
    
    # Execute
    results = []
    for step in steps:
        result = llm.invoke(f"Execute step: {step}\nTools: {tools}")
        results.append(result.content)
    
    # Synthesize
    return llm.invoke(f"Synthesize: {results}")

# 3. Anthropic Computer Use / Tool Use
import anthropic
client = anthropic.Anthropic()

tools = [{
    "name": "search_web",
    "description": "Search the web",
    "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}
}]

def agent_loop(user_msg, max_iter=10):
    messages = [{"role": "user", "content": user_msg}]
    for i in range(max_iter):
        response = client.messages.create(
            model="claude-3-7-sonnet-latest",
            max_tokens=1024,
            tools=tools,
            messages=messages
        )
        if response.stop_reason == "end_turn":
            return response
        if response.stop_reason == "tool_use":
            messages.append({"role": "assistant", "content": response.content})
            tool_use = next(b for b in response.content if b.type == "tool_use")
            tool_result = execute_tool(tool_use.name, tool_use.input)
            messages.append({
                "role": "user",
                "content": [{"type": "tool_result", "tool_use_id": tool_use.id, "content": tool_result}]
            })
    return "Max iterations reached"

# 4. Reflexion
class ReflexiveAgent:
    def __init__(self, llm):
        self.llm = llm
        self.reflections = []
    
    def attempt(self, task):
        # Try with past reflections
        ctx = "\n".join(self.reflections)
        result = self.llm.invoke(f"Task: {task}\nPast learnings: {ctx}")
        return result
    
    def reflect(self, task, result, success):
        if not success:
            reflection = self.llm.invoke(f"Task: {task}\nResult: {result}\nReflect on failure and how to improve.")
            self.reflections.append(reflection.content)

# 5. Hierarchical via CrewAI
# from crewai import Agent, Task, Crew
# researcher = Agent(role="Researcher", goal="Gather info", llm=llm)
# writer = Agent(role="Writer", goal="Draft article", llm=llm)
# crew = Crew(agents=[researcher, writer], tasks=[...])

# 6. Multi-agent debate
def debate(question, n_rounds=3):
    agent_a = "You argue YES"
    agent_b = "You argue NO"
    history = []
    for _ in range(n_rounds):
        a = llm(f"{agent_a}\n\nDebate so far: {history}\nQuestion: {question}")
        history.append({"A": a})
        b = llm(f"{agent_b}\n\nDebate so far: {history}\nA argued: {a}")
        history.append({"B": b})
    
    final = llm(f"Debate transcript: {history}\nWhat's the consensus?")
    return final
```

## Pour aller plus loin

- Yao et al., *ReAct: Synergizing Reasoning and Acting in Language Models* (ICLR 2023)
- Anthropic, *Building effective agents* (engineering blog 2024) — workflow vs agent
- Shinn et al., *Reflexion: Language Agents with Verbal Reinforcement Learning* (NeurIPS 2023)
- Zhou et al., *Language Agent Tree Search Unifies Reasoning Acting and Planning* (ICML 2024)
- Wang et al., *A Survey on Large Language Model based Autonomous Agents* (2024)
- *LangGraph*, *CrewAI*, *AutoGen* documentation
- **Liens internes** : [[agent-loops]], [[Tool use patterns]], [[Agent memory]], [[Multi-agent systems]], [[Agent evaluation]], [[Prompt engineering]]
