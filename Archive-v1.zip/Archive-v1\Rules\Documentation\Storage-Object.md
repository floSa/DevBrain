---
galaxie: dev
type: rule
domaine: documentation
applicable: type-service-storage-object
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, documentation, storage, s3, minio, object-storage]
---

# Règle — Documentation Stockage objet

S'applique à : [[MinIO]], AWS S3, Cloudflare R2, Backblaze B2, et tout autre stockage objet.

## Principe (1 phrase)
Le `services/<storage>/README.md` doit fixer **l'arborescence des buckets et la politique de rétention** — ces deux points évitent 90% des problèmes d'organisation et de coût.

## MUST

### 1. Arborescence des buckets
Liste exhaustive des buckets avec leur rôle :

```
| Bucket | Rôle | Contenu | Public ? |
|--------|------|---------|----------|
| <projet>-raw | Ingestion brute | PDFs originaux uploadés par les users | non |
| <projet>-processed | Données traitées | JSON normalisés après pipeline | non |
| <projet>-models | Artefacts ML | Modèles entraînés, weights | non |
| <projet>-public | Assets publics | Images, fichiers téléchargeables par CDN | oui |
| <projet>-backups | Snapshots DB | Dumps PG/Mongo périodiques | non |
```

Pour chaque bucket :
- **Convention de nommage des objets** (ex: `users/<user_id>/<doc_id>.pdf`)
- **Versionning** activé ou non
- **Encryption** (SSE-S3, SSE-KMS, client-side)

### 2. Politique de rétention
Documenter pour chaque bucket :
- **Durée de conservation** (ex: bucket `*-raw` → 90 jours, `*-backups` → 30 jours, `*-models` → infini)
- **Lifecycle rules** configurées (transition vers Glacier, expiration auto)
- **Politique en cas d'échec d'ingestion** : garde-t-on le fichier source ou non ?
- **Soft delete** : les objets supprimés sont-ils récupérables ?

### 3. Contrat d'interface
- Endpoint d'accès (`endpoint_url` pour MinIO, région pour S3)
- Variables d'env : `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `S3_BUCKET_*`
- Client utilisé (`boto3`, `minio-py`, etc.)
- Patterns d'usage (`upload_file`, `presigned_url`, `multipart`)

### 4. Sécurité
- **IAM policies** ou ACLs configurées
- **Buckets jamais publics par défaut**
- **Presigned URLs** : durée par défaut, contraintes
- Si utilisé pour des données sensibles : encryption at rest + in transit obligatoires

## SHOULD

- **Volumétrie attendue** par bucket (ordre de grandeur)
- **Métriques coût** : monitoring du storage utilisé et des egress
- **Stratégie multi-région** (réplication cross-region si applicable)
- **Audit logs** : qui accède à quoi (CloudTrail / MinIO audit)

## NICE

- Diagramme de flux : quel service produit/consomme quel bucket
- Scripts de cleanup périodiques (objets orphelins)
- Quotas par utilisateur (si app multi-tenant avec storage par tenant)

## Pièges classiques

- **Buckets publics accidentels** : audit régulier obligatoire
- **Egress fees** sur S3/GCS — surveiller le volume sortant
- **MinIO AGPL** : implications légales si tu redistribues — voir [[MinIO]]
- **Pas de cleanup** : les buckets `*-tmp` qui grossissent à l'infini
- **Filename collisions** sans UUID ou timestamp dans la convention de nommage
- **Restore non testé** : faire un drill de restore tous les trimestres

## Voir aussi

- Template : `Templates/ServiceDocs/README - storage-object.md`
- [[README - Service]] — règle parente
- [[MinIO]] — fiche Service
- [[Document-Processing]] — souvent en aval pour les pipelines RAG
