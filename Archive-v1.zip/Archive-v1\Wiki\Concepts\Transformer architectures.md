---
galaxie: wiki
nom: Transformer architectures
alias: [encoder-only, decoder-only, encoder-decoder, BERT, GPT, T5, transformer block]
type: concept
categorie: concept/transformers
sous_categories: [transformer, architecture, encoder, decoder]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Vaswani 2017, Devlin 2018 (BERT), Radford 2018 (GPT), Raffel 2020 (T5)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, transformer, architecture, llm]
---

# Transformer architectures

## TL;DR

Trois grandes familles de Transformers : **encoder-only** (BERT, RoBERTa, DeBERTa) pour comprendre/classifier, **decoder-only** (GPT, Llama, Claude, Mistral) pour générer (le standard moderne des LLMs), **encoder-decoder** (T5, BART, Whisper) pour seq2seq (traduction, summarization, ASR). Chaque "block" Transformer = **self-attention + MLP** avec **residual + normalization**. Variantes modernes : **RMSNorm** (vs LayerNorm), **SwiGLU** (vs GELU), **pre-LN** (vs post-LN), [[Positional encoding|RoPE]] (vs sinusoidal). Le decoder-only domine en 2026 grâce à la flexibilité (in-context learning, instructable, RLHF).

## Le problème

Le paper Transformer (Vaswani 2017) propose une architecture **encoder-decoder** pour la traduction. Mais selon le use case (classification, génération, seq2seq), des variantes sont plus naturelles.

## L'idée

### Block Transformer (le building block universel)

Chaque block standard :

```
       ┌─────────────────────────┐
       │ residual + LayerNorm    │
       │           │             │
       │     [MLP / FFN]         │
       │           │             │
       │ residual + LayerNorm    │
       │           │             │
       │  [Self-attention]       │
       │           │             │
       └───────────│─────────────┘
                 input
```

**Composants** :
- **Self-attention** (voir [[Self-attention]])
- **MLP / FFN** : couche feed-forward $X \to \text{Linear} \to \text{Activation} \to \text{Linear}$
- **Residual connections** : permet gradient flow profond
- **Normalization** (LayerNorm ou RMSNorm)

### Pre-LN vs Post-LN

#### Post-LN (original Vaswani)

```
out = LN(x + Sublayer(x))
```

Normalisation **après** la skip connection. Instable en train profond → besoin de warmup.

#### Pre-LN (modern standard)

```
out = x + Sublayer(LN(x))
```

Normalisation **avant** la sublayer. Plus stable, train sans warmup. **Standard moderne** (Llama, GPT, Mistral).

### Normalisations

#### LayerNorm

$$ \text{LN}(x) = \frac{x - \mu}{\sigma} \cdot \gamma + \beta $$

avec $\mu, \sigma$ stats sur les features (par token). Standard original.

#### RMSNorm (Zhang 2019)

$$ \text{RMSNorm}(x) = \frac{x}{\sqrt{\frac{1}{d} \sum x_i^2}} \cdot \gamma $$

Pas de centrage (pas de $\mu$, pas de $\beta$). **Plus rapide**, performance équivalente. Standard Llama, Mistral, Qwen, Gemma.

#### DeepNorm

Pour train very-deep Transformers (>1000 layers). Microsoft research.

### FFN / MLP block

#### Vanilla MLP

$$ \text{FFN}(x) = W_2 \cdot \text{ReLU}(W_1 x) $$

avec $W_1 \in \mathbb{R}^{d \times 4d}$ (expansion 4x), $W_2 \in \mathbb{R}^{4d \times d}$.

#### GeGLU / SwiGLU (Shazeer 2020)

Standard moderne. Active **GLU** (Gated Linear Unit) :

$$ \text{SwiGLU}(x) = (x W_1 \odot \text{Swish}(x W_3)) W_2 $$

avec **3 matrices** au lieu de 2. Meilleure expressivité. **2/3 expansion ratio** pour garder même nb de params.

Standard Llama 2/3, Mistral, Qwen.

#### Activations

- **ReLU** : classique, simple. Mort si activation < 0.
- **GELU** : smooth ReLU, $x \cdot \Phi(x)$. Standard BERT/GPT-2.
- **SwiGLU** : pour FFN moderne (LLaMA-style)
- **Swish / SiLU** : $x \cdot \sigma(x)$. Smooth, sans gradient vanishing.

### Architectures macro

#### Encoder-only (BERT family)

```
[Input] → [Embedding + PE] → [N × Encoder Block] → [Output]
```

- **Bidirectional self-attention** (pas de masque causal)
- Pas de génération autoregressive
- Output = embedding par token + special [CLS]
- **Use** : classification, NER, sentence embeddings, QA extractive
- **Pretraining** : MLM (Masked Language Modeling) — masque ~15% tokens, prédit

Exemples : **BERT**, **RoBERTa**, **DeBERTa**, **DistilBERT**, **MPNet**, **DeBERTa v3**.

#### Decoder-only (GPT family) — **standard moderne**

```
[Input] → [Embedding + PE] → [N × Decoder Block with causal mask] → [LM head]
```

- **Causal self-attention** (token ne voit que le passé)
- Génération **autoregressive** : prédit next token, append, recommence
- **Pretraining** : Causal LM (next token prediction)
- **Standard pour LLM moderne** : GPT-4, Claude, Llama, Mistral, Qwen, Gemma, DeepSeek

Pourquoi domine ?
- Simple à scale
- Génératif natif
- Instructable via prompting (in-context learning)
- RLHF naturel
- Multimodal extensible

#### Encoder-decoder (T5 / BART family)

```
[Input] → [Encoder] → [memory]
                           │
                           ↓ (cross-attention)
[Output prefix] → [Decoder] → [Output]
```

- **Encoder** lit l'input (bidirectional)
- **Decoder** génère output (causal + cross-attention sur encoder)
- **Use** : traduction (T5), summarization (BART), ASR (Whisper)
- **Pretraining** : span corruption (T5), denoising (BART)

Exemples : **T5**, **BART**, **mT5**, **mBART**, **Whisper**, **NLLB**.

#### Prefix-LM

Compromis : encoder regard bidirectional sur "prefix" (prompt), decoder causal sur reste. Utilisé dans UL2.

### Récap

| Famille | Attention | Use case | Exemples |
|---|---|---|---|
| **Encoder-only** | bidirectional | classif, embeddings, NER | BERT, RoBERTa, DeBERTa |
| **Decoder-only** | causal | génération | GPT-4, Claude, Llama, Mistral |
| **Encoder-decoder** | bi (enc) + causal (dec) | seq2seq | T5, BART, Whisper |
| **Prefix-LM** | bi (prefix) + causal | hybride | UL2 |

### Composants modernes (Llama-style)

Architecture canonique 2026 (Llama 3 / Mistral / Qwen) :

- **Decoder-only**
- **RMSNorm** + **Pre-LN**
- **RoPE** (positional encoding)
- **SwiGLU** FFN
- **GQA** (Grouped-Query Attention) — voir [[Flash Attention and efficient attention]]
- **No bias** in linears
- **Flash Attention** kernel
- **Tied embeddings** (sometimes) — input/output embedding shared

### Évolutions récentes

- **MoE** : remplacer FFN par Mixture of Experts (voir [[Mixture of Experts]])
- **State Space Models** : Mamba, RWKV (voir [[State Space Models]])
- **Hybrid** : Jamba (Mamba + attention), Samba
- **Multi-token prediction** (DeepSeek-V3) : prédire plusieurs tokens d'un coup
- **Differential attention** (Microsoft) : soustraction de 2 softmax pour réduire noise

### Sizing typique

| Modèle | Layers | d_model | Heads | Params |
|---|---|---|---|---|
| BERT-base | 12 | 768 | 12 | 110M |
| BERT-large | 24 | 1024 | 16 | 340M |
| GPT-2 small | 12 | 768 | 12 | 124M |
| GPT-2 XL | 48 | 1600 | 25 | 1.5B |
| GPT-3 | 96 | 12288 | 96 | 175B |
| Llama 2 7B | 32 | 4096 | 32 | 7B |
| Llama 3 70B | 80 | 8192 | 64 | 70B |
| Llama 4 (MoE) | varies | varies | varies | 400B (38B active) |

## Quand c'est utile

- **Tout LLM moderne** : decoder-only de facto
- **Classification / NER / embeddings** : encoder-only (BERT family) plus efficace
- **Traduction / summarization** : encoder-decoder dédié (T5, NLLB) souvent meilleur que decoder-only en perf/cost
- **ASR / TTS** : Whisper / Seamless = encoder-decoder
- **VLM** : Vision encoder + LLM decoder (LLaVA-style)
- **Code search** : encoder-only fine-tuné (StarCoder embeddings)
- **Pretraining custom** : choisir architecture selon downstream

## Quand ça ne marche pas / pièges

- **BERT pour génération** : pas conçu pour, donne mauvais résultats
- **GPT pour classification** : marche mais 10x plus coûteux que BERT
- **Encoder-decoder vs decoder-only** : pour seq2seq, encoder-decoder a moins de params mais meilleure compression info — toujours benchmarker
- **Post-LN deep models** : instabilité, besoin de warmup long. Préférer Pre-LN.
- **LayerNorm en FP16** : numerical issues. Utiliser bf16 ou compute in fp32.
- **SwiGLU avec 4x expansion** : trop de params. Standard = 2.67x (8/3) pour SwiGLU.
- **Mixing implementations** : RoPE de Llama 1 vs Llama 3 (theta différent), incompatible.
- **Tied embeddings sans care** : `lm_head` shared avec `embed_tokens`, mais certains modèles untie pour gagner expressivité.
- **Confondre couche et block** : "32 layers" = 32 Transformer blocks, pas 32 linear layers.

## Code minimal

```python
import torch
import torch.nn as nn
import torch.nn.functional as F

class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(d))
        self.eps = eps
    
    def forward(self, x):
        norm = x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)
        return norm * self.weight

class SwiGLU(nn.Module):
    def __init__(self, d_model, d_ff):
        super().__init__()
        self.W1 = nn.Linear(d_model, d_ff, bias=False)
        self.W3 = nn.Linear(d_model, d_ff, bias=False)
        self.W2 = nn.Linear(d_ff, d_model, bias=False)
    
    def forward(self, x):
        return self.W2(F.silu(self.W1(x)) * self.W3(x))

class TransformerBlock(nn.Module):
    """Llama-style decoder block: Pre-LN + RMSNorm + SwiGLU + Causal attention."""
    def __init__(self, d_model, n_heads, d_ff):
        super().__init__()
        self.attn_norm = RMSNorm(d_model)
        self.attn = nn.MultiheadAttention(d_model, n_heads, batch_first=True, bias=False)
        self.ffn_norm = RMSNorm(d_model)
        self.ffn = SwiGLU(d_model, d_ff)
    
    def forward(self, x, mask=None):
        # Pre-LN attention
        h = self.attn_norm(x)
        attn_out, _ = self.attn(h, h, h, attn_mask=mask, need_weights=False)
        x = x + attn_out
        
        # Pre-LN FFN
        x = x + self.ffn(self.ffn_norm(x))
        return x

# Decoder-only model (GPT-style)
class DecoderOnly(nn.Module):
    def __init__(self, vocab_size, d_model=512, n_heads=8, n_layers=6, d_ff=2048):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.blocks = nn.ModuleList([
            TransformerBlock(d_model, n_heads, d_ff) for _ in range(n_layers)
        ])
        self.norm = RMSNorm(d_model)
        self.lm_head = nn.Linear(d_model, vocab_size, bias=False)
    
    def forward(self, ids):
        B, T = ids.shape
        x = self.embed(ids)
        # Causal mask
        mask = nn.Transformer.generate_square_subsequent_mask(T)
        for block in self.blocks:
            x = block(x, mask)
        x = self.norm(x)
        return self.lm_head(x)  # logits over vocab

# Hugging Face : architectures standards
from transformers import AutoModel, AutoModelForCausalLM, AutoModelForSeq2SeqLM
encoder_only = AutoModel.from_pretrained("bert-base-uncased")
decoder_only = AutoModelForCausalLM.from_pretrained("meta-llama/Meta-Llama-3-8B")
encoder_decoder = AutoModelForSeq2SeqLM.from_pretrained("google-t5/t5-base")
```

## Pour aller plus loin

- Vaswani et al., *Attention Is All You Need* (NeurIPS 2017)
- Devlin et al., *BERT* (NAACL 2019)
- Radford et al., *Improving Language Understanding by Generative Pre-Training* (OpenAI 2018) — GPT
- Raffel et al., *Exploring the Limits of Transfer Learning with a Unified Text-to-Text Transformer* (JMLR 2020) — T5
- Touvron et al., *LLaMA* / *Llama 2* — architecture moderne décrite
- Karpathy, *Let's reproduce GPT-2 (124M)* (YouTube)
- *The Annotated Transformer* (Rush, Harvard NLP)
- **Liens internes** : [[Self-attention]], [[Positional encoding]], [[Tokenization]], [[Flash Attention and efficient attention]], [[Mixture of Experts]], [[State Space Models]]
