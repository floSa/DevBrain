---
name: add-wiki-workflow
description: |
  Use this skill when the user wants to document a step-by-step procedure
  in the personal Wiki. Triggers: "ajoute le workflow", "documente la
  procédure", "ajoute un workflow pour <X>", or when the user describes
  a recurring multi-step task they want to capture (debug X, setup Y,
  evaluate Z). Generates a fiche compliant with Templates/Wiki-Workflow.md
  in Wiki/Workflows/<Nom>.md.
---

# Skill — add-wiki-workflow

## Quand l'utiliser

L'utilisateur veut **capturer une procédure step-by-step** qu'il fait ou voudrait faire de manière reproductible. Différent d'un concept (notion) ou d'un service (outil) : un workflow est une **séquence d'actions**.

Exemples : "Bootstrap projet AI eng", "Évaluer un système LLM", "Debug pipeline data", "Setup pgvector local", "Migrer un projet de pandas vers Polars".

## Pré-requis vault

Mode wiki. Périmètre `Wiki/Workflows/` uniquement.

## Procédure

### Étape 1 — Vérifier la non-duplication

Cherche `Wiki/Workflows/**/<nom>*.md`. Si existe, propose mise à jour.

### Étape 2 — Catégoriser

`categorie: workflow/<famille>` :

| Famille | Exemples |
|---|---|
| `workflow/ai-eng` | Bootstrap RAG, eval LLM, prompt tuning |
| `workflow/data-eng` | Debug pipeline, schéma drift, backfill |
| `workflow/mlops` | Déployer modèle, monitoring, retraining |
| `workflow/ml-eng` | Bench frameworks, optim hyperparam, scaling training |
| `workflow/data-science` | Faire une ACP, sélectionner les features, eval modèle |
| `workflow/dev-flow` | Onboarding projet, setup local, debug CI |

### Étape 3 — Identifier les pré-requis

Récolte :
- Outils nécessaires (mentionner les fiches Services pertinentes)
- Connaissances prérequises (concepts liés)
- Durée estimée (15min, 1h, 1 journée…)
- Domaines : où ce workflow s'applique

### Étape 4 — Construire le corps en 6 sections

Template `Wiki-Workflow.md` :

```markdown
# <Nom>

## Quand l'utiliser
(En 1 phrase : quand est-ce que ce workflow est pertinent ?)

## Pré-requis
- 
- 

## Procédure

### 1. <étape>
```bash
# commandes / actions concrètes
```

### 2. <étape>
...

## Checklist de fin
- [ ] 
- [ ] 

## Pièges courants
- 

## Variantes
- Si <condition> → fais <variation>

## Voir aussi
- [[Pattern - X]]
- [[<service ou skill>]]
```

### Étape 5 — Frontmatter

```yaml
---
nom: <Nom du workflow>
type: workflow
categorie: workflow/<famille>
sous_categories: [tags fins]
domaines: [...]
duree_estimee: <ex: 30min-2h>
prerequis: [<liste>]
status:                          # vide si complet, 'stub' si stub
created: <YYYY-MM-DD>
modified: <YYYY-MM-DD>
tags: [workflow, <famille-court>]
---
```

### Étape 5bis — Repérer les fiches qui mentionnent déjà ce workflow (via `find-connexes.ps1`)

**Avant** d'écrire :

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/find-connexes.ps1 -Name "<nom-workflow>"
```

Liste [FAIBLE] = candidates pour `add-wikilinks` à l'étape 9.

### Étape 6 — Wikilinker (via `discover-links.ps1`)

**Toujours utiliser le script** :

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/discover-links.ps1 \
    -Title "<nom-workflow>" \
    -Categorie "workflow/<famille>" \
    -Domaines "<csv>" \
    -SousCategories "<csv>" \
    -Tags "<csv>" \
    -TopN 20
```

Un workflow touche plusieurs galaxies à la fois (DEV + WIKI + SKILLS) → garder un `TopN` plus élevé (15-20).

**Workflow** :
1. Lance le script avec les metadata
2. Catégoriser le top par galaxie (Services, Concepts, Outils, Patterns)
3. Présente à l'utilisateur groupé par catégorie
4. Insère en section **Voir aussi** structurée :
   - **Services impliqués** : Postgres, Polars, uv...
   - **Concepts** : RAG, Embeddings...
   - **Patterns** : Pattern - RAG basique...
   - **Outils** : claude-api, anthropic-xlsx...

**Reverse linking** : si le workflow décrit une procédure cross-galaxy, propose d'ajouter `[[<NouveauWorkflow>]]` dans les fiches Services/Concepts/Patterns critiques.

### Étape 7 — Demander validation

Montre :
- Path cible
- Frontmatter
- Section "Procédure" (la plus longue, c'est elle qui doit être actionnable)

"OK pour écrire ?"

### Étape 8 — Écrire

Path : `Wiki/Workflows/<Nom du workflow>.md`. Garde les espaces dans le nom de fichier — c'est lisible et Obsidian les gère bien.

### Étape 9 — Audit post-création + propagation des wikilinks

```bash
# Audit fantomes introduits
powershell -ExecutionPolicy Bypass -File AI/scripts/find-connexes.ps1 -Path "Wiki/Workflows/<nom>.md"

# Propage le wikilink dans les fiches qui mentionnent le workflow en bare
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "<nom-workflow>" -All
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "<nom-workflow>" -All -Apply

# Verification finale
powershell -ExecutionPolicy Bypass -File AI/scripts/report-ghosts.ps1
```

## Anti-patterns à éviter

- **Workflow trop abstrait** — un workflow doit être *exécutable* en suivant les étapes. Si c'est juste de la prose, c'est probablement un concept.
- **Commandes shell non-testées** — préviens si tu as inventé une syntaxe sans la vérifier
- **Pas de Checklist de fin** — sans elle, l'utilisateur ne sait pas s'il a fini
- **Pas de Pièges** — un workflow sans pièges est suspect, demande à l'utilisateur les écueils qu'il a en tête
- **Sortir du périmètre** Wiki/Workflows/

## Format minimal de stub

```yaml
---
nom: <Nom>
type: workflow
categorie: workflow/<famille>
sous_categories: []
domaines: []
duree_estimee: 
prerequis: []
status: stub
created: <today>
modified: <today>
tags: [workflow, stub, <famille-court>]
---

# <Nom>

> **Stub** — à étoffer. Notes brutes : <source / 1 ligne contexte>
```

## Voir aussi

- `add-wiki-concept` (notions vs procédures)
- `add-service` (outils mentionnés dans les workflows)
- `expand-stub` (étoffer un workflow en status: stub)
