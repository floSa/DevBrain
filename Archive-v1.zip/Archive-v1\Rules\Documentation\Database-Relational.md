---
galaxie: dev
type: rule
domaine: documentation
applicable: type-service-database-relational
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, documentation, database, postgres, mysql]
---

# Règle — Documentation Base de données relationnelle

S'applique à : [[Postgres]], [[MySQL]], [[SQLite]], [[CockroachDB]], et toute autre DB relationnelle.

## Principe (1 phrase)
Le `services/<db>/README.md` doit décrire **schéma, migrations, rôle métier** avec assez de détail pour qu'un nouvel arrivant comprenne le modèle de données en 10 minutes.

## MUST

### 1. Schéma relationnel
- Lister les **tables principales** avec leur rôle métier (1-2 lignes par table)
- Documenter les **clés primaires** et **clés étrangères**
- Documenter les **index** non triviaux (autres que ceux auto-générés sur PK/FK)
- Inclure un schéma visuel (Mermaid `erDiagram`) si > 5 tables ou relations complexes

### 2. Migrations
- **Outil de migration** explicité (Alembic, Flyway, Liquibase, etc.)
- Procédure **up** documentée : comment ajouter une nouvelle migration
- Procédure **down** documentée : comment rollback (et les limites — ex: une colonne supprimée n'est pas récupérable)
- Convention de nommage des fichiers de migration
- Politique des migrations destructrices (ex: `DROP COLUMN` interdits sans plan de transition)

### 3. Rôle métier
- Lister explicitement quelles **données résident dans cette DB** : utilisateurs, logs, rôles, configuration applicative, etc.
- Si schéma multi-tenant : documenter la stratégie (schema-per-tenant, row-level security, etc.)
- Mentionner les données qui **ne sont pas** ici (ex: "les fichiers binaires vont dans MinIO, voir services/minio/")

### 4. Contrat d'interface
- URL de connexion (variable d'env)
- Pool de connexions configuré (taille, timeouts)
- ORM ou driver utilisé (SQLAlchemy, Prisma, sqlx, etc.)

## SHOULD

- **Volumétrie attendue** par table (ordre de grandeur)
- **Stratégie de backup** (fréquence, rétention, restore tested)
- **Index futurs identifiés** (à créer quand la volumétrie le justifiera)
- **Politique de soft delete** (colonne `deleted_at` vs hard delete)
- **Audit trail** : quelles modifs sont tracées et où

## NICE

- Schéma exporté (`pg_dump --schema-only` versionné)
- Diagramme ER auto-généré (DBeaver, dbml, etc.)
- Métriques de performance baseline

## Pièges spécifiques à anticiper (lien vers REX)

- Postgres : `max_connections` × workers × pool_size — voir [[REX - Postgres]]
- MySQL : `utf8` ≠ `utf8mb4` (encodage)
- Migrations sur grosses tables : `CONCURRENTLY` (PG) / `online DDL` (MySQL) obligatoires

## Voir aussi

- Template : `Templates/ServiceDocs/README - database-relational.md`
- [[README - Service]] — règle parente
- [[Postgres]], [[MySQL]], [[SQLite]] — fiches Services
- [[Alembic]] — outil de migration recommandé pour Postgres + SQLAlchemy
