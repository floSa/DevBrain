---
galaxie: dev
nom: LiteLLM
alias: [litellm]
categorie: llm/framework
sous_categories: [proxy, multi-llm, gateway]
licence: MIT
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[OpenAI API]]", portkey, OpenRouter]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, llm, proxy, gateway]
url_officiel: https://www.litellm.ai/
url_docs: https://docs.litellm.ai/
url_repo: https://github.com/BerriAI/litellm
---

# LiteLLM

## Pourquoi

Proxy/gateway qui **uniformise l'appel à 100+ LLM** (Anthropic, OpenAI, Google, Cohere, Bedrock, Azure, locaux via Ollama, etc.) derrière une seule API : le format OpenAI. Tu écris ton code une fois, tu changes de modèle/provider via un flag.

Bonus : logging, retry, fallback automatique, cost tracking, rate limiting, cache. C'est la **brique infra LLM** dans un système multi-provider.

## Quand l'utiliser

- App qui doit supporter plusieurs providers LLM (fallback, A/B, contrats clients)
- Centralisation du logging/cost tracking en un seul point
- Tu veux tester rapidement différents modèles sans changer ton code
- Déployer un *proxy gateway* devant ton équipe pour partager une clé API et tracker les coûts

## Quand NE PAS l'utiliser

- App mono-provider et simple → utilise le SDK natif ([[Anthropic Claude API]] ou OpenAI direct) — moins de couches
- Latence ultra-critique → chaque hop ajoute des ms
- Tu utilises déjà un framework LLM complet (LangChain, etc.) qui fait la même abstraction

## Pièges connus

- Le format OpenAI ne capture pas toutes les features avancées des autres providers (ex. Claude prompt caching, message ordering strict)
- Les coûts cumulés peuvent dériver si tu n'agresses pas le rate limiting
- Le proxy hébergé peut devenir un SPOF — prévoir de pouvoir le bypass

## Liens

- Doc officielle : https://docs.litellm.ai/
- Repo : https://github.com/BerriAI/litellm
- [[Anthropic Claude API]]
