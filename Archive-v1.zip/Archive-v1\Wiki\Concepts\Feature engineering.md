---
galaxie: wiki
nom: Feature engineering
alias: [feature engineering, feature transformation, encoding, scaling, binning]
type: concept
categorie: concept/ml
sous_categories: [feature-engineering, preprocessing, ml]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: []
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, feature-engineering, preprocessing]
---

# Feature engineering

## TL;DR

Transformer les **variables brutes** en **features modèle-friendly**. Reste **le levier #1 de performance** sur données tabulaires (Kaggle, M5, banque, assurance), même à l'ère du deep learning. Familles : **encoding catégoriel** (one-hot, target, frequency), **scaling/normalization** (StandardScaler, MinMax, RobustScaler, Yeo-Johnson), **binning**, **transformations** (log, Box-Cox), **interactions** (×, ratio, polynomiales), **agrégations** (group-by stats), **dates** ([[Time series feature engineering]]), **textuel** (TF-IDF, embeddings), **target encoding** (avec CV pour éviter leak). Tree-based vs linear vs NN ont des **besoins différents** : ne pas tout appliquer aveuglément.

## Le problème

Les modèles **ne voient pas** les données comme nous. Un modèle linéaire ne capture pas $\log(x)$ depuis $x$ ; un réseau de neurones ne sait pas que "lundi" et "mardi" sont voisins ; un arbre de décision ignore la magnitude.

Le **feature engineering** comble ce gap entre représentation brute et ce que le modèle peut exploiter efficacement.

## L'idée

### 1. Encoding variables catégorielles

#### One-Hot Encoding (OHE)

$$ \text{Color} \in \{\text{red, green, blue}\} \to [1, 0, 0], [0, 1, 0], [0, 0, 1] $$

- Standard pour linear, NN
- **Explose en haute cardinalité** (1000+ catégories → 1000 colonnes)
- Drop one category (avoid collinearity) pour LM

#### Label Encoding

Mapping catégorie → integer (red=0, green=1, blue=2).

- ⚠️ **Crée un ordre artificiel** → bad pour linear / NN
- OK pour **tree-based** (LightGBM, XGBoost, RandomForest) qui split sur des bins

#### Frequency / Count Encoding

Remplacer catégorie par sa fréquence dans le train set.

- Compact, marche bien sur haute cardinalité
- Pas de leak si fitté sur train uniquement

#### Target Encoding (Mean Encoding)

Remplacer catégorie par la **moyenne de la cible** pour cette catégorie :

$$ \text{TE}(c) = \frac{1}{|D_c|} \sum_{i \in D_c} y_i $$

- Très puissant sur haute cardinalité
- **Risque énorme de leakage** : si fitté sur tout train → modèle voit "le bon answer"
- Solutions : **CV interne** (out-of-fold encoding), **smoothing** (interpoler vers global mean), **noise injection**
- CatBoost le fait nativement ([[CatBoost]]), `category_encoders` lib

#### Hashing Encoding

$$ h(\text{category}) \mod K \to \text{integer} $$

- Cardinalité fixe quel que soit le nombre de catégories
- Collisions possibles mais marche en pratique
- Standard pour stream / online learning

#### Embeddings (NN)

Apprendre une représentation dense $\mathbb{R}^d$ pour chaque catégorie. Standard en NN / recommendation systems.

### 2. Scaling / Normalization

| Méthode | Formule | Quand |
|---|---|---|
| **StandardScaler** | $(x - \mu) / \sigma$ | linéaires, NN, distance-based |
| **MinMaxScaler** | $(x - \min) / (\max - \min)$ | bounded [0,1], NN, images |
| **RobustScaler** | $(x - Q_2) / (Q_3 - Q_1)$ | présence outliers |
| **MaxAbsScaler** | $x / \max(|x|)$ | sparse data, pas de centrage |
| **Normalizer** | $x / \|x\|_p$ | rowwise (cosine sim) |
| **PowerTransformer (Yeo-Johnson, Box-Cox)** | rendre gaussien | données skewed |
| **QuantileTransformer** | uniformiser via quantiles | extrême robustesse |

**Tree-based n'ont PAS besoin de scaling** : splits sur quantiles, invariant aux transformations monotones.

**Linear, NN, k-NN, SVM, K-means** : scaling obligatoire.

### 3. Transformations non-linéaires

#### Log transform

Pour variables très skewed (revenue, count) :

$$ x' = \log(1 + x) $$

(log1p évite log(0)). Standard pour faire ressembler à gaussien.

#### Box-Cox / Yeo-Johnson

Famille paramétrique : trouve la transformation qui rend la distribution la plus gaussienne. Box-Cox demande positivité, Yeo-Johnson gère les négatifs.

#### Sqrt, reciprocal, squared

Pour curvatures spécifiques. À justifier théoriquement.

#### Binning / Discretization

Continu → catégorie (bins). Pour :
- Linear models : capturer non-linéarités sans tree
- Robustesse aux outliers
- Interprétabilité (scoring credit)

Méthodes : uniform, quantile, k-means clustering, ChiMerge (supervisé).

### 4. Création de features dérivées

#### Interactions

$$ x_{12} = x_1 \cdot x_2 \quad \text{ou} \quad x_{12} = x_1 / x_2 $$

Capture des effets multiplicatifs (revenue × tenure, mass × velocity).

- Linear/LR : doit être explicite
- Tree-based : peut découvrir mais aidé par la création explicite
- NN : peut apprendre

#### Polynomial features

$x, x^2, x^3, x_1 x_2$. Standard pour régression non-linéaire baseline.

#### Ratios

`revenue / customers`, `defects / units_produced`. Souvent plus informatif que les composantes.

#### Aggrégations group-by

Pour chaque entité, calculer stats globales :
- `mean(price | category)`
- `count(orders | user)`
- `std(visits | week)`
- `nunique(products | session)`

Génial sur data tabulaire (Kaggle staples). Lib : `pandas`, `featuretools` (auto-aggregation).

### 5. Datetime features

Voir [[Time series feature engineering]] pour TS. Pour features tabulaires :
- `year`, `month`, `day`, `hour`, `weekday`
- `is_weekend`, `is_holiday`
- `days_since_event`, `time_to_deadline`

### 6. Texte

- **TF-IDF** : `TfidfVectorizer`
- **Counts / Bag of words** : `CountVectorizer`
- **N-grams** : capture les bigrammes (unigram_2)
- **Embeddings** : `sentence-transformers` (cf. [[embeddings]])
- **LLM-based** : embedding via OpenAI/Cohere/Mistral

### 7. Image

- **Pretrained CNN features** : extract from ResNet, ViT (penultimate layer)
- **CLIP features** : text + image alignés
- **Hashing perceptuel** pour dedup

### 8. Géographique

- **Haversine** distance entre coordonnées
- **Géohash** (string court pour aire)
- **Densité de POI** : nb restaurants dans 500m
- **Region encoding** : country/city → target encoding

### Modèle-spécifique

| Modèle | Encoding cat | Scaling | Imputation NaN | Interactions explicites |
|---|---|---|---|---|
| **LR / Logistic** | OHE | obligatoire | obligatoire | utile |
| **k-NN, SVM, K-means** | OHE | obligatoire | obligatoire | utile |
| **Random Forest, XGBoost** | label/freq/target | non | gère NaN (XGBoost) | facultatif |
| **LightGBM** | natif `categorical_feature` | non | gère NaN | facultatif |
| **CatBoost** | natif target encoding | non | gère NaN | facultatif |
| **Neural Network** | embedding | obligatoire | obligatoire | apprend |

### Pipeline sklearn correct

```python
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline

preprocessor = ColumnTransformer([
    ('num', StandardScaler(), numeric_cols),
    ('cat', OneHotEncoder(handle_unknown='ignore'), cat_cols),
])

pipe = Pipeline([
    ('preprocess', preprocessor),
    ('model', LogisticRegression())
])

pipe.fit(X_train, y_train)  # tout fitté sur train uniquement → pas de leak
pipe.score(X_test, y_test)
```

### Best practices

1. **Toujours pipeline** : split → fit pipeline sur train uniquement → transform test (cf. [[Data leakage]])
2. **Domain knowledge** : meilleure feature = celle suggérée par un expert métier
3. **Itérer** : EDA → hypothèse → feature → CV score → décision
4. **Garder simple** : 30 features pertinentes >> 500 features tout-venant
5. **Tree-based en premier** : moins de preprocessing, baseline rapide
6. **Tester l'effet** : permutation importance, feature ablation
7. **Reproducibility** : seed dans target encoding CV
8. **Pas de feature qui leak** : voir [[Data leakage]]
9. **Auto-extraction tsfresh/featuretools** : prototype OK, en prod ça scale mal
10. **Versioning de features** : feature store pour prod (Feast, Tecton)

### Auto-FE tools

- **featuretools** : Deep Feature Synthesis (auto aggregations sur tables relationnelles)
- **tsfresh** : extraction massive pour séries temporelles
- **AutoFeat, OpenFE** : creation de features supervisée
- **LightAutoML, H2O AutoML, AutoGluon** : auto-ml complet incluant FE
- **DataPrep, dabl** : EDA + FE quick wins

## Quand c'est utile

- **Données tabulaires** : reste le levier #1 vs deep learning (M5, Kaggle classics)
- **Compétitions Kaggle** : feature engineering crée le winning margin
- **Banque / Assurance / Credit scoring** : interpretability + regulation → linear + heavy FE
- **Retail forecasting** : lags, calendar, exogenous features
- **Cold start ML** : peu de data → maximizer signal par feature
- **Production ML** : feature store discipline

## Quand ça ne marche pas / pièges

- **Data leakage** via FE : target encoding sans CV, scaling avant split, rolling stats sans shift. Voir [[Data leakage]].
- **Sur-ingénierie** : 500 features dont 480 inutiles → overfit, débogage difficile. Privilégier qualité quantité.
- **OHE explosion** : 10000 catégories × OHE = 10000 cols sparse → mémoire. Préférer target/frequency/hashing.
- **Target encoding sans regularization** : sur catégories rares, mean = vrai label → leak parfait. Smoothing obligatoire.
- **Scaling tree-based** : inutile (mais pas nocif). Just skip.
- **Imputation NaN par mean global** : leak temporel sur TS. Utiliser group / last known value.
- **Encoding incohérent train/test** : nouvelle catégorie en test pas vue en train → erreur. `handle_unknown='ignore'`.
- **Polynomial features sur haute dim** : $d \to d^2$ explosion combinatoire.
- **Auto-FE sans review** : tsfresh sort 800 features non-interprétables → fragile, hard to debug.
- **Feature engineering manuel sur deep learning** : NN peut apprendre lui-même → souvent inutile sauf features très non-triviales.
- **Forget about feature store** : recompute features à chaque batch / serve = inconsistance train/prod.

## Code minimal

```python
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import (
    StandardScaler, MinMaxScaler, RobustScaler, PowerTransformer,
    OneHotEncoder, KBinsDiscretizer
)
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression

# Dataset jouet
df = pd.DataFrame({
    'age': [25, 30, 45, 60, np.nan],
    'income': [30000, 50000, 80000, 120000, 200000],  # skewed
    'city': ['Paris', 'Lyon', 'Paris', 'Marseille', 'Paris'],
    'target': [0, 0, 1, 1, 0]
})

# Numeric pipeline
num_cols = ['age', 'income']
num_transformer = Pipeline([
    ('impute', SimpleImputer(strategy='median')),
    ('log', FunctionTransformer(np.log1p)),  # log transform for income
    ('scale', StandardScaler())
])

# Categorical pipeline
cat_cols = ['city']
cat_transformer = Pipeline([
    ('impute', SimpleImputer(strategy='most_frequent')),
    ('ohe', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer([
    ('num', num_transformer, num_cols),
    ('cat', cat_transformer, cat_cols)
])

pipe = Pipeline([
    ('preprocess', preprocessor),
    ('clf', LogisticRegression())
])

X = df.drop(columns='target')
y = df['target']
pipe.fit(X, y)

# Target encoding avec CV (out-of-fold) pour éviter leak
from category_encoders import TargetEncoder
import category_encoders as ce
te = ce.TargetEncoder(cols=['city'], smoothing=1.0)
X_te = te.fit_transform(X, y)
# Pour leak-safe: utiliser dans pipeline avec CV

# Aggregations group-by
df['user_id'] = [1, 1, 2, 2, 3]
df['orders'] = [3, 5, 1, 2, 4]
df = df.merge(df.groupby('user_id')['orders'].agg(['mean', 'sum', 'count']).reset_index()
                .rename(columns={'mean': 'user_orders_mean', 'sum': 'user_orders_sum',
                                  'count': 'user_orders_count'}),
                on='user_id')

# Polynomial features
from sklearn.preprocessing import PolynomialFeatures
poly = PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)
X_poly = poly.fit_transform(df[['age', 'income']].fillna(0))
print(f"From 2 features to {X_poly.shape[1]} (with interactions)")

# Binning
kbd = KBinsDiscretizer(n_bins=5, encode='ordinal', strategy='quantile')
df['income_bin'] = kbd.fit_transform(df[['income']])

# Yeo-Johnson (gaussianize)
pt = PowerTransformer(method='yeo-johnson')
income_norm = pt.fit_transform(df[['income']])

# Frequency encoding
freq_map = df['city'].value_counts().to_dict()
df['city_freq'] = df['city'].map(freq_map)

# Hashing
from sklearn.feature_extraction import FeatureHasher
hasher = FeatureHasher(n_features=8, input_type='string')
X_hash = hasher.fit_transform(df[['city']].astype(str).values)

# Datetime
df['date'] = pd.date_range('2024-01-01', periods=5)
df['dow'] = df['date'].dt.dayofweek
df['month'] = df['date'].dt.month
df['is_weekend'] = (df['dow'] >= 5).astype(int)

# Cycliques
df['dow_sin'] = np.sin(2 * np.pi * df['dow'] / 7)
df['dow_cos'] = np.cos(2 * np.pi * df['dow'] / 7)
```

## Pour aller plus loin

- Kuhn & Johnson, *Feature Engineering and Selection* (CRC 2019) — bible
- Zheng & Casari, *Feature Engineering for Machine Learning* (O'Reilly 2018)
- *Kaggle Master's notebooks* (Bojan Tunguz, Abhishek Thakur, etc.) — best in class FE examples
- *featuretools*, *tsfresh*, *category_encoders* docs
- **Liens internes** : [[Time series feature engineering]], [[Data leakage]], [[Missing data]], [[Regularization]], [[Imbalanced classification]]
