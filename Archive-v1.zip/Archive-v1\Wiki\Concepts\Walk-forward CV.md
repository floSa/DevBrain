---
galaxie: wiki
nom: Walk-forward CV
alias: [Walk-forward validation, Time series cross-validation, Rolling-origin evaluation]
type: concept
categorie: concept/time-series
sous_categories: [cross-validation, backtest, forecasting, time-series]
domaines: [data-science, ml-eng, mlops]
maturite: established
auteurs_cles: [Tashman 2000, Hyndman]
lecture_min: 8
created: 2026-05-19
modified: 2026-05-19
tags: [concept, time-series, cv, validation]
---

# Walk-forward CV — Validation croisée pour séries temporelles

## TL;DR

KFold standard **leak les données du futur** dans l'entraînement → résultats trop optimistes sur séries temporelles. La **walk-forward CV** simule un usage réel : entraîner uniquement sur le passé, prédire le futur, **avancer le curseur temporel**, recommencer. Deux variantes : **expanding** (fenêtre qui grandit) vs **sliding** (fenêtre qui glisse).

## Le problème

Avec KFold "naïf" sur une série temporelle :

```
[1 2 3 4 5 6 7 8 9 10]   ← données ordonnées dans le temps
   train       test
[1 2 3   6 7 8 9 10]    [4 5]        ← fold 1
```

Le modèle est entraîné sur des points **postérieurs** au test (6, 7, 8, 9, 10) → il "connaît" le futur. C'est du **data leakage temporel**. Les scores obtenus sont trop bons, ne reflètent pas la performance réelle en production.

## L'idée

### Walk-forward expanding (origin croissant)

```
Étape 1 : train = [1, 2, 3, 4, 5]                test = [6]
Étape 2 : train = [1, 2, 3, 4, 5, 6]             test = [7]
Étape 3 : train = [1, 2, 3, 4, 5, 6, 7]          test = [8]
...
```

Chaque "origine" $T$ : entraîner sur $X_{1..T}$, prédire $X_{T+1..T+h}$ (horizon $h$). Avancer $T$.

Avantages :
- Toujours utilise toutes les données passées (plus d'info)
- Stable
- Simule un système de production qui ré-entraîne périodiquement

### Walk-forward sliding (fenêtre fixe)

```
Étape 1 : train = [1, 2, 3, 4, 5]   test = [6]
Étape 2 : train = [2, 3, 4, 5, 6]   test = [7]
Étape 3 : train = [3, 4, 5, 6, 7]   test = [8]
...
```

Fenêtre d'entraînement de taille fixe qui glisse. Préféré si :
- Stationnarité douteuse (les vieilles données ne valent plus rien)
- Concept drift attendu
- Modèle qui apprend rapidement, pas besoin d'historique long

### Variantes pratiques

- **Horizon** : prédire $h=1$ point ou $h=K$ points à chaque étape (multi-step)
- **Pas** : avancer de 1 point ou de $\Delta$ points entre deux validations (gain temps si $\Delta>1$)
- **Validation interne** : un sub-split du train pour tuner les hyperparams sans toucher le test

### Métriques

Une métrique par étape, puis on agrège (moyenne, médiane, voire distribution complète).

Métriques classiques :
- **MAE** : $\frac{1}{n} \sum |y - \hat y|$ — robuste, échelle de la série
- **RMSE** : $\sqrt{\frac{1}{n} \sum (y - \hat y)^2}$ — pénalise les gros écarts
- **MAPE** : $\frac{1}{n} \sum |y - \hat y| / |y|$ — % d'erreur, **inutile** si $y$ peut être 0
- **MASE** (Mean Absolute Scaled Error) : MAE divisé par MAE d'une baseline naïve → **lecture absolue** ($<1$ = mieux que naïve, $>1$ = pire)
- **sMAPE** : variante symétrique de MAPE, mais critiqué (asymétrie résiduelle)

## Quand c'est utile

- **Tout modèle de forecasting** — sans exception
- Comparer des modèles concurrents (statsmodels ARIMA vs LightGBM vs Prophet) de manière équitable
- Calibrer la fréquence de ré-entraînement en prod (cf. MLOps)
- Détecter des dégradations (le score augmente avec le temps → concept drift)

## Quand ça ne marche pas / pièges

- **KFold quand même** → leakage massif, résultats faux. Ne **jamais** sur TS.
- **Train trop court** au début → modèles instables pour les premières origines. Soit on jette ces fold-là, soit on commence plus tard.
- **Horizon multiple** (multi-step) : attention au framing (cf. [[Forecasting framing]])
- **Holiday/event leakage** : si on a une feature "fériés", il ne faut PAS la calculer avec la connaissance du futur
- **MAPE sur série avec zéros** : explose. Utiliser MASE ou MAE.
- **Une seule origine d'évaluation** (holdout simple) : pas assez robuste. Toujours plusieurs origines.

## Code minimal

```python
import pandas as pd
from sklearn.metrics import mean_absolute_error

ts = pd.Series(..., index=pd.date_range('2020', periods=100, freq='D'))

n_train_init = 30
horizon = 7

results = []
for origin in range(n_train_init, len(ts) - horizon):
    train = ts.iloc[:origin]
    test = ts.iloc[origin:origin + horizon]
    
    model = fit_model(train)              # ARIMA, Prophet, ML...
    forecast = model.predict(horizon)
    
    mae = mean_absolute_error(test, forecast)
    results.append({'origin': origin, 'mae': mae})

import pandas as pd
df = pd.DataFrame(results)
print(df['mae'].mean(), df['mae'].std())
```

Avec [[statsforecast]] ou [[darts]], c'est automatisé.

## Implémentations concrètes

- `sklearn.model_selection.TimeSeriesSplit` — version expanding basique
- `statsforecast` — `cross_validation()` natif, ultra-rapide
- `darts` — `backtest()` et `historical_forecasts()`
- Manuel : boucle for + slicing pandas (5 lignes, contrôle total)

## Pour aller plus loin

- Tashman, *Out-of-sample tests of forecasting accuracy: an analysis and review* (2000) — paper fondateur
- Hyndman, *Forecasting: Principles and Practice* (FPP3) — chap. cross-validation pour TS
- **Liens internes** : [[Stationarity]], [[Autocorrelation]], [[Forecasting framing]], [[Evaluer un systeme LLM]] (parallèles eval LLM / eval TS)
