---
galaxie: wiki
nom: Time series feature engineering
alias: [TS features, lag features, rolling stats, tsfresh, calendar features]
type: concept
categorie: concept/time-series
sous_categories: [feature-engineering, time-series, ml]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: []
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, time-series, feature-engineering, ml]
---

# Time series feature engineering

## TL;DR

Transformer une série temporelle en **features tabulaires** exploitables par des modèles ML (XGBoost, LightGBM, neural nets non-récurrents). Familles : **lags** (y_{t-1}, y_{t-7}…), **rolling statistics** (mean, std, min, max sur fenêtre), **calendaires** (jour de semaine, mois, holidays), **différences/ratios** (Δ, log-return, % change), **Fourier / trig** (cos/sin pour saisonnalité), **lag de variables exogènes** (météo, prix). Standard avant LightGBM/XGBoost pour forecast (M5 winners, Kaggle TS competitions). Bibliothèques : `tsfresh`, `featuretools`, `tsfeatures`, `mlforecast`. **Attention aux fuites** (data leakage) : toujours fenêtre passée stricte.

## Le problème

Les modèles ML (XGBoost, LightGBM, MLP) ne savent pas traiter une séquence brute — ils attendent un **tabular dataset**. Comment encoder l'**information temporelle** ($y_{t-1}$, saisonnalité, tendance) sans recourir aux modèles autoreg classiques (ARIMA, RNN) ?

C'est ce qui a fait gagner les **competitions Kaggle** et **M5** : LightGBM + features ingénieuses surpasse souvent les modèles deep learning.

## L'idée

### 1. Lag features

$$ y_{t-1}, y_{t-2}, y_{t-7}, y_{t-14}, y_{t-365}, \dots $$

- Lag 1 = persistence (très prédictive en TS)
- Lag 7 = même jour semaine précédente (weekly seasonality)
- Lag 365 = même jour année précédente (annual)

**Choix des lags** : guidé par ACF/PACF ([[Autocorrelation]]) et la saisonnalité.

**Important pour multi-step forecasts** : choisir l'**horizon de prédiction** $h$ dicte les lags utilisables. Pour forecast h=7, on ne peut pas utiliser y_{t-1} (pas connue), mais y_{t-7} et plus ok. Voir [[Forecasting framing]] (direct vs recursive).

### 2. Rolling statistics

Sur fenêtre glissante de taille $w$ :

| Statistique | Formule | Capture |
|---|---|---|
| `rolling_mean` | $\bar y$ sur fenêtre | tendance locale |
| `rolling_std` | $\sigma$ | volatilité locale |
| `rolling_min, max` | min, max | range |
| `rolling_median` | médiane | robust to outliers |
| `rolling_q25, q75` | quantiles | distribution shape |
| `rolling_skew, kurt` | skewness, kurtosis | shape distribution |
| `rolling_sum` | sum | count d'événements |

Choix de $w$ : 7, 14, 30, 90, 365 (selon données journalières / horaires). Plusieurs $w$ en parallèle.

### 3. Expanding statistics

Statistiques sur tout l'historique jusqu'à $t-1$ (pas de fenêtre fixe). Capture tendance long-terme.

### 4. Calendar features

| Feature | Utilité |
|---|---|
| `day_of_week` (0-6) | weekly seasonality |
| `day_of_month` (1-31) | monthly patterns |
| `month` (1-12) | annual seasonality |
| `quarter` (1-4) | seasonal effects |
| `week_of_year` (1-52) | annual cycle |
| `is_weekend` | binary |
| `is_holiday` (par pays) | jours fériés (besoin lib `holidays`) |
| `days_since_holiday` | distance au prochain/dernier férié |
| `is_month_start, is_month_end` | effets de fin de mois |
| `business_day` (count) | jours ouvrés du mois |

**Encoding** : pour features cycliques (month, day_of_week), utiliser **sin/cos** :

$$ x_{\sin} = \sin(2 \pi \cdot t / T), \quad x_{\cos} = \cos(2 \pi \cdot t / T) $$

Permet de capturer la cyclicité (décembre proche de janvier dans l'espace transformé).

### 5. Différences et ratios

| Feature | Formule | Capture |
|---|---|---|
| `diff_1` | $y_t - y_{t-1}$ | accroissement |
| `pct_change` | $\frac{y_t - y_{t-1}}{y_{t-1}}$ | % growth |
| `log_return` | $\log(y_t / y_{t-1})$ | finance standard |
| `seasonal_diff` | $y_t - y_{t-m}$ | saisonnier diff |
| `ratio_to_lag` | $y_t / y_{t-7}$ | ratio à same-DOW |

Utile pour détecter accélérations / décélérations.

### 6. Fourier features

Pour multi-saisonnalité (jour de semaine + annuel + lunaire) :

$$ \sum_{k=1}^K \left[ a_k \sin\left(\frac{2 \pi k t}{T}\right) + b_k \cos\left(\frac{2 \pi k t}{T}\right) \right] $$

avec $T$ = période, $K$ = nb d'harmoniques. Standard chez Prophet, et permet à LightGBM de capturer saisonnalités complexes.

### 7. Lag de variables exogènes

$$ X^{(j)}_{t-1}, X^{(j)}_{t-7}, \text{rolling stats}(X^{(j)}) $$

Critical pour régression sur covariables (météo, prix concurrents, promo).

### 8. Trend features

- **Time index** $t$ : capture tendance linéaire
- **Polynômes** $t^2, t^3$ : tendance non-linéaire (avec parcimonie)
- **Régression locale (LOESS)** sur fenêtre
- **STL trend** comme feature

### 9. Auto-extraction : tsfresh, featuretools

**tsfresh** : extrait **800+ features** automatiquement (statistiques, signal processing, distributions, …). Puis filtre par significance test (Benjamini-Hochberg). Standard mais lourd.

**featuretools** : Deep Feature Synthesis, génération automatique pour relational + TS.

**tsfeatures** (Hyndman, R/Python) : features pour caractériser des séries (entropy, trend strength, seasonal strength, lumpiness, …). Standard pour **forecasting model selection**.

### 10. Domain-specific

- **Retail** : event flags (sales, Black Friday), product attributes, promo intensity
- **Energy** : temperature features (HDD, CDD = heating/cooling degree days)
- **Finance** : technical indicators (RSI, MACD, Bollinger bands)
- **Web traffic** : referrer, device, geo
- **Marketing** : ad spend, channel mix

### Pipeline typique pour ML forecast

```
Raw TS y_t
   ↓
[Calendar features] → day_of_week, month, is_holiday
[Lag features]      → lag_1, lag_7, lag_30, lag_365
[Rolling stats]     → rolling_mean_7, rolling_std_30, ...
[Exogenous lags]    → temp_lag_1, price_lag_7, ...
[Fourier]           → sin_yearly, cos_yearly, sin_weekly, ...
   ↓
Tabular X_t
   ↓
LightGBM / XGBoost / CatBoost → ŷ_{t+h}
```

### Best practices

1. **Strict temporal split** : test set strictement après train. Pas de KFold (cf. [[Walk-forward CV]])
2. **Pas de leak** : tous les `rolling` doivent utiliser **uniquement le passé** (rolling(w).mean().shift(1))
3. **Lag minimal = horizon** : pour forecast h=7, ne pas utiliser y_{t-1} car non disponible
4. **Plusieurs windows** : 3, 7, 14, 28, 91, 365 — laisse le model choisir
5. **Cycliques en sin/cos** plutôt qu'integers (sauf si tree-based model qui gère bins)
6. **Tree-based** (LightGBM/XGBoost) excelle avec ces features. NN demandent normalization.
7. **Évaluer la feature importance** + permutation importance pour pruner
8. **Auto-extraction (tsfresh)** : pratique au prototype, mais features non-interprétables et coûteux à reprod en prod
9. **Multi-series feature** : feature globale (moyenne par groupe / SKU)

## Quand c'est utile

- **Forecast avec ML (XGBoost/LightGBM/CatBoost)** : meilleure performance qu'ARIMA en présence de covariables
- **Kaggle / M5 / M6 competitions** : standard winning approach
- **Production simple** : pipeline sklearn-compatible, facile à déployer
- **Avec covariables exogènes** : ML > méthodes statistiques classiques
- **Multi-series** (retail SKU) : transfer learning entre séries via features
- **Beaucoup de séries** : mlforecast (Nixtla) industrialise tout
- **Anomaly detection** : features pour IsolationForest

## Quand ça ne marche pas / pièges

- **Data leakage** : feature de rolling_mean(7) sans `.shift(1)` → inclut $y_t$ dans la moyenne → leak. Vérifier en backtest.
- **Lag impossible** : forecaster h=7 avec y_{t-1} comme feature → inutilisable en prod (la valeur n'existe pas)
- **Trop de features** : XGBoost overfit. Filtrer par importance, permutation importance.
- **Cold start** : nouvelle série → pas d'historique pour lags. Imputer avec mean global ou utiliser meta-features.
- **Non-stationnarité** : si tendance forte, ML peut extrapoler mal. Travailler sur différences ou log.
- **Saisonnalité non-couverte** : pas de feature lag_365 sur série annuelle → modèle louper saisonnalité. Toujours mettre des lags à toutes les saisonnalités.
- **Tree-based ne extrapole pas** : LightGBM ne peut pas prédire hors range de train. Sur tendance croissante, sera systématiquement biaisé bas. Solution : différencier, ou utiliser GBM avec slope correction.
- **Features auto-extraits sans review** : tsfresh peut sortir des features absurdes (FFT components, etc.) qui ne s'expliquent pas → fragile en prod.
- **Encoding catégoriel par mois** : utiliser one-hot ou cyclique sin/cos, pas integer naïf (treat as categorical for tree, sin/cos for NN)

## Code minimal

```python
import numpy as np
import pandas as pd

# Setup : série journalière 2 ans
dates = pd.date_range('2023-01-01', '2025-01-01', freq='D')
y = 100 + np.sin(2 * np.pi * np.arange(len(dates)) / 365) * 30 + np.random.randn(len(dates)) * 5
df = pd.DataFrame({'date': dates, 'y': y})

# 1. Calendar features
df['day_of_week'] = df['date'].dt.dayofweek
df['day_of_month'] = df['date'].dt.day
df['month'] = df['date'].dt.month
df['quarter'] = df['date'].dt.quarter
df['week_of_year'] = df['date'].dt.isocalendar().week
df['is_weekend'] = (df['day_of_week'] >= 5).astype(int)
df['is_month_start'] = df['date'].dt.is_month_start.astype(int)

# Holidays (lib `holidays`)
import holidays
fr = holidays.France()
df['is_holiday'] = df['date'].apply(lambda x: x in fr).astype(int)

# 2. Cyclical encoding
df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
df['dow_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
df['dow_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)

# 3. Lag features (CRITICAL: .shift to éviter leak)
for lag in [1, 7, 14, 30, 365]:
    df[f'lag_{lag}'] = df['y'].shift(lag)

# 4. Rolling statistics (TOUJOURS shift(1) après rolling pour éviter leak)
for w in [7, 14, 30, 90]:
    df[f'roll_mean_{w}'] = df['y'].shift(1).rolling(w).mean()
    df[f'roll_std_{w}'] = df['y'].shift(1).rolling(w).std()
    df[f'roll_min_{w}'] = df['y'].shift(1).rolling(w).min()
    df[f'roll_max_{w}'] = df['y'].shift(1).rolling(w).max()

# 5. Differences
df['diff_1'] = df['y'].diff(1)
df['diff_7'] = df['y'].diff(7)
df['pct_change'] = df['y'].pct_change(1)
df['seasonal_diff'] = df['y'] - df['y'].shift(7)

# 6. Fourier features (saisonnalité multi)
for k in [1, 2, 3]:  # 3 harmoniques annuelles
    df[f'fourier_yearly_sin_{k}'] = np.sin(2 * np.pi * k * np.arange(len(df)) / 365.25)
    df[f'fourier_yearly_cos_{k}'] = np.cos(2 * np.pi * k * np.arange(len(df)) / 365.25)

# Cleanup et split temporel
df = df.dropna()
split = int(len(df) * 0.8)
train, test = df.iloc[:split], df.iloc[split:]

X_cols = [c for c in df.columns if c not in ('date', 'y')]
X_train, y_train = train[X_cols], train['y']
X_test, y_test = test[X_cols], test['y']

# 7. LightGBM forecast
from lightgbm import LGBMRegressor
model = LGBMRegressor(n_estimators=500, learning_rate=0.05)
model.fit(X_train, y_train, eval_set=[(X_test, y_test)], callbacks=[])
preds = model.predict(X_test)

mae = np.mean(np.abs(y_test - preds))
print(f"MAE = {mae:.2f}")

# Feature importance
importance = pd.DataFrame({'feature': X_cols, 'importance': model.feature_importances_})
importance = importance.sort_values('importance', ascending=False).head(15)
print(importance)

# 8. mlforecast (Nixtla) pour faire ça à l'échelle
from mlforecast import MLForecast
from mlforecast.lag_transforms import RollingMean, ExpandingMean
from mlforecast.target_transforms import Differences

df2 = pd.DataFrame({'unique_id': 'serie1', 'ds': dates, 'y': y})
fcst = MLForecast(
    models={'lgb': LGBMRegressor()},
    freq='D',
    lags=[1, 7, 14, 30, 365],
    lag_transforms={
        1: [RollingMean(window_size=7), RollingMean(window_size=30)],
    },
    date_features=['dayofweek', 'month', 'quarter'],
    target_transforms=[Differences([1])],
)
fcst.fit(df2)
forecast = fcst.predict(h=30)

# 9. tsfresh (auto-extraction massive)
# from tsfresh import extract_features
# from tsfresh.feature_extraction import EfficientFCParameters
# features = extract_features(df_long, column_id='id', column_sort='time',
#                              default_fc_parameters=EfficientFCParameters())
```

## Pour aller plus loin

- Kaggle M5 competition winners — feature engineering détaillé
- tsfresh docs — *Time Series Feature extraction*
- Hyndman & Athanasopoulos, *Forecasting: Principles and Practice* (3e éd.) — chap. 7
- *mlforecast* (Nixtla) — best-in-class library pour forecasting ML scale
- Bontempi, Ben Taieb, Le Borgne, *Machine Learning Strategies for Time Series Forecasting* (2013)
- **Liens internes** : [[ARIMA SARIMA]], [[Forecasting framing]], [[Forecasting metrics]], [[Walk-forward CV]], [[Autocorrelation]], [[Stationarity]], [[Feature engineering]]
