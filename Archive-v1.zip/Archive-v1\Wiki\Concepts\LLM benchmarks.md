---
galaxie: wiki
nom: LLM benchmarks
alias: [MMLU, BBH, GPQA, IFEval, HellaSwag, AlpacaEval, Arena Hard]
type: concept
categorie: concept/llm-eval
sous_categories: [benchmarks, eval, llm, general]
domaines: [ai-eng]
maturite: established
auteurs_cles: []
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, eval, benchmarks]
---

# LLM benchmarks (généraux)

## TL;DR

Benchmarks standards pour évaluer les LLMs sur **knowledge, reasoning, instructions, long context, chat**. Hiérarchie de difficulté (2026) : **MMLU** (saturé, ~92%), **MMLU-Pro** (active), **BBH** (Big-Bench Hard), **GPQA Diamond** (PhD-level science), **HLE** (Humanity's Last Exam, hardest), **ARC-AGI** (Chollet, abstraction). **Reasoning** : AIME, MATH, GSM8K. **Instructions** : IFEval, FollowBench. **Chat** : LMSYS Arena (Elo), MT-Bench, AlpacaEval, Arena Hard. Standard 2026 : **MMLU-Pro + GPQA + IFEval + AIME + MMLU + Arena** = battery basique. Attention : **contamination** (benchmark dans training set), **gaming** (overfitting), **saturation** (90%+ = no signal).

## Le problème

Comment **comparer** des LLMs ? Subjectif (tone, helpfulness) ET objectif (math, code, knowledge).

→ Standards measurable, repeatable, comparable.

## L'idée

### Knowledge / general

#### MMLU (Hendrycks 2020)

Massive Multitask Language Understanding. 57 subjects (STEM, humanities, professional). Multiple-choice.

- **State 2026** : saturé. Claude Sonnet ~92%, GPT-4o ~89%
- Standard pour ranking sur knowledge breadth
- Mais : facile à contaminer (questions sur internet)

#### MMLU-Pro (Wang 2024)

Harder MMLU : 10 choix au lieu de 4, plus reasoning required.

- **Active** : ~75% top models
- Standard recent

#### MMLU-Redux

Cleaned version (fewer broken questions).

#### Big-Bench Hard (BBH, Suzgun 2022)

23 tâches difficiles de BIG-Bench. Reasoning chain required.

#### HellaSwag

Common sense reasoning, NLI-style.

#### ARC (Easy / Challenge)

Science questions, Allen AI.

#### WinoGrande

Coreference resolution, common sense.

#### TruthfulQA

Truthfulness sur misleading questions.

#### GPQA (Rein 2023)

Graduate-level google-proof questions (PhD-level biology, chemistry, physics).

- **GPQA Diamond** : 198 hardest
- **State 2026** : ~70-80% top models
- Standard pour frontier

#### Humanity's Last Exam (HLE, 2024)

3000 expert-level questions across all fields. Designed to last.

- **Active** : top models ~10-15%

#### ARC-AGI (Chollet)

Abstract reasoning, IQ-style. Designed as fluid intelligence test.

- **Active** : modèles strugglent encore

### Reasoning / Math

#### GSM8K (Cobbe 2021)

Grade-school math word problems.

- **Saturé** : top models >95%

#### MATH (Hendrycks 2021)

Compétition math (algebra, geometry, calculus, etc.).

- **Active** : ~70-85% top models

#### AIME (2024, 2025)

American Invitational Mathematics Examination. Hard high school olympiad.

- Standard pour reasoning models (o1, R1)

#### AMC

American Math Competition.

#### Olympiad benchmarks

IMO (International Math Olympiad), PutnamBench, FrontierMath (hardest).

#### TheoremQA, ProofNet, minif2f

Theorem-proving.

### Code

#### HumanEval (Chen 2021), HumanEval+

Function completion from docstrings.

- **Saturé** : top models ~90%

#### MBPP, MBPP+

Mostly Basic Python Problems.

#### BigCodeBench

Function-level coding, more realistic.

#### LiveCodeBench

Recent problems (anti-contamination).

#### SWE-Bench

Real GitHub issues. Voir [[Agent evaluation]].

#### Aider polyglot benchmark

Multi-language code edits.

#### CodeContests

Competitive programming.

#### CRUX-Eval

Code understanding (predict input / output).

### Instructions following

#### IFEval (Zhou 2023)

Verifiable instructions ("write exactly 3 sentences", "no commas").

- Standard pour chat models alignment

#### FollowBench

Multi-aspect constraints.

### Long context

Voir aussi [[Context engineering]].

#### Needle in a Haystack (NIAH)

Embed fact dans long doc, retrieve.

#### RULER

Multi-needle, retrieval, aggregation.

#### LongBench v1, v2

Multi-task long context.

#### InfiniteBench

Très long context.

#### BABILong

Synthetic long-context reasoning.

### Chat / Human preference

#### LMSYS Chatbot Arena

**Crowdsourced Elo** : users compare 2 random models blind, vote.

- **Real human preference**
- Top ranking : Claude, GPT, Gemini frontier
- Standard de facto pour "good chat"

#### MT-Bench

Multi-Turn conversations, GPT-4 judge.

#### AlpacaEval v1, v2

Comparaison vs reference (text-davinci-003). v2 = length-controlled.

#### Arena Hard / ArenaHard-Auto

Hard subset, LLM judge.

#### WildBench

Real user queries from WildChat.

### Multilingue

- **MGSM** : Multilingual GSM (math)
- **XNLI** : NLI multilangues
- **XCOPA** : commonsense multilangue
- **Flores** : traduction
- **MMLU multilangue**
- **Belebele** : reading comprehension multilangue
- **Global-MMLU** : MMLU étendu

### Multimodal (Vision)

Voir [[Vision Language Models]] :
- MMMU, MMMU-Pro
- MMBench, SEED-Bench
- MathVista
- DocVQA, ChartQA, AI2D, OCRBench
- POPE, HallusionBench
- MM-Vet, LLaVA-Bench

### Safety

- HarmBench
- AdvBench
- ToxicChat
- BeaverTails
- DoNotAnswer
- XSTest
- TrustLLM

### Standard battery (2026)

Pour évaluer un nouveau LLM :

```
Knowledge   : MMLU-Pro, GPQA Diamond
Reasoning   : BBH, AIME, MATH
Code        : HumanEval+, MBPP+, LiveCodeBench, BigCodeBench
Instruction : IFEval, MT-Bench
Long context: RULER, NIAH multi-needle
Chat        : Arena (Elo), Arena Hard
Multilingue : MGSM
Safety      : HarmBench
Multimodal  : MMMU-Pro, MathVista
```

### Pièges

#### Contamination

Benchmark dans training data → score gonflé. Tests :
- **LiveCodeBench** : problems après cutoff
- **Tests private** (Scale, Anthropic internal)

#### Saturation

90%+ = no signal différentiateur. Move to harder benchmark.

#### Gaming

Fine-tune sur eval style → high score, generalize mal.

#### Benchmark drift

Recent papers train on benchmark style → biased.

#### Single bench misleading

Modèle good MMLU bad code, ou inverse. Toujours **multi-bench**.

### Outils

#### lm-evaluation-harness (EleutherAI)

Open-source. Standard pour eval HuggingFace models.

#### OpenAI Evals

OpenAI-compatible.

#### HELM (Stanford)

Holistic Evaluation : comprehensive.

#### BIG-Bench

Original "Beyond the Imitation Game".

#### Inspect AI (UK AISI)

Modern eval framework.

#### LMSYS Arena code

Open.

### Best practices

1. **Multi-bench** : never single metric
2. **Match use case** : code app ? Focus HumanEval, SWE-Bench
3. **Live benchmarks** quand possible (anti-contamination)
4. **Track over time** : new models, new benchmarks
5. **Eval custom** : your specific tasks > public bench
6. **Don't train on benchmarks** : ridiculous and contaminating
7. **Compare iso-conditions** : same prompts, same temperature
8. **Compute cost too** : tokens, latency, $$$
9. **Watch saturation** : 90%+ → move on
10. **Don't trust marketing** : check leaderboards

## Quand c'est utile

- **Model selection** : choose Claude vs GPT vs open
- **Track new models** : Llama 4 vs Claude 4 vs GPT-5
- **Domain-specific** : math heavy → AIME, code heavy → SWE-Bench
- **Compare opensource vs closed** : leaderboards
- **CI/CD model upgrades** : regression suite
- **Research papers** : standard reporting
- **Cost-quality analysis** : find Pareto

## Quand ça ne marche pas / pièges

- **Single number** : misleading
- **Public benchmarks contaminés** : especially older ones
- **Saturated benchmarks** : no signal
- **Gaming** : models trained on bench style
- **Benchmark ≠ use case** : MMLU good, prod bad
- **Static benchmarks** : don't capture new behaviors (agent, multimodal)
- **Cultural / language bias** : EN-centric
- **Multiple choice can be cheesed** : ABCD elimination strategies
- **LLM judge biased** : same family → bias
- **Marketing claims** : "SOTA on X bench" — context matters

## Code minimal

```python
# 1. lm-evaluation-harness (EleutherAI)
# pip install lm-eval

# Eval on multiple benchmarks
# python -m lm_eval --model hf \
#     --model_args pretrained=meta-llama/Meta-Llama-3-8B-Instruct \
#     --tasks mmlu,gsm8k,hellaswag,arc_challenge \
#     --batch_size 8 \
#     --output_path ./results

# 2. EleutherAI lm_eval Python API
from lm_eval import simple_evaluate
results = simple_evaluate(
    model="hf",
    model_args="pretrained=meta-llama/Meta-Llama-3-8B-Instruct",
    tasks=["mmlu", "gsm8k"],
    num_fewshot=5,
)

# 3. Inspect AI
# pip install inspect-ai
# inspect eval mmlu --model anthropic/claude-3-7-sonnet-latest

# 4. OpenAI Evals
# git clone https://github.com/openai/evals
# cd evals
# oaieval gpt-4o.txt my_eval

# 5. Custom benchmark runner
def run_benchmark(model, dataset, n_samples=100):
    results = []
    for example in dataset[:n_samples]:
        prediction = model(example["prompt"])
        correct = check_answer(prediction, example["answer"])
        results.append({"correct": correct, "prediction": prediction})
    accuracy = sum(r["correct"] for r in results) / len(results)
    return {"accuracy": accuracy, "results": results}

# 6. MMLU-style (multiple choice)
def mmlu_query(question, choices):
    prompt = f"""Question: {question}
A) {choices[0]}
B) {choices[1]}
C) {choices[2]}
D) {choices[3]}

Answer:"""
    response = llm(prompt)
    return extract_letter(response)  # A, B, C, or D

# 7. GSM8K (math)
def gsm8k_eval(model):
    correct = 0
    for ex in dataset:
        response = model(ex["question"] + "\n\nLet's think step by step.")
        answer = extract_number(response)
        if answer == ex["answer"]:
            correct += 1
    return correct / len(dataset)

# 8. HumanEval (code)
def humaneval(model):
    passed = 0
    for problem in dataset:
        code = model(problem["prompt"])
        passed += run_tests(code, problem["test"])
    return passed / len(dataset)

# 9. LMSYS Arena (vote your way)
# Sample queries from Arena dataset, generate with N models, judge.
```

## Pour aller plus loin

- *EleutherAI lm-evaluation-harness* (open-source)
- *HELM* (Stanford) holistic eval
- *Inspect AI* (UK AISI)
- *LMSYS Chatbot Arena* leaderboard
- Hendrycks et al., *Measuring Massive Multitask Language Understanding* (MMLU, ICLR 2021)
- Wang et al., *MMLU-Pro: A More Robust and Challenging Multi-Task Language Understanding Benchmark* (NeurIPS 2024)
- Rein et al., *GPQA: A Graduate-Level Google-Proof Q&A Benchmark* (2023)
- Anthropic, OpenAI model cards — always cite benchmarks
- **Liens internes** : [[LLM eval metrics]], [[Agent evaluation]], [[Code and math benchmarks]], [[LLM-as-judge]]
