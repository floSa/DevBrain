---
galaxie: dev
type: rule
domaine: docs
applicable: global
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, docs, readme]
---

# Règle — README.md du projet

## Principe
Le README est la **première impression** et le point de départ pour toute personne (toi dans 6 mois, contributeur, recruteur). Sections fixes, exemples concrets, à jour.

## MUST

- Présence d'un `README.md` à la racine.
- Couvre au minimum : **Quoi** / **Pourquoi** / **Install** / **Usage** / **Tests** / **Licence**.
- Code snippets testés (pas de pseudo-code mensonger).
- Lien vers la licence (pas juste la mentionner).

## SHOULD

- **Badges** en haut : CI status, version, licence, coverage si applicable.
- Section **Architecture** ou lien vers `docs/ARCHITECTURE.md` si non trivial.
- Section **Contributing** ou lien vers `CONTRIBUTING.md` si projet ouvert.
- Captures d'écran / GIF pour les apps avec UI.
- Roadmap ou lien vers les issues si projet vivant.

## NICE-TO-HAVE

- Code de conduite (`CODE_OF_CONDUCT.md`) si projet public communautaire.
- Section **Acknowledgements** / **Inspiration** pour citer les sources.
- Section **Sponsors** ou Patreon si applicable.

## Squelette type

```markdown
# <Nom du projet>

> Une phrase qui dit ce que ça fait et pour qui.

[![CI](badge_url)](ci_url) [![License](badge_url)](LICENSE)

## Quoi
2-3 lignes — la value prop.

## Pourquoi
2-3 lignes — le problème résolu.

## Install
\`\`\`bash
pip install monprojet
# ou
npm install monprojet
\`\`\`

## Usage
\`\`\`python
from monprojet import truc
result = truc(...)
\`\`\`

## Tests
\`\`\`bash
pytest
\`\`\`

## Documentation
Lien vers la doc complète si elle est ailleurs.

## Contributing
Lien vers CONTRIBUTING.md si projet ouvert.

## Licence
[MIT](LICENSE)
```

## Exemples

### Bon
[https://github.com/astral-sh/uv](https://github.com/astral-sh/uv) — README complet, badges, install par OS, exemples de commande.

### Mauvais
- README qui dit juste "TODO" depuis 6 mois.
- README qui contredit le code (commands renommées, deps obsolètes).
- README de 5000 lignes sans table des matières.

## Exceptions

- Pour une lib publiée sur PyPI/npm, le README sert aussi de page de package — soigner particulièrement.
- Pour un script jetable / POC : README minimal accepté (3-4 lignes).

## Voir aussi

- [[Rules/Global/Documentation]] — pour la doc plus profonde
- [[Rules/Types/Library]] — règles spécifiques aux libs publiées
