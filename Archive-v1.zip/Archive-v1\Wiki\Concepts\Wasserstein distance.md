---
galaxie: wiki
nom: Wasserstein distance
alias: [Earth Mover's Distance, EMD, optimal transport, distance de Wasserstein]
type: concept
categorie: concept/info-theory
sous_categories: [wasserstein, optimal-transport, emd, metric]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Monge 1781, Kantorovich 1942, Arjovsky 2017 (WGAN)]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, info-theory, wasserstein, optimal-transport]
---

# Wasserstein distance — Earth Mover's Distance

## TL;DR

Distance entre distributions inspirée du **transport optimal** : combien de "masse de probabilité" faut-il déplacer (et sur quelle distance) pour transformer $p$ en $q$ ? **Vraie métrique**, **gère les supports disjoints**, **gradient stable** même quand $p$ et $q$ ne se chevauchent pas. Fondation des WGANs et de tout le domaine "optimal transport" appliqué au ML.

## Le problème

La [[KL divergence]] et la [[Jensen-Shannon divergence]] ont un défaut quand $p$ et $q$ ont des supports **disjoints ou quasi-disjoints** :

- KL : explose à $+\infty$
- JS : sature à $\log 2$, gradient nul → entraînement de GAN qui plante

Or en pratique, les distributions à comparer sont souvent presque disjointes (modèle génératif au début de l'entraînement, vraie data en haute dim). On veut une distance qui :
- est **bornée** même pour supports disjoints
- a un **gradient informatif** (pas plat) même quand les distributions sont éloignées

## L'idée

### Métaphore de la terre

Imagine $p$ et $q$ comme deux **piles de sable** sur la droite réelle. La distance de Wasserstein = travail minimum pour transformer la pile $p$ en pile $q$, où "travail" = masse × distance déplacée.

```
p :  ▆ . . . . . ▆ .
q :  . ▆ . . . . . ▆

→ déplacer chaque grain de p vers le q le plus proche
→ coût = somme(masse × |distance déplacement|)
```

### Définition formelle

Soit $\Pi(p, q)$ l'ensemble des **plans de transport** : distributions jointes $\gamma$ telles que ses marginales soient $p$ et $q$. La distance de Wasserstein d'ordre $r$ :

$$ W_r(p, q) = \left( \inf_{\gamma \in \Pi(p, q)} \int \|x - y\|^r \, d\gamma(x, y) \right)^{1/r} $$

Cas le plus courant : $r = 1$ (EMD).

### Forme duale (Kantorovich-Rubinstein)

Pour $W_1$, il existe une formulation duale très utile :

$$ W_1(p, q) = \sup_{\|f\|_L \leq 1} \mathbb{E}_{x \sim p}[f(x)] - \mathbb{E}_{x \sim q}[f(x)] $$

où le sup est sur les fonctions 1-Lipschitz. C'est ce que **WGAN** approxime avec un discriminateur (critic).

### Cas 1D — formule fermée

Pour des distributions 1D, $W_1$ a une expression simple :

$$ W_1(p, q) = \int_{-\infty}^{+\infty} |F_p(x) - F_q(x)| \, dx $$

où $F_p$, $F_q$ sont les CDFs. C'est l'aire entre les deux CDFs.

### Wasserstein 2 pour gaussiennes

Pour $p = \mathcal{N}(\mu_1, \Sigma_1)$ et $q = \mathcal{N}(\mu_2, \Sigma_2)$ :

$$ W_2^2(p, q) = \|\mu_1 - \mu_2\|^2 + \text{tr}\left(\Sigma_1 + \Sigma_2 - 2(\Sigma_2^{1/2} \Sigma_1 \Sigma_2^{1/2})^{1/2}\right) $$

Très utilisée en pratique (FID — Fréchet Inception Distance — est en fait $W_2$ sur features Inception).

### Propriétés

- **Vraie métrique** : symétrique, inégalité triangulaire, nulle ssi $p = q$
- **Finie** pour supports disjoints (contrairement à KL)
- **Gradient utile** : continue dans la topologie faible, fournit des gradients informatifs
- **Coût de calcul** : $O(n^3 \log n)$ par programmation linéaire pour le cas général ; $O(n \log n)$ en 1D ; $O(n^2)$ avec Sinkhorn (régularisation entropique)

### Régularisation Sinkhorn

Pour rendre le calcul tractable en haute dim, on ajoute une régularisation entropique :

$$ W_\varepsilon(p, q) = \inf_{\gamma} \int \|x-y\| d\gamma + \varepsilon \cdot H(\gamma) $$

Algorithme : **Sinkhorn-Knopp** ($O(n^2)$ par itération, converge vite). Implémenté dans POT (Python Optimal Transport), géomloss, sinkhorn library.

## Quand c'est utile

- **GANs** : WGAN, WGAN-GP — entraînement plus stable que GAN original (qui utilise JS)
- **Comparaison de générateurs** : FID = $W_2$ sur features (Heusel 2017)
- **Détection de drift** : robuste aux décalages de distribution (vs PSI, KL)
- **Transport optimal** appliqué (color transfer, domain adaptation, alignement embeddings)
- **Sinkhorn loss** pour matching d'embeddings (CLIP-like)
- **Survival analysis**, économétrie, finance

## Quand ça ne marche pas / pièges

- **Coût computationnel** prohibitif sur grandes distributions sans régularisation Sinkhorn
- **Choix de la métrique sous-jacente** $\|x - y\|$ : euclidienne par défaut, mais peut être customisée (impact fort sur le résultat)
- **WGAN-GP** : nécessite gradient penalty pour enforcer la contrainte 1-Lipschitz du critic — sans ça, le WGAN simple sous-performe
- **Confusion W₁ vs W₂** : différentes propriétés, valeurs non-comparables
- **Estimation empirique** sur petit $N$ biaisée (Slice Wasserstein ou debiased Sinkhorn pour mitiger)
- **Curse of dimensionality** : convergence empirique en $n^{-1/d}$ en dimension $d$ → très lente en haute dim

## Code minimal

```python
import numpy as np
from scipy.stats import wasserstein_distance

# 1D — cas simple
p_samples = np.random.normal(0, 1, 1000)
q_samples = np.random.normal(2, 1.5, 1000)
w1 = wasserstein_distance(p_samples, q_samples)
print(f"W1 = {w1:.3f}")

# Avec POT (Python Optimal Transport) — multi-dim
import ot
X_p = np.random.randn(100, 5)  # 100 samples in 5D
X_q = np.random.randn(80, 5)

# Plans de transport
M = ot.dist(X_p, X_q)  # cost matrix (euclidean)
a = np.ones(100) / 100
b = np.ones(80) / 80

# Wasserstein exact (LP, coûteux)
T = ot.emd(a, b, M)
w1 = (T * M).sum()

# Sinkhorn (rapide, régularisé)
T_sinkhorn = ot.sinkhorn(a, b, M, reg=0.1)

# FID-like (Wasserstein 2 entre gaussiennes)
def w2_gaussian(mu1, cov1, mu2, cov2):
    from scipy.linalg import sqrtm
    diff = mu1 - mu2
    covmean = sqrtm(cov1 @ cov2)
    if np.iscomplexobj(covmean):
        covmean = covmean.real
    return diff @ diff + np.trace(cov1 + cov2 - 2 * covmean)
```

## Pour aller plus loin

- Villani, *Optimal Transport: Old and New* (2008) — référence mathématique
- Peyré & Cuturi, *Computational Optimal Transport* (2019) — pratique
- Arjovsky et al., *Wasserstein GAN* (2017) — WGAN
- Cuturi, *Sinkhorn Distances* (2013) — Sinkhorn algorithm
- Lib POT : https://pythonot.github.io/
- **Liens internes** : [[KL divergence]], [[Jensen-Shannon divergence]], [[Shannon entropy]]
