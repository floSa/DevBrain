---
galaxie: dev
nom: Helicone
alias: [helicone]
categorie: llm/observability
sous_categories: [proxy, observability, caching, routing, llm-ops]
licence: Apache-2.0 (Core), Proprietaire (Cloud)
licence_type: open-source
hosted: both
maturite: production
langage: TypeScript
clients_officiels: [via proxy headers, multi-langage]
plateforme: [cloud, docker]
score: 4
mes_projets: []
alternatives: ["[[Langfuse]]", "[[LangSmith]]", Portkey, OpenRouter, LiteLLM]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, observability, proxy, gateway]
url_officiel: https://www.helicone.ai/
url_docs: https://docs.helicone.ai/
url_repo: https://github.com/Helicone/helicone
---

# Helicone

## Pourquoi
**Proxy LLM avec observability intégrée**. Zéro config : tu changes ton `base_url` d'OpenAI/Anthropic/etc. pour passer par Helicone → tracking automatique de tous les calls. Combo unique : observability + caching + routing + rate limits dans un seul layer.

## Quand l'utiliser
- App multi-provider qui veut un seul layer pour tracking + cache + routing
- Pas le luxe d'instrumenter le code (Helicone via base_url change un import)
- Semantic cache out-of-the-box
- Rate limiting cross-provider
- Self-host pour data sensitive

## Quand NE PAS l'utiliser
- Stack LangChain pure → [[LangSmith]] (intégration plus profonde)
- Tracing customisé (chains/agents complexes) → [[Langfuse]] (decorators flexibles)
- Tu veux gérer le routing toi-même → [[LiteLLM]] (lib client-side)
- Latence ultra-critique — proxy ajoute 1 hop

## Pièges connus
- **Proxy = SPOF potentielle** : si Helicone down, tes calls LLM down (mode fallback à configurer)
- **Caching cache pollution** : semantic cache peut servir mauvaise réponse — tuner threshold
- **Pricing volume** : free tier 100k requests/mois, vite saturé en prod
- **Latence proxy** : ~10-50ms ajoutés, négligeable mais pas zéro
- **Self-host** : Postgres + ClickHouse needed, plus complexe que Langfuse self-host
- **OpenAI proxy primarily** : autres providers OK mais OpenAI = best path

## Liens
- [[Langfuse]] / [[LangSmith]] — alternatives observability
- [[LiteLLM]] — alternative router client-side
- Portkey — alternative gateway managed
- [[LLM observability]] / [[Routing and cascading]] / [[LLM caching]] (concepts)
- Docs : https://docs.helicone.ai/
- GitHub : https://github.com/Helicone/helicone
