---
galaxie: dev
nom: darts
alias: [unit8-darts, u8darts]
categorie: ml/framework
sous_categories: [forecasting, time-series, unified-api, statistical, ml, deep-learning]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[statsforecast]]", "[[neuralforecast]]", "[[Prophet]]"]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, time-series, forecasting, unified]
url_officiel: https://unit8co.github.io/darts/
url_docs: https://unit8co.github.io/darts/
url_repo: https://github.com/unit8co/darts
---

# darts

## Pourquoi

Framework forecasting **généraliste et unifié** : une seule API pour tester ARIMA classique, gradient boosting, deep learning. Concept central : `TimeSeries` (wrapper pandas/xarray) commun à tous les modèles. Très **pédagogique**, idéal pour comparer des familles de modèles sans réécrire le code à chaque fois.

Versus Nixtla ([[statsforecast]] + [[neuralforecast]]) : darts est plus **généraliste** (couvre tout dans une seule lib), Nixtla est **plus performant** sur chaque catégorie spécifique (vitesse + état de l'art DL). Choix de stack à faire selon priorité.

## Quand l'utiliser

- Tu **explores** plusieurs familles de modèles (statistical + ML + DL) et veux comparer rapidement
- API homogène souhaitée (un seul `model.fit(ts)` que ce soit ARIMA ou TFT)
- Benchmarks pédagogiques, démos, slides ("voici ce que ça donne avec 5 modèles différents")
- Backtest et cross-validation walk-forward intégrés
- Pipelines avec **transformers de prétraitement** (scaling, BoxCox, missing values)

## Quand NE PAS l'utiliser

- Production hautes perfs sur ARIMA en masse → [[statsforecast]] est ~10× plus rapide
- DL state-of-the-art le plus récent → [[neuralforecast]] embarque les derniers modèles plus vite
- Une seule série avec diagnostic statistique poussé → [[statsmodels]]
- Tu n'as pas envie d'apprendre la classe `TimeSeries` (légère courbe d'apprentissage)

## Pièges connus

- Classe `TimeSeries` au lieu de pandas DataFrame direct → conversion à faire (`TimeSeries.from_dataframe`), source d'erreurs au début
- Documentation parfois en retard sur l'API (jeune projet en évolution)
- Moins **opinionated** que Nixtla — plus de flexibilité = plus de risque de mauvais choix
- Les modèles DL utilisent PyTorch Lightning en sous-couche : les warnings PL peuvent être bruyants

## Liens

- Doc officielle : https://unit8co.github.io/darts/
- Repo : https://github.com/unit8co/darts
- Concepts liés : [[Stationarity]], [[Walk-forward CV]], [[Forecasting framing]]
- Alternatives : [[Prophet]] (simple), [[statsforecast]] (perf statistical), [[neuralforecast]] (perf DL)
