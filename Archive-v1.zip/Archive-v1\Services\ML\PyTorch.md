---
galaxie: dev
nom: PyTorch
alias: [pytorch, torch]
categorie: ml/dl-framework
sous_categories: [deep-learning, tensors, autograd, gpu, training]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python (C++/CUDA core)
clients_officiels: [python, cpp]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: ["[[TensorFlow]]", "[[JAX]]", MLX (Apple)]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, deep-learning, pytorch]
url_officiel: https://pytorch.org/
url_docs: https://pytorch.org/docs/
url_repo: https://github.com/pytorch/pytorch
---

# PyTorch

## Pourquoi
**Framework de deep learning #1** (recherche et prod). Dynamique (eager mode), syntaxe Pythonic, écosystème massif : Hugging Face, vLLM, torchtune, Lightning, FSDP, torch.compile (depuis 2.0). Standard de fait pour entraîner / fine-tuner / inférer des LLMs et autres modèles DL.

## Quand l'utiliser
- Training tout modèle DL (LLM, vision, audio, RL)
- Fine-tuning LLM (HuggingFace transformers + PEFT)
- Inférence avec accélération (torch.compile, FlashAttention)
- Distributed training (DDP, FSDP, DeepSpeed)
- Recherche ML (eager mode pratique pour debug)

## Quand NE PAS l'utiliser
- Apple Silicon optimisé → MLX (mémoire unifiée native)
- TPU pur (Google Cloud) → [[JAX]] (compilation XLA mieux)
- Production embedded → ONNX Runtime, TFLite, ExecuTorch
- Stack TensorFlow legacy → [[TensorFlow]]
- Inférence LLM seule (sans training) → [[vLLM]], TGI

## Pièges connus
- **CUDA versions** : matching torch / CUDA / cuDNN — vérifier `torch.version.cuda` vs driver
- **Memory leaks** : circular refs entre Tensor + tape autograd, attention en boucles
- **DataLoader workers** : `num_workers > 0` peut bloquer en debug (forks Windows pire)
- **Mixed precision** : utiliser `torch.amp.autocast` + `GradScaler` ou bf16
- **DDP vs DP** : DataParallel (DP) est déprécié, utiliser DistributedDataParallel (DDP)
- **torch.compile** : peut planter sur code dynamique. Test en eager d'abord.
- **FSDP vs DeepSpeed ZeRO** : 2 stacks distinctes, choisir et s'y tenir

## Liens
- [[HuggingFace]] — transformers built on PyTorch
- [[Optuna]] — HP tuning souvent combiné
- [[MLflow]] — tracking
- PyTorch Lightning (wrapper) : https://lightning.ai/
- torchtune (LLM fine-tuning) : https://github.com/pytorch/torchtune
- Docs : https://pytorch.org/docs/stable/
