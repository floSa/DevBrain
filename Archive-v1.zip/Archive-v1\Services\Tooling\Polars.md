---
galaxie: dev
nom: Polars
alias: [polars, pl]
categorie: tooling/data
sous_categories: [dataframe, lazy, rust, multi-thread, arrow]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Rust (Python/JS bindings)
clients_officiels: [python, ts, rust]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[pandas]]", "[[DuckDB]]", "[[Modin]]", "[[Dask]]"]
remplace: ["[[pandas]]"]
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, tooling, data, dataframe, rust, lazy]
url_officiel: https://pola.rs/
url_docs: https://docs.pola.rs/
url_repo: https://github.com/pola-rs/polars
---

# Polars

## Pourquoi
DataFrames en Rust avec API Python élégante. Multi-thread natif, **lazy execution** (optimisations comme un query planner SQL), Apache Arrow under the hood, syntaxe expressions plus prédictible que pandas. 5-30x plus rapide que pandas selon l'op.

## Quand l'utiliser
- Tout nouveau projet de data prep / ETL Python
- Datasets de moyenne à grande taille (1 GB - 100 GB en streaming)
- Pipelines de transformation où la perf compte
- Quand l'API expressions (`pl.col()`, `pl.when().then()`) clique pour toi

## Quand NE PAS l'utiliser
- Tu vis dans un écosystème legacy 100% pandas
- Tu as besoin d'une intégration tierce qui ne supporte que pandas (rare maintenant — `to_pandas()` est trivial)
- Très très grande scale distribuée → [[Dask]], [[Spark]]

## Pièges connus
- **API expressions** : différente de pandas, courbe d'apprentissage 1-2 jours
- **Lazy vs eager** : `LazyFrame` vs `DataFrame`, `.collect()` à comprendre
- **Versions** : projet jeune, breaking changes acceptables avant 1.0 stable
- **Strings** : type Utf8 strict, pas de `object` fourre-tout pandas
- **Print en notebook** : tronqué par défaut, configurer `pl.Config`

## Liens
- [[pandas]] — alternative legacy
- [[Parquet]] — format I/O optimal pour Polars
- [[DuckDB]] — autre approche pour analytics local
- Cookbook : https://docs.pola.rs/user-guide/
- Comparatif perf vs pandas : https://pola.rs/posts/benchmarks/
