---
galaxie: wiki
nom: claude-api
type: claude-code-skill
plateforme: claude-code
categorie: skill/dev-flow
sous_categories: [api, sdk, anthropic, prompt-caching, llm-app]
auteur: Anthropic
source: claude-code natif
source_url: https://docs.claude.com/en/docs/build-with-claude/overview
install_cmd: 
install_doc: https://docs.claude.com/
licence: 
licence_type: proprietary
domaines: [ai-eng, ml-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, api, llm]
---

# claude-api

## Pourquoi

Skill **bundled** avec Claude Code. Se déclenche quand le code touche au SDK Anthropic (`anthropic` Python ou `@anthropic-ai/sdk` Node). Il apprend à l'agent à écrire / corriger / optimiser des apps Claude API avec les bonnes pratiques **prompt caching** et migration entre versions modèles.

C'est **le skill par défaut** quand tu builds une feature LLM dans un projet Python ou TS.

## Quand l'utiliser

- Ajouter une feature qui appelle l'API Claude (chat, tool use, batch, files, citations, memory, etc.)
- Optimiser le coût/latence d'une app Claude existante via le prompt caching
- Migrer un script entre versions de modèle (4.5 → 4.6 → 4.7)
- Remplacer un modèle retiré (`claude-2`, `claude-instant`) par son remplaçant

## Quand NE PAS l'utiliser

- Le projet utilise OpenAI / Gemini / autre SDK → le skill se désactive tout seul, mais ne le force pas
- Code provider-neutre (LangChain, LiteLLM…) → préfère un skill framework-spécifique si dispo

## Comment l'installer

Pas d'install — il est natif à Claude Code. Vérifie sa présence :

```bash
claude
# dans la session :
> Liste les skills bundled disponibles
```

## Exemples d'usage

```
> ajoute le prompt caching sur la conversation principale de chat.py
> migre app.ts de claude-3-5-sonnet vers claude-sonnet-4-7
> propose une stratégie de cache hit rate >80% pour mon agent
```

## Pièges connus

- Le skill ne se déclenche pas sur un fichier *appelé* `claude.py` si le code n'importe pas `anthropic` — il check l'import, pas le nom.
- Sur un projet multi-providers, il peut se déclencher quand tu ne voulais que toucher la partie OpenAI. Dis-lui "ignore claude-api ici" si besoin.

## Liens

- Doc API Claude : https://docs.claude.com/
- Migration de modèles : https://docs.claude.com/en/docs/about-claude/models
