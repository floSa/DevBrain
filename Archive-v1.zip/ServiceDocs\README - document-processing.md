# Service — <NOM_DU_SERVICE>

<!--
Template à copier dans <projet>/services/<nom>/README.md.
Référence règle : Rules/Documentation/Document-Processing.md du DevBrain.
-->

## Rôle métier

<À REMPLIR : 2-3 lignes — quel besoin de parsing/normalisation.>

Exemple :
> Pipeline de parsing des documents uploadés par les users (PDF, DOCX, HTML, images). Normalise tout en Markdown structuré pour consommation par le service de chunking + embedding en aval.

## Formats supportés

| Format | Extension | Parser | OCR ? | Limite | Status |
|--------|-----------|--------|-------|--------|--------|
| PDF natif | `.pdf` | Docling | ❌ | 200 MB | ✅ supporté |
| PDF scanné | `.pdf` | Docling + Tesseract | ✅ | 50 MB | ✅ supporté |
| DOCX | `.docx` | Docling | ❌ | 50 MB | ✅ supporté |
| HTML | `.html` | defuddle | ❌ | 10 MB | ✅ supporté |
| Image | `.png`, `.jpg` | Tesseract | ✅ | 20 MB | ✅ supporté |
| Markdown | `.md` | passthrough | ❌ | — | ✅ supporté |
| `.doc` legacy | `.doc` | — | — | — | ❌ refusé |
| `.epub` | `.epub` | — | — | — | ❌ refusé |
| `.rtf` | `.rtf` | — | — | — | ❌ refusé |

> Tout autre format → `415 Unsupported Media Type` côté API.

## Pipeline de normalisation

```mermaid
flowchart TD
  input[File upload] --> detect[Detect format]
  detect --> route{Routing}
  route -->|pdf/docx| docling[Docling parse]
  route -->|html| defuddle[defuddle extract]
  route -->|image| ocr[Tesseract OCR]
  route -->|md| passthru[Passthrough]
  docling --> normalize[Normalize to Markdown]
  defuddle --> normalize
  ocr --> normalize
  passthru --> normalize
  normalize --> validate[Validate schema]
  validate --> output[NormalizedDocument]
```

### Format de sortie standardisé

**Tous les inputs** ressortent en ce même format Pydantic (versionné) :

```python
class NormalizedDocument(BaseModel):
    doc_id: str                       # UUID
    source_type: Literal["pdf", "docx", "html", "image", "md"]
    source_path: str                  # s3://...
    title: str | None
    author: str | None
    created_at: datetime | None       # extrait du fichier source si dispo
    content_md: str                   # markdown structuré
    sections: list[Section]           # hiérarchie h1/h2/h3
    tables: list[Table]               # tables extraites séparément
    images: list[ImageRef]            # images extraites (refs S3)
    metadata: dict                    # extra (langue, nb_pages, etc.)
    parsing_meta: ParsingMeta         # durée, version parser, warnings
```

### Schéma JSON publié

`services/<nom>/schemas/normalized_document.json` (versionné, auto-généré depuis Pydantic)

## Contrat d'interface

```python
def process_document(s3_key: str) -> NormalizedDocument:
    """
    Pipeline complet : download → detect → parse → normalize → validate.
    
    Returns:
        NormalizedDocument validé.
    
    Raises:
        UnsupportedFormatError: format non listé
        ParseFailedError: parsing impossible (log + retry possible)
        OCRFailedError: OCR n'a rien extrait (image trop dégradée)
    """
    ...

# Mode async aussi disponible
async def process_document_async(s3_key: str) -> NormalizedDocument: ...
```

- **Idempotence** : rejouer le parsing produit le même output (cache par `(s3_key, parser_version)`)
- **Mode batch** : `process_batch(s3_keys: list[str]) -> AsyncIterator[NormalizedDocument]`

## Stratégie de chunking (en aval)

> Le chunking est dans `services/<vector-db>/` (cf. [[Database-Vector]] règle), pas ici.

Cependant, le NormalizedDocument est conçu pour faciliter le chunking :
- `sections[]` permet un chunking structure-aware (par heading)
- `content_md` permet un chunking recursive standard

## Conservation des originaux

- **Fichiers source** conservés dans `<projet>-raw` pendant **90 jours** (cf. [[Storage-Object]])
- **NormalizedDocument** stockés dans `<projet>-processed` (régénérables depuis raw)
- **Reprocessing** : commande `services/<nom>/scripts/reprocess.py --since=2026-04-01`

## Configuration

| Variable | Type | Défaut | Description |
|----------|------|--------|-------------|
| `DOC_PARSER_TIMEOUT_S` | `int` | `300` | Timeout par doc |
| `DOC_PARSER_MAX_FILE_MB` | `int` | `200` | Taille max input |
| `DOC_OCR_LANGUAGES` | `list[str]` | `["eng", "fra"]` | Langues OCR |
| `DOC_PARSER_GPU_ENABLED` | `bool` | `false` | Utiliser GPU pour Docling |
| `<À REMPLIR>` |  |  |  |

## Démarrage local

```bash
# Si Docling avec modèles à télécharger
docker-compose up -d doc-processor

# Premier run télécharge les modèles (~3 GB)
docker-compose logs -f doc-processor

# Test sur un fichier
uv run python -m services.<nom>.cli process tests/fixtures/sample.pdf
```

## Tests

```bash
# Test unitaire avec fixtures
uv run pytest tests/unit/services/doc_processing/

# Tests d'intégration (parsing réel sur fixtures)
uv run pytest tests/integration/test_doc_processing.py
```

Fixtures recommandées dans `tests/fixtures/documents/` :
- `simple.pdf`, `complex_tables.pdf`, `scanned.pdf`, `multi_lang.pdf`
- `simple.docx`, `with_images.docx`
- `article.html`, `medium_article.html`
- `chart.png`, `table_screenshot.png`

## Métriques de qualité

- **Taux de succès parsing** : tracked en prod, alerte si < 95%
- **Temps moyen par doc** : par format, alerte si dégradation
- **Taille moyenne d'output** vs input : ratio attendu

## Pièges à anticiper

- **PDFs scannés faussement détectés** comme natifs → fallback OCR
- **Encoding UTF-8 vs Latin-1** sur HTML legacy
- **Tables complexes (rowspan/colspan)** : extraction imparfaite à valider
- **Formules math** : LaTeX vs MathML — choisir et tester
- **OCR hallucinations** sur images low-res
- **Documents > 500 pages** : risque timeout/mémoire

## Liens

- DevBrain : [[Docling]] · [[Database-Vector]] · [[Storage-Object]]
- Règle : [[Document-Processing]]
- Doc Docling : <https://docling-project.github.io/docling/>
- Schéma de sortie : `services/<nom>/schemas/normalized_document.json`
