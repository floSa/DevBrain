---
galaxie: dev
nom: Nebula Graph
alias: [nebula, nebulagraph]
categorie: database/graph
sous_categories: [property-graph, distributed, ngql]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: C++
clients_officiels: [python, ts, go, java]
plateforme: [linux]
score: 
mes_projets: []
alternatives: ["[[Neo4j]]", "JanusGraph", "ArangoDB"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, database, graph, distributed]
url_officiel: https://www.nebula-graph.io/
url_docs: https://docs.nebula-graph.io/
url_repo: https://github.com/vesoft-inc/nebula
---

# Nebula Graph

## Pourquoi
Base graphe distribuée open-source (Apache-2.0), conçue pour la **scalabilité horizontale** : milliards de nœuds, milliards d'edges. Architecture séparée storage/compute, langage **nGQL** (proche Cypher). Origine chinoise, mature en Asie, plus discret en occident.

## Quand l'utiliser
- Graphes très larges (>1B nœuds ou edges) où [[Neo4j]] devient cher / limité
- Besoin de licence permissive (Apache-2.0 vs GPL/commercial Neo4j)
- Workload distribué dès le départ
- Use cases similaires à Neo4j mais à l'échelle (réseau social public, supply chain industrielle)

## Quand NE PAS l'utiliser
- Petit/moyen graphe → [[Neo4j]] est plus simple à exploiter
- Équipe non-graph experte → écosystème moins riche que Neo4j
- Besoin d'un GUI / Studio polished → outils moins matures
- Si compatibilité Cypher stricte importante → Neo4j ou Memgraph

## Pièges connus
- **Architecture 3-tier** (graphd, metad, storaged) : ops complexes
- **nGQL ≠ Cypher** : syntaxe proche mais incompatibilités
- **Documentation** : initialement orientée chinois, traductions inégales
- **Écosystème** : moins d'intégrations LangChain/LlamaIndex que [[Neo4j]]
- **Sizing** : tuning des shards et partitions à faire

## Liens
- [[Neo4j]] — alternative plus mature en occident
- nGQL reference : https://docs.nebula-graph.io/master/3.ngql-guide/1.nGQL-overview/1.overview/
- Nebula Cloud : https://www.nebula-graph.io/cloud
- Comparaison Neo4j/Nebula : à faire en interne selon volumes
