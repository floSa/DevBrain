---
galaxie: wiki
nom: <% tp.file.title %>
type: workflow
categorie: workflow/
sous_categories: []
domaines: []
duree_estimee: 
prerequis: []
created: <% tp.date.now("YYYY-MM-DD") %>
modified: <% tp.date.now("YYYY-MM-DD") %>
tags: [workflow]
---

# <% tp.file.title %>

## Quand l'utiliser

(En 1 phrase : quand est-ce que ce workflow est pertinent ?)

## Pré-requis

- 
- 

## Procédure

### 1. <étape>

```bash
# commandes / actions concrètes
```

### 2. <étape>


### 3. <étape>


## Checklist de fin

- [ ] 
- [ ] 

## Pièges courants

- 

## Variantes

- Si <condition> → fais <variation>
- 

## Voir aussi

- [[Pattern - X]]
- [[<service ou skill>]]
