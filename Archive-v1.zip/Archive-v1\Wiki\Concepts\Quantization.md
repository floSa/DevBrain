---
galaxie: wiki
nom: Quantization (LLM)
alias: [quantization, GPTQ, AWQ, GGUF, FP8, INT4, NF4, BitNet]
type: concept
categorie: concept/llm-training
sous_categories: [quantization, ptq, qat, inference, llm]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Dettmers 2022 (LLM.int8), Frantar 2022 (GPTQ), Lin 2023 (AWQ), Ma 2024 (BitNet)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, quantization, inference, optimization]
---

# Quantization (LLM)

## TL;DR

Réduire la **précision** des weights (et parfois activations) d'un LLM : **FP16/BF16 → INT8/INT4/FP4/NF4** → division par 2-4 de la mémoire et accélération. Familles : **PTQ** (Post-Training Quantization, le standard) — GPTQ, AWQ, GGUF, HQQ, SmoothQuant ; **QAT** (Quantization-Aware Training) — meilleur mais coûteux ; **KV cache quantization** ; **FP8** training (H100). **BitNet** explore 1.58-bit. Permet de faire tourner Llama 70B sur un GPU 24GB (Q4) ou un laptop M-series (GGUF). Standard pour serving cost-effective et edge.

## Le problème

Llama 70B en BF16 = ~140 GB → impossible sur consumer GPU. Inference cost domine en prod (vs training). Comment **réduire la mémoire / accélérer** sans casser la qualité ?

## L'idée

### Concepts de base

#### Quantization basique

Convertir float continu → integer discret :

$$ q = \text{round}\left(\frac{w - z}{s}\right), \quad w \approx s q + z $$

avec $s$ scale, $z$ zero-point.

#### Symmetric vs asymmetric

- **Symmetric** : $z = 0$, range $[-s \cdot 2^{n-1}, s \cdot 2^{n-1}]$
- **Asymmetric** : $z \neq 0$, mieux pour activations skewed

#### Per-tensor vs per-channel vs per-group

- **Per-tensor** : 1 scale pour toute la matrice → loss d'info
- **Per-channel** : 1 scale par output channel → standard
- **Per-group** : 1 scale par groupe de 64-128 weights → meilleur, GGUF/GPTQ
- **Per-token** : pour activations dynamic

### Précisions

| Format | Bits | Range | Notes |
|---|:-:|---|---|
| FP32 | 32 | énorme | training standard original |
| **BF16** | 16 | full | training standard moderne |
| **FP16** | 16 | small (overflow risk) | inference common |
| **FP8 (E4M3)** | 8 | low | H100, BlackWell |
| **FP8 (E5M2)** | 8 | wider, low precision | gradients FP8 |
| **INT8** | 8 | discrete | standard PTQ |
| **INT4** | 4 | très discret | LLM inference standard |
| **NF4** | 4 | adapted to normal dist | QLoRA standard |
| **FP4** | 4 | float 4-bit | newer |
| **INT2 / 1.58-bit** | 2 / log2(3) | extreme | BitNet research |

### PTQ — Post-Training Quantization (standard)

Quantifier **après** training, sans re-train. Méthodes :

#### LLM.int8() (Dettmers 2022)

- **Vector-wise** quantization
- **Outlier detection** : garder les ~0.1% outlier weights en FP16
- Pas de loss de qualité sur Llama 13B+
- Library `bitsandbytes`

#### GPTQ (Frantar 2022)

- **Layer-by-layer** : approximer chaque layer en quantifiant col-by-col
- Use **Hessian-based** corrections
- Calibration sur un small dataset
- Standard 4-bit pour LLMs

#### AWQ (Activation-aware Weight Quantization, Lin 2023)

- **Identifier weights importants** via magnitude des activations
- Scale ces weights up before quantization → preservation
- Meilleur que GPTQ sur certains modèles
- Standard moderne

#### GGUF (llama.cpp)

Format de Lab quantization ouvert. Variants :
- **Q4_0, Q4_1** : 4-bit basic
- **Q4_K_M** : 4-bit K-quants medium quality (standard 4-bit moderne)
- **Q5_K_M** : 5-bit K-quants medium
- **Q6_K** : 6-bit K-quants
- **Q8_0** : 8-bit basic
- **IQ3_M, IQ2_S** : "Importance" quants — meilleur que Q3 traditionnel

GGUF = format standard pour llama.cpp, Ollama, LM Studio.

#### HQQ (Half-Quadratic Quantization)

Fast, no calibration data needed. Bon compromis.

#### QuIP / QuIP#

Très agressive (2-3 bit) avec préservation qualité. Recherche.

#### SmoothQuant (Xiao 2022)

**Migrate** la difficulty de activations vers weights via scaling. Permet INT8 weights + activations simultanément.

### QAT — Quantization-Aware Training

Pendant le training, **simuler la quantization** dans le forward pass (avec gradient straight-through).

- Meilleur que PTQ
- **Coûteux** (re-train le modèle)
- Utilisé pour edge models (Phi, Gemma quantized variants)

### KV cache quantization

Le **KV cache** domine la mémoire en inference long context. Quantifier en 4-bit ou 8-bit :
- Réduit cache par 2-4x
- Souvent négligeable sur qualité (cache n'est pas weights critiques)
- Support natif : Hugging Face transformers `cache_implementation="quantized"`

### FP8 training (H100, BlackWell)

H100 supports FP8 in tensor cores → train massive models en FP8 :
- 2x throughput vs BF16
- E4M3 pour forward, E5M2 pour gradients
- Used in Llama 4, DeepSeek-V3, OpenAI training
- Tooling : NVIDIA Transformer Engine, Megatron-LM

### MXFP / Microscaling

Standard récent (Open Compute Project) :
- MXFP8, MXFP4 : block-FP avec shared exponent per block
- Très efficient pour matmul

### BitNet — 1.58-bit (Ma 2024)

Recherche extrême : ternary weights {-1, 0, 1}. Compétitif avec FP16 selon papers, hardware-friendly. Future de l'inference ?

### Mémoire et perf gains

Llama 70B en :
- BF16 : 140 GB
- INT8 : 70 GB
- Q4_K_M (4-bit) : ~40 GB
- IQ2_M (2-bit) : ~22 GB (avec perte)

Inference speedup :
- INT8 sur consumer GPU : 1.5-2x
- INT4 : 2-3x
- Permet **batch sizes** plus grands → throughput global meilleur

### Qualité — combien de perte ?

Empirique sur benchmarks :
- **BF16 → INT8** : quasi-zéro
- **BF16 → INT4 (GPTQ/AWQ/Q4_K_M)** : 1-3% drop perplexity
- **BF16 → IQ3** : 3-5% drop
- **BF16 → IQ2** : 5-15% drop (cas par cas)
- **Q8_0** : indistinguable de BF16

Gros modèles (>30B) tolèrent mieux la quantization.

### Outils

| Outil | Type | Use case |
|---|---|---|
| **bitsandbytes** | Library | QLoRA, training en 4/8-bit |
| **AutoGPTQ** | Library | PTQ GPTQ |
| **AutoAWQ** | Library | PTQ AWQ |
| **llama.cpp** | Inference engine | GGUF format, CPU/GPU |
| **Ollama** | Wrapper | Easy GGUF model serving |
| **vLLM** | Serving | INT8/INT4 inference natif |
| **llm-compressor** | Library | Quantization pour vLLM |
| **TensorRT Model Optimizer** | NVIDIA | INT4/INT8/FP8 |
| **MLX** | Apple | Quantization native M-series |
| **NeuralMagic Sparse-Quantize** | Production | Sparsity + quant |

### Best practices

1. **Q4_K_M / AWQ INT4** : default pour inference cost-effective
2. **Q8_0 / INT8** : si qualité critique, mémoire moyenne
3. **NF4 + QLoRA** pour fine-tuning sur consumer GPU
4. **FP8 training** pour très gros modèles (H100/B200 available)
5. **Eval qualité après** : MMLU + perplexity + task-specific
6. **KV cache 4-bit** sur long context
7. **vLLM + AWQ ou llm-compressor** en production
8. **Évaluer plusieurs quants** (Q4 vs IQ3) — gain mémoire vs perte
9. **Pas de quant agressive** sur small models (<7B) — souffrent plus

## Quand c'est utile

- **Serving cost reduction** : 4x moins de GPU pour même throughput
- **Local LLM** : Llama 70B sur RTX 4090 (Q4)
- **Edge / mobile** : iPhone running Phi via MLX
- **Multi-tenant** : plus de modèles en RAM
- **Long context** : KV cache quantization libère mémoire
- **Fine-tuning consumer GPU** : QLoRA permet 70B sur 48GB
- **Batch inference** : batch plus gros = throughput plus haut

## Quand ça ne marche pas / pièges

- **Quantization trop agressive** sur small model : Phi-3 quant Q4 dégrade plus que Llama 70B Q4
- **Outliers** dans activations : sans SmoothQuant, INT8 activations cassent
- **Mixed precision bugs** : matmul int4 × fp16 demande implementation careful
- **Calibration data biaisée** : GPTQ/AWQ calibrés sur Wikipedia mauvais sur code
- **Quantifier puis fine-tune** : peut produire des shifts. Préférer QAT ou QLoRA.
- **CPU inference quant** : GGUF sur CPU lent, intéressant que pour absence de GPU
- **Quantization MoE** : moins efficace, experts différents → perte de qualité
- **KV cache quant agressive** : Q2 cache casse, Q4 OK
- **Format incompatible** : GGUF llama.cpp != AWQ != GPTQ — convertir si change de stack
- **Quantifier rarement utilisé** : if model serves 100 RPS, fast inference matter ; pour 1 user, quant peu utile
- **Tensor cores INT4** : nouveau (H100 v2, BlackWell), pas partout

## Code minimal

```python
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

# 1. bitsandbytes 4-bit (QLoRA-style)
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_use_double_quant=True,
)
model = AutoModelForCausalLM.from_pretrained(
    "meta-llama/Meta-Llama-3-8B-Instruct",
    quantization_config=bnb_config,
    device_map="auto"
)
# Memory : ~5 GB au lieu de 16 GB BF16

# 2. AutoGPTQ 4-bit
# from auto_gptq import AutoGPTQForCausalLM, BaseQuantizeConfig
# quant_config = BaseQuantizeConfig(bits=4, group_size=128, damp_percent=0.01)
# model = AutoGPTQForCausalLM.from_pretrained(model_id, quant_config)
# model.quantize(calibration_data)
# model.save_pretrained("./model-gptq")

# 3. AutoAWQ
# from awq import AutoAWQForCausalLM
# model = AutoAWQForCausalLM.from_pretrained(model_id)
# model.quantize(tokenizer, calib_data=calibration_data, quant_config=quant_config)
# model.save_quantized("./model-awq")

# 4. GGUF via llama.cpp
# 1. Convert HF model
# python llama.cpp/convert_hf_to_gguf.py meta-llama/Meta-Llama-3-8B-Instruct \
#     --outfile model-f16.gguf
# 2. Quantize
# ./llama-quantize model-f16.gguf model-q4-k-m.gguf Q4_K_M

# 5. vLLM avec quantization
# vllm serve TheBloke/Llama-3-8B-AWQ --quantization awq
# vllm serve neuralmagic/Llama-3-8B-Instruct-quantized.w8a8 --quantization compressed-tensors

# 6. KV cache quantization (HF)
model_q_cache = AutoModelForCausalLM.from_pretrained(
    "meta-llama/Meta-Llama-3-8B-Instruct",
    torch_dtype=torch.bfloat16,
    cache_implementation="quantized",
    cache_config={"backend": "HQQ", "nbits": 4, "axis-key": 0, "axis-value": 0}
)

# 7. Mesurer la mémoire
def get_model_memory_gb(model):
    mem = sum(p.numel() * p.element_size() for p in model.parameters())
    return mem / 1e9

print(f"Model memory: {get_model_memory_gb(model):.2f} GB")

# 8. Ollama (wrapper GGUF)
# ollama run llama3:8b-instruct-q4_K_M

# 9. MLX (Apple Silicon)
# from mlx_lm import load, generate
# model, tokenizer = load("mlx-community/Llama-3-8B-Instruct-4bit")
# response = generate(model, tokenizer, prompt="Hello", max_tokens=100)

# Eval quality après quantization
# from lm_eval import simple_evaluate
# results = simple_evaluate(model, tasks=["mmlu", "hellaswag"], batch_size=8)
```

## Pour aller plus loin

- Dettmers et al., *LLM.int8(): 8-bit Matrix Multiplication for Transformers at Scale* (NeurIPS 2022)
- Frantar et al., *GPTQ: Accurate Post-Training Quantization for Generative Pre-trained Transformers* (ICLR 2023)
- Lin et al., *AWQ: Activation-aware Weight Quantization for LLM Compression and Acceleration* (2023)
- Dettmers et al., *QLoRA: Efficient Finetuning of Quantized LLMs* (NeurIPS 2023)
- Xiao et al., *SmoothQuant: Accurate and Efficient Post-Training Quantization for Large Language Models* (ICML 2023)
- Ma et al., *The Era of 1-bit LLMs: All Large Language Models are in 1.58 Bits* (BitNet, 2024)
- *llama.cpp*, *vLLM*, *bitsandbytes*, *AutoGPTQ*, *AutoAWQ* documentation
- **Liens internes** : [[PEFT]] (QLoRA), [[Inference optimization]], [[Flash Attention and efficient attention]] (KV cache), [[Vector norms]] (precision)
