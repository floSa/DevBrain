---
galaxie: dev
nom: Kestra
alias: [kestra]
categorie: data/orchestrator
sous_categories: [yaml, multi-language, orchestrator, event-driven, declarative]
licence: Apache-2.0
licence_type: open-source
hosted: self ou cloud
maturite: production
langage: Java
clients_officiels: [python, http, cli, terraform]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[Prefect]]", "[[Dagster]]", "[[Airflow]]", "Mage", "[[Argo Workflows]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, orchestrator, yaml, event-driven]
url_officiel: https://kestra.io/
url_docs: https://kestra.io/docs/
url_repo: https://github.com/kestra-io/kestra
---

# Kestra

## Pourquoi

Orchestrateur **déclaratif YAML, multi-langage**. Différenciateur clé : tu peux mélanger **Python + JavaScript + Shell + SQL + Java** dans le **même workflow**, chaque step déclaré en YAML. UI web moderne (édition flow + monitoring), event-driven natif (file dropped, Kafka message, webhook, schedule), **plugins riches** (200+ : S3, GCS, [[BigQuery]], [[Snowflake]], dbt, Airbyte, AWS, etc.).

Cible : équipes data **polyglottes** ou **non-Python only**, qui veulent versionner leurs workflows en YAML + Git. Concurrent direct d'Airflow / Prefect / Dagster pour le segment "ops + analystes + ingés data".

## Quand l'utiliser

- **Équipe polyglotte** : Python + SQL + Bash + JS dans un même flow
- **Workflows déclaratifs versionnés Git** : YAML > code pour audit / review
- **UI web pour business users / analystes** : édition directe via UI
- **Event-driven** : file detected sur S3, Kafka message, webhook → trigger flow
- **Plugins SaaS** : Airbyte, Fivetran, dbt Cloud, Snowflake, BigQuery wrappés
- **Multi-tenancy** : namespaces, RBAC enterprise
- **Combo dbt** : Kestra orchestre les runs dbt
- **Replay / backfill** facile via UI

## Quand NE PAS l'utiliser

- **Stack Python pure** → [[Prefect]] / [[Dagster]] (code Python > YAML)
- **Asset-centric ML / data lineage** → [[Dagster]] (software-defined assets)
- **Complexité ETL > YAML** : conditional logic / dynamic DAGs lourds en YAML → Python natif mieux
- **Kubernetes natif strict** → [[Argo Workflows]]
- **Très petite équipe** : Kestra demande un peu d'infra (JVM, DB, storage)
- **Écosystème Python ML pur** : intégrations moins riches que Prefect/Dagster sur ce segment

## Pièges connus

- **YAML grossit vite** : workflows complexes deviennent illisibles, modulariser via subflows
- **Écosystème plus jeune** vs Airflow (10+ ans), moins de Stack Overflow / blog posts
- **Plugins variables en qualité** : core OK, plugins community parfois fragiles
- **Workers = JVM** : memory footprint plus gros que Python workers
- **Storage backend** : Postgres / Elasticsearch / Kafka selon config → infra à provisionner
- **Templating Pebble** (pas Jinja) : syntaxe différente d'Airflow / Prefect
- **Versioning enterprise** : tier payant pour features avancées (git sync auto, audit log fin)
- **Kestra EE (Enterprise Edition)** : RBAC fin, SSO, audit → tier payant
- **Performance scheduler** : sur 10k+ tâches concurrentes, tuning Java (heap, GC) nécessaire

## Code minimal

```bash
# Lancer via Docker Compose
curl -o docker-compose.yml https://raw.githubusercontent.com/kestra-io/kestra/develop/docker-compose.yml
docker compose up -d
# UI : http://localhost:8080
```

```yaml
# flows/etl-daily.yml : un flow multi-langage
id: etl-daily
namespace: company.data
description: ETL quotidien commandes -> warehouse

triggers:
  - id: daily
    type: io.kestra.plugin.core.trigger.Schedule
    cron: "0 6 * * *"

tasks:
  - id: extract
    type: io.kestra.plugin.scripts.python.Script
    beforeCommands:
      - pip install requests pandas
    script: |
      import requests, pandas as pd
      from kestra import Kestra
      r = requests.get("https://api.example.com/orders")
      df = pd.DataFrame(r.json())
      df.to_csv("orders.csv", index=False)
      Kestra.outputs({"rows": len(df)})
    outputFiles:
      - orders.csv

  - id: transform
    type: io.kestra.plugin.scripts.shell.Commands
    inputFiles:
      orders.csv: "{{ outputs.extract.outputFiles['orders.csv'] }}"
    commands:
      - awk -F, '$3 > 100' orders.csv > big_orders.csv
    outputFiles:
      - big_orders.csv

  - id: load
    type: io.kestra.plugin.gcp.bigquery.LoadFromGcs
    from: "{{ outputs.transform.outputFiles['big_orders.csv'] }}"
    destinationTable: project.dataset.orders
    format: CSV
```

```python
# Trigger un flow via API Python
import requests

response = requests.post(
    "http://localhost:8080/api/v1/executions/company.data/etl-daily",
    files={"inputs": (None, '{"date": "2026-05-20"}')},
)
print(response.json())
```

## Liens

- [[Comparatif - Orchestrateurs data]]
- [[Prefect]] / [[Dagster]] / [[Airflow]] — alternatives Python-natif
- Mage — alternative notebook-style
- [[Argo Workflows]] — alternative K8s-native
- [[dbt]] — combo classique (Kestra orchestre)
- Docs : https://kestra.io/docs/
- GitHub : https://github.com/kestra-io/kestra
- Plugins : https://kestra.io/plugins
