---
galaxie: dev
nom: seaborn
alias: [seaborn]
categorie: tooling/viz
sous_categories: [visualization, matplotlib, statistical, python, exploratory]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: ["matplotlib", "plotly", "altair", "bokeh", "ggplot2 (R)"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, viz, stats, exploratory]
url_officiel: https://seaborn.pydata.org/
url_docs: https://seaborn.pydata.org/
url_repo: https://github.com/mwaskom/seaborn
---

# seaborn

## Pourquoi

Wrapper haut niveau sur **matplotlib** pour **visualisations statistiques**. Defaults élégants, **syntax pandas-friendly** (`sns.scatterplot(data=df, x='col1', y='col2', hue='cat')`), plots stats en 1 ligne : distribution, regression, corrélation, pairplot, heatmap. **Standard de facto** pour analyse exploratoire en data science Python.

Depuis **seaborn 0.12** (2022) : nouvelle interface **`seaborn.objects`** (`so.Plot(df).add(so.Dots())`) inspirée de ggplot2 / grammar-of-graphics, en parallèle de l'API fonctionnelle historique. Les deux coexistent : l'ancienne reste référente, la nouvelle est plus composable.

## Quand l'utiliser

- **Exploration data science** : boxplot, violin, heatmap, pairplot, jointplot
- **Quick stats viz dans notebook** : 1 ligne pour un plot publication-acceptable
- **Defaults beaux** sans tuning matplotlib (palettes, contexts, themes)
- **Combo pandas natif** : `data=df, x='col', y='col2', hue='cat'`
- **Distribution plots** : `histplot`, `kdeplot`, `ecdfplot`, `rugplot`
- **Regression plots** : `regplot`, `lmplot` avec CI, residplot
- **Faceting (FacetGrid / catplot)** : small multiples conditionnelles
- **Correlation heatmap** : `sns.heatmap(df.corr(), annot=True)`

## Quand NE PAS l'utiliser

- **Interactivité** → [[plotly]] / [[bokeh]] / [[altair]] (seaborn = statique)
- **Apps web prod end-user** → frameworks ad-hoc (Streamlit + plotly, Dash)
- **Custom heavy** : pour un layout très spécifique, matplotlib direct
- **Très gros volumes** (>100k points) : `scatterplot` rame → matplotlib + datashader
- **Animation / temps réel** → matplotlib.animation ou plotly
- **3D plots** : seaborn n'en fait pas, matplotlib mplot3d

## Pièges connus

- **API duale 0.12+** : interface fonctionnelle vs `seaborn.objects` → confusion (deux façons de faire la même chose)
- **`hue` overloaded** : sépare en couleurs mais parfois en groupes statistiques aussi → comportement plot-dépendant
- **Configuration globale matplotlib** : `sns.set_theme()` modifie le rcParams global, peut surprendre
- **Performance sur gros datasets** : KDE, scatterplot rament au-delà de 100k points
- **`catplot` / `relplot` / `displot` (figure-level) vs `boxplot` / `scatterplot` / `histplot` (axes-level)** : distinction critique mais mal documentée — figure-level crée sa propre figure, axes-level utilise un ax existant
- **Palettes mal interprétées** : `palette='husl'` ≠ `palette='Set2'`, lire la doc des palettes
- **Tightness layout** : figure-level appelle `tight_layout` auto, axes-level pas
- **Confidence intervals coûteux** : `ci=95` calcul par bootstrap, lent sur gros données → `ci=None`
- **Pivot interne pour heatmap** : `sns.heatmap` veut un DataFrame déjà pivoté
- **Annotations manuelles** : ajouter texte / lignes = retomber sur matplotlib

## Code minimal

```bash
pip install seaborn pandas
```

```python
import seaborn as sns
import matplotlib.pyplot as plt

sns.set_theme(style="whitegrid", context="notebook", palette="deep")

tips = sns.load_dataset("tips")

# Scatter avec regression + hue
sns.lmplot(data=tips, x="total_bill", y="tip", hue="smoker",
           col="time", height=4, aspect=1.2)
plt.show()
```

```python
# Distribution + box + violin
fig, axes = plt.subplots(1, 3, figsize=(15, 4))
sns.histplot(data=tips, x="total_bill", kde=True, ax=axes[0])
sns.boxplot(data=tips, x="day", y="total_bill", ax=axes[1])
sns.violinplot(data=tips, x="day", y="total_bill", hue="sex",
               split=True, ax=axes[2])
plt.tight_layout()
plt.show()
```

```python
# Heatmap correlation
import numpy as np

corr = tips.select_dtypes("number").corr()
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm",
            center=0, vmin=-1, vmax=1, square=True)
plt.show()
```

```python
# Pairplot : exploration multi-variables en 1 ligne
iris = sns.load_dataset("iris")
sns.pairplot(iris, hue="species", diag_kind="kde", corner=True)
plt.show()
```

```python
# FacetGrid manuel pour control fin
g = sns.FacetGrid(tips, col="day", row="smoker", height=3, aspect=1.3)
g.map_dataframe(sns.scatterplot, x="total_bill", y="tip", hue="sex")
g.add_legend()
plt.show()
```

```python
# Nouvelle API seaborn.objects (0.12+, grammar of graphics)
import seaborn.objects as so

(
    so.Plot(tips, x="total_bill", y="tip", color="smoker")
    .add(so.Dots())
    .add(so.Line(), so.PolyFit())
    .facet(col="time")
    .label(title="Tip vs Bill par moment et statut fumeur")
)
```

## Liens

- matplotlib — foundation (seaborn rend des Axes matplotlib)
- altair / plotly / bokeh — alternatives interactives
- ggplot2 (R) — équivalent grammar (inspiration de seaborn.objects)
- pandas — combo naturel (DataFrames)
- Docs : https://seaborn.pydata.org/
- Gallery : https://seaborn.pydata.org/examples/index.html
- GitHub : https://github.com/mwaskom/seaborn
