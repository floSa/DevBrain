---
name: add-rule
description: |
  Use this skill to create a new rule fiche in Rules/. Triggers:
  "ajoute une règle", "documente la règle <X>", "écris une rule pour
  <domaine>", or when the user describes a recurring constraint or best
  practice they want to formalize. Generates a rule compliant with the
  Rule template, placing it in Rules/Global/, Rules/Types/<type>/ or
  Rules/Stacks/<stack>/ according to scope.
---

# Skill — add-rule

## Quand l'utiliser

L'utilisateur veut **formaliser une règle** transverse à appliquer à ses projets. Exemples :
- "Ajoute une règle : tout endpoint API doit avoir un timeout explicite"
- "Documente la convention : 1 logger par module, niveau via env var"
- "Écris une règle ML : toute fonction d'eval doit logger les métriques dans MLflow"

Différent de `add-service` (outil) ou `add-wiki-concept` (notion). Une règle est une **contrainte opérationnelle** appliquée par Claude en mode projet.

## Pré-requis vault

Mode build. Périmètre `Rules/`.

## Procédure

### 1. Identifier le scope

| Scope | Dossier cible | Quand l'appliquer |
|---|---|---|
| **Global** | `Rules/Global/` | S'applique à TOUS les projets, sans condition |
| **Type** | `Rules/Types/<type>/` | S'applique aux projets d'un certain type (web-app, cli, ml-pipeline, data-pipeline, library) |
| **Stack** | `Rules/Stacks/<stack>/` | S'applique uniquement à une stack précise (python-fastapi, ts-nextjs, etc.) |
| **Documentation** | `Rules/Documentation/` | Règles de doc projet par type de service intégré |

Si l'utilisateur ne précise pas, demande.

### 2. Identifier le domaine

`domaine:` parmi : `git`, `docs`, `tests`, `code-style`, `security`, `logging`, `dependencies`, `data-quality`, `api-design`, etc.

### 3. Identifier la strictness

| Niveau | Sémantique |
|---|---|
| `must` | Bloquant. Claude doit appliquer sans demander. |
| `should` | Par défaut. Claude signale les écarts mais peut être contourné. |
| `nice-to-have` | Si possible, agrément. |

### 4. Frontmatter

```yaml
---
galaxie: dev
type: rule
domaine: <git | docs | tests | code-style | security | logging | dependencies | ...>
applicable: global | type-<type> | stack-<stack>
strictness: must | should | nice-to-have
created: <YYYY-MM-DD>
modified: <YYYY-MM-DD>
tags: [rule, <domaine>]
---
```

### 5. Corps en 5 sections

```markdown
# <Nom de la règle>

## Principe (1 phrase)

## MUST (si applicable)
- 

## SHOULD (si applicable)
- 

## NICE (si applicable)
- 

## Exemples
### Bon
```code```
### Mauvais
```code```

## Exceptions
- 
```

### 6. Demander validation puis écrire

Path : `Rules/<Scope>/<Nom>.md`.

## Anti-patterns à éviter

- **Règle trop générique** ("écris du bon code") → pas exploitable, demande à être plus précis
- **Mélanger plusieurs règles** dans un seul fichier → 1 règle = 1 fichier
- **Pas d'exemple bon/mauvais** → la règle reste théorique
- **Strictness `must` sur du subjectif** → use `should` quand il y a place au jugement
- **Sortir du périmètre Rules/**

## Voir aussi

- `update-rule` (modifier une règle existante)
- `propose-stack` (utilise les Rules en mode projet)
- `doc-service` (utilise Rules/Documentation/)
