---
name: update-service
description: |
  Use this skill to patch an existing Service fiche in Services/.
  Triggers: "modifie le service", "patch <nom service>", "mets à jour la
  fiche <service>", "j'ai testé <service>, score X", "<service> a une nouvelle
  version", "ajoute une alternative à <service>", "transition status".
  Preserves the fiche, updates 'modified:', optionally transitions status
  (actif → en-eval → abandonne).
---

# Skill — update-service

## Quand l'utiliser

Modifier une fiche existante dans `Services/`. Cas typiques :
- Transition status (actif → en-eval → abandonne)
- Ajout d'une alternative dans `alternatives:`
- Ajout d'un projet dans `mes_projets:`
- Mise à jour du score après usage réel
- Patch d'une section (Pourquoi, Quand utiliser, Pièges, Liens)
- Mise à jour de la maturité ou de la licence

## Pré-requis vault

Mode build. Périmètre `Services/` uniquement.

## Procédure

1. **Localiser** la fiche : `Services/<Cat>/<Nom>.md`. Si nom ambigu, lister les candidats.
2. **Lire** frontmatter + corps.
3. **Identifier le type de patch** :
   - Frontmatter : status, score, maturite, alternatives, mes_projets, url_*
   - Corps : Pourquoi / Quand l'utiliser / Quand NE PAS / Pièges / Liens
4. **Demander la matière** à l'utilisateur (note, URL, REX, version).
5. **Préserver** ce qui n'est pas touché.
6. **Mettre à jour `modified:`**.
7. **Lien REX** : si l'utilisateur a aussi un bug à logger, propose d'invoquer `log-bug` après.
8. **Wikilinker** les nouvelles références (alternatives ajoutées doivent exister comme fiches).
9. **Montrer le diff** avant écriture.

## Transition de status — workflow

```
actif       → "fiche à jour, service utilisable"
   ↓
en-eval     → "en cours d'évaluation, pas encore validé"
   ↓
abandonne   → "ne plus utiliser, raison documentée"
```

Une transition vers `abandonne` doit s'accompagner d'une note dans la section "Pièges connus" expliquant pourquoi.

## Anti-patterns à éviter

- **Rewrite intégral** d'une fiche pour un petit ajout
- **Score inventé** — le score reflète l'usage réel
- **Modifier la catégorie** sans réfléchir aux conséquences (Bases, comparatifs `.base` filtrent dessus)
- **Wikilinks fantômes** — vérifier que les alternatives ajoutées ont leur fiche
- **Oublier de patcher Bugs/REX - <Nom>.md** si la modification vient d'un bug rencontré

## Voir aussi

- `add-service` (création)
- `log-bug` (logger un REX en parallèle)
- `compare-services` (régénérer un comparatif si la catégorie change)
