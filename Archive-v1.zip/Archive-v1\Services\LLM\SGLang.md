---
galaxie: dev
nom: SGLang
alias: [sglang, sgl]
categorie: llm/inference
sous_categories: [inference, serving, radix-attention, structured-output]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python + C++/CUDA
clients_officiels: [python, openai-compat]
plateforme: [linux]
score: 4
mes_projets: []
alternatives: ["[[vLLM]]", "[[TGI]]", "[[TensorRT-LLM]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, inference, serving, radix-attention]
url_officiel: https://github.com/sgl-project/sglang
url_docs: https://docs.sglang.ai/
url_repo: https://github.com/sgl-project/sglang
---

# SGLang

## Pourquoi

Serveur LLM avec **RadixAttention** : prefix caching via **arbre radix**, particulièrement efficace pour des workloads où plusieurs requests partagent des prefixes (chatbot multi-user avec system prompt commun, RAG avec context partagé, agents avec history). Performance souvent **supérieure à [[vLLM]]** sur ces cas (gains 2-5x sur cache hits).

Aussi : **structured output via grammar** (JSON, regex, EBNF) compilé en FSM/PDA — plus rapide et plus fiable que les `guided_json` de vLLM pour structured generation. Frontend DSL Python optionnel pour structurer les prompts (`sgl.gen`, `sgl.assistant`, etc.).

Développé par LMSYS (Chatbot Arena) + UCB. Standard montant 2024-2026 pour LLM serving haute performance.

## Quand l'utiliser

- **Apps avec shared prefixes massifs** : chatbot multi-user (system prompt commun), RAG avec contexts récurrents, agents
- **Structured output strict** (JSON Schema, regex) à haute throughput
- **Multi-LoRA serving** (S-LoRA intégré)
- **Benchmarks throughput agressifs** : SGLang gagne souvent sur Mixtral, Llama 3 70B
- **Speculative decoding** (EAGLE, MTP)
- **Multimodal** (Llama 4, LLaVA, Qwen2-VL supportés)

## Quand NE PAS l'utiliser

- **Stack vLLM mature** → migration coûteuse, vLLM "good enough" la plupart du temps
- **Modèles très exotiques** non supportés (couverture < vLLM mais croît vite)
- **Petite échelle / dev** → [[Ollama]] / [[llama.cpp]] suffisent
- **Stack HuggingFace strict** → [[TGI]] (intégration HF Hub plus immédiate)
- **Windows / macOS** : Linux only en pratique (CUDA)
- **CPU-only** → llama.cpp

## Pièges connus

- **Setup plus complexe que vLLM** : install CUDA + flashinfer kernels, parfois douloureux
- **Moins de modèles "out-of-the-box"** (mais le catalogue grossit vite)
- **Doc moins mature** vs vLLM (qui a 2+ ans d'avance écosystème)
- **Frontend DSL optionnel** : pas obligatoire mais ajoute une couche d'apprentissage si tu l'utilises
- **RadixAttention** : magique sur shared prefixes, mais surcoût si prefixes peu partagés → check ton workload
- **Versions très actives** : breaking changes possibles entre minor, pin `sglang==X.Y.Z`
- **NCCL multi-GPU** : tensor parallelism nécessite NCCL setup propre
- **`--enable-torch-compile`** : gain perf mais compile lent au premier appel (warmup)

## Code minimal

```bash
# Server
# pip install "sglang[all]"
python -m sglang.launch_server \
    --model-path meta-llama/Meta-Llama-3.1-8B-Instruct \
    --port 30000 \
    --tp 1 \
    --enable-cache-report

# Multi-GPU tensor parallelism
python -m sglang.launch_server --model-path meta-llama/Meta-Llama-3.1-70B-Instruct --tp 4
```

```python
# Client OpenAI-compat
from openai import OpenAI
client = OpenAI(base_url="http://localhost:30000/v1", api_key="EMPTY")

response = client.chat.completions.create(
    model="meta-llama/Meta-Llama-3.1-8B-Instruct",
    messages=[{"role": "user", "content": "Hello"}],
)

# Structured output strict (JSON Schema)
response = client.chat.completions.create(
    model="...",
    messages=[{"role": "user", "content": "Extract: John, 30 yo"}],
    response_format={
        "type": "json_schema",
        "json_schema": {
            "schema": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
                "required": ["name", "age"],
            }
        },
    },
)

# Frontend DSL SGLang (optionnel, pour pipelines complexes)
import sglang as sgl
sgl.set_default_backend(sgl.RuntimeEndpoint("http://localhost:30000"))

@sgl.function
def multi_turn_qa(s, question):
    s += sgl.system("You are helpful")
    s += sgl.user(question)
    s += sgl.assistant(sgl.gen("answer", max_tokens=256))

state = multi_turn_qa.run(question="What is RAG?")
print(state["answer"])
```

## Liens

- [[vLLM]] — alt principal, plus mature
- [[TGI]] — alt HuggingFace-natif
- [[TensorRT-LLM]] — alt NVIDIA hardware-optimisé
- [[Inference optimization]] / [[Flash Attention and efficient attention]] (concepts)
- **LMSYS** (créateurs, Chatbot Arena) : https://lmsys.org/
- Docs : https://docs.sglang.ai/
- GitHub : https://github.com/sgl-project/sglang
- Paper : *Efficient Execution of Structured Language Model Programs* (NeurIPS 2024)
