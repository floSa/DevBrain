---
galaxie: wiki
nom: LLM eval metrics
alias: [BLEU, ROUGE, BERTScore, RAGAS, LLM-as-judge, faithfulness, perplexity]
type: concept
categorie: concept/metrics
sous_categories: [metrics, llm, nlp, evaluation, rag]
domaines: [ai-eng, ml-eng]
maturite: emerging
auteurs_cles: [Papineni 2002 (BLEU), Lin 2004 (ROUGE), Zhang 2019 (BERTScore)]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, metrics, llm, nlp, rag, eval]
---

# LLM eval metrics

## TL;DR

Évaluer une sortie LLM est **plus dur que classifier ou régresser** : open-ended, multi-référence, sémantique. Quatre familles : **n-gram overlap** (BLEU, ROUGE — vieux mais standards), **embedding-based** (BERTScore, MoverScore — sémantique), **LLM-as-judge** (GPT-4 / Claude juge — état de l'art mais coûteux), **task-specific** (faithfulness, answer relevance pour RAG ; pass@k pour code). Couplé à des **évals end-to-end** sur gold dataset + **A/B tests** prod. Outils standards : RAGAS, DeepEval, LangSmith, Helicone, TruLens.

## Le problème

Évaluer "ce LLM est-il bon ?" est ambigu :
- **Plusieurs réponses correctes possibles** (génération open-ended)
- **Pas de label dur** (résumé, traduction, code)
- **Critères multiples** : factualité, fluidité, complétude, ton, sécurité
- **Dérive avec le modèle** : prompt update = re-éval

D'où une explosion de métriques imparfaites, qu'il faut combiner.

## L'idée

### 1. N-gram overlap (génération de texte vs référence)

#### BLEU (Papineni 2002)

$$ \text{BLEU} = \text{BP} \cdot \exp\left(\sum_{n=1}^N w_n \log p_n\right) $$

- $p_n$ = precision n-gram (n=1..4)
- BP = brevity penalty (pénalise réponses trop courtes)
- Standard en traduction
- **Limitation** : pas sémantique, biais sur petites variations ("car" vs "vehicle"). Pas adapté au LLM moderne.

#### ROUGE (Lin 2004)

Famille pour résumé :
- **ROUGE-N** : recall n-gram (vs précision pour BLEU)
- **ROUGE-L** : longest common subsequence
- **ROUGE-S** : skip-bigram (autorise gaps)

Standard summarization. Mêmes limites que BLEU.

#### METEOR

Ajoute synonymes (WordNet) et stemming. Légèrement mieux que BLEU.

### 2. Embedding-based

#### BERTScore (Zhang 2019)

Similarité **cosine** entre embeddings BERT des tokens des deux textes :

$$ \text{BERTScore}_R = \frac{1}{|x|} \sum_{x_i \in x} \max_{y_j \in y} x_i^\top y_j $$

(recall) + version precision, F1.

- **Sémantique** : "car" et "vehicle" se ressemblent
- Score $\in [0, 1]$ (cosine normalisé)
- Standard moderne pour génération de texte
- Implem : `bert_score` Python

#### MoverScore

Wasserstein distance entre word embeddings → optimal transport entre les deux textes. Plus robuste à la longueur, mais coûteux.

### 3. Perplexity

$$ \text{PPL} = \exp\left(-\frac{1}{N} \sum_i \log p(x_i | x_{<i})\right) $$

Voir [[Perplexity]]. Métrique de **qualité de modélisation** (sur eval set), pas de génération. Standard pour comparer LLM en pretraining.

### 4. LLM-as-judge (état de l'art)

Faire scorer la sortie par un autre LLM (souvent GPT-4 ou Claude) avec un prompt structuré :

```
You are evaluating an LLM response.
Question: {question}
Response: {response}
Reference (optional): {reference}

Score 1-5 on:
- Accuracy: ...
- Coherence: ...
- Completeness: ...

Output JSON: {"accuracy": int, "coherence": int, "completeness": int, "rationale": "..."}
```

**Variants** :
- **Pointwise** : score absolu (1-5)
- **Pairwise** : comparer A vs B → A meilleur, B meilleur, tie
- **Reference-based** : juge a accès à la golden answer
- **Reference-free** : juge évalue intrinsèquement

**Pros** :
- Corrélation forte avec human eval (>0.8 sur tasks standards)
- Flexible (n'importe quelle dimension d'évaluation)
- Scalable (vs annotateurs humains)

**Cons** :
- Coût ($$ par API call)
- Biais du juge (préfère textes longs, format markdown, ton du modèle qui l'a entraîné)
- Reproductibilité (température, seeds)
- Validation : LLM-as-judge doit être validé sur sample humain

Outils : G-Eval (Liu 2023), Prometheus, MT-Bench, AlpacaEval, RAGAS.

### 5. Métriques RAG (RAGAS-style)

Spécifiques au RAG :

#### Faithfulness

% des **claims** dans la réponse qui sont **soutenus par le context** retrieved.

Calcul (LLM-as-judge) :
1. Extraire les claims atomiques de la réponse
2. Pour chaque claim, vérifier si **inferrable** du context
3. Faithfulness = fraction supportée

#### Answer relevance

À quel point la réponse traite la **question posée** (cosine entre question et générée).

#### Context precision / recall

Voir [[Ranking metrics]] — Recall@k, Precision@k sur les chunks retrieved par rapport au ground truth.

#### Context utilization

% du context retrieved qui est effectivement **utilisé** dans la réponse.

#### Triad RAGAS : Context Precision + Faithfulness + Answer Relevance

Coupled scoring du pipeline RAG complet : retrieve → augment → generate.

### 6. Code generation

#### Pass@k (Codex paper)

$$ \text{pass@k} = \mathbb{E}\left[1 - \binom{n - c}{k} / \binom{n}{k}\right] $$

avec $n$ samples par problème, $c$ corrects. Probabilité qu'au moins 1 des $k$ samples passe les tests unitaires.

- pass@1 = strict (1 essai)
- pass@10 = avec retries
- Standard HumanEval, MBPP, SWE-Bench

### 7. Safety / harm metrics

- **Refusal rate** : % de refus correct vs incorrects
- **Toxicity** : Perspective API, Detoxify
- **Bias** : BOLD, BBQ benchmarks
- **Hallucination rate** : faithfulness sur tasks groundés
- **Prompt injection success rate** : red-teaming

### Tableau récap

| Métrique | Type | Coût | Sémantique | Standard pour |
|---|---|:-:|:-:|---|
| BLEU | n-gram | gratuit | ✗ | traduction (legacy) |
| ROUGE | n-gram | gratuit | ✗ | summarization |
| BERTScore | embedding | $ | ✓ | génération texte |
| Perplexity | LM | $ | ✓ | pretraining eval |
| LLM-as-judge | LLM | $$$ | ✓ | tout, état de l'art |
| Faithfulness | LLM-as-judge | $$ | ✓ | RAG |
| Pass@k | execution | gratuit | ~ | code gen |
| Toxicity | classifier | $ | ✓ | safety |

### Pipeline d'éval typique en prod

1. **Gold dataset** annoté humain : ~100-500 examples par task
2. **Métriques automatiques** : BERTScore, ROUGE pour bases
3. **LLM-as-judge** : factualité, complétude, ton
4. **Métriques task-specific** : faithfulness (RAG), pass@k (code), refusal (safety)
5. **CI gate** : seuil sur dataset ; fail si régression
6. **A/B test prod** : taux conversion, NPS user, retention
7. **Monitoring** : drift, hallucinations rate via judge sur sample prod

Voir [[Evaluer un systeme LLM]] (workflow détaillé).

### Limitations communes

- **N-gram overlap** : insensible à la sémantique. Deux réponses correctes paraphrasées peuvent scorer 0.
- **LLM-as-judge** : biaisé (préfère format = modèle qui juge, biais positions pairwise)
- **Reference-based** : ne marche que si gold answer existe. Pour open-ended, impossible.
- **Calibration** : un score "4/5" du juge sur 2 sets différents n'est pas comparable.

## Quand c'est utile

- **Évaluation LLM en CI/CD** : eval gate sur dataset gold avant déploiement
- **A/B test de prompts** : comparer 2 prompts sur même metric set
- **Benchmark de modèles** : choisir GPT-4 vs Claude vs open-source
- **Monitoring prod** : LLM-as-judge sur échantillon traffic, alertes
- **Optimisation RAG** : tune retrieval k, embedding model, chunking via Context Precision/Recall
- **Red-teaming** : safety metrics avant lancement
- **Compétitions** : HumanEval, MT-Bench, AlpacaEval

## Quand ça ne marche pas / pièges

- **Métrique unique** : un BLEU élevé peut cacher une mauvaise factualité. Toujours coupler.
- **BLEU/ROUGE sur LLM moderne** : trop strict, ne reflète plus la qualité. Préférer BERTScore + LLM judge.
- **LLM-as-judge avec son propre modèle** : biais auto-évaluation. Utiliser juge tiers (e.g. GPT-4 juge Claude et vice versa).
- **Gold dataset trop petit** : 50 examples = variance énorme. Min 200-500.
- **Dataset contamination** : si le LLM a vu HumanEval en pretraining, scores gonflés.
- **Sur-optimiser un métrique proxy** : entraîner avec ROUGE objective → modèle écrit du salami n-gram, lisible mais creux.
- **A/B test sous-puissé** : LLM differences souvent subtiles → besoin de gros sample. Voir [[A-B testing]].
- **Non-reproductibilité** : LLM judge température > 0 ⇒ scores variables. Fixer T=0, seed.
- **Sécurité ignored** : un modèle plus performant peut être moins safe. Toujours co-evaluer.
- **Eval drift** : LLM judge évolue avec ses updates → re-baseline périodiquement.

## Code minimal

```python
# BLEU
from sacrebleu import corpus_bleu
refs = [["The cat sits on the mat."]]
hyps = ["The cat is on the mat."]
print(f"BLEU = {corpus_bleu(hyps, refs).score:.2f}")

# ROUGE
from rouge_score import rouge_scorer
scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
print(scorer.score("Reference text.", "Hypothesis text."))

# BERTScore
from bert_score import score
P, R, F1 = score(["The cat is on the mat."], ["The cat sits on the mat."],
                  lang='en', verbose=False)
print(f"BERTScore F1 = {F1.mean():.3f}")

# LLM-as-judge (pseudo-code Claude/OpenAI)
import anthropic
client = anthropic.Anthropic()

def judge(question, answer, reference=None):
    prompt = f"""Question: {question}
Answer: {answer}
{f'Reference: {reference}' if reference else ''}

Rate the answer on:
- Accuracy (1-5)
- Completeness (1-5)
- Coherence (1-5)

Output JSON only: {{"accuracy": int, "completeness": int, "coherence": int, "reasoning": "..."}}"""

    response = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=300,
        temperature=0,  # IMPORTANT
        messages=[{"role": "user", "content": prompt}]
    )
    return response.content[0].text

# RAGAS-style faithfulness (sketch)
def faithfulness(answer, context):
    # 1. Extract atomic claims from answer (LLM call)
    # 2. For each claim, verify supported by context (LLM call)
    # 3. Return fraction supported
    pass  # use ragas library directly

# pass@k pour code gen
def pass_at_k(test_results, n, k):
    """test_results: array of bools per sample, n=total samples, k=tries."""
    import math
    c = sum(test_results)
    if n - c < k:
        return 1.0
    return 1 - math.comb(n - c, k) / math.comb(n, k)

# Eval pipeline minimal
gold = [{"question": "...", "answer": "...", "context": "..."}, ...]
def eval_dataset(gold, llm_call):
    results = []
    for example in gold:
        prediction = llm_call(example["question"], example["context"])
        results.append({
            "bertscore": bert_score([prediction], [example["answer"]], lang='en')[2].item(),
            "judge_acc": judge(example["question"], prediction, example["answer"]),
        })
    return results

# Avec ragas
# from ragas import evaluate
# from ragas.metrics import faithfulness, answer_relevancy, context_precision
# results = evaluate(dataset=ds, metrics=[faithfulness, answer_relevancy, context_precision])
```

## Pour aller plus loin

- Papineni et al., *BLEU: a Method for Automatic Evaluation of Machine Translation* (ACL 2002)
- Lin, *ROUGE: A Package for Automatic Evaluation of Summaries* (2004)
- Zhang et al., *BERTScore: Evaluating Text Generation with BERT* (ICLR 2020)
- Liu et al., *G-Eval: NLG Evaluation using GPT-4 with Better Human Alignment* (EMNLP 2023)
- Chen et al., *Evaluating Large Language Models Trained on Code* (Codex, 2021) — pass@k
- *RAGAS* (Shahul et al. 2023), *DeepEval*, *TruLens* — frameworks d'éval RAG
- Anthropic / OpenAI cookbooks sur eval — best practices
- **Liens internes** : [[Perplexity]], [[Ranking metrics]], [[RAG]], [[Evaluer un systeme LLM]], [[A-B testing]]
