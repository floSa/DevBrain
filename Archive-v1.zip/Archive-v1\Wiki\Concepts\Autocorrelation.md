---
galaxie: wiki
nom: Autocorrelation (ACF, PACF)
alias: [Autocorrélation, ACF, PACF]
type: concept
categorie: concept/time-series
sous_categories: [acf, pacf, correlation, arima-identification]
domaines: [data-science, data-eng]
maturite: established
auteurs_cles: [Box & Jenkins 1970]
lecture_min: 10
created: 2026-05-19
modified: 2026-05-19
tags: [concept, time-series, autocorrelation, acf, pacf]
---

# Autocorrelation — ACF et PACF

## TL;DR

L'**ACF** (autocorrelation function) mesure la corrélation entre $X_t$ et $X_{t-k}$ pour différents lags $k$. La **PACF** (partial autocorrelation) mesure cette corrélation **après avoir contrôlé pour les lags intermédiaires**. Lecture visuelle des deux → identification des ordres $p$ (AR) et $q$ (MA) d'un ARIMA. Outil central de la méthode Box-Jenkins.

## Le problème

Sur une série temporelle, on veut savoir :
- Y a-t-il un **effet mémoire** ? La valeur d'hier influence-t-elle celle d'aujourd'hui ?
- À quelle distance temporelle cette dépendance s'estompe ?
- Y a-t-il une **saisonnalité** mesurable ?

L'autocorrélation quantifie ces dépendances pour chaque lag $k$.

## L'idée

### ACF — Autocorrelation Function

Définition pour une série stationnaire :

$$ \rho(k) = \frac{\mathrm{Cov}(X_t, X_{t-k})}{\mathrm{Var}(X_t)} = \frac{\gamma(k)}{\gamma(0)} $$

- $\rho(0) = 1$ par construction
- $\rho(k) \in [-1, 1]$
- Si $|\rho(k)|$ grand → forte dépendance entre $X_t$ et $X_{t-k}$

Estimateur empirique sur un échantillon :

$$ \hat\rho(k) = \frac{\sum_{t=k+1}^n (x_t - \bar x)(x_{t-k} - \bar x)}{\sum_{t=1}^n (x_t - \bar x)^2} $$

### PACF — Partial Autocorrelation Function

Problème de l'ACF : $\rho(2)$ inclut un effet "direct" $X_t \leftarrow X_{t-2}$ **plus** un effet indirect $X_t \leftarrow X_{t-1} \leftarrow X_{t-2}$. La PACF isole l'effet direct.

Définition : $\phi(k)$ est le coefficient de $X_{t-k}$ dans la régression linéaire :

$$ X_t = \phi_1 X_{t-1} + \phi_2 X_{t-2} + \dots + \phi_k X_{t-k} + \varepsilon_t $$

Autrement dit, on enlève l'effet des lags 1 à $k-1$ et on regarde ce qui reste.

Calcul pratique : équations de Yule-Walker récursives (Durbin-Levinson).

### Identification ARIMA via ACF/PACF

C'est le cœur de la méthode Box-Jenkins :

| Modèle | ACF | PACF |
|---|---|---|
| **AR(p)** | décroissance progressive (exponentielle / sinusoïdale) | **cut** brutal après lag $p$ |
| **MA(q)** | **cut** brutal après lag $q$ | décroissance progressive |
| **ARMA(p, q)** | décroissance après lag $q$ | décroissance après lag $p$ |

"Cut" = passe sous les bandes de signification ($\pm 1.96 / \sqrt{n}$) brutalement.

### Saisonnalité dans l'ACF

Si la série est saisonnière de période $s$, l'ACF montre des **pics réguliers** aux multiples de $s$ (lag $s$, $2s$, $3s$…). C'est un diagnostic visuel rapide de la saisonnalité.

## Quand c'est utile

- **Diagnostic** avant modélisation ARIMA / SARIMA
- Détection de la saisonnalité
- Vérifier l'**indépendance des résidus** d'un modèle (un modèle bien ajusté a des résidus dont l'ACF est plate, sinon il reste de l'information non exploitée)
- Test de Ljung-Box sur les résidus (basé sur ACF cumulée)

## Quand ça ne marche pas / pièges

- **Série non-stationnaire** : ACF décroît trop lentement (ne décroît jamais sous la bande) → différencier d'abord (cf. [[Stationarity]])
- **Outliers** : faussent les estimateurs ACF/PACF
- **Saisonnalité multiple** : ACF montre plusieurs pics, identification ARIMA non triviale → utiliser auto-ARIMA / STL decomposition
- **Échantillon petit** : bandes de signification très larges, identification difficile
- **Confusion ACF / PACF** : l'erreur fréquente est de regarder ACF pour AR et PACF pour MA. C'est l'inverse :
  - AR(p) → PACF cut, ACF décroît
  - MA(q) → ACF cut, PACF décroît

## Code minimal

```python
import statsmodels.api as sm
import matplotlib.pyplot as plt
import pandas as pd

ts = pd.Series(...)

# ACF
fig, axes = plt.subplots(2, 1, figsize=(10, 6))
sm.graphics.tsa.plot_acf(ts, lags=40, ax=axes[0])
sm.graphics.tsa.plot_pacf(ts, lags=40, ax=axes[1], method='ywm')
plt.show()

# Test de Ljung-Box sur les résidus d'un modèle
from statsmodels.stats.diagnostic import acorr_ljungbox
lb_test = acorr_ljungbox(residuals, lags=10, return_df=True)
# Si toutes les p-values > 0.05 → résidus indistinguables d'un bruit blanc
```

## Implémentations concrètes

- `statsmodels.tsa.stattools.acf`, `pacf`, `plot_acf`, `plot_pacf`
- `pandas.plotting.autocorrelation_plot` — version simple
- R : `forecast::ggAcf`, `forecast::ggPacf` (Hyndman, magnifiques visualisations)

## Pour aller plus loin

- Box, Jenkins, *Time Series Analysis: Forecasting and Control* (1970, étendu à 2015)
- Hyndman, *Forecasting: Principles and Practice* (FPP3) — chap. 9 sur ARIMA et identification
- **Liens internes** : [[Stationarity]], [[Walk-forward CV]], [[Forecasting framing]]
