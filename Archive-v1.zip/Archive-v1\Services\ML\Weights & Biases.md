---
galaxie: dev
nom: Weights & Biases
alias: [wandb, w-and-b, weights-and-biases]
categorie: ml/tracking
sous_categories: [tracking, experiments, ml-ops, sweeps, artifacts, llm-observability]
licence: Proprietaire
licence_type: proprietary
hosted: managed
maturite: production
langage: Python (backend interne)
clients_officiels: [python, julia]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[MLflow]]", "[[Aim]]", "[[ClearML]]", "[[Comet]]", "[[Neptune]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, tracking, experiments, observability]
url_officiel: https://wandb.ai/
url_docs: https://docs.wandb.ai/
url_repo: https://github.com/wandb/wandb
---

# Weights & Biases

## Pourquoi

**Plateforme #1 de tracking d'expériences ML/DL** (cloud-first). UX très polish, sweeps (hyperparameter search managed), artifacts versioning, reports collaboratifs, **Weave** (observability LLM récente, équivalent Langfuse / LangSmith). Utilisé par OpenAI, Anthropic, Stability AI, NVIDIA, Cohere — devenu un standard de fait dans la recherche ML.

Vs [[MLflow]] : W&B = cloud-natif premium ; MLflow = open self-host gratuit, moins de polish UX. Vs [[Aim]] : Aim = local-first open, W&B = collaborative cloud.

## Quand l'utiliser

- **Tracking expériences ML / DL sérieux** : loss, metrics, hyperparams, code version, system metrics (GPU/CPU/RAM)
- **Sweeps** : HP search managé (Bayesian, Grid, Random) avec early stopping
- **Artifacts** : versioning datasets + modèles + reports avec lineage
- **Reports collaboratifs** : partager analyses + plots avec l'équipe / management
- **LLM observability via Weave** : tracing LLM calls + evals
- **Compare runs** côte à côte : interactive plots, scatter HP vs metric
- **Resume** : reprise de training après crash
- **Stack premium recherche** : si tu travailles dans une lab IA, c'est probablement déjà là

## Quand NE PAS l'utiliser

- **Self-host obligatoire** → [[MLflow]] (W&B Server = deal Enterprise cher)
- **Budget zéro** → [[MLflow]] open ou [[Aim]] (open + light)
- **Stack léger sans cloud** → [[Aim]] (UI locale rapide)
- **Compliance / on-prem strict** → MLflow / ClearML on-prem
- **Données ultra-sensibles** sans accord W&B → préférer self-host
- **Logs LLM uniquement** sans ML training → [[Langfuse]] / [[Helicone]] suffisent

## Pièges connus

- **Cloud only par défaut** (free tier généreux mais cloud uniquement). W&B Server (self-host) = deal Enterprise (négocier).
- **Pricing volume** : free tier OK perso. Team / Enterprise tarifs progressifs par seat + storage + GPU hours tracked → peut surprendre.
- **Lock-in modéré** : export possible (`wandb-export`) mais friction (notebooks Reports, plots custom).
- **Logging hooks ralentissent training** : `wandb.log(step=x)` peut bloquer si réseau lent. Utiliser `wandb.log({}, commit=False)` pour batcher, ou async mode.
- **Code-saving** : peut capturer accidentellement secrets (.env). Configurer `save_code=False` ou utiliser `.wandbignore`.
- **System metrics** : `wandb.init()` lance un thread qui poll GPU/CPU — overhead non négligeable sur boucles très rapides.
- **Sweeps** : agent doit tourner H24, pas serverless. `wandb agent SWEEP_ID` à monitorer.
- **Multi-process / DDP** : `wandb.init` une fois par process, sinon doublons. Mode `wandb.init(group="...")` pour grouper.

## Code minimal

```python
# pip install wandb
import wandb

# Auth via WANDB_API_KEY env var ou `wandb login`
wandb.init(
    project="my-llm-finetune",
    name="experiment-42",
    config={                           # hyperparams trackés
        "learning_rate": 2e-5,
        "epochs": 3,
        "batch_size": 8,
        "model": "Llama-3.1-8B",
    },
    tags=["sft", "lora"],
)

# Log training loop
for epoch in range(wandb.config.epochs):
    for step, batch in enumerate(dataloader):
        loss = train_step(batch)
        wandb.log({"loss": loss, "step": step}, step=step)

    val_loss, val_acc = validate()
    wandb.log({"val_loss": val_loss, "val_acc": val_acc, "epoch": epoch})

# Artifacts : versioning du modèle
artifact = wandb.Artifact("my-model", type="model", metadata={"f1": 0.92})
artifact.add_file("model.safetensors")
wandb.log_artifact(artifact)

wandb.finish()

# --- Sweeps ---
sweep_config = {
    "method": "bayes",
    "metric": {"name": "val_loss", "goal": "minimize"},
    "parameters": {
        "learning_rate": {"distribution": "log_uniform_values", "min": 1e-6, "max": 1e-3},
        "batch_size": {"values": [4, 8, 16, 32]},
    },
}
sweep_id = wandb.sweep(sweep_config, project="my-llm-finetune")
# Puis run agent :
#   wandb agent SWEEP_ID
# (peut être distribué sur plusieurs machines simultanément)

# --- Weave (LLM observability) ---
# pip install weave
import weave
weave.init("my-rag-app")

@weave.op()
def rag_query(question: str) -> str:
    docs = retrieve(question)
    return llm_generate(question, docs)
# Chaque appel est tracé dans Weave dashboard (latence, cost, inputs, outputs)
```

## Liens

- [[MLflow]] — alt open self-host
- [[Aim]] — alt open léger
- [[Comet]] / [[Neptune]] / [[ClearML]] — alt cloud
- [[Optuna]] / [[Ray Tune]] — alt sweeps (sans cloud)
- **Weave** (W&B LLM) : https://weave.dev/
- Docs W&B : https://docs.wandb.ai/
- Pricing : https://wandb.ai/site/pricing
- GitHub : https://github.com/wandb/wandb
