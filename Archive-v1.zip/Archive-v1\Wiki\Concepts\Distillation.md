---
galaxie: wiki
nom: Knowledge distillation
alias: [distillation, knowledge transfer, teacher-student, DistilBERT, TinyBERT]
type: concept
categorie: concept/llm-training
sous_categories: [distillation, compression, llm, small-models]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Hinton 2015]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, distillation, compression]
---

# Knowledge distillation

## TL;DR

Transférer la **connaissance** d'un gros modèle "teacher" vers un **petit modèle "student"**. Hinton 2015 : entraîner student sur les **soft labels** (logit distribution) du teacher, pas juste hard labels. Résultats : petits modèles **boostés** (DistilBERT, TinyBERT, MiniLM, Phi), **inférence rapide**, capacité préservée à 90-95%. Étend à : **distillation de raisonnement** (Llama-3.1-Tulu-3-8B distillé de 70B), **on-policy distillation** (student génère, teacher corrige), **speculative decoding** (utilise small model pour accélérer big). Standard 2026 : petits modèles open (Phi-4, Gemma-2-2B, SmolLM 3) sont en réalité fortement distillés.

## Le problème

Gros LLM trop coûteux pour :
- Edge / mobile (mémoire limitée)
- Production high-QPS (cost prohibitive)
- Latency-sensitive (TTFT important)

Comment **transférer** la capacité d'un 70B vers un 7B viable ?

## L'idée

### Distillation classique (Hinton 2015)

Teacher $T$ produit **soft labels** (distribution sur classes) :

$$ p_T(y|x) = \text{softmax}(z_T / \tau) $$

avec $\tau$ **temperature** (> 1 lisse la distribution → révèle "dark knowledge").

Student $S$ entraîné pour matcher :

$$ L = \alpha \cdot \text{CE}(y, p_S) + (1-\alpha) \cdot \text{KL}(p_T || p_S) $$

Combine **hard label loss** (standard) + **soft KL** (distillation).

### Types de distillation

#### Response-based (logits)

Le standard, ci-dessus. Match logits / probabilities.

#### Feature-based

Match **hidden states** intermédiaires :

$$ L_{feat} = \|h_T^{(i)} - h_S^{(i)}\|^2 $$

Plus expressif mais nécessite arch compatible.

#### Relation-based

Match **relations** entre samples (e.g. distances entre paires d'examples) plutôt que valeurs absolues.

#### On-policy vs off-policy

- **Off-policy** : student apprend sur dataset pré-généré par teacher
- **On-policy** : student génère sa propre output, teacher corrige (mieux pour LLM, évite distribution shift)

#### Black-box distillation

Si teacher accessible que par API (no logits) : utiliser **outputs (samples)** comme training data. Standard pour distill GPT-4 → Llama.

### Distillation classique pour BERT/NLP

#### DistilBERT (Sanh 2019)

Distill BERT-base (110M) → DistilBERT (66M) :
- 40% smaller
- 60% faster
- **97% de la perf** sur GLUE

Recipe : KL distillation + cosine similarity sur hidden states + MLM standard.

#### TinyBERT (Jiao 2020)

Two-stage distillation (pretraining + task-specific).

#### MiniLM (Wang 2020)

Distill attention distributions + relations entre attention values. Standard pour embeddings (all-MiniLM-L6).

### Distillation LLM moderne

#### Phi family (Microsoft)

**Insight Phi** : "textbook quality" data + distillation = SLM compétitif.

- Phi-1 (1.3B) : code, distillé de GPT-3.5 generated data
- Phi-2 (2.7B), Phi-3 (3.8B mini), Phi-3.5, Phi-4 (14B) — chacun bat des modèles plus gros

#### Distill-Whisper (Gandhi 2023)

Distill Whisper-large (1.5B) → Distil-Whisper (756M, 50% plus rapide).

#### DeepSeek-R1 distillation

DeepSeek-R1 (671B) → distill traces sur Llama 8B / 70B, Qwen 7B / 14B / 32B → tous gagnent en reasoning.

#### Gemma 2 distillation

Gemma 2 2B / 9B distillés de Gemma 2 27B avec techniques avancées.

#### Llama-3.1-Tulu-3-8B / 70B

AllenAI : SFT + DPO avec on-policy distillation. SOTA open small models.

### Synthetic data via distillation

**Approche moderne** : générer du data de training avec un gros teacher.

- Self-Instruct (basé teacher = GPT-3)
- Cosmopedia (HF) : 25B tokens synthétiques généré par teacher
- OpenMathInstruct (NVIDIA) : math via teacher
- Llama 3 fine-tuning data : généré en partie via Llama 3 70B → distill vers 8B

**Risque** : **model collapse** (Shumailov 2024) — recursive training sur data généré dégrade. Need real human data mix.

### Speculative decoding (distillation pour speed-up)

Utiliser **small model** (draft) pour propose plusieurs tokens, **big model** vérifie. Le draft est souvent distillé du big.

Voir [[Speculative decoding]] pour détails.

### Match Distillation vs Fine-tuning

| Aspect | Distillation | Fine-tuning seul |
|---|---|---|
| Teacher needed | ✓ | ✗ |
| Data type | distill teacher output | labeled human |
| Small student perf | excellente | limited |
| Cost | élevé (teacher inference) | modéré |
| Use case | small fast model | n'importe quel model |

### Best practices

1. **On-policy** > off-policy quand possible (student génère, teacher corrige)
2. **Temperature** $\tau = 2-5$ pour révéler dark knowledge
3. **Mix data** : distill + human data → robustesse
4. **Eval generalization** : student peut overfit teacher's biases
5. **Multi-teacher** : combine plusieurs experts
6. **Filter teacher outputs** : qualité critique, sinon distill garbage
7. **Match arch** quand possible : same family teacher/student
8. **Pretrain student** d'abord : init mieux que random
9. **Curriculum** : easy → hard distillation

## Quand c'est utile

- **Production cost reduction** : 7B distillé peut suffire à 90% des use cases d'un 70B
- **Edge deployment** : on-device LLM (Phi-4, Gemma 2)
- **High QPS apps** : serving cheaper
- **Speed-critical** : speculative decoding accélère 2-3x
- **Specialized SLM** : reasoning, code, multilingue
- **Open-source ecosystems** : democratize via small models
- **Multimodal compression** : Distil-Whisper, MobileVLM
- **Industry-specific** : médical, legal SLMs distillés

## Quand ça ne marche pas / pièges

- **Teacher bias** : student hérite des biais du teacher (sometimes worse)
- **Model collapse** : training recursif sur synthetic data dégrade
- **Calibration shift** : student moins calibré que teacher
- **Edge cases lost** : teacher gère rare cases, student rate
- **Black-box distillation** : sans logits, info perdue
- **Distillation gap reste** : on ne récupère **pas** toute la perf
- **Cost of teacher** : génér data avec GPT-4 est cher
- **Over-distill** : student overfit teacher → ne généralise pas
- **Wrong teacher** : distill un mauvais teacher = SLM avec ses défauts
- **Synthetic eval contamination** : si test set fuit dans synthetic train

## Code minimal

```python
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer

# Setup teacher (Llama 3 70B) et student (Llama 3 8B)
teacher_id = "meta-llama/Meta-Llama-3-70B"
student_id = "meta-llama/Meta-Llama-3-8B"

teacher = AutoModelForCausalLM.from_pretrained(teacher_id, torch_dtype=torch.bfloat16, device_map="auto")
student = AutoModelForCausalLM.from_pretrained(student_id, torch_dtype=torch.bfloat16, device_map="auto")
tokenizer = AutoTokenizer.from_pretrained(teacher_id)

teacher.eval()  # frozen

def distill_loss(student_logits, teacher_logits, labels, tau=2.0, alpha=0.5):
    # CE loss on hard labels
    ce = F.cross_entropy(
        student_logits.view(-1, student_logits.size(-1)),
        labels.view(-1),
        ignore_index=-100
    )
    
    # KL divergence on soft labels (with temperature)
    s_log_probs = F.log_softmax(student_logits / tau, dim=-1)
    t_probs = F.softmax(teacher_logits / tau, dim=-1)
    kl = F.kl_div(s_log_probs, t_probs, reduction='batchmean') * (tau ** 2)
    
    return alpha * ce + (1 - alpha) * kl

# Training loop (off-policy)
for batch in dataloader:
    input_ids = batch["input_ids"]
    labels = batch["labels"]
    
    # Get teacher logits (no grad)
    with torch.no_grad():
        teacher_outputs = teacher(input_ids)
        teacher_logits = teacher_outputs.logits
    
    # Student forward
    student_outputs = student(input_ids)
    student_logits = student_outputs.logits
    
    loss = distill_loss(student_logits, teacher_logits, labels)
    loss.backward()
    optimizer.step()
    optimizer.zero_grad()

# On-policy distillation (student génère, teacher juge/corrige)
def on_policy_step(student, teacher, prompt_ids, tokenizer, max_len=200):
    # Student generates
    with torch.no_grad():
        student_gen = student.generate(prompt_ids, max_new_tokens=max_len, do_sample=True)
    
    # Teacher provides logits for student's generation
    with torch.no_grad():
        teacher_outputs = teacher(student_gen)
    
    # Student re-forwards (with grad) for distillation
    student_outputs = student(student_gen)
    
    loss = distill_loss(student_outputs.logits, teacher_outputs.logits, ...)
    return loss

# Black-box distillation : generate synthetic data from teacher API
def generate_synthetic_data(teacher_api, prompts, n_samples=10000):
    data = []
    for prompt in prompts:
        response = teacher_api.generate(prompt)
        data.append({"prompt": prompt, "response": response})
    return data

# Distill via TRL avec generated data
# from trl import SFTTrainer
# trainer = SFTTrainer(model=student, train_dataset=synthetic_dataset, ...)

# Eval distilled model
# from lm_eval import simple_evaluate
# results = simple_evaluate(student, tasks=["mmlu", "hellaswag"], batch_size=8)
# Compare to teacher_results — measure distillation gap
```

## Pour aller plus loin

- Hinton, Vinyals, Dean, *Distilling the Knowledge in a Neural Network* (NIPS Workshop 2015) — papier fondateur
- Sanh et al., *DistilBERT, a distilled version of BERT* (2019)
- Jiao et al., *TinyBERT: Distilling BERT for Natural Language Understanding* (EMNLP 2020)
- Gunasekar et al., *Textbooks Are All You Need* (Phi-1, 2023)
- Gandhi et al., *Distil-Whisper: Robust Knowledge Distillation via Large-Scale Pseudo Labelling* (2023)
- DeepSeek-AI, *DeepSeek-R1 Technical Report* (2025) — distillation pour reasoning
- Shumailov et al., *The Curse of Recursion: Training on Generated Data Makes Models Forget* (2023) — model collapse
- **Liens internes** : [[SFT]], [[KL divergence]], [[Speculative decoding]], [[Small Language Models]], [[Synthetic data generation]], [[Cross-entropy]]
