---
galaxie: wiki
nom: Boxed Expressions
alias: [boxed-expressions, dmn-boxed, literal-expression, invocation, context, function-definition]
type: concept
categorie: concept/business-rules
sous_categories: [dmn, boxed-expressions, decision-logic, feel]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [OMG, Bruce Silver]
lecture_min: 8
created: 2026-05-21
modified: 2026-05-21
tags: [concept, dmn, boxed-expressions]
---

# Boxed Expressions

## TL;DR

Une **décision DMN** n'est pas forcément une decision table. Le standard définit **10+ formes graphiques** pour exprimer la logique : **Decision Table** (la plus connue), **Literal Expression** (formule FEEL inline), **Invocation** (appel d'un BKM), **Function Definition** (corps d'un BKM), **Context** (struct key-value), **List**, **Relation** (table de données), **Conditional**, **Iterator**, **Filter** (depuis DMN 1.4). Chacune a une **représentation graphique en boîte** (d'où le nom "boxed") qui rend le calcul lisible visuellement, même pour des expressions complexes. C'est ce qui distingue DMN d'un simple "Excel avec règles".

## Le problème

Decision tables sont parfaites pour des conditions discrètes. Mais :
- Comment exprimer une **formule mathématique** ? (calcul de mensualité)
- Comment **invoquer un BKM** réutilisable depuis une décision ?
- Comment **structurer un résultat composite** (struct avec plusieurs champs) ?
- Comment **décrire un dataset** (tableau de valeurs) en entrée ?
- Comment **itérer sur une liste** (DMN 1.4+) ?

→ DMN définit une **palette de "boxes"** pour chacun de ces cas, toutes interchangeables et composables.

## L'idée

### Les 10 formes principales

#### 1. Decision Table

La référence, vue dans [[Decision Tables]]. Lignes = règles, colonnes = inputs/outputs, hit policy.

```
┌──────────────────────────────┐
│ Eligibility       U          │
├──────┬───────┬───────────────┤
│ Age  │Income │ → Eligibility │
├──────┼───────┼───────────────┤
│ <25  │  -    │ "refused"     │
│[25..]│ >30k  │ "accepted"    │
└──────┴───────┴───────────────┘
```

#### 2. Literal Expression

Une seule expression FEEL. La plus simple.

```
┌─────────────────────────────────────┐
│ Monthly payment                     │
├─────────────────────────────────────┤
│ amount * rate / (1 - (1+rate)**-n)  │
└─────────────────────────────────────┘
```

#### 3. Invocation

Appel d'un BKM avec **bindings** explicites (parameter → expression).

```
┌─────────────────────────────────────┐
│ Loan capacity                       │
├─────────────────────────────────────┤
│  calculer_taux                      │   ← nom du BKM invoqué
├─────────────┬───────────────────────┤
│ amount      │ customer.income * 7   │
│ rate        │ market.current_rate   │
│ duration    │ request.years         │
└─────────────┴───────────────────────┘
```

#### 4. Function Definition

Le **corps d'un BKM** : paramètres formels + expression.

```
┌─────────────────────────────────────┐
│ FUNCTION  loan_capacity_formula     │
├─────────────────────────────────────┤
│ (amount, rate, duration)            │   ← parameters
├─────────────────────────────────────┤
│ amount * rate * (1+rate)**duration  │   ← body (literal expression)
│ / ((1+rate)**duration - 1)          │
└─────────────────────────────────────┘
```

#### 5. Context

**Décomposition** d'un calcul en étapes nommées (équivalent d'un struct ou d'un `let ... in ...`).

```
┌─────────────────────────────────────┐
│ Final scoring                       │
├──────────────┬──────────────────────┤
│ base_score   │ ml_model(features)   │
│ adjustment   │ if customer.vip      │
│              │   then 0.1 else 0    │
│ final_score  │ base_score+adjustment│
├──────────────┼──────────────────────┤
│  <result>    │ final_score          │   ← FINAL RESULT (optionnel)
└──────────────┴──────────────────────┘
```

Les variables intermédiaires sont calculées dans l'ordre, et la dernière entrée (ou `<result>`) est le résultat.

#### 6. List

Construction d'une liste (équivalent literal liste).

```
┌─────────────────────────────┐
│ Allowed countries           │
├─────────────────────────────┤
│ "FR"                        │
│ "BE"                        │
│ "CH"                        │
│ "LU"                        │
└─────────────────────────────┘
```

#### 7. Relation

Une **table de données** (pas de décision) : lignes = entrées, colonnes = champs.

```
┌──────────────────────────────────────────────┐
│ VAT rates by country                          │
├──────────┬──────────┬──────────────────────────┤
│ country  │ standard │ reduced                 │
├──────────┼──────────┼──────────────────────────┤
│ "FR"     │ 0.20     │ 0.055                   │
│ "DE"     │ 0.19     │ 0.07                    │
│ "BE"     │ 0.21     │ 0.06                    │
└──────────┴──────────┴──────────────────────────┘
```

Équivalent FEEL : `[{country: "FR", standard: 0.20, reduced: 0.055}, ...]`.

#### 8. Conditional (DMN 1.4+)

`if ... then ... else` sous forme boxed.

```
┌─────────────────────────────────────┐
│ IF                                  │
│   customer.age >= 18                │
├─────────────────────────────────────┤
│ THEN                                │
│   "adult"                           │
├─────────────────────────────────────┤
│ ELSE                                │
│   "minor"                           │
└─────────────────────────────────────┘
```

#### 9. Iterator (DMN 1.4+)

`for ... in ... return ...` boxed (équivalent map / forEach).

```
┌─────────────────────────────────────┐
│ FOR                                 │
│   c                                 │   ← variable
├─────────────────────────────────────┤
│ IN                                  │
│   customers                         │   ← collection
├─────────────────────────────────────┤
│ RETURN                              │
│   c.amount * 1.20                   │   ← expression
└─────────────────────────────────────┘
```

#### 10. Filter (DMN 1.4+)

Filtrage d'une liste avec prédicat.

```
┌─────────────────────────────────────┐
│ FILTER                              │
│   customers                         │   ← list
├─────────────────────────────────────┤
│ MATCH                               │
│   item.amount > 1000                │   ← predicate
└─────────────────────────────────────┘
```

### Composition

Toutes les boxes sont **composables** : une cellule de decision table peut contenir une literal expression, une cellule de context peut être une invocation, etc.

Exemple : décision finale = context qui contient une invocation et une conditional.

```
┌──────────────────────────────────────────────────────┐
│ FINAL DECISION (context)                              │
├───────────────┬───────────────────────────────────────┤
│ capacity      │  invoke loan_capacity_formula(...)   │
│ accept        │  if capacity > request.amount        │
│               │     then "accept" else "decline"     │
│ <result>      │  {decision: accept, capacity: capa.} │
└───────────────┴───────────────────────────────────────┘
```

### Pourquoi "boxed" ?

L'intention OMG : rendre chaque type d'expression **visuellement distinct** dans un éditeur, pour que le métier reconnaisse au coup d'œil "ça c'est une formule", "ça c'est un appel de fonction", "ça c'est un struct". Au lieu d'avoir tout en code FEEL plat (qui ressemble vite à du Python compact), tu as des **boîtes étiquetées**.

C'est ce qui distingue un outil DMN d'un simple éditeur Excel + rules engine.

### Sérialisation XML

Chaque boxed expression a son tag XML :
- `<decisionTable>`, `<literalExpression>`, `<invocation>`, `<functionDefinition>`, `<context>`, `<list>`, `<relation>`, `<conditional>`, `<for>`, `<filter>`

Le moteur DMN parse l'arbre et évalue récursivement.

### Quel format pour quoi ?

| Cas | Forme recommandée |
|---|---|
| Règles discrètes (matching) | Decision Table |
| Formule mathématique | Literal Expression |
| Appel d'une fonction réutilisable | Invocation |
| Définir une fonction | Function Definition (dans un BKM) |
| Calcul en étapes nommées | Context |
| Tableau de référence (constants) | Relation |
| Liste statique de valeurs | List |
| Branchement simple | Conditional (ou table à 2 lignes) |
| Map / forEach sur collection | Iterator |
| Filter une collection | Filter (ou literal expression avec FEEL filter) |

## Quand c'est utile

- **Tu ne peux pas exprimer ta décision en table** : formule mathématique, structure complexe → literal / context / function
- **Réutiliser une logique** : extract en BKM (function), invoque-la depuis plusieurs décisions
- **Décomposer un calcul long** : context avec étapes nommées (équivalent comments + variables)
- **Tableau de paramètres** : VAT rates par pays, scores par segment → relation
- **DMN 1.4+** : conditional / iterator / filter rendent FEEL plus accessible visuellement (pas besoin de comprehensions FEEL inline)
- **Architecture propre** : 1 décision = 1 BKM appelé via invocation, séparation interface/implémentation

## Quand ça ne marche pas / pièges

- **Sur-utilisation de context** : un context à 10 étapes devient illisible — refactor en BKM
- **Literal expression trop longue** : si ta formule dépasse 5 lignes, c'est probablement un BKM à extraire
- **Conditional imbriqué profond** : 5 niveaux de if-then-else → une decision table serait plus claire
- **Outils ne supportent pas tous** : DMN 1.4 conditional/iterator/filter pas dans tous les engines (vérifier la version)
- **Iterator vs FEEL `for`** : équivalents sémantiquement, l'iterator boxed est plus lisible visuellement mais plus verbeux à éditer
- **Relation vs liste de contexts** : préférer relation si tu as un schéma fixe (3+ entrées avec mêmes champs)
- **Confusion BKM vs invocation** : le BKM **définit** la fonction (function definition), l'invocation **l'appelle** — deux décisions distinctes
- **Bindings d'invocation incomplets** : oublier de mapper un paramètre = erreur runtime
- **Function definition standalone** : une fonction n'est utile qu'invoquée → toujours dans un BKM
- **Box trop "graphique"** sur écran petit : sur un laptop 13", certains modèles deviennent illisibles → préférer le mode "compact" / FEEL plat quand on collabore en remote

## Code minimal

### Literal expression (XML)

```xml
<decision id="monthlyPayment" name="Monthly payment">
  <variable name="monthly_payment" typeRef="number"/>
  <informationRequirement>
    <requiredInput href="#amount"/>
  </informationRequirement>
  <literalExpression>
    <text>amount * rate * (1 + rate) ** n / ((1 + rate) ** n - 1)</text>
  </literalExpression>
</decision>
```

### Context

```xml
<decision id="finalScore" name="Final Score">
  <variable name="final_score" typeRef="number"/>
  <context>
    <contextEntry>
      <variable name="base" typeRef="number"/>
      <literalExpression><text>ml_score</text></literalExpression>
    </contextEntry>
    <contextEntry>
      <variable name="bonus" typeRef="number"/>
      <literalExpression>
        <text>if customer.tier = "VIP" then 0.1 else 0</text>
      </literalExpression>
    </contextEntry>
    <contextEntry>
      <!-- Résultat final (pas de variable nommée) -->
      <literalExpression><text>base + bonus</text></literalExpression>
    </contextEntry>
  </context>
</decision>
```

### Invocation d'un BKM

```xml
<decision id="loanCapacity" name="Loan Capacity">
  <knowledgeRequirement>
    <requiredKnowledge href="#loanFormulaBKM"/>
  </knowledgeRequirement>
  <invocation>
    <literalExpression><text>loanFormula</text></literalExpression>
    <binding>
      <parameter name="amount" typeRef="number"/>
      <literalExpression><text>customer.income * 7</text></literalExpression>
    </binding>
    <binding>
      <parameter name="rate" typeRef="number"/>
      <literalExpression><text>market.rate</text></literalExpression>
    </binding>
    <binding>
      <parameter name="duration" typeRef="number"/>
      <literalExpression><text>20</text></literalExpression>
    </binding>
  </invocation>
</decision>
```

### Function Definition (dans un BKM)

```xml
<businessKnowledgeModel id="loanFormulaBKM" name="loanFormula">
  <encapsulatedLogic kind="FEEL">
    <formalParameter name="amount" typeRef="number"/>
    <formalParameter name="rate" typeRef="number"/>
    <formalParameter name="duration" typeRef="number"/>
    <literalExpression>
      <text>amount * rate / (1 - (1 + rate) ** -duration)</text>
    </literalExpression>
  </encapsulatedLogic>
</businessKnowledgeModel>
```

### Relation (table de constants)

```xml
<decision id="vatRates" name="VAT Rates">
  <relation>
    <column name="country" typeRef="string"/>
    <column name="standard" typeRef="number"/>
    <column name="reduced" typeRef="number"/>
    <row>
      <literalExpression><text>"FR"</text></literalExpression>
      <literalExpression><text>0.20</text></literalExpression>
      <literalExpression><text>0.055</text></literalExpression>
    </row>
    <row>
      <literalExpression><text>"DE"</text></literalExpression>
      <literalExpression><text>0.19</text></literalExpression>
      <literalExpression><text>0.07</text></literalExpression>
    </row>
  </relation>
</decision>
```

## Pour aller plus loin

- OMG DMN spec, section 7 (Boxed Expressions) : https://www.omg.org/spec/DMN/
- Bruce Silver, *DMN Method and Style*, ch. 12-14 (boxed expressions et BKM)
- DMN TCK boxed expressions tests : https://github.com/dmn-tck/tck
- Camunda Modeler — éditeur visuel WYSIWYG des boxed : https://camunda.com/download/modeler/
- DMN-js (rendu HTML des boxed) : https://github.com/bpmn-io/dmn-js
- **Liens internes** : [[Decision Model and Notation]], [[Decision Tables]], [[FEEL]], [[BKM - Business Knowledge Model]], [[DMN Conformance Levels]]
