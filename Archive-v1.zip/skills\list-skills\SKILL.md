---
name: list-skills
description: |
  Use this skill to get a comprehensive inventory of all DevBrain skills,
  combining executable custom skills (AI/skills/) and the wiki catalogue
  of external tools (Wiki/Outils/). Triggers: "liste mes skills", "qu'est
  ce que j'ai comme skills", "show me all skills", "inventaire skills".
  Output: grouped Markdown table sorted by galaxie/type.
---

# Skill — list-skills

## Quand l'utiliser

L'utilisateur veut une **vue d'ensemble** de tout ce qui est dispo dans son brain côté skills/outils :
- Skills exécutables custom (AI/skills/) : ceux que Claude peut invoquer dans cette session
- Outils catalogués (Wiki/Outils/) : Claude Code skills, MCP, CLI, etc., descriptifs

Sortie unifiée, pour qu'il sache "qu'est-ce que j'ai à dispo" sans devoir naviguer plusieurs dossiers.

## Pré-requis vault

Lecture seule. Aucun mode imposé.

## Procédure

### 1. Inventaire exécutables — `AI/skills/`

Pour chaque sous-dossier de `AI/skills/`, lire le `SKILL.md` et extraire :
- `name`
- 1ère ligne de `description` (résumé)

Groupe ces skills par "galaxie cible" (déduite de la description) :
- **DEV** : opère sur Services/, Bugs/, Patterns/, Rules/
- **WIKI** : opère sur Wiki/*
- **META** : opère sur le brain entier (process-inbox, cross-link, audit-skills, list-skills, etc.)

### 2. Inventaire catalogue — `Wiki/Outils/`

Pour chaque `.md` sous `Wiki/Outils/**`, lire le frontmatter et extraire :
- `nom`, `type`, `plateforme`, `status`, `score`

Groupe par sous-dossier (Claude-Code, Obsidian, MCP-Servers, CLI-Tools).

### 3. Présenter

Format proposé :

```markdown
# Inventaire skills DevBrain — YYYY-MM-DD

## 🟣 SKILLS exécutables (AI/skills/) — N skills

### DEV (X)
| Skill | Rôle |
|---|---|
| `add-service` | Créer une fiche Service |
| ...

### WIKI (Y)
...

### META (Z)
...

## 🟢 WIKI — Outils catalogués (Wiki/Outils/) — M fiches

### Claude-Code (X) — anthropic-*, claude-*
| Outil | Type | Status | Score |
|---|---|---|---|
| anthropic-xlsx | claude-code-skill | discovered | — |
| ...

### Obsidian (Y)
...

### MCP-Servers (Z)
...

### CLI-Tools (W)
...

## Stats globales
- Skills exécutables : N (X dev, Y wiki, Z meta)
- Outils catalogués : M (dont K en `used`, L à tester)
```

### 4. Suggestions actions

À la fin du rapport, proposer :
- Outils `discovered` depuis > 30j → invoquer `audit-skills`
- Skills mentionnés sans fiche outil correspondante (gap doc)
- Outils `used` sans `score:` rempli

## Anti-patterns à éviter

- **Sortir un mur de texte** sans grouping → toujours grouper par galaxie/sous-dossier
- **Manquer des skills** : lister `AI/skills/*/SKILL.md` exhaustivement, pas seulement ceux mémorisés
- **Confondre exécutable et catalogué** : un MCP est *catalogué* dans Wiki/Outils/ mais *exécuté* via la config Claude. Pas le même

## Voir aussi

- `audit-skills` (hygiène du catalogue Wiki/Outils/)
- `validate-skill` (vérifie le format des SKILL.md exécutables)
- `add-custom-skill` (créer un nouveau skill exécutable)
