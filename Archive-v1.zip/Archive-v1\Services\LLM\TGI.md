---
galaxie: dev
nom: TGI
alias: [tgi, text-generation-inference]
categorie: llm/inference
sous_categories: [inference, serving, huggingface, quantization, batching]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Rust + Python
clients_officiels: [python, ts, rest, openai-compat]
plateforme: [linux, macos, windows (Docker)]
score: 4
mes_projets: []
alternatives: ["[[vLLM]]", "[[SGLang]]", "[[TensorRT-LLM]]", "Ollama"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, inference, serving, huggingface]
url_officiel: https://github.com/huggingface/text-generation-inference
url_docs: https://huggingface.co/docs/text-generation-inference/
url_repo: https://github.com/huggingface/text-generation-inference
---

# TGI

## Pourquoi

**Text Generation Inference** — serveur d'inférence LLM par Hugging Face. Container Docker production-ready, intégration native HF Hub (1 modèle = 1 env var), continuous batching, Flash Attention v2/v3, prefix caching, support quantization (GPTQ, AWQ, EETQ, bitsandbytes, GGUF), streaming, OpenAI-compatible endpoint.

Alternative production à [[vLLM]] avec une orientation **HuggingFace-natif** plus prononcée — pratique si tu déploies déjà des modèles HF Hub et veux servir avec un seul env var.

## Quand l'utiliser

- **Stack HuggingFace existante** : modèles HF Hub déployés en 1 commande
- **Quantization variée** : AWQ / GPTQ / EETQ / bitsandbytes / GGUF supportés
- **Combo HF Inference Endpoints** (managed) : TGI tourne dessous, transition self-host smooth
- **Multi-LoRA serving** (depuis v2) : plusieurs LoRA adapters sur même base
- **Modèles propriétaires** (gated HF Hub) : auth HF token natif
- **Speculative decoding** (Medusa)

## Quand NE PAS l'utiliser

- **Performance throughput maximale** → [[vLLM]] reste souvent leader sur benchmarks bruts
- **Modèles custom non-HF** → vLLM / SGLang plus flexibles
- **Apple Silicon / Mac dev** → [[llama.cpp]] / [[Ollama]] / MLX
- **CPU-only inference** → [[llama.cpp]] / Ollama (TGI = GPU)
- **Setup ultra-léger** → [[Ollama]] pour dev local
- **Stack TensorRT optimisée NVIDIA H100/H200** → [[TensorRT-LLM]] (NVIDIA-natif)

## Pièges connus

- **Licence change historique** : HFOIL (non-OSI, restrictive) en 2023 → retour **Apache 2.0** fin 2023. Sur les versions ≥ 2.0, OK pour usage commercial.
- **Moins de bleeding-edge** vs vLLM (vLLM adopte plus vite les optims publiées : PagedAttention v2, async output processing)
- **Configs env vars verbeuses** : `MODEL_ID`, `QUANTIZE`, `MAX_TOTAL_TOKENS`, `MAX_BATCH_PREFILL_TOKENS`, etc. — tuning à faire
- **Versions Docker** : pin tag (`2.x.x`) sinon breakages
- **Sharding multi-GPU** : config `NUM_SHARD=N`. Pas toujours optimal vs vLLM tensor parallelism.
- **Pas de prefix caching** aussi sophistiqué que vLLM / SGLang (RadixAttention)
- **OpenAI-compat endpoint** (`/v1/chat/completions`) : disponible mais quelques quirks vs OpenAI strict
- **Memory pressure** : `--cuda-memory-fraction` à régler sinon OOM (TGI alloue large par défaut)

## Code minimal

```bash
# Lancer TGI en Docker (1 commande)
docker run --gpus all --shm-size 1g -p 8080:80 \
    -e MODEL_ID=meta-llama/Meta-Llama-3.1-8B-Instruct \
    -e HUGGING_FACE_HUB_TOKEN=hf_xxx \
    -e QUANTIZE=awq \
    -e MAX_TOTAL_TOKENS=8192 \
    -e MAX_BATCH_PREFILL_TOKENS=8192 \
    ghcr.io/huggingface/text-generation-inference:latest

# Multi-LoRA (v2+)
docker run --gpus all -p 8080:80 \
    -e MODEL_ID=meta-llama/Meta-Llama-3.1-8B \
    -e LORA_ADAPTERS=hf-internal/llama3-lora-1=adapter-1,hf-internal/llama3-lora-2=adapter-2 \
    ghcr.io/huggingface/text-generation-inference:latest
```

```python
# Client : utiliser le SDK OpenAI (TGI expose endpoint OpenAI-compat)
from openai import OpenAI
client = OpenAI(base_url="http://localhost:8080/v1", api_key="not-needed")

response = client.chat.completions.create(
    model="meta-llama/Meta-Llama-3.1-8B-Instruct",   # matche MODEL_ID
    messages=[{"role": "user", "content": "Hello"}],
    max_tokens=100,
)
print(response.choices[0].message.content)

# Ou SDK natif HF
from huggingface_hub import InferenceClient
client = InferenceClient("http://localhost:8080")
for chunk in client.text_generation("Hello", max_new_tokens=100, stream=True):
    print(chunk, end="")

# Generate avec adapter LoRA
response = client.chat.completions.create(
    model="adapter-1",                                # nom du LoRA déployé
    messages=[...],
)
```

## Liens

- [[vLLM]] — alt principal
- [[SGLang]] — alt RadixAttention
- [[TensorRT-LLM]] — alt NVIDIA-optimisé
- [[Inference optimization]] (concept)
- **HuggingFace Inference Endpoints** (managed, TGI dessous) : https://huggingface.co/inference-endpoints
- Docs : https://huggingface.co/docs/text-generation-inference/
- GitHub : https://github.com/huggingface/text-generation-inference
