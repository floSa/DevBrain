---
galaxie: dev
nom: PydanticAI
alias: [pydantic-ai]
categorie: llm/framework
sous_categories: [agents, structured-output, type-safe]
licence: MIT
licence_type: open-source
hosted: self
maturite: beta
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[LangGraph]]", "[[Instructor]]", smolagents]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, llm, agents, pydantic]
url_officiel: https://ai.pydantic.dev/
url_docs: https://ai.pydantic.dev/
url_repo: https://github.com/pydantic/pydantic-ai
---

# PydanticAI

## Pourquoi

Framework d'agents LLM **type-safe**, créé par l'équipe Pydantic elle-même. Tu déclares ton agent comme une classe Pydantic, ses tools comme des fonctions typées. L'agent suit le contrat Pydantic strict, supporte multi-providers (Anthropic, OpenAI, Google, Ollama, Groq…), dependency injection, streaming.

L'esprit : prendre tout ce qu'on aime de FastAPI (Pydantic + DI + types) et l'appliquer aux agents. Le "FastAPI des agents".

## Quand l'utiliser

- Tu fais déjà du FastAPI / Pydantic et tu veux un framework agent cohérent stylistiquement
- App agent où la fiabilité du contrat (types in/out) est critique
- Tu veux du multi-provider sans avoir à apprendre LangChain
- Préfère le "data class + functions" style à l'API "chain.invoke()"

## Quand NE PAS l'utiliser

- Workflow multi-agent complexe avec graphes → [[LangGraph]] est plus mature
- Tu détestes Pydantic / tu préfères dict bruts — pas ton framework
- Tu veux quelque chose d'ultra-stable en prod aujourd'hui → encore beta (mai 2026), surveille la roadmap

## Pièges connus

- API encore en évolution — verrouille ta version
- Less battle-tested que LangChain → moins de templates, moins de Stack Overflow
- Le dependency injection est puissant mais ajoute de la complexité conceptuelle

## Liens

- Doc : https://ai.pydantic.dev/
- Repo : https://github.com/pydantic/pydantic-ai
- [[Instructor]] (structured output sans agents)
- [[LangGraph]] (alternative agent-graph)
