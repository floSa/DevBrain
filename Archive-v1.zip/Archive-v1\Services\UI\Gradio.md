---
galaxie: dev
nom: Gradio
alias: [gradio]
categorie: ui/ml-demo
sous_categories: [ml-demo, hf-spaces, prototype, python-only]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python, js, openai-compat]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Streamlit]]", "Panel", "Solara"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ui, ml, demo, huggingface]
url_officiel: https://www.gradio.app/
url_docs: https://www.gradio.app/docs
url_repo: https://github.com/gradio-app/gradio
---

# Gradio

## Pourquoi
Framework Python pour démos ML. Chaque modèle = `Interface(fn, inputs, outputs)`. Composants riches pour audio/image/video/chat. Hosting gratuit sur HuggingFace Spaces. Le défaut pour montrer un modèle à un non-tech ou pour partager un POC.

## Quand l'utiliser
- Démo d'un modèle ML (classif, génération, transcription, vision…)
- Chatbot UI rapide (`gr.ChatInterface` est excellent)
- POC interne pour faire tester un modèle sans pondre une app
- Hébergement sur HuggingFace Spaces (gratuit, instantané)
- Annotation / data labeling rapide

## Quand NE PAS l'utiliser
- Dashboard data / analytics → [[Streamlit]] est plus adapté
- App multi-page complexe avec state → vrai framework front
- App user-facing en prod avec UX poussée → React/Vue
- Quand on veut un layout 100% custom → composants Gradio sont opinionated

## Pièges connus
- **Versions 4.x → 5.x** : changements UI majeurs, vérifier la compat des composants
- **Concurrence** : `concurrency_limit` à régler, sinon 1 user = blocage
- **Queue** : `queue=True` indispensable pour les fonctions lentes (sinon timeout)
- **Streaming** : `yield` dans la fonction pour streaming, ne pas oublier `stream_every` / `stream`
- **API auto** : `/api/predict` exposé même si tu fais une UI — protéger ou désactiver
- **Custom CSS** : possible mais limité (grandes refontes UI = pénibles)

## Liens
- [[Streamlit]] — alternative orientée data app
- HuggingFace Spaces (hosting gratuit) : https://huggingface.co/spaces
- ChatInterface : https://www.gradio.app/guides/creating-a-chatbot-fast
- Component library : https://www.gradio.app/docs/gradio/interface
