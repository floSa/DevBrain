---
galaxie: dev
nom: statsmodels
alias: [statsmodels, sm]
categorie: tooling/stats
sous_categories: [statistics, regression, time-series, econometrics]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[scikit-learn]]", "[[pingouin]]", "[[scipy.stats]]", "R lme4/forecast"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, tooling, stats, regression, time-series]
url_officiel: https://www.statsmodels.org/
url_docs: https://www.statsmodels.org/stable/
url_repo: https://github.com/statsmodels/statsmodels
---

# statsmodels

## Pourquoi
Stats classique en Python, là où [[scikit-learn]] s'arrête. **Tests d'hypothèses, p-values, intervalles de confiance, AIC/BIC, ARIMA/SARIMAX, GLM, modèles mixtes**. API formula style R (`y ~ x1 + x2`). Le défaut quand tu fais de la stat inférentielle, pas du ML prédictif.

## Quand l'utiliser
- Inférence statistique (signification de coefficients, ICs)
- Régressions linéaires/logistiques avec **interprétation** (vs prédiction)
- Séries temporelles : ARIMA, SARIMAX, ETS, VAR
- ANOVA, ANCOVA, modèles mixtes
- Tests statistiques (Wald, LR, etc.)
- Quand un référent stat (ou un reviewer) demande une "vraie" sortie de modèle

## Quand NE PAS l'utiliser
- ML pur prédictif → [[scikit-learn]]
- Forecasting moderne (deep learning, LightGBM, NeuralProphet) → autres libs
- Très gros datasets → statsmodels pas optimisé pour le scaling

## Pièges connus
- **Formula API vs array API** : deux mondes, choisir et s'y tenir
- **Constante** : `sm.add_constant(X)` à ajouter manuellement (pas auto)
- **Patsy** : moteur formula, peut surprendre sur certains termes (`C()` pour catégoriel)
- **Performance** : single-thread principalement
- **Maintenance** : projet stable mais releases plus lentes que sklearn

## Liens
- [[scikit-learn]] — alternative pour le ML prédictif
- [[pandas]] — entrée idéale (Series/DataFrame avec formula)
- Examples gallery : https://www.statsmodels.org/stable/examples/index.html
