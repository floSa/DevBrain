---
galaxie: wiki
nom: Hierarchical forecasting
alias: [hierarchical, reconciliation, MinT, bottom-up, top-down, OLS]
type: concept
categorie: concept/time-series
sous_categories: [hierarchical, reconciliation, time-series, forecasting]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Hyndman 2011, Wickramasuriya-Athanasopoulos-Hyndman 2019 (MinT)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, time-series, forecasting, hierarchical]
---

# Hierarchical forecasting

## TL;DR

Quand on a une **hiérarchie de séries** (Total → Region → Store → SKU, ou Country → State → City), comment **garantir la cohérence** des prévisions à tous les niveaux (somme des forecasts SKU = forecast Store) tout en maximisant la précision ? Trois approches classiques : **bottom-up**, **top-down**, **middle-out**. Approche moderne : **reconciliation** (Hyndman et al. 2011, MinT 2019) qui ajuste optimalement tous les niveaux d'un coup. Standard chez Amazon, Walmart, Uber. Implémenté dans `hierarchicalforecast` (Nixtla).

## Le problème

Dans le retail / supply chain / planification :
- On forecaste à plusieurs niveaux d'agrégation (Country → Region → Store)
- Les décisions opérationnelles se prennent à différents niveaux (stock régional vs SKU local)
- **Si on forecaste indépendamment** → les forecasts ne somment plus (incohérence)
- **Si on forecaste un seul niveau et désagrège** → perd l'info des niveaux fins

Comment **réconcilier** ?

## L'idée

### Setup formel

Hiérarchie de $n$ séries observées : $y_{i,t}$ pour $i = 1, \dots, n$.

Notation matricielle : $y_t = S b_t$
- $b_t$ : séries au niveau le plus bas (bottom-level, $m$ séries)
- $S$ : matrice de sommation ($n \times m$), encode la hiérarchie
- $y_t$ : toutes les séries (incluant agrégats)

Exemple à 4 séries (1 Total, 2 Regions, 2 Stores chacune) → $S$ devient :
$$ S = \begin{pmatrix} 1 & 1 & 1 & 1 \\ 1 & 1 & 0 & 0 \\ 0 & 0 & 1 & 1 \\ 1 & 0 & 0 & 0 \\ 0 & 1 & 0 & 0 \\ 0 & 0 & 1 & 0 \\ 0 & 0 & 0 & 1 \end{pmatrix} $$

### Approches classiques

#### Bottom-up

Forecaster chaque série bottom $b_t$, puis agréger : $\tilde y_t = S \hat b_t$.

- ✅ Cohérent par construction
- ✅ Capture variations granulaires
- ❌ Bottom level souvent bruyant → forecasts bruyants à tous niveaux
- ❌ Coûteux (nb modèles = nb séries bottom)

#### Top-down

Forecaster le top $\hat y_{1,t}$, puis désagréger par proportions historiques :

$$ \tilde b_{i,t} = p_i \cdot \hat y_{1,t}, \quad \tilde y_t = S \tilde b_t $$

- ✅ Top stable (forecast facile)
- ✅ 1 seul modèle
- ❌ Suppose proportions stables
- ❌ Perd info granulaire

Variantes : proportions historiques, proportions forecastées.

#### Middle-out

Forecaster un niveau intermédiaire, agréger up, désagréger down. Compromis.

### Reconciliation (Hyndman et al. 2011)

Vue moderne : forecaster **indépendamment chaque série** (base forecasts $\hat y_t$), puis **réconcilier** :

$$ \tilde y_t = S P \hat y_t $$

avec $P$ matrice de projection. Si bien choisie : 
- $\tilde y_t$ est cohérent ($\tilde y_t = S \tilde b_t$)
- Erreur minimisée

#### OLS reconciliation

$P_{OLS} = (S^\top S)^{-1} S^\top$ → minimise $\|\hat y - \tilde y\|^2$. Pas optimal mais simple.

#### MinT (Minimum Trace, Wickramasuriya-Athanasopoulos-Hyndman 2019)

État de l'art :

$$ P_{MinT} = (S^\top W^{-1} S)^{-1} S^\top W^{-1} $$

avec $W$ = matrice de covariance des erreurs de base forecast.

- **Optimal au sens MSE**
- Plusieurs estimateurs de $W$ : identity (OLS), structurelle, shrinkage, sample
- Standard moderne, implem dans `hierarchicalforecast` Nixtla

#### Cross-temporal reconciliation

Aller plus loin : réconcilier en hiérarchie **cross-section** ET **temporelle** (e.g. forecast daily, weekly, monthly cohérents). Implem : Athanasopoulos, Hyndman et al.

### Choix d'approche

| Approche | Cohérent | Précis | Coût | Quand |
|---|:-:|:-:|---|---|
| Bottom-up | ✓ | OK (si bottom propre) | élevé | data bottom propre, peu de hierarchies |
| Top-down | ✓ | moyen | bas | data bottom bruyante, proportions stables |
| Middle-out | ✓ | mixte | moyen | hiérarchie large |
| OLS reconciliation | ✓ | mieux que above | moyen | baseline reconciliation |
| **MinT** | ✓ | meilleur | moyen | **default moderne** |

### Hierarchies vs groupes

- **Hiérarchie strict** : Total → Region → Store → SKU (chaque niveau partitionne)
- **Grouped** : plusieurs hiérarchies orthogonales (e.g. Region × Product Category). Plus complexe, MinT généralise.

### Évaluation

Évaluer à **chaque niveau** :
- MASE / WAPE par niveau
- Coherence loss (devrait être ~0 après reconciliation)
- Per-level forecast skill vs naive

Souvent on compare : base forecast indep vs après reconciliation. MinT améliore généralement à tous les niveaux.

### Best practices

1. **Forecaster indépendamment** avec auto-ARIMA / auto-ETS / ML à chaque niveau (parallel via statsforecast)
2. **MinT shrinkage** comme reconciliation default
3. **Évaluer par niveau** : reporting hiérarchique
4. **Garder la base forecast** non-réconciliée pour analyse
5. **Backtest walk-forward** avec reconciliation à chaque step ([[Walk-forward CV]])

## Quand c'est utile

- **Retail** : Country / Region / Store / SKU
- **Supply chain** : DC / regional warehouse / SKU
- **Énergie** : National grid / regional / individual customer
- **Tourism** : Country / region / sector
- **Finance** : Conso / business unit / project
- **Marketing** : Total spend / channel / campaign

## Quand ça ne marche pas / pièges

- **Hiérarchie incohérente dans data** : $y_t \neq S b_t$ historiquement (bug de data, missing). Reconciliation MinT échoue → vérifier les données.
- **Bottom level très bruyant** : reconciliation peut amplifier le bruit. Lisser bottom ou utiliser top-down si bottom n'apporte rien.
- **Proportions non-stationnaires** : top-down assume proportions stables. Si pas vrai → biais.
- **W mal estimée** dans MinT : sample covariance singulière sur séries courtes → utiliser shrinkage ou structurelle.
- **Mélange de fréquences** : ne pas réconcilier daily avec monthly directement (utiliser cross-temporal MinT).
- **Coût computationnel** : MinT scale en $O(n^3)$ vs n séries. Pour très grandes hierarchies (1M+ séries), utiliser approximations.
- **Distributional forecasts** : reconciliation MinT est sur point forecasts. Pour probabiliste, utiliser bootstrapping (Panagiotelis et al.).
- **Confondre reconciliation et imputation** : si données manquantes, imputer avant, pas via reconciliation.

## Code minimal

```python
import numpy as np
import pandas as pd
from statsforecast import StatsForecast
from statsforecast.models import AutoARIMA
from hierarchicalforecast.core import HierarchicalReconciliation
from hierarchicalforecast.methods import BottomUp, TopDown, MinTrace
from hierarchicalforecast.utils import aggregate

# Setup : data hierarchique
# Long format : unique_id contient l'identifiant à chaque niveau
df = pd.DataFrame({
    'unique_id': ['North/Store1', 'North/Store2', 'South/Store1', 'South/Store2'] * 24,
    'ds': pd.date_range('2024-01-01', periods=24, freq='M').tolist() * 4,
    'y': np.random.poisson(100, 96)
})

# 1. Construire hierarchies + S matrix
spec = [
    ['Region'],
    ['Region', 'Store']
]
df[['Region', 'Store']] = df['unique_id'].str.split('/', expand=True)
Y_df, S_df, tags = aggregate(df, spec=spec)

# 2. Forecaster indépendamment chaque série
sf = StatsForecast(models=[AutoARIMA(season_length=12)], freq='M', n_jobs=-1)
sf.fit(Y_df)
Y_hat_df = sf.forecast(h=12, fitted=True)
Y_fitted_df = sf.forecast_fitted_values()

# 3. Reconciliation avec différentes méthodes
hrec = HierarchicalReconciliation(reconcilers=[
    BottomUp(),
    TopDown(method='forecast_proportions'),
    MinTrace(method='ols'),
    MinTrace(method='mint_shrink'),
])
Y_rec = hrec.reconcile(Y_hat_df=Y_hat_df, Y_df=Y_fitted_df, S=S_df, tags=tags)

print(Y_rec.head())  # forecasts cohérents par méthode

# 4. Vérification cohérence : somme bottom == top forecast
top = Y_rec[Y_rec.unique_id == 'Total'].set_index('ds')['AutoARIMA/MinTrace_method-mint_shrink']
bottoms_sum = Y_rec[Y_rec.unique_id.str.contains('/')].groupby('ds')[
    'AutoARIMA/MinTrace_method-mint_shrink'].sum()
print(f"Diff (devrait être ≈ 0): {(top - bottoms_sum).abs().max():.6f}")

# 5. Évaluation par niveau
from hierarchicalforecast.evaluation import HierarchicalEvaluation
def mase(y, y_hat, y_insample, seasonality=12):
    return np.mean(np.abs(y - y_hat)) / np.mean(np.abs(y_insample[seasonality:] - y_insample[:-seasonality]))

evaluator = HierarchicalEvaluation(evaluators=[mase])
# evaluation = evaluator.evaluate(Y_hat_df=Y_rec, Y_test_df=Y_test, tags=tags, Y_df=Y_train)
```

## Pour aller plus loin

- Hyndman et al., *Optimal Combination Forecasts for Hierarchical Time Series* (CSDA 2011)
- Wickramasuriya, Athanasopoulos, Hyndman, *Optimal Forecast Reconciliation for Hierarchical and Grouped Time Series Through Trace Minimization* (JASA 2019) — MinT
- Athanasopoulos et al., *Hierarchical and grouped time series* (IJF 2009)
- Hyndman & Athanasopoulos, *Forecasting: Principles and Practice* (3e éd.) — chap. 11
- Nixtla `hierarchicalforecast` docs et tutorials
- **Liens internes** : [[ARIMA SARIMA]], [[Exponential smoothing]], [[Forecasting framing]], [[Forecasting metrics]], [[statsforecast]] (service), [[Walk-forward CV]]
