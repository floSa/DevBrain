---
galaxie: wiki
nom: Small Language Models (SLM)
alias: [SLM, Phi, Gemma, SmolLM, MobileLLM, OLMo, edge LLM]
type: concept
categorie: concept/llm-families
sous_categories: [slm, small-models, edge, llm]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Gunasekar 2023 (Phi), Liu 2024 (MobileLLM)]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, small-models, edge]
---

# Small Language Models (SLM)

## TL;DR

Modèles **< 14B params** : compromis qualité / cost / latency / edge deployment. Familles 2026 : **Phi** (1, 1.5, 2, 3, 3.5, 4 — Microsoft), **Gemma** (1, 2, 3 — Google), **SmolLM** (1, 2, 3 — HF), **OLMo** (Allen AI, fully open), **MobileLLM** (Meta, <1B mobile-optimized), **Apple OpenELM**, **Qwen 0.5B-7B**, **TinyLlama**, **StableLM**. Souvent issus de **distillation** (Phi from textbook + GPT-4) ou **continued pretraining**. Run sur edge (mobile, browser, RPi). Use cases : on-device inference, low-latency, cheap deployment, privacy. **Loi 2025** : un SLM bien curé peut être > qu'un model 10x plus grand sur tâches spécifiques.

## Le problème

GPT-4 / Claude Opus = trop chers / lents / cloud-only. Beaucoup d'apps n'ont pas besoin de "tout savoir" — juste de la tâche spécifique.

→ **Petit modèle distillé / spécialisé** : 90% perf grand modèle à 1/100 le cost.

## L'idée

### Familles 2026

#### Microsoft Phi family

Démarré avec idée **"textbook quality"** : data synthétique haute qualité curée + distillation GPT-3.5/4.

- **Phi-1** (1.3B) : code, distillé GPT-3.5
- **Phi-1.5** (1.3B) : language
- **Phi-2** (2.7B)
- **Phi-3 mini** (3.8B), **Phi-3 small** (7B), **Phi-3 medium** (14B)
- **Phi-3.5 mini / MoE** (3.8B / 41B)
- **Phi-3.5-Vision** (4.2B) : multimodal
- **Phi-4** (14B) : 2024, compétitif avec Llama 3 70B sur certains
- **Phi-4-multimodal**

Pioneer "small can be smart".

#### Google Gemma

- **Gemma 1** (2B, 7B) : 2024
- **Gemma 2** (2B, 9B, 27B) : 2024
- **Gemma 3** (latest, multilingue, multimodal)
- **Gemma 2-2B distilled** : tres performant pour sa taille

Open weights. Standard for fine-tuning baseline.

#### Hugging Face SmolLM

- **SmolLM** (135M, 360M, 1.7B) : tiny pour edge
- **SmolLM2** : amélioration
- **SmolLM3** : recent

Open data, open code, open weights.

#### Allen AI OLMo

- **OLMo 1**, **OLMo 2** : fully open (data + weights + code)
- Recherche reproductible

#### Meta MobileLLM

< 1B params optimisé mobile.

#### Apple OpenELM

Pour Apple Silicon.

#### Qwen small

- **Qwen 0.5B**, **1.5B**, **3B**, **7B** : Alibaba

#### Mistral

- **Mistral 7B** : early frontier small
- **Mistral Nemo 12B**, **Mistral Small** (24B)

#### StableLM

Stability AI series.

#### TinyLlama

1.1B, popular base.

#### Llama 3.x small

- **Llama 3.2 1B, 3B** : small Meta options

### Pourquoi ils marchent

Plusieurs raisons :

#### Distillation

Cf. [[Distillation]]. SLM apprend du gros teacher. Phi = exemple parfait.

#### Data quality

"Textbooks > web scrape". Phi philosophy : curate hardest, train less.

#### Compute-optimal training

Cf. [[Scaling laws]]. Llama 3.2 1B trained sur 9T tokens → over-trained, performant.

#### Architectural improvements

GQA, FlashAttn, SwiGLU → mêmes archi que les big.

#### Specialization

SLM fine-tuné sur ta tâche peut battre Claude Opus zéro-shot.

### Performance vs taille (2026)

Quelques exemples :
- Phi-3 mini (3.8B) ≈ Llama 2 70B (sur MMLU, GSM8K)
- Gemma 2 27B ≈ Llama 3 70B
- Qwen 2.5 7B ≈ GPT-3.5 (sur benchs)
- Llama 3.2 3B = decent agent

Pareto curve moves down each year.

### Use cases

#### On-device

- iPhone/iPad : MLX + Phi/Gemma quantized
- Android : MediaPipe + Gemma
- Browser : WebLLM (WASM/WebGPU)
- Raspberry Pi : llama.cpp + Q4 model

#### Low-latency

Voice agents need <300ms ASR + LLM. SLM = critical.

#### Cost-sensitive

10K queries/day × $0.001 SLM vs $0.05 GPT-4 → $400/day saved.

#### Privacy

On-device → data never leaves user.

#### Fine-tuning experimentation

Train sur 24GB GPU avec QLoRA.

### Quantization for edge

Combine avec [[Quantization]] :
- Phi-3 mini Q4 : ~2 GB → fits mobile
- Gemma 2-2B Q4 : ~1.5 GB
- Run on iPhone 15 Pro Max comfortably

### Modèles à la frontière SLM

Tableau évolutif :

| Modèle | Params | Year | Notes |
|---|---|---|---|
| Phi-3.5-mini | 3.8B | 2024 | strong reasoning |
| Gemma 2-2B | 2B | 2024 | distilled 27B |
| Llama 3.2 3B | 3B | 2024 | multilingual |
| Qwen 2.5 7B | 7B | 2024 | overall strong |
| Phi-4 | 14B | 2024 | competitive 70B |
| Mistral Small 3 | 24B | 2025 | larger SLM |
| Gemma 3 | varies | 2025 | latest Google |
| OLMo 2 | 7B, 13B | 2024 | fully open |

### Fine-tune SLMs

Avec [[PEFT]] LoRA : tu peux fine-tune Phi-3 mini sur ton domaine en quelques heures sur RTX 4090. Standard 2026.

### Use SLM in production

Pattern : **fine-tune SLM + serve avec vLLM** :
```
1. Take Phi-3.5-mini base
2. Fine-tune LoRA sur tes données (~10K examples)
3. Merge LoRA
4. Serve vLLM
5. Cost ~5% of using GPT-4
```

### Best practices

1. **Evaluate fit** : SLM enough pour ta tâche ?
2. **Fine-tune** : SLM générique mediocre, fine-tuné performant
3. **Quantize** for edge
4. **Pas pour reasoning lourd** : math, multi-step → bigger model
5. **Combine cascade** : SLM first, escalate sur fail
6. **Distillation** : créer ton propre SLM custom
7. **Multilingue** : check coverage (souvent faible)
8. **Benchmark sur ton use case** : pas blindly trust public
9. **Open weights** : eval freedom, no vendor lock
10. **Privacy compliance** : on-device pour PII

## Quand c'est utile

- **Edge deployment** : mobile, IoT, browser
- **High-volume** : 1M queries/day
- **Cost-critical** : startups, free tiers
- **Latency-critical** : voice agents, code completion
- **Privacy** : medical, legal on-device
- **Specialized tasks** : fine-tuned on domain
- **Offline** : no network needed
- **Self-hosted** : no API dependency
- **Multimodal embedded** : Phi-3.5-Vision

## Quand ça ne marche pas / pièges

- **Complex reasoning** : SLM struggle sur math, planning long
- **Multi-step agents** : SLM tool use mediocre
- **Long context** : effective ctx < frontier
- **Multilingual gaps** : non-EN often weak
- **Hallucinations more** : less knowledge in weights
- **Coding complex** : SLM code mediocre vs Claude / Codestral
- **Generic tasks** : Claude Haiku ($) might be cheaper than self-host SLM
- **Maintenance** : self-host = ops burden
- **Updates** : new model every few months → re-eval, re-fine-tune
- **Quality variance** : SLMs from different vendors very different

## Code minimal

```python
# 1. Phi-3.5 mini (HuggingFace)
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
import torch

model_id = "microsoft/Phi-3.5-mini-instruct"
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(
    model_id, torch_dtype=torch.bfloat16, device_map="auto"
)

pipe = pipeline("text-generation", model=model, tokenizer=tokenizer)
output = pipe([
    {"role": "user", "content": "Explain quantum computing in 1 paragraph"}
], max_new_tokens=200)
print(output[0]["generated_text"])

# 2. Gemma 2-2B
model_id = "google/gemma-2-2b-it"
# Similar pipeline

# 3. SmolLM3
model_id = "HuggingFaceTB/SmolLM3-3B"
# Use HuggingFaceTB org

# 4. Qwen 2.5 7B
model_id = "Qwen/Qwen2.5-7B-Instruct"

# 5. Ollama (easy local SLMs)
# ollama pull phi3.5:mini
# ollama pull gemma2:2b
# ollama pull qwen2.5:7b
# ollama run phi3.5:mini

# 6. LM Studio / GPT4All (UIs)
# Download GGUF Q4_K_M, run locally

# 7. MLX (Apple Silicon)
from mlx_lm import load, generate
model, tokenizer = load("mlx-community/Phi-3.5-mini-instruct-4bit")
response = generate(model, tokenizer, prompt="Hello", max_tokens=100)

# 8. WebLLM (browser)
# https://webllm.mlc.ai/
# Run SLMs in browser via WebGPU

# 9. Fine-tune SLM avec QLoRA
from transformers import AutoModelForCausalLM, BitsAndBytesConfig
from peft import LoraConfig, get_peft_model
from trl import SFTTrainer, SFTConfig

bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4")
model = AutoModelForCausalLM.from_pretrained("microsoft/Phi-3.5-mini-instruct",
                                              quantization_config=bnb, device_map="auto")
lora_config = LoraConfig(r=16, lora_alpha=32, target_modules="all-linear",
                         task_type="CAUSAL_LM")
model = get_peft_model(model, lora_config)

# trainer = SFTTrainer(model=model, train_dataset=ds, ...)
# trainer.train()
# model.save_pretrained("./my-phi-tuned")

# Fine-tuning Phi-3.5-mini sur 10K examples = 30 min on RTX 4090

# 10. Serve fine-tuned SLM
# vllm serve ./my-phi-tuned --max-model-len 4096 --quantization awq

# 11. Compare iso-cost
# Self-host Phi-3.5 on RunPod : ~$1/h, 100 req/s → $0.000003 per req
# vs Claude Haiku : ~$0.0003 per req (~100x more)
```

## Pour aller plus loin

- Gunasekar et al., *Textbooks Are All You Need* (Phi-1, 2023)
- Abdin et al., *Phi-3 Technical Report* (2024)
- Hoffmann et al., *Training Compute-Optimal Large Language Models* (Chinchilla, 2022)
- Mehta et al., *OpenELM* (Apple 2024)
- Liu et al., *MobileLLM: Optimizing Sub-billion Parameter Language Models for On-Device Use Cases* (ICML 2024)
- *HuggingFace SmolLM* series blog posts
- *Gemma 2 Technical Report* (Google 2024)
- *Allen AI OLMo 2 Technical Report*
- *Ollama, LM Studio* documentation
- **Liens internes** : [[Scaling laws]], [[Distillation]], [[Quantization]], [[PEFT]]
