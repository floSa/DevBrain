---
galaxie: dev
nom: AutoGen
alias: [autogen, autogen-agentchat, autogenstudio]
categorie: llm/framework
sous_categories: [multi-agent, agents, llm-orchestration, microsoft]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python (.NET aussi)
clients_officiels: [python, dotnet]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[CrewAI]]", "[[LangGraph]]", Semantic Kernel, Swarm (OpenAI), MetaGPT]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, multi-agent, autogen, microsoft]
url_officiel: https://microsoft.github.io/autogen/
url_docs: https://microsoft.github.io/autogen/stable/
url_repo: https://github.com/microsoft/autogen
---

# AutoGen

## Pourquoi
Framework **multi-agent** Microsoft. Modèle "conversational agents" : plusieurs agents (planner / coder / critic / executor) discutent jusqu'à résoudre la tâche. Code execution sandboxé natif. AutoGen Studio (UI) pour prototyping. v0.4 (2024) = rewrite avec architecture événementielle.

## Quand l'utiliser
- Tâches multi-step complexes nécessitant rôles distincts
- Code generation collaboratif (Coder + Reviewer + Tester)
- Recherche / synthèse (Planner + Researchers + Synthesizer)
- Tu veux UI prototyping (AutoGen Studio)
- Architecture événementielle pour scale

## Quand NE PAS l'utiliser
- Single-agent → over-engineering, juste un loop ReAct ([[agent-loops|Agent loops]])
- Orchestration explicite avec contrôle fin → [[LangGraph]] (graphs > conversations)
- Rôles simples production → [[CrewAI]] (UX plus opinionated)
- Stack OpenAI lock-in OK → Swarm (OpenAI, plus light)
- Stack .NET → [[Semantic Kernel]] (Microsoft aussi mais natif .NET)

## Pièges connus
- **v0.2 → v0.4 (2024-2025)** : refactor majeur (events, async). v0.2 deprecated, tutos online mélangés.
- **AgentChat vs Core** : v0.4 a 2 niveaux d'API
- **Code execution** : Docker container recommandé (pas exécuter en local sans sandbox)
- **Loops infinis** : agents peuvent boucler. `max_turns` strict obligatoire.
- **Cost explosion** : N agents × M turns × tokens history = $$ vite
- **Multi-agent ≠ toujours meilleur** : benchmarks montrent souvent single-agent solide + tools = aussi bon
- **AutoGen Studio** : utile pour proto, pas pour prod

## Liens
- [[CrewAI]] / [[LangGraph]] — alternatives
- Semantic Kernel — alt Microsoft (.NET-first)
- [[Multi-agent systems]] / [[Agent patterns]] (concepts)
- Docs : https://microsoft.github.io/autogen/stable/
- GitHub : https://github.com/microsoft/autogen
- Studio : https://microsoft.github.io/autogen/stable/user-guide/autogenstudio-user-guide/index.html
