---
galaxie: dev
nom: Great Expectations
alias: [great-expectations, ge, gx]
categorie: data/quality
sous_categories: [data-quality, validation, profiling, tests]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: [Soda, Pandera, dbt tests, Cuallee, Deequ]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, quality, validation]
url_officiel: https://greatexpectations.io/
url_docs: https://docs.greatexpectations.io/
url_repo: https://github.com/great-expectations/great_expectations
---

# Great Expectations

## Pourquoi
Framework de **data quality** : déclare des "expectations" (assertions sur tes données), les valide, génère des rapports + Data Docs (HTML statique). Standard historique pour la qualité data en Python. Pandera est plus léger (typing + Pydantic), Soda plus moderne pour le cloud.

## Quand l'utiliser
- Pipelines ETL avec validation à chaque étape
- Profiling automatique d'un nouveau dataset
- Data contracts entre équipes (producer / consumer)
- CI/CD data : breaking changes detection
- Génération de docs data interactives (Data Docs)

## Quand NE PAS l'utiliser
- Validation simple DataFrame Python → Pandera (Pydantic-like, plus simple)
- Stack dbt déjà mature → dbt tests natifs (suffit souvent)
- SaaS data quality → Soda Cloud
- Big data Spark natif → Deequ (Amazon, JVM-based)
- Apps Python avec validation runtime → Pydantic

## Pièges connus
- **v0.x → v1.x (2024)** : refactor majeur. v0 obsolète, certains tutoriels datés.
- **Setup verbeux** : context + datasources + suites + checkpoints. Beaucoup de YAML.
- **Performance** : peut être lent sur grosses datasets si pas configuré (sampling, fluent datasources)
- **Data Docs** : utiles mais statiques (HTML), pas vraiment "live"
- **Pandera comparison** : GE plus puissant en discovery / profiling, Pandera plus simple en typing inline
- **Cloud (managed)** : pricing peut surprendre

## Liens
- Pandera (alt léger) : https://pandera.readthedocs.io/
- Soda Core / Cloud : https://www.soda.io/
- [[Prefect]] / [[Dagster]] — orchestration combinée
- Docs : https://docs.greatexpectations.io/
- Migration v0 → v1 : https://docs.greatexpectations.io/docs/oss/guides/migrating/
