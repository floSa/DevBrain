---
galaxie: dev
nom: pandas
alias: [pandas, pd]
categorie: tooling/data
sous_categories: [dataframe, python, analysis, etl]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python (C/Cython core)
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Polars]]", "[[DuckDB]]", "[[Modin]]", "[[Dask]]"]
remplace: []
remplace_par: ["[[Polars]]"]
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, tooling, data, dataframe, python]
url_officiel: https://pandas.pydata.org/
url_docs: https://pandas.pydata.org/docs/
url_repo: https://github.com/pandas-dev/pandas
---

# pandas

## Pourquoi
La lib historique de DataFrames Python. Ecosystème massif (lit/écrit tout : CSV, Parquet, SQL, Excel, JSON), API mature, intégration totale avec scikit-learn, matplotlib, plotly. Reste le défaut pour la plupart des notebooks et data prep.

## Quand l'utiliser
- Notebooks DS, EDA, prototypes
- Datasets < 1-2 GB en mémoire
- Stack `numpy + scikit-learn + matplotlib` standard
- Quand on a besoin de l'écosystème (intégrations partout)

## Quand NE PAS l'utiliser
- Datasets > 5-10 GB → [[Polars]] (lazy + multi-thread) ou [[DuckDB]]
- Pipelines à perf critique → [[Polars]] (3-30x plus rapide selon ops)
- Très large scale distribuée → [[Dask]], [[Spark]]

## Pièges connus
- **Indexing** : `iloc` vs `loc` vs `at` — sources de bugs
- **SettingWithCopyWarning** : à comprendre, sinon mutations silencieuses
- **Memory** : `int64` par défaut sur des `bool` peut exploser la RAM
- **Versions 2.x** : Arrow backend disponible, à activer pour perf (`dtype_backend="pyarrow"`)
- **Index implicite** : surprend quand on vient de SQL/Polars

## Liens
- [[Polars]] — alternative moderne
- [[numpy]] — backend natif
- [[Parquet]] — format I/O recommandé
- Modern pandas (Tom Augspurger) : https://tomaugspurger.net/posts/modern-1-intro/
