---
galaxie: wiki
nom: Inference optimization
alias: [batching, continuous batching, PagedAttention, prefix caching, chunked prefill, TTFT, TPOT]
type: concept
categorie: concept/llm-inference
sous_categories: [inference, batching, kv-cache, optimization, serving]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Kwon 2023 (vLLM), Yu 2022 (Orca)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, inference, serving, optimization]
---

# Inference optimization

## TL;DR

Techniques pour **maximiser throughput** et **minimiser latency** d'un LLM en production. Coeur : **batching dynamique** (continuous batching, Orca), **KV cache management** (PagedAttention, vLLM), **prefix caching** (RadixAttention, SGLang), **chunked prefill**, **quantization** ([[Quantization]]), [[Speculative decoding]], [[Flash Attention and efficient attention]]. Métriques clés : **TTFT** (Time to First Token), **TPOT/ITL** (Inter-Token Latency), **throughput** (tokens/sec), **tokens/dollar**. Stack moderne 2026 : **vLLM** / **SGLang** / **TGI** + GQA model + Flash Attention + speculative + AWQ/INT8. Sans, on serve un Llama 70B à 30 tok/s ; avec, à 500+ tok/s en multi-user.

## Le problème

LLM inference est **memory-bound** (pas compute-bound) sur GPU :
- Pour chaque token généré, on **relit tout le modèle** (cf. autoregressive)
- KV cache grossit avec context → mémoire
- Single user = GPU idle 80% du temps

→ Maximiser **throughput** en multi-tenant tout en gardant **latency** acceptable.

## L'idée

### Métriques

#### TTFT (Time To First Token)

Temps entre request et premier token output. Critique pour UX (chat, code completion).

- Goal : < 500ms typique, < 200ms premium

#### TPOT / ITL (Inter-Token Latency)

Temps entre tokens consécutifs. Détermine "perceived speed" après TTFT.

- Goal : 20-50ms (50 tok/s perçus)

#### Throughput

Tokens / second en total (tous users). Détermine cost par token.

- Llama 3 70B sur 8xH100 vLLM : ~5000+ tok/s aggregate

#### Cost metrics

- **Tokens / dollar** : tokens servis par $ de compute
- **Calls / dollar** : calls totales par $
- **VRAM / model** : combien tu peux servir simultanément

### Phases d'inference

Une request a 2 phases :

#### Prefill (prompt processing)

Process le **prompt entier** en un seul batch (compute-bound). Génère le 1er token.

- $O(n^2)$ compute (attention)
- Bon use of GPU
- Détermine TTFT

#### Decode (token-by-token)

Generate token par token (memory-bound). Chaque token = 1 forward pass.

- Memory-bound
- GPU sous-utilisé sur single user
- Détermine TPOT

### Static vs Dynamic Batching

#### Static batching

Attendre que $N$ requests arrivent, batcher, generate jusqu'à toutes finies, return.

- Simple
- **Padding waste** : courte request attend longue
- **Idle GPU** entre batches

#### Continuous batching (Orca, Yu 2022)

Insérer / retirer requests **in-flight** au niveau token :

```
Step 1 : batch [req1: token2, req2: token1, req3: token1]
Step 2 : req1 finished → batch [req2: token2, req3: token2, req4: token1] (new request joins)
Step 3 : ...
```

- **2-4x throughput** vs static
- Standard vLLM, TGI, SGLang
- **Bottleneck** : memory (KV cache, voir PagedAttention)

### KV cache management

#### Le problème mémoire

KV cache stocké pour chaque token : $2 \cdot L \cdot h \cdot d \cdot \text{bytes}$ par token.

Pour Llama 3 70B (GQA, 8 KV heads, head_dim 128, 80 layers, bf16) : ~150 KB / token.

- Context 8K : 1.2 GB
- Context 32K : 4.8 GB
- 10 users à 32K : 48 GB

→ KV cache **domine** la mémoire après les weights.

#### PagedAttention (Kwon 2023, vLLM)

Idée : **page-based memory** comme OS :
- KV cache = blocks de taille fixe (16-32 tokens)
- Allocate dynamically à chaque request
- **No fragmentation**, no over-provisioning
- Permet continuous batching efficient

**Standard** vLLM, TGI (Flashbatched).

#### KV cache quantization

Quantifier KV cache en INT8 ou INT4 → diviser mémoire par 2-4. Peu de perte qualité.

### Prefix caching

Multi-request avec **prefix commun** (system prompt, few-shot, RAG context) :

#### vLLM prefix caching

Hash chaque block, réutiliser KV cache si match. Auto, transparent.

#### RadixAttention (SGLang, Zheng 2023)

Arbre **radix** pour matcher prefixes. Plus efficient que hash-based pour shared prefixes.

#### Anthropic prompt caching, OpenAI auto

Provider-side, voir [[Context engineering]].

**Gain typique** : 50-90% latency / cost sur requests avec system prompt commun.

### Chunked prefill

Pour long prompts : process prefill en **chunks** plutôt que tout d'un coup. Permet d'**interleaver** avec decode (continuous batching mieux).

### Disaggregated prefill / decode

**Innovation 2024** : Séparer prefill et decode sur GPUs **différents** (Pipelines, PD-disagg).

- Prefill GPU optimisé pour compute
- Decode GPU optimisé pour memory bandwidth
- Standard chez OpenAI, Google internal

### Spec decoding

Voir [[Speculative decoding]]. Petit drafter accélère gros target. 2-3x speedup.

### Multi-LoRA serving

Servir plusieurs LoRA adapters sur même base model :

- **S-LoRA** (2023) : milliers de LoRA en parallèle
- **Punica** : multi-LoRA serving efficient
- **LoRAX**, **vLLM** : production stacks

### Quantization at serving

Voir [[Quantization]]. INT8 / INT4 → 2-4x compute and memory savings.

### Model routing & cascading

Pour app multi-step :
- **Cheap model d'abord**, escalate to gros si fail
- **RouteLLM, NotDiamond** : router des queries
- Save 50-80% cost en moyenne

### Stack moderne 2026 (production)

```
┌──────────────────────────────────┐
│ Gateway (rate limit, auth, cache)│
└─────────────┬────────────────────┘
              │
┌─────────────▼────────────────────┐
│ Router (LiteLLM, Portkey)        │
│ - Multi-provider                 │
│ - Fallback                       │
│ - Semantic cache                 │
└─────────────┬────────────────────┘
              │
┌─────────────▼────────────────────┐
│ vLLM / SGLang / TGI              │
│ - Continuous batching            │
│ - PagedAttention                 │
│ - Prefix caching                 │
│ - Speculative decoding           │
│ - GQA + Flash Attn               │
│ - AWQ / INT8 quantization        │
│ - Multi-LoRA                     │
└─────────────┬────────────────────┘
              │
        GPUs (H100, B200, MI300X)
```

### Sourcing options

| Stack | Strengths |
|---|---|
| **vLLM** | Continuous batching, PagedAttention, broad model support, prefix caching, AWQ/INT8/FP8 |
| **SGLang** | RadixAttention, frontend DSL, fast |
| **TGI** | HF integration, AWQ/EETQ, Medusa speculative |
| **TensorRT-LLM** | NVIDIA optimized, FP8, best perf on NVIDIA HW |
| **LMDeploy** | Multi-platform, INT4/INT8, FP8 |
| **llama.cpp** | CPU + GPU local, GGUF format |
| **MLX** | Apple Silicon native |
| **Ollama** | Local serving wrapper for llama.cpp |
| **Modal, RunPod, Together, Fireworks** | Managed services |

### Best practices

1. **Profile workload** : prefill-heavy ou decode-heavy ?
2. **GQA model** pour reduced KV cache
3. **vLLM ou SGLang** = default modernes
4. **Prefix caching** : enable, énorme gain
5. **Spec decoding** si gros modèle + small drafter same family
6. **AWQ INT4** : 2-3x throughput, peu de perte qualité
7. **Continuous batching** : enable
8. **Monitor TTFT / TPOT / throughput** par tenant
9. **Routing cheap → big** pour cost reduction
10. **Test under load** : single user benchmarks misleadingly fast

## Quand c'est utile

- **Toute prod LLM** : sans optimisation, cost 10x trop élevé
- **High QPS serving** : Slack, Notion AI, ChatGPT-scale
- **Long context apps** : KV cache management critique
- **Multi-tenant** : continuous batching + prefix caching
- **Self-hosted** : compete avec API providers cost-wise
- **Edge deployment** : llama.cpp + GGUF quant
- **Real-time** : voice agents, code completion (TTFT critical)
- **Batch jobs** : OpenAI Batch API 50% discount, similaire self-hosted

## Quand ça ne marche pas / pièges

- **Single user benchmark** : trompeur, prod = multi-tenant
- **PagedAttention overhead** : sur 1 request, pas de gain
- **Prefix cache invalidation** : prefixes uniques → no hit
- **Speculative décodage low acceptance** : pire qu'unspeculative
- **KV cache quant agressive** : Q4 OK, Q2 dégrade
- **Long context attention quality** : optimization speed mais quality drop
- **Multi-LoRA conflicts** : adapter weights collisions
- **Memory fragmentation** : sans Paged, fragmentation tue throughput
- **GPU under-utilisation** : single user model trop petit → batch
- **Mixed precision bugs** : numerical issues fp16/int8 mix
- **TTFT vs throughput trade-off** : optimiser un peut hurt l'autre
- **Wrong stack for use case** : vLLM ≠ optimal partout

## Code minimal

```python
# 1. vLLM (standard moderne)
from vllm import LLM, SamplingParams

llm = LLM(
    model="meta-llama/Meta-Llama-3-70B-Instruct",
    tensor_parallel_size=4,
    max_model_len=8192,
    enable_prefix_caching=True,       # Prefix cache
    quantization="awq",                # AWQ INT4
    gpu_memory_utilization=0.9,
    enable_chunked_prefill=True,
    # Speculative decoding
    speculative_model="meta-llama/Meta-Llama-3-8B-Instruct",
    num_speculative_tokens=5,
    # Multi-LoRA
    enable_lora=True,
    max_lora_rank=64,
    max_loras=4,
)

sampling = SamplingParams(temperature=0.7, top_p=0.9, max_tokens=200)
outputs = llm.generate(["Hello", "Bonjour"], sampling)

# 2. Server vLLM
# vllm serve meta-llama/Meta-Llama-3-70B-Instruct \
#       --tensor-parallel-size 4 \
#       --max-model-len 8192 \
#       --quantization awq \
#       --enable-prefix-caching \
#       --speculative-model meta-llama/Meta-Llama-3-8B-Instruct \
#       --num-speculative-tokens 5 \
#       --enable-chunked-prefill

# 3. SGLang (frontend DSL + serving)
import sglang as sgl

@sgl.function
def multi_turn_qa(s, question):
    s += sgl.system("You are a helpful AI.")
    s += sgl.user(question)
    s += sgl.assistant(sgl.gen("answer", max_tokens=256))

# 4. TGI
# docker run --gpus all -p 8080:80 \
#       -e MODEL_ID=meta-llama/Meta-Llama-3-70B-Instruct \
#       -e QUANTIZE=awq \
#       -e SPECULATIVE=5 \
#       ghcr.io/huggingface/text-generation-inference:latest

# 5. Bench TTFT / TPOT custom
import time
import requests

def bench_request(prompt, n_tokens=100):
    start = time.perf_counter()
    first_token = None
    last_token = None
    
    with requests.post("http://localhost:8000/v1/completions", json={
        "model": "llama",
        "prompt": prompt,
        "max_tokens": n_tokens,
        "stream": True
    }, stream=True) as r:
        for line in r.iter_lines():
            now = time.perf_counter()
            if first_token is None:
                first_token = now
                ttft = first_token - start
            last_token = now
    
    total = last_token - start
    tpot = (total - ttft) / (n_tokens - 1)
    return ttft, tpot, total

# 6. KV cache size estimation
def kv_cache_gb(n_params=70e9, n_layers=80, kv_heads=8, head_dim=128, seq_len=8192, batch=1, bytes_per=2):
    return 2 * n_layers * kv_heads * head_dim * seq_len * batch * bytes_per / 1e9

print(f"Llama 3 70B GQA 8K ctx batch=1 : {kv_cache_gb():.2f} GB")
print(f"With Q4 KV cache              : {kv_cache_gb(bytes_per=0.5):.2f} GB")

# 7. Prefix cache hit rate (concept)
# Si 100 requests share same system prompt :
# - First request : compute prefill
# - Others : reuse KV cache
# Throughput effective × N_requests

# 8. Routing cascade
def cascade(query, threshold=0.8):
    cheap_result = call_llm("haiku", query)
    if cheap_result.confidence > threshold:
        return cheap_result
    return call_llm("sonnet", query)  # escalate
```

## Pour aller plus loin

- Yu et al., *Orca: A Distributed Serving System for Transformer-Based Generative Models* (OSDI 2022)
- Kwon et al., *Efficient Memory Management for Large Language Model Serving with PagedAttention* (SOSP 2023) — vLLM
- Zheng et al., *SGLang: Efficient Execution of Structured Language Model Programs* (NeurIPS 2024)
- *vLLM*, *SGLang*, *TGI*, *TensorRT-LLM* docs et benchmarks
- Anyscale, Modal, Fireworks blogs (TTFT/TPOT optimization)
- **Liens internes** : [[Flash Attention and efficient attention]], [[Speculative decoding]], [[Quantization]], [[Context engineering]], [[Self-attention]]
