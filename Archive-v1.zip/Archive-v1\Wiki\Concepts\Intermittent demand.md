---
galaxie: wiki
nom: Intermittent demand
alias: [Croston, ADIDA, TSB, sparse demand, lumpy demand, intermittent]
type: concept
categorie: concept/time-series
sous_categories: [intermittent, sparse, croston, time-series, forecasting]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Croston 1972, Syntetos-Boylan 2005, Teunter-Syntetos-Babai 2011]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, time-series, forecasting, intermittent, demand]
---

# Intermittent demand

## TL;DR

Séries de **comptes avec beaucoup de zéros** (spare parts, low-volume SKU, événements rares). ARIMA / ETS standard **ne marchent pas** : ils prédisent une moyenne entre 0 et la valeur observée → forecast non-sensé. Méthodes dédiées : **Croston** (1972) sépare *taille de demande* × *fréquence*, **SBA** (Syntetos-Boylan 2005, correction de biais), **TSB** (Teunter-Syntetos-Babai 2011, gère obsolescence). Standard dans pièces détachées (automotive, military), warehouses. Toujours classifier la série d'abord (smooth / erratic / intermittent / lumpy) via le quadrant **ADI × CV²**.

## Le problème

Données typiques : pièces détachées, ventes rares, défauts intermittents.

```
[0, 0, 0, 5, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 7, 0, ...]
```

- **Présence de zéros majoritaire**
- **Demande arrive de façon intermittente**
- **Quand elle arrive, la taille varie**

ARIMA prédit ~moyenne, donc une **valeur faible et constante** → inutile pour décisions de stock (jamais 0 alors qu'il y a souvent 0, jamais le bon volume quand il arrive).

## L'idée

### Classification : quadrant ADI × CV²

Avant tout, **classifier** la série :
- **ADI** (Average Demand Interval) : nombre de périodes moyen entre 2 demandes non-nulles
- **CV²** : coefficient de variation au carré des demandes non-nulles

Quatre catégories (Syntetos & Boylan) :

| Catégorie | ADI | CV² | Méthode |
|---|---|---|---|
| **Smooth** | ≤ 1.32 | ≤ 0.49 | ARIMA / ETS standard |
| **Intermittent** | > 1.32 | ≤ 0.49 | Croston / SBA |
| **Erratic** | ≤ 1.32 | > 0.49 | Modèles ML, lognormal |
| **Lumpy** | > 1.32 | > 0.49 | SBA, TSB, ou ML spécialisé |

Cette classification dirige le choix d'algorithme.

### Croston (1972) — la baseline

Idée : décomposer la série en :
- $z_t$ : **taille** de la demande (seulement quand demande non-nulle)
- $p_t$ : **intervalle** entre 2 demandes non-nulles

Lisser chacun via Exponential Smoothing :

$$ \hat z_t = \alpha y_t + (1-\alpha) \hat z_{t-1} \quad \text{(quand demande)} $$
$$ \hat p_t = \alpha p_t + (1-\alpha) \hat p_{t-1} \quad \text{(quand demande)} $$

Forecast :

$$ \hat y_t = \frac{\hat z_t}{\hat p_t} $$

**Limitations** :
- **Biaisé** (estimateur du ratio surestime)
- **Update seulement quand demande** → pas de réaction à l'absence prolongée (obsolescence)
- Hyperparamètre $\alpha$ unique pour les deux séries

### SBA — Syntetos-Boylan Approximation (2005)

Correction du biais de Croston :

$$ \hat y_t^{\text{SBA}} = \left(1 - \frac{\alpha}{2}\right) \cdot \frac{\hat z_t}{\hat p_t} $$

- Quasi-non-biaisé
- Recommandé par défaut sur **lumpy**
- Implementé partout (statsforecast, forecast R)

### TSB — Teunter-Syntetos-Babai (2011)

Améliore Croston en gérant **l'obsolescence** :
- Met à jour la **probabilité de demande** $p_t$ à **chaque période** (pas seulement quand demande)
- Détecte naturellement quand un item devient obsolète

$$ \hat p_t = \beta \cdot \mathbb{1}[y_t > 0] + (1 - \beta) \hat p_{t-1} $$
$$ \hat z_t = \alpha y_t + (1-\alpha) \hat z_{t-1} \quad \text{(quand demande)} $$
$$ \hat y_t = \hat p_t \cdot \hat z_t $$

Recommandé quand certains items deviennent dormants.

### ADIDA — Aggregate-Disaggregate Intermittent Demand Approach

Idée : **agréger** la série à une fréquence plus basse (mois → trimestre), forecaster là où il y a moins de zéros, **désagréger** ensuite.

Souvent **simple et efficace**, parfois meilleur que Croston spécialisé.

### IMAPA — Intermittent Multiple Aggregation Prediction Algorithm

Extension d'ADIDA : forecaste à **plusieurs niveaux d'agrégation**, moyenne pondérée. Robuste.

### Methods pour distribution complète

Pour **inventory planning**, on a besoin de la distribution de la demande sur un lead time (pas juste la moyenne). Approches :

- **Bootstrap** : ré-échantillonner sur historique pour générer scénarios
- **Compound Poisson** : Poisson sur arrivées × distribution de tailles
- **Tweedie GLM** : famille exponentielle qui inclut zéros + continu positif
- **GBM avec Tweedie loss** : XGBoost / LightGBM avec `tweedie` objective

### Évaluation spécifique

**MAPE inutile** (division par 0). Préférer :
- **MAE / RMSE** absolus
- **MASE** (vs naive)
- **WAPE** = Σ|err| / Σ|y| (robuste à 0)
- **MAAPE** (Mean Arctangent Absolute Percentage Error) — gère 0
- **CRPS** pour distributional forecasts
- **Service level** / **fill rate** : % de demandes satisfaites avec stock prévu

### Best practices

1. **Classifier d'abord** la série (ADI × CV²)
2. **SBA** comme baseline robuste
3. **Comparer** Croston / SBA / TSB / ADIDA / standard ETS
4. **ML avec Tweedie** pour les gros catalogues avec covariables (prix, promo)
5. **Évaluer en service level / fill rate**, pas juste accuracy
6. **Distinguer SLOB** (Slow/Obsolete) : items vraiment morts ≠ items lumpy actifs
7. **Lead time matters** : agréger sur lead time, pas par période base

## Quand c'est utile

- **Pièces détachées** automobile, military, aerospace
- **Low-volume SKU** retail (long tail)
- **Demand planning** spare parts, MRO (Maintenance, Repair, Operations)
- **Healthcare** : medicines rares
- **Defects / incidents** : taux d'occurrence
- **Tickets de support** par catégorie rare
- **Energy outages** : événements

## Quand ça ne marche pas / pièges

- **Confondre intermittent et smooth-with-outliers** : analyser ADI × CV² avant de choisir.
- **Croston naïf** : biaisé, utiliser SBA.
- **Méthodes Croston-like** ne gèrent pas covariables. Si features importantes (promo, prix), utiliser ML Tweedie ou hurdle models.
- **Negative forecasts** : Croston peut sortir des nombres non-entiers / négatifs theoriquement. Clamper à 0.
- **Évaluer en MAPE** : division par 0 → préférer MASE/WAPE.
- **Ignorer obsolescence** : Croston met à jour seulement à la demande. TSB ou flag manuel pour items morts.
- **Une seule métrique** : viser haute accuracy point forecast peut être trompeur — viser le **service level** business.
- **ML overfitting** : avec 90% de 0, un ML peut "apprendre à prédire 0" et avoir un MAE bas trompeur. Vérifier sur observations non-nulles séparément.
- **Lead time variable** : si lead time change, recalibrer agrégation
- **Aggrégation perd les pics** : ADIDA peut lisser des spikes importants.

## Code minimal

```python
import numpy as np
import pandas as pd

# Simuler série intermittente
np.random.seed(0)
n = 100
demand_prob = 0.2
demand_size_mean = 5

y = np.where(np.random.random(n) < demand_prob,
              np.random.poisson(demand_size_mean, n), 0)

# ADI et CV²
nonzero = y[y > 0]
n_nonzero = len(nonzero)
adi = len(y) / n_nonzero
cv2 = (nonzero.std() / nonzero.mean())**2

print(f"ADI  = {adi:.2f}  (>1.32 = intermittent)")
print(f"CV²  = {cv2:.2f}  (>0.49 = erratic/lumpy)")

# Classification
if adi <= 1.32 and cv2 <= 0.49:
    print("Smooth")
elif adi > 1.32 and cv2 <= 0.49:
    print("Intermittent → Croston/SBA")
elif adi <= 1.32 and cv2 > 0.49:
    print("Erratic")
else:
    print("Lumpy → SBA/TSB ou ML")

# Croston implem from scratch
def croston(y, alpha=0.4):
    z, p = y[y > 0][0], 1  # init avec première demande
    forecast = []
    p_since_last = 1
    for yt in y:
        if yt > 0:
            z = alpha * yt + (1 - alpha) * z
            p = alpha * p_since_last + (1 - alpha) * p
            p_since_last = 1
        else:
            p_since_last += 1
        forecast.append(z / p)
    return np.array(forecast)

# SBA = Croston × (1 - α/2)
def sba(y, alpha=0.4):
    return croston(y, alpha) * (1 - alpha / 2)

# TSB
def tsb(y, alpha=0.4, beta=0.2):
    z, p = y[y > 0][0], (y > 0).mean()
    forecast = []
    for yt in y:
        p = beta * (yt > 0) + (1 - beta) * p
        if yt > 0:
            z = alpha * yt + (1 - alpha) * z
        forecast.append(p * z)
    return np.array(forecast)

print(f"Croston forecast (last) = {croston(y, 0.4)[-1]:.2f}")
print(f"SBA     forecast (last) = {sba(y, 0.4)[-1]:.2f}")
print(f"TSB     forecast (last) = {tsb(y, 0.4, 0.2)[-1]:.2f}")

# Via statsforecast (mieux : avec intervalles)
from statsforecast import StatsForecast
from statsforecast.models import CrostonOptimized, CrostonSBA, TSB, ADIDA, IMAPA

df = pd.DataFrame({'unique_id': 'serie1', 'ds': pd.date_range('2024-01-01', periods=n, freq='D'),
                    'y': y})
sf = StatsForecast(models=[CrostonOptimized(), CrostonSBA(), TSB(alpha_d=0.2, alpha_p=0.2),
                              ADIDA(), IMAPA()], freq='D')
sf.fit(df)
forecast_sf = sf.predict(h=10, level=[95])
print(forecast_sf.head())

# Pour ML : Tweedie objective avec LightGBM
import lightgbm as lgb
# Tweedie distribution gère zéros + continu positif
# X = features (date, lag, covariables...), y = demand
# model = lgb.LGBMRegressor(objective='tweedie', tweedie_variance_power=1.5)
# model.fit(X_train, y_train)

# Évaluation : MASE et WAPE
def mase(y_true, y_pred, y_train, m=1):
    naive_mae = np.mean(np.abs(y_train[m:] - y_train[:-m]))
    return np.mean(np.abs(y_true - y_pred)) / naive_mae

def wape(y_true, y_pred):
    return np.sum(np.abs(y_true - y_pred)) / np.sum(np.abs(y_true))

# Service level (% lead time periods sans rupture)
def fill_rate(y_true, y_pred):
    return (y_pred >= y_true).mean()
```

## Pour aller plus loin

- Croston, *Forecasting and stock control for intermittent demands* (OR Quarterly 1972)
- Syntetos & Boylan, *The accuracy of intermittent demand estimates* (IJF 2005) — SBA paper
- Teunter, Syntetos, Babai, *Intermittent demand: Linking forecasting to inventory obsolescence* (EJOR 2011) — TSB
- Petropoulos, Makridakis, et al., *Forecasting* in IJF — articles régulièrement
- *Forecasting: Principles and Practice* — section intermittent (3e éd.)
- **Liens internes** : [[Exponential smoothing]], [[ARIMA SARIMA]], [[Forecasting metrics]], [[Forecasting framing]], [[statsforecast]] (service)
