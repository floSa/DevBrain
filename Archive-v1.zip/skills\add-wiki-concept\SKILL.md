---
name: add-wiki-concept
description: |
  Use this skill when the user wants to add a new concept fiche to the
  personal Wiki of DevBrain. Triggers: "ajoute le concept", "documente
  la notion", "ajoute une fiche concept", or when the user describes a
  notion they want to retrieve quickly later (statistical method, ML
  concept, LLM mechanism, system design idea). Generates a fiche
  compliant with Templates/Wiki-Concept.md in Wiki/Concepts/<Nom>.md.
---

# Skill — add-wiki-concept

## Quand l'utiliser

L'utilisateur veut **documenter une notion** dans son wiki personnel. Différent de `add-service` (outil concret) et de `add-wiki-outil` (outil utilisé par l'agent). Un concept est une **idée** qu'on veut retrouver vite dans 6 mois.

Exemples : ACP, RAG, bias-variance tradeoff, MCP protocol, walk-forward CV, embeddings.

## Pré-requis vault

L'utilisateur doit être en **mode wiki**. Périmètre strict : `Wiki/Concepts/` uniquement.

## Procédure

### Étape 1 — Vérifier la non-duplication

Cherche `Wiki/Concepts/**/<nom>*.md` et synonymes courants. Si la fiche existe déjà, propose de la **mettre à jour** plutôt qu'un doublon.

### Étape 2 — Catégoriser

Choisir la famille `concept/<famille>` selon le sujet :

| Famille | Exemples |
|---|---|
| `concept/stats` | ACP, AFC, FAMD, tests d'hypothèse, bootstrap, IC |
| `concept/ml` | bias-variance, regularization, cross-validation, ensembling |
| `concept/llm` | RAG, prompt caching, tool use, embeddings, agent loops |
| `concept/time-series` | stationnarité, ARIMA, forecasting framing, walk-forward |
| `concept/data` | data quality, schema drift, idempotence, normalization |
| `concept/system` | MCP, REST vs RPC, event sourcing, eventual consistency |

Si rien ne va, demande à l'utilisateur. Ne pas inventer.

### Étape 3 — Identifier les domaines pertinents

`domaines:` parmi : `data-science`, `data-eng`, `mlops`, `ml-eng`, `ai-eng`, `doc`. Un concept peut avoir plusieurs domaines.

### Étape 4 — Pré-remplir depuis source

Si l'utilisateur fournit URL/paper/article :
1. Invoke `defuddle` (kepano) ou WebFetch pour extraire le contenu
2. Pré-remplit : auteur clé, lecture estimée, points principaux

Sinon, demande à l'utilisateur la matière de base (1-2 paragraphes).

### Étape 5 — Frontmatter complet

```yaml
---
nom: <Nom du concept>
type: concept
categorie: concept/<famille>
sous_categories: [tag1, tag2]                    # tags fins, optionnel
domaines: [<liste de domaines pertinents>]
maturite: established | emerging | controversial
auteurs_cles: [<personnes ou orgas clés>]
lecture_min: <estimation en minutes pour lire la fiche>
status:                                          # vide en mode complet, 'stub' si stub
created: <YYYY-MM-DD>
modified: <YYYY-MM-DD>
tags: [concept, <famille-court>]
---
```

### Étape 6 — Corps en 6 sections fixes (template `Wiki-Concept.md`)

```markdown
# <Nom>

## TL;DR
(2-3 lignes pour retrouver le concept en 30 secondes)

## Le problème
(Ce qu'on essaie de résoudre. Sans le problème, pas besoin du concept.)

## L'idée
(Le mécanisme central. Schémas/exemples bienvenus.)

## Quand c'est utile
- 

## Quand ça ne marche pas / pièges
- 

## Implémentations concrètes
- [[<service ou skill>]] — usage typique

## Pour aller plus loin
- Paper / blog / talk
- Notes perso
```

### Étape 6bis — Repérer les fiches qui mentionnent déjà ce concept (via `find-connexes.ps1`)

**Avant** d'écrire, scanne le vault :

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/find-connexes.ps1 -Name "<Nom>"
```

Note la liste [FAIBLE] (mentions sans wikilink) — ce sont les fiches que `add-wikilinks.ps1` va patcher à l'étape 10.

### Étape 7 — Wikilinker (via `discover-links.ps1`)

**Toujours utiliser le script** plutôt que deviner. Il scanne tout le vault et propose les candidats les plus pertinents en se basant sur le frontmatter (catégorie, domaines, sous_categories, tags, alias).

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/discover-links.ps1 \
    -Title "<Nom>" \
    -Categorie "concept/<famille>" \
    -Domaines "<csv des domaines>" \
    -SousCategories "<csv des sous_categories>" \
    -Tags "<csv des tags>" \
    -TopN 15
```

Le script affiche un tableau scoré + une section "Liens internes" prête à copier-coller.

**Workflow** :
1. Lance le script avec les metadata pressentis pour la nouvelle fiche
2. Présente le top 10-15 candidats à l'utilisateur (avec scores et justifications)
3. L'utilisateur sélectionne ceux à garder
4. Insère les wikilinks retenus :
   - Dans le **TL;DR** : 2-3 liens vers concepts liés majeurs
   - Dans **L'idée** : liens vers prérequis
   - Dans **Implémentations concrètes** : services/outils qui implémentent
   - Dans **Pour aller plus loin** : section "Liens internes" structurée

**Important** :
- Ne **jamais** créer de wikilink vers une fiche qui n'existe pas (le script ne propose que des cibles existantes)
- Si une cible naturelle manque, propose à l'utilisateur de créer un stub d'abord
- Le score est indicatif — l'utilisateur reste seul juge de la pertinence

**Reverse linking** (optionnel mais conseillé) :
Après création, propose à l'utilisateur d'**ajouter la nouvelle fiche** comme wikilink dans les fiches top-score qui n'en ont pas encore. Workflow :
1. Pour chaque candidate du top 5, vérifie si la nouvelle fiche est déjà mentionnée
2. Si non, propose : "Ajouter `[[<NouveauNom>]]` dans la section X de `<candidate>` ?"

### Étape 8 — Demander validation

Avant écriture, montrer :
- Path cible : `Wiki/Concepts/<Nom>.md`
- Frontmatter complet
- TL;DR (la partie la plus importante — relue par toi dans 6 mois)

"OK pour écrire ?"

### Étape 9 — Écrire et rappeler

Path : `Wiki/Concepts/<Nom>.md`.

Rappelle à l'utilisateur les liens créés. Si des concepts liés n'existent pas encore, propose de créer des stubs.

### Étape 10 — Audit post-création + propagation des wikilinks

Après écriture, exécute la chaîne d'hygiène :

```bash
# Audit fantômes introduits dans la nouvelle fiche
powershell -ExecutionPolicy Bypass -File AI/scripts/find-connexes.ps1 -Path "Wiki/Concepts/<Nom>.md"

# Propage le wikilink [[<Nom>]] dans les fiches qui le mentionnent en bare
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "<Nom>" -All
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "<Nom>" -All -Apply

# Vérification finale : 0 fantôme attendu
powershell -ExecutionPolicy Bypass -File AI/scripts/report-ghosts.ps1
```

## Anti-patterns à éviter

- **Inventer du contenu** factuel — préfère TL;DR vague à TL;DR inventé
- **Mélanger concept et outil** — un *concept* ACP est différent du *service* prince
- **Sortir du périmètre Wiki/Concepts/** — ne touche pas à Services/, Patterns/, etc.
- **Wikilinks fantômes** — pas de `[[X]]` vers fichier inexistant
- **Surcharger le concept de code** — un concept doit rester explicatif. Le code va dans les fiches services/skills.

## Format minimal de stub

Si l'utilisateur demande explicitement un stub (ou via `process-inbox`) :

```yaml
---
nom: <Nom>
type: concept
categorie: concept/<famille>
sous_categories: []
domaines: []
maturite: 
auteurs_cles: []
lecture_min: 
status: stub
created: <today>
modified: <today>
tags: [concept, stub, <famille-court>]
---

# <Nom>

> **Stub** — à étoffer. Notes brutes : <source / 1 ligne contexte>
```

## Voir aussi

- `add-service` (outils concrets vs notions)
- `add-wiki-outil` (skills utilisés par l'agent)
- `add-wiki-workflow` (procédures step-by-step)
- `expand-stub` (étoffer un concept en status: stub)
- `cross-link` (audit des liens manquants entre concepts)
