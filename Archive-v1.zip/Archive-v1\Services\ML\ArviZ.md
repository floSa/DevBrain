---
galaxie: dev
nom: ArviZ
alias: [arviz]
categorie: ml/bayesian
sous_categories: [bayesian, visualization, diagnostics, pymc, mcmc]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["bayesplot (R)", "matplotlib direct"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, bayesian, visualization, diagnostics]
url_officiel: https://www.arviz.org/
url_docs: https://python.arviz.org/en/stable/
url_repo: https://github.com/arviz-devs/arviz
---

# ArviZ

## Pourquoi

Library Python pour **visualisation + diagnostics** de modèles bayésiens. Compatible **PyMC, NumPyro, Stan (CmdStanPy/PyStan), Pyro, emcee**. Standard pour produire :
- **Diagnostics MCMC** : R-hat (Gelman-Rubin), ESS (Effective Sample Size), trace plots, autocorrélation
- **Posterior predictive checks** : confronter postérieur aux observations
- **Comparaison de modèles** : LOO (Leave-One-Out), WAIC, model averaging
- **Plots postérieurs** : densités, forest plots, pair plots, energy plots

Format pivot : **`InferenceData`** (basé sur xarray) qui standardise les traces MCMC entre frameworks. Si tu fais du bayésien en Python, tu vas finir avec ArviZ.

## Quand l'utiliser

- **Diagnostiquer convergence MCMC** : R-hat > 1.01 ou ESS < 400 = problème
- **Posterior predictive checks** : `az.plot_ppc()` pour valider que ton modèle génère des data plausibles
- **Comparaison de modèles** : `az.compare()` avec LOO / WAIC (équivalent AIC/BIC bayésien)
- **Plots postérieurs publication-ready** : forest plots, HDI intervals
- **Combo [[PyMC]] / Stan / NumPyro** : le standard de facto
- **Pair plots** pour repérer corrélations / divergences HMC
- **Model checking** rigoureux dans un workflow Bayesian Workflow (Gelman)

## Quand NE PAS l'utiliser

- **Pas de modèle bayésien** → matplotlib / seaborn direct
- **Visualisation single-shot** : pour un histogramme simple, seaborn plus rapide
- **R user** → `bayesplot` (R) est l'équivalent natif
- **Workflow non-MCMC pur (variational)** : ArviZ supporte mais moins riche que pour MCMC

## Pièges connus

- **Format InferenceData spécifique** : il faut convertir manuellement si ton sampler n'a pas de conversion native (`az.from_dict`, `az.from_emcee`)
- **Performance sur très gros traces** : 100k+ samples × 4 chaînes × 1000 params → ArviZ rame, échantillonner ou thinning
- **Plots customizable mais doc à creuser** : beaucoup de kwargs cachés
- **R-hat seuil 1.01 strict** : ancienne litérature dit 1.1, nouvelle 1.01 (Vehtari et al 2021)
- **ESS bulk vs tail** : différencier ESS_bulk (centre) et ESS_tail (queues) — utile pour quantiles extrêmes
- **az.summary mal interprété** : les colonnes mcse_mean, mcse_sd sont les standard errors de l'estimation, pas les sd du posterior
- **plot_trace lent** sur multi-paramètres : filtrer avec `var_names`
- **LOO / WAIC peuvent échouer silencieusement** : Pareto k > 0.7 → estimation pas fiable, ArviZ warn mais on rate

## Code minimal

```bash
pip install arviz pymc
```

```python
import arviz as az
import pymc as pm
import numpy as np

# Modele simple : regression bayesienne
np.random.seed(42)
X = np.linspace(0, 10, 100)
y = 2.5 * X + 1.0 + np.random.normal(0, 1, 100)

with pm.Model() as model:
    alpha = pm.Normal("alpha", mu=0, sigma=10)
    beta = pm.Normal("beta", mu=0, sigma=10)
    sigma = pm.HalfNormal("sigma", sigma=1)
    mu = alpha + beta * X
    pm.Normal("y_obs", mu=mu, sigma=sigma, observed=y)

    idata = pm.sample(2000, tune=1000, chains=4, return_inferencedata=True)
    idata.extend(pm.sample_posterior_predictive(idata))

# Diagnostics
print(az.summary(idata, var_names=["alpha", "beta", "sigma"]))
# verifier r_hat < 1.01 et ess_bulk > 400

# Plots
az.plot_trace(idata, var_names=["alpha", "beta", "sigma"])
az.plot_posterior(idata, var_names=["alpha", "beta"], hdi_prob=0.94)
az.plot_ppc(idata, num_pp_samples=100)
az.plot_pair(idata, var_names=["alpha", "beta"], divergences=True)
```

```python
# Comparaison de modeles avec LOO
with pm.Model() as model_b:
    # un modele alternatif (e.g. avec un terme quadratique)
    ...
    idata_b = pm.sample(2000, idata_kwargs={"log_likelihood": True})

comp = az.compare({"linear": idata, "quadratic": idata_b}, ic="loo")
print(comp)   # rank, elpd_loo, dse, weight, ...
az.plot_compare(comp)
```

## Liens

- [[PyMC]] — combo classique (sampler bayésien)
- Stan / NumPyro / Pyro / emcee — autres samplers compatibles
- bayesplot (R) — équivalent dans l'écosystème R
- [[MCMC]] (concept)
- Bayesian Workflow (Gelman et al 2020) : https://arxiv.org/abs/2011.01808
- Docs : https://python.arviz.org/en/stable/
- GitHub : https://github.com/arviz-devs/arviz
