---
galaxie: dev
nom: FastAPI
alias: [fastapi]
categorie: framework/backend
sous_categories: [async, api, rest, openapi]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: ["Flask", "Django", "Litestar", "Express"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, framework, backend, python, async]
url_officiel: https://fastapi.tiangolo.com/
url_docs: https://fastapi.tiangolo.com/
url_repo: https://github.com/tiangolo/fastapi
---

# FastAPI

## Pourquoi
Framework backend Python async, basé sur Starlette + Pydantic. Validation automatique des entrées, génération OpenAPI native, performances proches de Node/Go. Standard de fait pour API REST en Python moderne.

## Quand l'utiliser
- API REST/GraphQL en Python
- Projets ML/IA exposant des endpoints (compatible avec asyncio, intégration aisée des inférences)
- Microservices Python
- Quand on veut une doc OpenAPI gratuite et à jour
- Quand on a besoin de validation forte des inputs

## Quand NE PAS l'utiliser
- App full-stack avec rendu serveur lourd → préférer Django (admin, ORM, batteries included)
- Pure API sync simple → Flask suffit, plus léger
- Equipe non-Python → utiliser ce que l'équipe maîtrise
- Besoins ultra-performants (μs) → Rust/Go

## Pièges connus
- **Pydantic v1 vs v2** : breaking changes en 2023, vérifier la version utilisée
- **Dépendances async/sync mélangées** : un endpoint async qui appelle du sync bloquant tue les perfs (utiliser `run_in_threadpool`)
- **Background tasks** : limitées, préférer un vrai broker ([[Redis]] + Dramatiq/Celery) pour la prod
- **Lifespan events** : utiliser le nouveau context manager `lifespan=` (le on_startup/on_shutdown est déprécié)
- **Documentation auto** : gourmande en RAM si nombreux endpoints, désactivable en prod (`docs_url=None`)
- **CORS** : le middleware par défaut n'est pas strict, configurer explicitement les origines

## Liens
- [[Pattern - API REST FastAPI minimale]]
- [[Pydantic]] — validation utilisée par FastAPI
- [[Uvicorn]] — serveur ASGI typique
- Doc officielle : https://fastapi.tiangolo.com/
- Tutoriel async best practices : https://fastapi.tiangolo.com/async/
