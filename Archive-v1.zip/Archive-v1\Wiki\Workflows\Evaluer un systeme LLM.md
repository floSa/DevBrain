---
galaxie: wiki
nom: Evaluer un systeme LLM
type: workflow
categorie: workflow/ai-eng
sous_categories: [eval, llm, metrics, golden-dataset]
domaines: [ai-eng, ml-eng]
duree_estimee: 1-3h pour un setup initial, puis itératif
prerequis: [système LLM en place, ~30 cas d'usage représentatifs identifiés]
created: 2026-05-19
modified: 2026-05-19
tags: [workflow, ai-eng, eval, llm]
---

# Évaluer un système LLM

## Quand l'utiliser

Tu as un système LLM (RAG, agent, classifieur, extracteur structuré) et tu veux **savoir s'il s'améliore ou se dégrade** au fil des tweaks. Sans eval, tu navigues à vue : un changement de prompt qui te semble bon peut casser 20 % de tes cas en silence.

À faire **avant** d'optimiser, pas après.

## Pré-requis

- Système LLM minimalement fonctionnel (même primitif)
- ~30 cas représentatifs de ton domaine (questions, documents, prompts)
- 1-2h de focus pour constituer le gold dataset

## Procédure

### 1. Constituer le gold dataset

Le plus important — un mauvais dataset = eval inutile.

```python
# src/myapp/eval/dataset.py
GOLD = [
    {
        "id": "gd-001",
        "question": "Comment configurer le timeout de Postgres ?",
        "expected_answer_contains": ["statement_timeout", "ms"],
        "expected_sources": ["docs/db/postgres.md"],
        "category": "config",
        "difficulty": "easy",
    },
    # ...30+ cases
]
```

Règles de constitution :
- **30 minimum, 100 idéal** — sous 30, les métriques sont du bruit
- **Couvre les catégories** : faciles, difficiles, edge cases, hors-scope (questions auxquelles le système doit dire "je ne sais pas")
- **Versionne dans Git** — c'est la baseline qui détecte les régressions
- **Pas de cas que le LLM a vu en few-shot** — sinon tu mesures la mémorisation

### 2. Choisir les métriques selon le système

| Système | Métriques minimum |
|---|---|
| **RAG** | Faithfulness, answer relevance, context precision (cf. [[Ragas]]) |
| **Classifieur** | Accuracy, F1, confusion matrix par classe |
| **Extractor** structured | Field-level precision/recall, schema compliance rate |
| **Chatbot conversationnel** | Helpfulness (rated 1-5), refus rate, latence p95 |
| **Agent (tool use)** | Tool selection accuracy, task completion rate, # steps moyen |

### 3. Setup d'éval reproductible

```python
# src/myapp/eval/run.py
import asyncio
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy, context_precision

async def run_eval():
    results = []
    for case in GOLD:
        response = await my_system.ask(case["question"])
        results.append({
            "question": case["question"],
            "answer": response.text,
            "contexts": response.retrieved_chunks,
            "ground_truth": case["expected_answer_contains"],
        })
    
    scores = evaluate(
        dataset=results,
        metrics=[faithfulness, answer_relevancy, context_precision],
    )
    return scores
```

### 4. Baseline + tracking

Note la baseline dans un CSV/Markdown versionné. À chaque changement majeur, refais tourner, compare.

```
# eval-history.md
| Date       | Commit  | Faithfulness | Answer Relev | Context Prec | Notes |
|------------|---------|--------------|--------------|--------------|-------|
| 2026-05-19 | abc1234 | 0.72         | 0.81         | 0.65         | baseline |
| 2026-05-20 | def5678 | 0.78         | 0.82         | 0.74         | +reranker cohere |
```

### 5. LLM-as-judge (avec précaution)

Pour les évaluations où la note humaine est trop coûteuse (helpfulness, fluency, conversational quality), utiliser un LLM comme juge :

- Modèle **différent et plus fort** que celui évalué (Claude Opus pour évaluer un système Claude Sonnet)
- Prompt structuré (rubric explicite, échelle, exemples)
- **Toujours valider sur 20-30 cas avec humain** pour mesurer la corrélation juge/humain

```python
JUDGE_PROMPT = """
Tu évalues une réponse d'assistant LLM. Note de 1 à 5 sur :
- helpfulness : la réponse aide-t-elle ?
- accuracy : est-elle correcte ?
- conciseness : est-elle adaptée en longueur ?

Réponse en JSON strict.
"""
```

### 6. Eval continue en CI

Une fois la baseline en place, branche l'eval sur la CI (sur PR ou nightly).

```yaml
# .github/workflows/eval.yml
on: [pull_request]
jobs:
  eval:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: uv run python -m myapp.eval.run --baseline main
      - run: # commenter sur la PR si delta > 5%
```

## Checklist de fin

- [ ] Gold dataset de 30+ cas versionné
- [ ] 3+ métriques pertinentes définies et automatisées
- [ ] Baseline notée dans un fichier d'historique
- [ ] Setup repro en 1 commande (`uv run python -m myapp.eval.run`)
- [ ] (Bonus) LLM-judge calibré vs humain
- [ ] (Bonus) Eval en CI sur les PRs

## Pièges courants

- **Dataset trop petit** (<20 cas) → métriques très bruitées
- **Dataset trop homogène** → tu n'évalues qu'un seul mode de défaillance
- **Pas de cas "négatifs"** (questions hors scope) → tu rates les hallucinations
- **LLM-as-judge sans validation humaine** → tu mesures peut-être le biais du juge plus que le système
- **Métriques absolues vs relatives** : 0.72 de faithfulness ne dit rien dans l'absolu. Le delta vs baseline compte.
- **Pas de tracking historique** → tu refais le même eval, mais sans comparer

## Variantes

- Pour un **chatbot conversationnel multi-tour**, ajouter des cas multi-tour dans le dataset (l'historique de conversation compte)
- Pour un **agent tool-use**, tracker `step_count`, `tool_calls`, `success_rate` plutôt que la qualité textuelle pure
- Pour un système **production temps réel**, ajouter latence p50/p95/p99 dans les métriques

## Voir aussi

- Concept : [[RAG]] (eval RAG spécifique)
- Services : [[Ragas]], [[TruLens]], [[Phoenix Arize]], [[DeepEval]]
- Pattern : [[Pattern - RAG basique]]
- Outils : [[claude-api]] (le skill connaît les bonnes pratiques eval)
