---
galaxie: wiki
nom: Perplexity
alias: [perplexité, PPL, branching factor]
type: concept
categorie: concept/info-theory
sous_categories: [perplexity, language-model, nll, evaluation]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Jelinek 1977]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, info-theory, perplexity, language-model]
---

# Perplexity — perplexité

## TL;DR

Métrique standard pour **évaluer les modèles de langue** : "à quel point le modèle est-il *perplexe* (surpris) face aux données ?". Mathématiquement, c'est l'**exponentielle de la cross-entropy** moyenne. Interprétation intuitive : **nombre effectif de choix équiprobables** que le modèle considère à chaque token. PPL = 10 → le modèle hésite comme s'il avait 10 choix équivalents.

## Le problème

Pour comparer deux modèles de langue sur les mêmes données, on veut une métrique qui :
- est **indépendante de la taille du dataset** (contrairement à la NLL totale)
- a une **interprétation intuitive** (vs la NLL pure)
- pénalise plus fortement les prédictions confiantes mais fausses (vs accuracy)

La perplexité satisfait les trois.

## L'idée

### Définition

Pour un modèle de langue $p_\theta$ et un texte $w_1, w_2, \dots, w_N$ :

$$ \text{PPL}(p_\theta) = \exp\left( -\frac{1}{N} \sum_{i=1}^N \log p_\theta(w_i | w_{<i}) \right) = e^{H(p_\theta, p_{\text{data}})} $$

C'est l'**exponentielle de la cross-entropy moyenne par token** (en nats), ou de manière équivalente :

$$ \text{PPL}(p_\theta) = 2^{H_2(p_\theta, p_{\text{data}})} \quad \text{(en bits)} $$

### Interprétation : branching factor

Si la perplexité vaut $K$, le modèle se comporte comme s'il **hésitait uniformément entre $K$ tokens** à chaque position.

Exemples concrets :
- Modèle parfait → PPL = 1 (aucune hésitation)
- Modèle uniforme sur vocabulaire de taille $V$ → PPL = $V$
- GPT-2 sur WikiText-103 : PPL ≈ 30
- GPT-3 175B sur LAMBADA : PPL ≈ 3-4
- LLMs récents (2026) : PPL < 3 sur la plupart des benchmarks

### Lien avec [[Cross-entropy]]

PPL = exp(CE). Donc baisser la PPL = baisser la CE = augmenter la log-vraisemblance.

C'est exactement ce qu'on optimise quand on entraîne un modèle de langue (next-token prediction).

### Variantes

#### Per-token perplexity

Standard, ce qu'on calcule par défaut.

#### Per-word perplexity

Important quand on **compare différents tokenizers** : un modèle byte-level a une PPL par token plus basse qu'un modèle word-level, mais ne signifie pas qu'il est meilleur. Il faut convertir en PPL par mot pour comparer équitablement :

$$ \text{PPL}_{\text{word}} = \exp\left(\frac{N_{\text{tokens}}}{N_{\text{words}}} \cdot \log \text{PPL}_{\text{token}}\right) $$

#### Bits-per-character (BPC)

Métrique alternative, surtout pour modèles character-level :

$$ \text{BPC} = \frac{1}{N_{\text{chars}}} \sum_i -\log_2 p(c_i | c_{<i}) $$

Plus bas = meilleur. Indépendant du tokenizer.

#### Perplexity sur conditional generation

Pour T5, BART, etc. : on calcule la PPL sur la portion à générer (target), conditionnée sur l'input.

## Quand c'est utile

- **Benchmark modèles de langue** : WikiText-103, OpenWebText, etc.
- **Monitoring training** : courbe PPL sur validation set en temps réel
- **Comparer modèles à tokenizers différents** : passer en PPL par mot ou BPC
- **Détection de drift en prod** : surveiller la PPL sur traffic réel (montée = drift de domaine)
- **Sélection de modèle** : à capacité égale, le plus bas PPL gagne

## Quand ça ne marche pas / pièges

- **PPL ≠ qualité subjective** : un modèle peut avoir une PPL excellente mais générer du contenu peu utile (problème classique de NLL avec mesure indirecte de qualité). Toujours croiser avec eval humaine ou benchmarks tâches.
- **Comparer tokenizers différents** sans normaliser → résultats trompeurs. Toujours convertir en PPL/mot ou BPC.
- **PPL sur texte hors-distribution** explose, ne reflète pas la qualité réelle du modèle
- **PPL sur tokens spéciaux** (`<eos>`, padding) — exclure ou non ? Conventions varient. Documenter ton choix.
- **Calcul sur texte long** : attention au context window — si le texte est tronqué, la PPL sera artificiellement haute sur les premiers tokens (modèle conditionné sur rien)
- **PPL et fine-tuning** : après instruction tuning, la PPL peut **monter** légèrement sur des benchmarks classiques tout en améliorant la qualité subjective. Pas un défaut, juste un mismatch métrique-objectif.

## Code minimal

```python
import torch
import torch.nn.functional as F
from math import exp

# Calcul de PPL sur une séquence
def perplexity(model, tokenizer, text, device='cuda'):
    model.eval()
    inputs = tokenizer(text, return_tensors='pt').to(device)
    
    with torch.no_grad():
        outputs = model(**inputs, labels=inputs['input_ids'])
        # outputs.loss est la cross-entropy moyenne par token
    
    ppl = exp(outputs.loss.item())
    return ppl

# Avec HuggingFace
from transformers import AutoModelForCausalLM, AutoTokenizer

model = AutoModelForCausalLM.from_pretrained("gpt2")
tokenizer = AutoTokenizer.from_pretrained("gpt2")

text = "The quick brown fox jumps over the lazy dog."
print(f"PPL = {perplexity(model, tokenizer, text):.2f}")

# Sliding window pour textes plus longs que context
def sliding_perplexity(model, tokenizer, text, max_length=1024, stride=512):
    encodings = tokenizer(text, return_tensors='pt')
    nlls = []
    for i in range(0, encodings.input_ids.size(1), stride):
        begin = max(i + stride - max_length, 0)
        end = min(i + stride, encodings.input_ids.size(1))
        input_ids = encodings.input_ids[:, begin:end].to('cuda')
        target_ids = input_ids.clone()
        target_ids[:, :-stride] = -100  # ignore loss on context
        with torch.no_grad():
            outputs = model(input_ids, labels=target_ids)
        nlls.append(outputs.loss * (end - max(i, begin)))
    return exp(torch.stack(nlls).sum() / encodings.input_ids.size(1))
```

## Pour aller plus loin

- Jelinek et al., *Perplexity—a measure of the difficulty of speech recognition tasks* (1977) — origine
- *Evaluation Metrics for Language Modeling* (HuggingFace blog) — pédagogique avec code
- Articles sur **PPL vs downstream tasks** (Hendrycks et al., MMLU) — discussion sur la limite de PPL comme proxy
- **Liens internes** : [[Cross-entropy]], [[Shannon entropy]], [[embeddings]], [[tool-use]]
