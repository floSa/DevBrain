---
galaxie: wiki
nom: Bayesian inference
alias: [bayes, inference bayesienne, posterior, prior]
type: concept
categorie: concept/statistics
sous_categories: [bayesian, posterior, prior, predictive, hierarchical]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Bayes 1763, Laplace 1812, Jeffreys 1939, Gelman]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, statistics, bayesian, posterior]
---

# Bayesian inference

## TL;DR

Cadre statistique où on **représente l'incertitude sur les paramètres par une distribution** (le prior), qu'on **met à jour avec les données** via la règle de Bayes pour obtenir le posterior. Sortie = **distribution complète sur $\theta$**, pas un point. Permet de quantifier l'incertitude naturellement, d'incorporer des connaissances préalables, et de faire des **prédictions probabilistes** rigoureuses. Outils standards : PyMC, Stan, NumPyro.

## Le problème

Les méthodes fréquentistes (MLE, IC) donnent des estimations ponctuelles + variabilité asymptotique. Mais :
- Comment quantifier l'incertitude **finie** rigoureusement ?
- Comment **incorporer** une expertise métier (priors) ?
- Comment faire des **prédictions** en propageant l'incertitude sur tous les paramètres ?

L'approche bayésienne répond à tout ça d'un coup.

## L'idée

### Règle de Bayes

$$ \underbrace{p(\theta | D)}_{\text{posterior}} = \frac{\overbrace{p(D | \theta)}^{\text{likelihood}} \overbrace{p(\theta)}^{\text{prior}}}{\underbrace{p(D)}_{\text{evidence}}} $$

- **Prior** $p(\theta)$ : ce qu'on croit avant de voir les données
- **Likelihood** $p(D | \theta)$ : probabilité des données sachant $\theta$
- **Posterior** $p(\theta | D)$ : croyance **mise à jour** après les données
- **Evidence** $p(D) = \int p(D | \theta) p(\theta) d\theta$ : constante de normalisation

### Workflow bayésien standard

1. **Spécifier le modèle génératif** : choisir likelihood + priors
2. **Calculer le posterior** : exact (conjugué), MCMC, ou variational inference
3. **Diagnostiquer la convergence** : R-hat, ESS, trace plots
4. **Posterior predictive checks** : générer des données simulées et comparer aux observées
5. **Inférence / décision** : moyennes/médianes/CrI du posterior, posterior predictive distribution

### Priors

- **Informatifs** : encoder une connaissance préalable (e.g. $\beta \sim \mathcal{N}(0, 1)$ si on s'attend à des effets modérés)
- **Faiblement informatifs** : régularisation douce (e.g. half-normal pour scales)
- **Non-informatifs / objectifs** : Jeffreys prior, uniforme — minimisent l'apport
- **Hierarchical priors** : priors sur les priors (multilevel models, partial pooling)

**Choix de prior** : pas neutre, à justifier. Préférer faiblement informatif sauf raison.

### Posterior

Caractérisé par :
- **Moyenne / médiane** : estimation ponctuelle
- **Crédibilité (CrI)** : intervalle contenant $1 - \alpha$ de la masse du posterior. Interprétation **directe** : "il y a 95% de chances que $\theta \in [a, b]$"
  - À comparer à l'IC fréquentiste : "si on répétait l'expérience, 95% des IC contiendraient $\theta$" — bien plus tortueux
- **Mode** = MAP (voir [[MAP estimation]])

### Posterior predictive

Pour prédiction sur nouvelle donnée $\tilde y$ :

$$ p(\tilde y | D) = \int p(\tilde y | \theta) p(\theta | D) d\theta $$

Intègre sur **toute l'incertitude** sur $\theta$. Pratique en bayésien via samples MCMC :

```
for sample θ_t in MCMC trace:
    ŷ_t = sample from p(y | θ_t)
```

Donne une **distribution de prédiction**, pas un point.

### Modèles conjugués (cas exacts)

Quand prior et likelihood se "mélangent bien", le posterior a une forme close :

| Likelihood | Prior conjugué | Posterior |
|---|---|---|
| Bernoulli / Binomial | Beta | Beta |
| Poisson | Gamma | Gamma |
| Normal (μ, σ² connue) | Normal | Normal |
| Normal (σ² inconnue) | Normal-Inv-Gamma | Normal-Inv-Gamma |
| Multinomial | Dirichlet | Dirichlet |

Utiles pédagogiquement et en démarrage froid (Thompson sampling).

### Modèles hiérarchiques / multilevel

Très puissant en bayésien :

$$ y_{ij} \sim \mathcal{N}(\mu_j, \sigma^2), \quad \mu_j \sim \mathcal{N}(\mu_0, \tau^2) $$

Effets aléatoires (mixed effects), partial pooling : les groupes "empruntent de la force" l'un à l'autre, sans full pooling ni no pooling.

Standard pour **A/B testing multi-bras**, **panel data**, **modèles mixtes**.

### Calcul du posterior

Souvent intractable analytiquement. Méthodes :

- **MCMC** ([[MCMC]]) : Metropolis-Hastings, Gibbs, HMC, NUTS — gold standard
- **Variational inference** : approximer le posterior par une famille paramétrique simple (mean-field, normalizing flows)
- **Laplace approximation** : gaussienne autour du MAP
- **Sequential Monte Carlo** : pour streaming
- **ABC (Approximate Bayesian Computation)** : si likelihood pas calculable mais simulable

### Model comparison

- **Bayes factor** : ratio des evidences $p(D | M_1) / p(D | M_2)$
- **WAIC / LOO-CV** : information criteria bayésiens, prennent en compte l'overfitting
- **Posterior predictive checks** : qualitatif

### Lien avec ML moderne

- **Bayesian deep learning** : poids des NN bayésiens (MC dropout, variational NN, ensembles)
- **Probabilistic programming** : PyMC, Stan, NumPyro, Pyro, Edward
- **Diffusion models** : score = $\nabla_x \log p(x)$, lien fort avec score-based inference
- **Gaussian processes** : full bayésien sur fonctions
- **Bayesian optimization** : optimiser une fonction coûteuse via GP + acquisition

## Quand c'est utile

- **Petits échantillons** : régularisation principielle, propagation d'incertitude rigoureuse
- **Connaissance experte à intégrer** : prior informatif
- **Décision sous incertitude** : intégrer sur posterior dans une utilité (decision theory)
- **Modèles hiérarchiques** : multilevel/mixed models naturels en bayésien
- **Quantification d'incertitude** : intervalles de crédibilité interprétables
- **A/B testing bayésien** : "probabilité que A > B" directe, sans p-value
- **Prediction probabiliste** : posterior predictive intègre l'incertitude
- **Calibration** : naturellement calibré (Bayes décision optimale)

## Quand ça ne marche pas / pièges

- **Coût computationnel** : MCMC sur gros modèles = lent. VI plus rapide mais approximé.
- **Choix du prior** : prior dominant les données = "le prior fait l'analyse" (red flag). Faire sensitivity analysis.
- **Modèles mal spécifiés** : posterior peut être confiant dans la mauvaise réponse. Toujours posterior predictive checks.
- **Multimodalité** : MCMC peut rater des modes, posterior multimodal difficile à résumer
- **Identifiabilité** : modèles non-identifiables → posterior dégénéré, problèmes de convergence
- **Reparamétrisation** : NUTS/HMC bien plus efficaces sur paramétrisation centrée/non-centrée selon contexte
- **Confondre prior et posterior** : un "intervalle de crédibilité à 95%" sous prior écrasant n'est pas data-driven
- **Convergence non-vérifiée** : utiliser MCMC sans diagnostic = invalid inference

## Code minimal

```python
import numpy as np
import pymc as pm
import arviz as az

# Modèle bayésien simple : régression linéaire
np.random.seed(0)
X = np.linspace(-1, 1, 100)
y = 2 * X + 1 + np.random.normal(0, 0.5, 100)

with pm.Model() as model:
    # Priors faiblement informatifs
    alpha = pm.Normal('alpha', mu=0, sigma=10)
    beta = pm.Normal('beta', mu=0, sigma=10)
    sigma = pm.HalfNormal('sigma', sigma=1)
    
    # Likelihood
    mu = alpha + beta * X
    y_obs = pm.Normal('y_obs', mu=mu, sigma=sigma, observed=y)
    
    # MCMC (NUTS)
    trace = pm.sample(2000, tune=1000, chains=4, target_accept=0.95)

# Résultats
print(az.summary(trace))
# Outputs : mean, sd, hdi_3%, hdi_97%, r_hat, ess

# Posterior predictive
with model:
    pp = pm.sample_posterior_predictive(trace)

# Intervalles de crédibilité directs
hdi = az.hdi(trace, hdi_prob=0.95)
print(f"95% CrI sur beta: {hdi['beta'].values}")

# Probabilité que beta > 1.5
beta_samples = trace.posterior['beta'].values.flatten()
print(f"P(β > 1.5 | D) = {np.mean(beta_samples > 1.5):.3f}")

# Comparaison avec un modèle alternatif (LOO)
# ... ajouter d'autres modèles puis az.compare(...)

# Exemple conjugué : Beta-Binomial (sans MCMC)
# Prior: Beta(α=2, β=2). Observe : 7 succès / 10 essais
# Posterior: Beta(α+s, β+n-s) = Beta(9, 5)
from scipy.stats import beta as beta_dist
posterior = beta_dist(9, 5)
print(f"Mean posterior: {posterior.mean():.3f}, 95% CrI: {posterior.interval(0.95)}")
```

## Pour aller plus loin

- Gelman et al., *Bayesian Data Analysis* (3e éd. 2013) — bible
- McElreath, *Statistical Rethinking* (2e éd. 2020) — pédagogique
- Kruschke, *Doing Bayesian Data Analysis* (2014) — accessible
- *Bayesian Methods for Hackers* (Davidson-Pilon) — gratuit, PyMC
- **Liens internes** : [[Maximum likelihood estimation]] (vs), [[MAP estimation]], [[MCMC]], [[PyMC]], [[A-B testing]] (bayésien)
