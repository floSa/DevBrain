---
galaxie: wiki
nom: Tokenization
alias: [BPE, WordPiece, SentencePiece, tiktoken, byte-level BPE, subword]
type: concept
categorie: concept/nlp
sous_categories: [tokenization, bpe, subword, llm]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Sennrich 2016 (BPE), Kudo 2018 (SentencePiece)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, nlp, llm, tokenization]
---

# Tokenization

## TL;DR

Transformer du **texte brut** en **séquence d'IDs** que le modèle peut digérer. Familles : **BPE** (Byte-Pair Encoding, GPT-2/3/4, Llama) — merge greedy ; **WordPiece** (BERT) — variante BPE ; **SentencePiece** (T5, Llama) — language-agnostic incluant **Unigram LM** ; **tiktoken** (OpenAI, BPE optimisé). Critique car : (1) **vocabulary size** affecte taille modèle & vitesse ; (2) **multilinguisme** dépend du tokenizer ; (3) **digit tokenization** affecte arithmétique ; (4) **special tokens** (BOS, EOS, system, etc.) définissent chat templates ; (5) **byte fallback** garantit qu'aucun caractère ne peut faire planter. Tokenizer mauvais = modèle handicapé.

## Le problème

Comment représenter du texte arbitraire (multilingue, code, emoji, math, URL) avec un **vocabulaire fini** ? Word-level tokenization échoue sur out-of-vocabulary. Character-level → séquences trop longues. **Subword** est le compromis moderne.

## L'idée

### BPE (Byte-Pair Encoding, Sennrich 2016)

Algorithme greedy :

1. Démarrer avec **vocab de caractères** + données comme séquences de chars
2. Compter toutes les paires adjacentes
3. **Merge la paire la plus fréquente** → nouveau token
4. Répéter jusqu'à vocab_size

**Résultat** : tokens fréquents → 1 token ; tokens rares → splittés en subwords.

Exemple : "tokenization" → ["token", "ization"] (si "ization" suffix fréquent)

### Byte-level BPE (GPT-2)

Plutôt que partir de chars Unicode, partir des **bytes** (256 valeurs initiales).

- **Garantie** : tout texte est représentable (jamais d'OOV)
- Gère naturellement Unicode (UTF-8 bytes)
- Standard moderne pour GPT, Llama, Qwen

### WordPiece (BERT)

Variante de BPE qui choisit le merge **maximisant la likelihood** au lieu de la fréquence.

- Préfixe `##` pour subwords (e.g. "##ization")
- BERT, DistilBERT, RoBERTa

### SentencePiece (Kudo 2018)

Tokenizer **language-agnostic** :
- Traite le texte comme **séquence de bytes** (whitespace inclus comme `▁`)
- Pas de prétraitement langue-spécifique
- Supporte deux algorithmes : **BPE** ou **Unigram LM**

#### Unigram LM (Kudo)

Approche probabiliste :
1. Init avec vocab très grand (toutes les substrings)
2. Estimer probas via EM
3. Élaguer les tokens les moins utiles
4. Final tokenization = Viterbi qui maximise la likelihood

Plus flexible que BPE, donne plusieurs tokenizations possibles → **subword regularization** (sampling pour data aug).

T5, Llama (SentencePiece BPE), mBART, Whisper.

### Tiktoken (OpenAI)

Tokenizer **rust-based** très rapide. BPE, vocab ~100K (GPT-4) ou 200K (GPT-4o).

```python
import tiktoken
enc = tiktoken.encoding_for_model("gpt-4")
tokens = enc.encode("Hello world!")
```

### Caractéristiques importantes

#### Vocabulary size

- **GPT-2** : 50,257
- **Llama 1/2** : 32,000
- **Llama 3** : 128,000 (multilingue ++)
- **GPT-4** : 100K (cl100k_base)
- **GPT-4o** : 200K (o200k_base)
- **Qwen2** : 152K

**Trade-off** :
- Vocab grand → moins de tokens par texte (cheaper inference, plus de context)
- Vocab grand → embedding/lm_head matrices énormes (ex. 128K × 4096 = 524M params)
- Vocab petit → séquences longues, rare tokens cassés en plus de sub-tokens

#### Multilinguisme

Tokenizer entraîné sur corpus majorité anglais → tokenize chinois/arabe à 3-5x plus de tokens qu'anglais. Coût de l'API multilingue gonfle.

**Solutions** : tokenizer multilingue dédié (XLM-R, Llama 3, Qwen).

#### Code

Code = whitespace strictement (Python indent), tokens longs (`__init__`, snake_case). Standard : préserver whitespace, BPE adapté. **Tiktoken** très efficace sur code.

#### Number tokenization

Crucial pour math/reasoning :
- GPT-3 : nombres tokenisés ensemble → modèle mauvais en math (`123456` = 1 token, opaque)
- Llama 2 : chaque digit séparé → meilleur en math
- GPT-4 : digits split par groupes de 3
- Convention moderne : split digit-par-digit pour math

#### Special tokens

Tokens spéciaux non-générables par BPE :
- `<bos>` / `<s>` : début sequence
- `<eos>` / `</s>` : fin
- `<pad>` : padding
- `<unk>` : unknown (rare avec byte-fallback)
- `<|system|>`, `<|user|>`, `<|assistant|>` : roles (chat template)
- `<|tool_call|>` : function calling
- `<|image|>` : multimodal

#### Chat templates

Format de prompt pour chat-tuned models. Llama 3 :

```
<|begin_of_text|><|start_header_id|>system<|end_header_id|>
You are a helpful assistant<|eot_id|>
<|start_header_id|>user<|end_header_id|>
Hello!<|eot_id|>
<|start_header_id|>assistant<|end_header_id|>
```

**Important** : utiliser le **bon chat template** du modèle. Hugging Face fournit `tokenizer.apply_chat_template()`.

#### Byte fallback

Si un caractère pas dans le vocab, fallback au niveau byte. Garantit qu'aucun input ne peut faire planter.

### Pièges connus

#### Glitch tokens (SolidGoldMagikarp)

Tokens dans le vocab mais **jamais vus** en training (e.g. usernames Reddit) → modèle hallucine sur ces tokens (Kelly 2023).

#### Tokenization inconsistencies

- `"hello"` vs `" hello"` : tokenize différemment (leading space significatif en BPE)
- Trimming espaces dans tools → drop info importante

#### Numerical operations cassées

`gpt-3.5 ` calcule "37 × 42" mal car tokenization opaque. Mieux : prompt avec espaces digit-par-digit.

#### Multilingual cost penalty

Une page en français = ~1.2x tokens d'une page en anglais. Une page en japonais = ~3x. Coût API correspondant.

### Best practices

1. **Toujours utiliser le tokenizer du modèle** : `AutoTokenizer.from_pretrained(model_id)`
2. **Comptabiliser les tokens avant call API** : `tiktoken` pour OpenAI, `tokenizer(text).input_ids` pour HF
3. **Chat templates via API** : `tokenizer.apply_chat_template(messages, tokenize=False)`
4. **Spécial tokens preservation** : si tu split du texte tokenisé, attention à ne pas couper en plein milieu d'un special token
5. **Multilingue** : préférer modèles avec tokenizer multilingue (Llama 3, Qwen)
6. **Code** : tokenizer GPT-4 / Codestral / Qwen-Coder efficient

## Quand c'est utile

- **Tout LLM** : ne peut pas y échapper
- **Counting cost API** : tiktoken pour estimer avant call
- **Custom domain (medical, legal, code)** : adapter le tokenizer peut gagner 20-30% tokens
- **Multilingue** : tokenizer adapté = 2-3x plus efficace
- **Embedding models** : même problématique
- **Custom training** : choisir/entraîner son tokenizer pour le domaine

## Quand ça ne marche pas / pièges

- **Token count != character count** : 1 token ≈ 4 chars (anglais), variable selon langue
- **Wrong tokenizer** : utiliser tokenizer GPT-2 sur Llama → garbage
- **Special tokens absents** : oublier `<bos>` / chat template → modèle confus
- **Trimming whitespace** : casse tokens en BPE (l'espace est dans le token)
- **Glitch tokens** : tokens jamais entraînés font halluciner
- **Math/code mal tokenisé** : impacte directement perf raisonnement
- **Multilingue penalty** : coût et latence gonflés sur langues mal supportées
- **Train sur tokenizer A, fine-tune sur tokenizer B** : impossible (embedding incompatibles)
- **Adding tokens post-hoc** : ajouter un token nécessite resize embedding + lm_head + retrain pour qu'il fonctionne
- **Token boundary leakage** : lors de chunking, couper en plein milieu d'un token (rare avec BPE byte-level)

## Code minimal

```python
# Hugging Face : tokenizer générique
from transformers import AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained("meta-llama/Meta-Llama-3-8B-Instruct")

text = "Bonjour, je suis floSa. Combien fait 37 × 42 ?"
tokens = tokenizer.encode(text)
print(f"Tokens: {tokens}")
print(f"Decoded: {tokenizer.decode(tokens)}")
print(f"Pieces: {[tokenizer.decode([t]) for t in tokens]}")
# Voir comment les digits sont tokenisés

# Chat template
messages = [
    {"role": "system", "content": "You are helpful."},
    {"role": "user", "content": "What's 37 * 42?"}
]
prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
print(prompt)

# Tiktoken (OpenAI)
import tiktoken
enc = tiktoken.encoding_for_model("gpt-4")
text = "How many tokens in this sentence?"
tokens = enc.encode(text)
print(f"{len(tokens)} tokens, cost ≈ {len(tokens) * 0.00001:.5f}$")

# Special tokens
print(f"BOS: {tokenizer.bos_token_id}, EOS: {tokenizer.eos_token_id}")
print(f"PAD: {tokenizer.pad_token}")

# Train custom BPE tokenizer
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import Whitespace

tokenizer_custom = Tokenizer(BPE(unk_token="<unk>"))
tokenizer_custom.pre_tokenizer = Whitespace()
trainer = BpeTrainer(vocab_size=10000, special_tokens=["<unk>", "<bos>", "<eos>"])
tokenizer_custom.train(files=["data.txt"], trainer=trainer)
tokenizer_custom.save("custom_tokenizer.json")

# SentencePiece
import sentencepiece as spm
# spm.SentencePieceTrainer.train(input="corpus.txt", model_prefix="m", vocab_size=8000)
# sp = spm.SentencePieceProcessor()
# sp.load("m.model")
# print(sp.encode_as_pieces("Hello world"))

# Counter tokens for cost estimation
def estimate_cost_gpt4(text, output_tokens=500):
    enc = tiktoken.encoding_for_model("gpt-4")
    input_tok = len(enc.encode(text))
    # Pricing 2026 (à vérifier)
    return input_tok * 0.00003 + output_tokens * 0.00006

# Multilingual comparison
texts = {
    "en": "Hello, how are you doing today?",
    "fr": "Bonjour, comment vas-tu aujourd'hui ?",
    "ja": "こんにちは、今日の調子はどうですか？",
    "code": "def fibonacci(n): return n if n < 2 else fib(n-1) + fib(n-2)"
}
for lang, text in texts.items():
    n_tok = len(enc.encode(text))
    print(f"{lang}: {n_tok} tokens ({n_tok / len(text):.2f} tok/char)")
```

## Pour aller plus loin

- Sennrich, Haddow, Birch, *Neural Machine Translation of Rare Words with Subword Units* (ACL 2016) — BPE
- Kudo, *Subword Regularization* (ACL 2018) — Unigram LM SentencePiece
- *tiktoken* (OpenAI) — fast BPE Rust impl
- *tokenizers* (Hugging Face) — Rust backend
- Karpathy, *Let's build the GPT Tokenizer* (YouTube)
- *Cyrl Geosmin* (Reddit), *glitch token* discussions — pathologies
- **Liens internes** : [[Self-attention]], [[embeddings]], [[Perplexity]], [[Transformer architectures]]
