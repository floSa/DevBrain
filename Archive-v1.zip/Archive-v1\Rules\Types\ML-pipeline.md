---
galaxie: dev
type: rule
domaine: ml-pipeline
applicable: type-ml
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, ml, ai, data-science]
---

# Règles — Type de projet : ML pipeline

## Principe
Reproductibilité avant tout. Données, modèles et code versionnés ensemble. Métriques baseline avant optimisation.

## MUST

- **Données versionnées** (DVC, Git-LFS, ou Lakehouse avec snapshots).
- **Modèles versionnés et tracés** (MLflow, Weights & Biases, ou registry interne).
- **Reproductibilité** : seed fixé, `requirements` pinned (lockfile), GPU/CPU matériel documenté.
- **Métriques baseline** documentées avant toute optimisation. "Mieux" doit avoir une référence.
- **Tests sur les transformations** de données (shape, ranges, NaN, distributions).

## SHOULD

- **Notebooks comme exploration**, pas comme code de prod. Convertir en `.py` après stabilisation.
- **Pipeline orchestrée** (Prefect, Airflow, Dagster, ou maison) — pas un script qui s'enchaîne.
- **Logging des expériences** : tous les runs traçables (params, metrics, artefacts).
- **Validation de schéma** des données entrantes (Pandera, Great Expectations).
- **Séparation stricte** train/val/test. Pas de leak.
- **Inférence séparée du training** : modèles déployés via service (FastAPI, BentoML, KServe).

## NICE-TO-HAVE

- Feature store (Feast, Tecton).
- A/B testing infra pour comparer modèles en prod.
- Monitoring des drifts (data drift, concept drift).
- Auto-retraining sur seuils de drift.

## Anti-patterns

- "Ça a marché sur ma machine" — sans docker, sans pin, sans seed.
- Modèles dans `git` (utiliser DVC, S3, registry).
- Pas de baseline → optimisation aveugle.
- Train + eval dans le même notebook qui se déroule "à la main".

## Outils

- Tracking : MLflow, W&B, Neptune
- Versioning : DVC, LakeFS, Pachyderm
- Orchestration : Prefect, Dagster, Airflow, Metaflow
- Serving : BentoML, KServe, Seldon, FastAPI maison
- Validation : Pandera, Great Expectations
- Notebooks reproductibles : Jupytext, Marimo

## Voir aussi

- [[Rules/Types/Data-pipeline]] — beaucoup en commun
- [[Rules/Global/Tests]]
