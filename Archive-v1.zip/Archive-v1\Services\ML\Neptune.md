---
galaxie: dev
nom: Neptune
alias: [neptune, neptune-ai]
categorie: ml/tracking
sous_categories: [tracking, experiments, cloud, metadata-store, monitoring]
licence: Propriétaire
licence_type: proprietary
hosted: cloud ou self (Enterprise)
maturite: production
langage: Python
clients_officiels: [python, r]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[Weights & Biases]]", "[[MLflow]]", "[[Aim]]", "[[Comet]]", "[[ClearML]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, tracking, cloud, metadata-store]
url_officiel: https://neptune.ai/
url_docs: https://docs.neptune.ai/
url_repo: https://github.com/neptune-ai/neptune-client
---

# Neptune

## Pourquoi

Plateforme **ML experiment tracking + metadata store** cloud. Différenciateur clé : structure **hiérarchique des metadata** (`run["params/lr"]`, `run["metrics/train/loss"]`) → tu peux logger 100k+ champs structurés, queries complexes, comparaisons fines.

Positionnement : alternative à W&B / Comet, **UI plus claire** et orientée data scientist (vs W&B orienté reports + sweeps). Particulièrement bien noté pour le tracking de **runs longs (foundation models, RL)** où la quantité de métadata explose. **Neptune Scale** (2024+) cible explicitement les workloads massifs.

## Quand l'utiliser

- **Équipe DS qui veut UI claire** sans setup self-host
- **Metadata hiérarchiques structurées** : not just metrics, mais artifacts, configs, files, lineage
- **Runs longs / massifs** (foundation models, RL) : Neptune scale > W&B sur 10k+ runs
- **Comparaisons fines** : table comparator multi-runs très puissant
- **Stack pricing OK** : tier gratuit Individual généreux pour solo
- **Reports collaboratifs** dashboards partagés
- **Combo Lightning / HF / PyTorch** : intégrations propres

## Quand NE PAS l'utiliser

- **Open-source obligatoire** → [[MLflow]] / [[Aim]] / [[ClearML]] (Neptune closed-source)
- **Self-host gratuit** : pas d'option, self-host = Enterprise payant
- **Très grande org / sweeps managed** → [[Weights & Biases]] plus mature
- **Communauté massive requise** : moins d'écosystème que W&B / MLflow
- **LLM tracking uniquement** → [[Langfuse]] / Opik plus naturel

## Pièges connus

- **Cloud only** par défaut : self-host = tier Enterprise payant
- **Pricing volume** : monitoring runs > X par mois → upgrade
- **Moins d'intégrations** que W&B / MLflow (mais essentiels OK : Lightning, HF, sklearn, XGBoost)
- **API key projet-scoped** : `NEPTUNE_PROJECT` + `NEPTUNE_API_TOKEN` à configurer
- **Async logging** : par défaut async (non-bloquant), penser à `run.wait()` avant exit script
- **Pivot Neptune Scale 2024** : focus enterprise / foundation models → roadmap individus moins claire
- **Structured logging verbeux** : `run["section/sub/metric"]` peut faire long
- **Export / lock-in** : export possible mais migration vers W&B / MLflow non triviale
- **Sweeps natifs limités** : Neptune track les sweeps externes (Optuna), n'orchestre pas comme W&B Sweeps

## Code minimal

```bash
pip install neptune
export NEPTUNE_API_TOKEN="..."
export NEPTUNE_PROJECT="floSa/llama-finetune"
```

```python
# Tracking standard
import neptune

run = neptune.init_run(
    project="floSa/llama-finetune",
    tags=["baseline", "lr-1e-4"],
)

# Metadata hierarchiques
run["params"] = {"lr": 1e-4, "batch_size": 32, "model": "llama-3-8b"}
run["dataset/version"] = "v3"
run["dataset/size"] = 12_345

for step in range(1000):
    train_loss = train_step()
    run["metrics/train/loss"].append(train_loss)
    if step % 100 == 0:
        val_loss = eval_step()
        run["metrics/val/loss"].append(val_loss)

# Artifacts
run["model/checkpoint"].upload("./model.bin")
run["plots/confusion_matrix"].upload("./cm.png")

run.stop()   # IMPORTANT : flush async
```

```python
# Integration Lightning
from lightning.pytorch.loggers import NeptuneLogger
import lightning as L

logger = NeptuneLogger(
    project="floSa/llama-finetune",
    log_model_checkpoints=True,
)
trainer = L.Trainer(logger=logger, max_epochs=10)
trainer.fit(model, datamodule)
```

## Liens

- [[Weights & Biases]] — alternative SaaS dominant
- [[MLflow]] — alternative open-source
- [[Aim]] / [[ClearML]] / [[Comet]] — alternatives tracking
- [[Optuna]] / [[Ray Tune]] — sweeps complémentaires (Neptune track les résultats)
- Docs : https://docs.neptune.ai/
- GitHub client : https://github.com/neptune-ai/neptune-client
- Site : https://neptune.ai/
