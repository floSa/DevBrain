---
galaxie: dev
nom: GitHub Actions
alias: [GHA, github-actions, gh-actions]
categorie: devops/ci
sous_categories: [ci, cd, automation]
licence: GitHub proprietary (free tier généreux)
licence_type: proprietary
hosted: managed
maturite: production
langage: YAML (config) + n'importe quoi (jobs)
clients_officiels: []
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: ["GitLab CI", "CircleCI", "Jenkins", "Drone CI"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, devops, ci, cd]
url_officiel: https://github.com/features/actions
url_docs: https://docs.github.com/en/actions
url_repo: https://github.com/actions
---

# GitHub Actions

## Pourquoi
CI/CD intégrée à GitHub, gratuite pour repos publics et généreuse pour privés. Marketplace énorme d'actions réutilisables. Default raisonnable pour tout projet hébergé sur GitHub.

## Quand l'utiliser
- Projet hébergé sur GitHub
- Besoin de CI standard (lint, test, build, deploy)
- Workflows réactifs (sur push, PR, release, schedule)
- Automatisations diverses (release notes, déploiements, scheduled jobs)

## Quand NE PAS l'utiliser
- Projet hors GitHub → GitLab CI / Drone CI selon hôte
- Builds très longs / GPU custom → self-hosted runners ou solutions dédiées
- Besoin de pipelines visuels complexes → CircleCI est plus mature là-dessus
- Sensibilité forte à la souveraineté → on-prem (Jenkins, Drone CI)

## Pièges connus
- **Coûts cachés** : repos privés, les minutes Linux × multiplicateurs (Windows ×2, macOS ×10) montent vite
- **Secrets** : ne pas mettre les vrais secrets en dur, utiliser `secrets.*` ou OIDC
- **Cache** : `actions/cache` indispensable pour Python/Node/Rust, sinon CI lente
- **Permissions GITHUB_TOKEN** : par défaut très larges. Restreindre via `permissions:` au début du workflow
- **Re-run des jobs failed** : pas atomique, peut relancer ce qui a déjà passé
- **Reusable workflows vs composite actions** : choisir tôt, conversion pénible
- **Action de tiers** : pinner par SHA (pas par tag) pour éviter supply chain attacks

## Pattern minimal Python

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main]
  pull_request:

permissions:
  contents: read

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
          cache: pip
      - run: pip install -e ".[dev]"
      - run: ruff check .
      - run: pytest --cov
```

## Liens
- [[Pattern - API REST FastAPI minimale]] — exemple de CI complète
- Pinning SHA : https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions
- Actions marketplace : https://github.com/marketplace?type=actions
- Awesome Actions : https://github.com/sdras/awesome-actions
