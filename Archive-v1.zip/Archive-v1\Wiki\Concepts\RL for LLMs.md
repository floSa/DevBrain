---
galaxie: wiki
nom: RL for LLMs
alias: [RL for LLMs, RLHF, RLAIF, DPO, GRPO, reasoning RL, post-training, alignment]
type: concept
categorie: concept/llm-training
sous_categories: [rl, llm, alignment, post-training, rlhf, dpo, grpo, reasoning]
domaines: [ai-eng, ml-eng]
maturite: emerging
auteurs_cles: [Christiano 2017, Ouyang 2022 (InstructGPT), Rafailov 2023 (DPO), DeepSeek 2024-2025 (GRPO, R1), Anthropic (CAI), AllenAI (Tulu 3)]
lecture_min: 10
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, rl, alignment, post-training]
---

# RL for LLMs

## TL;DR

Page de synthèse sur l'application du RL aux LLMs (post-training). Trois grandes vagues : (1) **RLHF avec PPO** (InstructGPT 2022, ChatGPT) — RM neural + PPO ; (2) **Offline methods** (DPO 2023, KTO, ORPO) — pas de RL explicite, optimisation directe sur préférences, devenu standard ; (3) **Reasoning RL** (GRPO, R1 2024-2025) — récompenses verifiables, raisonnement émergent. Stack 2026 typique : **SFT → DPO/IPO → RLHF iterative ou GRPO** selon objectif (chat alignment vs reasoning). RLAIF / Constitutional AI complètent côté safety. Cette fiche fait le pont entre [[Reinforcement learning]] et les algos LLM-spécifiques.

## Le problème

Un LLM **pretrained** (Llama base, etc.) sait continuer du texte mais ne sait pas :
- Suivre des instructions ("résume ce document")
- Refuser des requêtes dangereuses
- Rester cohérent / utile / honnête
- Calibrer son ton selon le contexte
- Raisonner étape par étape sur des problèmes durs

Le **post-training** sert à imprimer ces qualités. SFT marche pour les bases, mais a des limites (compounding errors, ne pénalise pas les mauvaises réponses, plafonné par les démonstrations). **Le RL pour LLMs** vient combler ce gap.

## L'idée

### Pipeline canonique (2022-2026)

```
                     [Pretrained base model]
                              │
                              ▼ SFT (= [[Imitation learning]] sur instructions)
                     [SFT / Instruct model]
                              │
                              ├──► PPO RLHF        (lourd, mais flexible)
                              │
                              ├──► DPO / IPO / KTO  (offline, simple, 2024+ standard)
                              │
                              └──► GRPO + verifiable rewards  (reasoning, R1-style)
                              │
                              ▼
                     [Aligned / reasoning model]
                              │
                              ▼ optionnellement
                     [Distill vers modèles plus petits]
```

### Phase 1 — SFT (Supervised Fine-Tuning)

Pure [[Imitation learning]]. Maximum likelihood sur paires (prompt, response). Sources : démonstrations humaines, GPT-4 outputs, conversations.

**Forces** : simple, marche bien comme bootstrap.

**Limites** :
- Compounding errors token-by-token
- Plafonné par la qualité des démos
- Pas de signal de "ce qui ne marche pas"
- Catastrophic forgetting des capacités base

### Phase 2 — RLHF avec PPO (Christiano 2017, InstructGPT 2022)

Voir [[RLHF and DPO]] et [[PPO]] pour les détails.

```
1. Collecter préférences : (prompt, y_w, y_l)
2. Entraîner Reward Model r_φ (loss Bradley-Terry) — voir [[Reward modeling]]
3. Fine-tuner LLM avec PPO :
   maximize  r_φ(x, y) - β · KL(π_θ || π_SFT)
```

**Avantages** :
- Performance excellente quand bien fait
- Flexible : tout reward signal possible
- Online : exploration possible

**Inconvénients** :
- 4 modèles en mémoire (policy + ref + RM + critic)
- Instable, tuning sensible (β, lr, batch)
- Reward hacking — voir [[Reward shaping and hacking]]
- Cher en compute

Standard de 2022-2023 (InstructGPT, ChatGPT, Claude v1). Progressivement remplacé par DPO pour chat.

### Phase 2 alternative — DPO (Rafailov 2023)

**Innovation conceptuelle** : la politique optimale au problème RLHF a une forme close en fonction du reward. On peut donc **dériver une loss qui optimise la policy directement sur les préférences, sans RM ni RL**.

$$ \mathcal{L}_{\text{DPO}} = -\mathbb{E}_{(x, y_w, y_l)} \log \sigma\left(\beta \log \frac{\pi_\theta(y_w|x)}{\pi_{\text{ref}}(y_w|x)} - \beta \log \frac{\pi_\theta(y_l|x)}{\pi_{\text{ref}}(y_l|x)}\right) $$

C'est de la **classification logistique** sur paires, juste 2 modèles en mémoire (policy + ref).

**Avantages** :
- Simple à implémenter
- Stable
- Sample-efficient (offline)
- Devenu standard 2024+ (Llama 3, Tulu 3, etc.)

**Inconvénients** :
- Pas d'exploration online
- Distribution shift entre data offline et policy
- Suboptimal pour reasoning rewards (binaires verifiable)

### Variantes DPO

| Méthode | Idée | Note |
|---|---|---|
| **DPO** | Forme close du RLHF optimum | standard 2024+ |
| **IPO** | DPO + régularisation contre overfit | Azar 2024 |
| **KTO** | Labels binaires "good/bad" (Kahneman-Tversky) | Ethayarajh 2024 |
| **ORPO** | Combine SFT + alignment en 1 étape | Hong 2024 |
| **SimPO** | Pas de ref model | Meng 2024 |
| **APO** | Anchored Preference Optimization | improvements 2024 |
| **β-DPO** | β adaptatif | recherche |

### Phase 3 — Reasoning RL (GRPO, R1)

[[GRPO]] = PPO sans critic, avantage = z-score dans un groupe de samples du même prompt.

**Recette R1 (DeepSeek 2025)** :
1. SFT court sur quelques milliers d'exemples CoT
2. GRPO massif sur math et code, **récompenses verifiables** (binaires : test passe / réponse correcte)
3. Reward composé : format reward (`<think>...</think><answer>...</answer>`) + correctness
4. KL légère vers SFT
5. Distillation vers modèles plus petits

**Émergent observé** : self-correction, backtracking, chain-of-thought sans avoir été explicitement entraîné à les produire.

**Followups** : Qwen-QwQ, Kimi-K1.5, OpenReasoner-Zero, Tulu 3 — tous suivent peu ou prou la recette.

### Verifiable rewards : le game changer

Pour math, code, jeu : la qualité est **objectivement vérifiable** :
- Math : extraire la réponse, comparer au ground truth
- Code : exécuter les tests unitaires
- Structured output : valider un schéma

**Avantages massifs** :
- Pas de RM neural à entraîner → pas de reward hacking sur le RM
- Reward dense binaire mais clean
- Scaling possible (millions de problèmes)
- Reproducible

C'est la raison du **boom des reasoning models** 2024-2026. Là où on a un vérificateur, on peut faire du RL massif.

### Constitutional AI / RLAIF (Anthropic)

Variante où le **RM est remplacé par un LLM critique** suivant une "constitution" écrite (principes : "ne pas tromper", "ne pas aider à des actions illégales", etc.).

Pipeline :
1. **SL-CAI** : modèle critique ses outputs selon la constitution, révise → SFT sur les révisions
2. **RL-CAI** : RM entraîné sur préférences AI (pas humain)

**Avantage** : scalable, pas de bottleneck human annotation. **Risque** : biais de la constitution, modèle qui sycophantise sur ses propres règles.

### RLAIF en pratique

- Anthropic Claude (Constitutional AI)
- Direct Nash Optimization (Yuan 2024) : self-play sur préférences AI
- Self-Rewarding LLM : modèle juge ses propres outputs

### Iterative RLHF (Tulu 3, Llama 3 style)

Loop :
1. SFT
2. Collecter préférences sur outputs **du modèle courant**
3. RM update (ou DPO direct)
4. Fine-tune (DPO ou PPO)
5. Goto 2

Combat le distribution shift. Standard pour les modèles open de pointe 2024.

### Récapitulatif comparatif

| Méthode | RM | RL | Modèles | Use case |
|---|:-:|:-:|:-:|---|
| SFT | ✗ | ✗ | 1 | bootstrap |
| RLHF (PPO) | ✓ | ✓ | 4 | flexible, alignment |
| DPO | implicite | ✗ | 2 | **default chat 2024+** |
| KTO | implicite | ✗ | 2 | data simple (good/bad) |
| ORPO | implicite | ✗ | 1 | single-stage |
| GRPO | verifiable / RM | ✓ | 2-3 | **default reasoning 2024+** |
| Constitutional AI | AI-RM | ✓ | 3 | safety |

### Best practices 2026

1. **Toujours commencer par SFT** : DPO/GRPO sans SFT décent = catastrophe
2. **Quality > quantity en preference data** : 10k paires propres > 100k bruitées
3. **DPO first pour chat alignment** : simple, stable, marche
4. **GRPO + verifiable pour reasoning** : math, code, science
5. **Iterative** : re-collecter préférences sur model courant à chaque round
6. **β KL bien calibré** : trop bas = hacking, trop haut = stuck
7. **Eval multi-axes** :
   - Task perf (MMLU, HumanEval, GSM8K)
   - Chat (MT-Bench, Arena Hard, AlpacaEval)
   - Safety (HarmBench, ToxiGen)
   - Length-controlled (éviter verbosity bias)
8. **Audit reward hacking** : sample top-reward, lecture humaine
9. **Combiner verifiable + RM** : RM pour soft signals (style), verifiable pour hard signals (correctness)
10. **Distill vers petits modèles** : un 7B distillé de R1 vaut mieux qu'un 7B trained from scratch

### Implementations / libs

- **TRL** (HuggingFace) : implémentation officielle SFT, DPO, KTO, ORPO, RewardTrainer, PPO, GRPO
- **TrlX** (CarperAI) : RLHF scalable
- **OpenRLHF** : distributed RLHF
- **Axolotl** : config-driven SFT/DPO
- **veRL** (ByteDance) : large-scale RLHF/GRPO
- **trl-extension / unsloth** : memory-efficient fine-tuning

## Quand c'est utile

- **Chat alignment** : tout LLM grand-public
- **Refusal / safety training** : RLHF + safety RM
- **Reasoning** : GRPO + verifiable
- **Style / persona** : DPO sur préférences stylistiques
- **Reduction de hallucinations** : preference data spécifique
- **Domain alignment** : médical, juridique avec experts
- **Multilingue** : iterative DPO sur préférences localisées
- **Agent training** : trajectoires d'outils → SFT puis RL

## Quand ça ne marche pas / pièges

- **Pas de SFT préalable** : DPO/PPO échouent souvent sans bootstrap décent
- **Preference data noise** : annotateurs en désaccord 20-30% → plafond inhérent
- **Reward hacking** sur RM : voir [[Reward modeling]], [[Reward shaping and hacking]]
- **Catastrophic forgetting** : capacités base (math, code) dégradent si preference data biaisée vers chat
- **Mode collapse** : modèle stuck sur une seule structure de réponse
- **Length bias** : verbosity explose si pas de length-controlled eval
- **Sycophancy** : modèle apprend à plaire au RM (proxy humain)
- **Distribution shift offline/online** : DPO sur data SFT, policy s'éloigne → reward implicite faux
- **GRPO sans verifiable** : si reward signal mauvais, GRPO ne fait pas mieux que PPO
- **Constitutional bias** : la constitution reflète biais de ses auteurs (souvent SF Bay)
- **Eval contamination** : MT-Bench / Arena Hard sur prompts proches du train set
- **Iterative DPO en boucle** : peut sur-aligner sur préférences artificielles, drifting from human values

## Code minimal

```python
# Pipeline 1 : SFT (via TRL)
from trl import SFTTrainer, SFTConfig
from transformers import AutoTokenizer, AutoModelForCausalLM
from datasets import load_dataset

tok = AutoTokenizer.from_pretrained("meta-llama/Meta-Llama-3-8B")
model = AutoModelForCausalLM.from_pretrained("meta-llama/Meta-Llama-3-8B", torch_dtype="bf16")
ds = load_dataset("HuggingFaceH4/ultrachat_200k")

config = SFTConfig(
    output_dir="./sft", per_device_train_batch_size=4,
    learning_rate=2e-5, num_train_epochs=1, max_seq_length=2048, bf16=True,
)
SFTTrainer(model=model, args=config, train_dataset=ds["train_sft"], tokenizer=tok).train()
```

```python
# Pipeline 2 : DPO sur le modèle SFT
from trl import DPOTrainer, DPOConfig
from datasets import load_dataset

sft_model = AutoModelForCausalLM.from_pretrained("./sft", torch_dtype="bf16")
ds = load_dataset("argilla/ultrafeedback-binarized-preferences-cleaned")

config = DPOConfig(
    output_dir="./dpo", per_device_train_batch_size=2,
    learning_rate=5e-7, num_train_epochs=1,
    beta=0.1, loss_type="sigmoid",
    max_length=2048, max_prompt_length=1024, bf16=True,
)
DPOTrainer(model=sft_model, args=config,
           train_dataset=ds["train"], tokenizer=tok).train()
```

```python
# Pipeline 3 : GRPO pour reasoning (math)
from trl import GRPOTrainer, GRPOConfig
import re

def math_reward_fn(completions, prompts, ground_truths, **kw):
    rewards = []
    for completion, gt in zip(completions, ground_truths):
        fmt_ok = bool(re.search(r"<answer>(.*?)</answer>", completion, re.DOTALL))
        fmt_bonus = 0.1 if fmt_ok else 0.0
        m = re.search(r"<answer>(.*?)</answer>", completion, re.DOTALL)
        if m:
            try:
                correct = abs(float(m.group(1).strip()) - float(gt)) < 1e-6
            except ValueError:
                correct = m.group(1).strip() == gt
            rewards.append(1.0 + fmt_bonus if correct else fmt_bonus)
        else:
            rewards.append(fmt_bonus)
    return rewards

dpo_model = AutoModelForCausalLM.from_pretrained("./dpo", torch_dtype="bf16")
config = GRPOConfig(
    output_dir="./grpo", per_device_train_batch_size=4,
    num_generations=8, max_completion_length=2048,
    learning_rate=1e-6, beta=0.04, epsilon=0.2,
    bf16=True, num_train_epochs=1,
)
GRPOTrainer(model=dpo_model, args=config,
            tokenizer=tok, train_dataset=math_dataset,
            reward_funcs=[math_reward_fn]).train()
```

```python
# Eval multi-axes minimal
def eval_suite(model, tokenizer):
    return {
        "math_gsm8k": eval_gsm8k(model, tokenizer),
        "code_humaneval": eval_humaneval(model, tokenizer),
        "chat_mt_bench": eval_mt_bench(model, tokenizer),     # LLM-as-judge
        "safety_harmbench": eval_harmbench(model, tokenizer),
        "length_control": eval_alpaca_eval_length_controlled(model, tokenizer),
    }
# Logger ces 5 métriques pour détecter régression sur dimensions non-ciblées par RL.
```

## Pour aller plus loin

- Christiano et al., *Deep RL from Human Preferences* (NeurIPS 2017)
- Ouyang et al., *Training language models to follow instructions with human feedback* (InstructGPT, 2022)
- Rafailov et al., *Direct Preference Optimization* (NeurIPS 2023)
- Bai et al., *Constitutional AI: Harmlessness from AI Feedback* (Anthropic 2022)
- Shao et al., *DeepSeekMath* (2024) — GRPO
- DeepSeek-AI, *DeepSeek-R1* (2025)
- Lambert et al., *Tulu 3: Pushing Frontiers in Open Language Model Post-Training* (AllenAI 2024)
- Dubey et al., *The Llama 3 Herd of Models* (Meta 2024) — recette post-training détaillée
- TRL HuggingFace : https://huggingface.co/docs/trl/
- Allen AI OLMo / Tulu / Open Instruct repo : https://github.com/allenai/open-instruct
- Awesome RLHF : https://github.com/opendilab/awesome-RLHF
- **Liens internes** : [[RLHF and DPO]], [[PPO]], [[GRPO]], [[Reward modeling]], [[Reward shaping and hacking]], [[SFT]], [[Imitation learning]], [[Reasoning models]], [[Reinforcement learning]], [[Policy gradient]]
