---
galaxie: wiki
nom: Poisson process
alias: [processus de Poisson, Poisson distribution, processus ponctuel]
type: concept
categorie: concept/probability
sous_categories: [poisson-process, point-process, count, queueing, arrival]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Poisson 1837]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, probability, poisson-process, point-process]
---

# Poisson process — processus de Poisson

## TL;DR

Modèle canonique d'**événements aléatoires dans le temps** (ou l'espace), avec un **taux $\lambda$ constant** et des occurrences **indépendantes**. Le nombre d'événements dans un intervalle $[0, t]$ suit une loi de Poisson de paramètre $\lambda t$. Modélise : arrivées clients, défauts de produits, sinistres, clics web, mutations génétiques, photons reçus...

## Le problème

Modéliser un **flux d'événements** simples où :
- Chaque événement arrive de manière indépendante
- Le taux moyen ne change pas dans le temps
- Pas deux événements simultanés

Le processus de Poisson est le **modèle de base** dans ces hypothèses.

## L'idée

### Définition (processus de Poisson homogène)

$N(t)$ = nombre d'événements dans $[0, t]$ est un processus de Poisson de taux $\lambda > 0$ si :

1. $N(0) = 0$
2. **Incréments indépendants** : $N(t_2) - N(t_1)$ indépendant de $N(s_2) - N(s_1)$ pour intervalles disjoints
3. **Distribution** : pour tout $s, t > 0$ :

$$ N(s + t) - N(s) \sim \text{Poisson}(\lambda t) $$

soit $\mathbb{P}(N(s+t) - N(s) = k) = \frac{(\lambda t)^k e^{-\lambda t}}{k!}$

### Loi de Poisson — rappel

Si $X \sim \text{Poisson}(\mu)$ :
- $\mathbb{P}(X = k) = \frac{\mu^k e^{-\mu}}{k!}$
- $\mathbb{E}[X] = \mu, \, \text{Var}(X) = \mu$ (moyenne = variance, **équidispersion**)

### Temps inter-arrivées

Si $T_1, T_2, \dots$ sont les temps **entre événements consécutifs**, alors $T_i \overset{i.i.d.}{\sim} \text{Exp}(\lambda)$ :

$$ \mathbb{P}(T_i > t) = e^{-\lambda t} $$

Connue comme la **propriété de mémoire-less** de l'exponentielle : $P(T > t + s \mid T > s) = P(T > t)$ — la durée déjà attendue n'influence pas la suite.

### Liens fondamentaux

| Quantité | Loi |
|---|---|
| Nombre d'événements $N(t)$ | Poisson($\lambda t$) |
| Temps inter-arrivées $T_i$ | Exp($\lambda$) |
| Temps du $k$-ème événement $S_k = T_1 + \dots + T_k$ | Gamma($k, \lambda$) (Erlang) |
| Conditionnel : sachant $N(t) = n$, les temps d'arrivée | uniformes sur $[0, t]$ |

### Extensions

#### Processus de Poisson non-homogène

Le taux $\lambda(t)$ varie dans le temps. Nombre d'événements dans $[a, b]$ suit Poisson($\int_a^b \lambda(s) ds$).

Cas typique : appels client suivent une rythmique journalière (taux haut en journée, bas la nuit).

#### Processus de Poisson composé

Chaque événement porte une "marque" $Y_i$ (i.i.d.). Le total $S(t) = \sum_{i=1}^{N(t)} Y_i$ est un processus de Poisson composé.

Cas typique : sinistres en assurance — fréquence des sinistres = Poisson, montant de chaque sinistre = distribution.

#### Processus de Poisson spatial

Mêmes propriétés sur un espace $\mathbb{R}^d$ : nombre d'événements dans une région $A$ suit Poisson($\lambda \cdot \text{vol}(A)$).

Modèles : étoiles dans une portion de ciel, fissures sur un matériau, occurrences d'une espèce sur un territoire.

#### Doubly stochastic / Cox process

Le taux $\lambda$ est **lui-même aléatoire**. Modèle plus flexible pour la sur-dispersion (variance > moyenne).

### Vérifier l'hypothèse de Poisson

Tests classiques :
- **Test de dispersion** (variance/moyenne ≈ 1)
- **QQ-plot** des temps inter-arrivées vs Exp
- **Test de Kolmogorov-Smirnov** sur les inter-arrivées

Si variance >> moyenne (sur-dispersion) : passer à **Binomiale négative** ou Cox process.

## Quand c'est utile

- **File d'attente** : modèle d'arrivées en théorie des files (M/M/1, M/G/1...)
- **Counts en régression** : régression Poisson pour modéliser un nombre d'événements (sinistres, ventes, défauts)
- **Survival analysis** : hazard rate constant → modèle exponentiel = Poisson process
- **Telecommunications** : arrivées de paquets
- **Web analytics** : clics, sessions
- **Bioinformatique** : mutations le long d'un génome
- **Photons en imagerie** (bruit de Poisson)
- **A/B testing avec count outcomes** : tests basés sur Poisson

## Quand ça ne marche pas / pièges

- **Sur-dispersion** : variance > moyenne — données réelles souvent sur-dispersées (clustering d'événements). Solutions : Binomiale négative, Cox.
- **Sous-dispersion** : variance < moyenne — distribution Conway-Maxwell-Poisson
- **Événements pas indépendants** : burst d'activité (DDoS, soldes). Hawkes process / self-exciting models.
- **Taux variable mal modélisé** : approximation homogène alors que le taux varie → Poisson non-homogène
- **Confusion Poisson vs binomial** : binomial = nombre fixe d'essais ; Poisson = nombre d'événements en temps fixe. À grande N et faible p, binomial ≈ Poisson.
- **Régression Poisson "robust"** sans correction : si sur-dispersion, les SE sont sous-estimés. Utiliser quasi-Poisson ou NB.

## Code minimal

```python
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

# Simuler un processus de Poisson de taux λ sur [0, T]
def simulate_poisson_process(lam, T):
    n_events = np.random.poisson(lam * T)
    times = np.sort(np.random.uniform(0, T, n_events))
    return times

# Ou via inter-arrivées
def simulate_via_interarrivals(lam, T):
    times = []
    t = 0
    while True:
        t += np.random.exponential(1 / lam)
        if t > T: break
        times.append(t)
    return np.array(times)

lam, T = 5, 10  # 5 événements/unité, 10 unités de temps
times = simulate_poisson_process(lam, T)
print(f"{len(times)} événements sur [0, {T}], attendu ≈ {lam * T}")

# Vérification : nombre suit Poisson(λT)
n_simulations = 10000
counts = [np.random.poisson(lam * T) for _ in range(n_simulations)]
print(f"Moyenne: {np.mean(counts):.2f}, Variance: {np.var(counts):.2f}")
# Les deux ≈ λT = 50

# Régression Poisson (count data)
from sklearn.linear_model import PoissonRegressor
X = np.random.randn(100, 3)
y = np.random.poisson(np.exp(X @ np.array([0.3, -0.5, 0.2])))
model = PoissonRegressor(alpha=0.1).fit(X, y)
print(f"Coefficients: {model.coef_}")

# Test de dispersion
disp_ratio = np.var(y) / np.mean(y)
print(f"Dispersion ratio: {disp_ratio:.2f}")  # ≈ 1 si Poisson, > 1 si sur-disp
```

## Pour aller plus loin

- Ross, *Introduction to Probability Models* (12e éd.) — chap. 5 sur processus de Poisson
- Daley & Vere-Jones, *An Introduction to the Theory of Point Processes* — référence avancée
- *Hawkes processes* (Laub et al.) — extension aux processus auto-excitants
- **Liens internes** : [[Markov chains]], [[Central limit theorem]], [[Brownian motion]], [[lifelines]]
