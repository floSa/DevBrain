---
galaxie: dev
nom: MinIO
alias: [minio]
categorie: storage
sous_categories: [object-storage, s3-compatible, self-hosted]
licence: AGPL-3.0
licence_type: open-source
hosted: both
maturite: production
langage: Go
clients_officiels: [python, ts, go, java, dotnet, rust]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[AWS S3]]", "[[Cloudflare R2]]", "Backblaze B2", "Garage", "SeaweedFS"]
remplace: ["[[AWS S3]]"]
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, storage, object-storage, s3, self-hosted]
url_officiel: https://min.io/
url_docs: https://min.io/docs/minio/linux/index.html
url_repo: https://github.com/minio/minio
---

# MinIO

## Pourquoi
Object storage S3-compatible self-hosted. Single binary Go, déploiement trivial (Docker / K8s), API 1:1 avec S3 → tout SDK S3 fonctionne. Le défaut pour stocker des blobs sans dépendre d'un cloud.

## Quand l'utiliser
- Avoir du "S3" en local (dev, staging, on-prem prod)
- Migration progressive S3 → on-prem (compatibilité 100%)
- Backup ou data lake self-hosted
- Tests de code S3 sans payer / sans réseau
- Hosting de modèles ML, datasets, artefacts CI

## Quand NE PAS l'utiliser
- Cloud-native pur AWS → [[AWS S3]] direct (moins d'ops)
- Faible volume avec budget → [[Cloudflare R2]] ou Backblaze B2 (egress gratuit / cheap)
- Fichiers chiffrés clientside avec sharing user-friendly → solutions dédiées
- **Licence AGPL** : si tu redistribues du code qui consomme MinIO en SaaS, lis bien la licence (subscription commerciale dispo)

## Pièges connus
- **AGPL** : implications sur le code distribué, pas un détail
- **Erasure coding** : par défaut sur 4+ disques, à comprendre avant déploiement (perte de capacité contre tolérance)
- **Versioning** : à activer explicitement par bucket
- **Lifecycle rules** : syntaxe S3 mais quelques limites (vérifier compat)
- **MinIO Console** : UI web utile, mais à ne pas exposer publiquement
- **Migration from filesystem** : MinIO n'aime pas qu'on touche aux fichiers en dehors de son API
- **Récents changements** : le mode "single drive" et certaines features ont évolué — vérifier la doc à jour

## Liens
- Client `mc` (MinIO Client) : https://min.io/docs/minio/linux/reference/minio-mc.html
- Helm chart : https://github.com/minio/minio/tree/master/helm
- Python SDK (boto3 standard) : utiliser `endpoint_url=` pointant sur MinIO
