---
galaxie: wiki
nom: KL divergence
alias: [Kullback-Leibler divergence, divergence KL, relative entropy]
type: concept
categorie: concept/info-theory
sous_categories: [kl-divergence, distance, relative-entropy, asymmetric]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Kullback-Leibler 1951]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, info-theory, kl, divergence]
---

# KL divergence — divergence de Kullback-Leibler

## TL;DR

Mesure d'**écart** entre deux distributions $p$ et $q$ : "combien d'information on perd en utilisant $q$ pour approximer $p$". **Pas une vraie distance** (asymétrique, ne satisfait pas l'inégalité triangulaire). Fondation de l'inférence variationnelle, VAEs, RLHF, distillation, divergence entre modèles.

## Le problème

On veut quantifier à quel point une distribution prédite $q$ s'écarte d'une distribution cible $p$. Cas typiques :

- $p$ = vraie distribution des données, $q$ = modèle. À quel point le modèle est-il faux ?
- $p$ = posterior bayésien exact, $q$ = approximation variationnelle. À quel point l'approximation est-elle mauvaise ?
- $p$ = output d'un teacher (distillation), $q$ = output du student.

La KL répond à ces questions.

## L'idée

### Définition

Pour deux distributions $p$ et $q$ sur le même espace discret :

$$ D_{\text{KL}}(p \| q) = \sum_i p_i \log \frac{p_i}{q_i} = \mathbb{E}_{x \sim p}\left[\log \frac{p(x)}{q(x)}\right] $$

Cas continu : remplacer somme par intégrale.

### Propriétés

- **Non-négative** : $D_{\text{KL}}(p \| q) \geq 0$ (inégalité de Gibbs)
- **Zéro ssi $p = q$** : presque partout
- **Asymétrique** : $D_{\text{KL}}(p \| q) \neq D_{\text{KL}}(q \| p)$ en général
- **Pas une métrique** : ne satisfait pas l'inégalité triangulaire
- **Infinie** si $\exists i : q_i = 0$ et $p_i > 0$ (support de $q$ doit couvrir celui de $p$)
- **Invariante par reparamétrisation** : $D_{\text{KL}}$ ne dépend pas du choix de variable

### Lien avec [[Cross-entropy]] et [[Shannon entropy]]

$$ D_{\text{KL}}(p \| q) = H(p, q) - H(p) $$

En classification supervisée, $H(p)$ est constant (entropie de la vraie distribution) → minimiser cross-entropy = minimiser KL.

### Forward vs reverse KL

Direction cruciale en pratique :

- **Forward KL** $D_{\text{KL}}(p \| q)$ — **mass-covering** : $q$ doit couvrir tout le support de $p$. Si $p > 0$ en un point et $q = 0$, la KL explose. Tendance à étaler $q$.

- **Reverse KL** $D_{\text{KL}}(q \| p)$ — **mode-seeking** : $q$ peut concentrer sur un mode de $p$ et ignorer les autres. Si $q > 0$ et $p = 0$, KL explose. Tendance à se concentrer.

```
p = bimodal, q = unimodal :

Forward KL :  q s'étale entre les 2 modes (covers all mass)
Reverse KL :  q se concentre sur 1 seul mode (mode collapse)
```

Choix selon le contexte :
- **VAE** (ELBO) utilise reverse KL : $D_{\text{KL}}(q \| p)$
- **MLE / Cross-entropy** = forward KL
- **Distillation** utilise typiquement forward (student = q apprend à matcher teacher = p)
- **RLHF / DPO** : utilise des variantes (forward/reverse selon formulation)

### KL pour distributions continues — cas gaussien

Pour deux gaussiennes 1D $p = \mathcal{N}(\mu_1, \sigma_1^2)$, $q = \mathcal{N}(\mu_2, \sigma_2^2)$ :

$$ D_{\text{KL}}(p \| q) = \log \frac{\sigma_2}{\sigma_1} + \frac{\sigma_1^2 + (\mu_1 - \mu_2)^2}{2 \sigma_2^2} - \frac{1}{2} $$

Très utilisé en VAE (où on calcule la KL entre la loi approximée $q(z|x)$ et le prior $p(z) = \mathcal{N}(0, I)$).

### ELBO et inférence variationnelle

L'**Evidence Lower BOund** :

$$ \log p(x) = \mathbb{E}_{z \sim q}[\log p(x, z) - \log q(z|x)] + D_{\text{KL}}(q \| p(z|x)) $$

Maximiser ELBO = minimiser reverse KL vers le posterior. Base de l'inférence variationnelle, VAE, et beaucoup d'algos bayésiens.

## Quand c'est utile

- **VAEs** : terme de régularisation
- **Inférence variationnelle** (PyMC SVI, BlackBox VI)
- **Distillation de modèles** (teacher → student)
- **RLHF / DPO** : pénalité de divergence par rapport au modèle de référence
- **Détection de drift** (KL entre distribution d'entraînement et de prod)
- **Information bottleneck** et autres principes info-théoriques
- **A/B testing** bayésien (comparer posteriors)

## Quand ça ne marche pas / pièges

- **Support disjoint** : $D_{\text{KL}}(p \| q) = \infty$. En pratique on smoothe les distributions ou on utilise [[Jensen-Shannon divergence]] (toujours finie) ou [[Wasserstein distance]] (gère le support disjoint).
- **Confusion forward/reverse** : faire le mauvais choix peut détruire le modèle (mode collapse en VAE si on inverse l'ELBO)
- **Mauvaise interprétation comme distance** : asymétrique, pas d'inégalité triangulaire
- **Estimation sur échantillon** : nécessite estimer $p$ et $q$ ; estimateurs naïfs biaisés sur petit $N$
- **KL en haute dimension** : peut exploser même pour des distributions "proches" (curse of dimensionality)
- **Choix de l'unité** (nats vs bits) : impact sur l'échelle d'interprétation

## Code minimal

```python
import torch
import torch.nn.functional as F
import numpy as np
from scipy.stats import entropy

# Discret — scipy
p = np.array([0.5, 0.3, 0.2])
q = np.array([0.4, 0.4, 0.2])
kl_pq = entropy(p, q, base=2)  # D_KL(p || q) — note l'ordre (p first)

# PyTorch — pour deep learning
log_p = F.log_softmax(logits_p, dim=-1)
log_q = F.log_softmax(logits_q, dim=-1)

# F.kl_div(input, target) : input doit être log-probas, target probas
# Calcule sum target * (log target - input)
kl = F.kl_div(log_q, log_p.exp(), reduction='batchmean')

# KL pour deux gaussiennes (cas VAE)
def kl_gaussian(mu, log_var):
    """KL(N(mu, sigma) || N(0, I)) avec log_var = log sigma^2"""
    return -0.5 * torch.sum(1 + log_var - mu.pow(2) - log_var.exp())
```

## Pour aller plus loin

- Kullback & Leibler, *On Information and Sufficiency* (1951) — paper original
- Cover & Thomas, *Elements of Information Theory* — chap. 2
- *VAE tutorial* (Kingma) — section sur l'ELBO et la reverse KL
- **Liens internes** : [[Shannon entropy]], [[Cross-entropy]], [[Jensen-Shannon divergence]], [[Wasserstein distance]], [[Mutual information]]
