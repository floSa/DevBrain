---
galaxie: dev
nom: dynaconf
alias: [dynaconf]
categorie: tooling/config
sous_categories: [config, multi-env, secrets, python, vault, layered]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python, cli]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[Pydantic]] Settings", "[[python-dotenv]]", "[[hydra]]", "environs"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, config, multi-env, secrets]
url_officiel: https://www.dynaconf.com/
url_docs: https://www.dynaconf.com/
url_repo: https://github.com/dynaconf/dynaconf
---

# dynaconf

## Pourquoi

Lib de config Python **multi-env + multi-format** : TOML, YAML, JSON, INI, `.env`, env vars, **HashiCorp Vault**, Redis, AWS Secrets Manager. Layered configuration (default → env → custom layer → secrets), validation, lazy loading, CLI dédiée (`dynaconf list`, `dynaconf write`), plugins **Flask / Django / FastAPI**.

Cible : applications **production** où la config vient de plusieurs sources (fichier YAML pour structure, `.env` pour dev local, Vault pour secrets prod) et tu veux que ce soit transparent pour le code. Plus puissant que `python-dotenv`, plus simple que `hydra`. Concurrent direct de `pydantic-settings` (moins typé mais plus de backends).

## Quand l'utiliser

- **Multi-env sérieux** : dev / staging / prod avec overrides hiérarchiques
- **Backends de secrets** : Vault, Redis, AWS Secrets Manager intégrés natifs
- **Multi-format** : TOML pour la structure + `.env` pour dev + Vault pour secrets
- **Flask / Django app** avec config riche : plugins officiels
- **CLI overrides + env vars** combinés proprement
- **Hot-reload** possible (lazy loading)
- **Layered defaults** : `[default]` → `[development]` → `[production]` dans un seul `settings.toml`
- **Validation** : `Validator("DATABASE_URL", must_exist=True)`

## Quand NE PAS l'utiliser

- **ML experiments** (composition + sweeps) → [[hydra]]
- **Config simple** (.env + 10 vars) → [[python-dotenv]] + [[Pydantic]] Settings
- **FastAPI moderne** : `pydantic-settings` plus naturel (typage + Pydantic 2)
- **API typée stricte** : Dynaconf est faiblement typé (Boxed dict) → Pydantic Settings mieux
- **Communauté énorme requise** : Dynaconf a moins de momentum 2024+ vs pydantic-settings

## Pièges connus

- **API plus complexe** que python-dotenv → onboarding plus long
- **Magic attributes** : `settings.FOO` peut renvoyer `None` silencieusement si pas défini → utiliser Validators
- **Doc parfois lacunaire** sur edge cases (interaction Vault + env, validation conditionnelle)
- **Moins de momentum 2024+** : releases plus rares, communauté plus modeste que pydantic-settings
- **Typage faible** : `settings.PORT` renvoie un string si pas casté → préciser via `@int` or Validator
- **Variable d'env `ENV_FOR_DYNACONF`** : choisit le namespace (default, development, production) — facile à oublier
- **Loading order** subtil : env vars > secrets > custom layer > env section > default
- **Vault backend** : config init non triviale (token / role / mount point)
- **Boxed dict** (`settings.deep.nested.value`) : pratique mais cache parfois des typos silencieuses

## Code minimal

```bash
pip install "dynaconf[vault,redis]"
```

```toml
# settings.toml
[default]
name = "MyApp"
debug = false
database = { url = "sqlite:///app.db", pool_size = 5 }

[development]
debug = true
database.url = "postgres://dev:dev@localhost/dev"

[production]
debug = false
database.url = "@format {env[DATABASE_URL]}"
database.pool_size = 20

# .secrets.toml (gitignored)
[default]
OPENAI_API_KEY = "sk-..."
```

```python
# config.py
from dynaconf import Dynaconf

settings = Dynaconf(
    envvar_prefix="MYAPP",                    # MYAPP_DEBUG=true overrides
    settings_files=["settings.toml", ".secrets.toml"],
    environments=True,                         # active layers [default]/[development]/[production]
    load_dotenv=True,                          # lit aussi .env
    env_switcher="ENV_FOR_MYAPP",
)
```

```python
# Usage
from config import settings

print(settings.name)
print(settings.database.url)
print(settings.OPENAI_API_KEY)
```

```bash
# Switcher d'env
ENV_FOR_MYAPP=production python app.py

# Override via env var (envvar_prefix)
MYAPP_DEBUG=true python app.py

# CLI
dynaconf list
dynaconf write toml -e production -v DATABASE__URL=postgres://...
```

```python
# Validation + Vault
from dynaconf import Dynaconf, Validator

settings = Dynaconf(
    envvar_prefix="MYAPP",
    settings_files=["settings.toml"],
    vault_enabled=True,
    vault={"url": "https://vault.example.com", "token": "..."},
    validators=[
        Validator("DATABASE_URL", must_exist=True),
        Validator("PORT", default=8000, gte=1, lte=65535),
        Validator("DEBUG", is_type_of=bool),
    ],
)
settings.validators.validate()   # leve erreur si invalide
```

## Liens

- [[Pydantic]] Settings (`pydantic-settings`) — alternative typed moderne **recommandée** pour FastAPI/apps Pydantic
- [[python-dotenv]] — alternative simple .env
- [[hydra]] — alternative ML / experiments
- environs — alternative orientée parsing typé
- Plugins Flask / Django / FastAPI : https://www.dynaconf.com/integrations/
- Docs : https://www.dynaconf.com/
- GitHub : https://github.com/dynaconf/dynaconf
