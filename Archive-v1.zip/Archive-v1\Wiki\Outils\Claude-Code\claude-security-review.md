---
galaxie: wiki
nom: security-review
type: claude-code-skill
plateforme: claude-code
categorie: skill/code-quality
sous_categories: [security, audit, sast]
auteur: Anthropic
source: claude-code natif
source_url: https://docs.claude.com/en/docs/claude-code
install_cmd: 
install_doc: 
licence: 
licence_type: proprietary
domaines: [data-eng, mlops, ai-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, security, audit]
---

# security-review

## Pourquoi

Skill **bundled** spécialisé **revue de sécurité** : il scanne les changements en cours sur la branche pour détecter des vulnérabilités courantes (SQL injection, secrets en dur, désérialisation unsafe, deps avec CVE connues, IAM/perms trop ouvertes, etc.).

Différent de [[claude-review]] : `review` regarde la qualité globale ; `security-review` ne regarde QUE la sécu mais en profondeur.

## Quand l'utiliser

- Avant de merger une PR qui touche à l'auth, aux secrets, aux entrées utilisateur, aux requêtes SQL
- Sur un projet ML qui ouvre une API (model serving) → vérifier input validation, rate-limiting
- Quand tu intègres une nouvelle dépendance et que tu veux check les usages dangereux
- Audit ponctuel avant prod

## Quand NE PAS l'utiliser

- Code purement notebook / exploration → ROI faible
- Comme remplacement d'un vrai SAST (Snyk, Semgrep, Bandit, Trivy) → c'est un complément, pas un substitut

## Comment l'installer

Natif Claude Code, déclenchable via `/security-review`.

## Exemples d'usage

```
> /security-review
> security-review uniquement les fichiers modifiés depuis main
> propose des tests adversariaux pour les nouveaux endpoints
```

## Pièges connus

- Faux positifs courants sur les "secrets en dur" : les chaînes constantes utilisées en tests sont flaggées
- Ne remplace pas un audit pro pour les apps grand public ou produit financier

## Liens

- Doc Claude Code : https://docs.claude.com/en/docs/claude-code
