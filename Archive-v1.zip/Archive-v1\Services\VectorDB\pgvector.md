---
galaxie: dev
nom: pgvector
alias: [pgvector, pg-vector]
categorie: database/vector
sous_categories: [postgres-extension, hnsw, ivfflat]
licence: PostgreSQL
licence_type: open-source
hosted: both
maturite: production
langage: C
clients_officiels: [tout client Postgres]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Qdrant]]", "[[Weaviate]]", "[[Milvus]]", "[[Chroma]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, database, vector, postgres, extension]
url_officiel: https://github.com/pgvector/pgvector
url_docs: https://github.com/pgvector/pgvector#readme
url_repo: https://github.com/pgvector/pgvector
---

# pgvector

## Pourquoi
**Extension Postgres** qui ajoute un type `vector` et des opérateurs de similarité (`<->`, `<#>`, `<=>`). Tu vis dans Postgres → tu fais du vector search dans Postgres. Pas de service séparé, pas de duplication, transactions ACID gratuites. Pragmatique gagnant pour la majorité des projets.

## Quand l'utiliser
- Tu utilises déjà [[Postgres]]
- Volume modéré (< 10-50M vecteurs)
- Filtrage relationnel important (joins SQL avec tes autres tables)
- Tu veux une seule source de vérité, pas un dual-write app/vector-DB
- Cohérence transactionnelle requise entre tes données métier et tes embeddings

## Quand NE PAS l'utiliser
- Très grande scale ou très haut throughput → [[Qdrant]] / [[Milvus]]
- Pas de Postgres dans le projet → installer Postgres pour pgvector seulement = perdant face à [[Qdrant]] / [[Chroma]]
- Besoin de hybrid search (BM25 + dense) avancé → pgvector le permet (FTS Postgres + vector) mais [[Weaviate]] / [[Qdrant]] sont mieux outillés
- Index très spécifiques (DiskANN, IVF-PQ optimisé) → solutions dédiées

## Pièges connus
- **Index HNSW vs IVFFlat** : HNSW recommandé en général (meilleur recall), IVFFlat plus rapide à construire
- **Index `m`, `ef_construction`** : à tuner selon volume et exigence recall/latency
- **`maintenance_work_mem`** : à augmenter pour la création d'index (sinon très lent)
- **Filtrage + ANN** : pre-filter exact (lent sur gros datasets) vs post-filter (peut perdre du recall) — vérifier les query plans
- **Dimension limit** : max 16000 (ajusté par version), généralement suffisant
- **Version mismatch** : extension vs Postgres version à vérifier

## Liens
- [[Postgres]] — base
- [[Qdrant]], [[Weaviate]], [[Milvus]] — alternatives serveur dédié
- README pgvector : https://github.com/pgvector/pgvector
- Tutoriel HNSW pgvector : https://supabase.com/blog/increase-performance-pgvector-hnsw
- pgvecto.rs (alternative Rust extension) : https://github.com/tensorchord/pgvecto.rs
