---
galaxie: dev
nom: BentoML
alias: [bentoml, bento]
categorie: ml/serving
sous_categories: [model-serving, packaging, python-first]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python
clients_officiels: [python, rest, grpc]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Ray Serve]]", "[[NVIDIA Triton]]", "[[KServe]]", "[[Seldon Core]]", "[[FastAPI]] custom"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ml, serving, python]
url_officiel: https://bentoml.com/
url_docs: https://docs.bentoml.com/
url_repo: https://github.com/bentoml/BentoML
---

# BentoML

## Pourquoi
Framework Python pour **packager et servir** des modèles ML. Décorateurs `@bentoml.service`, gestion des runners, batching adaptatif, génération automatique d'OpenAPI, build d'images Docker. Pour passer d'un modèle à une API HTTP/gRPC en quelques lignes.

## Quand l'utiliser
- Servir un modèle ML/LLM en HTTP/gRPC sans réécrire le boilerplate
- Multi-modèles dans un même service (ensemble, A/B testing)
- Adaptive batching (regroupement automatique de requêtes)
- Pipeline ML complet : preprocessing + modèle + postprocessing
- Build automatique d'une image Docker → K8s

## Quand NE PAS l'utiliser
- Charge énorme avec besoin perf maximale → [[NVIDIA Triton]]
- Besoin Ray ecosystem complet (training + serving) → [[Ray Serve]]
- App très simple, juste une fonction → [[FastAPI]] custom suffit

## Pièges connus
- **Versions 1.x → 1.2+** : refactor majeur (`@bentoml.service` API), suivre la doc à jour
- **Runners** : abstraction puissante mais courbe d'apprentissage
- **Adaptive batching** : à activer/régler selon latence cible (`max_latency_ms`)
- **Bento store** : artefacts dans `~/bentoml/`, à monter en CI
- **Python only** : si tu veux servir en Go/Rust, regarde Triton
- **BentoCloud (managed)** : pricing à valider

## Liens
- [[Ray Serve]], [[NVIDIA Triton]] — alternatives serving
- [[MLflow]] — pour le model registry en amont
- [[Docker]] — `bentoml containerize` génère l'image
- Quickstart : https://docs.bentoml.com/en/latest/get-started/quickstart.html
