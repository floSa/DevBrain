---
galaxie: wiki
nom: Factor Analysis of Mixed Data (FAMD)
alias: [FAMD, AFDM, Analyse Factorielle des Données Mixtes]
type: concept
categorie: concept/stats
sous_categories: [factor-analysis, mixed-data, categorical, continuous]
domaines: [data-science]
maturite: established
auteurs_cles: [Pagès 2004, Lê & Pagès]
lecture_min: 10
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, famd, factor-analysis, mixed]
---

# Factor Analysis of Mixed Data (FAMD)

## TL;DR

Analyse factorielle pour des données comportant **simultanément des variables continues et catégorielles**. Mathématiquement, c'est un pont entre [[PCA]] (continu) et [[MCA]] (catégoriel) : on pondère chaque type de variable pour qu'elles contribuent équitablement à l'inertie totale, puis on fait une PCA sur le tableau unifié.

## Le problème

La plupart des datasets réels mélangent les deux types :
- Données patient : âge (continu), sexe (catégoriel), poids (continu), groupe sanguin (catégoriel)
- Enquête : revenu (continu), profession (catégoriel), satisfaction 1-10 (ordinal/continu), ville (catégoriel)

Que faire ?

- **Tout catégoriser puis MCA** → perte d'info des continues
- **Tout dummyfier puis PCA** → poids déséquilibré (une catégorielle à 10 modalités pèse 10× plus qu'une continue)
- **Modèles séparés** → on perd la vision conjointe

FAMD résout en pondérant correctement.

## L'idée

### Codage et standardisation

Soient $K$ variables continues et $Q$ variables catégorielles, avec $J = \sum_q J_q$ modalités total.

**Variables continues** :
- Centrer et réduire : $\tilde x_k = (x_k - \bar x_k) / \sigma_k$
- Contribution à l'inertie totale : 1 par variable continue → inertie continue totale = $K$

**Variables catégorielles** :
- Encoder en matrice indicatrice $Z \in \{0,1\}^{n \times J}$
- Pondérer chaque colonne par $1/\sqrt{p_{q,m}}$ où $p_{q,m}$ est la proportion de la modalité $m$ de la variable $q$
- Centrer aussi
- Contribution à l'inertie totale : $J_q - 1$ par variable catégorielle → inertie catégorielle totale = $J - Q$

### Inertie totale et équilibre

Inertie totale = $K + (J - Q)$.

L'astuce de la pondération : **chaque variable** (continue ou catégorielle) contribue avec la même magnitude à l'inertie, indépendamment de son type ou de son nombre de modalités. C'est ce qui fait que FAMD est "équitable".

### PCA sur le tableau pondéré

Concaténer les blocs continus standardisés et les blocs catégoriels indicateurs pondérés. Faire une PCA classique (SVD) sur le résultat.

Les composantes principales sont les directions de variance maximale **sur l'ensemble mixte**.

### Représentations

FAMD fournit deux plans :
- **Plan des individus** — points dans l'espace factoriel
- **Plan des variables** — :
  - Variables continues : flèches (loadings), comme en PCA
  - Variables catégorielles : barycentre des individus de chaque modalité
- **Plan modalités** : positions des modalités, comme en MCA

### Interprétation pratique

- Un axe corrélé à une variable continue ET à plusieurs modalités catégorielles = un axe **sémantiquement transverse** ("axe socio-économique", "axe de gravité maladie")
- Modalités catégorielles loin du centre = modalités rares / structurantes

## Quand c'est utile

- Datasets cliniques (continus + catégoriels naturels)
- Enquêtes mixtes
- Préliminaire à un clustering mixte (HCPC après FAMD)
- Préliminaire à un modèle ML où on veut comprendre les variables structurantes

## Quand ça ne marche pas / pièges

- **Beaucoup plus de variables d'un type que de l'autre** → le type majoritaire domine quand même légèrement. Considérer MFA avec 2 groupes (continu / catégoriel).
- **Variables ordinales** : FAMD les traite comme catégorielles, on perd l'ordre. Soit les traiter comme continues (si suffisamment de niveaux), soit utiliser des méthodes dédiées (PCA non-linéaire / Princals).
- **Valeurs manquantes** : FAMD naïve ne les gère pas. Soit imputation préalable, soit méthodes itératives (PCAmix, missMDA).
- **Trop de modalités rares** → tirent les axes ; fusionner ou marquer en supplémentaire.
- **Confusion avec PCAmix** : PCAmix (Chavent et al.) est très proche de FAMD, à quelques détails de pondération près.

## Code minimal

```python
import prince

# df : DataFrame mixte
famd = prince.FAMD(n_components=3, n_iter=10).fit(df)

famd.plot(df)
print(famd.eigenvalues_summary)

# Coordonnées
ind = famd.row_coordinates(df)
var = famd.column_coordinates_summary
```

## Implémentations concrètes

- [[prince]] — `prince.FAMD`
- R : `FactoMineR::FAMD` (référence), `PCAmix::PCAmix` (variante)
- `missMDA` (R) — pour la gestion des valeurs manquantes via FAMD itérative

## Pour aller plus loin

- Pagès, *Analyse Factorielle Multiple Appliquée aux Variables Qualitatives et aux Données Mixtes* (Revue de Statistique Appliquée, 2004)
- Husson, Lê, Pagès — *Analyse de données avec R*
- **Liens internes** : [[PCA]] (cas continu pur), [[MCA]] (cas catégoriel pur), [[MFA]] (groupes de variables avec types mélangés), [[GPA]]
