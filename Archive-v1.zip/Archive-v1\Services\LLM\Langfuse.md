---
galaxie: dev
nom: Langfuse
alias: [langfuse]
categorie: llm/observability
sous_categories: [tracing, observability, evals, prompt-mgmt, llm-ops]
licence: MIT (Core), Proprietaire (Cloud)
licence_type: open-source
hosted: both
maturite: production
langage: TypeScript + Python SDK
clients_officiels: [python, ts, langchain, llamaindex]
plateforme: [linux, macos, windows, docker]
score: 5
mes_projets: []
alternatives: ["[[LangSmith]]", "[[Helicone]]", Arize Phoenix, Braintrust, Weave (W&B), Lunary]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, observability, tracing]
url_officiel: https://langfuse.com/
url_docs: https://langfuse.com/docs
url_repo: https://github.com/langfuse/langfuse
---

# Langfuse

## Pourquoi
**Observability LLM open-source** (MIT). Tracing complet, prompt management, evals, datasets. Self-hostable via Docker. L'alternative open à LangSmith (qui est lié à LangChain). Standard 2026 pour qui veut de l'observability LLM sans vendor lock-in.

## Quand l'utiliser
- App LLM en prod qui doit tracker coût, latence, qualité
- Auditer les hallucinations par sample
- A/B tester des prompts (Prompt Management intégré)
- Eval continu sur prod traces (LLM-as-judge)
- Multi-provider (OpenAI, Anthropic, Mistral, etc.) unifié
- Self-host pour data sensitive (médical, légal)

## Quand NE PAS l'utiliser
- Stack 100% LangChain → [[LangSmith]] native intégration meilleure
- Proxy + observability + cache combiné → [[Helicone]] (proxy plus pratique)
- W&B existant → Weave reste cohérent
- Très petite échelle → début pas justifié, juste logger

## Pièges connus
- **Self-host setup** : Docker Compose ok, Postgres + ClickHouse pour scale, devient lourd
- **Cloud free tier** : 50k events/mois, peut suffire en dev
- **Decorators Python** : `@observe` simple, mais async + nested traces peuvent être tricky
- **OpenInference compatible** : intègre avec Arize Phoenix mais format pas 100% identique
- **Sampling** : par défaut 100% (trace tout) — coûteux en prod, sampler à 5-10%
- **Datasets** : pour eval, peut bien convertir prod traces → eval set

## Liens
- [[LangSmith]] — alternative LangChain
- [[Helicone]] — proxy + observability
- Phoenix Arize — open-source alternative
- [[LLM observability]] (concept)
- Docs : https://langfuse.com/docs
- Pricing : https://langfuse.com/pricing
- GitHub : https://github.com/langfuse/langfuse
