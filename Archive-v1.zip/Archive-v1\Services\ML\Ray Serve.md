---
galaxie: dev
nom: Ray Serve
alias: [ray-serve, ray.serve]
categorie: ml/serving
sous_categories: [serving, distributed, python, multi-model]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Python (C++ core via Ray)
clients_officiels: [python, rest, grpc]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[BentoML]]", "[[NVIDIA Triton]]", "[[KServe]]", "[[FastAPI]] custom"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, ml, serving, ray, distributed]
url_officiel: https://docs.ray.io/en/latest/serve/index.html
url_docs: https://docs.ray.io/en/latest/serve/index.html
url_repo: https://github.com/ray-project/ray
---

# Ray Serve

## Pourquoi
Composant **serving** de l'écosystème [[Ray]]. Scaling horizontal natif (Ray cluster), composition de modèles en pipelines (`@serve.deployment` + `Deployment.bind()`), routing dynamique, autoscaling. Le choix quand tu vis déjà dans Ray (training + serving partagés).

## Quand l'utiliser
- Stack Ray déjà en place (Ray Train, Ray Tune)
- Pipelines de plusieurs modèles avec déploiements indépendants scalables
- Multi-tenancy avec isolation (multiple deployments)
- Autoscaling fin (replicas, ressources GPU/CPU différenciées)
- Besoin de distribution sur plusieurs nodes / multi-GPU

## Quand NE PAS l'utiliser
- Pas de cluster Ray → setup plus lourd que [[BentoML]]
- Besoin maximum perf sur un seul GPU → [[NVIDIA Triton]] (TensorRT, FasterTransformer)
- Très simple service mono-modèle → [[FastAPI]] / [[BentoML]]

## Pièges connus
- **Ray cluster** : à dimensionner correctement (head + workers)
- **Object store memory** : à régler (`object_store_memory`)
- **Versioning Ray** : evolution rapide de l'API Serve, pinner
- **Logs / observability** : Ray Dashboard utile mais pas magique en prod, intégrer avec [[Grafana]]
- **GPU scheduling** : `ray_actor_options={"num_gpus": 0.5}` pour partage GPU

## Liens
- [[BentoML]], [[NVIDIA Triton]] — alternatives serving
- Ray Tune (compagnon) : https://docs.ray.io/en/latest/tune/
- Ray Train : https://docs.ray.io/en/latest/train/
- KubeRay (operator K8s) : https://github.com/ray-project/kuberay
