---
galaxie: wiki
nom: Guardrails & safety runtime
alias: [guardrails, NeMo Guardrails, LLM Guard, Lakera, input filtering, output filtering]
type: concept
categorie: concept/llm-production
sous_categories: [guardrails, safety, security, llm-ops]
domaines: [ai-eng]
maturite: established
auteurs_cles: []
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, safety, production, guardrails]
---

# Guardrails & safety runtime

## TL;DR

**Filtres de sécurité** appliqués autour des LLM calls : **input filtering** (PII, prompt injection, jailbreak, toxicity) et **output filtering** (content moderation, hallucinations, PII leak, schema). Outils : **NVIDIA NeMo Guardrails**, **Guardrails AI**, **LLM Guard**, **Lakera Guard**, **Protect AI**, **Aporia Guardrails**, providers built-in (OpenAI Moderation, Anthropic safety filters, Azure Content Safety). Pattern : combine **classifier light** (cheap, fast) + **LLM judge** (expensive, accurate) + **structured validators**. Sans guardrails, LLM en prod = risque legal, brand, security.

## Le problème

LLM en production peut :
- **Leak PII** (emails, SSN, credit cards)
- **Hallucinate** des fausses infos critique
- **Comply with injection** (instructions cachées dans user input)
- **Produire content harmful** (hate, violence)
- **Bypass restrictions** (jailbreak)
- **Aboutir à actions dangereuses** (DELETE, transfer money)

→ **Filtres** sur input et output indispensables.

## L'idée

### Architecture

```
[User input]
    │
    ▼
[Input filters] ──→ block / sanitize
    │
    ▼
[LLM call]
    │
    ▼
[Output filters] ──→ redact / refuse / re-generate
    │
    ▼
[User]
```

### Input filtering

#### PII detection

Detect emails, SSN, credit cards, names, addresses dans user input.

Outils :
- **Presidio** (Microsoft) : open-source PII detection
- **AWS Macie**
- **Lakera Guard**
- **Custom regex** + NER models

#### Toxicity / Harm classifiers

Detect toxic / hateful content.

- **Perspective API** (Google) : free, multilingue
- **Detoxify** : open-source
- **OpenAI Moderation API** : free with API
- **Azure Content Safety**

#### Prompt injection detection

Detect tentatives d'injection :
- "Ignore previous instructions"
- Hidden text in documents
- Spotlighting attempts

Outils :
- **PromptGuard** (Meta)
- **Lakera Guard prompt injection detector**
- **Custom LLM-as-judge**

#### Jailbreak detection

DAN, persona attacks, encoding-based, etc.

#### Off-topic detection

User asks about prohibited topic.

- Classifier custom
- LLM-as-judge

### Output filtering

#### Content moderation

Hate, violence, sexual, self-harm → block ou refuse.

#### PII redaction

Si LLM produit PII (e.g. from RAG retrieval), redact :
- Names → "[NAME]"
- Emails → "[EMAIL]"
- Numbers → "[CARD]"

#### Hallucination detection

LLM-as-judge sur output vs context. Faithfulness check.

- RAGAS faithfulness
- Lynx, NLI-based classifiers

#### Schema validation

JSON output respects schema ? Voir [[Structured outputs]].

#### Length limits

Max tokens output enforce.

#### Topic restrictions

LLM stays "on topic" (e.g. customer service ≠ medical advice).

#### Markdown / link sanitization

Strip URLs, markdown rendering pour éviter exfiltration via image URLs.

### Outils

#### NVIDIA NeMo Guardrails

Framework complet :
- Colang DSL pour rules
- Dialog rails, retrieval rails, execution rails
- Production-ready

```python
from nemoguardrails import RailsConfig, LLMRails
config = RailsConfig.from_path("./config")
rails = LLMRails(config)
response = rails.generate(prompt="...")
```

#### Guardrails AI

Validators Python :
- Pydantic-based
- Schema, regex, ML-based
- Async support

```python
from guardrails import Guard
from guardrails.hub import ToxicLanguage, DetectPII

guard = Guard().use_many(ToxicLanguage, DetectPII(["EMAIL", "PHONE"]))
result = guard(llm_api=openai.chat.completions.create, prompt="...")
```

#### LLM Guard

Open-source toolkit :
- Input scanners (anonymize, prompt injection, secrets)
- Output scanners (deanonymize, code, JSON valid, sensitive)

#### Lakera Guard

API-based. Strong on prompt injection.

#### Protect AI

Enterprise focus.

#### Aporia Guardrails

Configurable policies.

#### Provider built-in

- **OpenAI Moderation API** : free
- **Anthropic safety filters** : built-in Claude
- **Azure Content Safety** : multi-language
- **Google Perspective API** : toxicity
- **AWS Bedrock Guardrails**

### Strategies

#### Fail-closed vs fail-open

- **Fail-closed** : si guardrail fails (e.g. classifier down), block user. Safer.
- **Fail-open** : let through. UX prioritaire.

Choose selon risk tolerance.

#### Tiered

```
1. Cheap fast classifier (input)
2. LLM call
3. Cheap fast classifier (output)
4. If suspicious : LLM judge (slow but accurate)
```

Compromis latency / accuracy.

#### Confidence thresholds

Pas binaire. Confidence scores :
- High confidence violation → block
- Medium → log + warn
- Low → pass

#### Custom policies

Each app a son context :
- Customer support : never give medical advice
- Therapy app : escalate suicide mentions
- Children : strict content

### Structured guardrails

Pour outputs structurés :
- **JSON schema validation** (Pydantic, jsonschema)
- **Type-safe wrappers** (Instructor) → auto-retry
- **Function args validation**

Voir [[Structured outputs]].

### Architecture levels

#### 1. Input

Sanitize, detect threats before LLM sees.

#### 2. Prompt-level

Defense in system prompt :
- Spotlighting (mark user input)
- Sandwich defense (instructions before AND after)
- Constitutional prompting

#### 3. Output

Filter generated text.

#### 4. Action

Si agent : approve tools / actions critical (HITL).

### Best practices

1. **Defense in depth** : multiple layers
2. **Combine** classifier + LLM judge (different strengths)
3. **Latency budget** : guardrails add ~50-300ms
4. **Threshold tuning** : minimize false positives + false negatives
5. **Audit log** : tous les blocks tracked
6. **A/B test** safety vs UX
7. **Per-use-case policies** : pas one-size-fits-all
8. **User feedback** : appeal / report
9. **Red team** : test your guardrails (cf. [[Jailbreaking and defenses]])
10. **Update continuously** : new attacks emerge

## Quand c'est utile

- **Tout chat / agent en prod** : non-négociable
- **Enterprise** : compliance, brand safety
- **Régulé** (medical, finance, legal)
- **Multi-tenant** : isolation, PII protection
- **Children-facing** apps
- **Public web** : adversaires
- **API providers** : protect downstream

## Quand ça ne marche pas / pièges

- **False positives** : block legitimate queries
- **Latency hit** : guardrails ajoute 200-500ms
- **Cost** : LLM judge expensive
- **Bypass** : attaquants finissent par bypass
- **Multi-language** : classifiers weak hors EN
- **Context-dependent** : "kill" violent in literature, OK
- **Over-blocking** = user frustration
- **Under-blocking** = legal / safety risk
- **PII classifier wrong** : misses obscure PII formats
- **Hallucination detection imparfait** : LLM judge fait elle aussi des erreurs
- **No silver bullet** : combine pour multi-layer
- **Adversarial input** : carefully crafted bypass
- **Compliance dépend du pays** : règles different (GDPR, HIPAA, etc.)

## Code minimal

```python
# 1. OpenAI Moderation API (free)
from openai import OpenAI
client = OpenAI()

response = client.moderations.create(input="some text to check")
result = response.results[0]
if result.flagged:
    print("BLOCK:", result.categories)
    # categories : hate, violence, sexual, self-harm, etc.

# 2. Detoxify (open-source toxicity)
from detoxify import Detoxify
predictions = Detoxify('original').predict("text to check")
# {'toxicity': 0.02, 'severe_toxicity': 0.001, ...}

# 3. Presidio (PII detection)
from presidio_analyzer import AnalyzerEngine
analyzer = AnalyzerEngine()
results = analyzer.analyze(text="My email is john@example.com", entities=["EMAIL_ADDRESS"], language="en")
# Then redact:
from presidio_anonymizer import AnonymizerEngine
anonymizer = AnonymizerEngine()
anonymized = anonymizer.anonymize(text=text, analyzer_results=results)

# 4. NeMo Guardrails
# pip install nemoguardrails
from nemoguardrails import RailsConfig, LLMRails

# config.yml :
# models:
#   - type: main
#     engine: openai
#     model: gpt-4o
# rails:
#   input:
#     flows: [check jailbreak, check sensitive topics]

config = RailsConfig.from_path("./config")
rails = LLMRails(config)
response = await rails.generate_async(messages=[{"role": "user", "content": "..."}])

# 5. Guardrails AI
from guardrails import Guard
from guardrails.hub import ToxicLanguage, DetectPII

guard = Guard().use_many(
    ToxicLanguage(threshold=0.5, on_fail="exception"),
    DetectPII(pii_entities=["EMAIL_ADDRESS", "PHONE_NUMBER"], on_fail="fix")
)

response = guard(
    llm_api=openai.chat.completions.create,
    prompt_params={"model": "gpt-4o", "messages": [{"role": "user", "content": "..."}]}
)

# 6. LLM Guard
from llm_guard.input_scanners import Anonymize, BanTopics, PromptInjection
from llm_guard.output_scanners import Deanonymize, Sensitive

input_scanners = [Anonymize(), BanTopics(["politics"]), PromptInjection()]
output_scanners = [Sensitive(), Deanonymize(anonymize_scanner)]

for scanner in input_scanners:
    prompt, valid, risk = scanner.scan(prompt)
    if not valid:
        print(f"BLOCKED: {scanner.__class__.__name__}")

response = llm.invoke(prompt)

for scanner in output_scanners:
    response, valid, risk = scanner.scan(prompt, response)

# 7. LLM-as-judge hallucination detection
def check_grounded(query, response, context):
    judge_prompt = f"""
Query: {query}
Context: {context}
Response: {response}

Is the response grounded in the context?
Output JSON: {{"grounded": true/false, "reasoning": "..."}}
"""
    judge_response = client.messages.create(
        model="claude-3-haiku-20240307",
        max_tokens=200,
        messages=[{"role": "user", "content": judge_prompt}]
    )
    return json.loads(judge_response.content[0].text)

# 8. Custom multi-layer pipeline
def safe_llm_call(user_input, allowed_topics, system_prompt):
    # Layer 1 : PII anonymize
    anonymized = presidio_redact(user_input)
    
    # Layer 2 : Moderation
    mod = openai_moderation(anonymized)
    if mod.flagged:
        return "I can't process this request."
    
    # Layer 3 : Prompt injection detection
    if detect_injection(anonymized):
        return "Suspicious input detected."
    
    # Layer 4 : Topic check
    if not is_on_topic(anonymized, allowed_topics):
        return "Off-topic for this assistant."
    
    # LLM call
    response = llm.invoke(system_prompt + "\n" + anonymized)
    
    # Layer 5 : Output check
    if openai_moderation(response).flagged:
        return "Response blocked."
    
    # Layer 6 : Deanonymize
    response = deanonymize(response)
    
    return response

# 9. Structured output validation
from pydantic import BaseModel, ValidationError
class SafeResponse(BaseModel):
    answer: str
    confidence: float
    sources: list[str]

# Validate or retry
try:
    parsed = SafeResponse.model_validate_json(llm_output)
except ValidationError:
    # retry or fallback
    pass
```

## Pour aller plus loin

- *NVIDIA NeMo Guardrails* documentation
- *Guardrails AI* documentation
- *LLM Guard* (Laiyer.ai) GitHub
- *Lakera Guard* documentation
- *Microsoft Presidio* documentation
- OWASP LLM Top 10
- Anthropic, *Building safe agents* blog
- *Detoxify*, *Perspective API* docs
- **Liens internes** : [[Prompt injection]], [[Jailbreaking and defenses]], [[LLM observability]], [[Structured outputs]], [[Agent patterns]]
