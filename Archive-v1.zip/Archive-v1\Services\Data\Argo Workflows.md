---
galaxie: dev
nom: Argo Workflows
alias: [argo, argo-workflows]
categorie: data/orchestrator
sous_categories: [kubernetes, workflow, cncf, dag, ci-cd]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Go
clients_officiels: [python, java, go, cli]
plateforme: [linux]
score: 3
mes_projets: []
alternatives: ["[[Prefect]]", "[[Dagster]]", "[[Airflow]]", "Tekton", "Flyte"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, kubernetes, workflow, orchestrator]
url_officiel: https://argo-workflows.readthedocs.io/
url_docs: https://argo-workflows.readthedocs.io/en/latest/
url_repo: https://github.com/argoproj/argo-workflows
---

# Argo Workflows

## Pourquoi

Orchestrateur de workflows **Kubernetes-native** (projet CNCF gradué). Chaque **step = un pod** K8s. Workflows définis en CRD YAML, scalent naturellement avec la capacité du cluster, héritent de tout l'écosystème K8s (RBAC, secrets, volumes, GPU scheduling, network policies).

Cible : équipes qui vivent **déjà 100% sur Kubernetes** et veulent un orchestrateur qui ne sort pas de cette abstraction. Fait partie de la suite **Argo** avec Argo CD (GitOps), Argo Events (event-driven triggers), Argo Rollouts (progressive delivery). Standard pour **ML training distribué**, **bio-info pipelines**, **CI/CD K8s**.

## Quand l'utiliser

- **Stack Kubernetes existante** : un cluster déjà là, équipe SRE qui le maintient
- **Workflows scientifiques / bioinformatique** : pipelines DAG longs avec étapes hétérogènes
- **ML training distribué** : combo MPI Operator + Argo Workflows
- **CI/CD complexe sur K8s** : déclencher des builds multi-étapes en YAML
- **Combo Argo CD + Events + Rollouts** : stack GitOps complète
- **Workflows event-driven** : Argo Events → Argo Workflows
- **Resource isolation forte par step** : chaque step a ses propres limits CPU/mem/GPU
- **Multi-tenancy** via namespaces K8s natif

## Quand NE PAS l'utiliser

- **Pas de K8s** → [[Prefect]] / [[Dagster]] / [[Airflow]] (Python-natif, plus simples)
- **Python-first équipe data** : orchestrateurs Python plus naturels
- **Workflows < 100 tasks / jour** : Kubernetes overhead pas justifié, cron simple suffit
- **Data lineage / catalog requis** : [[Dagster]] mieux out-of-the-box
- **UI riche pour business users** : Airflow / Prefect plus accessibles
- **Petite équipe sans plateforme K8s** : courbe d'apprentissage très raide

## Pièges connus

- **YAML verbeux** : workflows complexes deviennent illisibles → utiliser **Hera** (DSL Python) ou WorkflowTemplates
- **DAG dynamique** nécessite WorkflowTemplate + recursion (pas trivial) ou `withItems` / `withParam`
- **UI moins riche** que Airflow / Prefect / Dagster côté business
- **Resource limits par pod critiques** : si pas définis = noisy neighbors / OOM cluster
- **Artifacts** : passage de fichiers entre steps via S3/GCS/MinIO, à configurer
- **Pod startup overhead** : ~5-15s par step (pull image, schedule) → mauvais pour DAGs très granulaires
- **Logs dispersés** : un pod par step → logs à agréger (Loki / ELK conseillé)
- **Retry / failure handling** : configurable mais syntaxe yaml lourde
- **Workflow controller HA** : single point-of-failure si pas configuré HA
- **Migration vers Argo Workflows 3.x** : breaking changes possibles, lock la version

## Code minimal

```bash
# Install (cluster K8s requis)
kubectl create namespace argo
kubectl apply -n argo -f https://github.com/argoproj/argo-workflows/releases/download/v3.5.5/quick-start-minimal.yaml

# CLI
brew install argo
argo version
```

```yaml
# hello-world.yaml
apiVersion: argoproj.io/v1alpha1
kind: Workflow
metadata:
  generateName: hello-world-
  namespace: argo
spec:
  entrypoint: main
  templates:
    - name: main
      dag:
        tasks:
          - name: extract
            template: run-step
            arguments:
              parameters: [{name: cmd, value: "echo extracting && sleep 2"}]
          - name: transform
            template: run-step
            depends: extract
            arguments:
              parameters: [{name: cmd, value: "echo transforming && sleep 2"}]
          - name: load
            template: run-step
            depends: transform
            arguments:
              parameters: [{name: cmd, value: "echo loading"}]
    - name: run-step
      inputs:
        parameters: [{name: cmd}]
      container:
        image: alpine:3.19
        command: [sh, -c]
        args: ["{{inputs.parameters.cmd}}"]
        resources:
          requests: {cpu: "100m", memory: "64Mi"}
          limits: {cpu: "500m", memory: "256Mi"}
```

```bash
argo submit -n argo hello-world.yaml --watch
argo list -n argo
argo logs -n argo @latest
```

```python
# Hera : DSL Python (recommande pour eviter le YAML)
# pip install hera-workflows
from hera.workflows import Workflow, DAG, script

@script()
def hello(name: str) -> None:
    print(f"hello {name}")

with Workflow(generate_name="dag-", entrypoint="main", namespace="argo") as w:
    with DAG(name="main"):
        a = hello(name="extract")
        b = hello(name="transform")
        c = hello(name="load")
        a >> b >> c

w.create()
```

## Liens

- [[Comparatif - Orchestrateurs data]]
- [[Prefect]] / [[Dagster]] / [[Airflow]] — alternatives Python-natif
- Argo CD — projet jumeau (GitOps)
- Argo Events — event-driven triggers
- Argo Rollouts — progressive delivery
- Tekton — alternative CI/CD K8s-native
- Flyte — alternative ML-focused K8s-native
- Hera — DSL Python pour Argo Workflows
- Docs : https://argo-workflows.readthedocs.io/
- GitHub : https://github.com/argoproj/argo-workflows
