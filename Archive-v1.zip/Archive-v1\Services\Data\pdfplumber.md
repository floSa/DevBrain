---
galaxie: dev
nom: pdfplumber
alias: [pdfplumber]
categorie: data/document
sous_categories: [pdf, extraction, tables, python, geometry]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[PyMuPDF]]", "Camelot", "Tabula", "[[Unstructured]]", "[[Docling]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, pdf, python, extraction]
url_officiel: https://github.com/jsvine/pdfplumber
url_docs: https://github.com/jsvine/pdfplumber#readme
url_repo: https://github.com/jsvine/pdfplumber
---

# pdfplumber

## Pourquoi

Lib Python pure d'extraction PDF : **texte, tables, géométrie des éléments** (bbox, fonts, lines, rectangles). Construite au-dessus de `pdfminer.six`. Différenciateur : excellente sur les **tableaux structurés** avec des règles de détection configurables (lines explicites, gaps de texte), et **coordinate-aware** — tu peux extraire par zone bounding-box précise.

Cible : scripts ETL où il faut extraire des **tables précises** de PDFs financiers / réglementaires / scientifiques, avec contrôle fin (vs OCR-ML). Plus lent que PyMuPDF mais meilleur pour tables. Souvent utilisé en complément : pdfplumber pour les tables, PyMuPDF pour le texte rapide.

## Quand l'utiliser

- **Extraction de tables structurées** : factures, bilans, rapports avec lignes/colonnes claires
- **Scripts ETL one-shot** : extraction reproductible, déterministe
- **Coordinate-aware extraction** : "extraire le texte dans la zone (100, 200, 400, 350)"
- **Combiner texte + visuel** : `page.to_image()` pour debug visuel des extractions
- **Pas besoin de quality ML** : règles déterministes suffisent
- **Custom table strategy** : configurer detect_lines vs detect_text vs explicit lines
- **Combo PyMuPDF** : utiliser pdfplumber juste pour les tables critiques

## Quand NE PAS l'utiliser

- **Layout très complexe** (multi-colonnes, encadrés flottants, formules) → [[Marker]] / [[Unstructured]] / [[Docling]] (ML)
- **Vitesse pure** : [[PyMuPDF]] ~10x plus rapide pour extraction texte
- **Documents scannés (images)** : pdfplumber lit le texte vectoriel uniquement → OCR (Tesseract, Paddle, Surya) requis avant
- **RAG end-to-end** : pas de chunking / elements / metadata RAG natifs → [[Unstructured]] / [[Docling]] mieux
- **Énorme volume** : Python pur, single-thread → batching multiprocess à coder soi-même

## Pièges connus

- **Plus lent que PyMuPDF** : facteur 5-10x sur extraction texte massive
- **Tables avec cellules fusionnées** : parfois ratées, à tuner avec `table_settings`
- **Tables sans lignes explicites** : detect_lines échoue, passer en `text` strategy avec `explicit_horizontal_lines`
- **Cellules vides ignorées** : peuvent décaler la grille → vérifier shape
- **Pas de chunking RAG natif** : pas d'elements typés (Title, NarrativeText) comme Unstructured
- **Documents scannés silencieux** : retourne du vide sans warning → vérifier `page.chars` non-vide
- **Mémoire sur gros PDFs** : `pdfplumber.open()` charge tout → utiliser context manager
- **Tables imbriquées** : non gérées proprement (tableaux dans tableaux)
- **Caractères Unicode exotiques** : parfois mal décodés (à vérifier sur PDFs non-latin)
- **`extract_tables` retourne list[list[list]]** : pas de DataFrame direct, convertir à la main

## Code minimal

```bash
pip install pdfplumber
```

```python
import pdfplumber

# Extraction texte + tables
with pdfplumber.open("rapport.pdf") as pdf:
    for page in pdf.pages:
        # Texte
        text = page.extract_text()
        print(text[:200])

        # Tables (auto-detection)
        for table in page.extract_tables():
            for row in table:
                print(row)
```

```python
import pdfplumber
import pandas as pd

# Table sans lignes explicites : strategy "text"
with pdfplumber.open("bilan.pdf") as pdf:
    page = pdf.pages[2]
    tables = page.extract_tables(table_settings={
        "vertical_strategy": "text",
        "horizontal_strategy": "text",
        "snap_tolerance": 3,
    })
    df = pd.DataFrame(tables[0][1:], columns=tables[0][0])
    print(df)
```

```python
# Extraction par bbox precise
with pdfplumber.open("facture.pdf") as pdf:
    page = pdf.pages[0]
    # bbox = (x0, top, x1, bottom)
    cropped = page.crop((100, 200, 400, 350))
    print(cropped.extract_text())

    # Debug visuel
    img = page.to_image(resolution=150)
    img.draw_rect((100, 200, 400, 350), stroke="red", fill=None)
    img.save("debug.png")
```

```python
# Acceder a la geometrie brute
with pdfplumber.open("doc.pdf") as pdf:
    page = pdf.pages[0]
    print(len(page.chars))   # tous les caracteres avec x0, y0, fontname, size
    print(len(page.lines))   # toutes les lignes vectorielles
    print(len(page.rects))   # tous les rectangles
```

## Liens

- [[PyMuPDF]] — alternative ~10x plus rapide (texte brut)
- Camelot / Tabula — alternatives spécialisées tables (Camelot wrappe pdfplumber)
- [[Unstructured]] — alternative RAG-friendly (elements typés)
- [[Docling]] — alternative IBM
- [[Marker]] — alternative ML (transformers)
- pdfminer.six — backend bas-niveau utilisé par pdfplumber
- GitHub : https://github.com/jsvine/pdfplumber
