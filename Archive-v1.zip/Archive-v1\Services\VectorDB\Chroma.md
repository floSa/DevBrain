---
galaxie: dev
nom: Chroma
alias: [chromadb, chroma-db]
categorie: database/vector
sous_categories: [embedded, python-first, prototyping]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: beta
langage: Python (Rust core)
clients_officiels: [python, ts]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Qdrant]]", "[[Weaviate]]", "[[pgvector]]", "[[Faiss]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, database, vector, embedded, python]
url_officiel: https://www.trychroma.com/
url_docs: https://docs.trychroma.com/
url_repo: https://github.com/chroma-core/chroma
---

# Chroma

## Pourquoi
Vector DB **simplissime** orientée prototypage Python. `chromadb.Client()` et c'est parti. Modes embedded (SQLite-like) ou client/server. Le défaut quand tu veux du vector search en 5 minutes sans déployer.

## Quand l'utiliser
- POC, démos, notebooks
- Outils internes / scripts personnels
- Apprentissage / tutoriels RAG
- Tests unitaires nécessitant un vector store local
- Embedded mode dans une app Python desktop

## Quand NE PAS l'utiliser
- Production sérieuse → [[Qdrant]], [[Weaviate]] ou [[Milvus]]
- Multi-tenancy → manque de maturité
- Très grande scale (>10M vecteurs) → autre choix
- Hybrid search avancé / filtering complexe → [[Qdrant]]

## Pièges connus
- **Maturité** : le projet bouge vite, breaking changes fréquents avant 1.0
- **Persistance** : `PersistentClient` requis explicitement, sinon tout en RAM
- **Embeddings auto** : par défaut Chroma génère des embeddings (Sentence Transformers), à override si tu veux gérer toi-même
- **Distance metric** : `l2`, `ip`, `cosine` — défaut `l2` peut surprendre (préférer `cosine` pour text)
- **Performance** : OK jusqu'à ~1-5M vecteurs, après devient le goulot
- **Backups** : copier le dossier de persistance, pas d'outil natif

## Liens
- [[Qdrant]] — alternative production
- [[pgvector]] — si déjà Postgres
- [[Faiss]] — si tu veux just la lib sans serveur
- Chroma Cloud (managed) : https://www.trychroma.com/
- Cookbook : https://cookbook.chromadb.dev/
