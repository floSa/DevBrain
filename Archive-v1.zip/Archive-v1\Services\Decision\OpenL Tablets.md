---
galaxie: dev
nom: OpenL Tablets
alias: [openl-tablets, openl, openl tablets brms]
categorie: decision/engine
sous_categories: [openl, dmn, rules-engine, brms, excel, java]
licence: LGPL
licence_type: open-source
hosted: self
maturite: production
langage: Java
clients_officiels: [java, rest, soap, python (via REST), javascript (via REST)]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[Camunda]]", "[[Drools]]", "[[pyDMNrules]]", "FICO Blaze Advisor", "IBM ODM"]
remplace: []
remplace_par: []
created: 2026-05-21
modified: 2026-05-21
status: actif
tags: [service, openl, dmn, rules-engine, brms, excel]
url_officiel: https://openl-tablets.org/
url_docs: https://openl-tablets.org/documentation/user-guides
url_repo: https://github.com/openl-tablets/openl-tablets
---

# OpenL Tablets

## Pourquoi

**BRMS open-source orienté Excel**. Les analystes métier modélisent les règles dans **Microsoft Excel** (format spécifique avec entêtes typées), OpenL compile ces feuilles en **Java bytecode natif**, et expose les décisions comme **REST API** automatiquement. Combine 3 forces rares :

1. **Authoring familier** : Excel — les analystes connaissent déjà
2. **Performance** : compilation Java native (millions de décisions/s)
3. **Hot reload** : changes dans Excel → live en production sans downtime

Version récente : **5.27.14** (octobre 2025), open-source LGPL, Jakarta EE 10 compliant. Support DMN partiel (decision tables principalement, FEEL limité — niveau L2 essentiellement).

Cible : équipes en banque / assurance où les **business analysts maintiennent les règles directement en Excel** et l'IT fournit le runtime. Forte adoption Europe de l'Est et clients enterprise.

## Quand l'utiliser

- **Business analysts qui vivent en Excel** : barrière d'entrée nulle, ils sont autonomes
- **Hot reload requis** : changes Excel → live, **zero downtime**
- **Performance élevée** : compilation Java native, millions de décisions/seconde
- **Combo REST API** : OpenL expose auto les rules comme endpoints REST
- **Stack JVM** mais avec **authoring non-dev** souhaité
- **Décision tables principalement** (vs DMN avancé) : OpenL excelle sur ce 80/20
- **Migration depuis "Excel + macros VBA"** : passage à un BRMS sans rupture
- **Open-source LGPL** : compatible usage commercial (vs GPL strict)

## Quand NE PAS l'utiliser

- **DMN strict L3 / FEEL avancé** → [[Camunda]] ou [[Drools]]
- **Stack Python pure** : OpenL est Java → utiliser via REST seulement, ou préférer [[pyDMNrules]] natif
- **BPMN intégré** : OpenL est rules-only, pas de workflow → combiner avec un BPMN engine externe
- **Petite équipe sans Excel culture** : si business analysts préfèrent web UI, autre outil
- **DRD graphique complexe** : OpenL est table-centric, le DRD est moins central
- **DMN portability** : modèles OpenL sont propriétaires (.xls), pas portables vers Camunda/Drools sans conversion
- **Communauté petite** : moins de StackOverflow / blog posts que Camunda/Drools

## Pièges connus

- **Format Excel propriétaire** : tu peux écrire en `.xls` ou `.xlsx`, mais avec **conventions OpenL spécifiques** (headers `Rules`, `Test`, `Datatype`, etc.) — pas du DMN XML standard
- **Lock-in Excel format OpenL** : migrer vers Camunda/Drools = réécriture
- **Adoption hors Europe centrale/Est** : communauté plus petite que Drools/Camunda
- **DMN support partiel** : couvre decision tables principalement, FEEL avancé limité → vérifier si tes besoins matchent
- **WebStudio (UI web)** : pratique mais moins fluide que Camunda Modeler côté DMN
- **Versioning Excel** : merge Git sur `.xls` non-trivial, prévoir review visuelle
- **Hot reload** : super en théorie, mais peut introduire des bugs si tu modifies en prod sans test (déployer staging d'abord)
- **Documentation** : essentiellement anglais, parfois traduite mécaniquement
- **REST API stub** : OpenL génère auto les endpoints mais le contrat (OpenAPI) peut être bizarre → personnaliser
- **Licence LGPL** : compatible commercial mais **modifications du code OpenL** doivent être publiées
- **Datatype custom** : utile mais syntaxe spécifique OpenL (`Datatype` Excel tab)

## Code minimal

### Installation OpenL Studio (UI web)

```bash
# Télécharger OpenL Studio (WAR / standalone)
# https://openl-tablets.org/

# Lancer avec Docker
docker run -p 8080:8080 openltablets/openl-studio:5.27.14
# UI : http://localhost:8080
```

### Excel rules file (convention OpenL)

Tab `Rules` :
```
| Rules Eligibility(Customer c, Decimal score_ml)             |
| --- C1 --- | --- C2 --- | --- C3 --- | --- Result ---       |
| c.age      | c.income   | score_ml   | result               |
| < 25       |            |            | "refused"            |
| [25..65]   | > 30000    | > 0.7      | "accepted"           |
| [25..65]   | [15..30]k  |            | "accepted_guarantor" |
| > 65       | > 50000    | > 0.6      | "accepted"           |
```

Tab `Datatype Customer` :
```
| Datatype Customer |
| ---               | ---       |
| Integer           | age       |
| Integer           | income    |
| String            | tier      |
```

### Déployer + exposer en REST

OpenL Studio expose automatiquement le fichier Excel comme **REST endpoint** :

```bash
# Endpoint généré : http://localhost:8080/webservice/eligibility-1.0/Eligibility
curl -X POST "http://localhost:8080/webservice/eligibility-1.0/Eligibility" \
    -H "Content-Type: application/json" \
    -d '{
        "c": {"age": 35, "income": 25000, "tier": "STANDARD"},
        "score_ml": 0.78
    }'
# Réponse : "accepted_guarantor"
```

### Client Python

```python
import requests

def evaluate_eligibility(age, income, score_ml, tier="STANDARD"):
    r = requests.post(
        "http://openl-server:8080/webservice/eligibility-1.0/Eligibility",
        json={
            "c": {"age": age, "income": income, "tier": tier},
            "score_ml": score_ml,
        },
    )
    return r.text.strip('"')

print(evaluate_eligibility(35, 25000, 0.78))   # "accepted_guarantor"
```

### Tests intégrés (Tab Excel `Test`)

OpenL permet d'écrire les tests **dans le même Excel** :

```
| Test EligibilityTest                                        |
| --- c.age --- | --- c.income --- | --- score_ml --- | expected |
| 30            | 35000            | 0.85             | "accepted" |
| 20            | 100000           | 0.99             | "refused"  |
| 40            | 20000            | 0.7              | "accepted_guarantor" |
```

Exécutables via OpenL Studio ou en batch CLI.

### Combo Python + OpenL (pattern hybride avec ML)

```python
import xgboost as xgb
import requests
import pickle

with open("credit_xgb.pkl", "rb") as f:
    model = pickle.load(f)

def decide_credit(customer, request):
    # 1. Score ML en Python
    features = build_features(customer, request)
    score = float(model.predict_proba(features)[0][1])

    # 2. Décision règle via OpenL REST
    r = requests.post(
        "http://openl-server:8080/webservice/eligibility-1.0/Eligibility",
        json={"c": customer, "score_ml": score},
    )
    return {"decision": r.json(), "ml_score": score}
```

### OpenL Studio — UI web

OpenL Studio (WebStudio) permet aux business analysts :
- Éditer les fichiers Excel dans le navigateur (sans Excel local)
- Run les tests
- Voir l'historique des changements
- Déployer en production (avec gouvernance optionnelle : review, approval)

## Liens

- [[Camunda]] — alternative DMN production-grade
- [[Drools]] — alternative open-source Java pure
- [[pyDMNrules]] — alternative Python pure
- [[Decision Model and Notation]] / [[Decision Tables]] — concepts
- [[DMN and ML hybrid]] — pattern combiné ML + règles
- [[Decision Intelligence]] — angle plateforme
- FICO Blaze Advisor / IBM ODM — alternatives commerciales propriétaires
- Site officiel : https://openl-tablets.org/
- Release notes : https://openl-tablets.org/release-notes?ver=5.21
- GitHub : https://github.com/openl-tablets/openl-tablets
- Docs : https://openl-tablets.org/documentation/user-guides
