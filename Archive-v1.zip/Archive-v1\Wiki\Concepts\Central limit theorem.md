---
galaxie: wiki
nom: Central limit theorem
alias: [TCL, central limit theorem, théorème central limite, CLT]
type: concept
categorie: concept/probability
sous_categories: [clt, asymptotic, gaussian, law-of-large-numbers]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Laplace, Lyapunov, Lindeberg]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, probability, clt, gaussian]
---

# Central limit theorem — TCL

## TL;DR

**Pourquoi la loi normale est partout en stats** : la somme (ou moyenne) d'un grand nombre de variables aléatoires i.i.d. de variance finie tend vers une **loi normale**, **indépendamment** de la distribution d'origine. Fondation des [[Confidence intervals|IC]], des [[Hypothesis testing|tests d'hypothèse]], du [[Bootstrap]], et de presque toute l'inférence fréquentiste.

## Le problème

Pourquoi calcule-t-on des moyennes ? Et pourquoi la moyenne d'un échantillon a-t-elle une distribution gaussienne **quelle que soit** la distribution sous-jacente ? Le TCL répond à ces deux questions et justifie une grande partie des stats classiques.

## L'idée

### Énoncé classique (Lindeberg-Lévy)

Soient $X_1, X_2, \dots, X_n$ i.i.d. avec $\mathbb{E}[X_i] = \mu$ et $\text{Var}(X_i) = \sigma^2 < \infty$.

Notons $\bar X_n = \frac{1}{n} \sum X_i$ la moyenne empirique.

$$ \sqrt{n} \, (\bar X_n - \mu) \xrightarrow{d} \mathcal{N}(0, \sigma^2) \quad \text{quand} \quad n \to \infty $$

ou de manière équivalente :

$$ \bar X_n \approx \mathcal{N}\left(\mu, \frac{\sigma^2}{n}\right) \quad \text{pour } n \text{ grand} $$

### Interprétation intuitive

Quel que soit le shape de la distribution de départ (skewed, multimodale, discrète, exponentielle…), la moyenne de $n$ tirages :
- **Tend vers gaussienne** quand $n$ grandit
- **A pour moyenne $\mu$** (loi des grands nombres)
- **A pour écart-type $\sigma / \sqrt{n}$** (decay en $1/\sqrt{n}$)

C'est ce $1/\sqrt{n}$ qui sous-tend les bornes statistiques : pour doubler la précision, il faut **4× plus de données**.

### Vitesse de convergence

**Berry-Esseen** : pour $X_i$ avec $\mathbb{E}|X|^3 < \infty$ :

$$ \sup_x |F_n(x) - \Phi(x)| \leq \frac{C \rho}{\sigma^3 \sqrt{n}} $$

avec $\rho = \mathbb{E}|X - \mu|^3$. La convergence est en $O(1/\sqrt{n})$.

**Rule of thumb** : $n \geq 30$ suffit souvent ; mais pour des distributions très skewed (lognormal, exponential), $n \geq 100$-$1000$ peut être nécessaire.

### Variantes / extensions

#### TCL multidimensionnel

Pour $X_i \in \mathbb{R}^d$ avec covariance $\Sigma$ finie :

$$ \sqrt{n}(\bar X_n - \mu) \xrightarrow{d} \mathcal{N}_d(0, \Sigma) $$

#### TCL pour variables dépendantes

Extensions sous diverses formes de **mélange** ($\alpha$-mixing, $\beta$-mixing). Plus difficile à vérifier mais permet d'appliquer le TCL en time series.

#### TCL non-i.i.d. (Lyapunov, Lindeberg)

Conditions plus faibles que i.i.d., variance hétérogène. Demande une **condition de Lindeberg** (queues uniformément bornées).

#### Distribution des extrêmes (théorème de Fisher-Tippett)

Le TCL **ne s'applique pas aux maxima**. Pour $\max X_i$, on a un théorème analogue avec **3 familles limites** : Gumbel, Fréchet, Weibull.

### Implications pratiques

#### Intervalles de confiance

L'IC à 95% pour la moyenne $\mu$ via le TCL :

$$ \text{IC}_{95\%} = \bar X_n \pm 1.96 \cdot \frac{s}{\sqrt{n}} $$

avec $s$ l'écart-type empirique. Valide pour $n$ "assez grand" — d'où l'omniprésence.

#### Bootstrap

Le [[Bootstrap]] est une réincarnation **non-paramétrique** du TCL : approximer la distribution d'échantillonnage de toute statistique régulière par rééchantillonnage.

#### Régression linéaire

Estimateurs $\hat\beta_{OLS}$ sont asymptotiquement gaussiens (TCL multidim sur $X^\top y$). Justifie les tests sur les coefficients.

#### Mini-batch SGD

Le gradient mini-batch est une moyenne empirique → par TCL, ≈ gaussien autour du vrai gradient. Justifie SGD comme une approximation bruitée de GD.

### Pièges classiques

- **Variance infinie** : si $X_i$ a des **queues lourdes** ($\mathbb{E}[X^2] = \infty$, ex. distribution de Cauchy, Pareto α<2), le TCL **ne s'applique pas**. La moyenne ne converge pas vers une gaussienne, elle hérite des queues lourdes.

- **Indépendance fausse** : sur séries temporelles fortement corrélées, les écarts-type calculés via $\sigma/\sqrt{n}$ sont **sous-estimés**. Utiliser HAC standard errors.

- **Convergence lente sur skew** : distribution lognormale très skewed → TCL marche mais demande $n$ très grand pour être visible.

## Quand c'est utile

- **Calcul d'IC** sur moyennes, proportions, OR, RR
- **Tests t** : la statistique de Student converge vers normale pour $n$ grand
- **Modèles linéaires** : asymptotique des estimateurs OLS / GLM
- **SGD analysis** : approximation gaussienne du bruit
- **Survival analysis** : test de log-rank asymptotique
- **A/B testing** : Welch t-test, z-test sur proportions
- **Justifier qu'une moyenne est "stable"** vs un échantillon individuel

## Quand ça ne marche pas / pièges

- **Variance infinie** (queues lourdes Pareto α < 2, Cauchy) → pas de TCL classique
- **Petits échantillons** ($n < 20-30$) avec distribution skewed → utilisation TCL injustifiée. Bootstrap ou tests non-paramétriques préférés.
- **Time series autocorrélé** : variance effective < $n$ d'individus indépendants. Correction de Newey-West.
- **Maxima / minima** : utiliser EVT (extreme value theory), pas TCL
- **Bias of estimator** : TCL parle de $\bar X_n \to \mu$. Si l'estimateur est biaisé, la limite n'est pas la vraie valeur.
- **Confusion TCL vs LLN** : LLN dit $\bar X_n \to \mu$ (convergence point). TCL dit en plus que les **fluctuations** sont gaussiennes.

## Code minimal

```python
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

# Démonstration : moyenne de variables très skewed → gaussienne
np.random.seed(0)
n_per_avg = 100      # taille de chaque échantillon dont on prend la moyenne
n_avgs = 10000        # nombre d'expériences

# Distribution de départ : exponentielle (très skewed)
samples = np.random.exponential(scale=2, size=(n_avgs, n_per_avg))
means = samples.mean(axis=1)

fig, ax = plt.subplots(1, 2, figsize=(10, 4))
ax[0].hist(samples[0], bins=30); ax[0].set_title("Distribution originale (Exp)")
ax[1].hist(means, bins=50); ax[1].set_title(f"Moyenne sur n={n_per_avg} → gaussienne")

# Tests de normalité sur les moyennes
print(stats.shapiro(means))  # p-value élevée si normal
print(f"Mean: {means.mean():.3f}, Std: {means.std():.3f}")
# Prediction TCL : Mean ≈ 2, Std ≈ 2/sqrt(100) = 0.2

# IC à 95% sur une moyenne
data = np.random.lognormal(0, 1, 100)
ic_low, ic_high = stats.t.interval(0.95, len(data) - 1,
                                    loc=data.mean(),
                                    scale=stats.sem(data))
print(f"IC95%: ({ic_low:.3f}, {ic_high:.3f})")
```

## Pour aller plus loin

- Klenke, *Probability Theory: A Comprehensive Course* — chap. sur TCL classique et modernes
- Billingsley, *Probability and Measure* — référence académique
- Embrechts, Klüppelberg, Mikosch, *Modelling Extremal Events* — pour les contre-exemples (variance infinie)
- **Liens internes** : [[Hypothesis testing]], [[Confidence intervals]], [[Bootstrap]], [[Concentration inequalities]] (bornes finite-sample), [[Gradient descent]]
