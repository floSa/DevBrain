---
galaxie: wiki
nom: Multiple testing correction
alias: [correction tests multiples, Bonferroni, Holm, FDR, Benjamini-Hochberg]
type: concept
categorie: concept/stats
sous_categories: [multiple-testing, fwer, fdr, bonferroni, holm, benjamini-hochberg]
domaines: [data-science]
maturite: established
auteurs_cles: [Bonferroni 1936, Holm 1979, Benjamini-Hochberg 1995]
lecture_min: 7
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, multiple-testing, fwer, fdr]
---

# Multiple testing correction

## TL;DR

Quand tu fais $m$ tests d'hypothèse avec $\alpha = 0.05$, **la probabilité d'avoir au moins un faux positif explose** ($\approx 1 - 0.95^m$). À $m = 20$ : 64%. Pour contrôler ce risque, on **corrige** soit le **FWER** (probabilité d'au moins une erreur — Bonferroni, Holm) soit le **FDR** (proportion attendue de faux positifs parmi les rejets — Benjamini-Hochberg).

## Le problème

Tu testes 20 variantes de landing page contre l'originale en A/B. Sous $H_0$ (aucune ne diffère), avec $\alpha = 0.05$, la proba qu'**au moins une** soit "significative" par hasard est :

$$ 1 - (1 - 0.05)^{20} \approx 0.64 $$

Soit 64% de chances de crier au loup à tort. C'est l'**inflation du type I**.

Variantes du problème :
- 1000 gènes testés en biologie pour différentielle d'expression
- 50 features testées une à une pour corrélation avec target
- Backtest de stratégies trading
- A/B testing avec plein de métriques secondaires

## L'idée

### FWER — Family-Wise Error Rate

Probabilité d'**au moins une** fausse découverte :

$$ \text{FWER} = P(\text{au moins un } H_0 \text{ vrai rejeté}) $$

Contrôler le FWER à $\alpha$ = "garantir que sur l'ensemble de la famille de tests, on a moins de $\alpha$ de chance d'avoir un seul faux positif".

#### Bonferroni

Le plus simple. Pour $m$ tests, utiliser le seuil $\alpha/m$ pour chacun, OU multiplier chaque p-value par $m$ :

$$ p_i^{\text{Bonf}} = \min(m \cdot p_i, 1) $$

✅ Simple, garanti contrôler FWER ≤ $\alpha$
❌ **Très conservateur** : avec $m$ grand, presque rien n'est significatif

#### Holm-Bonferroni (Holm)

Plus puissant que Bonferroni en gardant la garantie FWER.
1. Trier les p-values : $p_{(1)} \leq p_{(2)} \leq \dots \leq p_{(m)}$
2. Comparer $p_{(i)}$ à $\frac{\alpha}{m - i + 1}$
3. Rejeter $p_{(1)}, \dots, p_{(k)}$ jusqu'au premier $p_{(k+1)} > \frac{\alpha}{m-k}$

**Toujours préférer Holm à Bonferroni** : même garantie, plus puissant.

#### Sidák

Variante avec correction multiplicative : $\alpha_{\text{adj}} = 1 - (1-\alpha)^{1/m}$. Très proche de Bonferroni, légèrement moins conservateur.

### FDR — False Discovery Rate

Au lieu de contrôler la probabilité d'**au moins une** erreur, on contrôle la **proportion attendue de faux positifs parmi les rejets** :

$$ \text{FDR} = E\left[\frac{\text{faux positifs}}{\text{total rejets}}\right] $$

Tolère plus de faux positifs en absolu, mais maintient une proportion raisonnable. **Plus puissant** que FWER, particulièrement pour $m$ grand.

#### Benjamini-Hochberg (BH)

1. Trier les p-values : $p_{(1)} \leq p_{(2)} \leq \dots \leq p_{(m)}$
2. Trouver le plus grand $k$ tel que $p_{(k)} \leq \frac{k}{m} \alpha$
3. Rejeter $p_{(1)}, \dots, p_{(k)}$

Garantit $\text{FDR} \leq \alpha$ sous indépendance ou dépendance positive.

#### Benjamini-Yekutieli (BY)

Variante valide sous **toute structure de dépendance**, mais plus conservatrice.

### Choix FWER vs FDR

| | FWER (Bonferroni/Holm) | FDR (BH) |
|---|---|---|
| Quand | Décisions individuelles critiques (médical, A/B test prod) | Exploration, screening |
| Coût d'un faux positif | Élevé | Modéré |
| Nb de tests | Petit à moyen ($m < 50$) | Moyen à grand ($m \geq 50$) |
| Exemples | Médecine clinique, finance | Génomique, ML feature selection |

### Pré-spécifier vs explorer

- **Pré-spécifier** une famille de tests **avant** l'expérience → correction propre
- **Explorer** puis correction post-hoc → souvent insuffisant. Préférer une approche bayésienne ou répliquer sur dataset indépendant.

## Quand c'est utile

- A/B testing avec plusieurs métriques
- Analyse génomique / multi-omics
- Sélection de features par tests univariés
- Comparaison de plusieurs modèles ML (Tukey HSD est en réalité une correction multiple)
- Screening exploratoire avant validation

## Quand ça ne marche pas / pièges

- **Ne pas corriger** quand on devrait → inflation du type I, conclusions faussées
- **Sur-correction** (Bonferroni avec $m$ énorme) → puissance ridicule, on rate tous les vrais effets. Passer au FDR.
- **Confusion sur le "$m$"** : $m$ = nombre de **tests planifiés et reportés**, pas seulement ceux significatifs. Compter honnêtement.
- **Tests dépendants** : Bonferroni reste valide ; BH valide aussi sous dépendance positive ; BY plus conservatrice.
- **Application à p-values déjà sélectionnées** (post-hoc filter) → biais. Toujours appliquer la correction à l'ensemble complet des tests.
- **Confusion familial vs trial-wise** : si tu mènes 20 expériences indépendantes, chacune avec son test, pas besoin de Bonferroni global.

## Code minimal

```python
from statsmodels.stats.multitest import multipletests

p_values = [0.01, 0.04, 0.03, 0.005, 0.20, 0.50, 0.001]

# Bonferroni
reject, p_corrected, _, _ = multipletests(p_values, alpha=0.05, method='bonferroni')

# Holm
reject_h, p_h, _, _ = multipletests(p_values, alpha=0.05, method='holm')

# Benjamini-Hochberg (FDR)
reject_bh, p_bh, _, _ = multipletests(p_values, alpha=0.05, method='fdr_bh')

print(f"Original  : {p_values}")
print(f"Bonferroni: {p_corrected.round(3)}, rejected: {reject}")
print(f"Holm      : {p_h.round(3)}, rejected: {reject_h}")
print(f"BH (FDR)  : {p_bh.round(3)}, rejected: {reject_bh}")
```

## Implémentations concrètes

- `statsmodels.stats.multitest.multipletests` — toutes les méthodes (`bonferroni`, `holm`, `fdr_bh`, `fdr_by`, etc.)
- `scipy.stats.false_discovery_control`
- R : `p.adjust` (méthodes : `bonferroni`, `holm`, `BH`, `BY`)

## Pour aller plus loin

- Benjamini & Hochberg, *Controlling the False Discovery Rate* (JRSS-B 1995) — paper fondateur FDR
- Holm, *A simple sequentially rejective multiple test procedure* (1979)
- Goeman & Solari, *Multiple hypothesis testing in genomics* (2014) — review moderne
- **Liens internes** : [[Hypothesis testing]], [[t-test and ANOVA]] (post-hoc Tukey est une correction), [[Chi-squared tests]]
