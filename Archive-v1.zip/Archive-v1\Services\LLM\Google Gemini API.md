---
galaxie: dev
nom: Google Gemini API
alias: [gemini, gemini-api, vertex-ai-gemini, gemini-flash, gemini-pro]
categorie: llm/api
sous_categories: [api, llm, multimodal, native-mm, long-context, google]
licence: Proprietaire
licence_type: proprietary
hosted: managed
maturite: production
langage: 
clients_officiels: [python, ts, go, java]
plateforme: [cloud]
score: 4
mes_projets: []
alternatives: ["[[Anthropic Claude API]]", "[[OpenAI API]]", "[[Mistral API]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, api, gemini, google, multimodal]
url_officiel: https://ai.google.dev/
url_docs: https://ai.google.dev/gemini-api/docs
url_repo: 
---

# Google Gemini API

## Pourquoi
LLM API Google DeepMind. Modèles **Gemini Flash** (rapide/cheap), **Pro** (balanced), **Ultra**, **Thinking** (reasoning). **Multimodal natif** (texte + image + audio + vidéo en input). **Long context star** : 1M tokens (2M en preview), excellent NIAH. Context caching avec TTL configurable.

## Quand l'utiliser
- Long document analysis (100K-1M tokens) — Gemini brille
- Multimodal natif (vidéo / audio en input)
- Context caching avec TTL custom (jusqu'à 1 an)
- Pricing agressif Flash pour scale (~$0.075/1M input)
- Stack GCP (Vertex AI intégration)

## Quand NE PAS l'utiliser
- Reasoning hard (math compétition, code algorithm) → Claude Opus / o3 (souvent meilleurs)
- Sécurité / refus → Claude moins de faux positifs souvent
- API stabilité historique → Gemini évolue vite, breaking changes plus fréquents
- Petits prompts simples → choix de modèle plus large ailleurs

## Pièges connus
- **2 APIs** : Google AI Studio (rapide, gratuit limited) vs Vertex AI (enterprise GCP) — features parfois divergentes
- **Versions** : `gemini-2.5-pro`, `-flash`, `-thinking-experimental` — roadmap évolue tous les ~3 mois
- **Safety filters** : peut bloquer réponses légitimes, configurer `safety_settings` explicitement
- **Function calling** : format légèrement différent OpenAI/Anthropic
- **Context caching** : explicit (`CachedContent.create`), pricing séparé
- **Latency** : Flash très rapide, Pro/Thinking lent
- **Régions** : disponibilité variable selon modèle (Vertex)

## Liens
- [[Anthropic Claude API]] / [[OpenAI API]] / [[Mistral API]] — alternatives
- [[Context engineering]] — Gemini = champion context caching
- [[Vision Language Models]] — Gemini natif multimodal
- AI Studio : https://aistudio.google.com/
- Vertex AI Gemini : https://cloud.google.com/vertex-ai
- Docs : https://ai.google.dev/gemini-api/docs
- Pricing : https://ai.google.dev/pricing
