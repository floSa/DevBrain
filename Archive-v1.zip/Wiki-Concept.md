---
galaxie: wiki
nom: <% tp.file.title %>
type: concept
categorie: concept/
sous_categories: []
domaines: []
maturite: 
auteurs_cles: []
lecture_min: 
created: <% tp.date.now("YYYY-MM-DD") %>
modified: <% tp.date.now("YYYY-MM-DD") %>
tags: [concept]
---

# <% tp.file.title %>

## TL;DR

(2-3 lignes pour retrouver le concept en 30 secondes dans 6 mois)

## Le problème

(Ce qu'on essaie de résoudre. Sans le problème, pas besoin du concept.)

## L'idée

(Le mécanisme central. Schémas/exemples bienvenus.)

## Quand c'est utile

- 
- 

## Quand ça ne marche pas / pièges

- 

## Implémentations concrètes

- [[<service ou skill>]] — usage typique
- 

## Pour aller plus loin

- Paper / blog / talk : 
- Notes perso :
