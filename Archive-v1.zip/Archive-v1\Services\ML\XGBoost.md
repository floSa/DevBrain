---
galaxie: dev
nom: XGBoost
alias: [xgb, eXtreme Gradient Boosting]
categorie: ml/framework
sous_categories: [gradient-boosting, supervised, tabular, regression, classification, ranking]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: C++
clients_officiels: [python, r, java, scala, julia]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[LightGBM]]", "[[CatBoost]]", "[[scikit-learn]]"]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, ml, gradient-boosting, supervised, tabular]
url_officiel: https://xgboost.readthedocs.io/
url_docs: https://xgboost.readthedocs.io/en/stable/
url_repo: https://github.com/dmlc/xgboost
---

# XGBoost

## Pourquoi

L'implémentation **historique et de référence** du gradient boosting sur arbres, créée par Tianqi Chen (2014). A dominé les compétitions Kaggle pendant des années. Très optimisé en C++ (sparse-aware, parallélisme, GPU). **Le baseline tabulaire** : si XGBoost ne marche pas, c'est que tu as un problème non-tabulaire.

Concurrent direct de [[LightGBM]] (Microsoft, plus rapide) et [[CatBoost]] (Yandex, meilleur sur catégoriel). En 2025-2026, les trois cohabitent ; XGBoost reste la valeur sûre la plus largement testée en prod.

## Quand l'utiliser

- Données tabulaires (CSV, parquet, SQL → pandas)
- Classification binaire / multiclass, régression, ranking (LTR)
- Mix continu + catégoriel (avec one-hot ou label encoding)
- Quand tu veux une baseline forte rapidement
- Mode "production stable, communauté énorme" préféré à "plus rapide mais moins testé"

## Quand NE PAS l'utiliser

- Données non-tabulaires (images, texte, audio) → DL dédié
- Très haute cardinalité catégorielle native → [[CatBoost]] (gère sans one-hot)
- Vitesse d'entraînement critique sur très gros dataset → [[LightGBM]]
- Tu veux un seul algo qui couvre régression linéaire, GLM, MM → [[scikit-learn]]
- < 100 observations → modèle simple ou bayésien

## Pièges connus

- **Sklearn-like API vs Booster native** : `XGBClassifier/XGBRegressor` (sklearn-compatible) plus simple ; `xgb.train(...)` natif plus flexible mais verbose
- **Early stopping** : nécessite un eval_set, easy à oublier → overfit silencieux
- **Catégoriel** : XGBoost a un mode `enable_categorical=True` mais moins mature que CatBoost ; pour <50 modalités, one-hot reste safe
- **GPU** : `tree_method='hist'` + `device='cuda'` pour bénéficier du GPU. Plus rapide sur gros dataset (≥1M lignes), gain marginal sinon
- **Missing values** : XGBoost gère NaN nativement (apprend la direction "par défaut" à chaque split). Ne pas imputer si pas nécessaire.
- **Tuning** : trop d'hyperparams (n_estimators, max_depth, learning_rate, subsample, colsample, gamma, reg_alpha, reg_lambda, min_child_weight). Utiliser Optuna ou la suggestion documentée d'Anil Aakaur

## Liens

- Doc officielle : https://xgboost.readthedocs.io/
- Repo : https://github.com/dmlc/xgboost
- Paper : Chen & Guestrin, *XGBoost: A Scalable Tree Boosting System* (KDD 2016)
- Concepts liés : [[Ensembling]] (boosting), [[Bias-variance tradeoff]], [[Cross-validation]], [[Regularization]], [[ROC AUC]], [[Calibration]]
- Alternatives : [[LightGBM]], [[CatBoost]]
- [[Optuna]] (tuning d'hyperparams)
