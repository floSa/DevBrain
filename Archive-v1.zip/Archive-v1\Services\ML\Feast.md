---
galaxie: dev
nom: Feast
alias: [feast, feast-feature-store]
categorie: ml/feature-store
sous_categories: [feature-store, ml-ops, online-store, offline-store, point-in-time]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python / Go
clients_officiels: [python, go, java]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["Tecton", "Hopsworks", "Featureform", "AWS SageMaker Feature Store"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, feature-store, ml-ops]
url_officiel: https://feast.dev/
url_docs: https://docs.feast.dev/
url_repo: https://github.com/feast-dev/feast
---

# Feast

## Pourquoi

**Feature store open-source #1**. Sépare deux mondes :
- **Offline store** ([[BigQuery]], [[Snowflake]], Redshift, Parquet S3) : features historiques pour training avec **point-in-time correctness** (pas de data leakage temporel)
- **Online store** (Redis, DynamoDB, Postgres) : features fraîches pour serving low-latency

Standard pour orgs ML matures qui veulent du **feature reuse** entre modèles et de la **consistency train/serve** (le modèle voit exactement les mêmes features en train qu'en prod). Concurrent open-source de Tecton (managed, fondé par les créateurs Feast initiaux) et Hopsworks.

## Quand l'utiliser

- **Plusieurs modèles** partagent les mêmes features (recommandation + fraude + churn = features users communes)
- **Pipeline train/serve** avec besoin de **consistency** stricte
- **Point-in-time correctness** : éviter data leakage (e.g. avg basket à T sans inclure achats futurs)
- **Multiple data scientists** qui réutilisent / découvrent des features (registry partagé)
- **Online inference low-latency** : Redis/DynamoDB lookup en <10ms
- **Materialisation programmée** : push features offline → online périodiquement
- **Combo Spark / Snowflake** : intégrations natives

## Quand NE PAS l'utiliser

- **1 modèle / 1 use case** : over-engineering, un script pandas suffit
- **Petite échelle** : moins de 10 features, < 1M users → Postgres direct OK
- **Stack très custom** : parfois plus rapide à build maison
- **LLM / RAG only** : feature store n'a pas grand sens pour LLM eng
- **Streaming features uniquement** → outils streaming dédiés ([[Flink]] features, etc.)
- **Pas d'équipe ML platform** : Feast demande un mainteneur dédié

## Pièges connus

- **Setup lourd** : online store + offline store + registry + materialisation → 3-4 services à orchestrer
- **Concepts à apprendre** : Entity, FeatureView, FeatureService, OnlineStore, OfflineStore — onboarding 1-2 semaines
- **Point-in-time correctness mal compris** : si tu zappes l'event_timestamp, tu fais du data leakage sans le voir
- **Tecton managed cher** : version SaaS facturée à six chiffres pour les grosses orgs
- **Doc parfois en retard** sur le code (releases fréquentes)
- **Materialisation = job batch** : pas magique, à planifier (Airflow/Prefect)
- **Online store choisi à vie** : changer de backend = remateraliser tout
- **Spark backend optionnel** : sans Spark, scale offline limité (Snowflake/BigQuery natifs préférés)
- **Feature transforms limités** : Feast n'est PAS un compute engine — transforms riches = downstream (dbt, Spark)

## Code minimal

```bash
pip install "feast[redis,snowflake]"
feast init my_feature_repo
cd my_feature_repo
```

```python
# feature_repo/example.py
from datetime import timedelta
from feast import Entity, FeatureView, Field, FileSource
from feast.types import Float32, Int64

# Entity : la cle business
user = Entity(name="user_id", join_keys=["user_id"])

# Source = table avec event_timestamp obligatoire
user_stats_source = FileSource(
    path="data/user_stats.parquet",
    timestamp_field="event_timestamp",
)

# FeatureView = ensemble de features pour une entity
user_stats_fv = FeatureView(
    name="user_stats",
    entities=[user],
    ttl=timedelta(days=30),
    schema=[
        Field(name="orders_7d", dtype=Int64),
        Field(name="avg_basket_30d", dtype=Float32),
    ],
    source=user_stats_source,
    online=True,
)
```

```bash
# Deployer le registry + materialiser
feast apply
feast materialize-incremental $(date -u +"%Y-%m-%dT%H:%M:%S")
```

```python
# Cote training : historical features (point-in-time correct)
from feast import FeatureStore
import pandas as pd

store = FeatureStore(repo_path=".")

entity_df = pd.DataFrame({
    "user_id": [1, 2, 3],
    "event_timestamp": pd.to_datetime(["2026-05-15", "2026-05-16", "2026-05-17"]),
})
training_df = store.get_historical_features(
    entity_df=entity_df,
    features=["user_stats:orders_7d", "user_stats:avg_basket_30d"],
).to_df()

# Cote serving : online features (low-latency)
features = store.get_online_features(
    features=["user_stats:orders_7d", "user_stats:avg_basket_30d"],
    entity_rows=[{"user_id": 1}],
).to_dict()
```

## Liens

- Tecton — version managed Feast++ (par les créateurs initiaux)
- Hopsworks — alternative open-source + managed
- Featureform — alternative plus jeune, code-first
- AWS SageMaker Feature Store — alternative AWS-natif
- [[Spark]] / [[Snowflake]] / [[BigQuery]] — backends offline typiques
- [[Redis]] / DynamoDB — backends online typiques
- Docs : https://docs.feast.dev/
- GitHub : https://github.com/feast-dev/feast
