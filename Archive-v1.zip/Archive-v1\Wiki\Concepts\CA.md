---
galaxie: wiki
nom: Correspondence Analysis (CA)
alias: [CA, AFC, Analyse Factorielle des Correspondances]
type: concept
categorie: concept/stats
sous_categories: [factor-analysis, categorical, contingency-table, chi-square]
domaines: [data-science]
maturite: established
auteurs_cles: [Benzécri 1973 (école française), Greenacre 1984]
lecture_min: 12
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, ca, factor-analysis, categorical]
---

# Correspondence Analysis (CA)

## TL;DR

L'analogue de [[PCA]] pour un **tableau de contingence** entre deux variables catégorielles. Représente les modalités lignes ET colonnes dans un même plan factoriel, où la **proximité géométrique reflète l'association statistique** (au sens du $\chi^2$). C'est la méthode signature de l'école française d'analyse de données.

## Le problème

Soit un tableau de contingence $N \in \mathbb{N}^{I \times J}$ croisant deux variables catégorielles (ex. profession × média préféré). On veut :
- **Visualiser les associations** entre modalités lignes et colonnes
- Identifier les **modalités "qui s'attirent"** vs celles indépendantes
- Mesurer l'écart global à l'indépendance (au-delà du simple $\chi^2$)

## L'idée

### Cadre

Soit $n = \sum N_{ij}$. On définit :
- **Tableau des fréquences** : $F = N / n$
- **Marges** : $r_i = \sum_j F_{ij}$ (poids ligne), $c_j = \sum_i F_{ij}$ (poids colonne)
- **Profils ligne** : $F_{ij} / r_i$ (distribution conditionnelle de la colonne sachant ligne $i$)
- **Profils colonne** : $F_{ij} / c_j$ symétrique

### Distance du $\chi^2$

Au lieu de la distance euclidienne, on compare les profils via la distance du $\chi^2$, pondérée par l'inverse des marges :

$$ d^2_{\chi^2}(i, i') = \sum_j \frac{1}{c_j} \left( \frac{F_{ij}}{r_i} - \frac{F_{i'j}}{r_{i'}} \right)^2 $$

Cette distance a la propriété d'**équivalence distributionnelle** : fusionner deux colonnes identiques ne change pas la géométrie.

### Calcul par SVD pondérée

On forme la matrice standardisée :

$$ Z = D_r^{-1/2} (F - r c^\top) D_c^{-1/2} $$

avec $D_r = \mathrm{diag}(r)$, $D_c = \mathrm{diag}(c)$. Notamment $Z_{ij} = (F_{ij} - r_i c_j)/\sqrt{r_i c_j}$ — c'est le signed Pearson residual.

SVD : $Z = U \Sigma V^\top$. Les **valeurs propres** $\lambda_k = \sigma_k^2$ s'appellent les **inerties principales**.

### Inertie totale et lien $\chi^2$

L'inertie totale = somme des $\lambda_k$ = $\chi^2 / n$, où $\chi^2$ est le test classique d'indépendance.

Forte inertie totale = forte dépendance entre les deux variables.

### Coordonnées

- **Coordonnées lignes** : $F_r = D_r^{-1/2} U \Sigma$ — projection des lignes
- **Coordonnées colonnes** : $F_c = D_c^{-1/2} V \Sigma$

Représentation symétrique : on superpose les deux nuages dans le même plan factoriel.

**Interprétation** : deux modalités proches dans le plan sont **plus associées qu'attendu sous indépendance**. Une modalité loin du centre = forte contribution à l'inertie d'un axe.

## Quand c'est utile

- Sondages, panels (média × profession, vote × région)
- Analyse de questionnaires fermés (deux questions à la fois)
- Linguistique (texte × auteur : mots distinctifs par auteur)
- Marketing (produit × segment)
- Tout cas où le $\chi^2$ "passe" mais où on veut comprendre la structure de la dépendance

## Quand ça ne marche pas / pièges

- **>2 variables catégorielles** → utiliser [[MCA]] (extension)
- **Variables continues** → c'est [[PCA]] / [[FAMD]]
- **Échantillon trop petit** → les fréquences attendues < 5 cassent l'interprétation $\chi^2$
- **Modalité ultra-rare** → ressort comme outlier qui tire un axe — souvent à fusionner ou retirer
- **Interpréter une "proximité"** entre une ligne et une colonne demande attention : la représentation symétrique n'est qu'une approximation, vraie seulement à l'optimum.
- **Confusion proximité géométrique vs causalité** : une CA décrit l'association, pas la causalité.

## Code minimal

```python
import prince

df = pd.DataFrame({
    'profession': ['cadre', 'ouvrier', 'cadre', ...],
    'média':      ['Le Monde', 'TF1', 'Mediapart', ...],
})

# Contingency table puis CA
ct = pd.crosstab(df['profession'], df['média'])
ca = prince.CA(n_components=2).fit(ct)

ca.plot(ct)   # plan factoriel symétrique
print(ca.eigenvalues_)            # inerties
print(ca.row_coordinates(ct))     # coords lignes
print(ca.column_coordinates(ct))  # coords colonnes
```

## Implémentations concrètes

- [[prince]] — pythonique, ergonomie FactoMineR
- [[fanalysis]] — alternative, plus minimaliste
- R : `FactoMineR::CA` (la référence académique)
- `statsmodels` — pas natif CA mais $\chi^2$ et résidus dispos

## Pour aller plus loin

- Greenacre, *Correspondence Analysis in Practice* (3e éd., 2017) — bible
- Référence française : Husson, Lê, Pagès, *Analyse de données avec R*
- **Liens internes** : [[PCA]] (le pendant continu), [[MCA]] (extension >2 var. cat.), [[FAMD]] (mix continu/cat.), [[MFA]] (groupes de variables)
