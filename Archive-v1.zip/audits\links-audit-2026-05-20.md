---
galaxie: ai
nom: Audit liens manquants 2026-05-20
type: audit
created: 2026-05-20
tags: [audit, links, report]
---

# Audit liens manquants - 2026-05-20

> Genere par `AI/scripts/audit-links.ps1` (MinScore=12, TopN=8).
> Pour chaque fiche, liste les fiches dont le score de similarite est >= 12 mais qui ne sont PAS deja wikilinkees.

## Stats

- Fiches auditees    : 171
- Fiches avec liens manquants : 167
- Total liens manquants candidats : 1277

## Liens manquants par fiche

### `Wiki/Concepts/Ranking metrics.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 37 | `[[Forecasting metrics]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics |
| 37 | `[[Regression metrics]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics |
| 26 | `[[t-SNE and UMAP]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 25 | `[[Reranking]]` | wiki | alias-partial | cat-top | domaines:ai-eng | souscat:retrieval | tags:concept+rag+retrieval |
| 23 | `[[Clustering evaluation]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:evaluation+metrics | tags:concept+metrics | mots:metrics |
| 23 | `[[MAP estimation]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept | mots:map |
| 22 | `[[ROC AUC]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics |
| 22 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/RAG.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 29 | `[[LLM eval metrics]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm+rag |
| 25 | `[[embeddings]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:retrieval | tags:concept+llm |
| 23 | `[[Query transformations]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept+rag+llm | mots:rag |
| 23 | `[[Advanced RAG|Advanced RAG architectures]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept+rag+llm | mots:rag |
| 23 | `[[RAG eval|RAG evaluation]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept+rag+llm | mots:rag |
| 21 | `[[Ranking metrics]]` | wiki | cat-top | domaines:ml-eng+ai-eng | souscat:retrieval | tags:concept+retrieval+rag |
| 19 | `[[Synthetic data generation]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Tokenization]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/Regression metrics.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 25 | `[[LLM eval metrics]]` | wiki | categorie | domaines:ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics |
| 24 | `[[Clustering evaluation]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:evaluation+metrics | tags:concept+metrics | mots:evaluation+metrics |
| 22 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[ROC AUC]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics |
| 22 | `[[MAP estimation]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 15 | `[[Walk-forward CV]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept | mots:evaluation |

### `Wiki/Concepts/Reasoning models.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Small Language Models|Small Language Models (SLM)]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:models |
| 16 | `[[Context engineering]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:long |
| 16 | `[[Vision Language Models|Vision Language Models (VLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:models |
| 15 | `[[LLM-as-judge]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Structured outputs]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Synthetic data generation]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[SFT|SFT (Supervised Fine-Tuning)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/RAG eval.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 23 | `[[Code and math benchmarks|Code & math benchmarks]]` | wiki | categorie | domaines:ai-eng | souscat:llm-eval | tags:concept+llm+eval |
| 23 | `[[LLM benchmarks]]` | wiki | categorie | domaines:ai-eng | souscat:eval | tags:concept+llm+eval |
| 21 | `[[Ragas]]` | dev | alias-exact | tags:llm+eval+rag |
| 18 | `[[Query transformations]]` | wiki | cat-top | domaines:ai-eng | souscat:rag | tags:concept+rag+llm | mots:rag |
| 17 | `[[Chunking strategies]]` | wiki | cat-top | domaines:ai-eng | souscat:rag | tags:concept+rag+llm |
| 16 | `[[Classification metrics]]` | wiki | alias-partial | cat-top | tags:concept | mots:metrics+precision |
| 15 | `[[Reranking]]` | wiki | cat-top | domaines:ai-eng | souscat:rag | tags:concept+rag |
| 14 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | alias-partial | cat-top | tags:concept |

### `Wiki/Concepts/prompt-caching.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[Inference optimization]]` | wiki | cat-top | domaines:ai-eng | souscat:optimization | tags:concept+llm+optimization | mots:caching |
| 18 | `[[agent-loops|Agent loops]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 18 | `[[RAG]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 18 | `[[embeddings]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 18 | `[[tool-use|Tool Use]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 17 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng | souscat:optimization | tags:concept+llm+optimization |
| 16 | `[[mcp-protocol|MCP Protocol]]` | wiki | categorie | domaines:ai-eng | tags:concept |
| 14 | `[[Flash Attention and efficient attention|Flash Attention & efficient attention]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm+optimization |

### `Wiki/Concepts/Prompt injection.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 13 | `[[Context engineering]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:prompt |
| 13 | `[[Synthetic data generation]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:data |
| 13 | `[[LLM caching]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:prompt |
| 13 | `[[prompt-caching|Prompt Caching]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:prompt |
| 13 | `[[Prompt engineering]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:prompt |
| 12 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm |
| 12 | `[[Reliability patterns|Reliability patterns (LLM)]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm |
| 12 | `[[Scaling laws]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm |

### `Wiki/Concepts/Query transformations.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[RAG eval|RAG evaluation]]` | wiki | cat-top | domaines:ai-eng | souscat:rag | tags:concept+rag+llm | mots:rag |
| 17 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng | souscat:rag | tags:concept+llm+rag |
| 14 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | tags:concept |
| 13 | `[[Self-attention]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:multi |
| 13 | `[[Multi-agent systems]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:multi |
| 12 | `[[Reliability patterns|Reliability patterns (LLM)]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm |
| 12 | `[[Reasoning models]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm |
| 12 | `[[Routing and cascading|LLM routing & cascading]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm |

### `Wiki/Concepts/Quantization.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:inference+llm | tags:concept+llm+inference+optimization |
| 25 | `[[Synthetic data generation]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[Scaling laws]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[Distillation|Knowledge distillation]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[SFT|SFT (Supervised Fine-Tuning)]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 24 | `[[Transformer architectures]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 21 | `[[Decoding strategies]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm+inference |

### `Wiki/Concepts/Regularization.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Clustering evaluation]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 29 | `[[Vector norms]]` | wiki | alias-exact | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Ensembling]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[GMM|Gaussian Mixture Models (GMM)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[ROC AUC]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[DBSCAN]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Imbalanced classification]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/SFT.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 27 | `[[Scaling laws]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm+training |
| 25 | `[[Distillation|Knowledge distillation]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[Quantization|Quantization (LLM)]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Decoding strategies]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 16 | `[[Mixture of Experts|Mixture of Experts (MoE)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[Flash Attention and efficient attention|Flash Attention & efficient attention]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |

### `Wiki/Concepts/Self-attention.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Mixture of Experts|Mixture of Experts (MoE)]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+transformer+llm |
| 24 | `[[Inference optimization]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 22 | `[[State Space Models|State Space Models (SSM)]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+llm |
| 17 | `[[Synthetic data generation]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm | mots:self |
| 16 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[Distillation|Knowledge distillation]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[Decoding strategies]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[PEFT|PEFT (LoRA, QLoRA, DoRA)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |

### `Wiki/Concepts/Small Language Models.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Reasoning models]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:models |
| 18 | `[[Vision Language Models|Vision Language Models (VLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:language+models+llm |
| 16 | `[[LLM-as-judge]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |
| 16 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |
| 16 | `[[LLM benchmarks]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |
| 15 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Structured outputs]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Synthetic data generation]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/Shannon entropy.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 27 | `[[Jensen-Shannon divergence]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+info-theory | mots:shannon |
| 26 | `[[Wasserstein distance]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+info-theory |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 18 | `[[embeddings]]` | wiki | cat-top | domaines:ai-eng+ml-eng+data-science | tags:concept |
| 18 | `[[Markov chains]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[SVD|SVD (Singular Value Decomposition)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Ranking metrics]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |

### `Wiki/Concepts/Scaling laws.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 27 | `[[SFT|SFT (Supervised Fine-Tuning)]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm+training |
| 27 | `[[Synthetic data generation]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm+training |
| 27 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm+training |
| 25 | `[[PEFT|PEFT (LoRA, QLoRA, DoRA)]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[Quantization|Quantization (LLM)]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Feature engineering]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept | mots:scaling |
| 19 | `[[Tokenization]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/RLHF and DPO.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 27 | `[[Scaling laws]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm+training |
| 27 | `[[Tokenization]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 27 | `[[Synthetic data generation]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm+training |
| 25 | `[[Distillation|Knowledge distillation]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[Quantization|Quantization (LLM)]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Decoding strategies]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/Reliability patterns.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Guardrails|Guardrails & safety runtime]]` | wiki | categorie | domaines:ai-eng | souscat:llm-ops | tags:concept+llm+production | mots:llm |
| 18 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 14 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | tags:concept |
| 13 | `[[Small Language Models|Small Language Models (SLM)]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |
| 13 | `[[LLM benchmarks]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |
| 13 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |
| 13 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |
| 13 | `[[LLM-as-judge]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |

### `Wiki/Concepts/Routing and cascading.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Guardrails|Guardrails & safety runtime]]` | wiki | categorie | domaines:ai-eng | souscat:llm-ops | tags:concept+llm+production | mots:llm |
| 17 | `[[LiteLLM]]` | dev | alias-exact | tags:llm |
| 14 | `[[CA|Correspondence Analysis (CA)]]` | wiki | alias-partial | cat-top | tags:concept |
| 13 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |
| 13 | `[[LLM-as-judge]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |
| 13 | `[[Mixture of Experts|Mixture of Experts (MoE)]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:routing |
| 13 | `[[LLM benchmarks]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |
| 13 | `[[Vision Language Models|Vision Language Models (VLM)]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |

### `Wiki/Concepts/ROC AUC.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Clustering evaluation]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:evaluation+metrics | tags:concept+ml+metrics |
| 30 | `[[Imbalanced classification]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:imbalanced+classification | tags:concept+ml+classification |
| 27 | `[[Classification metrics]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:metrics+classification+evaluation | tags:concept+metrics+classification |
| 22 | `[[Ensembling]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[DBSCAN]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Regularization]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Regression metrics]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics |
| 22 | `[[Poisson process]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Workflows/Evaluer un systeme LLM.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 20 | `[[Evaluer un modele forecast]]` | wiki | cat-top | domaines:ml-eng | souscat:eval+metrics | tags:workflow+eval | mots:evaluer+un |
| 19 | `[[LLM eval metrics]]` | wiki | domaines:ai-eng+ml-eng | souscat:metrics+llm | tags:llm+eval | mots:llm |
| 18 | `[[Bootstrap projet AI eng]]` | wiki | categorie | domaines:ai-eng | tags:workflow+ai-eng |
| 15 | `[[LLM-as-judge]]` | wiki | domaines:ai-eng | souscat:eval+llm | tags:llm+eval | mots:llm |
| 15 | `[[LLM benchmarks]]` | wiki | domaines:ai-eng | souscat:eval+llm | tags:llm+eval | mots:llm |
| 14 | `[[Quantization|Quantization (LLM)]]` | wiki | domaines:ai-eng+ml-eng | souscat:llm | tags:llm | mots:llm |
| 13 | `[[Synthetic data generation]]` | wiki | domaines:ai-eng+ml-eng | souscat:llm | tags:llm |
| 13 | `[[Speculative decoding]]` | wiki | domaines:ai-eng+ml-eng | souscat:llm | tags:llm |

### `Wiki/Concepts/Multi-agent systems.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[agent-loops|Agent loops]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents+llm | mots:agent |
| 18 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 15 | `[[tool-use|Tool Use]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+llm |
| 15 | `[[mcp-protocol|MCP Protocol]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents |
| 14 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | tags:concept |
| 13 | `[[Self-attention]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:multi |
| 13 | `[[Query transformations]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:multi |
| 13 | `[[Bayesian inference]]` | wiki | cat-top | domaines:ai-eng | souscat:hierarchical | tags:concept |

### `Wiki/Concepts/Mutual information.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[Gradient descent|Gradient descent and variants]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 26 | `[[Wasserstein distance]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+info-theory |
| 26 | `[[Jensen-Shannon divergence]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+info-theory |
| 26 | `[[Cross-entropy]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+info-theory |
| 22 | `[[Loss landscape and saddle points]]` | wiki | alias-partial | cat-top | domaines:ml-eng+ai-eng | tags:concept |
| 22 | `[[A-B testing|A/B testing]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Missing data]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Data leakage]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Multiple testing correction.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 20 | `[[MCA|Multiple Correspondence Analysis (MCA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats | mots:multiple+multiples |
| 19 | `[[MFA|Multiple Factor Analysis (MFA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats | mots:multiple |
| 18 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[PCA|Principal Component Analysis (PCA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |
| 18 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[CA|Correspondence Analysis (CA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Bootstrap]]` | wiki | categorie | domaines:data-science | tags:concept+stats |

### `Wiki/Concepts/Mixture of Experts.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Positional encoding]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+transformer+llm |
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:ml-eng+ai-eng | tags:concept |
| 22 | `[[State Space Models|State Space Models (SSM)]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+llm |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 16 | `[[Decoding strategies]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[PEFT|PEFT (LoRA, QLoRA, DoRA)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |

### `Wiki/Concepts/mcp-protocol.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Tool use patterns]]` | wiki | alias-partial | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents | mots:mcp |
| 22 | `[[tool-use|Tool Use]]` | wiki | categorie | domaines:ai-eng | souscat:tools+agents | tags:concept |
| 21 | `[[agent-loops|Agent loops]]` | wiki | categorie | domaines:ai-eng | souscat:agents | tags:concept+agents |
| 16 | `[[prompt-caching|Prompt Caching]]` | wiki | categorie | domaines:ai-eng | tags:concept |
| 16 | `[[RAG]]` | wiki | categorie | domaines:ai-eng | tags:concept |
| 16 | `[[embeddings]]` | wiki | categorie | domaines:ai-eng | tags:concept |
| 15 | `[[Agent memory]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents |
| 15 | `[[Agent evaluation]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents |

### `Wiki/Concepts/MCMC.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 28 | `[[Decoding strategies]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | souscat:sampling | tags:concept+sampling | mots:sampling |
| 27 | `[[Concentration inequalities]]` | wiki | alias-partial | categorie | domaines:ml-eng | tags:concept+probability | mots:markov |
| 26 | `[[Brownian motion]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+probability |
| 22 | `[[Poisson process]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+probability |
| 22 | `[[Central limit theorem]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+probability |
| 22 | `[[Missing data]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 20 | `[[Bayesian inference]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept+bayesian |

### `Wiki/Concepts/Missing data.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[ROC AUC]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Regularization]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[K-means]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Clustering evaluation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[GMM|Gaussian Mixture Models (GMM)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Ensembling]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[DBSCAN]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/MFA.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[CA|Correspondence Analysis (CA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats+factor-analysis | mots:analysis+analyse+factorielle |
| 23 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 23 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats+factor-analysis |
| 19 | `[[Multiple testing correction]]` | wiki | categorie | domaines:data-science | tags:concept+stats | mots:multiple |
| 18 | `[[t-test and ANOVA]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Hypothesis testing]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Chi-squared tests]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Confidence intervals]]` | wiki | categorie | domaines:data-science | tags:concept+stats |

### `Wiki/Concepts/Newton & quasi-Newton.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[Learning rate schedules]]` | wiki | categorie | domaines:ml-eng | tags:concept+optimization |
| 14 | `[[Missing data]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Maximum likelihood estimation|Maximum likelihood estimation (MLE)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Mutual information]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Multi-armed bandits]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[PCA|Principal Component Analysis (PCA)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Positional encoding.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Mixture of Experts|Mixture of Experts (MoE)]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+transformer+llm |
| 22 | `[[State Space Models|State Space Models (SSM)]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+llm |
| 19 | `[[Feature engineering]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept | mots:encoding |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 16 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[Distillation|Knowledge distillation]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[Inference optimization]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |

### `Wiki/Concepts/Poisson process.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+probability |
| 22 | `[[ROC AUC]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 18 | `[[Concentration inequalities]]` | wiki | categorie | domaines:ml-eng | tags:concept+probability |
| 15 | `[[Data drift]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept | mots:distribution |
| 14 | `[[PCA|Principal Component Analysis (PCA)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Multi-armed bandits]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Newton & quasi-Newton|Newton & quasi-Newton (BFGS, L-BFGS)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Mutual information]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Prompt engineering.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 34 | `[[Agent patterns]]` | wiki | alias-exact | cat-top | domaines:ai-eng | souscat:react+llm | tags:concept+llm | mots:react |
| 21 | `[[Speculative decoding]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 21 | `[[Decoding strategies]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 18 | `[[Inference optimization]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 16 | `[[Synthetic data generation]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:self |
| 15 | `[[PEFT|PEFT (LoRA, QLoRA, DoRA)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Scaling laws]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/Projections.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+linalg |
| 18 | `[[PAC learning]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 14 | `[[Maximum likelihood estimation|Maximum likelihood estimation (MLE)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Multi-armed bandits]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Missing data]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Markov chains]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Jensen-Shannon divergence]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/PGA.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Confidence intervals]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | tags:concept+stats |
| 26 | `[[MCA|Multiple Correspondence Analysis (MCA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis+dimensionality-reduction | tags:concept+stats | mots:analysis+analyse |
| 23 | `[[CA|Correspondence Analysis (CA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 23 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:principal+principales |
| 23 | `[[FAMD|Factor Analysis of Mixed Data (FAMD)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 23 | `[[MFA|Multiple Factor Analysis (MFA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 22 | `[[Bootstrap]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+stats |
| 20 | `[[t-SNE and UMAP]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:dimensionality-reduction+manifold | tags:concept |

### `Wiki/Concepts/PCA.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 33 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:factor-analysis+dimensionality-reduction | tags:concept+stats | mots:principal+analysis+analyse+en+principales |
| 30 | `[[Confidence intervals]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | tags:concept+stats |
| 26 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats+factor-analysis | mots:principal+composantes+principales |
| 23 | `[[GPA|Generalized Procrustes Analysis (GPA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 22 | `[[Bootstrap]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+stats |
| 18 | `[[Chi-squared tests]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Multiple testing correction]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[SVD|SVD (Singular Value Decomposition)]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:svd | tags:concept | mots:en |

### `Wiki/Concepts/PAC learning.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 31 | `[[Generalization bounds]]` | wiki | alias-partial | categorie | domaines:ml-eng | souscat:generalization | tags:concept+learning-theory | mots:pac+bayes |
| 19 | `[[Bayesian inference]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept | mots:bayes |
| 18 | `[[Projections]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[State Space Models|State Space Models (SSM)]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 14 | `[[Autocorrelation|Autocorrelation (ACF, PACF)]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[LLM benchmarks]]` | wiki | alias-partial | cat-top | tags:concept |

### `Wiki/Concepts/Perplexity.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 32 | `[[LLM eval metrics]]` | wiki | alias-exact | cat-top | domaines:ai-eng+ml-eng | souscat:evaluation | tags:concept |
| 22 | `[[Mutual information]]` | wiki | categorie | domaines:ml-eng+ai-eng | tags:concept+info-theory |
| 22 | `[[Jensen-Shannon divergence]]` | wiki | categorie | domaines:ml-eng+ai-eng | tags:concept+info-theory |
| 22 | `[[KL divergence]]` | wiki | categorie | domaines:ml-eng+ai-eng | tags:concept+info-theory |
| 22 | `[[Wasserstein distance]]` | wiki | categorie | domaines:ml-eng+ai-eng | tags:concept+info-theory |
| 22 | `[[AI security]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | tags:concept |
| 18 | `[[DBSCAN]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 17 | `[[Ranking metrics]]` | wiki | cat-top | domaines:ml-eng+ai-eng | souscat:evaluation | tags:concept |

### `Wiki/Concepts/PEFT.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 25 | `[[Distillation|Knowledge distillation]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[Synthetic data generation]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[Scaling laws]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Tokenization]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Decoding strategies]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/Speculative decoding.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:inference+llm | tags:concept+llm+inference+optimization |
| 23 | `[[Context engineering]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm+inference |
| 22 | `[[Structured outputs]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:decoding |
| 21 | `[[Chain-of-Thought|Chain-of-Thought (CoT)]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 21 | `[[Prompt engineering]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 20 | `[[Synthetic data generation]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm | mots:model |
| 19 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[PEFT|PEFT (LoRA, QLoRA, DoRA)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |

### `Wiki/Outils/Claude-Code/claude-review.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 35 | `[[claude-security-review|security-review]]` | wiki | alias-partial | categorie | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code | mots:review |
| 33 | `[[claude-simplify|simplify]]` | wiki | categorie | domaines:data-eng+mlops+ml-eng+ai-eng | souscat:code-review | tags:skill+claude-code |
| 25 | `[[mcp-github]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | souscat:github | tags:github |
| 24 | `[[claude-update-config|update-config]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:skill+claude-code |
| 24 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:skill+claude-code |
| 24 | `[[claude-init|init]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:skill+claude-code |
| 22 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:skill |
| 20 | `[[uv]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng |

### `Wiki/Outils/Claude-Code/claude-loop.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[claude-update-config|update-config]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 26 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 26 | `[[claude-init|init]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 22 | `[[mcp-filesystem]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng |
| 22 | `[[mcp-github]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng |
| 22 | `[[uv]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng |
| 20 | `[[claude-simplify|simplify]]` | wiki | cat-top | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 20 | `[[claude-review|review]]` | wiki | cat-top | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |

### `Wiki/Outils/Claude-Code/claude-security-review.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[claude-simplify|simplify]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 20 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | cat-top | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 20 | `[[claude-init|init]]` | wiki | cat-top | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 20 | `[[claude-schedule|schedule]]` | wiki | cat-top | domaines:mlops+ai-eng+data-eng | tags:skill+claude-code |
| 20 | `[[claude-loop|loop]]` | wiki | cat-top | domaines:mlops+ai-eng+data-eng | tags:skill+claude-code |
| 20 | `[[claude-update-config|update-config]]` | wiki | cat-top | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 18 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:data-eng+mlops+ai-eng | tags:skill |
| 16 | `[[mcp-filesystem]]` | wiki | cat-top | domaines:data-eng+mlops+ai-eng |

### `Wiki/Outils/Claude-Code/claude-schedule.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[claude-update-config|update-config]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 26 | `[[claude-init|init]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 26 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 22 | `[[uv]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng |
| 22 | `[[mcp-github]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng |
| 22 | `[[mcp-filesystem]]` | wiki | categorie | domaines:data-eng+mlops+ai-eng |
| 20 | `[[claude-security-review|security-review]]` | wiki | cat-top | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |
| 20 | `[[claude-review|review]]` | wiki | cat-top | domaines:data-eng+mlops+ai-eng | tags:skill+claude-code |

### `Wiki/Outils/Claude-Code/claude-init.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 34 | `[[claude-update-config|update-config]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng | tags:skill+claude-code |
| 34 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng | tags:skill+claude-code |
| 30 | `[[uv]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 30 | `[[mcp-filesystem]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 26 | `[[claude-schedule|schedule]]` | wiki | categorie | domaines:mlops+ai-eng+data-eng | tags:skill+claude-code |
| 26 | `[[mcp-github]]` | wiki | categorie | domaines:data-eng+mlops+ml-eng+ai-eng |
| 26 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng | tags:skill |
| 26 | `[[claude-loop|loop]]` | wiki | categorie | domaines:mlops+ai-eng+data-eng | tags:skill+claude-code |

### `Wiki/Outils/Claude-Code/anthropic-xlsx.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[anthropic-pdf|anthropic-skills:pdf]]` | wiki | categorie | domaines:data-science | tags:skill+claude-code+documents | mots:anthropic |
| 20 | `[[claude-update-config|update-config]]` | wiki | cat-top | domaines:data-science+data-eng+mlops | tags:skill+claude-code |
| 20 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | cat-top | domaines:data-science+data-eng+mlops | tags:skill+claude-code |
| 20 | `[[claude-init|init]]` | wiki | cat-top | domaines:data-science+data-eng+mlops | tags:skill+claude-code |
| 18 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:data-science+data-eng+mlops | tags:skill |
| 18 | `[[mcp-postgres]]` | wiki | cat-top | domaines:data-science+data-eng+mlops | tags:data |
| 17 | `[[anthropic-pptx|anthropic-skills:pptx]]` | wiki | categorie | tags:skill+claude-code+documents | mots:anthropic |
| 17 | `[[anthropic-docx|anthropic-skills:docx]]` | wiki | categorie | tags:skill+claude-code+documents | mots:anthropic |

### `Wiki/Outils/Claude-Code/anthropic-skill-creator.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[anthropic-consolidate-memory|anthropic-skills:consolidate-memory]]` | wiki | categorie | domaines:ai-eng | tags:skill+claude-code+meta | mots:anthropic |
| 17 | `[[anthropic-pptx|anthropic-skills:pptx]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:skill+claude-code | mots:anthropic |
| 17 | `[[anthropic-pdf|anthropic-skills:pdf]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:skill+claude-code | mots:anthropic |
| 16 | `[[claude-init|init]]` | wiki | cat-top | domaines:ml-eng+ai-eng | tags:skill+claude-code |
| 16 | `[[claude-update-config|update-config]]` | wiki | cat-top | domaines:ml-eng+ai-eng | tags:skill+claude-code |
| 16 | `[[claude-simplify|simplify]]` | wiki | cat-top | domaines:ml-eng+ai-eng | tags:skill+claude-code |
| 16 | `[[claude-review|review]]` | wiki | cat-top | domaines:ml-eng+ai-eng | tags:skill+claude-code |
| 16 | `[[claude-api]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:skill+claude-code |

### `Wiki/Outils/Claude-Code/claude-fewer-permission-prompts.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 34 | `[[claude-init|init]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng | tags:skill+claude-code |
| 30 | `[[mcp-filesystem]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 30 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng+doc | tags:skill |
| 30 | `[[uv]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 28 | `[[mcp-obsidian]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng+doc |
| 26 | `[[mcp-github]]` | wiki | categorie | domaines:data-eng+mlops+ml-eng+ai-eng |
| 26 | `[[claude-schedule|schedule]]` | wiki | categorie | domaines:mlops+ai-eng+data-eng | tags:skill+claude-code |
| 26 | `[[claude-loop|loop]]` | wiki | categorie | domaines:mlops+ai-eng+data-eng | tags:skill+claude-code |

### `Wiki/Outils/Claude-Code/claude-api.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Anthropic Claude API]]` | dev | alias-exact | souscat:api | tags:llm+api | mots:claude+api |
| 22 | `[[claude-update-config|update-config]]` | wiki | categorie | domaines:ml-eng+ai-eng | tags:skill+claude-code |
| 22 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | categorie | domaines:ml-eng+ai-eng | tags:skill+claude-code |
| 22 | `[[claude-init|init]]` | wiki | categorie | domaines:ml-eng+ai-eng | tags:skill+claude-code |
| 18 | `[[mcp-github]]` | wiki | categorie | domaines:ml-eng+ai-eng |
| 18 | `[[claude-loop|loop]]` | wiki | categorie | domaines:ai-eng | tags:skill+claude-code |
| 18 | `[[mcp-filesystem]]` | wiki | categorie | domaines:ml-eng+ai-eng |
| 18 | `[[uv]]` | wiki | categorie | domaines:ml-eng+ai-eng |

### `Wiki/Outils/Claude-Code/claude-simplify.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[claude-update-config|update-config]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:skill+claude-code |
| 24 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:skill+claude-code |
| 24 | `[[claude-init|init]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:skill+claude-code |
| 22 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:skill |
| 20 | `[[claude-schedule|schedule]]` | wiki | cat-top | domaines:mlops+ai-eng+data-eng | tags:skill+claude-code |
| 20 | `[[mcp-github]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng |
| 20 | `[[mcp-obsidian]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng |
| 20 | `[[uv]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng |

### `Wiki/Outils/Obsidian/kepano-defuddle.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[mcp-obsidian]]` | wiki | categorie | domaines:data-science+ai-eng+doc | tags:obsidian |
| 18 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | cat-top | domaines:data-science+ai-eng+doc | tags:skill |
| 14 | `[[anthropic-pptx|anthropic-skills:pptx]]` | wiki | cat-top | domaines:doc+ai-eng | tags:skill |
| 14 | `[[claude-update-config|update-config]]` | wiki | cat-top | domaines:data-science+ai-eng | tags:skill |
| 14 | `[[claude-init|init]]` | wiki | cat-top | domaines:data-science+ai-eng | tags:skill |
| 12 | `[[uv]]` | wiki | cat-top | domaines:data-science+ai-eng |
| 12 | `[[mcp-obsidian - reference outils|mcp-obsidian — référence outils]]` | wiki | categorie | tags:obsidian |
| 12 | `[[mcp-filesystem]]` | wiki | cat-top | domaines:data-science+ai-eng |

### `Wiki/Outils/MCP-Servers/mcp-postgres.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 19 | `[[mcp-obsidian]]` | wiki | cat-top | domaines:data-science+data-eng+mlops | tags:mcp | mots:mcp |
| 19 | `[[mcp-filesystem]]` | wiki | cat-top | domaines:data-science+data-eng+mlops | tags:mcp | mots:mcp |
| 18 | `[[anthropic-xlsx|anthropic-skills:xlsx]]` | wiki | cat-top | domaines:data-science+data-eng+mlops | tags:data |
| 16 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:data-science+data-eng+mlops |
| 16 | `[[claude-update-config|update-config]]` | wiki | cat-top | domaines:data-science+data-eng+mlops |
| 16 | `[[uv]]` | wiki | cat-top | domaines:data-science+data-eng+mlops |
| 16 | `[[claude-init|init]]` | wiki | cat-top | domaines:data-science+data-eng+mlops |
| 16 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | cat-top | domaines:data-science+data-eng+mlops |

### `Wiki/Workflows/Evaluer un modele forecast.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Forecasting metrics]]` | wiki | domaines:data-science+ml-eng | souscat:metrics+forecasting+time-series | tags:forecasting+time-series | mots:forecast |
| 18 | `[[Intermittent demand]]` | wiki | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:time-series+forecasting |
| 18 | `[[Hierarchical forecasting]]` | wiki | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:time-series+forecasting |
| 18 | `[[Exponential smoothing|Exponential smoothing (ETS)]]` | wiki | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:time-series+forecasting |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:time-series+forecasting |
| 16 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | alias-partial | domaines:data-science+ml-eng |
| 13 | `[[Time series anomaly detection]]` | wiki | domaines:data-science+ml-eng | souscat:time-series | tags:time-series |
| 13 | `[[Time series feature engineering]]` | wiki | domaines:data-science+ml-eng | souscat:time-series | tags:time-series |

### `Wiki/Outils/Obsidian/kepano-obsidian-skills.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 40 | `[[mcp-obsidian]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng+doc | souscat:obsidian | tags:obsidian | mots:obsidian |
| 30 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng+doc | tags:skill |
| 27 | `[[kepano-defuddle|kepano/defuddle]]` | wiki | categorie | domaines:data-science+ai-eng+doc | tags:skill+obsidian | mots:kepano |
| 26 | `[[claude-init|init]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng | tags:skill |
| 26 | `[[claude-update-config|update-config]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng | tags:skill |
| 24 | `[[mcp-filesystem]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 24 | `[[uv]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 22 | `[[claude-simplify|simplify]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:skill |

### `Wiki/Outils/MCP-Servers/mcp-obsidian.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 40 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng+doc | souscat:obsidian | tags:obsidian | mots:obsidian |
| 28 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng+doc |
| 27 | `[[mcp-obsidian - reference outils|mcp-obsidian — référence outils]]` | wiki | alias-partial | categorie | souscat:obsidian | tags:mcp+obsidian | mots:mcp+obsidian |
| 24 | `[[uv]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 24 | `[[claude-update-config|update-config]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 24 | `[[claude-init|init]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 24 | `[[kepano-defuddle|kepano/defuddle]]` | wiki | categorie | domaines:data-science+ai-eng+doc | tags:obsidian |
| 23 | `[[mcp-github]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:mcp | mots:mcp |

### `Wiki/Outils/CLI-Tools/uv.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[mcp-filesystem]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 30 | `[[claude-init|init]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 30 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 30 | `[[claude-update-config|update-config]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 26 | `[[mcp-github]]` | wiki | categorie | domaines:data-eng+mlops+ml-eng+ai-eng |
| 25 | `[[uv]]` | dev | alias-exact | souscat:package-manager+python | tags:python+package-manager |
| 24 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 24 | `[[mcp-obsidian]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |

### `Wiki/Outils/Claude-Code/claude-update-config.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 34 | `[[claude-init|init]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng | tags:skill+claude-code |
| 30 | `[[mcp-filesystem]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 30 | `[[uv]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 26 | `[[mcp-github]]` | wiki | categorie | domaines:data-eng+mlops+ml-eng+ai-eng |
| 26 | `[[claude-schedule|schedule]]` | wiki | categorie | domaines:mlops+ai-eng+data-eng | tags:skill+claude-code |
| 26 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng | tags:skill |
| 26 | `[[claude-loop|loop]]` | wiki | categorie | domaines:mlops+ai-eng+data-eng | tags:skill+claude-code |
| 24 | `[[claude-review|review]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:skill+claude-code |

### `Wiki/Outils/MCP-Servers/mcp-github.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 31 | `[[mcp-filesystem]]` | wiki | categorie | domaines:data-eng+mlops+ml-eng+ai-eng | tags:mcp+dev-flow | mots:mcp |
| 26 | `[[uv]]` | wiki | categorie | domaines:data-eng+mlops+ml-eng+ai-eng |
| 26 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | categorie | domaines:data-eng+mlops+ml-eng+ai-eng |
| 26 | `[[claude-init|init]]` | wiki | categorie | domaines:data-eng+mlops+ml-eng+ai-eng |
| 26 | `[[claude-update-config|update-config]]` | wiki | categorie | domaines:data-eng+mlops+ml-eng+ai-eng |
| 25 | `[[claude-review|review]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | souscat:github | tags:github |
| 23 | `[[mcp-obsidian]]` | wiki | cat-top | domaines:data-eng+mlops+ml-eng+ai-eng | tags:mcp | mots:mcp |
| 22 | `[[claude-loop|loop]]` | wiki | categorie | domaines:mlops+ai-eng+data-eng |

### `Wiki/Outils/MCP-Servers/mcp-filesystem.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 31 | `[[mcp-github]]` | wiki | categorie | domaines:data-eng+mlops+ml-eng+ai-eng | tags:mcp+dev-flow | mots:mcp |
| 30 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 30 | `[[claude-update-config|update-config]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 30 | `[[uv]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 30 | `[[claude-init|init]]` | wiki | categorie | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 27 | `[[mcp-obsidian]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng | tags:mcp | mots:mcp |
| 24 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:data-science+data-eng+mlops+ml-eng+ai-eng |
| 22 | `[[claude-schedule|schedule]]` | wiki | categorie | domaines:mlops+ai-eng+data-eng |

### `Wiki/Concepts/t-test and ANOVA.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[MFA|Multiple Factor Analysis (MFA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[MCA|Multiple Correspondence Analysis (MCA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[PCA|Principal Component Analysis (PCA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[FAMD|Factor Analysis of Mixed Data (FAMD)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[CA|Correspondence Analysis (CA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[GPA|Generalized Procrustes Analysis (GPA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |

### `Wiki/Concepts/t-SNE and UMAP.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[Ranking metrics]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 22 | `[[MAP estimation]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Clustering evaluation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Ensembling]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Imbalanced classification]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Regularization]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[ROC AUC]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Cross-validation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/Time series feature engineering.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 28 | `[[Time series anomaly detection]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series | mots:time+series+ts |
| 25 | `[[Hierarchical forecasting]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 25 | `[[Exponential smoothing|Exponential smoothing (ETS)]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 25 | `[[Intermittent demand]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 19 | `[[Imbalanced classification]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:ml | tags:concept+ml |
| 19 | `[[Missing data]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:ml | tags:concept+ml |
| 18 | `[[CA|Correspondence Analysis (CA)]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |
| 16 | `[[Cross-validation]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/Time series anomaly detection.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 27 | `[[Walk-forward CV]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series | mots:time+series |
| 25 | `[[Hierarchical forecasting]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 25 | `[[Intermittent demand]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 25 | `[[Exponential smoothing|Exponential smoothing (ETS)]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 24 | `[[Forecasting framing]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+time-series | mots:time+series |
| 19 | `[[Forecasting metrics]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 17 | `[[DBSCAN]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:outlier | tags:concept |
| 14 | `[[Multi-armed bandits]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Synthetic data generation.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 25 | `[[PEFT|PEFT (LoRA, QLoRA, DoRA)]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[Quantization|Quantization (LLM)]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 20 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm | mots:model |
| 19 | `[[Tokenization]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Decoding strategies]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 18 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |

### `Wiki/Concepts/Stationarity.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | categorie | domaines:data-science | tags:concept+time-series |
| 18 | `[[Hierarchical forecasting]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 18 | `[[Intermittent demand]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 18 | `[[Time series anomaly detection]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 18 | `[[Clustering evaluation]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |
| 18 | `[[Exponential smoothing|Exponential smoothing (ETS)]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 18 | `[[Time series feature engineering]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 12 | `[[Forecasting metrics]]` | wiki | cat-top | domaines:data-science | tags:concept+time-series |

### `Wiki/Concepts/State Space Models.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Mixture of Experts|Mixture of Experts (MoE)]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+llm |
| 22 | `[[Positional encoding]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+llm |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[PAC learning]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 16 | `[[Decoding strategies]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[embeddings]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[Distillation|Knowledge distillation]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |

### `Wiki/Concepts/SVD.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+linalg |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Projections]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+linalg |
| 18 | `[[Ranking metrics]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Cross-entropy]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[embeddings]]` | wiki | cat-top | domaines:ai-eng+ml-eng+data-science | tags:concept |
| 18 | `[[Shannon entropy]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Markov chains]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |

### `Wiki/Concepts/Structured outputs.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Tool use patterns]]` | wiki | alias-exact | cat-top | domaines:ai-eng | souscat:function-calling | tags:concept | mots:function+calling |
| 22 | `[[Speculative decoding]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:decoding |
| 21 | `[[Chain-of-Thought|Chain-of-Thought (CoT)]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 21 | `[[Context engineering]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 18 | `[[Inference optimization]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 17 | `[[Instructor]]` | dev | alias-exact | tags:llm |
| 15 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/Tokenization.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 27 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 21 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm+nlp |
| 19 | `[[Scaling laws]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Distillation|Knowledge distillation]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[SFT|SFT (Supervised Fine-Tuning)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Decoding strategies]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |

### `Wiki/Outils/Claude-Code/anthropic-consolidate-memory.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[anthropic-skill-creator|anthropic-skills:skill-creator]]` | wiki | categorie | domaines:ai-eng | tags:skill+claude-code+meta | mots:anthropic |
| 18 | `[[Agent memory]]` | wiki | alias-partial | domaines:ai-eng | souscat:memory | tags:memory | mots:memory |
| 15 | `[[claude-simplify|simplify]]` | wiki | cat-top | domaines:ai-eng | souscat:refactor | tags:skill+claude-code |
| 15 | `[[claude-init|init]]` | wiki | cat-top | domaines:ai-eng | souscat:claude-md | tags:skill+claude-code |
| 13 | `[[anthropic-pdf|anthropic-skills:pdf]]` | wiki | cat-top | domaines:ai-eng | tags:skill+claude-code | mots:anthropic |
| 13 | `[[anthropic-pptx|anthropic-skills:pptx]]` | wiki | cat-top | domaines:ai-eng | tags:skill+claude-code | mots:anthropic |
| 12 | `[[claude-schedule|schedule]]` | wiki | cat-top | domaines:ai-eng | tags:skill+claude-code |
| 12 | `[[claude-security-review|security-review]]` | wiki | cat-top | domaines:ai-eng | tags:skill+claude-code |

### `Wiki/Concepts/Wasserstein distance.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[Mutual information]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+info-theory |
| 26 | `[[Cross-entropy]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+info-theory |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Perplexity]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+info-theory |
| 18 | `[[Ranking metrics]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[t-SNE and UMAP]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Gradient descent|Gradient descent and variants]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[SVD|SVD (Singular Value Decomposition)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |

### `Wiki/Outils/Claude-Code/anthropic-pptx.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 29 | `[[anthropic-pdf|anthropic-skills:pdf]]` | wiki | categorie | domaines:ai-eng+ml-eng+doc | tags:skill+claude-code+documents | mots:anthropic |
| 21 | `[[anthropic-docx|anthropic-skills:docx]]` | wiki | categorie | domaines:doc | tags:skill+claude-code+documents | mots:anthropic |
| 20 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | cat-top | domaines:ml-eng+ai-eng+doc | tags:skill+claude-code |
| 18 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:ml-eng+ai-eng+doc | tags:skill |
| 17 | `[[anthropic-xlsx|anthropic-skills:xlsx]]` | wiki | categorie | tags:skill+claude-code+documents | mots:anthropic |
| 17 | `[[anthropic-skill-creator|anthropic-skills:skill-creator]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:skill+claude-code | mots:anthropic |
| 16 | `[[claude-simplify|simplify]]` | wiki | cat-top | domaines:ml-eng+ai-eng | tags:skill+claude-code |
| 16 | `[[claude-review|review]]` | wiki | cat-top | domaines:ml-eng+ai-eng | tags:skill+claude-code |

### `Wiki/Outils/Claude-Code/anthropic-pdf.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 29 | `[[anthropic-pptx|anthropic-skills:pptx]]` | wiki | categorie | domaines:doc+ai-eng+ml-eng | tags:skill+claude-code+documents | mots:anthropic |
| 24 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng+doc | tags:skill+claude-code |
| 22 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng+doc | tags:skill |
| 21 | `[[anthropic-docx|anthropic-skills:docx]]` | wiki | categorie | domaines:doc | tags:skill+claude-code+documents | mots:anthropic |
| 21 | `[[anthropic-xlsx|anthropic-skills:xlsx]]` | wiki | categorie | domaines:data-science | tags:skill+claude-code+documents | mots:anthropic |
| 20 | `[[claude-update-config|update-config]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:skill+claude-code |
| 20 | `[[claude-init|init]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:skill+claude-code |
| 20 | `[[mcp-obsidian]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng+doc |

### `Wiki/Concepts/Walk-forward CV.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 36 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series |
| 31 | `[[Cross-validation]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng+mlops | tags:concept+validation | mots:cross+validation+cv |
| 28 | `[[Exponential smoothing|Exponential smoothing (ETS)]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series |
| 28 | `[[Time series feature engineering]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series | mots:time+series+rolling |
| 28 | `[[Intermittent demand]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series |
| 28 | `[[Hierarchical forecasting]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series |
| 27 | `[[Time series anomaly detection]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series | mots:time+series |
| 23 | `[[Evaluer un modele forecast]]` | wiki | domaines:data-science+ml-eng+mlops | souscat:forecasting+time-series+backtest | tags:time-series |

### `Wiki/Concepts/Transformer architectures.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Distillation|Knowledge distillation]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 24 | `[[LLM eval metrics]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 24 | `[[Quantization|Quantization (LLM)]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 21 | `[[Vision Language Models|Vision Language Models (VLM)]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept+llm | mots:gpt |
| 20 | `[[LLM caching]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept+llm |
| 20 | `[[Agent memory]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept+llm |
| 18 | `[[Reranking]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |

### `Wiki/Concepts/tool-use.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Tool use patterns]]` | wiki | alias-partial | cat-top | domaines:ai-eng | souscat:function-calling+agents | tags:concept+tool-use+function-calling | mots:tool+use |
| 18 | `[[prompt-caching|Prompt Caching]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 18 | `[[RAG]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 18 | `[[embeddings]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 15 | `[[Structured outputs]]` | wiki | cat-top | domaines:ai-eng | souscat:function-calling | tags:concept+llm |
| 15 | `[[Agent memory]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+llm |
| 15 | `[[Multi-agent systems]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+llm |
| 15 | `[[Agent patterns]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+llm |

### `Wiki/Concepts/Vision Language Models.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[Video generation]]` | wiki | categorie | domaines:ai-eng | souscat:multimodal | tags:concept+multimodal |
| 18 | `[[Image generation]]` | wiki | categorie | domaines:ai-eng | tags:concept+multimodal |
| 18 | `[[Small Language Models|Small Language Models (SLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:language+models+llm |
| 16 | `[[Reasoning models]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:models |
| 16 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |
| 16 | `[[LLM-as-judge]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |
| 16 | `[[LLM benchmarks]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |
| 16 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |

### `Wiki/Concepts/Vector norms.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Projections]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+linalg |
| 22 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+linalg |
| 22 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+linalg |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 16 | `[[claude-init|init]]` | wiki | alias-partial | domaines:data-science+ml-eng |
| 14 | `[[Multi-armed bandits]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Missing data]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Jensen-Shannon divergence]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Context engineering.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 34 | `[[LLM caching]]` | wiki | alias-exact | cat-top | domaines:ai-eng | souscat:caching | tags:concept+llm+caching | mots:caching+prompt |
| 23 | `[[Speculative decoding]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm+inference |
| 23 | `[[Decoding strategies]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm+inference |
| 21 | `[[Inference optimization]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm+inference | mots:caching |
| 21 | `[[Structured outputs]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 21 | `[[Chain-of-Thought|Chain-of-Thought (CoT)]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 18 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 17 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm+inference |

### `Wiki/Concepts/Confidence intervals.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[PCA|Principal Component Analysis (PCA)]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | tags:concept+stats |
| 30 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | tags:concept+stats |
| 26 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | alias-partial | categorie | domaines:data-science | tags:concept+stats |
| 22 | `[[Calibration]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Regularization]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Hierarchical forecasting]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Classification metrics]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Clustering evaluation]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Cross-entropy.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 34 | `[[Classification metrics]]` | wiki | alias-exact | cat-top | domaines:data-science+ml-eng | souscat:classification | tags:concept | mots:log+loss |
| 26 | `[[Jensen-Shannon divergence]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+info-theory |
| 26 | `[[Mutual information]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+info-theory |
| 26 | `[[Wasserstein distance]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+info-theory |
| 24 | `[[Maximum likelihood estimation|Maximum likelihood estimation (MLE)]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept | mots:likelihood+log |
| 18 | `[[Ranking metrics]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[embeddings]]` | wiki | cat-top | domaines:ai-eng+ml-eng+data-science | tags:concept |
| 18 | `[[Gradient descent|Gradient descent and variants]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |

### `Wiki/Concepts/Convexity.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[Learning rate schedules]]` | wiki | categorie | domaines:ml-eng | tags:concept+optimization |
| 18 | `[[Adam optimizer|Adam optimizer (et famille)]]` | wiki | categorie | domaines:ml-eng | tags:concept+optimization |
| 14 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Maximum likelihood estimation|Maximum likelihood estimation (MLE)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Mutual information]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Multi-armed bandits]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Missing data]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Concentration inequalities.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 27 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | alias-partial | categorie | domaines:ml-eng | tags:concept+probability | mots:markov |
| 27 | `[[Markov chains]]` | wiki | alias-partial | categorie | domaines:ml-eng | tags:concept+probability | mots:markov |
| 19 | `[[Jensen-Shannon divergence]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept | mots:jensen |
| 18 | `[[Poisson process]]` | wiki | categorie | domaines:ml-eng | tags:concept+probability |
| 18 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[Missing data]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[Brownian motion]]` | wiki | categorie | domaines:ml-eng | tags:concept+probability |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |

### `Wiki/Concepts/Classification metrics.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 39 | `[[Forecasting metrics]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics+loss+accuracy |
| 38 | `[[Ranking metrics]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics+recall |
| 34 | `[[Cross-entropy]]` | wiki | alias-exact | cat-top | domaines:data-science+ml-eng | souscat:classification | tags:concept | mots:log+loss |
| 25 | `[[LLM eval metrics]]` | wiki | categorie | domaines:ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics |
| 23 | `[[Clustering evaluation]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:evaluation+metrics | tags:concept+metrics | mots:metrics |
| 22 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 18 | `[[CA|Correspondence Analysis (CA)]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |

### `Wiki/Concepts/Chunking strategies.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 23 | `[[Query transformations]]` | wiki | categorie | domaines:ai-eng | souscat:rag | tags:concept+rag+llm |
| 17 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng | souscat:rag | tags:concept+llm+rag |
| 17 | `[[RAG eval|RAG evaluation]]` | wiki | cat-top | domaines:ai-eng | souscat:rag | tags:concept+rag+llm |
| 15 | `[[Ranking metrics]]` | wiki | cat-top | domaines:ai-eng | souscat:retrieval | tags:concept+rag |
| 14 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | tags:concept |
| 13 | `[[Decoding strategies]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:strategies |
| 13 | `[[LLM caching]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:semantic |

### `Wiki/Concepts/Code and math benchmarks.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 23 | `[[RAG eval|RAG evaluation]]` | wiki | categorie | domaines:ai-eng | souscat:llm-eval | tags:concept+eval+llm |
| 21 | `[[LLM-as-judge]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm+eval | mots:bench |
| 15 | `[[Chain-of-Thought|Chain-of-Thought (CoT)]]` | wiki | cat-top | domaines:ai-eng | souscat:reasoning | tags:concept+llm |
| 15 | `[[Prompt engineering]]` | wiki | cat-top | domaines:ai-eng | souscat:reasoning | tags:concept+llm |
| 14 | `[[Missing data]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | tags:concept |
| 12 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm |
| 12 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm |

### `Wiki/Concepts/Clustering evaluation.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Regularization]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 30 | `[[Bias-variance tradeoff]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 30 | `[[ROC AUC]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+ml+metrics |
| 25 | `[[Cross-validation]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:validation | tags:concept+ml |
| 24 | `[[Regression metrics]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics+evaluation |
| 23 | `[[Forecasting metrics]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics |
| 23 | `[[Ranking metrics]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics |
| 23 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept | mots:nmi |

### `Wiki/Concepts/Cross-validation.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 25 | `[[Clustering evaluation]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:validation | tags:concept+ml |
| 22 | `[[Feature engineering]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Regularization]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Ensembling]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[GMM|Gaussian Mixture Models (GMM)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Missing data]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Imbalanced classification]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Calibration]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/Distillation.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 25 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[Scaling laws]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[PEFT|PEFT (LoRA, QLoRA, DoRA)]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 25 | `[[Quantization|Quantization (LLM)]]` | wiki | categorie | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 24 | `[[Transformer architectures]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 19 | `[[Decoding strategies]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |
| 19 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/Diffusion models.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Vision Language Models|Vision Language Models (VLM)]]` | wiki | categorie | domaines:ai-eng | souscat:multimodal | tags:concept+multimodal | mots:models |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[Jailbreaking and defenses|Jailbreaking & defenses]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 15 | `[[State Space Models|State Space Models (SSM)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept | mots:models |
| 14 | `[[Perplexity]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept |
| 14 | `[[Scaling laws]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept |
| 14 | `[[Self-attention]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept |
| 14 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept |

### `Wiki/Concepts/embeddings.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[Ranking metrics]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | souscat:retrieval | tags:concept |
| 18 | `[[Wasserstein distance]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[SVD|SVD (Singular Value Decomposition)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Brownian motion]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[t-SNE and UMAP]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Mutual information]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Cross-entropy]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[prompt-caching|Prompt Caching]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |

### `Wiki/Concepts/Eigendecomposition.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+linalg |
| 22 | `[[Projections]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+linalg |
| 14 | `[[Maximum likelihood estimation|Maximum likelihood estimation (MLE)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Mutual information]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Missing data]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Multi-armed bandits]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Jensen-Shannon divergence]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Decoding strategies.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 28 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | alias-partial | cat-top | domaines:ml-eng+ai-eng | souscat:sampling | tags:concept+sampling | mots:sampling |
| 24 | `[[Inference optimization]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+llm+inference |
| 23 | `[[Context engineering]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm+inference |
| 21 | `[[Chain-of-Thought|Chain-of-Thought (CoT)]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 21 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm+inference |
| 21 | `[[Imbalanced classification]]` | wiki | alias-partial | cat-top | domaines:ml-eng | souscat:sampling | tags:concept |
| 20 | `[[Multi-armed bandits]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept | mots:sampling+greedy |
| 19 | `[[Distillation|Knowledge distillation]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/Data drift.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 25 | `[[Time series anomaly detection]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept+monitoring | mots:drift |
| 22 | `[[Clustering evaluation]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Multi-armed bandits]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 16 | `[[LLM observability]]` | wiki | cat-top | souscat:monitoring+production | tags:concept+production+monitoring |
| 15 | `[[Missing data]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept | mots:data |
| 15 | `[[Poisson process]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept | mots:distribution |
| 15 | `[[Markov chains]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept | mots:distribution |

### `Wiki/Concepts/CUPED.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[MAP estimation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[Maximum likelihood estimation|Maximum likelihood estimation (MLE)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[Clustering evaluation]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Bayesian inference]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Mutual information]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Newton & quasi-Newton|Newton & quasi-Newton (BFGS, L-BFGS)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Poisson process]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/DBSCAN.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Cross-validation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Regularization]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[ROC AUC]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Feature engineering]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Missing data]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Ensembling]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/Data leakage.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 17 | `[[Clustering evaluation]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:validation | tags:concept |
| 15 | `[[Missing data]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept | mots:data |
| 14 | `[[PCA|Principal Component Analysis (PCA)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Newton & quasi-Newton|Newton & quasi-Newton (BFGS, L-BFGS)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Multi-armed bandits]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Chi-squared tests.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[FAMD|Factor Analysis of Mixed Data (FAMD)]]` | wiki | categorie | domaines:data-science | souscat:categorical | tags:concept+stats |
| 19 | `[[t-test and ANOVA]]` | wiki | categorie | domaines:data-science | tags:concept+stats | mots:test |
| 18 | `[[MFA|Multiple Factor Analysis (MFA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[PCA|Principal Component Analysis (PCA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |
| 18 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Confidence intervals]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Bootstrap]]` | wiki | categorie | domaines:data-science | tags:concept+stats |

### `Wiki/Concepts/Agent patterns.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 15 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Scaling laws]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[LLM benchmarks]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Small Language Models|Small Language Models (SLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[SFT|SFT (Supervised Fine-Tuning)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[LLM-as-judge]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/Agent memory.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 25 | `[[Agent evaluation]]` | wiki | categorie | domaines:ai-eng | souscat:agents+llm | tags:concept+agents | mots:agent |
| 24 | `[[Multi-agent systems]]` | wiki | categorie | domaines:ai-eng | souscat:agents | tags:concept+agents+llm | mots:agent |
| 20 | `[[Transformer architectures]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept+llm |
| 18 | `[[anthropic-consolidate-memory|anthropic-skills:consolidate-memory]]` | wiki | alias-partial | domaines:ai-eng | souscat:memory | tags:memory | mots:memory |
| 18 | `[[agent-loops|Agent loops]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents+llm | mots:agent |
| 15 | `[[Reasoning models]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Scaling laws]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/AI security.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Perplexity]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | tags:concept |
| 18 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[Clustering evaluation]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 17 | `[[Synthetic data generation]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm | mots:model |
| 17 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm | mots:model |
| 16 | `[[Distillation|Knowledge distillation]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[Positional encoding]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |

### `Wiki/Concepts/agent-loops.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 40 | `[[Agent patterns]]` | wiki | alias-exact | cat-top | domaines:ai-eng | souscat:agents+react+planning | tags:concept+agents+llm | mots:agent+loops |
| 21 | `[[mcp-protocol|MCP Protocol]]` | wiki | categorie | domaines:ai-eng | souscat:agents | tags:concept+agents |
| 18 | `[[prompt-caching|Prompt Caching]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 18 | `[[embeddings]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 18 | `[[Multi-agent systems]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents+llm | mots:agent |
| 18 | `[[Agent memory]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents+llm | mots:agent |
| 16 | `[[Agent evaluation]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents | mots:agent |
| 15 | `[[Tool use patterns]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents |

### `Wiki/Concepts/Agent evaluation.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 34 | `[[Code and math benchmarks|Code & math benchmarks]]` | wiki | alias-exact | cat-top | domaines:ai-eng | souscat:benchmarks | tags:concept+eval+benchmarks | mots:swe+bench |
| 25 | `[[Agent memory]]` | wiki | categorie | domaines:ai-eng | souscat:agents+llm | tags:concept+agents | mots:agent |
| 20 | `[[LLM benchmarks]]` | wiki | cat-top | domaines:ai-eng | souscat:benchmarks+llm | tags:concept+eval+benchmarks |
| 17 | `[[LLM-as-judge]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+eval | mots:eval+bench |
| 16 | `[[agent-loops|Agent loops]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents | mots:agent |
| 15 | `[[mcp-protocol|MCP Protocol]]` | wiki | cat-top | domaines:ai-eng | souscat:agents | tags:concept+agents |
| 14 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | alias-partial | cat-top | tags:concept |
| 13 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept |

### `Wiki/Concepts/A-B testing.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[MAP estimation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Maximum likelihood estimation|Maximum likelihood estimation (MLE)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 14 | `[[Missing data]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Newton & quasi-Newton|Newton & quasi-Newton (BFGS, L-BFGS)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[PCA|Principal Component Analysis (PCA)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Multi-armed bandits.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[CUPED]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[Maximum likelihood estimation|Maximum likelihood estimation (MLE)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[MAP estimation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Data drift]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 20 | `[[Decoding strategies]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept | mots:greedy+sampling |
| 15 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept | mots:sampling |
| 14 | `[[KL divergence]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Advanced RAG.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[RAG eval|RAG evaluation]]` | wiki | cat-top | domaines:ai-eng | souscat:rag | tags:concept+rag+llm | mots:rag |
| 14 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | tags:concept |
| 13 | `[[Ranking metrics]]` | wiki | cat-top | domaines:ai-eng | tags:concept+rag | mots:retrieval |
| 13 | `[[Self-attention]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:self |
| 13 | `[[Synthetic data generation]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:self |
| 13 | `[[Transformer architectures]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:architectures |
| 13 | `[[Prompt engineering]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:self |

### `Wiki/Concepts/Adam optimizer.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | alias-partial | cat-top | domaines:ml-eng+ai-eng | tags:concept |
| 22 | `[[Loss landscape and saddle points]]` | wiki | categorie | domaines:ml-eng+ai-eng | tags:concept+optimization |
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:ml-eng+ai-eng | tags:concept |
| 18 | `[[Convexity]]` | wiki | categorie | domaines:ml-eng | tags:concept+optimization |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 16 | `[[Inference optimization]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+optimization |
| 16 | `[[Flash Attention and efficient attention|Flash Attention & efficient attention]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+optimization |
| 16 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+optimization |

### `Wiki/Concepts/ARIMA SARIMA.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 38 | `[[Hierarchical forecasting]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series+forecasting |
| 33 | `[[Time series feature engineering]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 33 | `[[Time series anomaly detection]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 22 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[CUPED]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Data drift]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Ranking metrics]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Regression metrics]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Calibration.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Feature engineering]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 25 | `[[Imbalanced classification]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:classification | tags:concept+ml |
| 22 | `[[GMM|Gaussian Mixture Models (GMM)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Clustering evaluation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[DBSCAN]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Regularization]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Ensembling]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/CA.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 31 | `[[Chi-squared tests]]` | wiki | alias-partial | categorie | domaines:data-science | souscat:categorical | tags:concept+stats+categorical |
| 31 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | alias-partial | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats+factor-analysis |
| 23 | `[[GPA|Generalized Procrustes Analysis (GPA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 23 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 18 | `[[Hypothesis testing]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Imbalanced classification]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |
| 18 | `[[Ranking metrics]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |
| 18 | `[[Hierarchical forecasting]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |

### `Wiki/Concepts/Chain-of-Thought.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[Context engineering]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 21 | `[[Structured outputs]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 21 | `[[Speculative decoding]]` | wiki | categorie | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 18 | `[[Inference optimization]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 15 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[LLM benchmarks]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/Central limit theorem.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Brownian motion]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+probability |
| 22 | `[[Poisson process]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+probability |
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Markov chains]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+probability |
| 22 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+probability |
| 14 | `[[Newton & quasi-Newton|Newton & quasi-Newton (BFGS, L-BFGS)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[KL divergence]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Brownian motion.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 23 | `[[Poisson process]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+probability | mots:processus |
| 22 | `[[Missing data]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[ROC AUC]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 20 | `[[uv]]` | wiki | alias-partial | domaines:data-science+ml-eng+ai-eng |
| 18 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[embeddings]]` | wiki | cat-top | domaines:ai-eng+ml-eng+data-science | tags:concept |
| 18 | `[[SVD|SVD (Singular Value Decomposition)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |

### `Wiki/Concepts/Bayesian inference.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[CUPED]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[Multi-armed bandits]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 19 | `[[PAC learning]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept | mots:bayes |
| 19 | `[[Generalization bounds]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept | mots:bayes |
| 18 | `[[Shannon entropy]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Cross-entropy]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[KL divergence]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Ranking metrics]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |

### `Wiki/Concepts/Autocorrelation.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[Intermittent demand]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 18 | `[[Time series anomaly detection]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 18 | `[[Time series feature engineering]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 18 | `[[Hierarchical forecasting]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 18 | `[[Exponential smoothing|Exponential smoothing (ETS)]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 14 | `[[PAC learning]]` | wiki | alias-partial | cat-top | tags:concept |
| 12 | `[[Forecasting metrics]]` | wiki | cat-top | domaines:data-science | tags:concept+time-series |

### `Wiki/Concepts/Bootstrap.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+stats |
| 22 | `[[PCA|Principal Component Analysis (PCA)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+stats |
| 18 | `[[MFA|Multiple Factor Analysis (MFA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Decoding strategies]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[FAMD|Factor Analysis of Mixed Data (FAMD)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Multiple testing correction]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[GPA|Generalized Procrustes Analysis (GPA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |

### `Wiki/Concepts/Bias-variance tradeoff.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Clustering evaluation]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 25 | `[[Regularization]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:overfitting | tags:concept+ml |
| 22 | `[[DBSCAN]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Missing data]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Ensembling]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Imbalanced classification]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[GMM|Gaussian Mixture Models (GMM)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Feature engineering]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/KL divergence.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Perplexity]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+info-theory |
| 18 | `[[Markov chains]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[SVD|SVD (Singular Value Decomposition)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[t-SNE and UMAP]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[embeddings]]` | wiki | cat-top | domaines:ai-eng+ml-eng+data-science | tags:concept |
| 18 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Gradient descent|Gradient descent and variants]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |

### `Wiki/Concepts/K-means.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Feature engineering]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Imbalanced classification]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[t-SNE and UMAP]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[ROC AUC]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Missing data]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Cross-validation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Regularization]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Bias-variance tradeoff]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/Learning rate schedules.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Loss landscape and saddle points]]` | wiki | categorie | domaines:ml-eng+ai-eng | tags:concept+optimization |
| 18 | `[[Convexity]]` | wiki | categorie | domaines:ml-eng | tags:concept+optimization |
| 18 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[Newton & quasi-Newton|Newton & quasi-Newton (BFGS, L-BFGS)]]` | wiki | categorie | domaines:ml-eng | tags:concept+optimization |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 16 | `[[Inference optimization]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+optimization |
| 16 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+optimization |
| 16 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+optimization |

### `Wiki/Concepts/LLM caching.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 35 | `[[prompt-caching|Prompt Caching]]` | wiki | alias-exact | cat-top | domaines:ai-eng | souscat:optimization+cost | tags:concept+llm | mots:prompt+caching |
| 24 | `[[Reliability patterns|Reliability patterns (LLM)]]` | wiki | categorie | domaines:ai-eng | souscat:llm-ops | tags:concept+llm+production | mots:llm |
| 24 | `[[Guardrails|Guardrails & safety runtime]]` | wiki | categorie | domaines:ai-eng | souscat:llm-ops | tags:concept+llm+production | mots:llm |
| 20 | `[[Transformer architectures]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept+llm |
| 15 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng | souscat:optimization | tags:concept+llm |
| 14 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[CA|Correspondence Analysis (CA)]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | tags:concept |

### `Wiki/Concepts/LLM benchmarks.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 23 | `[[RAG eval|RAG evaluation]]` | wiki | categorie | domaines:ai-eng | souscat:eval | tags:concept+eval+llm |
| 16 | `[[Small Language Models|Small Language Models (SLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |
| 16 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |
| 15 | `[[Reasoning models]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Prompt engineering]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Evaluer un systeme LLM]]` | wiki | domaines:ai-eng | souscat:eval+llm | tags:eval+llm | mots:llm |
| 15 | `[[RLHF and DPO|RLHF, DPO & alignment]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/Inference optimization.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Decoding strategies]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+llm+inference |
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:ml-eng+ai-eng | tags:concept |
| 18 | `[[Prompt engineering]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 18 | `[[prompt-caching|Prompt Caching]]` | wiki | cat-top | domaines:ai-eng | souscat:optimization | tags:concept+llm+optimization | mots:caching |
| 18 | `[[Chain-of-Thought|Chain-of-Thought (CoT)]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 18 | `[[Structured outputs]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm |
| 16 | `[[embeddings]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |

### `Wiki/Concepts/Imbalanced classification.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 25 | `[[Missing data]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:ml | tags:concept+ml |
| 22 | `[[Clustering evaluation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[GMM|Gaussian Mixture Models (GMM)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[DBSCAN]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Ensembling]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[K-means]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Regularization]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/Intermittent demand.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Hierarchical forecasting]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series+forecasting |
| 28 | `[[Walk-forward CV]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:forecasting+time-series | tags:concept+time-series |
| 25 | `[[Time series anomaly detection]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 25 | `[[Time series feature engineering]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 18 | `[[Evaluer un modele forecast]]` | wiki | domaines:data-science+ml-eng | souscat:forecasting+time-series | tags:forecasting+time-series |
| 18 | `[[Stationarity]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |

### `Wiki/Concepts/Jensen-Shannon divergence.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[Mutual information]]` | wiki | categorie | domaines:data-science+ml-eng+ai-eng | tags:concept+info-theory |
| 22 | `[[Perplexity]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+info-theory |
| 19 | `[[Concentration inequalities]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept | mots:jensen |
| 18 | `[[SVD|SVD (Singular Value Decomposition)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[embeddings]]` | wiki | cat-top | domaines:ai-eng+ml-eng+data-science | tags:concept |
| 18 | `[[Markov chains]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |

### `Wiki/Concepts/Jailbreaking and defenses.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[Diffusion models]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 18 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 14 | `[[CA|Correspondence Analysis (CA)]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[MCA|Multiple Correspondence Analysis (MCA)]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[Exponential smoothing|Exponential smoothing (ETS)]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[Clustering evaluation]]` | wiki | alias-partial | cat-top | tags:concept |
| 13 | `[[Prompt engineering]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:shot |

### `Wiki/Concepts/Matrix decompositions.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 23 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+linalg | mots:matrix |
| 22 | `[[Regression metrics]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Clustering evaluation]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Projections]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+linalg |
| 22 | `[[K-means]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[GMM|Gaussian Mixture Models (GMM)]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[DBSCAN]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Markov chains.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 27 | `[[Concentration inequalities]]` | wiki | alias-partial | categorie | domaines:ml-eng | tags:concept+probability | mots:markov |
| 22 | `[[Central limit theorem]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+probability |
| 22 | `[[ROC AUC]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Missing data]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 19 | `[[Matrix products|Matrix products (Hadamard, Kronecker, outer, dot)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept | mots:matrix |
| 18 | `[[Shannon entropy]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[SVD|SVD (Singular Value Decomposition)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |

### `Wiki/Concepts/Matrix products.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 23 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+linalg | mots:matrix |
| 22 | `[[Projections]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+linalg |
| 22 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Adam optimizer|Adam optimizer (et famille)]]` | wiki | alias-partial | cat-top | domaines:ml-eng+ai-eng | tags:concept |
| 22 | `[[Missing data]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 19 | `[[Markov chains]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept | mots:matrix |
| 18 | `[[Shannon entropy]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |

### `Wiki/Concepts/MCA.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis+dimensionality-reduction | tags:concept+stats | mots:analysis+analyse |
| 23 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats+factor-analysis |
| 23 | `[[GPA|Generalized Procrustes Analysis (GPA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 23 | `[[Chi-squared tests]]` | wiki | categorie | domaines:data-science | souscat:categorical | tags:concept+stats+categorical |
| 20 | `[[Multiple testing correction]]` | wiki | categorie | domaines:data-science | tags:concept+stats | mots:multiple+multiples |
| 18 | `[[Missing data]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |
| 18 | `[[t-test and ANOVA]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Bootstrap]]` | wiki | categorie | domaines:data-science | tags:concept+stats |

### `Wiki/Concepts/Maximum likelihood estimation.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Cross-entropy]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept | mots:log+likelihood |
| 22 | `[[A-B testing|A/B testing]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[CUPED]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[Multi-armed bandits]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 20 | `[[Confidence intervals]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:estimation+frequentist | tags:concept |
| 15 | `[[Classification metrics]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept | mots:log |
| 14 | `[[Newton & quasi-Newton|Newton & quasi-Newton (BFGS, L-BFGS)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/LLM observability.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[LLM caching]]` | wiki | categorie | domaines:ai-eng | souscat:llm-ops | tags:concept+llm+production | mots:llm |
| 18 | `[[Cross-entropy]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 18 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 16 | `[[Data drift]]` | wiki | cat-top | souscat:monitoring+production | tags:concept+monitoring+production |
| 14 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | tags:concept |
| 13 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |
| 13 | `[[LLM-as-judge]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |
| 13 | `[[LLM benchmarks]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |

### `Wiki/Concepts/LLM eval metrics.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 37 | `[[RAG eval|RAG evaluation]]` | wiki | alias-exact | cat-top | domaines:ai-eng | souscat:rag | tags:concept+rag+eval+llm | mots:ragas+faithfulness+metrics |
| 36 | `[[LLM-as-judge]]` | wiki | alias-exact | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm+eval | mots:llm+as+judge+eval |
| 25 | `[[Classification metrics]]` | wiki | categorie | domaines:ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics |
| 25 | `[[Forecasting metrics]]` | wiki | categorie | domaines:ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics |
| 25 | `[[Regression metrics]]` | wiki | categorie | domaines:ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics |
| 24 | `[[Transformer architectures]]` | wiki | alias-partial | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 21 | `[[Ragas]]` | dev | alias-exact | tags:llm+eval+rag |
| 21 | `[[Tokenization]]` | wiki | cat-top | domaines:ai-eng+ml-eng | souscat:llm | tags:concept+nlp+llm |

### `Wiki/Concepts/LLM-as-judge.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[Code and math benchmarks|Code & math benchmarks]]` | wiki | categorie | domaines:ai-eng | tags:concept+llm+eval | mots:bench |
| 16 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |
| 16 | `[[Vision Language Models|Vision Language Models (VLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |
| 16 | `[[Small Language Models|Small Language Models (SLM)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm | mots:llm |
| 15 | `[[Synthetic data generation]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Structured outputs]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |
| 15 | `[[PEFT|PEFT (LoRA, QLoRA, DoRA)]]` | wiki | cat-top | domaines:ai-eng | souscat:llm | tags:concept+llm |

### `Wiki/Concepts/MAP estimation.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 23 | `[[Ranking metrics]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept | mots:map |
| 22 | `[[CUPED]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[Regression metrics]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Clustering evaluation]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Forecasting metrics]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Multi-armed bandits]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[A-B testing|A/B testing]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+statistics |
| 22 | `[[t-SNE and UMAP]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Loss landscape and saddle points.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Learning rate schedules]]` | wiki | categorie | domaines:ml-eng+ai-eng | tags:concept+optimization |
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:ml-eng+ai-eng | tags:concept |
| 18 | `[[Newton & quasi-Newton|Newton & quasi-Newton (BFGS, L-BFGS)]]` | wiki | categorie | domaines:ml-eng | tags:concept+optimization |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 16 | `[[Inference optimization]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+optimization |
| 16 | `[[Flash Attention and efficient attention|Flash Attention & efficient attention]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+optimization |
| 16 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+optimization |
| 16 | `[[Speculative decoding]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+optimization |

### `Wiki/Concepts/Hypothesis testing.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[MFA|Multiple Factor Analysis (MFA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[MCA|Multiple Correspondence Analysis (MCA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[PCA|Principal Component Analysis (PCA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |
| 18 | `[[FAMD|Factor Analysis of Mixed Data (FAMD)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[CA|Correspondence Analysis (CA)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | categorie | domaines:data-science | tags:concept+stats |

### `Wiki/Concepts/HCPC.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 31 | `[[CA|Correspondence Analysis (CA)]]` | wiki | alias-partial | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats+factor-analysis |
| 26 | `[[Confidence intervals]]` | wiki | alias-partial | categorie | domaines:data-science | tags:concept+stats |
| 23 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:principal+principales |
| 23 | `[[MFA|Multiple Factor Analysis (MFA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats+factor-analysis |
| 22 | `[[Hierarchical forecasting]]` | wiki | alias-partial | cat-top | domaines:data-science | souscat:hierarchical | tags:concept | mots:hierarchical |
| 21 | `[[GPA|Generalized Procrustes Analysis (GPA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats |
| 18 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |
| 18 | `[[Multiple testing correction]]` | wiki | categorie | domaines:data-science | tags:concept+stats |

### `Wiki/Concepts/GMM.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Imbalanced classification]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[t-SNE and UMAP]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[ROC AUC]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Missing data]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Cross-validation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Regularization]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Bias-variance tradeoff]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/Hierarchical forecasting.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Intermittent demand]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series+forecasting |
| 25 | `[[Time series anomaly detection]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 25 | `[[Time series feature engineering]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 22 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | alias-partial | cat-top | domaines:data-science | souscat:hierarchical | tags:concept | mots:hierarchical |
| 22 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 18 | `[[Evaluer un modele forecast]]` | wiki | domaines:data-science+ml-eng | souscat:forecasting+time-series | tags:forecasting+time-series |
| 18 | `[[Autocorrelation|Autocorrelation (ACF, PACF)]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |

### `Wiki/Concepts/Forecasting framing.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 28 | `[[Hierarchical forecasting]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:forecasting | tags:concept+time-series+forecasting | mots:forecasting |
| 27 | `[[Exponential smoothing|Exponential smoothing (ETS)]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:forecasting | tags:concept+time-series+forecasting |
| 27 | `[[Intermittent demand]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:forecasting | tags:concept+time-series+forecasting |
| 27 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:forecasting | tags:concept+time-series+forecasting |
| 24 | `[[Time series feature engineering]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+time-series | mots:time+series |
| 24 | `[[Time series anomaly detection]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+time-series | mots:time+series |
| 22 | `[[Forecasting metrics]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:forecasting | tags:concept+forecasting+time-series | mots:forecasting |
| 22 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Gradient descent.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 26 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 22 | `[[Clustering evaluation]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 22 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | tags:concept |
| 18 | `[[Shannon entropy]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[embeddings]]` | wiki | cat-top | domaines:ai-eng+ml-eng+data-science | tags:concept |
| 18 | `[[t-SNE and UMAP]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[SVD|SVD (Singular Value Decomposition)]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |
| 18 | `[[Markov chains]]` | wiki | cat-top | domaines:data-science+ml-eng+ai-eng | tags:concept |

### `Wiki/Concepts/Guardrails.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[LLM caching]]` | wiki | categorie | domaines:ai-eng | souscat:llm-ops | tags:concept+llm+production | mots:llm |
| 24 | `[[Routing and cascading|LLM routing & cascading]]` | wiki | categorie | domaines:ai-eng | souscat:llm-ops | tags:concept+llm+production | mots:llm |
| 24 | `[[Reliability patterns|Reliability patterns (LLM)]]` | wiki | categorie | domaines:ai-eng | souscat:llm-ops | tags:concept+llm+production | mots:llm |
| 14 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[AI security]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm+safety |
| 13 | `[[Quantization|Quantization (LLM)]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |
| 13 | `[[Small Language Models|Small Language Models (SLM)]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |
| 13 | `[[LLM benchmarks]]` | wiki | cat-top | domaines:ai-eng | tags:concept+llm | mots:llm |

### `Wiki/Concepts/GPA.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 23 | `[[FAMD|Factor Analysis of Mixed Data (FAMD)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 23 | `[[CA|Correspondence Analysis (CA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 23 | `[[MCA|Multiple Correspondence Analysis (MCA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 21 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats |
| 18 | `[[ROC AUC]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |
| 18 | `[[Multiple testing correction]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[t-test and ANOVA]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Confidence intervals]]` | wiki | categorie | domaines:data-science | tags:concept+stats |

### `Wiki/Concepts/Exponential smoothing.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Hierarchical forecasting]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series+forecasting |
| 25 | `[[Time series anomaly detection]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 25 | `[[Time series feature engineering]]` | wiki | categorie | domaines:data-science+ml-eng | souscat:time-series | tags:concept+time-series |
| 18 | `[[Evaluer un modele forecast]]` | wiki | domaines:data-science+ml-eng | souscat:forecasting+time-series | tags:forecasting+time-series |
| 18 | `[[Autocorrelation|Autocorrelation (ACF, PACF)]]` | wiki | categorie | domaines:data-science | tags:concept+time-series |
| 14 | `[[Missing data]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[MCMC|MCMC (Markov Chain Monte Carlo)]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |
| 14 | `[[Multi-armed bandits]]` | wiki | cat-top | domaines:data-science+ml-eng | tags:concept |

### `Wiki/Concepts/Ensembling.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 22 | `[[ROC AUC]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Feature engineering]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Clustering evaluation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Regularization]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[GMM|Gaussian Mixture Models (GMM)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Missing data]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Imbalanced classification]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Calibration]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/Forecasting metrics.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 39 | `[[Classification metrics]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics+accuracy+loss |
| 37 | `[[Ranking metrics]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics |
| 32 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series+forecasting |
| 25 | `[[LLM eval metrics]]` | wiki | categorie | domaines:ml-eng | souscat:metrics+evaluation | tags:concept+metrics | mots:metrics |
| 25 | `[[Hierarchical forecasting]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series+forecasting | mots:forecasting |
| 24 | `[[Exponential smoothing|Exponential smoothing (ETS)]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series+forecasting |
| 24 | `[[Intermittent demand]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:time-series+forecasting | tags:concept+time-series+forecasting |
| 23 | `[[Clustering evaluation]]` | wiki | cat-top | domaines:data-science+ml-eng | souscat:evaluation+metrics | tags:concept+metrics | mots:metrics |

### `Wiki/Concepts/Flash Attention and efficient attention.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 23 | `[[Mixture of Experts|Mixture of Experts (MoE)]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+llm | mots:sparse |
| 22 | `[[State Space Models|State Space Models (SSM)]]` | wiki | categorie | domaines:ai-eng+ml-eng | tags:concept+llm |
| 18 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 17 | `[[PEFT|PEFT (LoRA, QLoRA, DoRA)]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm | mots:efficient |
| 16 | `[[Distillation|Knowledge distillation]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |
| 16 | `[[Loss landscape and saddle points]]` | wiki | cat-top | domaines:ml-eng+ai-eng | tags:concept+optimization |
| 16 | `[[RAG]]` | wiki | cat-top | domaines:ai-eng+ml-eng | tags:concept+llm |

### `Wiki/Concepts/Feature engineering.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 30 | `[[Calibration]]` | wiki | alias-partial | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[GMM|Gaussian Mixture Models (GMM)]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Ensembling]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[t-SNE and UMAP]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Cross-validation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[ROC AUC]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[DBSCAN]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |
| 22 | `[[Clustering evaluation]]` | wiki | categorie | domaines:data-science+ml-eng | tags:concept+ml |

### `Wiki/Concepts/FAMD.md` (8 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 29 | `[[CA|Correspondence Analysis (CA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis+categorical | tags:concept+stats+factor-analysis | mots:analysis+analyse+factorielle |
| 23 | `[[PGA|Principal Geodesic Analysis (PGA)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats | mots:analysis+analyse |
| 23 | `[[HCPC|Hierarchical Clustering on Principal Components (HCPC)]]` | wiki | categorie | domaines:data-science | souscat:factor-analysis | tags:concept+stats+factor-analysis |
| 21 | `[[Chi-squared tests]]` | wiki | categorie | domaines:data-science | souscat:categorical | tags:concept+stats |
| 18 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:data-science | tags:concept |
| 18 | `[[t-test and ANOVA]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Multiple testing correction]]` | wiki | categorie | domaines:data-science | tags:concept+stats |
| 18 | `[[Confidence intervals]]` | wiki | categorie | domaines:data-science | tags:concept+stats |

### `Wiki/Concepts/Image generation.md` (7 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Video generation]]` | wiki | categorie | domaines:ai-eng | souscat:diffusion | tags:concept+multimodal+diffusion | mots:generation |
| 18 | `[[Speech models|Speech models (ASR/TTS)]]` | wiki | categorie | domaines:ai-eng | tags:concept+multimodal |
| 18 | `[[Mutual information]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 18 | `[[Jensen-Shannon divergence]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 14 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | tags:concept |
| 14 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | alias-partial | cat-top | tags:concept |
| 13 | `[[Brownian motion]]` | wiki | cat-top | domaines:ai-eng | souscat:diffusion | tags:concept |

### `Wiki/Outils/Claude-Code/anthropic-setup-cowork.md` (7 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 14 | `[[claude-loop|loop]]` | wiki | categorie | tags:skill+claude-code |
| 14 | `[[claude-schedule|schedule]]` | wiki | categorie | tags:skill+claude-code |
| 14 | `[[claude-update-config|update-config]]` | wiki | categorie | tags:skill+claude-code |
| 14 | `[[claude-keybindings-help|keybindings-help]]` | wiki | categorie | tags:skill+claude-code |
| 14 | `[[claude-api]]` | wiki | categorie | tags:skill+claude-code |
| 14 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | categorie | tags:skill+claude-code |
| 14 | `[[claude-init|init]]` | wiki | categorie | tags:skill+claude-code |

### `Wiki/Concepts/Tool use patterns.md` (7 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[Multi-agent systems]]` | wiki | categorie | domaines:ai-eng | souscat:agents | tags:concept+agents |
| 21 | `[[Agent memory]]` | wiki | categorie | domaines:ai-eng | souscat:agents | tags:concept+agents |
| 14 | `[[CA|Correspondence Analysis (CA)]]` | wiki | alias-partial | cat-top | tags:concept |
| 13 | `[[mcp-obsidian]]` | wiki | alias-partial | domaines:ai-eng | mots:mcp |
| 13 | `[[mcp-github]]` | wiki | alias-partial | domaines:ai-eng | mots:mcp |
| 13 | `[[mcp-filesystem]]` | wiki | alias-partial | domaines:ai-eng | mots:mcp |
| 12 | `[[mcp-obsidian - reference outils|mcp-obsidian — référence outils]]` | wiki | alias-partial | souscat:mcp | mots:mcp |

### `Wiki/Outils/Claude-Code/claude-keybindings-help.md` (7 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 19 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | categorie | souscat:productivity | tags:skill+claude-code+productivity |
| 14 | `[[claude-loop|loop]]` | wiki | categorie | tags:skill+claude-code |
| 14 | `[[claude-update-config|update-config]]` | wiki | categorie | tags:skill+claude-code |
| 14 | `[[claude-schedule|schedule]]` | wiki | categorie | tags:skill+claude-code |
| 14 | `[[anthropic-setup-cowork|anthropic-skills:setup-cowork]]` | wiki | categorie | tags:skill+claude-code |
| 14 | `[[claude-api]]` | wiki | categorie | tags:skill+claude-code |
| 14 | `[[claude-init|init]]` | wiki | categorie | tags:skill+claude-code |

### `Wiki/Concepts/Reranking.md` (5 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 24 | `[[Chunking strategies]]` | wiki | categorie | domaines:ai-eng | souscat:rag+retrieval | tags:concept+rag |
| 21 | `[[Query transformations]]` | wiki | categorie | domaines:ai-eng | souscat:rag | tags:concept+rag |
| 18 | `[[Transformer architectures]]` | wiki | alias-partial | cat-top | domaines:ai-eng | tags:concept |
| 15 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng | souscat:rag | tags:concept+rag |
| 15 | `[[RAG eval|RAG evaluation]]` | wiki | cat-top | domaines:ai-eng | souscat:rag | tags:concept+rag |

### `Wiki/Concepts/Hybrid retrieval.md` (5 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[Query transformations]]` | wiki | categorie | domaines:ai-eng | tags:concept+rag |
| 14 | `[[Mixture of Experts|Mixture of Experts (MoE)]]` | wiki | cat-top | domaines:ai-eng | souscat:sparse | tags:concept | mots:sparse |
| 14 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | tags:concept |
| 12 | `[[RAG eval|RAG evaluation]]` | wiki | cat-top | domaines:ai-eng | tags:concept+rag |
| 12 | `[[LLM eval metrics]]` | wiki | cat-top | domaines:ai-eng | tags:concept+rag |

### `Wiki/Concepts/Rademacher complexity.md` (5 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[Generalization bounds]]` | wiki | categorie | domaines:ml-eng | tags:concept+learning-theory |
| 18 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 14 | `[[CA|Correspondence Analysis (CA)]]` | wiki | alias-partial | cat-top | tags:concept |
| 12 | `[[Bias-variance tradeoff]]` | wiki | cat-top | domaines:ml-eng | tags:concept+generalization |

### `Wiki/Concepts/No Free Lunch theorem.md` (5 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[Generalization bounds]]` | wiki | categorie | domaines:ml-eng | souscat:generalization | tags:concept+learning-theory |
| 18 | `[[Matrix decompositions|Matrix decompositions (QR, LU, Cholesky)]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 18 | `[[Rademacher complexity]]` | wiki | categorie | domaines:ml-eng | tags:concept+learning-theory |
| 18 | `[[ARIMA SARIMA|ARIMA & SARIMA]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 12 | `[[Central limit theorem]]` | wiki | cat-top | domaines:ml-eng | tags:concept | mots:theorem+théorème |

### `Templates/Wiki-Concept.md` (4 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 20 | `[[Wiki-Outil|<% tp.file.title %>]]` | wiki | alias-exact | mots:<%+tp+file+title+%> |
| 20 | `[[Wiki-Workflow|<% tp.file.title %>]]` | wiki | alias-exact | mots:<%+tp+file+title+%> |
| 20 | `[[Project|<% tp.file.title %>]]` | dev | alias-exact | mots:<%+tp+file+title+%> |
| 20 | `[[Service|<% tp.file.title %>]]` | dev | alias-exact | mots:<%+tp+file+title+%> |

### `Templates/Wiki-Workflow.md` (4 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 20 | `[[Wiki-Concept|<% tp.file.title %>]]` | wiki | alias-exact | mots:<%+tp+file+title+%> |
| 20 | `[[Wiki-Outil|<% tp.file.title %>]]` | wiki | alias-exact | mots:<%+tp+file+title+%> |
| 20 | `[[Project|<% tp.file.title %>]]` | dev | alias-exact | mots:<%+tp+file+title+%> |
| 20 | `[[Service|<% tp.file.title %>]]` | dev | alias-exact | mots:<%+tp+file+title+%> |

### `Templates/Wiki-Outil.md` (4 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 20 | `[[Wiki-Concept|<% tp.file.title %>]]` | wiki | alias-exact | mots:<%+tp+file+title+%> |
| 20 | `[[Wiki-Workflow|<% tp.file.title %>]]` | wiki | alias-exact | mots:<%+tp+file+title+%> |
| 20 | `[[Project|<% tp.file.title %>]]` | dev | alias-exact | mots:<%+tp+file+title+%> |
| 20 | `[[Service|<% tp.file.title %>]]` | dev | alias-exact | mots:<%+tp+file+title+%> |

### `Wiki/Outils/Claude-Code/anthropic-docx.md` (4 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[anthropic-pptx|anthropic-skills:pptx]]` | wiki | categorie | domaines:doc | tags:skill+claude-code+documents | mots:anthropic |
| 21 | `[[anthropic-pdf|anthropic-skills:pdf]]` | wiki | categorie | domaines:doc | tags:skill+claude-code+documents | mots:anthropic |
| 17 | `[[anthropic-xlsx|anthropic-skills:xlsx]]` | wiki | categorie | tags:skill+claude-code+documents | mots:anthropic |
| 12 | `[[claude-fewer-permission-prompts|fewer-permission-prompts]]` | wiki | cat-top | domaines:doc | tags:skill+claude-code |

### `Wiki/Concepts/VC dimension.md` (3 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[Generalization bounds]]` | wiki | categorie | domaines:ml-eng | souscat:generalization | tags:concept+learning-theory |
| 18 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | domaines:ml-eng | tags:concept |
| 14 | `[[CA|Correspondence Analysis (CA)]]` | wiki | alias-partial | cat-top | tags:concept |

### `Wiki/Concepts/Speech models.md` (3 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[Video generation]]` | wiki | categorie | domaines:ai-eng | souscat:multimodal | tags:concept+multimodal |
| 18 | `[[Image generation]]` | wiki | categorie | domaines:ai-eng | tags:concept+multimodal |
| 14 | `[[Confidence intervals]]` | wiki | alias-partial | cat-top | tags:concept |

### `Wiki/Outils/MCP-Servers/mcp-obsidian - reference outils.md` (3 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 16 | `[[kepano-obsidian-skills|kepano/obsidian-skills]]` | wiki | categorie | souscat:obsidian | tags:obsidian | mots:obsidian |
| 12 | `[[Tool use patterns]]` | wiki | alias-partial | souscat:mcp | mots:mcp |
| 12 | `[[kepano-defuddle|kepano/defuddle]]` | wiki | categorie | tags:obsidian |

### `Wiki/Workflows/Bootstrap projet AI eng.md` (2 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 18 | `[[Evaluer un systeme LLM]]` | wiki | categorie | domaines:ai-eng | tags:workflow+ai-eng |
| 13 | `[[Bootstrap]]` | wiki | alias-partial | souscat:bootstrap | tags:bootstrap |

### `Wiki/Concepts/Video generation.md` (2 liens proposes)

| Score | Wikilink suggere | Galaxie | Justification |
|---:|---|---|---|
| 21 | `[[Vision Language Models|Vision Language Models (VLM)]]` | wiki | categorie | domaines:ai-eng | souscat:multimodal | tags:concept+multimodal |
| 13 | `[[Brownian motion]]` | wiki | cat-top | domaines:ai-eng | souscat:diffusion | tags:concept |

