---
galaxie: dev
nom: Snowflake
alias: [snowflake, snowflake-data-cloud]
categorie: data/warehouse
sous_categories: [data-warehouse, cloud, sql, dwh, analytics]
licence: Propriétaire
licence_type: proprietary
hosted: cloud
maturite: production
langage: SQL
clients_officiels: [python, jdbc, odbc, node, go, snowsql, snowpark]
plateforme: [aws, gcp, azure]
score: 4
mes_projets: []
alternatives: ["[[BigQuery]]", "AWS Redshift", "Databricks SQL", "[[DuckDB]] (single-node)", "[[Postgres]] + extensions"]
remplace: []
remplace_par: []
created: 2026-05-21
modified: 2026-05-21
status: actif
tags: [service, data, warehouse, sql, cloud]
url_officiel: https://www.snowflake.com/
url_docs: https://docs.snowflake.com/
url_repo:
---

# Snowflake

## Pourquoi

**Data warehouse cloud** SaaS, multi-cloud (AWS, GCP, Azure). Sépare **compute** (warehouses ajustables à la demande) et **storage** (S3/GCS/Blob sous-jacent), facture indépendamment. Concurrent direct de **[[BigQuery]]** et **Redshift**. Devenu standard de facto en mid/enterprise pour l'analytique structurée.

Différenciateurs clés :
- **Time travel** (jusqu'à 90 jours) — requêter l'état passé d'une table
- **Zero-copy cloning** — cloner une DB / schema / table en quelques secondes
- **Data sharing** — partager des datasets entre comptes Snowflake sans copie
- **Snowpark** — UDF Python/Java/Scala dans le moteur Snowflake
- **Streams + Tasks** — CDC + scheduling natif
- **Snowflake AI / Cortex** (2024+) — LLM + vector search natifs

## Quand l'utiliser

- **Data warehouse mid/enterprise** : 100 Go - 100 To, analytique structurée
- **Multi-cloud** : choisis ton cloud, Snowflake suit (vs Redshift = AWS only, BigQuery = GCP only)
- **Combo [[dbt]]** : Snowflake + dbt = stack analytics moderne
- **Data sharing inter-org** : partage de datasets sans pipeline (clients, partenaires)
- **Variables compute** : scaler les warehouses à la minute selon load
- **Snowpark / Cortex** : ML / LLM dans le moteur
- **Equipes pas full-cloud** : abstraction unifiée sur les 3 hyperscalers

## Quand NE PAS l'utiliser

- **Single-node analytique** → [[DuckDB]] (gratuit, local, presque aussi rapide pour < 1 Go)
- **Transactionnel** (OLTP) → [[Postgres]] / [[MySQL]] (Snowflake = OLAP)
- **GCP-natif total** → [[BigQuery]] (intégration profonde, serverless pricing)
- **Open-source obligatoire** → ClickHouse / DuckDB / Trino
- **Budget serré, charge stable** → Redshift Reserved Instances ou Postgres + colonnes (Citus/TimescaleDB)
- **Petite équipe / petits volumes** : Snowflake minimum cost > Postgres managed

## Pièges connus

- **Coût difficile à prévoir** : compute facturé à la seconde × taille warehouse, surveiller `WAREHOUSE_METERING_HISTORY`
- **Warehouse oubliés actifs** : un dev qui oublie un warehouse XL allumé une nuit = facture salée. Activer auto-suspend (60s)
- **Storage en plus du compute** : data + Time Travel + Fail-safe = facture distincte
- **Time Travel retention** : par défaut 1 jour Standard / 90 Enterprise+ → impact storage cost
- **Resource monitors** mal configurés : pas de cap par défaut, possible de cramer le budget mensuel en heures
- **Snowflake-specific SQL** : ARRAY_AGG, LATERAL FLATTEN, VARIANT type → moins portable
- **Permissions complexes** : ROLES + GRANTS + FUTURE GRANTS → audit non-trivial
- **Snowpark Python overhead** : startup cold non-négligeable
- **Vendor lock-in fort** : sortir de Snowflake = repenser la stack
- **MERGE non-idempotent par défaut** : faire attention au comportement vs Postgres / BigQuery
- **Limits par compte** : nb d'objets, parallelism — checker pour gros workloads

## Code minimal

```bash
# Install client Python
pip install snowflake-connector-python "snowflake-snowpark-python"

# Connexion via env vars
export SNOWFLAKE_ACCOUNT="xxxxxxx-yyyyyyy"
export SNOWFLAKE_USER="floSa"
export SNOWFLAKE_PASSWORD="..."
```

```python
import snowflake.connector
import os

conn = snowflake.connector.connect(
    user=os.environ["SNOWFLAKE_USER"],
    password=os.environ["SNOWFLAKE_PASSWORD"],
    account=os.environ["SNOWFLAKE_ACCOUNT"],
    warehouse="COMPUTE_WH",
    database="MYDB",
    schema="PUBLIC",
)

cur = conn.cursor()
cur.execute("SELECT current_version()")
print(cur.fetchone())

# Query + DataFrame pandas
import pandas as pd
cur.execute("SELECT * FROM orders WHERE date >= %s", ("2026-01-01",))
df = cur.fetch_pandas_all()
print(df.head())

cur.close(); conn.close()
```

```sql
-- Time travel : requêter l'état d'il y a 1 heure
SELECT * FROM orders AT(OFFSET => -3600);

-- Zero-copy clone (instantané, pas de duplication storage)
CREATE DATABASE prod_clone CLONE prod;

-- Auto-suspend warehouse après 60s d'inactivité
ALTER WAREHOUSE compute_wh SET AUTO_SUSPEND = 60 AUTO_RESUME = TRUE;

-- Resource monitor (alerte / hard limit)
CREATE RESOURCE MONITOR monthly_cap
    WITH CREDIT_QUOTA = 1000
    FREQUENCY = MONTHLY
    START_TIMESTAMP = IMMEDIATELY
    TRIGGERS ON 80 PERCENT DO NOTIFY
             ON 100 PERCENT DO SUSPEND;
```

```python
# Snowpark : DataFrame Python qui s'exécute dans Snowflake
from snowflake.snowpark import Session

session = Session.builder.configs({
    "account": "...", "user": "...", "password": "...",
    "warehouse": "COMPUTE_WH", "database": "MYDB", "schema": "PUBLIC",
}).create()

df = session.table("orders").filter("amount > 100").group_by("customer_id").agg({"amount": "sum"})
df.show()
result = df.to_pandas()       # ramène en local quand voulu
```

## Liens

- [[BigQuery]] / AWS Redshift — alternatives data warehouses cloud
- [[DuckDB]] — alternative single-node open-source
- [[Postgres]] — alternative OLTP / mid-scale
- [[dbt]] — combo standard (Snowflake + dbt = stack analytics moderne)
- [[Apache Iceberg]] — Snowflake supporte Iceberg tables (2024+)
- ClickHouse / Trino — alternatives open-source
- Docs : https://docs.snowflake.com/
- Pricing : https://www.snowflake.com/pricing/
