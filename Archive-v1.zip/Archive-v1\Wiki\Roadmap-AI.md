---
galaxie: wiki
nom: Roadmap AI Engineer
type: roadmap
categorie: wiki/roadmap
domaines: [ai-eng, ml-eng]
created: 2026-05-20
modified: 2026-05-20
tags: [roadmap, ai-eng, llm, reference, checklist]
---

# Roadmap AI Engineer — Carte de compétences

> Document de référence — **carte exhaustive** des compétences attendues d'un AI Engineer / Applied AI Expert orienté **LLMs, agents, multimodal, prod**. Sert de checklist et de boussole pour identifier ce qui est déjà documenté en fiche dédiée vs ce qui reste à creuser.
>
> **Ce n'est pas une page d'apprentissage** : juste les noms d'algos/concepts/outils/modèles. Pour la pédagogie, va voir les fiches dédiées dans `Wiki/Concepts/`.
>
> **Convention de wikilinks** : au fil du temps, les items déjà documentés en fiche dédiée sont wikilinkés ici. Pour explorer un concept : recherche via `Ctrl+O`.
>
> **Filtrer du graph view** : `-path:Wiki/Roadmap-AI.md` dans les filtres (cf. `INSTALL.md` §11.5.C).
>
> **Note** : la section 11 d'origine (Infrastructure GPU & Scale — hardware, parallélisme, kernels CUDA) a été volontairement écartée de ce wiki. Si besoin un jour, voir directement la doc NVIDIA, PyTorch Distributed, ou les papers Megatron / DeepSpeed / FSDP.

---

## 1. FONDAMENTAUX

### 1.1 Algèbre linéaire (orientée DL)
- Tensors
  - Rangs / dimensions
  - Shapes, axes, broadcasting
  - Notation Einstein (einsum)
  - Contiguous vs strided memory
- Opérations
  - Matmul (GEMM, batched)
  - Element-wise (Hadamard)
  - Outer product
  - Reduction (sum, mean, max, norm)
- Normes
  - L1, L2, L∞
  - Frobenius
  - Nuclear / spectral
  - Cosine similarity
- Décompositions utiles
  - SVD (réduction de rang, LoRA)
  - Eigendecomposition (spectral analysis)
  - QR (orthogonalisation)
  - Cholesky (matrices def. positives)
  - Low-rank approximation
- Calculs efficaces
  - Sparse matrices (CSR, COO)
  - Block-sparse
  - Tensor cores (matmul fused)
  - Mixed precision arithmetic

### 1.2 Calcul différentiel & autograd
- Dérivées
  - Partielles
  - Directionnelles
  - Vectorielles (gradient)
  - Matricielles (Jacobienne, Hessienne)
- Règle de la chaîne (multivariée)
- Backpropagation
  - Forward pass
  - Reverse pass
  - Computational graph
- Autograd
  - Forward-mode AD
  - Reverse-mode AD
  - VJP (Vector-Jacobian Product)
  - JVP (Jacobian-Vector Product)
  - Higher-order gradients
  - Gradient checkpointing
- Implémentations
  - PyTorch autograd
  - JAX (grad, vmap, jit)
  - TensorFlow GradientTape
- Stop-gradient / detach

### 1.3 Probabilités (utiles AI)
- Distributions
  - Bernoulli, Categorical, Multinomial
  - Gaussian (univariée, multivariée)
  - Mixture of Gaussians
  - Dirichlet
  - Gumbel (sampling discret différentiable)
  - Student-t
- Sampling
  - Inverse CDF
  - Rejection sampling
  - Importance sampling
  - Reparameterization trick
  - Gumbel-Softmax / Concrete distribution
  - Straight-Through estimator
- Monte Carlo
  - Vanilla MC
  - MCMC (Metropolis-Hastings, HMC, NUTS)
  - Variational inference
- Théorèmes
  - Théorème de Bayes
  - TCL
  - Inégalités (Jensen, Hoeffding)

### 1.4 Optimisation
- Gradient descent family
  - SGD
  - SGD + Momentum
  - Nesterov momentum
  - Adagrad
  - RMSprop
  - Adam, AdamW
  - AdaMax, Nadam
  - LAMB, LARS (large batch)
  - Lion (Google)
  - Sophia (second-order intuition)
  - Shampoo
  - Muon (récent)
  - AdEMAMix
- Schedules de learning rate
  - Constant
  - Step decay
  - Exponential decay
  - Cosine annealing
  - Cosine with warm restarts (SGDR)
  - Linear warmup
  - 1cycle / OneCycle
  - WSD (Warmup-Stable-Decay)
  - Inverse sqrt (Transformer original)
  - ReduceLROnPlateau
- Concepts
  - Convexité / non-convexité (loss landscapes DL)
  - Saddle points
  - Local minima vs global
  - Sharpness vs flatness (généralisation)
  - Loss landscape visualization
  - Mode connectivity
- Second-order (notions)
  - Newton's method
  - K-FAC
  - Natural gradient
  - Hessian-free optimization
- Stochasticité
  - Batch size effects
  - Linear scaling rule
  - Gradient noise scale
  - Critical batch size

### 1.5 Théorie de l'information
- Entropie de Shannon
- Entropie croisée (cross-entropy)
- Entropie conditionnelle
- KL divergence (forward, reverse)
- JS divergence
- Wasserstein / Earth Mover's distance
- Mutual information
- Pointwise MI (PMI)
- Perplexity
- Bits-per-byte / bits-per-character
- Coding (notions)
  - Huffman
  - Arithmetic coding (lien LLMs ↔ compression)
  - BPE comme compression

### 1.6 Fondamentaux ML
- Apprentissage
  - Supervisé / non-supervisé / self-supervised / RL
  - Pretraining → fine-tuning → alignement
- Biais-variance tradeoff
- Sur/sous-apprentissage
- Régularisation (notions)
- Capacité d'un modèle
- Loss vs metric
- Train/val/test splits
- Data leakage (input, target, group, temporal)
- Generalization
  - In-distribution
  - Out-of-distribution
  - Compositional
  - Length generalization
- Inductive bias
- Scaling laws
  - Kaplan et al. (2020)
  - Chinchilla (Hoffmann et al. 2022)
  - Compute-optimal training
  - Data-constrained scaling
  - Inference-time scaling (o1-style)
- Emergent abilities (et controverse)
- Grokking
- Double descent
- Phase transitions
- Lottery Ticket Hypothesis

### 1.7 Théorie des Transformers & attention
- Self-attention
  - Queries, Keys, Values
  - Scaled dot-product
  - Softmax attention
  - Complexité O(n²) en séquence
- Multi-head attention (MHA)
- Cross-attention
- Causal / masked attention
- Bidirectional vs unidirectional
- Variantes d'attention
  - MQA (Multi-Query)
  - GQA (Grouped-Query)
  - MLA (Multi-head Latent Attention - DeepSeek)
  - Sliding window (Mistral)
  - Global + local (Longformer)
  - Sparse attention (BigBird, Reformer)
  - Linear attention (Performer, Linformer)
  - Flash Attention v1/v2/v3 (IO-aware)
  - PagedAttention (vLLM)
  - Ring Attention (long context)
  - Differential Attention (récent)
- Positional encoding
  - Sinusoidal (original)
  - Learned
  - Relative (Shaw, T5)
  - RoPE (Rotary)
  - ALiBi (linear bias)
  - NoPE
  - YaRN / NTK-aware scaling (extension contexte)
- Normalisations dans le Transformer
  - LayerNorm
  - RMSNorm
  - Pre-LN vs Post-LN
  - DeepNorm
- FFN / MLP block
  - Activation (ReLU, GELU, SwiGLU, GeGLU)
  - Expansion ratio (4x classique)
- Architectures spécifiques
  - Encoder-only (BERT)
  - Decoder-only (GPT)
  - Encoder-decoder (T5, BART)
- MoE (Mixture of Experts)
  - Routing (top-k, expert choice)
  - Load balancing
  - Auxiliary losses
  - Shared experts
  - Fine-grained experts (DeepSeek)

### 1.8 State Space Models & alternatives au Transformer
- RNN classique (rappel)
- LSTM, GRU (rappel)
- xLSTM (revival)
- Linear RNNs
- S4, S5 (Structured State Spaces)
- Mamba (v1, v2)
- Mamba-MoE
- Hyena
- RetNet
- RWKV (v4, v5, v6, v7)
- Hybrides Transformer + SSM (Jamba, Zamba, Samba)
- TTT (Test-Time Training layers)

---

## 2. PROGRAMMATION & OUTILS AI

### 2.1 Python (orienté AI)
- Core moderne
  - Type hints, generics, Protocol
  - Dataclasses, attrs, Pydantic
  - Context managers
  - Décorateurs
- Async
  - asyncio (essentiel pour LLM apps)
  - aiohttp, httpx
  - Streaming responses (SSE)
  - Producer-consumer patterns
- Concurrence
  - threading, multiprocessing
  - concurrent.futures
  - asyncio.gather / TaskGroup
  - GIL (et son recul avec free-threading)
- Performance
  - Profiling (cProfile, py-spy, scalene)
  - Memory profiling (memray, tracemalloc)
  - Cython / Numba / Mojo
  - PyO3 / Rust bindings
- Packaging moderne
  - uv (rapide)
  - Poetry
  - PDM, Hatch
  - pyproject.toml
  - Lockfiles

### 2.2 Frameworks Deep Learning

#### PyTorch (prioritaire)
- Core
  - Tensors, devices, dtypes
  - autograd
  - nn.Module, nn.Parameter
  - nn.functional
- Data
  - Dataset, IterableDataset
  - DataLoader (workers, pin_memory, persistent_workers)
  - Sampler (Random, Sequential, Distributed, Weighted)
- Training
  - Optimizers, schedulers
  - AMP (autocast, GradScaler)
  - DDP, FSDP
  - Compile (torch.compile, TorchInductor)
- Écosystème
  - PyTorch Lightning
  - Hugging Face Accelerate
  - torchtune
  - torchtitan
  - Ignite
  - fastai
- Spécialisés
  - torchvision
  - torchaudio
  - torchtext (déprécié)
  - TorchRL
  - PyTorch Geometric

#### JAX
- Core
  - jax.numpy
  - jit, vmap, pmap, shard_map
  - grad, value_and_grad
  - PRNG keys (stateless RNG)
  - PyTrees
- Stack
  - Flax (NNX, Linen)
  - Haiku
  - Equinox
  - Optax (optimizers)
  - Orbax (checkpointing)
- Distribuée
  - pjit
  - SPMD
  - Mesh / sharding annotations

#### TensorFlow / Keras (notion)
- Keras 3 (multi-backend)
- tf.data
- tf.function

### 2.3 Écosystème Hugging Face
- transformers
  - AutoModel, AutoTokenizer, AutoConfig
  - Trainer, TrainingArguments
  - Generation (`generate()`, GenerationConfig)
  - pipelines
  - Custom architectures
- datasets
  - load_dataset, Dataset.map
  - Streaming
  - Arrow / Parquet backend
- tokenizers (Rust)
  - Train tokenizer
  - Special tokens
  - Padding, truncation, attention masks
- accelerate
  - Multi-GPU launch
  - Mixed precision
  - FSDP, DeepSpeed integration
- peft
  - LoRA, QLoRA, DoRA
  - Prefix, Prompt, P-Tuning, IA³
  - Adapters
- trl
  - SFTTrainer
  - DPOTrainer, KTOTrainer, ORPOTrainer
  - PPOTrainer, GRPOTrainer
  - Reward modeling
- diffusers
  - Pipelines (text2img, img2img, inpaint, controlnet)
  - Schedulers (DDIM, DPM, Euler, etc.)
  - LoRA pour diffusion
- evaluate (métriques)
- huggingface_hub
  - Push / pull models
  - Spaces (Gradio/Streamlit hosted)
  - Inference Endpoints
- safetensors (format sécurisé)
- text-generation-inference (TGI)
- text-embeddings-inference (TEI)
- candle (Rust)

### 2.4 Frameworks LLM apps
- LangChain
  - Chains (LCEL)
  - Runnables
  - Output parsers
  - Memory
  - Document loaders
- LangGraph
  - StateGraph
  - Cycles, branching
  - Checkpointing / persistence
  - Human-in-the-loop
- LlamaIndex
  - Documents, Nodes
  - Index types (vector, list, tree, knowledge graph)
  - Query engines
  - Sub-question / router query engines
- Haystack
- DSPy
  - Signatures
  - Modules, ChainOfThought, ReAct
  - Compilation (MIPRO, BootstrapFewShot)
  - Optimizers (programmatic prompt optim)
- Semantic Kernel (Microsoft)
- Outlines (structured generation)
- Instructor (Pydantic-based structured outputs)
- Guidance / LMQL (programmatic prompting)
- Mirascope
- BAML (boundary AI markup)

### 2.5 Frameworks d'agents
- OpenAI Agents SDK
- Anthropic Claude Agent SDK
- Smolagents (HF)
- AutoGen (Microsoft)
- CrewAI
- LangGraph (agents avec graphes)
- LlamaIndex Agents
- AutoGPT, BabyAGI (historiques)
- AgentScope
- MetaGPT
- Swarm (OpenAI, expérimental)
- Phidata / Agno
- Computer use SDKs
  - Anthropic Computer Use
  - OpenAI Operator-style
  - Browser automation (Playwright, Browser Use)

### 2.6 MCP (Model Context Protocol)
- Concepts
  - Servers, clients
  - Tools, resources, prompts
  - Transport (stdio, SSE, HTTP)
- Implémentations
  - Référence (Anthropic)
  - SDK Python, TS, autres
- Use cases
  - File system access
  - Database access
  - Custom enterprise tools

### 2.7 Vector databases
- Bibliothèques in-process
  - FAISS (Meta)
  - Annoy (Spotify)
  - ScaNN (Google)
  - HNSWlib
  - Voyager
- Vector DBs dédiés
  - Pinecone (managed)
  - Weaviate
  - Qdrant
  - Milvus / Zilliz
  - Chroma
  - LanceDB
  - Vespa
  - Marqo
  - Vald
- Extensions SQL
  - pgvector (Postgres)
  - pgvectorscale
  - Supabase (basé pgvector)
- Recherche hybride / full-text
  - Elasticsearch / OpenSearch (avec kNN)
  - Typesense
  - Meilisearch
- Critères de choix
  - Filtered search
  - Hybrid search
  - Multi-tenancy
  - Replication / sharding
  - Latence / throughput
  - Coût

### 2.8 Inference servers & runtimes
- LLM serving
  - vLLM (PagedAttention, continuous batching)
  - TGI (Text Generation Inference, HF)
  - SGLang (RadixAttention)
  - LMDeploy
  - TensorRT-LLM (NVIDIA)
  - DeepSpeed-MII / DeepSpeed-Inference
  - Aphrodite
  - llama.cpp
  - Ollama
  - LM Studio
  - GPT4All
  - exllamav2
  - MLX (Apple Silicon)
- General serving
  - Triton Inference Server
  - TorchServe
  - TensorFlow Serving
  - BentoML
  - Ray Serve
  - KServe
  - Modal
  - Replicate
  - Beam, RunPod, Lambda Labs
- Embeddings serving
  - TEI (Text Embeddings Inference)
  - Infinity
- Edge / mobile
  - ONNX Runtime
  - TFLite
  - Core ML
  - ExecuTorch (PyTorch mobile)
  - MediaPipe
  - WebLLM, WebGPU
  - Transformers.js

### 2.9 Frontend & app dev
- Python apps rapides
  - Streamlit
  - Gradio
  - Chainlit
  - Panel
  - Reflex
  - Mesop
  - FastHTML
- Backend / API
  - FastAPI
  - Litestar
  - Flask (legacy)
  - Starlette
- Web frontend AI
  - Next.js + Vercel AI SDK
  - Vue / Nuxt
  - SvelteKit
  - Remix
- UI components AI
  - shadcn/ui
  - Vercel AI Elements
  - assistant-ui
  - copilotkit
- Streaming
  - SSE (Server-Sent Events)
  - WebSockets
  - HTTP streaming chunked

### 2.10 Cloud & GPU providers
- Hyperscalers
  - AWS
    - Bedrock (Claude, Llama, etc. managed)
    - SageMaker
    - Trainium / Inferentia (Neuron SDK)
    - EC2 GPU (P4/P5/P6)
  - GCP
    - Vertex AI
    - TPU (v4, v5e, v5p, v6 Trillium)
    - GCE GPU
    - Gemini API
  - Azure
    - Azure OpenAI Service
    - Azure AI Foundry
    - ML Studio
- AI-native
  - Anthropic API
  - OpenAI API
  - Google AI Studio
  - Cohere
  - Mistral
  - Together AI
  - Fireworks
  - Anyscale
  - Groq (LPU)
  - SambaNova
  - Cerebras (CS-3)
  - Perplexity Sonar API
  - DeepInfra
  - Novita
- GPU-as-a-service
  - Modal
  - Replicate
  - RunPod
  - Lambda Labs
  - CoreWeave
  - Vast.ai
  - Paperspace
  - Crusoe
  - Vultr GPU
- LLM ops platforms
  - Databricks Mosaic
  - [[Snowflake]] Cortex
  - Hugging Face Inference Endpoints

### 2.11 Versioning, expérimentation, observabilité
- Code
  - Git, GitHub, GitLab
  - Conventional commits
  - Pre-commit hooks
- Données
  - DVC
  - LakeFS
  - HF Datasets versioning
- Modèles
  - HF Hub
  - MLflow Model Registry
  - W&B Artifacts
- Configs
  - Hydra
  - OmegaConf
  - pydantic-settings
- Experiment tracking
  - Weights & Biases
  - MLflow
  - Neptune.ai
  - Comet ML
  - ClearML
  - Aim
  - TensorBoard
- LLM-specific observabilité (voir aussi section 10)
  - LangSmith
  - Langfuse
  - Helicone
  - Arize Phoenix
  - Braintrust
  - Weave (W&B)
  - Traceloop / OpenLLMetry
  - Lunary
- Reproductibilité
  - Seeds (Python, NumPy, PyTorch, CUDA)
  - Deterministic mode
  - Docker images figées
  - Requirements pinning

### 2.12 Dev tooling
- IDE
  - VS Code (+ Cursor, Windsurf, Cline)
  - PyCharm
  - JupyterLab
  - Marimo (notebooks réactifs)
  - Colab, Kaggle Notebooks
- Coding assistants
  - GitHub Copilot
  - Cursor
  - Claude Code
  - Codeium / Windsurf
  - Cline / Roo Code (VS Code agents)
  - Continue.dev
  - Aider
- Linters & formatters
  - ruff (lint + format)
  - black (legacy)
  - mypy / pyright
- Testing
  - pytest
  - hypothesis
  - pytest-asyncio
- Documentation
  - MkDocs Material
  - Sphinx
  - Docstrings (NumPy / Google style)

---

## 3. ARCHITECTURES DE MODÈLES

### 3.1 Transformers en profondeur

#### Variantes d'attention
- MHA (Multi-Head Attention) — baseline
- MQA (Multi-Query) — partage K/V
- GQA (Grouped-Query) — compromis
- MLA (Multi-head Latent Attention) — DeepSeek
- Local / sliding window (Mistral, Longformer)
- Global + local hybride
- Sparse (Sparse Transformer, BigBird)
- Linear (Performer, Linformer, Linear Transformer)
- Kernel-based (FAVOR+)
- Cross-attention
- Flash Attention v1, v2, v3 (IO-aware, hardware)
- Paged Attention (vLLM)
- Ring Attention (extension contexte)
- Differential Attention (Microsoft)
- Native Sparse Attention (DeepSeek)

#### Positional encodings
- Sinusoidal (Vaswani)
- Learned absolute
- Relative (Shaw, T5 bias)
- RoPE (Rotary)
- RoPE scaling
  - PI (Position Interpolation)
  - NTK-aware
  - YaRN
  - LongRoPE
- ALiBi (Attention with Linear Biases)
- NoPE
- Mixed (RoPE + sliding window)

#### Normalisations
- LayerNorm (pre vs post)
- RMSNorm (LLaMA standard)
- DeepNorm
- ScaleNorm
- QK-Norm (stability)

#### Activations / FFN
- ReLU
- GELU
- SwiGLU (LLaMA standard)
- GeGLU
- ReGLU
- SiLU / Swish

#### Architectures macro
- Encoder-only (BERT family)
- Decoder-only (GPT family)
- Encoder-decoder (T5, BART)
- Prefix-LM
- UL2 / mixture-of-denoisers

#### MoE en détail
- Routing
  - Top-1, top-2
  - Expert Choice
  - Hash routing
  - Soft MoE
- Load balancing
  - Auxiliary loss
  - Loss-free balancing
- Architecture
  - Shared experts (DeepSeek)
  - Fine-grained experts (DeepSeek)
  - Hierarchical MoE
- Inférence MoE
  - Expert parallelism
  - All-to-all communication

#### Long context
- Sliding window attention
- Recurrence (Transformer-XL)
- Compression / pooling
- RAG-as-context
- YaRN, LongRoPE
- Ring Attention
- Attention sinks (StreamingLLM)
- Position interpolation
- LongRoPE, LongRoPE2
- Activation Beacon

#### Efficient Transformers
- Mixture of Depths
- Layer skipping / Early exit
- Speculative decoding integration
- Hybrid (SSM + attention)

### 3.2 Familles de LLMs

#### Closed-source frontières
- Anthropic Claude (Haiku, Sonnet, Opus — versions 3, 3.5, 3.7, 4, 4.5, 4.6, 4.7)
- OpenAI GPT (GPT-4, 4-Turbo, 4o, GPT-5)
- OpenAI reasoning (o1, o1-pro, o3, o3-mini, o4)
- Google Gemini (1.0, 1.5, 2.0, 2.5 — Flash, Pro, Ultra)
- Google DeepMind (Gemini Deep Think)
- xAI Grok (1, 2, 3, 4)

#### Open-weights frontières
- Meta Llama (1, 2, 3, 3.1, 3.2, 3.3, 4)
- Mistral (7B, Mixtral 8x7B, 8x22B, Large, Medium, Codestral)
- DeepSeek (V2, V2.5, V3, R1)
- Qwen (1, 1.5, 2, 2.5, 3 — Alibaba)
- Yi (01.ai)
- Falcon (TII)
- Cohere Command R / R+
- Databricks DBRX
- Snowflake Arctic
- Reka (Core, Flash, Edge)
- xAI Grok-1 (open)
- Tencent Hunyuan
- Z.ai GLM

#### Small Language Models
- Microsoft Phi (1, 1.5, 2, 3, 3.5, 4)
- Google Gemma (1, 2, 3 — 2B, 9B, 27B)
- Apple OpenELM
- Meta MobileLLM
- HuggingFace SmolLM (1, 2, 3)
- Allen AI OLMo (1, 2)
- StableLM
- TinyLlama
- Qwen 0.5B / 1.8B

#### Reasoning models (test-time compute)
- OpenAI o1, o3, o4 family
- DeepSeek-R1, R1-Zero, R1-Distill
- Qwen QwQ, QvQ
- Alibaba Qwen 3 (thinking modes)
- Anthropic extended thinking (Sonnet/Opus 3.7+)
- Google Gemini Thinking
- Kimi K1.5, K2 (Moonshot)
- Marco-o1
- Skywork-o1
- Concepts
  - Chain-of-Thought as training signal
  - Process Reward Models (PRM)
  - Outcome Reward Models (ORM)
  - Search at inference (MCTS, beam over thoughts)
  - GRPO (Group Relative Policy Optimization)
  - Long CoT generation

#### Code models
- Code Llama
- DeepSeek-Coder (V1, V2)
- Qwen-Coder
- CodeGemma
- StarCoder, StarCoder2
- Codestral
- WizardCoder
- Phind
- Replit Code
- OpenAI Codex (re-released)
- Claude as code (Claude Code intégration)
- Pratiques
  - Fill-in-the-middle (FIM)
  - Repo-level context
  - Code-specific tokenization

#### Domain-specific
- Médical (Med-PaLM, BioBERT, ClinicalBERT, Med42)
- Légal (LegalBERT, SaulLM)
- Finance (BloombergGPT, FinGPT)
- Science (Galactica, Minerva)
- Math (DeepSeek-Math, Llemma, Qwen-Math)

### 3.3 Vision Language Models (VLMs)
- Architectures
  - Vision encoder + projector + LLM
  - Cross-attention (Flamingo-style)
  - Token merging
  - Late fusion
  - Native multimodal (Chameleon, Fuyu)
- Modèles
  - GPT-4V, GPT-4o
  - Claude 3+ (vision native)
  - Gemini (native multimodal)
  - LLaVA (1, 1.5, 1.6 / NeXT)
  - LLaVA-OneVision
  - BLIP, BLIP-2, InstructBLIP
  - Flamingo, OpenFlamingo
  - Idefics (1, 2, 3)
  - Qwen-VL, Qwen2-VL, Qwen2.5-VL
  - InternVL (1, 2, 2.5, 3)
  - MiniCPM-V
  - DeepSeek-VL, DeepSeek-VL2
  - Molmo / PixMo (AllenAI)
  - Pixtral (Mistral)
  - Phi-3.5-Vision, Phi-4-multimodal
  - CogVLM
  - mPLUG-Owl
- Tâches
  - VQA (Visual Question Answering)
  - Document understanding (DocVQA, ChartQA)
  - OCR-free document AI
  - Grounding (referring expressions)
  - Image captioning
  - Visual reasoning
  - Multi-image / multi-turn

### 3.4 Modèles audio & speech

#### ASR (Speech-to-Text)
- Whisper (v1, v2, v3, large-v3-turbo)
- Distil-Whisper
- Faster-Whisper (CTranslate2)
- WhisperX (alignement + diarization)
- Seamless M4T (v1, v2)
- Conformer
- Wav2Vec 2.0
- HuBERT
- Canary (NVIDIA)
- Paraformer
- Moonshine

#### TTS (Text-to-Speech)
- ElevenLabs
- OpenAI TTS / Realtime
- XTTS v2 (Coqui)
- Tortoise TTS
- Bark
- StyleTTS 2
- F5-TTS
- Fish Speech
- Kokoro
- Parler-TTS
- VALL-E, NaturalSpeech (recherche)
- Sesame CSM

#### Audio models génériques
- AudioCLIP
- CLAP
- AudioLM
- MusicGen
- Stable Audio
- Suno
- Udio
- Riffusion

#### Speech-to-Speech / Voice agents
- OpenAI Realtime API (gpt-4o-realtime)
- GPT-4o native voice
- Gemini Live
- Anthropic voice (Sonnet voice)
- Kyutai Moshi
- Speech LLMs (SpeechGPT)
- Pipeline classique : ASR → LLM → TTS
- Diarization
  - pyannote.audio
  - NeMo Speaker Diarization

### 3.5 Embedding models

#### Texte
- OpenAI text-embedding-3 (small, large)
- Cohere Embed (v3, v4)
- Voyage AI (voyage-3, voyage-code, voyage-multilingual)
- Mistral Embed
- Google text-embedding-005, Gecko
- Anthropic Voyage (rebranded)
- Open-weights
  - Sentence-BERT family
  - E5 (small, base, large, mistral)
  - BGE (small, base, large, M3)
  - GTE (small, base, large, Qwen)
  - Nomic Embed
  - Jina Embeddings (v2, v3)
  - Stella
  - SFR-Embedding
  - Linq-Embed
  - NV-Embed (NVIDIA)

#### Multimodal
- CLIP (OpenAI)
- OpenCLIP
- SigLIP / SigLIP 2 (Google)
- Jina CLIP
- Nomic Embed Vision
- VoyageAI multimodal
- ImageBind (all modalities)

#### Code
- Voyage Code
- CodeBERT, GraphCodeBERT
- UniXcoder
- StarCoder embeddings

#### Caractéristiques
- Dimensions (256, 384, 768, 1024, 1536, 3072+)
- Matryoshka Representation Learning (MRL)
- Binary / int8 quantization
- Asymmetric (query vs document)
- Instruction-tuned embeddings
- Context length
- Multilinguisme

#### Rerankers
- Cross-encoders (sentence-transformers)
- Cohere Rerank (v3)
- Voyage Rerank
- Jina Reranker
- BGE-Reranker (large, v2)
- mxbai-rerank
- ColBERT, ColBERTv2
- RankGPT (LLM-as-reranker)
- mono/duo-T5

### 3.6 Diffusion models

#### Théorie
- Forward (noising) process
- Reverse (denoising) process
- DDPM (Denoising Diffusion Probabilistic Models)
- DDIM (Denoising Diffusion Implicit Models)
- Score-based / NCSN
- Continuous (SDE) formulation
- Stochastic Differential Equations
- Probability flow ODE
- v-prediction vs ε-prediction
- Classifier guidance
- Classifier-Free Guidance (CFG)
- Negative prompts

#### Architectures
- U-Net (original)
- DiT (Diffusion Transformer)
- MMDiT (Multi-Modal DiT, SD3)
- Latent Diffusion (LDM)
- Cascaded (Imagen)
- Pixel-space
- VAE (encoder/decoder pour latent space)

#### Schedulers / samplers
- DDPM (full)
- DDIM
- DPM-Solver, DPM-Solver++
- DPM++ (2M, SDE, Karras)
- Euler, Euler Ancestral
- Heun
- LMS
- UniPC
- LCM (Latent Consistency Models)
- Consistency Models (one-step)

#### Modèles image
- Stable Diffusion 1.x, 2.x
- SDXL, SDXL Turbo, SDXL Lightning
- Stable Diffusion 3, 3.5
- FLUX.1 (Schnell, Dev, Pro)
- FLUX.1 Kontext (édition)
- DALL-E 2, 3
- Midjourney v6, v7
- Imagen 3, 4
- Ideogram
- Recraft
- Playground v3
- HunyuanDiT
- Kolors
- AuraFlow
- PixArt-α, PixArt-Σ

#### Distillation / accélération
- LCM (Latent Consistency)
- LCM-LoRA
- SDXL Turbo (Adversarial Diffusion Distillation)
- SDXL Lightning
- Hyper-SD
- DMD2 (Distribution Matching)
- One-step / few-step generation

### 3.7 Architectures émergentes
- World models (Genie, Genie 2, DreamerV3)
- Joint Embedding (I-JEPA, V-JEPA, V-JEPA 2)
- Energy-Based Models
- Diffusion language models
  - SEDD
  - LLaDA
  - Mercury (Inception)
- Byte-level / tokenizer-free
  - MegaByte
  - SpaceByte
  - Byte Latent Transformer (BLT)
- Test-Time Training layers (TTT)
- Liquid Neural Networks

---

## 4. ENTRAÎNEMENT & ADAPTATION

### 4.1 Pre-training

#### Data curation
- Sources
  - Common Crawl
  - C4 (filtered CC)
  - The Pile
  - RefinedWeb
  - SlimPajama
  - RedPajama (v1, v2)
  - FineWeb, FineWeb-Edu
  - Dolma (AllenAI)
  - Nemotron-CC
  - Books (Books3 — controversé)
  - GitHub (code)
  - ArXiv, PubMed
  - Wikipedia
  - StackExchange
- Pipeline de filtrage
  - URL filtering
  - Language ID (fastText, GlotLID)
  - Quality filtering
    - Heuristic (Gopher rules)
    - Classifier-based (DataComp-LM, FineWeb-Edu)
    - Perplexity-based (KenLM)
  - Toxicity / NSFW filtering
  - Deduplication
    - Exact match
    - MinHash + LSH
    - SemDeDup (embedding-based)
    - Suffix arrays
  - Decontamination (test set removal)
  - PII removal
- Data mixing
  - Domain weighting
  - DoReMi (auto-tuning)
  - Curriculum (easy → hard)
  - Annealing (cooldown phase)
- Synthetic pretraining data
  - Phi-style "textbook quality"
  - Distillation-based
  - Cosmopedia

#### Tokenization
- Algorithmes
  - BPE
  - Byte-level BPE (GPT-2)
  - WordPiece
  - SentencePiece (Unigram)
  - Tiktoken (OpenAI)
- Considérations
  - Vocabulary size (32k, 50k, 100k, 200k, 256k)
  - Multilinguisme
  - Code (gestion whitespace)
  - Special tokens (BOS, EOS, PAD, sep, system)
  - Chat templates
  - Byte fallback
  - Number tokenization (digits split)

#### Objectives
- Causal LM (next token prediction)
- Masked LM (BERT)
- Span corruption (T5)
- Prefix LM
- Mixture-of-denoisers (UL2)
- FIM (Fill-In-the-Middle) pour code
- Multi-token prediction (DeepSeek-V3)

#### Scaling laws & compute
- Chinchilla optimal (20:1 tokens:params)
- Over-training (Llama 3 style)
- FLOPs estimation (6ND)
- Loss extrapolation
- Critical batch size
- Compute-optimal vs inference-optimal

### 4.2 Post-training / Adaptation

#### Continued pretraining (CPT)
- Domain adaptation
- Language adaptation
- Vocabulary extension
- Long-context extension
- Risks (catastrophic forgetting)

#### SFT (Supervised Fine-Tuning)
- Instruction tuning
- Chat / dialog tuning
- Tool-use tuning
- Format (chat templates)
- Datasets standards
  - Alpaca, Dolly, OpenAssistant
  - LIMA (less is more)
  - WildChat, LMSYS-Chat
  - UltraChat
  - Tulu (V1, V2, V3)
  - Open-Hermes
  - Magpie (synthetic)
  - OpenMathInstruct
  - Open-Orca
- Loss masking (sur outputs only)
- Packing (concatenation efficace)

#### PEFT (Parameter-Efficient Fine-Tuning)
- LoRA (Low-Rank Adaptation)
  - Rank, alpha, target modules
  - LoRA merge
- QLoRA (4-bit base + LoRA)
- DoRA (Weight-Decomposed)
- LoRA+
- AdaLoRA
- LoRA-FA
- VeRA (shared random matrices)
- rsLoRA (rank-stabilized)
- PiSSA (initialization avec SVD)
- Adapters (Houlsby, Pfeiffer)
- Prefix tuning
- Prompt tuning
- P-tuning (v1, v2)
- IA³ (Infused Adapter)
- BitFit (biases only)
- Considerations
  - Merging LoRAs
  - LoRA stacking
  - Switching adapters at inference

### 4.3 Alignement & RLHF

#### Reward modeling
- Bradley-Terry préférences
- Pairwise comparison
- Reward Model architecture
- RM training datasets
  - Anthropic HH-RLHF
  - OpenAssistant
  - UltraFeedback
  - PKU SafeRLHF
- Reward hacking / Goodhart
- Process Reward Models (PRMs)
- Outcome Reward Models (ORMs)

#### RLHF variants
- PPO (Proximal Policy Optimization)
  - Reference model / KL penalty
  - Critic / value head
  - GAE
- DPO (Direct Preference Optimization)
- IPO (Identity PO)
- KTO (Kahneman-Tversky Optimization)
- ORPO (Odds Ratio PO)
- SimPO
- CPO (Contrastive PO)
- SLiC (Sequence Likelihood Calibration)
- RRHF (Rank Responses)
- RLAIF (RL from AI Feedback)
- Constitutional AI (Anthropic)
  - SL-CAI (Supervised)
  - RL-CAI
- Self-rewarding
- Self-play (SPIN)

#### Reasoning-focused RL
- GRPO (Group Relative Policy Optimization, DeepSeek)
- RLOO (REINFORCE Leave-One-Out)
- RPO (Reinforced Preference Optimization)
- DAPO (Dynamic sAmpling PO)
- VAPO
- PPO with verifiable rewards (math, code)
- Outcome rewards (correct/incorrect)
- R1-Zero style (pure RL)

### 4.4 Distillation
- Réponses-based (logit / soft target)
- Feature-based (hidden states)
- Relation-based
- On-policy vs off-policy
- Distillation pour SLMs
  - DistilBERT
  - TinyBERT
  - MiniLM
  - Phi (data-centric distillation)
- Cross-architecture distillation
- Speculative distillation
- Distill-Whisper

### 4.5 Quantization
- Concepts
  - Symmetric vs asymmetric
  - Per-tensor / per-channel / per-group / per-token
  - Static vs dynamic
- Précisions
  - FP16, BF16
  - FP8 (E4M3, E5M2)
  - INT8
  - INT4
  - FP4, NF4
  - 2-bit (extrême)
  - 1.58-bit (BitNet)
- PTQ (Post-Training Quantization)
  - GPTQ
  - AWQ (Activation-aware)
  - GGUF (llama.cpp ecosystem)
    - Q4_K_M, Q5_K_M, Q6_K, Q8_0
    - I-quants (IQ3_M, IQ2_S, etc.)
  - HQQ (Half-Quadratic)
  - QuIP, QuIP#
  - SmoothQuant
  - LLM.int8() (bitsandbytes)
  - EXL2 (exllama)
  - SqueezeLLM
  - OmniQuant
  - SpQR
- QAT (Quantization-Aware Training)
- KV cache quantization (4-bit, 8-bit)
- Outils
  - bitsandbytes
  - AutoGPTQ
  - AutoAWQ
  - llm-compressor (vLLM)
  - TensorRT Model Optimizer

### 4.6 Model merging
- Linear interpolation (weight averaging)
- SLERP (Spherical Linear)
- Model Soups
- Task arithmetic
- TIES-Merging (TrIm, Elect, dISJoint)
- DARE (Drop And REscale)
- Frankenmerge / passthrough
- Evolutionary merge (Sakana)
- MergeKit (outil principal)
- Use cases
  - Combiner SFT + RLHF
  - Multi-task models
  - Recovering capabilities

### 4.7 Synthetic data generation
- Approches
  - Self-Instruct (Wang et al.)
  - Evol-Instruct (WizardLM)
  - Self-Alignment
  - Persona-driven (PersonaHub)
  - Magpie (prompt from chat template)
  - Genstruct / Bonito
- Teacher-student distillation
- Verification-based (math, code)
- Constitutional AI-style critique
- Reject sampling
- Best-of-N
- Considérations
  - Diversity
  - Model collapse risk
  - Curation / filtering
- Datasets connus
  - Cosmopedia (HF)
  - OpenMathInstruct (NVIDIA)
  - Tulu 3 mixes

### 4.8 Long-context training
- Position encoding extension
  - PI (Position Interpolation)
  - NTK-aware scaling
  - YaRN
  - LongRoPE
  - ABF (Adjusted Base Frequency)
- Training curriculum
  - Short → long staged
  - Data packing
- Architectural
  - Ring Attention
  - Sequence parallelism
  - Flash Attention long context
- Evaluation
  - Needle in a Haystack
  - RULER
  - LongBench

### 4.9 Multimodal training
- Vision encoder pre-training
  - CLIP contrastive
  - DINO / DINOv2 self-sup
  - MAE / SimMIM masked image modeling
  - SigLIP sigmoid contrastive
- Alignment stages
  - Stage 1: Projector training (frozen LLM + vision)
  - Stage 2: Vision-language instruction tuning
  - Stage 3: SFT / RLHF
- Strategies
  - LLaVA-style (linear / MLP projector)
  - Q-Former (BLIP-2)
  - Cross-attention (Flamingo)
  - Native (Chameleon, Fuyu)
- Image tokenization
  - Patch embeddings
  - Dynamic resolution (AnyRes)
  - Tile-based for hi-res

### 4.10 Eval-driven development
- Build → eval → iterate loop
- Golden datasets curation
- Tracking eval over time
- Eval set hygiene (no leakage)
- LLM-as-judge calibration
- Production traces → eval set

---

## 5. INFÉRENCE & PROMPT ENGINEERING

### 5.1 Decoding strategies
- Déterministes
  - Greedy
  - Beam search
  - Diverse beam search
- Stochastiques
  - Temperature scaling
  - Top-k sampling
  - Top-p / Nucleus (Holtzman)
  - Top-a
  - Min-p
  - Typical sampling
  - Mirostat (v1, v2)
  - Tail-free sampling
  - η-sampling
- Hybrides
  - Contrastive search (degeneration penalty)
  - Contrastive decoding
  - DoLa (Decoding by Layer Contrasting)
- Penalties
  - Repetition penalty
  - Presence / frequency penalty
  - No-repeat n-gram
  - DRY (Don't Repeat Yourself)
- Stop conditions
  - Max tokens
  - Stop sequences
  - EOS handling
- Logit manipulation
  - Logit bias
  - Logit processors
  - Banned tokens

### 5.2 Decoding accélérés
- Speculative decoding
  - Draft model
  - Verification
  - Acceptance rate
- Lookahead decoding
- Medusa (parallel heads)
- EAGLE (v1, v2, v3)
- ReDrafter
- Self-speculative
- Layer skip (early exit)
- Prompt lookup decoding (PLD)
- Tree attention (speculative)

### 5.3 Prompt engineering — techniques

#### Bases
- Zero-shot
- Few-shot / in-context learning
- Role prompting
- System prompts
- Instructions claires (formats, contraintes)
- Delimiters (XML tags, triple quotes)
- Output format spec

#### Reasoning
- Chain-of-Thought (CoT)
  - Zero-shot CoT ("Let's think step by step")
  - Few-shot CoT
- Self-Consistency (sample N, majority vote)
- Tree-of-Thoughts (ToT)
- Graph-of-Thoughts (GoT)
- Skeleton-of-Thought
- Algorithm-of-Thought
- Least-to-Most prompting
- Plan-and-Solve
- Step-back prompting
- Analogical prompting

#### Auto-amélioration
- Self-Refine (critique + revise)
- Reflexion (with memory)
- Self-Consistency
- Self-Verification
- Self-Critique
- Self-Discover

#### Tool / Agent prompting
- ReAct (Reason + Act)
- Toolformer pattern
- PAL (Program-Aided LM)
- PoT (Program of Thoughts)
- ART (Automatic Reasoning and Tool-use)

#### Avancé
- Instruction induction
- APE (Automatic Prompt Engineer)
- OPRO (Optimization by PROmpting)
- DSPy compilation (MIPRO, BootstrapFewShot)
- Meta-prompting
- Recursive prompting

#### Defense / Robustness
- Prompt sanitization
- Sandwich defense
- Random sequence enclosure
- Spotlighting
- Constitutional prompting

### 5.4 Structured outputs
- JSON mode (OpenAI, Anthropic, etc.)
- JSON Schema constrained
- Pydantic-based
  - Instructor
  - Marvin
- Grammar-based
  - GBNF (llama.cpp)
  - XGrammar (vLLM)
  - Outlines (regex, CFG)
- Function/tool schema
  - OpenAPI / JSON Schema
- Constrained decoding
  - Token masking
  - Finite State Machines
  - Pushdown automata for CFGs
- Type-safe outputs
  - Zod (TS)
  - Pydantic (Python)
- BAML
- TypeChat (Microsoft)

### 5.5 Function calling / Tool use
- Concepts
  - Tool definitions (schema)
  - Function calls (model output)
  - Tool results (back to model)
  - Multi-turn tool loop
- Variantes
  - Single tool call
  - Parallel tool calls
  - Sequential tool calls
  - Nested / dependent calls
- Patterns
  - ReAct loop
  - Pure function calling (no CoT in output)
  - Forced tool choice
  - Required vs optional tools
- Tools courants
  - Web search
  - Code execution (Python sandbox)
  - File I/O
  - Database queries
  - APIs externes (REST)
  - Computer use (UI automation)
- Computer Use
  - Anthropic Computer Use API
  - OpenAI Operator
  - Browser Use
  - Screenshots → actions
- MCP (voir 2.6)
- Évaluation
  - Tool-call accuracy
  - Argument correctness
  - Trajectory eval

### 5.6 Context engineering
- Token accounting
  - Context window sizing
  - Reserve for output
- Compression
  - Summarization
  - Hierarchical summary
  - LLMLingua, LongLLMLingua
  - Selective context
- Caching
  - Prompt caching (Anthropic, OpenAI, Gemini)
  - Cached prefix (system + tools)
  - Implicit vs explicit
  - TTL et coût
  - KV cache reuse
- Position effects
  - Lost in the middle
  - Order sensitivity
  - Few-shot order
- Long context patterns
  - Map-reduce
  - Refine
  - Stuff
  - Hierarchical
- Conversational memory
  - Buffer
  - Sliding window
  - Summary
  - Vector retrieval

### 5.7 Inference optimization (server-side)
- Batching
  - Static batching
  - Dynamic batching
  - Continuous batching (in-flight)
- KV cache management
  - PagedAttention (vLLM)
  - Block sizes
  - Eviction policies
- Prefix caching
  - RadixAttention (SGLang)
  - vLLM prefix caching
- Chunked prefill
- Speculative decoding (voir 5.2)
- Disaggregated prefill / decode
- Tensor / pipeline parallelism (inference)
- Quantization at serving time
- Multi-LoRA serving
  - S-LoRA
  - Punica
  - LoRAX

### 5.8 Coût & latence engineering
- Métriques
  - TTFT (Time To First Token)
  - TPOT / ITL (Inter-Token Latency)
  - Throughput (tokens/sec)
  - Tokens per dollar
- Stratégies
  - Model routing (cheap → expensive)
  - Model cascading
  - Semantic cache
  - Exact match cache
  - Async / batch processing
  - Streaming (perceived latency)
  - Speculative decoding
  - Smaller model for first-pass
- RouteLLM, NotDiamond, Martian
- Hosted vs self-hosted break-even

---

## 6. RAG & RECHERCHE D'INFORMATION

### 6.1 Document ingestion

#### Loaders
- PDFs
  - PyMuPDF (fitz)
  - pdfplumber
  - pypdf
  - Unstructured
  - LlamaParse (LlamaIndex)
  - Marker
  - Docling (IBM)
  - Mistral OCR
  - PaddleOCR
  - Tesseract
- Office
  - python-docx
  - openpyxl
  - python-pptx
- HTML
  - BeautifulSoup
  - trafilatura
  - Readability
  - Jina Reader
  - Firecrawl
  - ScrapeGraph
- Markdown / Code
- Email (mbox, eml)
- Images (vision LLM extraction)
- Audio (Whisper transcription)
- Video (frames + transcription)

#### Parsing avancé
- Layout-aware parsing
  - LayoutLM family
  - Donut
  - Nougat (papers scientifiques)
- Table extraction
  - Camelot
  - Tabula
  - PaddleStructure
  - Img2Table
- Figure / chart extraction
- Multi-modal extraction (text + image)

### 6.2 Chunking strategies
- Fixed-size
  - Character count
  - Token count
  - With overlap
- Recursive character splitting
- Sentence-based (NLTK, spaCy)
- Paragraph-based
- Semantic chunking
  - Embedding similarity break
  - Greedy semantic
- Document structure-aware
  - Markdown headers
  - HTML sections
  - Code (functions, classes)
- Late chunking (Jina)
- Agentic chunking (LLM-driven)
- Propositions / atomic facts
- Hierarchical (parent-child)
- Sliding window
- Considérations
  - Chunk size (tokens)
  - Overlap
  - Metadata per chunk
  - Context preservation

### 6.3 Embeddings pour RAG
- Choix du modèle (voir 3.5)
- Asymmetric (query vs passage)
- Instruction-tuned (E5-instruct, NV-Embed)
- Dimension trade-off
- Matryoshka (truncation)
- Quantization (binary, int8)
- Multi-vector
  - ColBERT (late interaction)
  - ColPali (vision documents)

### 6.4 Vector search

#### Algorithmes ANN
- Exact (brute force)
- HNSW (Hierarchical Navigable Small World)
- IVF (Inverted File)
- IVF-PQ (Product Quantization)
- IVF-OPQ
- ScaNN (Google)
- DiskANN / Vamana
- FreshDiskANN
- SPANN
- LSH (Locality-Sensitive Hashing)
- Annoy

#### Métriques
- Cosine similarity
- Dot product
- Euclidean / L2
- Hamming (binary embeddings)

#### Considérations
- Filtered search (pré vs post filter)
- Hybrid (vector + scalar attributes)
- Multi-tenancy
- Updates / deletes
- Recall vs latency tradeoff
- Memory footprint

### 6.5 Hybrid retrieval
- Sparse + dense
- BM25 + vector
- Fusion
  - RRF (Reciprocal Rank Fusion)
  - Linear weighted
  - Convex combination
  - Borda count
- Multi-stage retrieval
- SPLADE (learned sparse)
- BM25 variants (BM25F, BM25+)

### 6.6 Re-ranking
- Cross-encoders
  - Cohere Rerank
  - Voyage Rerank
  - Jina Reranker
  - BGE Reranker
  - mxbai-rerank
- ColBERT / ColBERTv2
- LLM rerankers
  - RankGPT (listwise)
  - RankZephyr
  - Setwise reranking
- Two-stage retrieve-then-rerank pattern

### 6.7 Query transformations
- HyDE (Hypothetical Document Embeddings)
- Multi-query (paraphrasing)
- Query decomposition (sub-questions)
- Query rewriting
- Step-back prompting (abstract → concrete)
- RAG-Fusion (multi-query + RRF)
- Routing (query → index)
- Query expansion
- Query classification
- Spelling correction

### 6.8 Architectures RAG avancées
- Naive RAG (retrieve → augment → generate)
- Advanced RAG (pre + post retrieval)
- Modular RAG
- Self-RAG (auto-évalue rétrieval)
- CRAG (Corrective RAG)
- FLARE (Forward-Looking Active REtrieval)
- Iter-RetGen
- GraphRAG (Microsoft)
  - Knowledge graph construction
  - Community summaries
  - Local vs global search
- Contextual Retrieval (Anthropic)
  - Chunk-level context
  - Prompt caching combiné
- Agentic RAG
  - Multi-step retrieval
  - Tool-using agent
- HippoRAG (memory-inspired)
- RAPTOR (hierarchical clustering)
- RAGFlow
- LightRAG
- LongRAG

### 6.9 Evaluation RAG
- Composantes à évaluer
  - Retrieval quality (recall, MRR, NDCG)
  - Context relevance
  - Faithfulness (grounded ?)
  - Answer relevance
  - Answer correctness
  - Citation quality
- Frameworks
  - RAGAS
  - ARES
  - TruLens
  - DeepEval
  - Continuous Eval (Relari)
  - Phoenix evals (Arize)
- Datasets
  - HotpotQA
  - Natural Questions
  - TriviaQA
  - MS MARCO
  - BEIR
  - MTEB (embeddings)
- Synthetic test generation
- LLM-as-judge sur RAG outputs

### 6.10 Production RAG
- Indexing pipelines
  - Initial bulk indexing
  - Incremental updates
  - Reindexing strategies
- Document lifecycle
- Permissions / ACL
- Multi-tenancy
- Versioning de documents
- Freshness vs cost
- Monitoring (retrieval distribution drift)

---

## 7. AGENTS & SYSTÈMES AUTONOMES

### 7.1 Définitions & taxonomies
- Workflow vs Agent (Anthropic)
  - Workflow : LLMs orchestrés via paths prédéfinis
  - Agent : LLMs dirigent dynamiquement leurs propres processus
- Niveaux d'autonomie
  - Reactive
  - Deliberative
  - Self-improving
- Single vs multi-agent

### 7.2 Architectures
- ReAct (Reason + Act loop)
- Plan-and-Execute / Plan-and-Solve
- Reflexion (memory of past failures)
- LATS (Language Agent Tree Search)
- ToT-based agents
- AutoGen patterns
- BabyAGI / task decomposition loop
- Workflow patterns (Anthropic)
  - Prompt chaining
  - Routing
  - Parallelization
  - Orchestrator-workers
  - Evaluator-optimizer
- Hierarchical agents
- Society of mind
- Agent foundation models
  - General-purpose agents
  - Web agents (WebGPT, WebGLM, ToolFormer)
  - Code agents (Devin-style)

### 7.3 Tool use
- Function calling natif (LLM provider)
- Code interpreter / sandbox
  - Pyodide
  - E2B
  - Modal sandboxes
  - Daytona
  - Riza
- Web tools
  - Search APIs (Tavily, Exa, Brave, Serper, You.com, Perplexity, Linkup)
  - Web scraping (Firecrawl, Jina Reader, ScrapeGraph)
  - Headless browsers (Playwright, Browserbase, Browser Use, Anchor)
- Computer use
  - Screenshots → vision LLM
  - Coordinate-based actions
  - Anthropic Computer Use
  - OpenAI Computer-using Agent
  - WebVoyager
- MCP servers (voir 2.6)
- Custom REST API tools
- Tool retrieval (sélection dynamique parmi N)

### 7.4 Memory
- Types
  - Short-term (conversation buffer)
  - Long-term (persistent)
  - Episodic (events, experiences)
  - Semantic (facts, knowledge)
  - Procedural (skills, routines)
  - Working memory (scratchpad)
- Mécanismes
  - Conversation summary
  - Vector store-based retrieval
  - Knowledge graph
  - Hybrid memory
- Solutions
  - Letta (anciennement MemGPT)
  - Mem0
  - Zep
  - LangMem
  - Cognee
- MemGPT (paging, hierarchical)
- Reflexion-style memory (verbal reinforcement)

### 7.5 Multi-agent systems
- Topologies
  - Hierarchical (manager + workers)
  - Network / mesh
  - Sequential
  - Parallel
  - Group chat / debate
- Communication patterns
  - Broadcast
  - Direct messaging
  - Shared blackboard
- Rôles spécialisés
  - Planner
  - Researcher
  - Coder
  - Critic
  - Executor
  - Aggregator
- Frameworks
  - AutoGen
  - CrewAI
  - LangGraph (multi-agent supervisor)
  - MetaGPT
  - ChatDev
  - Camel
  - Swarm (OpenAI)
- Debate / Multi-agent reasoning
- Society of Mind (SoM)

### 7.6 Planning
- LLM-as-planner
- Decomposition (task → subtasks)
- HTN (Hierarchical Task Networks)
- PDDL (classical planning + LLM)
- Tree search
  - MCTS
  - LATS
  - RAP
- Backtracking
- Replanning (sur échec)

### 7.7 Evaluation d'agents
- Benchmarks
  - AgentBench
  - GAIA
  - WebArena, VisualWebArena
  - WebShop
  - OSWorld (computer use)
  - WindowsAgentArena
  - SWE-Bench, SWE-Bench Verified
  - τ-bench (Tau-bench, tool use)
  - BFCL (Berkeley Function Calling Leaderboard)
  - MLE-Bench
  - TheAgentCompany
  - SimpleQA Verified
- Métriques
  - Success rate
  - Steps to solve
  - Cost per task
  - Tool-call accuracy
  - Trajectory faithfulness
- Évaluation par traces
- Process vs outcome eval

### 7.8 Production agents
- State management (durable execution)
  - Temporal
  - Inngest
  - Trigger.dev
  - Restate
  - LangGraph checkpointing
- Human-in-the-loop
- Approval gates
- Failure modes
  - Infinite loops
  - Tool misuse
  - Hallucinated tools
  - Cost runaway
- Observability (voir section 10)
- Sandboxing
- Permissions / capability isolation

---

## 8. GÉNÉRATIF MULTIMODAL

### 8.1 Génération d'images

#### Modèles fondateurs
- Stable Diffusion 1.5, 2.x
- SDXL, SDXL Turbo, SDXL Lightning
- SD3, SD3.5
- FLUX.1 (Schnell, Dev, Pro, Ultra)
- DALL-E 2, 3
- Midjourney v6, v7
- Imagen 3, 4
- Ideogram (v1, v2, v3 — text rendering)
- Recraft v3
- Playground v3
- Adobe Firefly
- Reve
- Krea
- HiDream
- Janus-Pro (DeepSeek)
- GPT-Image-1 (OpenAI)
- Nano Banana / Gemini Image

#### Contrôle
- ControlNet
  - Canny, depth, pose, segmentation, normal, scribble, OpenPose, lineart, MLSD, soft edge, tile
- T2I-Adapter
- IP-Adapter (image prompt)
- IP-Adapter FaceID
- InstantID, PuLID (identity preservation)
- Regional prompting
- Inpainting / outpainting
- LoRAs (style, character, concept)
- Textual Inversion
- DreamBooth
- Hypernetworks
- Multi-LoRA composition
- ControlNet variants pour FLUX (Union, etc.)

#### Édition d'images
- InstructPix2Pix
- MagicBrush
- Imagic
- Prompt-to-Prompt
- Null-text inversion
- FLUX Kontext
- Qwen-Image-Edit
- Gemini image edit
- BFL Tools
- DALL-E inpainting

#### UIs / outils
- ComfyUI (node-based)
- Automatic1111 / Forge
- InvokeAI
- SwarmUI
- Fooocus
- Civitai (modèles & LoRAs)

### 8.2 Génération vidéo
- Modèles
  - OpenAI Sora, Sora 2
  - Google Veo (1, 2, 3)
  - Runway (Gen-2, Gen-3, Gen-4)
  - Pika (1, 2)
  - Kling (1, 1.5, 2)
  - Luma Dream Machine / Ray 2
  - Hailuo (MiniMax)
  - Mochi (Genmo)
  - CogVideoX
  - HunyuanVideo
  - Wan / Wan-2 (Alibaba)
  - LTX-Video
  - Stable Video Diffusion
  - AnimateDiff (img → vid)
- Techniques
  - Text-to-video
  - Image-to-video
  - Video-to-video
  - First-last frame conditioning
  - Motion control / camera
  - Lipsync
- Évaluation
  - VBench
  - EvalCrafter
- Considérations
  - Length (s)
  - FPS, resolution
  - Coherence temporelle
  - Coût

### 8.3 Audio & musique
- Musique
  - Suno (v3, v4, v5)
  - Udio
  - MusicGen (Meta)
  - Stable Audio (1, 2, Open)
  - Lyria (Google)
  - Riffusion
  - YuE
  - DiffRhythm
- Sound effects
  - AudioGen
  - AudioLDM
  - ElevenLabs SFX
  - Stable Audio Open
- Speech (voir 3.4)
- Music separation (Demucs, Spleeter)
- Music transcription

### 8.4 Speech en profondeur
- ASR (voir 3.4)
- TTS (voir 3.4)
- Voice cloning
  - XTTS
  - F5-TTS
  - ElevenLabs Voice Lab
  - OpenVoice
- Real-time voice agents
  - LiveKit Agents
  - Pipecat
  - Vapi
  - Retell
  - Daily Bots
  - Vocode
- Métriques
  - WER, CER (ASR)
  - MOS, UTMOS (TTS)
  - SECS (speaker similarity)
- Latency (P95) en voice agents

### 8.5 3D
- NeRF (Neural Radiance Fields)
  - Instant-NGP
  - Nerfstudio
- 3D Gaussian Splatting
  - Original (Kerbl et al.)
  - 4DGS (dynamic)
- Text-to-3D
  - DreamFusion (SDS)
  - Magic3D
  - TripoSR
  - Stable Zero123
  - Meshy
  - Tripo3D
  - Rodin
  - Hyper3D
  - Trellis (Microsoft)
  - InstantMesh
- Image-to-3D
- Mesh generation
- Texture generation

### 8.6 Avatars & humans
- Talking avatars
  - SadTalker
  - HeyGen
  - D-ID
  - Synthesia
  - Hedra
- Lipsync
  - Wav2Lip
  - LatentSync
  - MuseTalk
- Body / motion
  - MotionGPT
  - Animate Anyone
- Video dubbing
- Voice → face animation

### 8.7 World models / interactive
- Genie (Google), Genie 2
- DIAMOND
- Oasis (Decart)
- GameNGen
- World Labs (Fei-Fei Li)
- Mirage (Dynamics Lab)
- Use cases
  - Game generation
  - Robotics simulation
  - Embodied AI

---

## 9. ÉVALUATION

### 9.1 Benchmarks LLM généraux
- MMLU
- MMLU-Pro
- MMLU-Redux
- Big-Bench Hard (BBH)
- HellaSwag
- ARC (Easy, Challenge)
- WinoGrande
- TruthfulQA
- IFEval (instruction following)
- FollowBench
- ZeroSCROLLS
- DROP
- AGIEval
- BBHard
- GPQA, GPQA Diamond
- SimpleQA
- Humanity's Last Exam (HLE)
- ARC-AGI (Chollet)

### 9.2 Reasoning / Math
- GSM8K
- MATH
- AIME (2024, 2025)
- AMC
- Olympiad benchmarks
  - IMO
  - PutnamBench
  - FrontierMath
- MathBench
- TheoremQA
- ProofNet
- minif2f

### 9.3 Code
- HumanEval, HumanEval+
- MBPP, MBPP+
- BigCodeBench
- LiveCodeBench
- CodeContests
- APPS
- SWE-Bench (Lite, Verified, Full)
- SWE-Bench Multimodal
- ClassEval
- DS-1000 (data science)
- HumanEvalPack
- MultiPL-E
- CRUX-Eval
- EvalPlus
- CodeForces ELO
- Aider polyglot benchmark

### 9.4 Long context
- Needle in a Haystack (NIAH)
- Multi-needle NIAH
- RULER
- LongBench (v1, v2)
- InfiniteBench
- ZeroSCROLLS
- BABILong
- LooGLE
- L-Eval
- HELMET
- LongICLBench

### 9.5 Multimodal (Vision)
- MMMU, MMMU-Pro
- MMBench
- SEED-Bench
- MathVista
- ChartQA
- DocVQA
- InfoVQA
- AI2D
- TextVQA
- OCRBench
- POPE (hallucination)
- HallusionBench
- MMVet
- LLaVA-Bench
- MM-Star
- Video-MME
- MVBench
- EgoSchema

### 9.6 Agentic / Tool use
- AgentBench
- GAIA
- WebArena, VisualWebArena
- WorkArena
- WebShop
- Mind2Web
- OSWorld
- WindowsAgentArena
- SWE-Bench (agents de code)
- τ-bench (Tau-bench)
- BFCL (v1, v2, v3)
- ToolBench
- API-Bank
- MLE-Bench
- TheAgentCompany
- Web-Bench

### 9.7 Safety / Alignement
- HarmBench
- AdvBench
- ToxicChat
- BeaverTails
- DoNotAnswer
- XSTest
- TrustLLM
- DecodingTrust
- AIR-Bench
- Anthropic's HH-eval

### 9.8 Multilingue
- MGSM (multilingual GSM)
- XNLI
- XCOPA
- Flores (translation)
- MMLU multilingue
- Belebele
- Global-MMLU

### 9.9 Human evaluation
- LMSYS Chatbot Arena (Elo)
- WildBench
- MT-Bench (Multi-Turn)
- AlpacaEval (v1, v2 - length-controlled)
- Arena-Hard
- ArenaHard-Auto
- HHH (Helpful, Honest, Harmless)
- Side-by-side annotation
- Likert ratings

### 9.10 LLM-as-judge
- Concepts
  - Pointwise (single answer scoring)
  - Pairwise (A vs B)
  - Reference-based
  - Reference-free
- Frameworks
  - G-Eval
  - Prometheus (v1, v2)
  - JudgeLM
  - PandaLM
  - Auto-J
- Biais connus
  - Position bias
  - Verbosity bias
  - Self-enhancement
  - Familiarity bias
- Mitigations
  - Order swapping
  - Multiple judges (jury)
  - Rubric-based
  - Constitutional judge

### 9.11 Évaluation custom
- Golden sets / hand-crafted eval
- Synthetic eval generation
- Rubric design
- Programmatic checks
  - Regex
  - Schema validation
  - Code exec (unit tests)
  - String / JSON match
- Pairwise human preference
- Inter-annotator agreement (Cohen's kappa, Krippendorff's alpha)
- Test set leakage detection
- A/B testing en prod

### 9.12 Outils d'évaluation
- LangSmith (evals & traces)
- Braintrust
- Weave (W&B)
- Phoenix (Arize)
- DeepEval
- Promptfoo
- Inspect AI (UK AISI)
- OpenAI Evals
- EleutherAI lm-evaluation-harness
- HELM (Stanford)
- BIG-Bench
- Vibe-eval
- Confident AI
- Patronus AI
- Galileo

---

## 10. AI ENGINEERING / SYSTÈMES EN PRODUCTION

### 10.1 Architecture d'applications LLM

#### Patterns courants
- Single-call (simple prompt)
- Chain (séquentiel)
- Router (sélection dynamique)
- Map-Reduce
- RAG (voir section 6)
- Agentic loop (voir section 7)
- Workflow (Anthropic patterns)
- Pipeline batch async

#### Composants
- API layer (FastAPI, Express, Next.js routes)
- Orchestration (LangGraph, custom)
- LLM client / abstraction layer
  - LiteLLM
  - OpenRouter (gateway)
  - Portkey
  - Helicone (proxy)
- Queue / message broker
  - Redis (RQ, Celery, BullMQ)
  - RabbitMQ
  - SQS
  - Kafka
- Storage
  - Postgres (state, traces)
  - Object storage (S3, GCS)
  - Vector DB (RAG)
  - Redis (cache)
- Streaming
  - SSE (Server-Sent Events)
  - WebSockets
  - HTTP chunked

#### Durable execution
- Temporal
- Inngest
- Trigger.dev
- Restate
- Hatchet
- Cloudflare Durable Objects
- LangGraph persistence

### 10.2 Caching
- Exact match cache
  - Redis with hash key
- Semantic cache
  - Embedding similarity
  - GPTCache
  - LangChain CacheManager
- Prompt caching (provider-side)
  - Anthropic prompt caching
  - OpenAI prompt caching
  - Gemini context caching
  - Strategies (system, tools, examples)
- KV cache reuse (serveur)
- Application-level caching
- Cache invalidation
- TTL strategies

### 10.3 Observabilité LLM
- Concepts
  - Trace (full request)
  - Span (sub-operation)
  - Generation (LLM call)
  - Tokens (input, output, cached)
  - Cost per call
  - Latency (TTFT, total)
  - Tool calls
- Plateformes
  - LangSmith (LangChain)
  - Langfuse (open-source)
  - Helicone
  - Arize Phoenix
  - Braintrust
  - Weave (W&B)
  - Traceloop / OpenLLMetry
  - Lunary
  - Portkey
  - Athina
  - LangTrace
  - Comet Opik
- Standards
  - OpenTelemetry (OTel) for LLMs
  - OpenInference
  - OpenLLMetry
- Sampling stratégies
  - 100% en dev
  - % en prod selon coût
  - Echec → 100%
- Dashboards
  - Coût par tenant / feature
  - Latence p50/p95/p99
  - Erreur rate
  - Token usage

### 10.4 Guardrails & safety en runtime
- Input filtering
  - PII detection
  - Toxicity classifiers
  - Prompt injection detection
  - Jailbreak detection
- Output filtering
  - Content moderation
  - Topic restrictions
  - PII redaction
  - Hallucination detection
- Outils
  - NVIDIA NeMo Guardrails
  - Guardrails AI (validators)
  - LLM Guard
  - Lakera Guard
  - Protect AI
  - Aporia Guardrails
  - Anthropic API safety filters
  - OpenAI Moderation API
  - Azure Content Safety
  - Google Perspective API
- Structured guardrails
  - Schema validation
  - JSON validation
  - Length limits
- Custom validators

### 10.5 Routing & cascading
- Multi-model routing
  - Task-based routing
  - Cost-based (cheap first)
  - Quality-based (escalation)
- Frameworks
  - RouteLLM
  - NotDiamond
  - Martian
  - Unify
  - OpenRouter
  - LiteLLM router
- Cascading patterns
  - Small → large escalation
  - Confidence-based escalation
  - Verifier-based
- Fallback chains
- Load balancing across providers

### 10.6 Reliability patterns
- Retries (with exponential backoff + jitter)
- Timeouts (per call, total)
- Circuit breakers
- Rate limiting
  - Token bucket
  - Provider quotas
- Graceful degradation
  - Fallback to smaller model
  - Cached fallback
  - Static fallback
- Idempotency
- Dead letter queues
- Provider failover
- Multi-region

### 10.7 Data flywheels
- Logging traces en prod
- Conversion traces → eval datasets
- User feedback
  - Thumbs up/down
  - Explicit edits
  - Implicit signals (retention, follow-ups)
- Annotation workflows
  - Label Studio
  - Argilla
  - Prodigy
  - SuperAnnotate
  - Scale AI / Surge AI / Labelbox
- Human review queues
- Active learning sampling
- Retraining triggers
- Continuous improvement loop

### 10.8 Continuous evaluation
- Production sampling
- Shadow evaluation
- Regression suites
- CI/CD for prompts
  - Prompt versioning
  - PR gates (eval must pass)
- Canary deployments (% traffic)
- A/B testing infrastructure
- Online metrics
  - Task success rate
  - User satisfaction
  - Cost per task
  - Latency
- Drift detection (input distribution)
- Hallucination monitoring

### 10.9 Coût & FinOps pour AI
- Token accounting per request
- Attribution (tenant, feature, user)
- Optimization levers
  - Model choice
  - Caching (prompt + semantic)
  - Batching (async API)
  - Smaller context
  - Output length limits
  - Distillation to smaller model
  - Self-host break-even analysis
  - Quantization
- Pricing tiers
  - Batch API (50% discount)
  - Cache hit pricing
- Forecasting & budgets
- Alerts on anomalies

### 10.10 Deployment patterns
- Canary release
- Shadow deployment
- Blue-Green
- A/B testing
- Feature flags
- Progressive rollout
- Versioned endpoints
- Multi-tenancy
- Edge deployment

### 10.11 Prompt management
- Versioning
- Templates
- A/B test prompts
- Multi-environment (dev/staging/prod)
- Outils
  - LangSmith Prompt Hub
  - Langfuse Prompts
  - PromptLayer
  - Helicone Prompts
  - Pezzo
- Programmatic optim (DSPy)

---

---

> *(Section 11 INFRASTRUCTURE GPU & SCALE volontairement omise — voir docs NVIDIA / PyTorch Distributed / Megatron / DeepSpeed pour ces sujets.)*

---

## 12. SÉCURITÉ & ROBUSTESSE (technique)

### 12.1 Prompt injection
- Direct injection
- Indirect injection (via documents, web pages, tool outputs)
- Multi-turn injection
- Multi-step / composite attacks
- Image-based injection (visual prompt injection)
- Goal hijacking
- Data exfiltration via injection
- Tool abuse
- Examples & taxonomies (OWASP LLM Top 10)

### 12.2 Jailbreaking
- Techniques classiques
  - DAN ("Do Anything Now")
  - Persona / role-play
  - Hypothetical framing
  - Reverse psychology
  - "Grandma exploit"
- Encoding-based
  - Base64
  - ROT13
  - Caesar cipher
  - Leetspeak
  - Pig Latin
- Adversarial suffixes (GCG)
- Multi-turn / crescendo
- Many-shot jailbreaking
- Cipher / language switching
- Token smuggling
- Visual jailbreaks (VLMs)
- Prefix injection
- Refusal suppression
- Automated red-team (PAIR, TAP)

### 12.3 Data exfiltration
- Prompt leaking
- System prompt extraction
- Tool config leaking
- Training data extraction
  - Membership inference
  - Extraction attacks (Carlini et al.)
- Sidechannel via tool outputs
- Markdown injection (rendered links / images)
- Indirect channels (URLs in outputs)

### 12.4 Adversarial robustness
- Vision adversarial
  - FGSM
  - PGD
  - C&W
  - Universal Adversarial Patches
  - Adversarial glasses
- Text adversarial
  - TextFooler
  - BERT-Attack
  - Character-level perturbations
- Multimodal adversarial (image → manipule VLM)
- Defenses
  - Adversarial training
  - Randomized smoothing
  - Input preprocessing

### 12.5 Model security
- Model extraction / stealing
- Model inversion
- Membership inference attacks
- Backdoor attacks
  - Data poisoning
  - Trojaned models
  - Sleeper Agents (Anthropic)
- Trigger detection
- Supply chain
  - Malicious model weights
  - Pickle file exploits
  - Compromised packages
- Safetensors (safe format)

### 12.6 Defenses
- Input
  - Sanitization
  - Anomaly detection
  - Injection classifiers (PromptGuard, Lakera)
- Output
  - Content filters
  - PII redaction
  - URL / link stripping
  - Markdown rendering controls
- Architecture
  - Capability isolation (least privilege)
  - Sandboxed tools
  - Spotlighting / data marking
  - StruQ (structured queries)
  - Dual LLM (privileged + quarantined)
- Training-time
  - Adversarial training
  - Constitutional AI / RLHF
  - Safety SFT
- Monitoring
  - Anomaly detection in traces
  - Unusual tool calls
  - Cost spikes

### 12.7 Red teaming
- Manual red teaming
- Automated red teaming
  - Garak (NVIDIA)
  - PyRIT (Microsoft)
  - HarmBench
  - LangTest
- Crescendo / multi-turn
- Adversarial training data generation
- Capability evaluations
- Dangerous capability evals (CBRN, cyber, autonomy)

### 12.8 Standards & frameworks
- OWASP LLM Top 10
- MITRE ATLAS (Adversarial Threat Landscape for AI Systems)
- NIST AI Risk Management Framework
- AI safety institutes (UK AISI, US AISI)

---

*Fin du document.*
