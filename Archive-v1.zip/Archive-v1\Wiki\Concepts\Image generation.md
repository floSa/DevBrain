---
galaxie: wiki
nom: Image generation
alias: [text-to-image, SD, FLUX, Midjourney, ControlNet, DreamBooth]
type: concept
categorie: concept/multimodal
sous_categories: [image-gen, t2i, diffusion, control]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Rombach 2022, Esser 2024 (SD3), Black Forest Labs (FLUX)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, multimodal, image-generation, diffusion]
---

# Image generation (text-to-image)

## TL;DR

Génération d'images depuis texte (et autres signaux). Stack 2026 : [[Diffusion models]] dominent (FLUX, SD3, SDXL, DALL-E, Midjourney, Imagen). Control fine via **LoRAs** (style, character), **ControlNet** (pose, depth, canny), **IP-Adapter** (image prompts), **InstantID** (identity preservation), **DreamBooth** (custom subjects). Acceleration : **LCM/Turbo/Lightning** (4 steps), distillation. UIs : **ComfyUI** (node-based, power user), **Automatic1111/Forge** (webui), **InvokeAI**, **Fooocus**. Hosting : **Replicate, Modal, RunPod, Fal.ai**.

## Le problème

Générer images photoréalistes / stylisées / éditées depuis text prompts. Avant 2022, GANs (StyleGAN) → instable, hard. Depuis Stable Diffusion (2022), démocratisation totale.

## L'idée

### Pipeline standard

```
[Text prompt]
   │
   ▼
[Text encoder]  (CLIP / T5)
   │
   ▼ + [random noise latent]
[Diffusion model]  (U-Net or DiT)
   │ ×N denoising steps
   ▼
[Latent]
   │
   ▼
[VAE decoder]
   │
   ▼
[Image]
```

Voir [[Diffusion models]] pour théorie.

### Modèles clés 2026

#### Open-source

| Modèle | Caractéristiques |
|---|---|
| **SDXL** | base solide, beaucoup de LoRAs / ControlNets |
| **SDXL Turbo / Lightning** | 1-4 steps |
| **SD3 / 3.5** | MMDiT, meilleur text rendering |
| **FLUX.1 Schnell** | distilled, 4 steps, open |
| **FLUX.1 Dev** | non-distilled, qualité++, non-commercial |
| **FLUX.1 Pro** | API only, best FLUX |
| **HiDream** | recent, alternative |
| **Janus-Pro** | DeepSeek, multimodal native |
| **AuraFlow, PixArt-α/Σ** | alternatives community |

#### Closed-source

| Modèle | Notes |
|---|---|
| **DALL-E 3** | OpenAI, ChatGPT integrated |
| **GPT-Image-1** | OpenAI 2024, native multimodal |
| **Midjourney v6/v7** | aesthetic, Discord |
| **Imagen 3, 4** | Google |
| **Ideogram v1/v2/v3** | text rendering best |
| **Recraft v3** | infographics, design |
| **Playground v3** | open community |
| **Adobe Firefly** | enterprise-safe |
| **Reve, Krea** | newer |
| **Nano Banana / Gemini Image** | Google integrated |

### Control mechanisms

#### LoRA

PEFT (cf. [[PEFT]]) pour style, character, concept :

```python
pipe.load_lora_weights("style-anime-v1.safetensors")
image = pipe("a samurai <lora:anime:1.0>").images[0]
```

Civitai = community marketplace.

#### Textual Inversion

Apprend un embedding pour un concept. 1-5 images. Léger.

#### DreamBooth

Fine-tune le modèle complet sur 3-5 images de ton sujet. Plus puissant que TI mais lourd.

#### ControlNet (Zhang 2023)

Conditionner sur :
- **Canny** edges
- **Depth** map
- **OpenPose** skeleton
- **Segmentation** masks
- **Normal** maps
- **Scribble**, **MLSD**, **Lineart**, **Soft edge**, **Tile**

```python
controlnet = ControlNetModel.from_pretrained("controlnet-canny")
pipe = StableDiffusionControlNetPipeline.from_pretrained(model_id, controlnet=controlnet)
image = pipe("a cyberpunk city", image=canny_image).images[0]
```

Variants pour FLUX : Union ControlNet, etc.

#### T2I-Adapter

Alternative léger à ControlNet.

#### IP-Adapter

**Image prompt** : conditionner sur une image (style, sujet).

#### IP-Adapter FaceID, InstantID, PuLID

**Identity preservation** : 1 photo → personne réutilisée dans nouvelles scenes. Très utilisé pour avatars, marketing.

#### Regional prompting

Différents prompts pour différentes régions de l'image.

#### Inpainting / outpainting

Generate dans une **zone masquée** d'une image existante.

```python
from diffusers import StableDiffusionInpaintPipeline
pipe = StableDiffusionInpaintPipeline.from_pretrained(...)
output = pipe(prompt="a cat", image=base_image, mask_image=mask)
```

Outpainting = inpaint sur extension de l'image.

### Édition d'images

#### InstructPix2Pix

"Add a hat" + image → image éditée.

#### MagicBrush

Similar, more controllable.

#### FLUX Kontext (Black Forest Labs)

Édition fine via FLUX. SOTA 2024.

#### Qwen-Image-Edit

Open-source édition.

#### Gemini Image Edit

Google native.

#### DALL-E inpainting

OpenAI.

### Prompting

#### Prompt structure

```
[Subject], [style], [details], [lighting], [composition], [quality boosters]
```

Ex : "A red dragon, anime style, intricate details, dramatic lighting, side view, masterpiece, 8k"

#### Negative prompts

"ugly, blurry, low quality, deformed, watermark"

#### Weights

`(red:1.3)` = boost importance.

#### Concept embeddings

`<lora:style-anime:0.8>` = activate LoRA.

### Acceleration

#### LCM (Latent Consistency)

4 steps. Bonne qualité.

#### Lightning, Turbo

1-8 steps via adversarial distillation.

#### DMD2

Distribution Matching Distillation v2. SOTA recent.

#### Hyper-SD

Better distillation.

### UIs

#### ComfyUI

**Node-based**. Power user. Customizable workflows. **Standard pour pros**.

#### Automatic1111 / Forge / Forge2

WebUI gradio. Pour LoRA testing, simple.

#### InvokeAI

Cleaner UI, project-based.

#### Fooocus

Simplified, beginner-friendly.

#### SwarmUI

Multi-backend.

#### Civitai

Community : models, LoRAs, prompts.

### Hosting / API

| Provider | Notes |
|---|---|
| **Replicate** | API marketplace |
| **Modal** | Custom containers |
| **RunPod** | GPU rental |
| **Fal.ai** | Fast inference |
| **Together AI** | Open models |
| **Anthropic** | (text-only, pas d'image gen) |
| **OpenAI DALL-E API** | |
| **Stability AI API** | SD |
| **Black Forest Labs API** | FLUX Pro |

### Workflow typique production

```
1. Choose model (SDXL Lightning for speed, FLUX Dev for quality)
2. Build prompt + negative prompt
3. Optionally : ControlNet for layout, IP-Adapter for style
4. Generate (4-30 steps depending on model)
5. Upscale (Real-ESRGAN, RealESR)
6. Face restoration (CodeFormer, GFPGAN) si needed
7. Post-process (color correction)
```

### Best practices

1. **Choose right model** : FLUX Pro pour qualité ; SDXL Lightning pour speed
2. **Detailed prompts** : ne pas vague
3. **Negative prompts** : indispensable pour qualité
4. **ControlNet** pour layout strict
5. **LoRA** pour style cohérent (brand, projet)
6. **DreamBooth** pour character / product specific
7. **Iterate on prompts** : Civitai pour inspiration
8. **Eval batch** : 4-8 samples, choisir best
9. **Seed control** : reproducibility
10. **Watermark / license check** sur output

## Quand c'est utile

- **Marketing / advertising** : génér visuals
- **Product mockups** : items in scenes
- **Concept art** : ideation rapide
- **Design** : variations, exploration
- **Blog / social media** : illustrations
- **Game dev** : assets, concept art
- **Educational** : diagrams, illustrations
- **Personal** : avatars, art
- **A/B testing creative** : variations
- **Synthetic data** : augmentation pour ML

## Quand ça ne marche pas / pièges

- **Hands / fingers** : digits often wrong
- **Faces in crowds** : distorted
- **Text dans l'image** : sauf SD3+, FLUX, Ideogram
- **Compositional** : "X next to Y" fails
- **Counting** : > 3-4 wrong
- **Brand assets** : need fine-tune / DreamBooth
- **Specific poses** : need ControlNet
- **Copyrights ambigus** : training data
- **NSFW / deepfakes** : ethics + legal
- **Watermarks** : modèles reproducent watermarks training
- **Iterative refinement hard** : prompt → image → tweak → re-generate, no easy "edit this" without tools
- **Cost** : FLUX Pro $0.05-0.10 / image, ajoute up

## Code minimal

```python
# Voir aussi [[Diffusion models]] code

# 1. FLUX.1 dev (open, qualité)
from diffusers import FluxPipeline
import torch

pipe = FluxPipeline.from_pretrained("black-forest-labs/FLUX.1-dev",
                                     torch_dtype=torch.bfloat16).to("cuda")
prompt = "A red dragon flying over a medieval castle, dramatic lighting, intricate scales"
image = pipe(prompt, num_inference_steps=50, guidance_scale=3.5,
              height=1024, width=1024, generator=torch.Generator("cuda").manual_seed(42)).images[0]
image.save("dragon.png")

# 2. SDXL avec LoRA
from diffusers import StableDiffusionXLPipeline
pipe = StableDiffusionXLPipeline.from_pretrained("stabilityai/stable-diffusion-xl-base-1.0",
                                                  torch_dtype=torch.float16).to("cuda")
pipe.load_lora_weights("./my-anime-lora.safetensors")
image = pipe("a samurai <lora:anime:1.0>", negative_prompt="blurry, low quality").images[0]

# 3. ControlNet (pose conditioning)
from controlnet_aux import OpenposeDetector
from diffusers import StableDiffusionXLControlNetPipeline, ControlNetModel

openpose = OpenposeDetector.from_pretrained("lllyasviel/Annotators")
pose_image = openpose(reference_image)

controlnet = ControlNetModel.from_pretrained("thibaud/controlnet-openpose-sdxl-1.0",
                                              torch_dtype=torch.float16)
pipe = StableDiffusionXLControlNetPipeline.from_pretrained(model_id, controlnet=controlnet)
image = pipe("knight in armor", image=pose_image).images[0]

# 4. IP-Adapter (image style transfer)
pipe.load_ip_adapter("h94/IP-Adapter", subfolder="sdxl_models", weight_name="ip-adapter-plus_sdxl_vit-h.safetensors")
image = pipe(prompt="a portrait", ip_adapter_image=reference_style).images[0]

# 5. Inpainting
from diffusers import StableDiffusionInpaintPipeline
pipe = StableDiffusionInpaintPipeline.from_pretrained(...)
output = pipe(prompt="a red hat", image=base_image, mask_image=mask)

# 6. Replicate API (managed)
import replicate
output = replicate.run(
    "black-forest-labs/flux-dev",
    input={"prompt": "A serene landscape", "num_inference_steps": 50}
)

# 7. OpenAI DALL-E 3
from openai import OpenAI
client = OpenAI()
response = client.images.generate(
    model="dall-e-3",
    prompt="A cyberpunk cat",
    size="1024x1024",
    quality="hd",
    n=1
)

# 8. FAL.ai (fast inference)
import fal_client
result = fal_client.run("fal-ai/flux/dev", arguments={
    "prompt": "...",
    "image_size": "landscape_16_9"
})

# 9. ComfyUI workflow API
# import requests
# r = requests.post("http://localhost:8188/prompt", json={"prompt": comfy_workflow})
```

## Pour aller plus loin

- Rombach et al., *High-Resolution Image Synthesis with Latent Diffusion Models* (CVPR 2022)
- Zhang et al., *Adding Conditional Control to Text-to-Image Diffusion Models* (ControlNet, ICCV 2023)
- Esser et al., *Scaling Rectified Flow Transformers for High-Resolution Image Synthesis* (SD3, ICML 2024)
- Ye et al., *IP-Adapter* (2023)
- Wang et al., *InstantID: Zero-shot Identity-Preserving Generation in Seconds* (2024)
- Ruiz et al., *DreamBooth* (CVPR 2023)
- *Diffusers* library docs
- *Civitai* — community models / LoRAs
- *ComfyUI* documentation
- *Black Forest Labs* (FLUX) blog
- **Liens internes** : [[Diffusion models]], [[PEFT]] (LoRA), [[embeddings]], [[Vision Language Models]]
