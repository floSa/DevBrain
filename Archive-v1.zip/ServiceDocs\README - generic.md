# Service — <NOM_DU_SERVICE>

<!--
Template GÉNÉRIQUE — à utiliser si le service ne rentre dans aucune des catégories spécifiques :
- README - database-relational.md (Postgres, MySQL, ...)
- README - database-vector.md (Qdrant, Weaviate, ...)
- README - database-graph.md (Neo4j, Nebula, ...)
- README - storage-object.md (MinIO, S3, ...)
- README - orchestration-data.md (Dagster, Airflow, ...)
- README - llm-orchestration.md (LangChain, LangGraph, ...)
- README - document-processing.md (Docling, OCR, ...)

Référence règle : Rules/Documentation/README - Service.md du DevBrain.
-->

## Rôle métier

<À REMPLIR : 2-4 lignes — ce que ce service fait pour l'application.>

## Contrat d'interface

<À REMPLIR : ce que le service expose, les endpoints / méthodes / events.>

```python
# Signatures principales
def example_method(arg: Type) -> ReturnType: ...
```

## Dépendances

- **En amont (services dont il dépend)** : <liste avec wikilinks devbrain>
- **En aval (services qui en dépendent)** : <liste>

## Configuration

| Variable | Type | Défaut | Description |
|----------|------|--------|-------------|
| `<À REMPLIR>` |  |  |  |

Voir aussi `.env.example` à la racine du projet (cf. règle [[Config-Env]]).

## Démarrage local

```bash
# Commandes pour lancer ce service en local
docker-compose up -d <service>
# ou
uv run python -m services.<nom>.main
```

## Tests

```bash
uv run pytest tests/unit/services/<nom>/
uv run pytest tests/integration/test_<nom>.py
```

## Pièges connus à anticiper

<À REMPLIR : liste courte. Lien vers `Bugs/REX - <Service>.md` du DevBrain si applicable.>

## Liens

- DevBrain : [[<À REMPLIR : nom de la fiche Service>]] · [[REX - <À REMPLIR>]] (s'il existe)
- Doc officielle : <URL>
- Issues : <lien GitHub si applicable>

---

> 💡 Si ce service mériterait son template dédié (catégorie qui revient souvent), créer un nouveau template dans `Templates/ServiceDocs/` et une règle correspondante dans `Rules/Documentation/`.
