---
galaxie: wiki
nom: Decision Intelligence
alias: [decision-intelligence, DI, decision automation, augmented decision]
type: concept
categorie: concept/business-rules
sous_categories: [decision-intelligence, decision-management, ml-rules, hybrid-ai, decision-automation]
domaines: [data-science, ml-eng, ai-eng]
maturite: emerging
auteurs_cles: [Lorien Pratt 2019 (livre "Link"), Gartner (catégorie DI), James Taylor]
lecture_min: 8
created: 2026-05-21
modified: 2026-05-21
tags: [concept, decision-intelligence, hybrid-ai, dmn, mlops]
---

# Decision Intelligence

## TL;DR

**Décision Intelligence (DI)** : pratique et catégorie d'outils qui visent à **augmenter / automatiser les décisions opérationnelles** en combinant **3 ingrédients** :
1. **Règles métier explicites** (DMN, BRMS)
2. **Modèles prédictifs ML** (scoring, classification, forecasting)
3. **Humain dans la boucle** (override, validation, supervision)

Cadre théorisé par **Lorien Pratt** (2019, *"Link"*), promu par **Gartner** comme catégorie distincte (DI Platforms). Concrètement : un système qui prend une décision = `ML predict + business rules + human gates`, traçable et auditable. La DI est l'**umbrella** qui réunit BRMS (Business Rules Management Systems), MLOps et BPM pour des décisions opérationnelles automatisées (souscription, scoring, pricing dynamique, fraude, allocation ressources).

## Le problème

Les architectures "ML-only" ou "rules-only" ont chacune leurs faiblesses :

| Approche | Force | Faiblesse |
|---|---|---|
| **Pure ML** | s'adapte aux patterns, scaling | boîte noire, pas auditable, dérive silencieuse |
| **Pure rules (BRMS/DMN)** | auditable, déterministe | rigide, demande des analystes pour chaque cas |
| **Pure humain** | jugement nuancé | lent, non scalable, inconsistant |

Le monde réel demande souvent les 3 : un score ML pour la rapidité, des règles métier pour la conformité, un humain pour les bordures.

**Decision Intelligence** est le **cadre de pensée** qui assume cette composition explicite, plutôt que d'opposer "AI vs rules".

## L'idée

### Le modèle Pratt — Causal Decision Diagram (CDD)

Lorien Pratt propose un **CDD** (Causal Decision Diagram) : un graphe où on rend explicites :

```
   [Décision]
       │
       │ cause
       ▼
   [Intermediate outcomes] ←─── [External factors]
       │
       │ cause
       ▼
   [Final outcome (KPI)]
```

On part de l'**outcome désiré** (e.g. "réduire les défauts de paiement de 5%") et on remonte aux **décisions** qu'on peut prendre (qui octroyer, quel montant, à quel taux). Chaque arc est annoté avec son **mécanisme causal** (donné par règle, par modèle ML, ou par hypothèse à valider).

Concept proche : **decision modeling causal**, lien avec [[Bayesian inference]] et inference causale.

### Le triangle DI

```
            [Règles métier]
           (DMN, BRMS, FEEL)
                  │
                  │ contraintes,
                  │ conformité
                  │
   [ML models] ───┼─── [Humain]
   (prédictions,  │    (override,
    scoring,      │     validation,
    classif)      │     supervision)
                  │
              [Décision]
```

3 sources contribuent à la décision finale, orchestrées par une plateforme.

### Patterns d'intégration

#### Pattern 1 — Rules orchestrent ML

Le plus courant en banque/assurance. Une **DMN decision table** prend en input le **score ML** et applique des règles métier dessus :

```feel
// Decision table "Octroi"
| score_ml      | revenu      | → décision       |
|---------------|-------------|------------------|
| > 0.85        | -           | "auto-approve"   |
| [0.5..0.85]   | > 50000     | "approve"        |
| [0.5..0.85]   | <= 50000    | "manual review"  |
| < 0.5         | -           | "auto-reject"    |
```

Le ML donne une probabilité, les règles définissent les **seuils**, les **exceptions** (clients VIP), les **gates humains** (manual review).

#### Pattern 2 — ML feeds DMN inputs

Un pipeline calcule des features ML (via [[Feast]], Tecton ou maison), passe les outputs au moteur DMN comme inputs :

```
Feature store → ML model → score
                              ↓
                  DMN inputs : {score, customer_data, market}
                              ↓
                         DMN engine
                              ↓
                         décision finale
                              ↓
                  action (approve / reject / route)
```

#### Pattern 3 — DMN + ML en parallèle, override humain

Le ML fait une **première prédiction**, la DMN fait sa **décision règles-only**. Si les deux sont d'accord → auto. Sinon → humain.

```
   ┌──ML predict──→ score_ml ─┐
   │                            │
inputs                          ├─→ orchestrator
   │                            │      │
   └──DMN rules──→ dec_rules ─┘      ├──→ agree   ──→ auto
                                     │
                                     └──→ disagree ──→ human review
```

Utile pour les phases de **shadow ML deployment** : valider que le ML décide comme les règles avant de l'autonomiser.

#### Pattern 4 — Continuous learning loop

Les décisions humaines (review, override) alimentent un dataset pour **re-entraîner le ML**. Les overrides révèlent les biais des règles ou du modèle. C'est la **boucle apprenante**.

### Plateformes DI commerciales

- **Decision-management leaders** historiques : FICO, IBM ODM, SAS Decision Manager, Pegasystems, Red Hat Decision Manager
- **Camunda 8** se positionne sur DI avec BPMN + DMN + Tasklist
- **Trisotech** vend une "Decision Automation Platform" L3
- **InRule**, **Sparkling Logic**, **OpenRules** — plateformes DI dédiées
- **Acteurs cloud** : AWS, GCP, Azure ont des composants (AWS Step Functions + SageMaker, GCP Vertex AI + Workflows) mais sans le standard DMN au cœur

Pour DI **open-source** : Camunda Platform 8 (community) + Drools / KIE Server, parfois combinés avec [[Prefect]] / [[Dagster]] pour le ML side.

### Gouvernance Decision Intelligence

Plus mature qu'une simple "use ML" :
- **Decision catalog** : inventaire des décisions automatisées de l'entreprise, leur owner, leur SLA
- **Audit trail** : pour chaque décision, trace de quelle règle / quel modèle a contribué
- **Performance metrics** : KPI business mappés aux décisions (taux d'approbation, taux d'override humain, drift)
- **Model risk management** : DI Platforms aident à documenter les modèles (validation, monitoring) — utile pour conformité Bâle, MIFID, AI Act
- **Versioning** : règles et modèles versionnés ensemble, déployables atomiquement
- **A/B testing de décisions** : DI Platforms supportent souvent des challenger models / challenger rules

### DI vs MLOps

Confusion fréquente. Distinction :

| MLOps | Decision Intelligence |
|---|---|
| Cycle de vie d'un **modèle** ML | Cycle de vie d'une **décision** automatisée |
| Train / deploy / monitor / retrain | Define / decide / execute / audit / improve |
| Focus : performance modèle | Focus : valeur business de la décision |
| KPI : accuracy, AUC, drift | KPI : business outcome (revenus, taux fraude, NPS) |
| Outils : MLflow, W&B, KServe | Outils : Camunda, Drools, FICO |

**MLOps + DI** : MLOps fournit les **modèles** que la DI **orchestre dans des décisions**.

### Régulation et explainability

Le contexte régulatoire récent (AI Act EU, RGPD Article 22 "decision automatisée significative") pousse à expliciter :
- **Quel système** a pris la décision (model + règles)
- **Quels inputs** ont contribué
- **Quel humain** peut être saisi pour recours

La DI répond exactement à ce besoin par construction (audit trail, règles explicites, gates humains). Voir [[Explainability and decision automation]].

### Lien avec [[Reinforcement learning]] et bandits

DI inclut historiquement les **règles + ML supervisé**. Front actif : intégrer des **bandits contextuels** et du **reinforcement learning** dans le triangle DI.

Exemple : pricing dynamique
- **Règles** : prix min / max légal, marges produit
- **ML supervisé** : prédire demande à chaque prix
- **Bandits / RL** : explorer le pricing optimal en ligne

C'est l'évolution actuelle des **DI Platforms** : passer de "rules + ML supervisé statique" à "rules + ML + apprentissage continu".

## Quand c'est utile

- **Décisions opérationnelles à haut volume** : milliers / millions / jour
- **Combine règles métier + ML** (banque, assurance, e-commerce, telco, santé)
- **Conformité réglementaire forte** : besoin d'audit + recours humain
- **Stratégie data-driven mature** : tu as ML en prod, tu veux le combiner avec des règles métier auditables
- **Décisions à valeur business mesurable** : tu peux mapper la décision à un KPI business
- **Évolution depuis BRMS** : tu as déjà une plateforme de règles, tu veux y ajouter du ML
- **Évolution depuis MLOps** : tu as déjà du ML en prod, tu veux des règles autour pour le trust

## Quand ça ne marche pas / pièges

- **Sur-engineering** : DI Platforms coûteuses (5-6 chiffres / an) — pas justifié si < 10 décisions automatisées
- **DI sans owner business** : projet IT pur = échec, il faut un business owner par catégorie de décision
- **Catalogue de décisions inexistant** : sans inventaire, tu ne sais pas ce qui est automatisé, pas de gouvernance
- **Buzzword DI sans pratique** : Gartner a poussé le terme, certains vendors badgent "DI" leur ancien BRMS sans réel apport
- **Rules vs ML guerre intestine** : équipes IT/business et data science se disputent au lieu de combiner — DI nécessite culture collaborative
- **Causal Decision Diagram superficiel** : faire le CDD = exercice utile mais ne dispense pas de la rigueur ensuite
- **Pas de boucle d'amélioration** : déployer DI puis ne jamais regarder = dégradation invisible
- **Plateforme propriétaire fermée** : lock-in fort (FICO, Pegasystems) — préférer standards ouverts (DMN, BPMN) pour migration future
- **Confondre DI et data science** : DI = automatiser décisions opérationnelles, data science = explorer / découvrir. Disciplines complémentaires mais distinctes
- **Pas de gates humains** : full automation sans recours = problème éthique + légal (AI Act, RGPD Art 22)

## Code minimal

### Architecture DI simplifiée (Python orchestrator)

```python
# Pipeline DI : ML predict → DMN evaluate → human gate
import requests
from pyDMNrules import DMN

# 1. ML model (déjà déployé, e.g. via FastAPI + KServe)
def predict_credit_score(features: dict) -> float:
    resp = requests.post("http://ml-service/predict", json=features)
    return resp.json()["score"]

# 2. DMN engine (rules)
dmn = DMN("credit_decision_rules.xlsx")

def make_decision(customer: dict, request: dict) -> dict:
    # Étape 1 : score ML
    features = extract_features(customer, request)
    score = predict_credit_score(features)

    # Étape 2 : DMN avec score ML comme input
    dmn_inputs = {
        "score_ml": score,
        "income": customer["income"],
        "amount_requested": request["amount"],
        "is_vip": customer["tier"] == "VIP",
    }
    status, dmn_output = dmn.decide(dmn_inputs)

    decision = dmn_output["decision"]  # "auto-approve" | "approve" | "manual_review" | "reject"

    # Étape 3 : human gate si nécessaire
    if decision == "manual_review":
        ticket_id = create_review_ticket(customer, request, score, dmn_output)
        return {"decision": "pending_human", "ticket": ticket_id}

    return {
        "decision": decision,
        "ml_score": score,
        "rules_applied": dmn_output.get("rules_fired"),
        "audit_id": log_decision(customer, request, score, dmn_output),
    }
```

### Audit trail structure

```python
{
  "decision_id": "dec_2026_05_21_xyz",
  "timestamp": "2026-05-21T14:32:11Z",
  "customer_id": "C-12345",
  "inputs": {...},
  "ml": {
    "model_id": "credit_v3.2",
    "model_version": "2026-05-01",
    "features_hash": "...",
    "score": 0.78,
    "explanation": {"top_features": ["income", "history", "age"]}
  },
  "rules": {
    "dmn_model_id": "credit_decision_v12",
    "fired_rules": ["r2", "r5", "r9"],
    "hit_policy": "UNIQUE"
  },
  "human": null,  // ou {"reviewer": "...", "override": "...", "reason": "..."}
  "outcome": "approve",
  "downstream_action": "create_loan_offer_12345"
}
```

### Decision catalog (YAML)

```yaml
decisions:
  - id: credit_approval
    owner: head_of_credit
    sla: "< 2 seconds (auto) ; < 24h (human review)"
    volume_per_day: 5000
    components:
      ml_model: credit_scoring_v3
      dmn_model: credit_decision_v12
      human_review_pool: credit_officers
    kpis:
      - auto_approval_rate
      - human_override_rate
      - default_rate_30d
    last_audit: 2026-05-01

  - id: fraud_detection
    owner: head_of_risk
    sla: "< 100ms"
    volume_per_day: 100000
    components:
      ml_model: fraud_xgboost_v8
      dmn_model: fraud_rules_v5
    kpis: [precision, recall, false_positive_rate]
```

## Pour aller plus loin

- Lorien Pratt, *Link: How Decision Intelligence Connects Data, Actions, and Outcomes for a Better World* (2019) — livre fondateur
- Pratt's CDD framework site : https://www.lorienpratt.com/
- Gartner Decision Intelligence Platform reports (payants)
- James Taylor, *Digital Decisioning: Using Decision Management to Deliver Business Impact* (2019)
- DMN community : https://dmn-community.com/
- **Liens internes** : [[Decision Model and Notation]], [[Decision Tables]], [[BPMN DMN CMMN]], [[DMN and ML hybrid]], [[Explainability and decision automation]], [[Reinforcement learning]], [[Multi-armed bandits]]
