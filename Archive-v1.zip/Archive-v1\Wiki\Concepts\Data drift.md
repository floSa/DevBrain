---
galaxie: wiki
nom: Data drift
alias: [data drift, concept drift, covariate shift, distribution shift, KS test, PSI]
type: concept
categorie: concept/ml-ops
sous_categories: [drift, monitoring, ml-ops, production]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Gama et al. 2014]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml-ops, monitoring, drift, production]
---

# Data drift

## TL;DR

Le **monde change**, les features changent, parfois la relation feature → cible change. Trois drifts à monitorer en prod : **covariate shift** ($p(X)$ change, $p(Y|X)$ stable), **label shift** ($p(Y)$ change), **concept drift** ($p(Y|X)$ change — le plus tueur). Détecter par tests stats (**KS**, **Chi²**), métriques de distribution (**PSI**, **Population Stability Index**), **Wasserstein**, ou comparer perf modèle référence vs récent. Sans monitoring drift, un modèle déployé décline silencieusement. Standard chez Evidently, NannyML, Arize, Fiddler.

## Le problème

Un modèle ML est entraîné sur des données historiques sous hypothèse i.i.d. **En prod, le monde évolue** :
- Comportements users changent (COVID, modes, économie)
- Nouvelles features (saison, produit, version app)
- Nouvelle population utilisateur (expansion géo)
- Cible elle-même change de définition

Le modèle continue à produire des prédictions, mais sa performance **dégrade silencieusement**. Comment **détecter** et **agir** ?

## L'idée

### Taxonomie

Soit $P_{\text{train}}(X, Y)$ et $P_{\text{prod}}(X, Y)$.

#### Covariate shift (data drift)

$$ P_{\text{train}}(X) \neq P_{\text{prod}}(X), \quad P(Y|X) \text{ stable} $$

**Exemple** : modèle de credit scoring entraîné sur 2019, déployé pendant COVID → distribution des revenus change, mais "revenu élevé = crédit ok" reste vrai.

Le modèle reste **conceptuellement correct**, mais peut être sous-calibré sur les nouvelles régions de l'espace input.

#### Label shift (prior shift)

$$ P_{\text{train}}(Y) \neq P_{\text{prod}}(Y), \quad P(X|Y) \text{ stable} $$

**Exemple** : modèle de fraud detection — taux de fraude augmente (de 1% à 5%) — la distribution des features de fraude reste, mais la proportion change.

Le modèle reste correct par classe mais sa **calibration globale** est fausse.

#### Concept drift (model decay)

$$ P_{\text{train}}(Y|X) \neq P_{\text{prod}}(Y|X) $$

**Le plus dangereux** : la relation entre features et cible elle-même change.

**Exemple** : modèle de churn → COVID change les raisons de churn → mêmes features prédisent différemment.

Le modèle **devient faux** sur les patterns appris.

### Types de drift dans le temps

| Type | Comportement |
|---|---|
| **Sudden** | shift abrupt (COVID, lancement produit) |
| **Gradual** | dérive lente (vieillissement des users) |
| **Incremental** | drift par étapes |
| **Recurring / seasonal** | revient cycliquement (saisons) |

### Détection — covariate shift (sur les features)

#### 1. Tests statistiques univariés

**KS test** (Kolmogorov-Smirnov) sur continues :

$$ D = \sup_x |F_{\text{train}}(x) - F_{\text{prod}}(x)| $$

p-value < α → distributions différentes.

**Chi²** sur catégorielles : test d'indépendance entre train/prod et catégorie.

**Limite** : sensible avec gros volume → tout devient "significatif". Préférer effect size.

#### 2. PSI (Population Stability Index)

Standard en credit risk, marketing :

$$ \text{PSI} = \sum_i (P_i^{\text{prod}} - P_i^{\text{train}}) \cdot \ln\left(\frac{P_i^{\text{prod}}}{P_i^{\text{train}}}\right) $$

avec $P_i$ = fraction des observations dans le bucket $i$ (discrétisation).

**Interprétation** :
- PSI < 0.1 : stable
- 0.1 ≤ PSI < 0.25 : drift modéré
- PSI ≥ 0.25 : drift significatif

Robuste, interprétable, standard.

#### 3. Wasserstein / Earth Mover's

Distance entre deux distributions. Voir [[Wasserstein distance]].

Plus stable que KS pour distributions multi-modales.

#### 4. Multivariate methods

Tests univariés feature-par-feature → loupent les **drifts de corrélation**.

- **MMD** (Maximum Mean Discrepancy) : test multivariate non-paramétrique (RKHS)
- **Adversarial classifier** : train classifier "train vs prod" → AUC élevée = drift
- **PCA + comparaison** : projeter dans espace réduit, comparer

### Détection — concept drift (sur le modèle)

#### 1. Performance monitoring

Si **labels arrivent rapidement** (ground truth disponible en prod) : suivre AUC / MAE / accuracy sur fenêtres glissantes. Dégradation = drift.

**Problème** : labels lents (e.g. churn confirmé à 6 mois) → ne peut pas détecter en temps réel.

#### 2. Proxy metrics quand labels absents

- **Predicted distribution drift** : la distribution des prédictions du modèle change
- **Confidence distribution** : modèle devient moins confiant
- **Feature importance shift** : importances change sur slice récent
- **Output calibration** : check sur les seuils décisionnels

#### 3. Sequential testing

CUSUM, Page-Hinkley : détection online de change point sur la performance.

#### 4. NannyML (CBPE — Confidence-Based Performance Estimation)

Estime la performance prod **sans labels** : utilise les probas du modèle + DRE (Direct Reverse Estimation). Standard récent.

### Stratégies de réponse

| Stratégie | Quand | Coût |
|---|---|---|
| **Ignorer** | drift mineur, perf OK | nul |
| **Réentraîner périodiquement** | drift gradual | moyen |
| **Réentraîner sur trigger** | drift détecté | bas (réactif) |
| **Online learning** | data streaming, drift continu | élevé (complexité) |
| **Ensemble incrémental** | drift varié | élevé |
| **Échantillonnage adaptatif** | importance weighting | moyen |
| **Window-based** | dropping old data | moyen |
| **Re-engineer features** | drift structurel | élevé |

### Production : pipeline drift monitoring

```
[Data ingestion]
        ↓
[Compute features]
        ↓
[Compute drift metrics: PSI, KS, ...]  ────► [Dashboard / alerts]
        ↓
[Model serving]
        ↓
[Log predictions + confidence]
        ↓
[Match labels (when available)]  ────► [Performance dashboard]
        ↓
[Trigger retraining if drift detected]
```

### Best practices

1. **Monitorer en continu**, pas juste à la batch retraining
2. **Slice par segment** : drift global peut être nul mais drift fort sur sous-population
3. **Baseline = training set**, comparer prod à ce reference
4. **Plusieurs seuils** : alerte (early), action (réentraîner)
5. **Combine plusieurs métriques** : PSI + KS + perf — pas un seul signal
6. **Document expected drift** : saisonnalité prévue ≠ drift anormal
7. **Réentraînement automatisé** : CI/CD pour le modèle (cf. MLOps)
8. **Shadow models** : un nouveau modèle qui tourne en parallèle, compare prédictions
9. **A/B testing pour retraining** : nouveau modèle vs ancien, valider avant promotion
10. **Évaluer en production** : pas juste sur le test set fixe historique

### Outils

- **Evidently AI** (open-source) : reports complets de drift, intégration MLflow
- **NannyML** (open-source) : performance estimation sans labels
- **WhyLabs** : SaaS monitoring
- **Arize, Fiddler, Aporia, Censius** : ML observability commerciale
- **MLflow** : tracking mais pas drift natif
- **Custom dashboards** : Grafana + métriques exportées

## Quand c'est utile

- **Tout modèle déployé en prod** : monitoring est non-négociable
- **Modèles régulés** (médical, finance) : audit trail
- **Recommender systems** : drift utilisateur permanent
- **Fraud detection** : adversaires adaptent (drift adversariel)
- **Forecasting** : économie change, saisons, événements
- **Computer vision** en prod (caméras qui dévient, équipement change)
- **NLP** : langue évolue, slang, nouvelles entités

## Quand ça ne marche pas / pièges

- **Confondre drift et bug** : pipeline broken (NaN, schéma changé) ≠ drift. Toujours vérifier data quality d'abord.
- **Tests trop sensibles** : KS avec gros N → tout devient significatif. Utiliser effect size (PSI threshold).
- **Drift saisonnier vs vrai drift** : un drift annuel est attendu. Comparer à la même période N-1.
- **Faux drift** : si distribution train différait déjà du déploiement initial (sample biased), drift apparent dès jour 1.
- **Concept drift ignoré** : surveiller features OK mais relation X→Y change silencieusement. Toujours monitorer perf si possible.
- **Réentraînement réactif tardif** : drift détecté mais retraining prend 2 semaines → perf déjà tombée. Streamline le pipeline.
- **Overreact aux faux positifs** : alarmes constantes → ignorées. Calibrer seuils.
- **Multivariate drift loupé** : tests univariés peuvent passer mais corrélations changent. Utiliser MMD ou adversarial.
- **Labels biaisés en prod** : si les labels disponibles en prod sont sélectionnés (e.g. fraudes uniquement confirmées par revue manuelle), évaluation faussée.
- **Drift adversariel** : attaquants adaptent leurs comportements → drift constant, retraining infinite.

## Code minimal

```python
import numpy as np
import pandas as pd
from scipy import stats

# Setup : feature train + prod
np.random.seed(0)
x_train = np.random.normal(0, 1, 10000)
x_prod = np.random.normal(0.5, 1.2, 5000)  # shift de mean + var

# 1. KS test
ks_stat, ks_pvalue = stats.ks_2samp(x_train, x_prod)
print(f"KS : stat={ks_stat:.3f}, p={ks_pvalue:.4f}")
print(f"  Drift {'détecté' if ks_pvalue < 0.05 else 'non détecté'}")

# 2. PSI
def psi(expected, actual, n_bins=10):
    bins = np.percentile(expected, np.linspace(0, 100, n_bins + 1))
    bins[0] = -np.inf
    bins[-1] = np.inf
    
    expected_counts, _ = np.histogram(expected, bins=bins)
    actual_counts, _ = np.histogram(actual, bins=bins)
    
    expected_pct = expected_counts / expected_counts.sum() + 1e-6
    actual_pct = actual_counts / actual_counts.sum() + 1e-6
    
    return np.sum((actual_pct - expected_pct) * np.log(actual_pct / expected_pct))

psi_value = psi(x_train, x_prod)
print(f"PSI = {psi_value:.3f}")
if psi_value < 0.1:
    print("  Stable")
elif psi_value < 0.25:
    print("  Drift modéré")
else:
    print("  Drift significatif → action")

# 3. Wasserstein
from scipy.stats import wasserstein_distance
w = wasserstein_distance(x_train, x_prod)
print(f"Wasserstein = {w:.3f}")

# 4. Adversarial validation
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score

X = np.concatenate([x_train, x_prod]).reshape(-1, 1)
y = np.concatenate([np.zeros(len(x_train)), np.ones(len(x_prod))])
auc = cross_val_score(RandomForestClassifier(n_estimators=100), X, y,
                       cv=3, scoring='roc_auc').mean()
print(f"Adversarial AUC = {auc:.3f}  (≈ 0.5 = pas de drift, > 0.7 = drift fort)")

# 5. Categorical (Chi²)
cat_train = np.random.choice(['A', 'B', 'C'], 1000, p=[0.5, 0.3, 0.2])
cat_prod = np.random.choice(['A', 'B', 'C'], 500, p=[0.3, 0.5, 0.2])

train_counts = pd.Series(cat_train).value_counts().sort_index()
prod_counts = pd.Series(cat_prod).value_counts().sort_index()

# Normalize, then Chi²
chi2, pval, dof, exp = stats.chi2_contingency([train_counts, prod_counts])
print(f"Chi² : stat={chi2:.2f}, p={pval:.4f}")

# 6. Performance dégradation (concept drift proxy)
# Si labels dispo : reporter AUC par fenêtre glissante
# preds, labels = ... (production logs)
# rolling_auc = pd.Series(preds, index=timestamps).rolling('7D').apply(
#     lambda window: roc_auc_score(labels_window, window))
# Alerte si rolling_auc < seuil

# 7. Evidently (intégration prod-ready)
# from evidently.report import Report
# from evidently.metric_preset import DataDriftPreset
# report = Report(metrics=[DataDriftPreset()])
# report.run(reference_data=df_train, current_data=df_prod)
# report.save_html("drift_report.html")
```

## Pour aller plus loin

- Gama, Žliobaitė, Bifet, Pechenizkiy, Bouchachia, *A survey on concept drift adaptation* (ACM CSUR 2014) — référence
- Lipton et al., *Detecting and Correcting for Label Shift with Black Box Predictors* (ICML 2018)
- *Evidently AI documentation*, *NannyML documentation*
- *Made With ML* — sections monitoring
- Aporia / Arize / WhyLabs — blogs ML observability
- **Liens internes** : [[Data leakage]], [[KL divergence]], [[Wasserstein distance]], [[Hypothesis testing]], [[Chi-squared tests]], [[A-B testing]]
