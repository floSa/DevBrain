---
galaxie: dev
nom: Neo4j
alias: [neo4j]
categorie: database/graph
sous_categories: [property-graph, cypher, knowledge-graph]
licence: GPL-3.0 (Community) / Commercial (Enterprise)
licence_type: open-source
hosted: both
maturite: production
langage: Java
clients_officiels: [python, ts, go, java, dotnet]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Nebula Graph]]", "ArangoDB", "JanusGraph", "Memgraph", "[[Postgres]] + Apache AGE"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, database, graph, cypher]
url_officiel: https://neo4j.com/
url_docs: https://neo4j.com/docs/
url_repo: https://github.com/neo4j/neo4j
---

# Neo4j

## Pourquoi
Base **graphe property-model**. Langage de requête **Cypher** (devenu standard via openCypher / GQL ISO). Mature, large écosystème, intégrations LLM natives (knowledge graphs pour RAG). Le défaut quand "graphe" est le bon modèle.

## Quand l'utiliser
- Données fondamentalement relationnelles **multi-hop** (recommandation, fraud, social, supply chain)
- Knowledge graphs pour RAG (GraphRAG, GraphCypher)
- Découverte de patterns complexes (cycles, communautés)
- Quand les joins SQL deviennent ingérables (> 5-7 hops)

## Quand NE PAS l'utiliser
- Modèle naturellement tabulaire → [[Postgres]] suffit largement
- Très haute scale graphe (milliards de nœuds) → [[Nebula Graph]] ou JanusGraph
- Budget contraint et besoin enterprise → version Community a des limites (clustering Aura/Enterprise only)
- Si tu veux juste une "ontologie maintenue à la main" → ne pas surévaluer le besoin

## Pièges connus
- **Community vs Enterprise** : clustering, RBAC fin, hot backups → Enterprise only
- **Cypher** : courbe d'apprentissage (pattern matching, agrégation graphique)
- **Memory-bound** : performance dépend fort de la RAM (page cache)
- **Modélisation graphe** : crucial dès le début (relations dirigées, propriétés sur edges)
- **APOC plugin** : indispensable mais à installer/maintenir
- **Migration data** : pas trivial depuis SQL, prévoir scripts ETL

## Liens
- [[Nebula Graph]] — alternative haute scale
- Cypher Reference : https://neo4j.com/docs/cypher-manual/current/
- LangChain integration : https://python.langchain.com/docs/integrations/graphs/neo4j_cypher/
- Aura (managed) : https://neo4j.com/cloud/aura/
- APOC : https://neo4j.com/labs/apoc/
