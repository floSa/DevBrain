---
galaxie: dev
nom: ClearML
alias: [clearml, allegro-clearml]
categorie: ml/tracking
sous_categories: [tracking, ml-ops, experiments, orchestration, agents, serving]
licence: Apache-2.0
licence_type: open-source
hosted: self ou cloud
maturite: production
langage: Python
clients_officiels: [python, cli]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[MLflow]]", "[[Weights & Biases]]", "[[Aim]]", "[[Comet]]", "[[Neptune]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, tracking, ml-ops, orchestration]
url_officiel: https://clear.ml/
url_docs: https://clear.ml/docs/
url_repo: https://github.com/allegroai/clearml
---

# ClearML

## Pourquoi

Plateforme **MLOps end-to-end** : tracking + orchestration + serving + **agents (workers)** + hyperparameter optimization. Open-source self-host généreux (ClearML Server full Apache-2.0) ou **ClearML Cloud** managed.

Vs MLflow : ClearML est **plus opinionated et plus complet** — agents distribués natifs (un worker poll une queue, exécute un task containerisé), HPO intégré (Bayesian, ASHA), serving (ClearML Serving), Datasets versionnés, pipelines code-first. Vs W&B : open-source intégral, self-host trivial, mais UX moins polish et écosystème moins riche.

## Quand l'utiliser

- **Stack MLOps complet self-host** : tracking + orchestration + agents dans un seul outil
- **Workers distribués** pour training : un script + une queue → ClearML déploie sur tes GPUs
- **Hyperparameter optimization intégré** (HpO Optuna-like wrappé natif)
- **Datasets versionnés** : `clearml-data` pour datasets immutables avec lineage
- **Reproductibilité forte** : ClearML capture le code, requirements, args, env Git
- **Pipelines code-first** : DAGs ML écrits en Python natif
- **Combo MLflow refactoring** : ClearML peut remplacer MLflow + Kubeflow + W&B
- **Cloud managed gratuit jusqu'à un point** : free tier généreux pour solo

## Quand NE PAS l'utiliser

- **Juste tracking simple** → [[MLflow]] / [[Aim]] plus légers
- **Orchestration data générique** → [[Prefect]] / [[Dagster]] / [[Airflow]] mieux
- **Stack LangChain / LLM serving** → outils LLM dédiés (Langfuse, vLLM)
- **Équipe déjà sur W&B / MLflow** : coût de migration > gain
- **Communauté énorme requise** : moins de retours / tuto que W&B / MLflow

## Pièges connus

- **Setup serveur lourd self-host** : MongoDB + Elasticsearch + Redis + ClearML Server → docker-compose mais nécessite resources (8 Go RAM mini)
- **Concepts à apprendre** : Task, Project, Pipeline, Agent, Queue, Worker → onboarding 1-2 semaines
- **Moins de retours communauté** vs W&B / MLflow → debugging plus solitaire
- **UI un poil verbose** : beaucoup d'onglets, pas toujours intuitif
- **Auto-capture aggressive** : ClearML capture tout (stdout, env, packages) → utile mais peut surprendre
- **Agent demande Docker** : workers tournent en containers, prévoir CI/registry
- **HpO via Optuna sous le capot** : fine, mais l'abstraction ajoute une couche
- **Versions Server vs Agent vs SDK** à matcher attention
- **Multi-tenant non trivial** : workspaces oui, mais isolation hard à configurer

## Code minimal

```bash
pip install clearml
clearml-init     # configure URL serveur + credentials (interactif)
```

```python
# Tracking minimaliste : 2 lignes
from clearml import Task

task = Task.init(
    project_name="llama-finetune",
    task_name="baseline-lr-1e4",
    tags=["baseline"],
)

# Auto-capture : hyperparams via argparse, models PyTorch, plots matplotlib, scalars
task.connect({"lr": 1e-4, "batch_size": 32, "model": "llama-3-8b"})

for epoch in range(10):
    train_loss = train_one_epoch()
    val_loss = evaluate()
    task.get_logger().report_scalar("loss", "train", train_loss, iteration=epoch)
    task.get_logger().report_scalar("loss", "val", val_loss, iteration=epoch)

task.upload_artifact("model", artifact_object=model_path)
task.close()
```

```python
# Pipeline + agents distribues
from clearml import PipelineController

pipe = PipelineController(name="rag-eval-pipeline", project="rag", version="1.0")

pipe.add_step(
    name="prepare-data",
    base_task_project="rag", base_task_name="prepare-data-template",
    parameter_override={"General/dataset_version": "v3"},
)
pipe.add_step(
    name="train",
    parents=["prepare-data"],
    base_task_project="rag", base_task_name="train-template",
)
pipe.add_step(
    name="eval",
    parents=["train"],
    base_task_project="rag", base_task_name="eval-template",
)

pipe.start(queue="gpu-a100")   # un agent poll la queue 'gpu-a100' et execute
```

```bash
# Lancer un agent worker (sur un noeud GPU)
clearml-agent daemon --queue gpu-a100 --docker --foreground
```

## Liens

- [[MLflow]] — alternative tracking + registry plus simple
- [[Weights & Biases]] — alternative SaaS managed
- [[Aim]] — alternative open-source légère (tracking only)
- [[Comet]] / [[Neptune]] — alternatives SaaS
- [[Optuna]] / [[Ray Tune]] — HPO complémentaires (ClearML wrappe Optuna)
- [[Prefect]] / [[Dagster]] — orchestration data générique
- Docs : https://clear.ml/docs/
- GitHub : https://github.com/allegroai/clearml
