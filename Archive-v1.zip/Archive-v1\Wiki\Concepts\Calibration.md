---
galaxie: wiki
nom: Calibration
alias: [model calibration, probability calibration, Brier score, Platt scaling, isotonic regression]
type: concept
categorie: concept/ml
sous_categories: [classification, probabilities, brier-score, platt-scaling, isotonic]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Platt 1999, Niculescu-Mizil & Caruana 2005]
lecture_min: 8
created: 2026-05-19
modified: 2026-05-19
tags: [concept, ml, calibration, probabilities]
---

# Calibration

## TL;DR

Un modèle est **calibré** si quand il prédit une probabilité $p$ (ex. "0.7 d'être positif"), la **vraie fréquence de positifs** dans le groupe d'exemples qu'il a annotés à $p$ est bien $p$. La plupart des modèles (boosting, neural nets, naive Bayes) ne sont **pas calibrés** par défaut — ils peuvent avoir un bon [[ROC AUC]] mais des probas inutilisables pour la décision. **Platt scaling** (logistic) et **isotonic regression** sont les deux méthodes de calibration post-hoc.

## Le problème

Tu as un classifieur qui prédit `0.9` de probabilité qu'un email soit du spam. Si tu utilises 0.9 comme une vraie probabilité — par exemple pour pondérer une décision business ou agrégér à d'autres scores — il faut que ce nombre soit **fiable**.

Or beaucoup de modèles produisent des scores **distordus** :
- **Random Forest** : tend à éviter les valeurs extrêmes (concentre près de 0.5)
- **Gradient boosting** : peut être sur-confident (probas trop proches de 0/1)
- **Naive Bayes** : violation de l'indépendance → probas faussées
- **Neural nets** modernes (DL) : sur-confidents (Guo et al. 2017)

Le modèle peut avoir un excellent ranking ([[ROC AUC]] élevé) **et** des probas absolues fausses.

## L'idée

### Mesurer la calibration

**Reliability diagram** : on bin les prédictions par tranche (ex. [0.0, 0.1), [0.1, 0.2), …, [0.9, 1.0]), et on calcule :
- Pour chaque bin, la **proba moyenne prédite** par le modèle
- Pour chaque bin, la **fréquence réelle de positifs** dans ce bin

Modèle parfaitement calibré → tous les points sur la diagonale $y = x$.

```
Frac positifs réels
1 |                        *
  |                  *           ← sur-confident
  |              *
  |        *
  |  *        ← sous-confident
0 |*
  +-----------------
  0  Proba prédite  1
```

### Brier score

Score quadratique entre proba prédite et étiquette réelle :

$$ \mathrm{BS} = \frac{1}{n} \sum_{i=1}^n (p_i - y_i)^2 $$

avec $y_i \in \{0, 1\}$. Plus bas = meilleur. Décomposition de Murphy :

$$ \mathrm{BS} = \text{calibration} + \text{refinement} - \text{base rate uncertainty} $$

Permet de **séparer** la part liée à la calibration de la part liée à la qualité du ranking.

### Expected Calibration Error (ECE)

Erreur de calibration moyenne, pondérée par la taille des bins :

$$ \mathrm{ECE} = \sum_{b=1}^B \frac{|B_b|}{n} \big| \text{acc}(B_b) - \text{conf}(B_b) \big| $$

Plus bas = meilleur. Souvent rapportée en deep learning.

### Méthodes de calibration post-hoc

#### Platt scaling (logistic calibration)

Sur un **dataset de calibration séparé** (jamais utilisé pour entraîner le modèle), on fitte une régression logistique sur les scores du modèle vers la cible :

$$ p_{\text{cal}}(x) = \frac{1}{1 + \exp(A \cdot s(x) + B)} $$

avec $s(x)$ le score brut du modèle, $A, B$ appris.

**Avantages** : 2 paramètres seulement, peu d'overfit, simple
**Inconvénient** : suppose une distorsion **sigmoïdale**, n'aide pas pour des distorsions complexes

#### Isotonic regression

Apprend une fonction **monotone par morceaux** $g$ telle que $p_{\text{cal}}(x) = g(s(x))$.

**Avantages** : capture des distorsions arbitraires
**Inconvénient** : plus de paramètres, peut overfit sur petit calibration set (>1000 exemples recommandé)

#### Temperature scaling (NN spécifique)

Pour les neural nets, simple division des logits par une température $T$ apprise :

$$ p_{\text{cal}} = \mathrm{softmax}(z / T) $$

Un seul paramètre. Très utilisé en DL (Guo et al. 2017).

### Workflow standard

1. Train set → entraîne le modèle de base
2. Calibration set (≥1000 exemples, séparé) → fitte Platt/Isotonic
3. Test set → évalue calibration (ECE, Brier, reliability diagram)

En sklearn : `CalibratedClassifierCV(method='sigmoid')` (Platt) ou `method='isotonic'` (isotonic) fait tout via CV interne.

## Quand c'est utile

- Tu utilises les probas pour **prendre des décisions** pondérées (ex. décision business sous incertitude)
- Tu **agrèges** des probas issues de plusieurs modèles
- Tu présentes les résultats à des **stakeholders non-techniques** ("le modèle est 85% sûr")
- **Médical, fraude, risque** : décisions critiques basées sur la valeur exacte de proba
- Tu utilises des **seuils variables** basés sur le coût (cf. [[ROC AUC]])

## Quand ça ne marche pas / pièges

- Beaucoup de **modèles "naturels" calibrés** : régression logistique, naive Bayes (parfois), modèles bayésiens. Pas besoin de re-calibrer.
- **Calibration sur le train set** → leakage, calibration apparente mais pas réelle. Toujours dataset séparé.
- **Trop peu de données pour calibrer** : Isotonic overfit, Platt sous-fit. < 1000 exemples → Platt préférable.
- **Drift de distribution** en production : un modèle calibré peut se décalibrer si la base rate change. Re-calibrer périodiquement.
- **Multiclass** : calibration plus complexe. `sklearn.calibration.CalibratedClassifierCV` gère OvR par défaut.
- **Confusion calibration / discrimination** : un modèle peut être bien calibré mais mauvais en ranking (toujours prédire la base rate). [[ROC AUC]] mesure la discrimination, calibration mesure la fidélité des probas.

## Code minimal

```python
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import brier_score_loss
import matplotlib.pyplot as plt

# Modèle de base
clf = GradientBoostingClassifier().fit(X_train, y_train)

# Calibration via CV
clf_cal = CalibratedClassifierCV(clf, method='isotonic', cv=5)
clf_cal.fit(X_train, y_train)

# Évaluation
y_proba = clf.predict_proba(X_test)[:, 1]
y_proba_cal = clf_cal.predict_proba(X_test)[:, 1]

print(f"Brier (raw) : {brier_score_loss(y_test, y_proba):.4f}")
print(f"Brier (cal) : {brier_score_loss(y_test, y_proba_cal):.4f}")

# Reliability diagram
for name, p in [('raw', y_proba), ('calibrated', y_proba_cal)]:
    frac_pos, mean_pred = calibration_curve(y_test, p, n_bins=10)
    plt.plot(mean_pred, frac_pos, marker='o', label=name)
plt.plot([0, 1], [0, 1], '--', color='gray', label='parfaite')
plt.xlabel('Proba prédite'); plt.ylabel('Frac positifs réels'); plt.legend()
```

## Implémentations concrètes

- `sklearn.calibration` : `CalibratedClassifierCV`, `calibration_curve`
- `sklearn.metrics.brier_score_loss`
- `netcal` (PyPI) — package dédié, plus de méthodes (temperature scaling, beta calibration, etc.)
- Pour deep learning : `torchcal`, ou implé custom de temperature scaling

## Pour aller plus loin

- Platt, *Probabilistic outputs for support vector machines and comparisons to regularized likelihood methods* (1999)
- Niculescu-Mizil & Caruana, *Predicting good probabilities with supervised learning* (ICML 2005)
- Guo et al., *On Calibration of Modern Neural Networks* (ICML 2017) — temperature scaling
- **Liens internes** : [[ROC AUC]], [[Bias-variance tradeoff]], [[Cross-validation]], [[XGBoost]] / [[LightGBM]] / [[CatBoost]]
