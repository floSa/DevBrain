---
name: update-rule
description: |
  Use this skill to patch an existing rule in Rules/. Triggers: "modifie
  la règle", "patch la rule <nom>", "mets à jour la règle <X>", "ajoute
  un exemple à la règle <Y>", "transition strictness". Preserves the
  rule, updates 'modified:', optionally transitions strictness or scope.
---

# Skill — update-rule

## Quand l'utiliser

Modifier une règle existante dans `Rules/`. Cas typiques :
- Ajouter un exemple bon/mauvais
- Transition de strictness : `nice-to-have → should → must`
- Élargir/restreindre le scope (Global → Type, ou inverse)
- Ajouter une exception
- Mettre à jour suite à un REX ("j'ai vu ça en prod, je veux le tracer")

## Pré-requis vault

Mode build. Périmètre `Rules/`.

## Procédure

1. **Localiser** la règle : `Rules/<scope>/<Nom>.md`. Si nom ambigu, lister.
2. **Lire** la règle existante.
3. **Identifier le type de patch** :
   - Frontmatter (strictness, applicable, domaine)
   - Corps (MUST/SHOULD/NICE, exemples, exceptions)
4. **Si transition de strictness vers `must`** : demander une justification claire — c'est un blocage Claude pour tous les projets concernés.
5. **Si changement de scope** : déplacer le fichier si nécessaire (`Rules/Global/` ↔ `Rules/Types/<X>/`).
6. **Préserver** la structure des sections.
7. **Mettre à jour `modified:`**.
8. **Wikilinker** les nouveaux services/concepts cités.
9. **Montrer le diff** avant écriture.

## Anti-patterns à éviter

- **Transition vers `must` à la légère** — ça bloque l'agent en mode projet
- **Mélanger plusieurs règles** dans un seul fichier — proposer un split
- **Effacer des exemples existants** — toujours append
- **Bouger un fichier sans mettre à jour les wikilinks** qui pointent dessus

## Voir aussi

- `add-rule` (création)
- `log-bug` (un REX peut justifier une nouvelle règle ou un upgrade strictness)
