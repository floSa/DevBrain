---
galaxie: dev
type: pattern
contexte: API REST Python pour SaaS petit à moyen, déploiement standard
created: 2026-05-01
modified: 2026-05-01
services_cles: ["[[FastAPI]]", "[[Postgres]]", "[[GitHub-Actions|GitHub Actions]]"]
projets_appliques: []
tags: [pattern, api, fastapi, python, backend]
---

# Pattern — API REST FastAPI minimale

## Contexte

Tu démarres une API REST Python pour un SaaS petit/moyen (< 50k req/jour). Stack moderne, déployable rapidement, qui scale honnêtement avant qu'on doive optimiser.

## Stack

- **Framework** : [[FastAPI]] — async, OpenAPI auto, validation Pydantic
- **Validation** : [[Pydantic]] v2 (inclus avec FastAPI moderne)
- **DB** : [[Postgres]] + [[SQLAlchemy]] 2.0 async + [[Alembic]] pour migrations
- **Serveur** : [[Uvicorn]] derrière un reverse proxy (Caddy / Nginx)
- **CI/CD** : [[GitHub-Actions|GitHub Actions]]
- **Linter / formatter** : [[Ruff]] (remplace black + isort + flake8)
- **Tests** : [[pytest]] + `pytest-asyncio` + `httpx` AsyncClient
- **Conteneur** : [[Docker]] multi-stage build

## Structure de projet

```
my-api/
├── pyproject.toml         # config tout-en-un (deps, ruff, pytest)
├── README.md
├── Dockerfile
├── docker-compose.yml     # PG + app pour dev local
├── .github/workflows/
│   └── ci.yml
├── alembic.ini
├── alembic/
│   └── versions/
├── src/
│   └── myapi/
│       ├── __init__.py
│       ├── main.py        # FastAPI app + lifespan
│       ├── config.py      # Settings via pydantic-settings
│       ├── db.py          # engine + session factory
│       ├── models/        # SQLAlchemy declarative
│       ├── schemas/       # Pydantic
│       ├── routers/       # endpoints groupés
│       └── services/      # logique métier
└── tests/
    ├── conftest.py
    └── test_*.py
```

## Décisions clés

### 1. async partout
- DB : SQLAlchemy 2.0 async
- HTTP client : `httpx.AsyncClient`
- Tests : `pytest-asyncio`

Avantage : pas de mix bloquant. Inconvénient : tout doit être async-aware (driver PG : `asyncpg`).

### 2. Settings via Pydantic
```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    database_url: str
    secret_key: str
    log_level: str = "INFO"
    class Config:
        env_file = ".env"

settings = Settings()
```
Validation au démarrage = échec immédiat si config foireuse.

### 3. Versionnement de l'API
Préfixer toutes les routes par `/v1`. Ne pas attendre la v2 pour le faire.

### 4. Healthcheck
`GET /health` qui vérifie : app alive + DB joignable. Utilisé par K8s/Docker.

### 5. Migrations Alembic
Toutes les modifs DB passent par alembic. Jamais de `Base.metadata.create_all()` en prod.

## Pièges (vu en projets)

- Mix async/sync : un appel `requests.get()` bloquant dans un endpoint async tue le loop. Toujours `httpx.AsyncClient`.
- Pas de timeout sur les calls externes → faillites en cascade. Toujours `timeout=`.
- Pool de connexions PG : 5 par défaut, 8 workers gunicorn = 40. Voir [[REX - Postgres]].
- Tests qui partagent une DB sans rollback → flaky. Pattern : transaction par test, rollback à la fin.

## Voir aussi

- [[FastAPI]], [[Postgres]], [[GitHub-Actions|GitHub Actions]]
- [[Pattern - SaaS multi-tenant]] (si besoin d'isolation)
- [[Rules/Types/Web-app]] — règles à appliquer
