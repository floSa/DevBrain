---
galaxie: dev
type: rule
domaine: documentation
applicable: type-service-orchestration-data
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, documentation, orchestration, dagster, airflow, pipelines]
---

# Règle — Documentation Orchestrateur de données

S'applique à : [[Dagster]], [[Airflow]], [[Flyte]], [[Metaflow]], [[Kubeflow]], [[ZenML]], Prefect.

## Principe (1 phrase)
Le `services/<orchestrator>/README.md` doit décrire **le flux logique complet (DAG / graphe d'assets), la politique de reprise et les déclencheurs** — sinon personne ne peut diagnostiquer une panne ou ajouter un step.

## MUST

### 1. Graphes d'Assets / DAG
- **Liste exhaustive** des assets / tasks principales
- **Dépendances** entre assets (qui produit quoi, qui consomme quoi)
- **Schéma visuel** (Mermaid `flowchart` ou export depuis l'UI)
- Pour chaque asset / task :
  - Rôle métier (1-2 lignes)
  - Inputs (sources de données)
  - Outputs (destinations : DB, storage, autre asset)
  - Fréquence d'exécution

Exemple Mermaid :
```mermaid
flowchart LR
  raw_pdfs[(MinIO raw)] --> parse[Docling parse]
  parse --> chunks[Chunking]
  chunks --> embed[Embedding API]
  embed --> qdrant[(Qdrant index)]
  qdrant --> eval[Eval Ragas]
```

### 2. Politique de reprise (Retries)
Pour chaque type de tâche, documenter :
- **Nombre max de retries**
- **Stratégie de backoff** : fixed, exponential, jittered
- **Timeout par task** (et timeout total du run)
- **Comportement en cas d'échec d'API externe** (LLM rate limit, DB indisponible) : retry vs skip vs alert
- **Idempotence** : chaque task doit être rejouable sans effet de bord. Préciser comment.

### 3. Déclencheurs (Sensors / Schedules)
Documenter exhaustivement :
- **Schedules cron** : `0 */6 * * *` → toutes les 6h, etc.
- **Sensors** : dépôt d'un fichier dans un bucket S3, message Kafka, webhook, etc.
- **Triggers manuels** : qui peut lancer manuellement, depuis quelle UI / CLI
- **Backfill** : procédure pour relancer un range de dates passées

### 4. Stratégie d'erreur et alerting
- Où vont les logs : stdout, structured logging (JSON), [[Loki]] / Datadog
- **Alerting** : Slack / email / PagerDuty configurés sur quels événements
- **Failed runs** : comment les diagnostiquer (UI, requêtes DB metadata)

### 5. Contrat d'interface
- Comment ajouter un nouveau pipeline (procédure pas à pas)
- Comment lancer un test local
- Variables d'env requises pour l'orchestrateur lui-même (cf. [[Config-Env]])

## SHOULD

- **SLA / SLO** : temps d'exécution attendus par pipeline
- **Coût estimé** par run (compute, API calls)
- **Tests des pipelines** : tests unitaires des fonctions, tests d'intégration sur un subset
- **Versioning des pipelines** : git-tracked, comment migrer entre versions sans casser
- **Multi-tenant** : si applicable, isolation par client

## NICE

- Schéma de l'infrastructure de l'orchestrateur (workers, scheduler, metadata DB)
- Scripts de migration de DAGs entre environnements (dev → staging → prod)
- Métriques de qualité : taux de succès, durée moyenne, durée P95

## Pièges classiques

- **Idempotence négligée** : un retry réinsert des doublons en DB
- **Timeout par défaut** trop long (1h+) → coûts qui explosent silencieusement
- **Variables / Connections** centralisées sans rotation des secrets
- **Schedule UTC vs local timezone** — toujours documenter le fuseau
- **Backfill non testé** : un dimanche soir tu en auras besoin et ça plantera
- **Migration v1 → v2** (Airflow, Dagster) sans plan → pipelines cassés

## Voir aussi

- Template : `Templates/ServiceDocs/README - orchestration-data.md`
- [[README - Service]] — règle parente
- [[Dagster]], [[Airflow]], [[Flyte]], [[Metaflow]], [[ZenML]], [[Kubeflow]] — fiches Services
- [[Comparatif - Orchestrateurs data]], [[Comparatif - ML orchestration]] — vues dynamiques
