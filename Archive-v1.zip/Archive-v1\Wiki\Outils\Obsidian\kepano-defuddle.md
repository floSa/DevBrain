---
galaxie: wiki
nom: kepano/defuddle
type: obsidian-skill
plateforme: claude-code
categorie: skill/knowledge
sous_categories: [web-scraping, readability, content-extraction]
auteur: Steph Ango (kepano)
source: kepano/defuddle
source_url: https://github.com/kepano/defuddle
install_cmd: npx skills add kepano/defuddle
install_doc: 
licence: MIT
licence_type: open-source
domaines: [data-science, ai-eng, doc]
score: 
status: tested
mes_projets: [DevBrain]
created: 2026-05-19
modified: 2026-05-19
tags: [skill, obsidian, scraping]
---

# kepano/defuddle

## Pourquoi

Skill compagnon de [[kepano-obsidian-skills]] qui apprend à l'agent à **extraire du contenu propre depuis une URL** (lecture mode style Readability). Pratique pour ingérer un article tech / un paper / un readme dans DevBrain sans tout le bruit (nav, ads, side notes).

## Quand l'utiliser

- Tu veux ajouter une fiche Service à partir d'un article web → l'agent fetch via defuddle, garde le contenu utile
- Tu veux résumer un article long → defuddle nettoie d'abord, le résumé est plus pertinent
- Inbox : tu colles une URL, défuddle l'extrait propre, puis l'agent classe

## Quand NE PAS l'utiliser

- L'URL pointe sur un PDF → utilise [[anthropic-pdf]]
- Site avec JavaScript lourd / contenu derrière auth → defuddle ne sait pas (utilise un browser MCP)

## Comment l'installer

```bash
npx skills add kepano/defuddle
```

Voir [[_installer-un-skill]] section *Obsidian skill*.

## Exemples d'usage

```
> à partir de https://martinfowler.com/articles/cd4ml.html, ajoute une fiche Pattern dans DevBrain
> récupère et résume https://arxiv.org/abs/... — uniquement les conclusions
```

## Pièges connus

- Sur certains sites (Medium, Substack avec paywall), le contenu extrait peut être tronqué
- Pas d'archivage — si la page disparaît, ta fiche garde le contenu mais le lien casse

## Liens

- Repo : https://github.com/kepano/defuddle
