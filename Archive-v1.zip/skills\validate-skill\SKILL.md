---
name: validate-skill
description: |
  Use this skill to lint and validate a SKILL.md file in AI/skills/.
  Triggers: "valide ce skill", "lint le skill <nom>", "check les skills",
  "audit format SKILL.md". Verifies: frontmatter conformance to Anthropic
  format, presence of trigger phrases in description, required sections
  in body. Outputs a list of issues + suggestions, never writes.
---

# Skill — validate-skill

## Quand l'utiliser

L'utilisateur veut **vérifier le format** d'un ou plusieurs SKILL.md, soit après création (`add-custom-skill`), soit en hygiène ponctuelle. Détecte les SKILL.md qui ne respectent pas la convention Anthropic ou DevBrain.

Read-only par construction : ce skill **n'écrit jamais**, il rapporte.

## Pré-requis vault

Lecture seule. Aucun mode imposé.

## Périmètre

- `AI/skills/<nom>/SKILL.md` (par défaut)
- Sur demande : un skill précis (`validate-skill add-service`) ou tous

## Procédure

### 1. Pour chaque SKILL.md à vérifier, contrôler :

**Frontmatter Anthropic** :
- [ ] Présence d'un bloc `---` ... `---` en début de fichier
- [ ] Champ `name:` présent, en **kebab-case** (slug), correspondant au nom du dossier parent
- [ ] Champ `description:` présent
- [ ] **PAS** de champ `galaxie:` (ce frontmatter est figé par Anthropic, pas DevBrain)
- [ ] Pas d'autres champs (ou alors signaler comme "extension non standard")

**Format de la description** :
- [ ] Contient "Use this skill" au début (forme conventionnelle)
- [ ] Contient des **triggers explicites** ("Triggers: '...', '...'")
- [ ] Décrit le **produit** (ce qui sera créé/modifié)
- [ ] Mentionne les contraintes (mode requis, périmètre, sécurité)
- [ ] Longueur raisonnable (60-300 mots)

**Corps DevBrain** :
- [ ] Titre H1 du format `# Skill — <nom>` (cohérence interne)
- [ ] Section "Quand l'utiliser" (H2)
- [ ] Section "Procédure" (H2) avec étapes numérotées
- [ ] Section "Anti-patterns à éviter" (H2)
- [ ] Section "Voir aussi" (H2) avec skills cousins ou docs liées
- [ ] (Optionnel mais recommandé) "Pré-requis vault" (mode, périmètre)

**Convention DevBrain** :
- [ ] Si le skill modifie un dossier, l'écriture respecte les frontières des galaxies (cf. CLAUDE.md)
- [ ] Si le skill délègue à un sous-skill (ex. `defuddle`), le nom est correct
- [ ] Si le skill mentionne un format de frontmatter, il est cohérent avec les templates

### 2. Rapport

```markdown
# Validation skills — YYYY-MM-DD

## Résumé
N skills vérifiés
- ✅ X conformes
- ⚠️ Y avec warnings
- ❌ Z avec erreurs bloquantes

## Détail

### ✅ add-service
Tout est OK.

### ⚠️ process-inbox
- Warning : description un peu longue (340 mots, recommandé < 300)
- Warning : pas de section "Pré-requis vault"

### ❌ skill-bidon
- Erreur : champ `description:` manquant
- Erreur : pas de section "Procédure"
- Suggestion : reprendre via `add-custom-skill` qui produit le format standard

## Actions proposées
1. Patcher `process-inbox` : ajouter section Pré-requis vault
2. Réécrire `skill-bidon` from scratch
```

### 3. Demander validation utilisateur pour les patches simples

Pour les warnings mineurs (sections manquantes, ordre des sections), proposer un patch concret que l'utilisateur peut valider. Si validé, l'utilisateur lance ensuite manuellement la correction (ou via un skill update-* dédié si on en a un pour les SKILL.md).

## Anti-patterns à éviter

- **Écrire** un fichier — ce skill est read-only par contrat
- **Inventer des règles** — la grille de validation est celle ci-dessus, fixe
- **Marquer une erreur sur du contenu** (ex. "ta description est mal rédigée") — checke uniquement le format
- **Skip les `_` ou skills sans dossier propre** : tous les sous-dossiers de `AI/skills/` avec un `SKILL.md` doivent être vérifiés

## Voir aussi

- `add-custom-skill` (créer un SKILL.md au format)
- `list-skills` (inventaire global)
- `anthropic-skills:skill-creator` (alternative officielle, peut aussi évaluer la qualité)
