---
galaxie: dev
nom: hdbscan
alias: [HDBSCAN-py, hdbscan-python]
categorie: ml/framework
sous_categories: [clustering, density-based, hierarchical, hdbscan]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: [scikit-learn DBSCAN, scikit-learn OPTICS, cuml HDBSCAN]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, ml, clustering, hdbscan, density-based]
url_officiel: https://hdbscan.readthedocs.io/
url_docs: https://hdbscan.readthedocs.io/en/latest/
url_repo: https://github.com/scikit-learn-contrib/hdbscan
---

# hdbscan

## Pourquoi

Implémentation Python de **HDBSCAN** (Hierarchical DBSCAN), version améliorée de DBSCAN qui gère les **densités variables** dans le même dataset. Élimine la nécessité de calibrer $\varepsilon$ comme dans DBSCAN classique. À privilégier sur `sklearn.cluster.DBSCAN` pour la plupart des usages modernes.

Bonus : fournit des scores de **persistance** par cluster (qualité) et des **soft cluster memberships** (proba d'appartenance).

## Quand l'utiliser

- Clusters de **densités très différentes** dans le même dataset
- $K$ inconnu et impossible à deviner a priori
- Données spatiales / GPS avec zones denses et zones lâches
- Embeddings après [[t-SNE and UMAP|UMAP]] / [[PCA]] → clustering hiérarchique stable
- Détection d'**outliers** native (noise label = -1)
- Single-cell RNA-seq (clusters de types cellulaires de tailles variables)
- Topic modeling sur documents

## Quand NE PAS l'utiliser

- Clusters de tailles et densités **homogènes** → [[K-means]] suffit et est plus rapide
- Très haute dimension ($p > 100$ sans réduction préalable) → la distance perd son sens
- Besoin de **soft assignment** principalement → [[GMM]] plus naturel
- Données catégorielles → HDBSCAN suppose une métrique numérique (sauf custom)
- < 200 points → HDBSCAN sur-fragmente sur trop petit dataset

## Pièges connus

- **`min_cluster_size`** : le seul hyperparam vraiment important. Si trop bas, fragmentation ; si trop haut, fusion des clusters proches. Règle empirique : `min_cluster_size` >= 10-15 ou ~1% du dataset
- **`min_samples`** : par défaut = `min_cluster_size`. Augmenter le rend plus conservateur (plus de noise)
- **`metric`** : par défaut `euclidean`. Pour text/cosine : `cosine`. Pour catégoriel : custom Gower-like
- **Standardisation** : toujours `StandardScaler` ou normaliser avant si features d'échelles différentes
- **Reproductibilité** : déterministe **dans le single-threaded mode**. Multi-threaded peut produire des ordres légèrement différents
- **Memory** : `cluster_selection_method='leaf'` consomme plus de mémoire que `eom` (par défaut)
- **Soft clusters** : `prediction_data=True` doit être fitted pour appeler `approximate_predict_scores` sur nouveaux points

## Liens

- Doc officielle : https://hdbscan.readthedocs.io/
- Repo : https://github.com/scikit-learn-contrib/hdbscan
- Paper : Campello, Moulavi, Sander, *Density-Based Clustering Based on Hierarchical Density Estimates* (PAKDD 2013)
- Concepts liés : [[DBSCAN]] (concept), [[K-means]] / [[GMM]] (alternatives), [[Clustering evaluation]] (validation), [[t-SNE and UMAP]] (prétraitement fréquent), [[umap-learn]]
- Alternatives : `sklearn.cluster.HDBSCAN` (intégré sklearn depuis 1.3), `sklearn.cluster.OPTICS`, `cuml.HDBSCAN` (GPU)
