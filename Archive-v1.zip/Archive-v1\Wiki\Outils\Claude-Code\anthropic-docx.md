---
galaxie: wiki
nom: anthropic-skills:docx
type: claude-code-skill
plateforme: claude-code
categorie: skill/documents
sous_categories: [docx, word, report]
auteur: Anthropic
source: anthropics/skills
source_url: https://github.com/anthropics/skills
install_cmd: claude plugin install anthropic-skills
install_doc: https://docs.claude.com/en/docs/build-with-claude/skills
licence: MIT
licence_type: open-source
domaines: [doc]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, documents, word]
---

# anthropic-skills:docx

## Pourquoi

Skill pour **créer, lire, éditer des fichiers Word (.docx)**. Pour pondre un rapport propre, une lettre, un mémo, ou faire du find/replace sur un docx existant en préservant les styles, en-têtes, tables des matières.

## Quand l'utiliser

- générer un rapport client à partir d'un brouillon markdown
- remplir un template Word existant (lettres, mémos, rapports type)
- find/replace dans un docx complexe (avec tracked changes, styles)
- extraire/réorganiser le contenu d'un docx pour autre usage

## Quand NE PAS l'utiliser

- pour de la doc tech versionnée → markdown + MkDocs/Docusaurus, jamais docx
- pour des rapports auto-générés en CI → préfère un template + `python-docx` direct

## Comment l'installer

```bash
claude plugin install anthropic-skills
```

Voir [[_installer-un-skill]].

## Exemples d'usage

```
> transforme ~/draft.md en rapport.docx avec table des matières et numérotation
> dans rapport.docx, remplace toutes les occurrences de "POC" par "MVP" 
  en gardant les styles
> extrais les sections H1 et H2 de rapport.docx en markdown
```

## Pièges connus

- Les tracked changes sont préservés mais l'agent ne les "résout" pas tout seul.
- Les commentaires Word existants restent visibles.

## Liens

- Source : https://github.com/anthropics/skills
