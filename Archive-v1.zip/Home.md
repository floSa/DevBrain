---
galaxie: meta
nom: Home
type: index
created: 2026-05-19
modified: 2026-05-20
tags: [index, home]
---

# 🧠 DevBrain — Home

> Page d'accueil du brain. Ajoute ce fichier aux **Bookmarks Obsidian** (étoile en haut à droite) pour y revenir d'un clic.

## 🚀 Quotidien

- 📥 [[Inbox]] — balance ici tes idées à ranger
- 🗺️ [[CLAUDE]] — le routeur que Claude lit à chaque session
- 📚 [[README]] — concept du brain + état actuel
- 🔧 [[INSTALL]] — guide d'installation pas à pas
- 🤝 [[CONTRIBUTING]] — règles de modification

## 🔵 Galaxie DEV — outils & pratiques

Ce qu'on met en prod, les briques techniques.

### Catalogues
- **Services** — `Services/` : ~70 fiches (databases, frameworks, LLM, ML, data)
- **Bugs** — `Bugs/` : REX par service
- **Patterns** — `Patterns/` : architectures opinionées + comparatifs
- **Rules** — `Rules/` : règles transverses (Global, Types, Documentation)

### Patterns architecturaux disponibles
- [[Pattern - API REST FastAPI minimale]]
- [[Pattern - RAG basique]]
- [[Pattern - Agent ReAct]]
- [[Pattern - LLM Eval setup]]
- [[Pattern - Pipeline ELT moderne]]
- [[Pattern - Forecasting production]]

### Comparatifs `.base` (vues dynamiques)
- `Patterns/Comparatif - Bases relationnelles.base`
- `Patterns/Comparatif - Bases vectorielles.base`
- `Patterns/Comparatif - LLM API.base`
- `Patterns/Comparatif - LLM frameworks.base`
- `Patterns/Comparatif - LLM eval et observability.base`
- `Patterns/Comparatif - ML orchestration.base`
- `Patterns/Comparatif - ML serving.base`
- `Patterns/Comparatif - Orchestrateurs de pipeline.base`
- `Patterns/Comparatif - DataFrames Python.base`

## 🟢 Galaxie WIKI — pensée & savoir

Ton espace de connaissance perso : concepts à retrouver vite, procédures, catalogue d'outils.

### Index
- [[_guide]] — qu'est-ce qu'un outil/concept/workflow, comment c'est rangé
- [[_installer-un-skill]] — procédure d'install par famille
- [[Roadmap]] — **carte exhaustive de compétences DS/ML** (checklist de révision, ~1500 items, profondeur 6-7 niveaux)
- [[Roadmap-AI]] — **carte exhaustive de compétences AI Engineer** (LLMs, agents, multimodal, prod — sans GPU)

### Concepts (127 fiches)

**LLM / AI engineering** :
- [[RAG]] • [[embeddings]] • [[prompt-caching]] • [[mcp-protocol]] • [[tool-use]] • [[agent-loops]]

**Stats factorielles** :
- [[PCA]] • [[CA]] • [[MCA]] • [[MFA]] • [[FAMD]] • [[GPA]] • [[PGA]] • [[HCPC]]

**Time series** :
- [[Stationarity]] • [[Autocorrelation]] • [[Walk-forward CV]] • [[Forecasting framing]]

**ML supervisé classique** :
- [[Bias-variance tradeoff]] • [[Cross-validation]] • [[Regularization]] • [[Ensembling]] • [[ROC AUC]] • [[Calibration]]

**Stats inférentielle** :
- [[Hypothesis testing]] • [[t-test and ANOVA]] • [[Chi-squared tests]] • [[Bootstrap]] • [[Multiple testing correction]] • [[Confidence intervals]]

**Réduction dim & clustering** :
- [[t-SNE and UMAP]] • [[K-means]] • [[DBSCAN]] • [[GMM]] • [[Clustering evaluation]]

**Théorie de l'information** :
- [[Shannon entropy]] • [[Cross-entropy]] • [[KL divergence]] • [[Jensen-Shannon divergence]] • [[Wasserstein distance]] • [[Mutual information]] • [[Perplexity]]

**Algèbre linéaire pour ML** :
- [[SVD]] • [[Eigendecomposition]] • [[Vector norms]] • [[Matrix decompositions]] • [[Matrix products]] • [[Projections]]

**Optimisation** :
- [[Gradient descent]] • [[Adam optimizer]] • [[Newton & quasi-Newton]] • [[Convexity]] • [[Learning rate schedules]] • [[Loss landscape and saddle points]]

**Théorie de l'apprentissage** :
- [[VC dimension]] • [[PAC learning]] • [[No Free Lunch theorem]] • [[Rademacher complexity]] • [[Generalization bounds]]

**Probabilités fondamentales** :
- [[Markov chains]] • [[Poisson process]] • [[Brownian motion]] • [[Central limit theorem]] • [[Concentration inequalities]] • [[MCMC]]

**Stats avancée / expérimentation** :
- [[Maximum likelihood estimation]] • [[MAP estimation]] • [[Bayesian inference]] • [[A-B testing]] • [[CUPED]] • [[Multi-armed bandits]]

**Métriques d'évaluation** :
- [[Regression metrics]] • [[Classification metrics]] • [[Forecasting metrics]] • [[Ranking metrics]] • [[LLM eval metrics]]

**Time series approfondi** :
- [[ARIMA SARIMA]] • [[Exponential smoothing]] • [[Hierarchical forecasting]] • [[Intermittent demand]] • [[Time series anomaly detection]] • [[Time series feature engineering]]

**Data quality & production ML** :
- [[Data leakage]] • [[Data drift]] • [[Imbalanced classification]] • [[Feature engineering]] • [[Missing data]]

### Galaxie AI Engineering (51 fiches, marathon 2026-05-20)

**Transformers & architectures** :
- [[Self-attention]] • [[Positional encoding]] • [[Tokenization]] • [[Transformer architectures]] • [[Flash Attention and efficient attention]] • [[Mixture of Experts]] • [[State Space Models]]

**LLM training & adaptation** :
- [[SFT]] • [[RLHF and DPO]] • [[PEFT]] • [[Quantization]] • [[Scaling laws]] • [[Distillation]]

**Inference & prompt engineering** :
- [[Decoding strategies]] • [[Speculative decoding]] • [[Prompt engineering]] • [[Structured outputs]] • [[Context engineering]] • [[Inference optimization]]

**RAG avancé** :
- [[Chunking strategies]] • [[Hybrid retrieval]] • [[Reranking]] • [[Query transformations]] • [[Advanced RAG]]

**Agents** :
- [[Agent patterns]] • [[Tool use patterns]] • [[Agent memory]] • [[Multi-agent systems]] • [[Agent evaluation]]

**Multimodal AI** :
- [[Vision Language Models]] • [[Diffusion models]] • [[Image generation]] • [[Speech models]] • [[Video generation]]

**LLM production** :
- [[LLM observability]] • [[Guardrails]] • [[Routing and cascading]] • [[Reliability patterns]] • [[LLM caching]]

**LLM evaluation** :
- [[LLM benchmarks]] • [[Code and math benchmarks]] • [[LLM-as-judge]] • [[RAG eval]]

**AI safety & security** :
- [[Prompt injection]] • [[Jailbreaking and defenses]] • [[AI security]]

**Frontier & advanced** :
- [[Small Language Models]] • [[Reasoning models]] • [[Synthetic data generation]] • [[Chain-of-Thought]]

### Workflows (4 fiches)
- [[Bootstrap projet AI eng]]
- [[Evaluer un systeme LLM]]
- [[Evaluer un modele forecast]]
- [[Debug pipeline data]]

### Outils catalogués (22 fiches)
- **Claude Code** : `Wiki/Outils/Claude-Code/` — anthropic-skills, claude-api, review, …
- **Obsidian** : `Wiki/Outils/Obsidian/` — kepano-*
- **MCP Servers** : `Wiki/Outils/MCP-Servers/` — mcp-obsidian, mcp-filesystem, mcp-github, mcp-postgres
- **CLI Tools** : `Wiki/Outils/CLI-Tools/` — uv

Vue requêtable : `Wiki/Comparatif - Outils.base`

## 🟣 Galaxie SKILLS — automatismes exécutables

22 skills custom dans `AI/skills/`. Liste complète via `list-skills`.

### Mode build (Services, Bugs, Patterns, Rules)
- `add-service`, `update-service`, `compare-services`
- `add-pattern`
- `add-rule`, `update-rule`
- `log-bug`
- `propose-stack`
- `doc-service`

### Mode wiki (Wiki/*)
- `add-wiki-concept`, `update-wiki-concept`
- `add-wiki-workflow`, `update-wiki-workflow`
- `add-wiki-outil`, `update-wiki-outil`
- `expand-stub`

### Transverse (méta)
- `process-inbox` — traite [[Inbox]]
- `cross-link` — détecte les wikilinks manquants
- `audit-skills` — hygiène mensuelle de Wiki/Outils/
- `list-skills` — inventaire global
- `add-custom-skill` — créer un nouveau skill exécutable
- `validate-skill` — linter de SKILL.md

## ⚪ Galaxie META — docs du brain lui-même

- [[CHANGELOG]] — historique des changements taxonomie/conventions
- [[README]] — concept général du brain
- [[INSTALL]] — guide d'installation détaillé
- [[CONTRIBUTING]] — règles de modification
- [[CLAUDE]] — routeur que Claude lit au démarrage
- `AI/audits/` — rapports d'audit générés (vault, links)
- `AI/decisions/` — ADR pour le brain lui-même
- `AI/scripts/` — scripts d'hygiène (`audit-vault`, `discover-links`, `audit-links`)

## 🎨 Codes couleurs galaxies

Si activé (`Settings → Apparence → Snippets CSS → galaxies`) :

- 🔵 **DEV** — `#3B82F6` (bleu acier) — Services/, Bugs/, Patterns/, Rules/
- 🟢 **WIKI** — `#10B981` (vert sauge) — Wiki/*
- 🟣 **SKILLS** — `#8B5CF6` (violet) — AI/skills/
- ⚪ **META** — `#94A3B8` (slate-gray) — docs racine + AI/audits/, decisions/, scripts/

Voir [[INSTALL]] §11.5 pour activer.

## 🛠️ Scripts d'hygiène

Dans `AI/scripts/` :

- **`audit-vault.ps1`** — état du vault (galaxies, vides, stubs, fantômes, concepts incomplets) → `AI/audits/audit-YYYY-MM-DD.md`
- **`discover-links.ps1`** — suggérer les wikilinks à utiliser pour une nouvelle fiche (ou auditer une fiche existante)
- **`audit-links.ps1`** — détecter les liens pertinents manquants sur fiches existantes → `AI/audits/links-audit-YYYY-MM-DD.md`

Voir [[2026-05-20-discover-links-strategy]] pour la stratégie complète.

## 📊 Stats du brain (mai 2026)

| Catégorie | Compte |
|---|---|
| **Total .md** | 315 |
| Services | ~70 |
| Patterns | 6 |
| Comparatifs `.base` | 9 |
| Concepts Wiki | 127 |
| Workflows Wiki | 4 |
| Outils Wiki catalogués | 22 |
| Skills custom exécutables | 22 |
| Règles | Global + Types + Documentation |
| Templates Templater | 10 |
| Scripts d'hygiène | 3 (audit-vault, discover-links, audit-links) |

## 🔭 Quoi faire ensuite ?

- 📥 Ajouter des sujets à [[Inbox]] et lancer "traite mon Inbox" en mode wiki
- 🔨 Démarrer un projet dev → utilise [[Pattern - RAG basique]] ou un autre pattern
- 🧹 Hygiène mensuelle → invoque `audit-vault.ps1`, `audit-links.ps1`, puis revue
- 📖 Lis [[_guide]] si tu es nouveau ici
