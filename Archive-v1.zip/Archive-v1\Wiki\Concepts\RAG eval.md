---
galaxie: wiki
nom: RAG evaluation
alias: [RAGAS, faithfulness, context precision, ARES, RAG metrics]
type: concept
categorie: concept/llm-eval
sous_categories: [rag, eval, llm-eval]
domaines: [ai-eng]
maturite: established
auteurs_cles: [Shahul 2023 (RAGAS)]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, rag, eval, llm]
---

# RAG evaluation

## TL;DR

Évaluer un [[RAG]] = évaluer **2 étapes** indépendamment : **retrieval** (Recall@k, Precision@k, NDCG, MRR) ET **generation** (faithfulness, answer relevance, citation quality). Frameworks dédiés : **RAGAS** (open, standard), **ARES**, **TruLens**, **DeepEval**, **Continuous Eval** (Relari), **Phoenix evals** (Arize). Datasets : **HotpotQA**, **Natural Questions**, **TriviaQA**, **MS MARCO**, **BEIR**, **MTEB** (embeddings). Synthetic test generation possible (RAGAS, Ragna). Pipeline RAG complet eval = retrieval recall + faithfulness + answer relevance + context precision/recall. Standard pour iterate sur chunking, embedder, reranker, prompts.

## Le problème

[[RAG]] a **plusieurs failure modes** :
- **Retrieval miss** : bon document existe mais pas retrieved → mauvais answer
- **Hallucination** : retrieved good, mais LLM ignore et hallucinate
- **Irrelevant context** : retrieved garbage → polluts answer
- **Wrong attribution** : LLM cite wrong source

Each demande **eval différente**.

## L'idée

### Composantes à évaluer

```
[Query] → [Retriever] → [Top-K chunks] → [LLM + context] → [Answer]
              │                                                │
              ▼                                                ▼
       Retrieval metrics                              Generation metrics
       - Recall@k                                     - Faithfulness
       - Precision@k                                  - Answer relevance
       - NDCG / MRR                                   - Answer correctness
       - Context precision                            - Citation quality
       - Context recall
```

### Retrieval metrics

Voir [[Ranking metrics]] :

#### Recall@k

Combien des **chunks pertinents** sont retrieved dans top-k.

```
Recall@5 = |relevant ∩ retrieved_5| / |relevant|
```

#### Precision@k

Combien des **retrieved sont pertinents**.

#### NDCG@k

Pondéré par position. Best chunks en début ?

#### MRR

Rang du premier pertinent.

#### Context Precision

Mesure : "parmi le contexte retrieved, quelle proportion est pertinente pour répondre" ?

Standard RAGAS.

#### Context Recall

Mesure : "parmi l'info nécessaire pour répondre, quelle proportion est dans le contexte retrieved" ?

### Generation metrics

#### Faithfulness (grounded?)

% des claims dans la réponse qui sont **soutenus par le contexte**.

Implementation (LLM-as-judge) :
1. Extract atomic claims de la réponse
2. Pour chaque claim, check si **inferrable** du context
3. Faithfulness = % supportés

```
Faithfulness = (claims supported by context) / (total claims)
```

Important : **détecte hallucinations**.

#### Answer Relevance

L'answer répond-elle à la **question** ?

Implementation : embed question, embed answer reformulated, cosine.

```python
# Reverse : "What question would this answer answer?"
reverse_q = llm(f"Generate a question for: {answer}")
score = cosine(embed(query), embed(reverse_q))
```

#### Answer Correctness

Vs **gold answer** : factual + semantic. Combine F1 + similarity.

#### Citation quality

Si LLM cite ses sources : sources correctes ? Coverage complète ?

### Frameworks

#### RAGAS (Shahul 2023)

**Standard open-source**. Suite complète :

- Faithfulness
- Answer relevance
- Context precision
- Context recall
- Answer correctness
- Answer similarity
- Aspect critique (toxicity, fluency, etc.)

```python
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy, context_precision, context_recall

results = evaluate(
    dataset=ds,  # contains : question, answer, contexts, ground_truth
    metrics=[faithfulness, answer_relevancy, context_precision, context_recall]
)
```

#### ARES (Saad-Falcon 2024)

Automated RAG eval with synthetic data + classifiers.

#### TruLens

Tracking + eval. "Triad" : context relevance, groundedness, answer relevance.

#### DeepEval

Test-like syntax pour LLM eval. Includes RAG metrics.

```python
from deepeval.metrics import FaithfulnessMetric
metric = FaithfulnessMetric(threshold=0.5)
metric.measure(test_case)
```

#### Continuous Eval (Relari)

Production-focused. Synthetic data + metrics.

#### Phoenix evals (Arize)

Open-source. Built on OpenInference.

#### LangSmith / Langfuse evals

Integrate avec leurs observability platforms.

### Synthetic eval generation

Pas d'eval set ? Generate :

```python
from ragas.testset import TestsetGenerator

generator = TestsetGenerator.from_langchain(generator_llm, critic_llm, embeddings)
testset = generator.generate_with_langchain_docs(docs, test_size=100,
                                                  distributions={simple: 0.5, reasoning: 0.4, multi_context: 0.1})
```

Question types :
- **Simple** : extract direct
- **Reasoning** : multi-step inference
- **Multi-context** : combine docs
- **Conditional** : if-then

### Datasets standards

| Dataset | Type | Use |
|---|---|---|
| **HotpotQA** | multi-hop QA | reasoning over multiple docs |
| **Natural Questions** | open-domain QA | Google, real questions |
| **TriviaQA** | trivia | factual QA |
| **MS MARCO** | passage ranking | retrieval baseline |
| **BEIR** | multi-domain retrieval | comprehensive retrieval |
| **MTEB** | embedding benchmark | embedder eval |
| **FreshQA** | recent questions | knowledge freshness |
| **LongBench** | long context QA | long ctx RAG |

### Pipeline d'eval typique

```
1. Build eval dataset (synthetic + manual)
2. Run RAG pipeline → save outputs
3. RAGAS metrics on outputs
4. Track over time (LangSmith)
5. Compare configs (chunk size, embedder, reranker)
6. CI gate on regressions
```

### Eval-driven RAG dev

1. **Start with baseline** : naive RAG
2. **Eval** : measure baseline scores
3. **Identify weak component** : low recall? low faithfulness?
4. **Iterate** : try different chunks, embedder, reranker, prompts
5. **Re-eval** : compare
6. **Production** : continuous eval sample

### Best practices

1. **Separate retrieval + generation eval** : different failure modes
2. **Build custom eval set** : domain-specific
3. **Synthetic + manual** : RAGAS gen + curate
4. **Faithfulness obligatoire** : detect hallucinations
5. **Context Precision** : redundant context = waste tokens
6. **Iterate granular** : change 1 thing at a time
7. **Production sampling** : real queries are best eval
8. **Track over time** : LangSmith / Langfuse
9. **CI eval** : prevent regression
10. **A/B test** in production : real users feedback

## Quand c'est utile

- **Build RAG** : iterate on configs (chunking, embedder, reranker)
- **Production monitoring** : detect quality drops
- **Compare frameworks** : LlamaIndex vs LangChain RAG
- **Choose embedder** : compare BGE vs Cohere vs OpenAI
- **Choose reranker** : Cohere vs BGE vs ColBERT
- **Chunk size tuning**
- **CI/CD gate** : prevent regression
- **Customer trust** : show metrics to stakeholders

## Quand ça ne marche pas / pièges

- **Synthetic eval bias** : generated questions trop similaires
- **Faithfulness LLM judge** : peut hallucinate scores
- **Context precision strict** : penalise legit redundancy
- **Recall@k difficult sans ground truth** : need annotated relevant chunks
- **No gold answer** : reference-free eval moins fiable
- **Single metric** : faithfulness up + answer relevance down → bad
- **LLM judge biases** : same family, verbosity, position
- **Cost RAGAS eval** : 4-5 LLM calls per example
- **Out-of-domain** : public datasets ≠ ton domaine
- **Cherry-picked** : show good eval examples, hide bad
- **Real users ≠ eval set** : prod queries différents
- **Multimodal RAG** : eval frameworks weak

## Code minimal

```python
# 1. RAGAS basic
from ragas import evaluate
from ragas.metrics import (
    faithfulness, answer_relevancy,
    context_precision, context_recall, answer_correctness
)
from datasets import Dataset

eval_data = {
    "question": [...],
    "answer": [...],          # RAG output
    "contexts": [[...], ...], # Retrieved chunks
    "ground_truth": [...]     # Optional, for correctness
}

ds = Dataset.from_dict(eval_data)
results = evaluate(ds, metrics=[
    faithfulness, answer_relevancy,
    context_precision, context_recall, answer_correctness
])
print(results)

# 2. Manual faithfulness
def faithfulness_score(answer, context):
    # Step 1 : extract claims
    claims_prompt = f"Extract atomic claims from this answer:\n{answer}\n\nList them."
    claims = llm(claims_prompt)
    claims_list = parse_claims(claims)
    
    # Step 2 : check each claim
    supported = 0
    for claim in claims_list:
        check = llm(f"Context: {context}\n\nClaim: {claim}\n\nIs claim supported by context? YES/NO")
        if "YES" in check.upper():
            supported += 1
    
    return supported / len(claims_list)

# 3. Synthetic test generation
from ragas.testset import TestsetGenerator
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

generator_llm = ChatOpenAI(model="gpt-4o-mini")
critic_llm = ChatOpenAI(model="gpt-4o")
embeddings = OpenAIEmbeddings()

generator = TestsetGenerator.from_langchain(generator_llm, critic_llm, embeddings)
testset = generator.generate_with_langchain_docs(
    docs,
    test_size=50,
    distributions={"simple": 0.5, "reasoning": 0.3, "multi_context": 0.2}
)
testset.to_pandas()

# 4. Custom retrieval eval
def eval_retrieval(eval_set, retriever, k=5):
    recall_scores = []
    for example in eval_set:
        retrieved = retriever.search(example["question"], k=k)
        retrieved_ids = {c.id for c in retrieved}
        gold_ids = set(example["relevant_chunk_ids"])
        recall = len(retrieved_ids & gold_ids) / len(gold_ids) if gold_ids else 0
        recall_scores.append(recall)
    return sum(recall_scores) / len(recall_scores)

# 5. Generation eval custom
def eval_generation(eval_set, rag_pipeline):
    results = []
    for example in eval_set:
        answer = rag_pipeline.query(example["question"])
        faithfulness = faithfulness_score(answer, example["context"])
        results.append({"q": example["question"], "a": answer, "faith": faithfulness})
    return results

# 6. TruLens
# from trulens_eval import Tru, Feedback
# tru = Tru()
# f_groundedness = Feedback(provider.groundedness).on_input_output()
# tru.run_app(rag_pipeline, feedbacks=[f_groundedness])

# 7. DeepEval (pytest-style)
from deepeval import assert_test
from deepeval.metrics import FaithfulnessMetric, AnswerRelevancyMetric
from deepeval.test_case import LLMTestCase

def test_rag():
    test_case = LLMTestCase(
        input="What is the capital of France?",
        actual_output="Paris is the capital of France.",
        retrieval_context=["Paris is the capital and most populous city of France."]
    )
    assert_test(test_case, [
        FaithfulnessMetric(threshold=0.7),
        AnswerRelevancyMetric(threshold=0.7)
    ])

# 8. Track in LangSmith
from langsmith import Client
client = Client()

# Create dataset
client.create_dataset("rag_eval_v1")
client.create_examples(inputs=[...], outputs=[...], dataset_name="rag_eval_v1")

# Run evaluation
# from langsmith.evaluation import evaluate
# results = evaluate(rag_chain, data="rag_eval_v1",
#                    evaluators=[faithfulness_evaluator])

# 9. Production sample eval
def sample_and_eval(traces, sample_rate=0.05):
    import random
    sampled = random.sample(traces, int(len(traces) * sample_rate))
    return [{"trace": t, "faithfulness": faithfulness_score(t.answer, t.context)} for t in sampled]
```

## Pour aller plus loin

- Shahul et al., *RAGAS: Automated Evaluation of Retrieval Augmented Generation* (EACL 2024)
- Saad-Falcon et al., *ARES: An Automated Evaluation Framework for Retrieval-Augmented Generation Systems* (NAACL 2024)
- *RAGAS* documentation
- *TruLens*, *DeepEval*, *Phoenix evals* documentation
- Continuous Eval (Relari) documentation
- *LangSmith*, *Langfuse* RAG eval features
- **Liens internes** : [[RAG]], [[Advanced RAG]], [[Ranking metrics]], [[LLM eval metrics]], [[LLM-as-judge]]
