---
galaxie: dev
nom: Temporal
alias: [temporal, temporal-io]
categorie: data/workflow
sous_categories: [durable, workflow, saga, retry, event-sourcing]
licence: MIT
licence_type: open-source
hosted: both
maturite: production
langage: Go
clients_officiels: [python, ts, go, java, .net, ruby, php]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["Inngest", "Trigger.dev", "Restate", "Hatchet"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, workflow, durable, saga]
url_officiel: https://temporal.io/
url_docs: https://docs.temporal.io/
url_repo: https://github.com/temporalio/temporal
---

# Temporal

## Pourquoi

Plateforme de **workflows durables**. Tu écris du code Python / Go / Java / TS comme un programme normal, Temporal s'occupe de :
- **Persistence d'état** (l'état du workflow survit au crash)
- **Retries intelligents** (exponential backoff + jitter, par-activity policy)
- **Timeouts** (start-to-close, schedule-to-start, heartbeat)
- **Recovery** après crash worker (replay event history)
- **Visibility** (UI + API pour inspect runs en cours)

Différent des orchestrateurs data ([[Airflow]] / [[Dagster]] / [[Prefect]]) : conçu pour **microservices, sagas, processus métier longs** (jours / mois) avec des side effects (paiements, emails, APIs externes).

## Quand l'utiliser

- **Microservices avec workflows longs** : onboarding utilisateur (multi-step, jours), processus paiement / refund
- **Sagas / compensation patterns** : si étape 3 échoue, rollback automatique étape 2 et 1
- **Retries sophistiqués** : "retry 5 fois exponentiel, sinon DLQ"
- **Recovery après crash** : worker redémarre → reprend exactement où il en était
- **Approval workflows / human-in-the-loop** : pause des jours en attendant action humaine
- **Cron-like jobs durables** : scheduler intégré, exactly-once semantics
- **Replays / debug** : event history complet, deterministic replay pour reproduire bugs

## Quand NE PAS l'utiliser

- **Pipeline ETL pur data** → [[Prefect]] / [[Dagster]] / [[Airflow]] (mieux adaptés data-DAG)
- **Cron simple** → cron-job tout court / GitHub Actions schedule
- **Pas de besoin de durabilité** → asyncio + queue (Celery / RQ)
- **Microservices avec 1-2 steps simples** → API direct + retry middleware
- **Très petite échelle** → setup cluster overkill (sauf Temporal Cloud)

## Pièges connus

- **Determinism mandate** : pas de `random`, `time.now()`, IO direct dans le workflow code. Side effects via **Activities** uniquement. Sinon → corruption replay.
- **Apprentissage SDK initial** : concepts Workflow / Activity / Worker / Task Queue / Signals / Queries
- **Temporal Cloud cher** : pricing par actions, vite gros sur high-volume
- **Self-host = ops cluster** : Temporal Server (Go) + Cassandra/Postgres/MySQL backend → setup non-trivial
- **Versionning workflows** : breaking changes de workflow code = patches complexes (workflow versioning API)
- **History size** : événements grossissent, ContinueAsNew nécessaire pour très longs workflows
- **Activities idempotence** : à toi de garantir (retries == executions multiples possibles)
- **Visibility queries** : limited filtering (search attributes à indexer)

## Code minimal

```python
# pip install temporalio
import asyncio
from datetime import timedelta
from temporalio import activity, workflow
from temporalio.client import Client
from temporalio.worker import Worker

# Activity : code avec side effects (API calls, DB writes, etc.)
@activity.defn
async def charge_credit_card(amount: int, card_token: str) -> str:
    # Vrai code : call Stripe / etc.
    return f"charge_id_for_{amount}"

@activity.defn
async def send_confirmation_email(email: str, charge_id: str) -> None:
    # Vrai code : send via SES / SendGrid
    pass

@activity.defn
async def refund_charge(charge_id: str) -> None:
    pass

# Workflow : orchestre les activities, déterministe
@workflow.defn
class CheckoutWorkflow:
    @workflow.run
    async def run(self, order: dict) -> str:
        # Retry policy par activity
        retry = {"maximum_attempts": 3, "initial_interval": timedelta(seconds=1)}

        try:
            charge_id = await workflow.execute_activity(
                charge_credit_card,
                order["amount"], order["card_token"],
                start_to_close_timeout=timedelta(seconds=30),
                retry_policy=retry,
            )
        except Exception:
            workflow.logger.error("Charge failed, aborting")
            raise

        try:
            await workflow.execute_activity(
                send_confirmation_email,
                order["email"], charge_id,
                start_to_close_timeout=timedelta(seconds=60),
            )
        except Exception:
            # Saga compensation : refund si email fail (exemple)
            await workflow.execute_activity(
                refund_charge, charge_id,
                start_to_close_timeout=timedelta(seconds=30),
            )
            raise

        return charge_id

# Worker : exécute workflows + activities
async def run_worker():
    client = await Client.connect("localhost:7233")
    worker = Worker(
        client,
        task_queue="checkout",
        workflows=[CheckoutWorkflow],
        activities=[charge_credit_card, send_confirmation_email, refund_charge],
    )
    await worker.run()

# Trigger un workflow depuis ton API
async def start_checkout(order: dict):
    client = await Client.connect("localhost:7233")
    result = await client.execute_workflow(
        CheckoutWorkflow.run,
        order,
        id=f"checkout-{order['id']}",
        task_queue="checkout",
    )
    return result
```

## Liens

- [[Comparatif - Orchestrateurs data]] — vs Airflow / Dagster / Prefect
- **Inngest** (alt event-driven moderne) : https://www.inngest.com/
- **Trigger.dev** (alt TypeScript-first) : https://trigger.dev/
- **Restate** (alt event-sourcing) : https://restate.dev/
- **Hatchet** (alt Postgres-based) : https://hatchet.run/
- Temporal Cloud (managed) : https://temporal.io/cloud
- Docs : https://docs.temporal.io/
- Python SDK : https://python.temporal.io/
