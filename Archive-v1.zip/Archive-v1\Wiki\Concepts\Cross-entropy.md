---
galaxie: wiki
nom: Cross-entropy
alias: [entropie croisée, log loss, NLL, negative log-likelihood]
type: concept
categorie: concept/info-theory
sous_categories: [cross-entropy, loss-function, classification, log-loss]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Shannon, ML community]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, info-theory, cross-entropy, loss]
---

# Cross-entropy — entropie croisée

## TL;DR

Mesure de **distance** entre une distribution vraie $p$ et une distribution prédite $q$. Plus $q$ s'éloigne de $p$, plus la cross-entropy augmente. **Loss standard en classification** (binary CE, categorical CE), équivalente à la **negative log-likelihood (NLL)**. Décomposition fondamentale : $H(p, q) = H(p) + D_{\text{KL}}(p \| q)$ — la cross-entropy = entropie vraie + pénalité d'écart au vrai.

## Le problème

En classification, on prédit une **distribution de probabilité** $q$ sur les classes. On veut une loss qui :
- est minimale quand $q = p$ (la prédiction matche la vérité)
- pénalise fortement les prédictions confiantes mais fausses ("prédit 0.99 pour la mauvaise classe")
- est dérivable pour la descente de gradient

La cross-entropy satisfait tout ça.

## L'idée

### Définition

Pour deux distributions $p$ (vraie) et $q$ (prédite) sur le même espace discret :

$$ H(p, q) = -\sum_i p_i \log q_i $$

Si la cible est un one-hot $p = e_y$ (classe vraie $y$), cela se réduit à :

$$ H(p, q) = -\log q_y $$

C'est la **negative log-likelihood (NLL)** du label vrai sous la distribution prédite.

### Décomposition

$$ H(p, q) = H(p) + D_{\text{KL}}(p \| q) $$

- $H(p)$ = entropie de Shannon de la vraie distribution (constante, indépendante du modèle)
- $D_{\text{KL}}(p \| q)$ = [[KL divergence]] de $p$ vers $q$ (la part qu'on peut minimiser)

**Minimiser cross-entropy = minimiser KL divergence** — c'est le mécanisme de l'apprentissage par maximum de vraisemblance (MLE).

### Binary cross-entropy (BCE)

Cas binaire $y \in \{0, 1\}$, $\hat y \in [0, 1]$ :

$$ \mathcal{L}_{\text{BCE}}(y, \hat y) = -\big[ y \log \hat y + (1 - y) \log(1 - \hat y) \big] $$

Équivalente à la **log-loss** classique.

### Categorical cross-entropy

Multi-classes $K$, target one-hot, softmax output $\hat y_k = \frac{e^{z_k}}{\sum_j e^{z_j}}$ :

$$ \mathcal{L}_{\text{CCE}}(y, \hat y) = -\sum_{k=1}^K y_k \log \hat y_k = -\log \hat y_{y^*} $$

où $y^*$ est l'indice de la classe vraie.

### Sparse categorical cross-entropy

Identique mais avec target = int (l'indice de la classe), sans one-hot. Plus efficient en mémoire pour beaucoup de classes (NLP, vision).

### Lien avec MLE

Minimiser la cross-entropy sur un dataset = **maximiser la vraisemblance** :

$$ \arg\min_\theta \frac{1}{N} \sum_{n=1}^N -\log q_\theta(y_n | x_n) = \arg\max_\theta \prod_n q_\theta(y_n | x_n) $$

C'est la justification théorique de l'utilisation de la cross-entropy en classification.

### Asymétrie

Important : $H(p, q) \neq H(q, p)$. L'ordre des arguments compte :
- $H(p_{\text{vrai}}, q_{\text{pred}})$ : la formulation standard
- Inverser → on apprend à prédire des "moyennes" de la vraie distribution, comportement très différent (cf. [[KL divergence]] forward vs reverse)

## Quand c'est utile

- **Classification** binaire et multi-classes — loss par défaut
- **Modèles de langue** : NLL par token (perplexity = exp(NLL))
- **RLHF / DPO** : la NLL sur les préférences est la base de l'optimisation
- **Distillation** : KL entre teacher et student (équivalent à cross-entropy à constante près)
- **Calibration** : NLL est sensible aux probabilités, contrairement à l'accuracy

## Quand ça ne marche pas / pièges

- **Classes très déséquilibrées** : la classe majoritaire domine le gradient. Solutions : class weights, focal loss, oversampling
- **Confiance excessive** : un modèle qui prédit 0.999 vs 0.5 sur la mauvaise classe est puni très différemment. Combine bien avec label smoothing pour atténuer.
- **Logits non-bornés** : implémenter via `log_softmax + nll_loss` plutôt que `softmax + log + sum` pour la stabilité numérique
- **Cross-entropy ≠ accuracy** : un modèle peut avoir une bonne accuracy et une CE médiocre (probabilités mal calibrées, cf. [[Calibration]])
- **KL forward vs reverse** : en distillation ou VAE, le choix entre $D_{\text{KL}}(p \| q)$ et $D_{\text{KL}}(q \| p)$ change radicalement le comportement (mass-covering vs mode-seeking)
- **Soft labels** : si la cible est elle-même une distribution (pas one-hot, ex. après augmentation type mixup), la formule générale s'applique mais on perd l'identification à la NLL

## Code minimal

```python
import torch
import torch.nn as nn
import torch.nn.functional as F

# Binary cross-entropy avec logits (sigmoid intégré, stable)
y_true = torch.tensor([1.0, 0.0, 1.0])
logits = torch.tensor([2.0, -1.5, 0.5])
bce = F.binary_cross_entropy_with_logits(logits, y_true)

# Categorical cross-entropy avec logits (softmax intégré, stable)
logits = torch.randn(32, 10)  # batch_size, num_classes
targets = torch.randint(0, 10, (32,))
ce = F.cross_entropy(logits, targets)  # = log_softmax + nll_loss

# Avec label smoothing
ce_smooth = F.cross_entropy(logits, targets, label_smoothing=0.1)

# Manuel pour comprendre
log_probs = F.log_softmax(logits, dim=-1)
nll = -log_probs[range(len(targets)), targets].mean()
# nll == ce
```

## Pour aller plus loin

- Goodfellow, Bengio, Courville, *Deep Learning* — chap. 5 (MLE) et chap. 6 (cross-entropy)
- Article *Why Cross-Entropy for Classification* (de.ai et autres) — pédagogique
- **Liens internes** : [[Shannon entropy]], [[KL divergence]], [[Perplexity]], [[Calibration]], [[ROC AUC]]
