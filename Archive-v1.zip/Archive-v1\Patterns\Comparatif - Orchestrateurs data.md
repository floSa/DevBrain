---
galaxie: dev
nom: Comparatif - Orchestrateurs data
type: comparatif
created: 2026-05-20
modified: 2026-05-20
tags: [comparatif, data-eng, orchestrator, etl]
---

# Comparatif — Orchestrateurs data

> Pour pipelines ETL/ELT, scheduling, retries, monitoring.

## Synthèse rapide

| Outil | Année | Standout | Cons |
|---|---|---|---|
| **[[Airflow]]** | 2014 (Apache) | mature, écosystème énorme (operators) | DAG dynamiques pénibles avant 2.x, JVM-ish lourd |
| **[[Dagster]]** | 2019 | asset-centric, types stricts, lineage natif, UX moderne | shift mental requis |
| **[[Prefect]]** | 2018 (v2 2022) | Python natif, dynamic, léger, Cloud propre | v1→v2 cassé |
| **[[Temporal]]** | 2019 | workflows durables non-data, état persisté, retry intelligent | overkill pure data ETL |
| **Kestra** | 2022 | YAML, multilangue, UI moderne | moins mature |
| **Mage** | 2022 | notebook-style, UX moderne | écosystème modeste |
| **Argo Workflows** | 2018 | Kubernetes-native, CRD-based | k8s only, YAML lourd |
| **dbt Cloud Scheduler** | — | combo natif dbt | dbt-only |

## Décision par cas

### ETL classique data warehouse
- **[[Airflow]]** : stack mature, opérateurs partout ([[Snowflake]], [[BigQuery]], S3, etc.)
- **[[Prefect]]** : si tu pars de zéro Python-natif
- **[[Dagster]]** : si tu veux du **asset-centric** (output = data asset)

### Pipelines ML + Data
- **[[Dagster]]** : excellent assets + lineage = combo data/ML
- **[[Prefect]]** : flexible
- Voir aussi [[Comparatif - ML orchestration]]

### Cloud-managed
- **Astronomer** (Airflow managed)
- **Prefect Cloud**
- **Dagster Cloud**
- **MWAA** (AWS Airflow), **Cloud Composer** (GCP Airflow)

### Workflows durables (non-data)
- **[[Temporal]]** : event sourcing, retry sophistiqué, microservices
- Pas un orchestrateur data, mais des fois confondu

### Kubernetes-first
- **Argo Workflows** : CRD k8s
- **[[Kubeflow]] Pipelines** : si ML
- **Tekton** : si CI/CD

### Simplicité moderne
- **Kestra** ou **Mage** : UX YAML/notebook
- Bons si l'équipe n'aime pas Python pur

## Critères de choix

| Critère | Best |
|---|---|
| Maturité / écosystème | Airflow |
| DAG dynamiques | Prefect / Dagster |
| Type safety / lineage | Dagster |
| Python natif minimal boilerplate | Prefect |
| Multi-langage (Java, Python, R) | Kestra |
| Kubernetes natif | Argo |
| Workflows durables (saga) | Temporal |
| Combo asset data + ML | Dagster |

## Voir aussi

- [[Comparatif - ML orchestration]] (spécifique ML)
- [[Airflow]] / [[Dagster]] / [[Prefect]] / [[Temporal]]
- dbt = transformation, pas orchestration (mais combine bien)
