---
galaxie: dev
type: rule
domaine: documentation
applicable: global
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, documentation, readme, project]
---

# Règle — README.md racine du projet

## Principe (1 phrase)
Le `README.md` racine du projet est la **porte d'entrée** : un développeur qui clone le repo doit pouvoir setup, lancer en local, et comprendre l'architecture en moins de 15 minutes.

## MUST — Sections obligatoires

```markdown
# <Nom du projet>

## Quoi
1-3 phrases : ce que fait l'app.

## Pourquoi
1-2 phrases : pourquoi elle existe.

## Architecture rapide
Schéma Mermaid ou ASCII art des composants principaux.
Lien vers `docs/ARCHITECTURE.md` pour les détails.

## Stack
- Backend : <X>
- Frontend : <Y>
- DB : <Z>
- Cache : <W>
- ...
Lien vers `services/<nom>/README.md` pour chaque composant.

## Pré-requis
- Python 3.12+
- Docker + Docker Compose
- ...

## Setup
```bash
git clone <repo>
cd <repo>
cp .env.example .env  # remplir les valeurs
docker-compose up -d  # services dépendants
uv sync               # ou pip install -r requirements.txt
uv run pytest         # vérifier que ça tourne
uv run python -m src.main
```

## Tests
- Unit : `uv run pytest tests/unit/`
- Integration : `uv run pytest tests/integration/` (docker requis)
- Eval (si LLM) : `uv run pytest tests/eval/`
Coverage actuelle : XX%

## Configuration
Variables d'env : voir `.env.example`.
Doc complète : `docs/CONFIG.md` ou cf. règle [[Config-Env]] du DevBrain.

## Déploiement
Voir `docs/DEPLOY.md`.

## Contribution
Voir `CONTRIBUTING.md` ou indiquer la procédure de PR.

## Licence
MIT / Apache-2.0 / etc. Voir `LICENSE`.
```

## SHOULD

- **Badges** : CI status, version, licence, coverage (en haut, après le titre)
- **Capture / GIF** de l'app en action si UI (sous "Quoi")
- **TOC** auto-générée pour les longs README
- **CHANGELOG** lien (si projet versionné)
- **FAQ** si questions récurrentes des contributeurs

## NICE

- **Lien vers la doc complète** (Mintlify, ReadTheDocs, GitBook)
- **Section "Architecture Decision Records"** pointant vers `docs/adr/`
- **Section "Acknowledgments"** (libs / projets dont on s'inspire)

## Anti-patterns

- README qui ne contient QUE le titre et un screenshot
- README qui contient toute la doc (mieux : `docs/` séparé)
- Steps de setup non testées (un nouvel arrivant ne peut pas setup)
- Commandes shell qui supposent un OS particulier sans le préciser
- Liens cassés vers la doc (à valider en CI : `linkcheck`)

## Voir aussi

- [[README - Service]] — README par service intégré
- [[Config-Env]] — `.env.example`
- [[Tests]] — section tests du README
- `Rules/Global/README.md` (si existant — règle plus générale sur les README OSS)
