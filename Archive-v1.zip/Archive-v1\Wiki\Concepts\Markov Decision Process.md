---
galaxie: wiki
nom: Markov Decision Process
alias: [MDP, processus de décision markovien, POMDP]
type: concept
categorie: concept/ml
sous_categories: [rl, mdp, markov, sequential-decision, formalism]
domaines: [ml-eng, ai-eng, data-science]
maturite: established
auteurs_cles: [Bellman 1957, Howard 1960, Puterman]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, rl, mdp, markov]
---

# Markov Decision Process — MDP

## TL;DR

Le **cadre mathématique standard** du [[Reinforcement learning]]. Un MDP est un tuple $(\mathcal{S}, \mathcal{A}, P, R, \gamma)$ : états, actions, transitions probabilistes, récompenses, facteur d'actualisation. La **propriété de Markov** dit que le futur ne dépend que de l'état actuel, pas de l'historique. Trois variantes pratiques : **MDP fini** (states/actions discrets), **MDP continu** (espaces continus, le cas robotique), **POMDP** (Partially Observable, l'agent ne voit pas l'état complet — le cas du monde réel et des LLMs-agents).

## Le problème

Quand un agent prend des décisions séquentielles, on a besoin d'un **langage formel** pour :
1. Décrire l'environnement (états, transitions, récompenses)
2. Définir précisément ce que veut dire "résoudre" le problème (politique optimale)
3. Raisonner sur la convergence des algorithmes

Sans cadre, on bricole. Avec MDP, on a des théorèmes (Bellman, existence de $\pi^*$, convergence de value iteration, etc.).

## L'idée

### Définition formelle

Un MDP est un tuple :

$$ \mathcal{M} = (\mathcal{S}, \mathcal{A}, P, R, \gamma) $$

avec :
- $\mathcal{S}$ : ensemble des **états** (fini, dénombrable ou continu)
- $\mathcal{A}$ : ensemble des **actions** (idem)
- $P(s' | s, a)$ : **modèle de transition** — proba d'aller en $s'$ après avoir joué $a$ en $s$
- $R(s, a)$ ou $R(s, a, s')$ : **fonction de récompense** (scalaire)
- $\gamma \in [0, 1)$ : **facteur d'actualisation** (préférence temporelle)

### Propriété de Markov

$$ P(s_{t+1} \mid s_t, a_t, s_{t-1}, a_{t-1}, \dots, s_0) = P(s_{t+1} \mid s_t, a_t) $$

**Le futur est conditionnellement indépendant du passé sachant le présent.** C'est la propriété fondatrice. Concrètement : l'état $s_t$ doit contenir **toute l'information pertinente** pour décider du futur.

> Si ton état "actuel" n'est pas markovien, **enrichis-le** : empile les 4 dernières frames (DQN sur Atari), ou utilise un RNN/Transformer pour résumer l'historique (POMDP, agents LLM).

### Politique et retour

- **Politique** $\pi : \mathcal{S} \to \Delta(\mathcal{A})$ — distribution sur actions sachant l'état. Stationnaire (ne dépend pas de $t$) sous Markov.
- **Retour** : somme actualisée des récompenses futures

$$ G_t = \sum_{k=0}^{\infty} \gamma^k r_{t+k+1} $$

- **Objectif** : trouver $\pi^*$ maximisant $\mathbb{E}_\pi[G_0]$.

### Pourquoi $\gamma < 1$ ?

Trois raisons :
1. **Préférence temporelle** : 1 € maintenant > 1 € dans 10 ans (économique)
2. **Convergence mathématique** : $\sum \gamma^k r$ converge si $|r|$ borné et $\gamma < 1$
3. **Modélisation d'incertitude** : un agent peut "mourir" → équivalent à $\gamma$

En pratique : $\gamma = 0.99$ ou $0.999$ pour horizons longs, $\gamma = 0.95$ pour court terme. Pour épisodes finis (jeu de N étapes), on peut prendre $\gamma = 1$.

### Variantes importantes

#### MDP fini

$|\mathcal{S}|, |\mathcal{A}| < \infty$. $P$ se stocke comme matrice $\mathcal{S} \times \mathcal{A} \times \mathcal{S}$. Cadre des preuves de Sutton & Barto. Cible : tabular Q-learning, value iteration.

#### MDP continu

$\mathcal{S} \subset \mathbb{R}^n$, $\mathcal{A} \subset \mathbb{R}^m$. Le cas robotique, contrôle. $P$ est une densité, $V$ et $Q$ sont approximées par des réseaux. Cible : PPO, SAC, TD3.

#### POMDP (Partially Observable MDP)

L'agent **ne voit pas $s_t$ directement**, seulement une observation $o_t \sim O(\cdot | s_t)$. Le vrai monde est presque toujours POMDP.

**Solution pratique** : maintenir une *belief* $b_t$ (distribution sur les états réels), ou un état latent appris par RNN/Transformer (DreamerV3, agents LLM).

Tuple : $(\mathcal{S}, \mathcal{A}, P, R, \mathcal{O}, O, \gamma)$.

#### Semi-MDP (SMDP)

Actions à durée variable (hierarchical RL, options framework). Utile pour macro-actions.

#### Constrained MDP (CMDP)

Maximiser la récompense **sous contrainte** (e.g. coût ≤ budget). Cadre du *safe RL*.

#### Multi-agent (MMDP, Markov games)

Plusieurs agents, transitions dépendent des actions de tous. Théorie de l'équilibre de Nash sous-jacente.

### Exemple jouet : GridWorld 4×4

```
+---+---+---+---+
| S | . | . | . |          actions: ↑ ↓ ← →
+---+---+---+---+          reward : -1 par pas
| . | X | . | . |                   +10 sur G
+---+---+---+---+                   -10 sur X
| . | . | . | . |          γ = 0.95
+---+---+---+---+          start  S, goal G
| . | . | . | G |          mur X (état terminal -)
+---+---+---+---+
```

- $\mathcal{S} = \{16 \text{ cases}\}$
- $\mathcal{A} = \{↑, ↓, ←, →\}$
- $P$ déterministe (ou stochastique si "glissant")
- $R$ comme dessus

Une politique $\pi$ est une flèche par case. La politique optimale va vers G en minimisant les pas.

### Lien avec les LLMs / agents

Quand on parle d'agent LLM (Claude qui appelle des outils, réfléchit, recommence), on est dans un POMDP :
- **État caché** : intention + monde réel
- **Observation** : tool outputs + historique de conversation
- **Action** : token suivant ou tool call
- **Récompense** : préférence humaine (RLHF), ou *verifiable* (test passe / math correct)
- **Politique** : le modèle lui-même $\pi_\theta(a | \text{context})$

C'est pour ça que RLHF/GRPO sont du RL au sens propre, pas une métaphore.

## Quand c'est utile

- **Formaliser un problème de décision séquentielle** avant de coder
- **Identifier la propriété de Markov** : si non, comment enrichir l'état ?
- **Comparer des cadres** : ton problème est-il fini, continu, POMDP, CMDP ?
- **Choisir un algo** : value iteration (MDP fini connu) vs PPO (continu) vs DreamerV3 (POMDP avec sim)
- **Raisonner sur la convergence** : les preuves Sutton & Barto s'appuient sur MDP fini

## Quand ça ne marche pas / pièges

- **Propriété de Markov violée** : si l'état "actuel" n'a pas toute l'info, l'algo ne convergera pas vers l'optimum — *enrichis l'état*
- **Stationnarité supposée** : MDP suppose $P$ et $R$ fixes dans le temps ; si l'environnement dérive (concept drift, multi-agent), faux
- **$P$ inconnu** : en model-free, on ne le voit jamais, on apprend $V$ ou $Q$ directement
- **Belief state explosion (POMDP)** : maintenir $b_t$ exactement est intractable en haute dim
- **Reward design** : c'est le piège #1 — un MDP mal récompensé donne une politique catastrophique mais "optimale" au sens du MDP
- **Continuous infinite spaces** : function approximation (réseau de neurones) — plus de garanties théoriques propres
- **Multi-agent ≠ MDP** : un autre agent transforme l'environnement en non-stationnaire ; passer à Markov game

## Code minimal

```python
# MDP fini représenté en numpy : GridWorld 4x4
import numpy as np

# 16 états (cases), 4 actions (↑↓←→)
n_states, n_actions = 16, 4
goal_state = 15
wall_state = 5

# P[s, a, s'] = proba de transition
P = np.zeros((n_states, n_actions, n_states))
R = np.full((n_states, n_actions), -1.0)   # -1 par pas
R[:, :] = -1.0
R[goal_state, :] = 0.0                      # absorbant

# Construction des transitions (déterministes)
def coord(s): return (s // 4, s % 4)
def state(r, c): return r * 4 + c

for s in range(n_states):
    if s == goal_state:
        for a in range(n_actions):
            P[s, a, s] = 1.0   # absorbant
        continue
    r, c = coord(s)
    moves = {0: (-1, 0), 1: (1, 0), 2: (0, -1), 3: (0, 1)}   # ↑↓←→
    for a, (dr, dc) in moves.items():
        nr, nc = max(0, min(3, r + dr)), max(0, min(3, c + dc))
        ns = state(nr, nc)
        if ns == wall_state:
            ns = s                          # mur = on reste
        P[s, a, ns] = 1.0
        if ns == goal_state:
            R[s, a] = 10.0
```

```python
# Value iteration sur ce MDP : voir [[Bellman equations]]
gamma = 0.95
V = np.zeros(n_states)
for _ in range(200):
    Q = R + gamma * (P * V[np.newaxis, np.newaxis, :]).sum(axis=2)
    V_new = Q.max(axis=1)
    if np.allclose(V, V_new, atol=1e-6):
        break
    V = V_new

policy = Q.argmax(axis=1)
print("Politique optimale (0=↑ 1=↓ 2=← 3=→) :")
print(policy.reshape(4, 4))
```

```python
# POMDP : maintenir une belief avec un RNN (pseudo-code agent LLM)
import torch
import torch.nn as nn

class BeliefAgent(nn.Module):
    def __init__(self, obs_dim, hidden_dim, n_actions):
        super().__init__()
        self.rnn = nn.GRUCell(obs_dim, hidden_dim)   # belief implicite
        self.policy = nn.Linear(hidden_dim, n_actions)

    def step(self, obs, h_prev):
        h = self.rnn(obs, h_prev)             # belief updated
        logits = self.policy(h)
        return logits, h
```

## Pour aller plus loin

- Sutton & Barto, ch. 3 *Finite Markov Decision Processes* — http://incompleteideas.net/book/the-book.html
- Puterman, *Markov Decision Processes: Discrete Stochastic Dynamic Programming* (1994) — la référence formelle
- Kaelbling, Littman, Cassandra, *Planning and acting in partially observable stochastic domains* (1998) — POMDP foundational
- Ng & Russell, *Algorithms for Inverse Reinforcement Learning* (2000) — quand $R$ est inconnu
- **Liens internes** : [[Reinforcement learning]], [[Bellman equations]], [[Value functions]], [[Markov chains]], [[Policy gradient]]
