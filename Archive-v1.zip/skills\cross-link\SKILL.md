---
name: cross-link
description: |
  Use this skill to audit and improve wikilinking inside the vault. Triggers:
  "fais un cross-link", "améliore les liens entre concepts", "audit les
  wikilinks", "propose des liens manquants", "trouve les wikilinks
  manquants", "fantomes". Runs the audit pipeline (report-ghosts +
  audit-links) and walks the user through fixing each issue : ghost
  wikilinks (create / dewikilink / alias-fix) and missing wikilinks
  (mentions sans [[ ]]).
---

# Skill — cross-link

## Quand l'utiliser

Après un batch d'ajouts/expansions, certaines fiches qui devraient se citer mutuellement ne le font pas. Exemple : tu viens d'ajouter `RAG`, `Embeddings`, `Vector Search`, et `Postgres+pgvector` — ces 4 fiches devraient toutes se wikilinker dans leur section *Voir aussi*. `cross-link` détecte les liens manquants **et les fantômes** (wikilinks vers fiches inexistantes), et te propose les corrections.

C'est l'hygiène qui transforme un *brain dump* en *graphe de connaissance*.

## Périmètre

Tout le vault par défaut. Filtrable par galaxie (`-Galaxie dev` ou `wiki`).

## Procédure

### Étape 1 — Audit des fantômes (via `report-ghosts.ps1`)

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/report-ghosts.ps1
# -> ecrit AI/audits/ghosts-YYYY-MM-DD.md + resume terminal
```

Le rapport groupe les fantômes en 4 buckets :

| Bucket | Sens | Action recommandée |
|---|---|---|
| **ALIAS-FIX** | une fiche existante a la cible dans son `alias:` | renommer `[[X]]` → `[[<vraie-fiche>]]` |
| **A CREER** | 3+ références → candidat sérieux à la création | proposer création (`add-service` / `add-wiki-concept`) |
| **A DECIDER** | 2 références | cas par cas (créer ou dewikilinker selon contexte) |
| **FAIBLE** | 1 référence | en général dewikilinker |

### Étape 2 — Traiter les fantômes un par un

Pour chaque cible fantôme, propose à l'utilisateur :

- **ALIAS-FIX** : montre les sources, applique le rename automatiquement (Edit batch).
- **A CREER** : propose `add-service` / `add-wiki-concept` selon la nature de la cible. Si l'utilisateur valide, lance le skill approprié et reprend après.
- **A DECIDER** / **FAIBLE** : montre les sources, demande "créer / dewikilinker / autre alias ?", applique.

### Étape 3 — Audit des liens manquants (via `audit-links.ps1`)

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/audit-links.ps1
# -> ecrit AI/audits/links-audit-YYYY-MM-DD.md
```

Pour chaque fiche, le script liste les candidats à wikilinker qui ne le sont pas encore (score ≥ 8 par défaut).

### Étape 4 — Combler les liens manquants

Deux options selon la nature :

**Cas 1 — fiche cible déjà bien établie, propagation simple** :

```bash
# Wikilinker la 1ere mention bare de X dans toutes les fiches qui le mentionnent
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "<NomCible>" -All
powershell -ExecutionPolicy Bypass -File AI/scripts/add-wikilinks.ps1 -Name "<NomCible>" -All -Apply
```

**Cas 2 — fiche A devrait citer B en section "Voir aussi"** (et inversement) :

Pour chaque paire (A, B) du rapport `audit-links` :
- Demande l'utilisateur : ajouter en *Voir aussi* dans les deux fiches ? Une seule ? Skip ?
- Si oui : Edit pour ajouter `- [[B]] — <raison courte>` dans la section "Liens" de A (et inversement)
- Mettre à jour `modified: <today>` dans le frontmatter

### Étape 5 — Vérification finale

```bash
powershell -ExecutionPolicy Bypass -File AI/scripts/report-ghosts.ps1
# Cible : 0 fantome
```

### Étape 6 — Récap utilisateur

```
Hygiene cross-link terminee :

Fantomes traites :
- ALIAS-FIX : N corrections appliquees
- A CREER  : M fiches creees
- A DECIDER : K dewikilinkees / N creees
- FAIBLE   : L dewikilinkees

Liens manquants comblees :
- add-wikilinks : X fiches patchees pour <NomCible>
- Voir aussi    : Y paires bidirectionnelles ajoutees

Vault final : Z fiches indexees, 0 wikilink fantome.

Prochaine hygiene suggeree : `audit-skills` (status discovered) ou `expand-stub`.
```

## Anti-patterns à éviter

- **Créer une fiche pour 1 seul fantôme isolé** : préfère dewikilinker. Un fantôme avec 1 ref n'a pas besoin d'exister.
- **Sur-wikilinker** : une fiche avec 50 wikilinks devient illisible. Limite à 5-10 *Voir aussi* par fiche, garde le plus pertinent.
- **Wikilinks dans le TL;DR ou TitreH1** — préfère les wikilinks dans le corps narratif et dans la section *Voir aussi*
- **Lier des fiches strictement non-pertinentes** parce que le score numérique est élevé — l'utilisateur reste l'arbitre final
- **Lancer `add-wikilinks -Apply` sans dry-run** — toujours valider la liste d'abord (le script wikilinke la 1ère occurrence et ça peut tomber dans un endroit non-souhaité)
- **Ignorer le rapport `AI/audits/ghosts-YYYY-MM-DD.md`** — l'utiliser comme checklist actionnable

## Mémoire des rejets

Optionnel mais utile : maintenir `AI/decisions/cross-link-rejects.md` avec les paires "non, jamais" pour ne plus les proposer.

## Scripts utilisés

| Script | Rôle |
|---|---|
| `AI/scripts/report-ghosts.ps1` | Liste vault-wide des fantômes, groupés par cible |
| `AI/scripts/audit-links.ps1` | Liens manquants : candidats à wikilinker non encore wikilinkés |
| `AI/scripts/add-wikilinks.ps1` | Propagation : wikilinke la 1ère mention bare d'un nom |
| `AI/scripts/find-connexes.ps1` | Audit ciblé sur une fiche (utilisé par les skills `add-*`) |

Doc consolidée : `AI/scripts/README.md`.

## Voir aussi

- `add-service` / `add-pattern` / `add-wiki-*` (créent les fiches qui combleront les fantômes "A CREER")
- `process-inbox` (ranger les fiches avant cross-link)
- `expand-stub` (étoffer les fiches `status: stub`)
- `audit-skills` (autre skill d'hygiène, focalisé sur les status)
