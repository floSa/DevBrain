---
galaxie: dev
nom: python-dotenv
alias: [python-dotenv, dotenv]
categorie: tooling/config
sous_categories: [config, env-vars, secrets, dotenv, 12-factor]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python, cli]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Pydantic]] Settings (pydantic-settings)", "[[hydra]]", "[[dynaconf]]", "environs"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, config, env-vars]
url_officiel: https://github.com/theskumar/python-dotenv
url_docs: https://saurabh-kumar.com/python-dotenv/
url_repo: https://github.com/theskumar/python-dotenv
---

# python-dotenv

## Pourquoi

Charge les variables depuis un fichier `.env` vers `os.environ`. Standard de fait pour le **dev Python local** depuis 2015. Implémente le pattern **12-factor app** : la config vient de l'environnement, pas du code.

Cas d'usage typique : un `.env` à la racine du projet (gitignored) avec `DATABASE_URL=postgres://...`, `OPENAI_API_KEY=sk-...`. Au démarrage, `load_dotenv()` lit le fichier et peuple `os.environ`, ensuite ton code utilise `os.getenv("OPENAI_API_KEY")`. Combine très bien avec [[Pydantic]] Settings (`pydantic-settings`) pour avoir de la **validation + typage**.

## Quand l'utiliser

- **Dev local** : DATABASE_URL, API_KEY, FEATURE_FLAGS dans `.env`
- **Secrets en local** (.env dans .gitignore, jamais commit)
- **12-factor app** : configuration via env vars partout
- **Multi-projet** : un `.env` par projet, isolation propre
- **Docker compose local** : `env_file: .env` natif
- **CLI dotenv** : `dotenv -f .env.staging run -- python script.py`
- **`override=False` par défaut** : env vars système prioritaires sur `.env` → safe en prod

## Quand NE PAS l'utiliser

- **Production cloud** → vrai **secret manager** : AWS Secrets Manager, GCP Secret Manager, HashiCorp Vault, Doppler, Infisical
- **Config riche / typée / nested** → [[Pydantic]] Settings (qui peut lire `.env` aussi)
- **Multi-env complexe** (dev/staging/prod avec overrides hiérarchiques) → [[hydra]] / [[dynaconf]]
- **Secrets partagés équipe** : `.env` partagé via Slack/mail = anti-pattern → Doppler, 1Password CLI, op
- **Configs très volumineuses** : YAML / TOML mieux pour grosse config structurée

## Pièges connus

- **Commit accidentel de .env** : TOUJOURS dans `.gitignore`, plus `.env.example` versionné comme template
- **Quotes vs no quotes** : `KEY="value with space"` vs `KEY=value with space` → différences subtiles selon lib
- **Multi-line values** : possibles via `"""` mais fragile, escape `$` et `\n`
- **Pas typé** : tout est string → `os.getenv("DEBUG") == "true"` (pas `True`), prévoir parsing
- **Interpolation $VAR** activée par défaut : `URL=postgres://$USER@host` peut surprendre → escape `\$` ou désactiver
- **load_dotenv() est idempotent** mais ne reload pas par défaut → utiliser `override=True` si tu changes `.env` à chaud
- **Ordre de précédence** : par défaut env vars OS > `.env`, mais easy à inverser par erreur avec `override=True`
- **Pas de validation** : `OPENAI_API_KEY=` vide passe silencieux → ajouter Pydantic Settings dessus
- **Encoding Windows** : `.env` doit être UTF-8 sans BOM (sinon parsing casse)

## Code minimal

```bash
pip install python-dotenv
# Ou avec extras CLI
pip install "python-dotenv[cli]"
```

```bash
# .env
DATABASE_URL=postgres://user:pass@localhost:5432/mydb
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
DEBUG=true
LOG_LEVEL=info
ALLOWED_HOSTS=localhost,127.0.0.1
```

```python
# Usage basique
from dotenv import load_dotenv
import os

load_dotenv()   # cherche .env dans le repertoire courant et parents

db_url = os.getenv("DATABASE_URL")
api_key = os.getenv("OPENAI_API_KEY")
debug = os.getenv("DEBUG", "false").lower() == "true"
```

```python
# Lire un .env specifique
from dotenv import load_dotenv
from pathlib import Path

env_path = Path(__file__).parent / ".env.staging"
load_dotenv(dotenv_path=env_path, override=True)
```

```python
# Combo recommande : pydantic-settings (validation + typage)
# pip install pydantic-settings
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str
    openai_api_key: str
    anthropic_api_key: str
    debug: bool = False
    log_level: str = "info"
    allowed_hosts: list[str] = []

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        env_parse_none_str="",
    )

settings = Settings()      # lit .env + env vars, valide les types
print(settings.database_url)
```

```bash
# .gitignore (ne JAMAIS commit le .env)
.env
.env.local
.env.*.local

# .env.example (commit OK, template)
DATABASE_URL=
OPENAI_API_KEY=
DEBUG=false
```

```bash
# CLI : injecter un env file dans une commande
dotenv -f .env.staging run -- python manage.py migrate
dotenv list -f .env
dotenv set KEY value
```

## Liens

- [[Pydantic]] Settings (`pydantic-settings`) — combo **recommandé** pour validation
- [[hydra]] — alternative riche (Meta, multi-env hiérarchique)
- [[dynaconf]] — alternative multi-format (.env, .yaml, .toml, Vault)
- environs — alternative orientée parsing typé
- Doppler / Infisical / 1Password CLI — secret managers
- 12-factor app : https://12factor.net/config
- GitHub : https://github.com/theskumar/python-dotenv
