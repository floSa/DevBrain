---
galaxie: wiki
nom: State Space Models (SSM)
alias: [SSM, Mamba, RWKV, S4, Mamba-2, linear RNN, xLSTM]
type: concept
categorie: concept/transformers
sous_categories: [ssm, mamba, rwkv, linear-rnn, sequence-model]
domaines: [ai-eng, ml-eng]
maturite: emerging
auteurs_cles: [Gu-Goel-Re 2022 (S4), Gu-Dao 2023 (Mamba), Peng 2023 (RWKV)]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, sequence-model, ssm, mamba, llm]
---

# State Space Models (SSM)

## TL;DR

Alternative aux Transformers pour les séquences. Famille basée sur des **équations d'état linéaires** (inspirées du contrôle / signal processing). **S4** (Gu 2021) → **Mamba** (Gu-Dao 2023, **selective SSM**) — résout les défauts des RNN classiques + complexité **linéaire** en séquence (vs $O(n^2)$ Transformer). **RWKV** (open-source) parallèle. **Hybrid Transformer-SSM** (Jamba, Samba, Zamba) gagnent en pratique. Avantages : **long context** quasi-gratuit, inference rapide (constant memory). Limites : in-context learning moins fort que Transformers, écosystème moins mature.

## Le problème

Transformers : $O(n^2)$, KV cache énorme en inference long context.
RNN/LSTM : $O(n)$ mais **séquentiel** (pas paralléel en training), **gradient vanishing** sur longues séquences.

**Question** : Peut-on avoir le meilleur des deux mondes — parallel training + linear inference + long-range modeling ?

## L'idée

### State Space Models — formulation

Une SSM continue (contrôle classique) :

$$ h'(t) = A h(t) + B x(t) $$
$$ y(t) = C h(t) + D x(t) $$

avec $h$ état caché, $A, B, C, D$ matrices apprises.

**Discrétisation** (par exemple Euler) :

$$ h_t = \bar A h_{t-1} + \bar B x_t $$
$$ y_t = C h_t $$

C'est essentiellement un **RNN linéaire**. Deux modes :
- **Recurrent** (inference) : un step à la fois, $O(1)$ par step
- **Convolutional** (training) : équivalent à convolver $x$ avec un kernel $\bar K$ → calcul parallèle en $O(n \log n)$ via FFT

### S4 — Structured State Spaces (Gu 2021)

Innovation : choisir $A$ avec une **structure spéciale (HiPPO)** pour bien encoder l'historique long.

- Permet de modéliser des dépendances >10K
- Pas mature pour text-LM
- Précurseur de Mamba

### Mamba (Gu-Dao 2023)

Innovation clé : **rendre $A, B, C$ dépendantes de l'input** (selective SSM).

$$ \bar A_t = f_A(x_t), \quad \bar B_t = f_B(x_t), \quad C_t = f_C(x_t) $$

→ le modèle **sélectionne** quelle info garder/oublier selon le token. Comme un "attention" en linéaire.

**Hardware-aware** : Mamba kernel optimisé (Triton) — scan algorithm parallèle.

**Mamba-2** (2024) : améliore via structured matrix decomposition, encore meilleur.

#### Avantages Mamba

- **$O(n)$ training**, **$O(1)$ inference per token**
- **Constant memory** en génération (state fixed-size, pas KV cache qui grossit)
- **Long context naturellement** : 1M+ tokens sans dégradation
- Compétitif avec Transformers à scale équivalent (Mamba 3B, 7B)

#### Limites Mamba

- **In-context learning** moins fort que Transformer
- **Copy task / retrieval** parfois moins bons
- **Écosystème** : moins de modèles, moins d'outils
- **Fine-tuning** : pas aussi standardisé

### RWKV — Linear RNN moderne

Approche **RNN parallèle** :
- Training : peut être parallélisé comme un Transformer (formulation "time-mix")
- Inference : récurrence pure (constant mémoire)

**Versions** : v4, v5 (Eagle), v6 (Finch), v7 (recent).

- Open-source, communauté active
- Quasi-Transformer en qualité (RWKV-v7)
- 100% open

### xLSTM (Beck 2024)

Revival LSTM avec améliorations :
- **Exponential gating** (numerically stable)
- **Matrix memory** (sLSTM, mLSTM variants)
- Compétitif avec Mamba sur petits modèles

### Hybrid models — l'approche gagnante actuelle

**Constat** : SSM et Transformer ont des forces complémentaires. Hybrides excellent :

#### Jamba (AI21, 2024)

- Alternance Mamba + attention layers
- 256K context, 52B params (MoE)

#### Zamba (Zyphra)

- Hybrid SSM + attention shared

#### Samba (Microsoft)

- Mamba + Sliding Window Attention
- Bon perf/cost

#### Falcon Mamba

- 7B Mamba pur, open-source

### Tableau récapitulatif

| Modèle | Type | Inference per token | Memory | Long-ctx | LLM mature |
|---|---|---|---|---|---|
| Transformer | attention | O(n) (KV cache grows) | O(n) | bottleneck | ✓✓✓ |
| Mamba | SSM | O(1) | O(1) constant | excellent | ✓ |
| Mamba-2 | SSM | O(1) | O(1) | excellent | ✓ |
| RWKV | linear RNN | O(1) | O(1) | very good | ✓ |
| Jamba | hybrid | mixed | mixed | excellent | ✓✓ |
| LSTM | RNN | O(1) | O(1) | poor | legacy |
| xLSTM | RNN+ | O(1) | O(1) | good | research |

### State Space Models — intuition

Imaginez un "etat $h$" qui résume le passé. À chaque step :
- $\bar A$ : "comment je garde / oublie l'état précédent"
- $\bar B$ : "comment j'incorpore le nouvel input"
- $C$ : "comment je décode l'état en output"

Mamba rend tout ça **conditional** au token courant → "selective" memory.

### TTT (Test-Time Training, Sun 2024)

Recent : *Test-Time Training Layers* — adapter le modèle en cours d'inférence sur les tokens passés. Compétitif avec Mamba.

### Pourquoi Transformer domine quand même

- **In-context learning** : Transformer excelle à copier / chercher du contexte → critique pour few-shot, agent, RAG
- **Tooling mature** : Flash Attention, vLLM, LoRA, RLHF tooling → tout pour Transformer
- **Scaling laws bien comprises** : Chinchilla optimal, etc.
- **Multimodal facile** : vision encoder → LLM decoder pattern
- **Cost-quality trade-off** : à params équivalents, Transformer souvent meilleur sur benchmarks

→ SSMs / hybrid montent mais Transformer reste standard 2026.

## Quand c'est utile

- **Long context** (>100K) : Mamba quasi-gratuit
- **Streaming inference** : constant memory, idéal pour audio/video
- **Edge / mobile** : pas de KV cache énorme
- **High throughput batch** : O(1) par token
- **Research / exploration** : architectures émergentes
- **Hybrid model** : Jamba / Samba excellent compromis production
- **Time series long** : analogue parfait (signal processing)

## Quand ça ne marche pas / pièges

- **In-context learning faible** : few-shot, agent tasks → Transformer souvent mieux
- **Tooling immature** : LoRA, RLHF, quantization moins mature sur SSM
- **Modèles open limités** : majorité des SOTA open = Transformer
- **Copy / retrieval tasks** : SSM moins bon à juste répéter / retrouver
- **Confondre SSM et linear attention** : différentes formulations, perfs différentes
- **Mamba sans hardware-aware kernel** : implémentation naïve très lente
- **Mixing SSM + attention naïvement** : design d'hybrid important (où placer, ratio)
- **Quantization** : moins mature qu'attention-based
- **Pas de standard benchmark spécifique** : hard à comparer SSM vs Transformer fair

## Code minimal

```python
import torch
import torch.nn as nn

# Mamba via mamba-ssm package
# pip install mamba-ssm causal-conv1d
from mamba_ssm import Mamba

batch, length, dim = 2, 64, 16
x = torch.randn(batch, length, dim).cuda()
model = Mamba(
    d_model=dim,
    d_state=16,    # SSM state expansion factor
    d_conv=4,      # Local convolution width
    expand=2,      # Block expansion factor
).cuda()
y = model(x)
print(y.shape)  # (batch, length, dim)

# Hugging Face : models Mamba disponibles
# from transformers import MambaConfig, MambaForCausalLM
# model = MambaForCausalLM.from_pretrained("state-spaces/mamba-2.8b-hf")

# RWKV via HF
# from transformers import RwkvForCausalLM
# model = RwkvForCausalLM.from_pretrained("RWKV/rwkv-4-7b-pile")

# Jamba (hybrid)
# from transformers import AutoModelForCausalLM
# model = AutoModelForCausalLM.from_pretrained("ai21labs/Jamba-v0.1",
#                                                 trust_remote_code=True,
#                                                 torch_dtype=torch.bfloat16)

# Compute comparison: Mamba vs Transformer en very long context
# Sur séquence 100K :
# - Transformer (Flash Attn) : ~minutes, KV cache énorme
# - Mamba : seconds, constant memory ~1GB

# Toy SSM scan (pour comprendre la mécanique)
def parallel_scan_naive(A, B, x):
    """Naive scan : h_t = A_t @ h_{t-1} + B_t @ x_t"""
    T, d = x.shape
    h = torch.zeros(d)
    out = []
    for t in range(T):
        h = A[t] * h + B[t] * x[t]
        out.append(h.clone())
    return torch.stack(out)

# En vrai Mamba utilise un parallel scan O(log n) sur GPU via Triton kernel
```

## Pour aller plus loin

- Gu, Goel, Ré, *Efficiently Modeling Long Sequences with Structured State Spaces* (ICLR 2022) — S4
- Gu, Dao, *Mamba: Linear-Time Sequence Modeling with Selective State Spaces* (2023)
- Dao, Gu, *Transformers are SSMs: Generalized Models and Efficient Algorithms Through Structured State Space Duality* (ICML 2024) — Mamba-2
- Peng et al., *RWKV: Reinventing RNNs for the Transformer Era* (2023)
- Beck et al., *xLSTM* (2024)
- Lieber et al., *Jamba: A Hybrid Transformer-Mamba Language Model* (2024)
- *The Annotated S4* (Gu) — tutoriel
- **Liens internes** : [[Self-attention]], [[Transformer architectures]], [[Flash Attention and efficient attention]], [[Brownian motion]] (SDE link)
