---
galaxie: wiki
nom: ARIMA & SARIMA
alias: [ARIMA, SARIMA, Box-Jenkins, ARMA, AR, MA, differentiation]
type: concept
categorie: concept/time-series
sous_categories: [arima, sarima, box-jenkins, time-series, forecasting]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Box, Jenkins 1970]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, time-series, forecasting, arima]
---

# ARIMA & SARIMA

## TL;DR

Famille classique de modèles linéaires pour séries temporelles. **AR(p)** combine $p$ valeurs passées de $y$, **MA(q)** combine $q$ erreurs passées, **I(d)** différencie $d$ fois pour rendre stationnaire. **ARIMA(p,d,q)** = combinaison. **SARIMA(p,d,q)(P,D,Q,m)** ajoute la **saisonnalité** (différenciation et termes saisonniers de période $m$). Workflow Box-Jenkins : (1) tester stationnarité ([[Stationarity]]), (2) différencier si besoin, (3) regarder ACF/PACF ([[Autocorrelation]]) pour identifier $p, q$, (4) fitter MLE, (5) diagnostiquer résidus. Toujours **baseline indispensable** dans tout projet forecasting.

## Le problème

Modéliser une série univariée $\{y_t\}$ avec des dépendances **temporelles** linéaires : "ce que vaut $y$ aujourd'hui dépend de $y$ hier et des chocs passés". Les modèles classiques de régression (OLS) ignorent l'ordre temporel et l'auto-corrélation.

## L'idée

### Composantes

#### AR(p) — Auto-Régressif d'ordre p

$$ y_t = c + \phi_1 y_{t-1} + \phi_2 y_{t-2} + \dots + \phi_p y_{t-p} + \varepsilon_t $$

avec $\varepsilon_t \sim \mathcal{N}(0, \sigma^2)$ bruit blanc.

- $y_t$ dépend de ses $p$ valeurs passées
- AR(1) avec $\phi_1$ = 1 → random walk
- |φ| < 1 → stationnaire

#### MA(q) — Moyenne Mobile d'ordre q

$$ y_t = c + \varepsilon_t + \theta_1 \varepsilon_{t-1} + \dots + \theta_q \varepsilon_{t-q} $$

- $y_t$ dépend des $q$ erreurs passées
- Moyenne mobile **des erreurs**, pas de $y$ (terminologie trompeuse)
- Toujours stationnaire

#### ARMA(p, q) = AR(p) + MA(q)

$$ y_t = c + \sum \phi_i y_{t-i} + \varepsilon_t + \sum \theta_j \varepsilon_{t-j} $$

Modèle de séries stationnaires standard.

#### I(d) — Différenciation

Si la série n'est **pas stationnaire** (tendance, drift), différencier :

$$ \Delta y_t = y_t - y_{t-1} $$

Une fois → I(1). Si encore non-stationnaire → différencier deux fois ($\Delta^2 y_t$) → I(2).

**ARIMA(p, d, q)** : appliquer ARMA(p, q) sur la série différenciée $d$ fois.

### SARIMA — saisonnier

Pour les séries avec **saisonnalité** (mensuelle, hebdomadaire, journalière) :

$$ \text{SARIMA}(p, d, q)(P, D, Q)_m $$

- $(p, d, q)$ : composantes non-saisonnières
- $(P, D, Q)$ : composantes saisonnières (en multiples de la période $m$)
- $m$ : période saisonnière (12 monthly, 7 daily, 24 hourly, etc.)

Exemple : $\text{SARIMA}(1, 1, 1)(1, 1, 1)_{12}$ pour série mensuelle avec saisonnalité annuelle.

### Variantes / extensions

#### ARIMAX / SARIMAX

Ajoute des **covariables exogènes** $X_t$ :

$$ y_t = \alpha + \beta^\top X_t + \text{ARIMA structure} $$

Standard chez statsforecast, statsmodels. Permet d'intégrer température, jours fériés, événements.

#### Auto-ARIMA

Sélectionne automatiquement $(p, d, q, P, D, Q)$ par AIC/BIC minimisation. Algorithme stepwise (Hyndman-Khandakar 2008). Implem : `pmdarima` Python, `auto.arima` R.

#### VARIMA / VAR

Multi-variate : plusieurs séries $\{y^{(1)}_t, \dots, y^{(k)}_t\}$ qui s'influencent. Voir Granger causality.

### Workflow Box-Jenkins (1970)

Recette historique :

1. **Vérifier stationnarité** : tests ADF, KPSS, visual inspection
2. **Différencier** ($d$) si besoin
3. **Identifier $(p, q)$** via ACF/PACF :
   - AR(p) → PACF tronqué après lag p, ACF qui décroît
   - MA(q) → ACF tronqué après lag q, PACF qui décroît
   - ARMA → décroissance dans les deux
4. **Identifier saisonnier** $(P, D, Q, m)$ via ACF/PACF saisonniers
5. **Fitter** MLE (maximum likelihood) ou conditional sum of squares
6. **Diagnostiquer résidus** :
   - Ljung-Box test (pas d'auto-corrélation résiduelle)
   - Histogramme des résidus (~ gaussien)
   - QQ-plot
7. **Choisir entre modèles** : AIC, BIC, AICc
8. **Out-of-sample** : forecast + comparer aux observations (cf. [[Walk-forward CV]])

### Tableau d'identification ACF/PACF

| Modèle | ACF | PACF |
|---|---|---|
| AR(p) | décroissance exponentielle/sinusoïdale | tronqué après lag p |
| MA(q) | tronqué après lag q | décroissance |
| ARMA(p, q) | décroissance | décroissance |
| Saisonnalité m | pics à lag m, 2m, 3m... | idem |

### Avantages / Limites

**Avantages** :
- **Interprétable** : chaque coefficient a un sens
- **Léger** : peu de paramètres, fitte sur peu de données
- **Mature** : 50 ans de littérature, théorie complète
- **Baseline obligatoire** : tout modèle plus complexe doit le battre

**Limites** :
- **Linéaire** : ne capture pas les non-linéarités
- **Univarié sauf SARIMAX** (limité en covariables)
- **Stationnarité hypothèse** : sensible aux changes de régime
- **Long horizon → forecast plat** (converge vers la moyenne)
- **Pas de mémoire longue** (différenciation entière) — utiliser ARFIMA pour long memory

### Modèles voisins / complémentaires

- **Exponential smoothing (ETS)** : voir [[Exponential smoothing]] — autre famille classique
- **Prophet** : decomposition trend + seasonality + holidays + change points (Meta)
- **Theta method** : forecast simple souvent compétitif (M-comp)
- **Neural** : N-BEATS, NHITS, DeepAR — ML moderne (cf. neuralforecast)

### Best practices

1. **Toujours fitter une ARIMA en baseline** : si un modèle deep learning ne bat pas SARIMA, le modèle est mauvais
2. **auto.arima ou pmdarima** : pour les cas simples
3. **Backtesting walk-forward** obligatoire ([[Walk-forward CV]])
4. **Diagnostics résidus** non-négo
5. **AIC/BIC pour sélection**, mais pas oublier l'out-of-sample
6. **Limiter $p + q \leq 5$** en général (sinon overfit)
7. **Pour gros volume de séries** : statsforecast (vectorisé), pas statsmodels (one-by-one trop lent)

## Quand c'est utile

- **Baseline forecasting** : obligatoire dans tout projet
- **Séries courtes** : ARIMA fitte avec 50-100 points, ML demande plus
- **Séries stables** : avec saisonnalité bien définie, ARIMA est dur à battre
- **Interprétabilité requise** : explicabilité réglementaire / business
- **Beaucoup de séries en parallèle** : statsforecast fait des milliers d'ARIMA en secondes
- **Stress tests / forecasts en chaîne** : ARIMA est rapide

## Quand ça ne marche pas / pièges

- **Non-stationnarité non corrigée** : fit ARMA sur série avec tendance → biais énorme. Toujours ADF d'abord.
- **Saisonnalités multiples** (jour de semaine + annuel) : SARIMA ne gère qu'une, utiliser Prophet ou TBATS.
- **Outliers, structural breaks** : ARIMA biaisé. Détecter + interpolate / régresseur dummy.
- **Trends non-linéaires** : ARIMA suppose tendance linéaire (différenciation). Utiliser ETS ou ML.
- **Long horizons** : forecast plat après quelques pas. Limites intrinsèques.
- **Auto-ARIMA local min** : stepwise sélection peut louper le bon modèle. Tester aussi grid search.
- **Sur-fit avec trop de paramètres** : limiter $p + q$.
- **Données intermittentes** (counts avec zéros) : ARIMA inadapté. Utiliser Croston (cf. [[Intermittent demand]]).
- **High-frequency data** (sub-daily) : SARIMA très lourd. Utiliser TBATS, Prophet, ML.
- **Confondre I(2) avec problème de mean** : différencier trop = overdifferenciation, sur-fit aux fluctuations.

## Code minimal

```python
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
import pmdarima as pm

# Données airline (saisonnalité 12)
from statsmodels.datasets.airline import load
data = load().data.iloc[:, 0]

# Auto-ARIMA
model_auto = pm.auto_arima(data, seasonal=True, m=12,
                            stepwise=True, suppress_warnings=True)
print(model_auto.summary())  # affiche orders + AIC
forecast = model_auto.predict(n_periods=12)

# SARIMA manuel
model = SARIMAX(data, order=(1, 1, 1), seasonal_order=(1, 1, 1, 12))
result = model.fit(disp=False)
print(result.summary())

# Forecast avec intervalles
forecast = result.get_forecast(steps=12)
mean = forecast.predicted_mean
ci = forecast.conf_int(alpha=0.05)
print(mean, ci)

# Diagnostics
result.plot_diagnostics(figsize=(12, 8))
# Vérifier : standard residuals (random), histogram (gaussien),
# QQ-plot (alignement), correlogram (pas de pics)

# Ljung-Box test sur résidus
from statsmodels.stats.diagnostic import acorr_ljungbox
print(acorr_ljungbox(result.resid, lags=[10], return_df=True))

# SARIMAX avec exogènes
X = pd.DataFrame({'holiday': np.random.binomial(1, 0.05, len(data))}, index=data.index)
model_x = SARIMAX(data, exog=X, order=(1, 1, 1), seasonal_order=(1, 1, 1, 12))
result_x = model_x.fit(disp=False)

# Avec statsforecast (10-100x plus rapide sur batch de séries)
from statsforecast import StatsForecast
from statsforecast.models import AutoARIMA

df = pd.DataFrame({'unique_id': 'serie1', 'ds': data.index, 'y': data.values})
sf = StatsForecast(models=[AutoARIMA(season_length=12)], freq='M')
sf.fit(df)
forecast_sf = sf.predict(h=12, level=[95])
```

## Pour aller plus loin

- Box, Jenkins, Reinsel, *Time Series Analysis: Forecasting and Control* (5e éd. 2015) — bible
- Hyndman & Athanasopoulos, *Forecasting: Principles and Practice* (3e éd.) — chap. 9
- Hyndman & Khandakar, *Automatic Time Series Forecasting: The forecast Package for R* (JSS 2008)
- Brockwell & Davis, *Introduction to Time Series and Forecasting* (3e éd.)
- **Liens internes** : [[Stationarity]], [[Autocorrelation]], [[Exponential smoothing]], [[Forecasting framing]], [[Forecasting metrics]], [[statsforecast]] (service), [[Prophet]] (service)
