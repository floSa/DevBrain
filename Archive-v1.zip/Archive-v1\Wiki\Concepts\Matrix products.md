---
galaxie: wiki
nom: Matrix products (Hadamard, Kronecker, outer, dot)
alias: [produits matriciels, Hadamard, Kronecker, outer product, dot product, einsum]
type: concept
categorie: concept/linalg
sous_categories: [products, hadamard, kronecker, outer, dot, einsum]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [Hadamard, Kronecker, Einstein]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, linalg, products]
---

# Matrix products — Hadamard, Kronecker, outer, dot

## TL;DR

Plusieurs façons de "multiplier" deux matrices/vecteurs, **chacune avec une sémantique différente**. Confondre les produits = bugs subtils en deep learning ou stats. Cheat-sheet : **dot** pour transformation linéaire, **Hadamard** pour modulation élément-par-élément (gates LSTM/GRU, masques), **Kronecker** pour structure produit (graphes, kernels), **outer** pour rank-1, **einsum** pour tout exprimer proprement.

## Le problème

Tu as deux objets (vecteurs ou matrices) — il existe **5+ façons** de les combiner. Choisir la mauvaise = erreur silencieuse (dimensions OK mais résultat absurde). Comprendre la sémantique de chacune évite ces bugs.

## L'idée

### Produit scalaire / dot product

$$ x^\top y = \sum_i x_i y_i $$

Deux vecteurs de même taille → un scalaire. Mesure d'alignement, base de la similarité cosinus, du produit matriciel, et de tout en ML.

```python
np.dot(x, y)  # ou x @ y
```

### Produit matriciel standard

$$ (AB)_{ij} = \sum_k A_{ik} B_{kj} $$

$A_{m \times p} \cdot B_{p \times n} = (AB)_{m \times n}$. Composition de transformations linéaires.

**Coût** : $O(mnp)$. Pour cas spéciaux : Strassen $O(n^{2.807})$, ou algos sub-cubiques théoriques.

```python
A @ B   # syntax moderne
np.matmul(A, B)
np.dot(A, B)   # idem mais broadcasting différent
```

### Produit de Hadamard (élément par élément)

$$ (A \odot B)_{ij} = A_{ij} \cdot B_{ij} $$

Notation : $A \odot B$, parfois noté $A * B$ ou $A \circ B$. Les deux matrices doivent avoir **la même taille**.

Utilisations massives :
- **Gates** dans LSTM, GRU : $f_t \odot c_{t-1}$ (forget gate * cell state)
- **Masques** : appliquer un mask binaire $M$ → $A \odot M$
- **Modulation** : attention scores * values dans certaines variantes
- **Element-wise scaling** par feature

```python
A * B   # numpy : * est Hadamard, pas matmul
np.multiply(A, B)
```

### Produit externe (outer product)

$$ x y^\top \in \mathbb{R}^{m \times n} \quad \text{avec} \quad (xy^\top)_{ij} = x_i y_j $$

Deux vecteurs → matrice **de rang 1**. Inverse du dot product :
- $x^\top y$ : reduction → scalaire
- $x y^\top$ : expansion → matrice

Apparait en :
- **Updates de Hebbian learning** : $\Delta W = \eta x y^\top$
- **Approximations rank-1** d'opérateurs
- **Gradient backprop** : $\nabla_W L = \delta x^\top$ (delta out × input)

```python
np.outer(x, y)
x.reshape(-1, 1) @ y.reshape(1, -1)
np.einsum('i,j->ij', x, y)
```

### Produit de Kronecker

$$ A \otimes B = \begin{pmatrix} a_{11} B & a_{12} B & \cdots \\ a_{21} B & a_{22} B & \cdots \\ \vdots & \vdots & \ddots \end{pmatrix} $$

Pour $A_{m \times n}$ et $B_{p \times q}$, $A \otimes B$ est $(mp) \times (nq)$.

Propriétés clés :
- $(A \otimes B)(C \otimes D) = (AC) \otimes (BD)$
- $\text{vec}(AXB^\top) = (B \otimes A) \text{vec}(X)$ — utile pour résoudre des équations matricielles
- Eigenvalues de $A \otimes B$ = produits $\lambda_i(A) \cdot \mu_j(B)$

Usages :
- **Knowledge graphs** : compositions de relations
- **Multi-task learning** : structures produit
- **Cosmological data, tensor methods**
- **K-FAC** (Kronecker-Factored Approximate Curvature) — préconditionneur en optim 2nd ordre

```python
np.kron(A, B)
```

### Notation Einstein (einsum)

Notation **compacte et universelle** pour tous les produits :

$$ C_{ij} = \sum_k A_{ik} B_{kj} \quad \Leftrightarrow \quad C = \text{einsum}('ik,kj->ij', A, B) $$

Le standard : indices répétés (k) sont sommés, indices uniques (i, j) restent. **Lisible** une fois habitué.

Exemples :

```python
# Matmul
einsum('ij,jk->ik', A, B)

# Hadamard (pas de sommation)
einsum('ij,ij->ij', A, B)

# Dot product
einsum('i,i->', x, y)

# Outer
einsum('i,j->ij', x, y)

# Trace
einsum('ii->', A)

# Batched matmul (très utilisé en DL)
einsum('bij,bjk->bik', A, B)

# Attention score (Q K^T puis softmax)
scores = einsum('bqd,bkd->bqk', Q, K) / sqrt(d)
```

En PyTorch : `torch.einsum`. En TF : `tf.einsum`.

**Vivement recommandé** d'apprendre einsum — rend ton code de DL beaucoup plus clair.

## Quand c'est utile

| Produit | Usage typique |
|---|---|
| **dot / matmul** | Forward NN, similarité (cosine), tout en algèbre linéaire |
| **Hadamard** | Gates LSTM/GRU, masques, élément-wise modulation, dropout |
| **Outer** | Hebbian update, gradient W = δ x^T, rank-1 corrections |
| **Kronecker** | Structures produit, K-FAC, knowledge graphs, tensor methods |
| **einsum** | Tout — particulièrement utile en attention / transformer |

## Quand ça ne marche pas / pièges

- **Confusion `np.dot` vs `@` vs `*`** :
  - `A * B` : Hadamard (broadcast si possible)
  - `A @ B` ou `np.matmul(A, B)` : matriciel
  - `np.dot(A, B)` : matriciel pour 2D, ambigu pour >2D
  - En PyTorch : `torch.mm` (2D strict), `torch.matmul` (général), `*` (Hadamard)

- **Dimensions broadcasting** : en numpy/PyTorch, le broadcasting peut "réussir" sur des shapes incompatibles sémantiquement. **Toujours vérifier les shapes après chaque op.**

- **Hadamard avec broadcasting subtil** : `A * b` où `A: (m, n)` et `b: (n,)` broadcaste b sur les lignes. Pratique mais source de bugs si on s'attendait à un produit matriciel.

- **Kronecker → explosion mémoire** : $A_{100 \times 100} \otimes B_{100 \times 100}$ = matrice $10^4 \times 10^4 = 10^8$ entrées. Souvent on évite la construction explicite via des structures spécialisées (LazyKronecker, etc.).

- **`einsum` performance** : sur certaines opérations courantes, `matmul` est plus rapide que `einsum`. Profile si critique.

- **Trace de produit non-commutatif** : $\text{tr}(AB) = \text{tr}(BA)$ mais $\text{tr}(ABC) = \text{tr}(BCA) = \text{tr}(CAB)$, **pas** $\text{tr}(ACB)$. Attention aux invariants.

## Code minimal

```python
import numpy as np
import torch

A = np.random.randn(3, 4)
B = np.random.randn(4, 5)
x = np.random.randn(3)
y = np.random.randn(5)

# Matmul
C = A @ B   # (3, 5)
assert C.shape == (3, 5)

# Hadamard
M = np.random.randn(3, 4)
H = A * M   # (3, 4), element-wise

# Outer
ox = np.outer(x, y)  # (3, 5)

# Dot product
d = np.dot(x[:3], np.random.randn(3))  # scalaire

# Kronecker (attention à la taille !)
A_small = np.array([[1, 2], [3, 4]])
B_small = np.array([[0, 1], [1, 0]])
K = np.kron(A_small, B_small)  # 4x4

# Einsum — attention multi-head
B, T, D, H = 32, 100, 512, 8
d_head = D // H
Q = np.random.randn(B, T, D).reshape(B, T, H, d_head)
K_mat = np.random.randn(B, T, D).reshape(B, T, H, d_head)
scores = np.einsum('bthd,bshd->bths', Q, K_mat) / np.sqrt(d_head)
# (B, T, H, T) — pour chaque batch/head/query, scores vs toutes les keys
```

## Pour aller plus loin

- *einsum is all you need* (Tim Rocktäschel blog) — tutoriel canonique
- Strang, *Linear Algebra and Its Applications* — fondamentaux
- Petersen & Pedersen, *The Matrix Cookbook* — formulaire exhaustif
- **Liens internes** : [[SVD]], [[Eigendecomposition]], [[Vector norms]], [[embeddings]], [[tool-use]]
