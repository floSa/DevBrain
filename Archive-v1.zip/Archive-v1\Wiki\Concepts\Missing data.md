---
galaxie: wiki
nom: Missing data
alias: [missing data, NaN, imputation, MCAR, MAR, MNAR]
type: concept
categorie: concept/ml
sous_categories: [missing-data, imputation, preprocessing, ml]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Rubin 1976, Little-Rubin 2019, van Buuren 2018 (mice)]
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, ml, missing-data, imputation]
---

# Missing data

## TL;DR

Les données réelles ont **des trous**. Trois mécanismes (Rubin 1976) : **MCAR** (Missing Completely At Random — manque sans biais), **MAR** (Missing At Random — manque expliqué par d'autres features), **MNAR** (Missing Not At Random — manque dépend de la valeur elle-même, biais). Méthodes : **suppression** (rowwise/colwise, dangereuse), **simple imputation** (mean/median/mode/constant), **modèle-based** (kNN, MICE, IterativeImputer), **indicator variable** (NaN comme info), **modèles natifs** (XGBoost/LightGBM/CatBoost handle NaN). **MNAR difficile** : nécessite hypothèses sur le mécanisme de missingness. Toujours **fitter l'imputer sur train uniquement** pour éviter [[Data leakage]].

## Le problème

Causes typiques de NaN :
- Capteur défaillant
- Question optionnelle non-répondue
- Fusion de tables (LEFT JOIN avec absence)
- Truncation (date > seuil)
- Données collectées progressivement
- Privacy (champ caché)

Risque : **suppression naïve perd info ; imputation naïve introduit bruit ; impute en aveugle peut biaiser**.

## L'idée

### Taxonomie Rubin (1976)

#### MCAR — Missing Completely At Random

$$ P(R_i | X_i, Y_i) = P(R_i) $$

avec $R_i$ indicateur de missingness. Le fait qu'il manque ne dépend de **rien**.

**Exemple** : capteur s'éteint aléatoirement, formulaires perdus.

**Conséquence** : suppression sans biais (mais perd info). Imputation simple OK.

#### MAR — Missing At Random

$$ P(R_i | X_i, Y_i) = P(R_i | X_i^{\text{observed}}) $$

Le manque dépend des **autres variables observées**, pas de la valeur manquante.

**Exemple** : "salary" manquant plus souvent chez les jeunes (age observé).

**Conséquence** : imputation modèle-based valide (modélise $X_{missing} | X_{observed}$).

#### MNAR — Missing Not At Random

$$ P(R_i | X_i, Y_i) \text{ depend de } X_i^{\text{missing}} $$

Le manque dépend de la **valeur cachée** elle-même.

**Exemple** : les très hauts revenus refusent de répondre. Salaire manquant **dépend** du salaire.

**Conséquence** : biais d'imputation, **difficile à corriger**. Nécessite hypothèse sur le mécanisme (Heckman, sélection model).

### Diagnostiquer le mécanisme

- **Visualiser** : missingno, heatmap des NaN. Patterns ?
- **Test MCAR** : Little's MCAR test (chi² statistic)
- **Comparer distributions** : si "income" missing systématiquement haut/bas vs observed → MNAR suspect
- **Domain knowledge** : pourquoi cette valeur manque ? La logique métier explique souvent

### Méthodes — suppression

#### Listwise deletion (rowwise)

`df.dropna()` — supprimer les lignes avec un NaN.

- Sans biais si MCAR
- Perd énormément de data (5 features avec 10% NaN chacune → 41% de lignes complètes attendues)
- Standard en stats traditionnelles mais **gaspillage**

#### Pairwise deletion

Garder chaque paire de variables où les deux sont observées. Utilisé pour matrices de corrélation, OLS.

#### Colwise (drop column)

Si > 50% NaN, parfois drop la colonne entière. À justifier.

### Méthodes — imputation simple

| Méthode | Pour |
|---|---|
| **Mean** | continues, distribution gaussienne |
| **Median** | continues, robuste outliers |
| **Mode** | catégorielles |
| **Constant** (e.g. 0, -999) | flag explicite "missing" |
| **Forward/backward fill** | TS |
| **Interpolation linéaire** | TS continues |

**Problèmes** :
- Sous-estime la variance (tous les NaN deviennent identiques)
- N'utilise pas l'info des autres features
- OK pour quick baseline, pas plus

### Imputation modèle-based

#### KNN imputation

Pour chaque ligne avec NaN, chercher les $k$ plus proches voisins (sur features observées) et moyenner.

```python
from sklearn.impute import KNNImputer
imputer = KNNImputer(n_neighbors=5)
```

- Capture corrélations entre features
- Lent sur gros datasets
- Sensible à la distance metric et au scaling

#### Iterative imputation (MICE-like)

**MICE** (Multiple Imputation by Chained Equations, van Buuren) :

```
Init: impute toutes les NaN avec mean
Repeat:
    For each variable X_j with NaN:
        Fit model: X_j ~ X_{-j} on observed rows
        Predict X_j for missing rows
Until convergence
```

Implem sklearn : `IterativeImputer`. Standard moderne.

- Multiple imputation : générer $m$ versions imputées → ensemble de prédictions → quantif incertitude
- R `mice` package est référence

#### Modèles spécifiques

- **MissForest** : Random Forest itératif
- **Datawig** (Amazon) : NN-based imputation
- **GAIN** : GAN-based imputation
- **HyperImpute** : auto-sélection

#### Domain-aware

Souvent mieux : utiliser logique métier ("si NaN sur 'nb_enfants', mettre 0 si situation familiale = célibataire").

### Approche : indicator variable

Plutôt qu'imputer, **garder l'info que c'est manquant** :

```
X_age = original (avec NaN remplacé par 0)
X_age_missing = 1 si NaN, 0 sinon
```

Le modèle apprend que "missing" est un signal. **Très utile** quand MNAR (la missingness est informative).

Combine bien avec imputation simple : `SimpleImputer(add_indicator=True)`.

### Modèles natifs handle NaN

**LightGBM, XGBoost, CatBoost, HistGradientBoosting** : gèrent NaN nativement (apprennent le best split direction).

- Pas besoin d'imputer
- Gère MNAR automatiquement (NaN devient une catégorie)
- **Souvent meilleur** que pre-imputation

Pour **linear / NN / k-NN / SVM** : imputation obligatoire (peut pas gérer NaN).

### Multiple imputation

**Idée** (Rubin) : générer $m$ datasets imputés différents, analyser chaque, combiner via règles de Rubin.

- Quantifie incertitude due à imputation
- Standard en stats sérieuses (clinical trials, économétrie)
- ML pratique : moins utilisé (overhead), mais MICE en mode multiple imputation utile

### Workflow recommandé

1. **EDA** : visualiser pattern de NaN (missingno)
2. **Comprendre la cause** : domain knowledge → MCAR/MAR/MNAR
3. **Évaluer impact** : combien de lignes / colonnes affectées ?
4. **Drop columns** si > 70-80% NaN et pas d'info
5. **Indicator variable** pour les colonnes informatives
6. **Imputer** :
   - Tree-based model : laisser NaN
   - Linear / NN : Iterative ou KNN
7. **Évaluer** : CV avec et sans imputation, comparer

### Best practices

1. **Toujours documenter** : pour chaque feature, pourquoi y a-t-il des NaN ?
2. **Pipeline sklearn** : imputer dans pipeline pour éviter [[Data leakage]]
3. **Tree-based first** : si LightGBM marche directement avec NaN, often best
4. **Indicator + impute** : keep info AND handle
5. **Domain-aware imputation** : 0 vs median peut tout changer business-wise
6. **Production discipline** : nouveau record en prod peut avoir NaN sur features pas vues en train. Pipeline doit gérer.
7. **Test set** : ne PAS imputer test set avec ses propres stats (data leakage). Use train-fitted imputer.
8. **Multiple imputation** pour analyses statistiques sérieuses (clinical trial, paper)
9. **Drop avec parcimonie** : dropna() peut tuer 50% du dataset

## Quand c'est utile

- **Tout dataset réel** : NaN quasi-universel
- **Survey data** : non-response patterns
- **Sensor data** : capteurs faillent
- **EHR / clinical** : missing rampant
- **Web logs** : champs optionnels
- **Joins de tables** : LEFT JOIN crée NaN
- **TS multi-séries** : différentes histoires

## Quand ça ne marche pas / pièges

- **Confondre MCAR / MAR / MNAR** : impacte le choix d'imputation, biais.
- **MNAR ignoré** : "income manquant" imputé par moyenne → biais énorme si les hauts revenus refusent.
- **Imputation après split** sur test : leakage si imputer fitté sur test.
- **Mean imputation** sous-estime variance, sous-estime SE des estimateurs, faux IC.
- **Drop > 50% des rows** : perd énormément, souvent biais (qui survit ?)
- **Imputer puis CV** sans inclure imputer dans pipeline : leak (imputer voit fold de test).
- **Indicator variable trop nombreux** : si beaucoup de features ont indicator, explosion dimensionnelle.
- **Iterative imputation non-converge** : sur datasets pathologiques, sklearn peut diverger.
- **KNN imputation non-scalée** : distance dominée par features à grande échelle. Scale d'abord.
- **Domain-blind imputation** : "0 sur nb_enfants" peut vouloir dire "pas d'enfants" ou "missing" — pas pareil business-wise.
- **Tree-based + imputation** : redondant, peut dégrader (l'imputation introduit du bruit que NaN-natif évite).
- **Production différente** : test set bien imputé, prod a un schema slightly different → bug.

## Code minimal

```python
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer, KNNImputer, IterativeImputer
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression

# Setup avec NaN
df = pd.DataFrame({
    'age': [25, 30, np.nan, 60, np.nan, 45],
    'income': [30000, 50000, 80000, np.nan, 200000, 90000],
    'city': ['Paris', 'Lyon', np.nan, 'Marseille', 'Paris', np.nan],
    'target': [0, 0, 1, 1, 0, 1]
})

# Visualiser
print(df.isnull().sum())
print(f"% rows avec au moins 1 NaN: {df.isnull().any(axis=1).mean()*100:.0f}%")

# Visualisation patterns
# import missingno as msno
# msno.matrix(df)
# msno.heatmap(df)  # corrélations NaN entre colonnes

# 1. Suppression
df.dropna()  # ✗ perd 100% des rows ici
df.dropna(axis=1, thresh=int(len(df) * 0.5))  # drop col si >50% NaN

# 2. Simple imputation
imp = SimpleImputer(strategy='median')
df['age_imp'] = imp.fit_transform(df[['age']])

# Add indicator
imp_ind = SimpleImputer(strategy='median', add_indicator=True)
result = imp_ind.fit_transform(df[['age', 'income']])
# 2 colonnes + 2 colonnes indicator

# 3. KNN imputation (scaler d'abord!)
from sklearn.preprocessing import StandardScaler
num_cols = ['age', 'income']
df_num = df[num_cols].copy()
scaler = StandardScaler()
df_num_scaled = pd.DataFrame(scaler.fit_transform(df_num.fillna(df_num.mean())),
                              columns=num_cols)
knn = KNNImputer(n_neighbors=2)
df_knn = pd.DataFrame(knn.fit_transform(df_num_scaled), columns=num_cols)
# Inverse transform pour revenir aux échelles originales
df_knn = pd.DataFrame(scaler.inverse_transform(df_knn), columns=num_cols)

# 4. Iterative imputation
ii = IterativeImputer(max_iter=10, random_state=0)
df_ii = pd.DataFrame(ii.fit_transform(df[num_cols]), columns=num_cols)

# 5. Pipeline correct (imputer dans le pipeline)
num_transformer = Pipeline([
    ('impute', SimpleImputer(strategy='median', add_indicator=True)),
    ('scale', StandardScaler())
])
cat_transformer = Pipeline([
    ('impute', SimpleImputer(strategy='constant', fill_value='MISSING')),
])

preprocessor = ColumnTransformer([
    ('num', num_transformer, ['age', 'income']),
    ('cat', cat_transformer, ['city'])
])

pipe = Pipeline([
    ('preprocess', preprocessor),
    ('clf', LogisticRegression())
])

X = df.drop(columns='target')
y = df['target']
# pipe.fit(X, y)  # ✅ imputer fitté sur train via pipeline

# 6. LightGBM avec NaN natif (pas besoin d'imputer)
from lightgbm import LGBMClassifier
X_lgb = df.drop(columns=['target', 'city'])  # numeric uniquement
clf = LGBMClassifier(verbose=-1)
clf.fit(X_lgb, y)
# Garde les NaN, LightGBM apprend le best direction

# 7. Multiple imputation (MICE-style avec ensemble)
from sklearn.linear_model import BayesianRidge
imputers = []
predictions = []
for seed in range(5):
    ii = IterativeImputer(estimator=BayesianRidge(), max_iter=5, random_state=seed)
    X_imp = ii.fit_transform(df[num_cols])
    # Train un model sur X_imp, predire test, stocker
    # Pool the m predictions for final estimate + uncertainty

# 8. R-style `mice` via `miceforest` Python
# import miceforest as mf
# kds = mf.ImputationKernel(df, save_all_iterations=True)
# kds.mice(5)  # 5 itérations
# imputed_data = kds.complete_data()
```

## Pour aller plus loin

- Little & Rubin, *Statistical Analysis with Missing Data* (3e éd. 2019) — bible
- van Buuren, *Flexible Imputation of Missing Data* (2e éd. 2018) — MICE
- Rubin, *Inference and missing data* (Biometrika 1976) — paper original
- *missingno* package (visualisation), *fancyimpute*, *miceforest* (Python)
- Stef van Buuren, *mice R package* documentation
- **Liens internes** : [[Feature engineering]], [[Data leakage]], [[Imbalanced classification]], [[Time series feature engineering]]
