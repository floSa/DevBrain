---
galaxie: dev
nom: Ray Tune
alias: [ray-tune, tune]
categorie: ml/hp-tuning
sous_categories: [hyperparameter, distributed, search, ray]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Optuna]]", Hyperopt, Weights & Biases Sweeps, scikit-learn GridSearch]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, ml, hyperparameter, tuning]
url_officiel: https://docs.ray.io/en/latest/tune/index.html
url_docs: https://docs.ray.io/en/latest/tune/index.html
url_repo: https://github.com/ray-project/ray
---

# Ray Tune

## Pourquoi
Bibliothèque **hyperparameter search distribué**, partie de [[Ray]]. Supporte Random, Grid, Bayesian (via Ax/BOHB), PBT (Population Based Training), ASHA (early stopping). Excellent en cluster. Pour single-machine + simplicité, [[Optuna]] est souvent meilleur choix.

## Quand l'utiliser
- HP search distribué cluster (10+ machines)
- Combiner search + early stopping (ASHA)
- PBT pour exploration adaptive
- Intégration native Ray Train (distributed training)
- Tu utilises déjà Ray pour autre chose

## Quand NE PAS l'utiliser
- Single-machine simple → [[Optuna]] (UI Optuna Dashboard meilleur)
- Sweeps W&B-natif → Weights & Biases Sweeps
- Grid search simple → scikit-learn GridSearchCV
- Pas de cluster Ray dispo → setup overhead

## Pièges connus
- **Dependency Ray** : pas léger, transitive deps importantes
- **Schedulers** : ASHA (early stop), PBT, HyperBand — comprendre les hyperparams de l'algo de search
- **Search space** : `tune.choice`, `tune.uniform`, `tune.loguniform` — bien encoder
- **Reporting** : `tune.report(metric=...)` à chaque step pour ASHA functionne
- **Checkpointing** : pour PBT, indispensable de checkpoint correctement
- **Trial parallelism** : `resources_per_trial={"gpu": 1}` important sinon over-subscribe

## Liens
- [[Ray]] — framework parent
- [[Optuna]] — alternative single-machine
- Docs : https://docs.ray.io/en/latest/tune/index.html
- Tune vs Optuna : https://docs.ray.io/en/latest/tune/getting-started.html
