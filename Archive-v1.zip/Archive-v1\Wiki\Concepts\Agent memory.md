---
galaxie: wiki
nom: Agent memory
alias: [memory, MemGPT, Letta, Mem0, Zep, episodic, semantic memory]
type: concept
categorie: concept/agents
sous_categories: [memory, agents, llm, persistent]
domaines: [ai-eng]
maturite: emerging
auteurs_cles: [Packer 2023 (MemGPT)]
lecture_min: 5
created: 2026-05-20
modified: 2026-05-20
tags: [concept, agents, memory, llm]
---

# Agent memory

## TL;DR

Donner aux agents une **mémoire persistante** au-delà du context window. Types : **short-term** (conversation buffer), **long-term** (user facts, preferences), **episodic** (events, experiences passées), **semantic** (faits sur le monde), **procedural** (skills appris), **working** (scratchpad). Mécanismes : **summarization**, **vector retrieval**, **knowledge graph**, **MemGPT-style paging**. Solutions packagées : **Letta** (MemGPT), **Mem0**, **Zep**, **LangMem**, **Cognee**. Sans memory, un agent oublie tout entre sessions — pas viable pour assistants personnels, customer support long-terme.

## Le problème

LLMs ont **context window fini** (8K-1M). Une longue conversation, ou un assistant qui sert plusieurs sessions, dépasse vite. Comment **retenir** info importante au-delà du context ?

## L'idée

### Types de mémoire

#### Short-term (working memory)

Le **context window actuel** : système prompt + history actuel.

- Limité par taille window
- Reset à chaque session

#### Long-term

Info **persistante across sessions** :
- User preferences ("aime le thé vert")
- Past projects worked on
- Personal facts (job, family)

Stocké externally (DB, vector store), retrieved en context.

#### Episodic memory

**Events / experiences** passées :
- "Tuesday 3pm : we discussed X"
- "Yesterday : user said Y"

Temporally indexed.

#### Semantic memory

**Facts about the world**, abstraits :
- "Paris is capital of France"
- "User's job is data scientist"

Sans timestamp, juste assertions.

#### Procedural memory

**Skills / routines** appris :
- "When asked to summarize emails, use bullet points"
- Workflows custom

#### Working memory / Scratchpad

Buffer **temporaire** durant une tâche complexe :
- Notes intermédiaires
- Plans actuels
- État de raisonnement

### Mécanismes

#### Conversation summary

Quand history dépasse seuil, **résumer** les plus anciens turns :

```
[Old turns 1-50] → Summary 1
[Recent turns 50-100] → kept verbatim

Context = Summary 1 + recent turns
```

Simple, marche. Mais lossy.

#### Sliding window

Garder les N derniers tokens. Aucune mémoire long-term.

#### Vector retrieval (RAG over conversation)

Embed chaque turn (ou paragraph) → store in vector DB → retrieve pertinents pour query courante.

```
User asks : "What did we decide about the API design?"
→ Retrieve relevant past turns about "API design"
→ Add to context
```

Standard moderne. Pareil que [[RAG]] mais sur conversation history.

#### Knowledge graph

Extract **entities + relations** des conversations, build graph :
- Persons, projects, decisions, dates
- Relations : "user works at X", "X owns Y"

Query : graph traversal.

#### MemGPT (Packer 2023)

Inspired par OS : **hierarchical memory** + paging :
- **Core memory** : always in context (system prompt, working memory)
- **External memory** : stockée DB, **paged in/out** par tool calls
- Agent appelle `memory_save()`, `memory_search()`, etc. lui-même

LLM **décide** quoi save et retrieve. Bypass context limit.

Renommé **Letta** maintenant.

#### Mem0

Solution packagée :
- Auto-extract facts importants des conversations
- Vector DB pour storage
- API simple

```python
from mem0 import Memory
m = Memory()
m.add("User prefers dark mode")
relevant = m.search("UI preference")
```

#### Zep

Memory layer for chat apps :
- Auto-summarization
- Vector + graph hybrid
- Multi-user, multi-session

#### LangMem

LangChain extension pour memory management.

### Architecture typique

```
[User Message]
      ↓
[Memory Retrieval] ──→ Vector DB / Graph / Summary
      ↓ (top-K relevant memories)
[LLM context]
      ↓
[Response]
      ↓
[Memory Update] ──→ Extract facts, save
                   Trigger summarization if needed
```

### Strategies

#### Selective memory

Pas tout sauver. **Filtre** :
- User-stated facts ("I'm vegetarian")
- Project info
- Recurring preferences
- Skip : small talk, trivial

LLM décide quoi save :
```
"Should we remember this? Why?"
→ YES if personal, important, recurring
→ NO if temporal, casual
```

#### Memory hierarchies

- L1 (working) : in-context, full detail
- L2 (recent) : compressed, retrievable
- L3 (long-term) : facts only, semantic

#### Forgetting / decay

Pas tout garder forever. Decay :
- TTL sur memories
- Frequency-based : rare-used memories pruned
- Relevance-based : if not retrieved in X queries, archive

### Multi-user / multi-tenant

Critical : **isolation** par user :
- user_id sur chaque memory
- Filter retrieval par user

### Conflict resolution

User dit deux choses contradictoires ("I love coffee" puis "I hate coffee"). Comment ?
- Timestamp → garder le plus récent
- Confidence : preferences peuvent changer
- Sometimes : keep both ("Last week said love, now hate")

### Best practices

1. **Choisir le bon type** : pas besoin de tout pour tout
2. **Vector retrieval** = default
3. **MemGPT / Letta** : si vraiment beaucoup de memory à gérer
4. **Selective saving** : LLM filter ce qui mérite
5. **User control** : user peut voir / edit / delete memories
6. **Privacy first** : data sensitive (preferences, conversations)
7. **Multi-user isolation** : obligatoire
8. **Decay / archival** : pas garder forever sans nécessité
9. **Eval memory recall** : tester sur questions de session passée
10. **Audit log** : tracker memory writes / reads

## Quand c'est utile

- **Personal assistants** : retenir préférences, contexts
- **Customer support** : history client across calls
- **Long-running agents** : projects multi-session
- **Multi-turn complex tasks** : memory of plan, decisions
- **Educational tools** : track student progress
- **Therapy / coaching apps** : history des sessions
- **Code agents** : remember codebase patterns, decisions
- **Research agents** : track findings across queries

## Quand ça ne marche pas / pièges

- **Privacy concerns** : memory peut contenir PII, secrets
- **Hallucinated memories** : LLM fabrique memories qui ne se sont pas produites
- **Conflicting memories** : sans resolution, contradictions
- **Stale memories** : info périmée non updated
- **Cost storage** : vector DB pour millions de users explose
- **Retrieval latency** : ajoute 100-500ms par query
- **Memory overflow** : trop de memories, retrieval bruyant
- **Cross-user leakage** : mauvais filter → user A voit memory user B
- **Compliance** : GDPR right to be forgotten → memory deletion required
- **Trusting memory blindly** : LLM peut over-rely sur old memory wrong
- **Multi-modal memories** : images / audio harder à memorize
- **Update consistency** : edit a memory, ensure all references updated

## Code minimal

```python
# 1. Vector-based memory (simple)
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

class VectorMemory:
    def __init__(self, dim=384):
        self.embedder = SentenceTransformer("all-MiniLM-L6-v2")
        self.index = faiss.IndexFlatIP(dim)
        self.memories = []
    
    def add(self, text, metadata=None):
        emb = self.embedder.encode([text])[0]
        self.index.add(np.array([emb]))
        self.memories.append({"text": text, "metadata": metadata or {}})
    
    def search(self, query, k=5):
        query_emb = self.embedder.encode([query])[0]
        scores, idx = self.index.search(np.array([query_emb]), k)
        return [self.memories[i] for i in idx[0]]

mem = VectorMemory()
mem.add("User prefers Python over JavaScript", {"type": "preference"})
mem.add("User works at Anthropic")
results = mem.search("What's the user's job?")
print(results)

# 2. Mem0
# pip install mem0ai
# from mem0 import Memory
# m = Memory()
# m.add("I'm a vegan", user_id="alice")
# m.add("I like sushi", user_id="alice")  # Could be flagged as conflict
# memories = m.search("food preferences", user_id="alice")

# 3. Letta (MemGPT)
# pip install letta
# Server-based, LLM tool calls memory_save/memory_search/etc.

# 4. Zep
# pip install zep-python
# from zep_python import ZepClient
# zc = ZepClient(api_url="...", api_key="...")
# zc.memory.add(session_id="user_123", message={...})
# memories = zc.memory.search(session_id="user_123", text="API design")

# 5. Summary-based memory (manual)
class SummaryMemory:
    def __init__(self, llm, max_recent=10):
        self.llm = llm
        self.summary = ""
        self.recent = []  # last N turns
        self.max_recent = max_recent
    
    def add_turn(self, user_msg, ai_msg):
        self.recent.append({"user": user_msg, "ai": ai_msg})
        if len(self.recent) > self.max_recent:
            # Move oldest to summary
            oldest = self.recent.pop(0)
            self.summary = self.llm(
                f"Add this turn to existing summary:\n"
                f"Old summary: {self.summary}\n"
                f"Turn: {oldest}\n"
                f"New summary:"
            )
    
    def get_context(self):
        ctx = f"Conversation summary: {self.summary}\n\nRecent turns:\n"
        for turn in self.recent:
            ctx += f"User: {turn['user']}\nAssistant: {turn['ai']}\n\n"
        return ctx

# 6. Knowledge graph memory (simplified)
import networkx as nx

class GraphMemory:
    def __init__(self):
        self.G = nx.DiGraph()
    
    def add_fact(self, subject, predicate, obj):
        self.G.add_edge(subject, obj, label=predicate)
    
    def query(self, subject):
        if subject in self.G:
            return [(n, self.G[subject][n]['label']) for n in self.G[subject]]
        return []

gm = GraphMemory()
gm.add_fact("Alice", "works_at", "Anthropic")
gm.add_fact("Alice", "likes", "Python")
print(gm.query("Alice"))

# 7. Selective memory (LLM judges what to save)
def should_remember(turn, llm):
    response = llm.invoke(f"""
Should we save this turn for long-term memory?
Turn: {turn}

Criteria:
- Personal fact about user → YES
- Preference / decision → YES
- Casual / small talk → NO
- Temporal context only → NO

Answer: YES or NO with 1 sentence reason.
""")
    return "YES" in response.content[:10]
```

## Pour aller plus loin

- Packer et al., *MemGPT: Towards LLMs as Operating Systems* (2023) — MemGPT → Letta
- *Mem0* documentation
- *Zep* documentation
- *Letta* (formerly MemGPT) repository
- *LangMem* (LangChain) experimental
- Andrej Karpathy talks on LLM agents and memory
- *Cognee*, *MemoryBank*, other emerging frameworks
- **Liens internes** : [[Agent patterns]], [[Tool use patterns]], [[RAG]], [[Context engineering]]
