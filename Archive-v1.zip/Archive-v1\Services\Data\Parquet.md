---
galaxie: dev
nom: Parquet
alias: [apache-parquet, parquet]
categorie: data/format
sous_categories: [columnar, compression, analytics]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: C++/Java (lib)
clients_officiels: [python (pyarrow), java, c++, rust, go]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["Apache ORC", "[[Avro]]", "Arrow IPC", "CSV"]
remplace: ["CSV"]
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, data, format, columnar, parquet]
url_officiel: https://parquet.apache.org/
url_docs: https://parquet.apache.org/docs/
url_repo: https://github.com/apache/parquet-format
---

# Parquet

## Pourquoi
Format de stockage **colonnaire** open-source. Compression efficace (Snappy/ZSTD/GZIP), prédicat pushdown, lecture sélective de colonnes, schemas typés. Standard de fait des **lakehouses** (lit par tout le monde : [[pandas]], [[Polars]], [[DuckDB]], Spark, [[BigQuery]], [[Snowflake]], Iceberg, Delta).

## Quand l'utiliser
- Tout fichier "tabulaire" persistant > quelques MB
- Data lake / lakehouse (avec [[Apache Iceberg]] ou Delta Lake)
- Échange entre process / langages (vs CSV)
- Snapshots de DataFrames longue durée (pandas/polars `to_parquet`)
- Données analytiques à requêter ad-hoc avec [[DuckDB]]

## Quand NE PAS l'utiliser
- Échange humain-lisible → CSV / JSON
- Streaming row-par-row → Avro ou Arrow IPC
- Très petits fichiers (< 1 MB) → overhead pas justifié
- Updates fréquents → format en lecture seule, mieux vaut une vraie DB

## Pièges connus
- **Petits fichiers** : "small files problem" sur object stores ; merger en chunks plus gros
- **Compression** : Snappy (rapide, défaut) vs ZSTD (taille minimale) vs GZIP (legacy) — choisir selon usage
- **Schema evolution** : possible mais avec règles ; documenter les changements
- **Partition by** : `year/month` pour pruning, mais éviter cardinalité trop haute
- **Row groups** : taille à tuner (~128MB-1GB typique)
- **NaN vs Null** : floats NaN ≠ Null logique, attention en interop pandas/Arrow

## Liens
- [[Polars]], [[pandas]], [[DuckDB]] — lecteurs/écrivains principaux
- [[Apache Iceberg]] / Delta Lake — lakehouses qui bâtissent dessus
- pyarrow : lib Python officielle
- Best practices : https://parquet.apache.org/docs/file-format/configurations/
