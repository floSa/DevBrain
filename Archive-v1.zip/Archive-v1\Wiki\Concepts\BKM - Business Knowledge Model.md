---
galaxie: wiki
nom: BKM - Business Knowledge Model
alias: [BKM, business-knowledge-model, dmn-bkm, function-definition-dmn]
type: concept
categorie: concept/business-rules
sous_categories: [dmn, bkm, reusable-logic, business-rules]
domaines: [data-science, ml-eng, ai-eng]
maturite: established
auteurs_cles: [OMG, Bruce Silver]
lecture_min: 6
created: 2026-05-21
modified: 2026-05-21
tags: [concept, dmn, bkm, business-rules]
---

# BKM — Business Knowledge Model

## TL;DR

Une **fonction réutilisable** dans DMN, paramétrée, invocable depuis plusieurs décisions. C'est le mécanisme **DRY** (Don't Repeat Yourself) du standard. Représenté graphiquement par un rectangle à coin coupé dans le DRD, contient une **function definition** (paramètres formels + corps en boxed expression). Permet de **factoriser** une formule mathématique, une logique métier complexe, ou même une autre decision table. Sans BKM, on duplique la même règle dans 3 décisions ; avec BKM, on l'écrit une fois et on l'invoque.

## Le problème

Tu modélises un domaine assurance auto. Tu as 3 décisions distinctes :
- **Tarification annuelle** : utilise une formule de prime
- **Recalcul à la souscription** : utilise la même formule de prime
- **Simulation tarif client** : utilise la même formule de prime

Sans BKM : tu duplique la formule dans 3 decision tables → désynchronisation garantie après 6 mois (un changement appliqué à une seule). Avec BKM : la formule est écrite une fois, les 3 décisions l'invoquent.

C'est l'équivalent d'une **fonction** dans un langage de programmation, mais explicite dans le modèle métier.

## L'idée

### Représentation dans le DRD

```
┌──────────────┐
│ Decision A   │
└──────┬───────┘
       │  (knowledge requirement, ligne pleine)
       ▼
┌─┐──────────┐
│ │   BKM    │   ← rectangle avec un coin "coupé" en haut-gauche
│ │ formule  │
│ │  prime   │
└─────────────┘
       ▲
       │  (knowledge requirement)
┌──────┴───────┐
│ Decision B   │
└──────────────┘
```

Plusieurs décisions peuvent dépendre du même BKM. Un BKM peut aussi invoquer un autre BKM (composition).

### Anatomie d'un BKM

Trois parties :

1. **Identité** : `id` (interne) + `name` (lisible)
2. **Paramètres formels** : liste de `(nom, type)`
3. **Corps** : une **boxed expression** (literal, decision table, function, context...)

Souvent le corps est une **function definition** (`encapsulatedLogic` en XML), mais ça peut être n'importe quelle boxed expression.

### Invocation depuis une décision

Une décision invoque un BKM via une **invocation boxed expression** :

```
┌────────────────────────────────────────┐
│ Decision : Prime tarifaire             │
├────────────────────────────────────────┤
│  formulePrime               ← BKM     │
├──────────────┬─────────────────────────┤
│ vehicule     │ customer.car            │
│ profil       │ customer.profile        │
│ kilom_annuel │ customer.km_per_year    │
└──────────────┴─────────────────────────┘
```

Le moteur évalue les expressions de droite (bindings), puis appelle le BKM avec ces valeurs.

### BKM vs Decision

Différence clé :

| BKM | Decision |
|---|---|
| Pas autonome — doit être invoqué | Autonome — peut être l'output final |
| Pas d'inputs implicites — paramètres explicites obligatoires | Peut lire des Input Data du modèle directement |
| Réutilisable | Spécifique à un cas |
| Logique "comment" | Logique "quoi" |

Règle pédagogique de Bruce Silver : *"Une décision est WHAT (quelle est l'éligibilité ?). Un BKM est HOW (comment calculer le ratio ?)."*

### BKM avec corps = decision table

Le corps d'un BKM peut être une **decision table** complète. C'est très puissant : tu peux paramétrer une table de règles.

Exemple : BKM `niveau_risque(âge, antecedents)` → decision table interne qui retourne `"low"`, `"medium"`, `"high"`. Invocable depuis n'importe quelle décision qui a besoin du niveau de risque.

### Composition de BKM

Un BKM peut invoquer un autre BKM. Tu construis une **bibliothèque de fonctions métier** réutilisables.

```
BKM mensualite(amount, rate, n)
  └── invoque BKM taux_marche(date) pour ajuster le rate
```

### Knowledge Requirement

L'arc DRD spécifique BKM → Decision (ou BKM → BKM) est un **knowledge requirement** (flèche pleine), différent du **information requirement** (Input Data → Decision, en flèche pleine aussi, mais sémantiquement distinct dans le XML).

### Quand extraire un BKM ?

Heuristiques :
- **Duplication** : la même logique apparaît dans 2+ décisions → BKM
- **Encapsulation** : la formule est complexe et tu veux la nommer pour la documenter
- **Évolution** : tu veux pouvoir changer la formule sans toucher les décisions appelantes
- **Test isolé** : tester un BKM est plus simple que tester chaque décision appelante
- **Paramétrisation** : la même logique avec des inputs différents → BKM

Heuristiques pour **NE PAS** extraire :
- Logique utilisée une seule fois → reste inline (literal expression dans la décision)
- BKM avec 0 paramètres → c'est probablement une constante, pas un BKM
- BKM qui ne fait que renvoyer un input → inutile, supprime

### BKM vs ML model

Important : un BKM est **déterministe et explicite**. Si tu veux invoquer un modèle ML probabiliste, ce n'est pas un BKM standard. Deux patterns :

1. **BKM avec corps natif** : certains moteurs (Camunda) permettent un BKM avec body Java/Kotlin/JS qui appelle un service externe → utiliser pour ML
2. **Input Data** : le score ML est un **input** de la décision (calculé en amont), pas un BKM

Mais conceptuellement, un BKM peut **wrapper** un appel ML s'il reste exprimable comme fonction pure (mêmes inputs → mêmes outputs, idempotent).

## Quand c'est utile

- **Formule métier utilisée par plusieurs décisions** : prime, taux, score
- **Encapsulation lisible** : nommer une logique complexe rend le DRD propre
- **Évolution maîtrisée** : un changement de formule = 1 endroit, pas 5
- **Bibliothèque métier** : équivalent d'un "namespace" de fonctions
- **Test unitaire isolé** : tester `formule_prime(x, y, z)` directement
- **Versioning fin** : versionner les BKM séparément des décisions
- **Combo BPMN** : un BKM peut être appelé par un *Business Rule Task* directement (sans passer par une decision)

## Quand ça ne marche pas / pièges

- **Sur-extraction** : BKM utilisé une fois = bruit dans le DRD
- **BKM sans paramètres** : indique soit un singleton (mettre en Input Data) soit une erreur de conception
- **BKM ↔ BKM cycles** : interdit, le moteur refuse
- **BKM qui modifie un état** : c'est interdit en FEEL pur, mais possible avec extensions Java → anti-pattern
- **Confusion paramètres formels / réels** : `formulePrime(amount, rate, duration)` doit être invoqué avec **bindings nommés**, pas par position (sauf si le moteur le supporte)
- **BKM qui invoque un service externe** : sort du cadre DMN pur, dépend du moteur (Camunda permet via job workers)
- **Pas de typage strict** : si tu déclares `amount: number` et tu passes une string, certains moteurs ne throw qu'au runtime
- **Documentation pauvre** : un BKM mérite son docstring (description metier de chaque paramètre)
- **Mismatch unit** : passer un montant en cents alors que le BKM attend des euros → bug silencieux. Convention : nommer `amount_eur` plutôt que `amount`
- **BKM duplicatant un built-in FEEL** : si tu écris `BKM string_upper(s) = upper case(s)`, c'est inutile, FEEL a déjà `upper case`

## Code minimal

### BKM en XML

```xml
<businessKnowledgeModel id="loanFormulaBKM" name="loanFormula">
  <variable name="loanFormula" typeRef="number"/>
  <encapsulatedLogic kind="FEEL">
    <formalParameter name="amount" typeRef="number"/>
    <formalParameter name="rate" typeRef="number"/>
    <formalParameter name="duration" typeRef="number"/>
    <literalExpression>
      <text>amount * rate / (1 - (1 + rate) ** -duration)</text>
    </literalExpression>
  </encapsulatedLogic>
</businessKnowledgeModel>
```

### Invocation depuis une Decision

```xml
<decision id="monthlyPayment" name="Monthly payment">
  <variable name="monthly_payment" typeRef="number"/>
  <knowledgeRequirement>
    <requiredKnowledge href="#loanFormulaBKM"/>
  </knowledgeRequirement>
  <informationRequirement><requiredInput href="#loan_amount"/></informationRequirement>
  <informationRequirement><requiredInput href="#interest_rate"/></informationRequirement>
  <informationRequirement><requiredInput href="#years"/></informationRequirement>

  <invocation>
    <literalExpression><text>loanFormula</text></literalExpression>
    <binding>
      <parameter name="amount" typeRef="number"/>
      <literalExpression><text>loan_amount</text></literalExpression>
    </binding>
    <binding>
      <parameter name="rate" typeRef="number"/>
      <literalExpression><text>interest_rate / 12</text></literalExpression>
    </binding>
    <binding>
      <parameter name="duration" typeRef="number"/>
      <literalExpression><text>years * 12</text></literalExpression>
    </binding>
  </invocation>
</decision>
```

### BKM avec corps decision table

```xml
<businessKnowledgeModel id="riskLevelBKM" name="riskLevel">
  <encapsulatedLogic>
    <formalParameter name="age" typeRef="number"/>
    <formalParameter name="claims_count" typeRef="number"/>

    <decisionTable hitPolicy="UNIQUE">
      <input label="age"><inputExpression typeRef="number"><text>age</text></inputExpression></input>
      <input label="claims"><inputExpression typeRef="number"><text>claims_count</text></inputExpression></input>
      <output label="level" typeRef="string"/>
      <rule>
        <inputEntry><text>&lt; 25</text></inputEntry>
        <inputEntry><text>&gt; 2</text></inputEntry>
        <outputEntry><text>"high"</text></outputEntry>
      </rule>
      <!-- ... -->
    </decisionTable>
  </encapsulatedLogic>
</businessKnowledgeModel>
```

### Test unitaire d'un BKM (Camunda)

```java
DmnEngine engine = DmnEngineConfiguration.createDefaultDmnEngineConfiguration().buildEngine();
DmnDecision bkmDecision = engine.parseDecision("loanFormula", inputStream);

VariableMap vars = Variables.createVariables()
    .putValue("amount", 100000.0)
    .putValue("rate", 0.005)        // 6% annuel / 12
    .putValue("duration", 240.0);    // 20 ans * 12

DmnDecisionResult result = engine.evaluateDecision(bkmDecision, vars);
double monthlyPayment = result.getSingleResult().<Double>getSingleEntry();
assertEquals(716.43, monthlyPayment, 0.01);
```

### Invocation depuis FEEL (sans XML)

```feel
// Dans une cellule ou literal expression
loanFormula(amount: 100000, rate: 0.005, duration: 240)

// Ou positional (moins recommandé)
loanFormula(100000, 0.005, 240)
```

## Pour aller plus loin

- OMG DMN spec, section 6.3 (Business Knowledge Model) : https://www.omg.org/spec/DMN/
- Bruce Silver, *DMN Method and Style*, ch. 13 (BKM patterns)
- Camunda BKM docs : https://docs.camunda.io/docs/components/modeler/dmn/business-knowledge-model/
- KIE / Drools BKM doc : https://docs.drools.org/
- **Liens internes** : [[Decision Model and Notation]], [[Boxed Expressions]], [[FEEL]], [[Decision Tables]], [[DRD - Decision Requirements Diagram]]
