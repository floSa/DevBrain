---
galaxie: wiki
nom: t-test and ANOVA
alias: [Student t-test, Welch t-test, ANOVA, F-test, paired t-test, Wilcoxon]
type: concept
categorie: concept/stats
sous_categories: [t-test, anova, hypothesis-testing, parametric, mean-comparison]
domaines: [data-science]
maturite: established
auteurs_cles: [Student (Gosset) 1908, Fisher 1925]
lecture_min: 9
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, t-test, anova]
---

# t-test and ANOVA — comparaison de moyennes

## TL;DR

Tests paramétriques pour comparer des **moyennes** entre groupes. **t-test** = 1 ou 2 groupes. **ANOVA** = ≥ 3 groupes (généralisation). Reposent sur la **normalité** (approximative pour grands $n$ via TCL). Si violée : équivalents non-paramétriques (**Wilcoxon**, **Kruskal-Wallis**) ou [[Bootstrap]].

## Le problème

Tu veux savoir si :
- La conversion moyenne d'une landing A diffère de B (t-test 2 groupes)
- Une nouvelle pédagogie change la note moyenne par rapport à la moyenne historique (t-test 1 groupe)
- 4 algorithmes ML diffèrent en moyenne sur un set de benchmarks (ANOVA)

## L'idée

### t-test (Student / Welch)

Statistique de base pour 2 groupes indépendants $A, B$ :

$$ t = \frac{\bar X_A - \bar X_B}{SE} $$

avec $SE$ l'erreur standard de la différence.

- **Student's t-test** : suppose **variances égales** $\sigma_A^2 = \sigma_B^2$. SE poolée.
- **Welch's t-test** : ne suppose pas l'égalité des variances. Plus robuste. **Par défaut** dans `scipy.stats.ttest_ind` avec `equal_var=False`.

Distribution sous $H_0$ : Student avec $df$ degrés de liberté (Welch a une formule pour $df$ effectif).

### Variantes

| Cas | Test | Quand |
|---|---|---|
| 1 échantillon vs valeur fixe | One-sample t-test | $H_0: \mu = \mu_0$ |
| 2 échantillons indépendants | Independent t-test (Welch préféré) | groupes différents |
| 2 échantillons pairés | Paired t-test | mêmes sujets pré/post |
| Non-paramétrique 2 indep. | Mann-Whitney U / Wilcoxon rank-sum | distribution non-normale |
| Non-paramétrique pairés | Wilcoxon signed-rank | pairé + non-normal |

### ANOVA — Analysis of Variance

Pour comparer $k \geq 3$ groupes :

$H_0$ : $\mu_1 = \mu_2 = \dots = \mu_k$
$H_1$ : au moins une moyenne diffère

Idée : décomposer la variance totale en variance **entre groupes** (signal) et **intra groupes** (bruit). Statistique :

$$ F = \frac{\text{MS}_{\text{between}}}{\text{MS}_{\text{within}}} = \frac{\frac{1}{k-1} \sum_g n_g (\bar X_g - \bar X)^2}{\frac{1}{n-k} \sum_g \sum_i (X_{g,i} - \bar X_g)^2} $$

Sous $H_0$ : $F \sim F(k-1, n-k)$. Si $F$ grand → significatif.

### Post-hoc — quel groupe diffère ?

ANOVA dit "au moins un diffère" mais pas lequel. **Post-hoc tests** font des comparaisons par paires :
- **Tukey HSD** : populaire, corrige type I
- **Bonferroni** : trop conservateur si beaucoup de groupes
- **Dunnett** : compare chaque groupe à un témoin

Toujours **un seul** post-hoc par expérience (cf. [[Multiple testing correction]]).

### Hypothèses sous-jacentes

1. **Indépendance** des observations — critique. Données pairées → utiliser version pairée.
2. **Normalité** des résidus par groupe — moins critique si $n \geq 30$ (TCL), sinon test de Shapiro-Wilk.
3. **Homoscédasticité** (variances égales) — pour Student t-test et ANOVA classique. Sinon Welch ou Welch-ANOVA.

Si 1 violée : choisir un test approprié (mixed effects).
Si 2 violée : Wilcoxon (non-paramétrique) ou [[Bootstrap]].
Si 3 violée : Welch's t-test ou Welch's ANOVA (`scipy.stats.f_oneway` ne le gère pas → utiliser pingouin ou statsmodels).

### Effect size

La p-value seule ne suffit pas. Toujours rapporter **Cohen's d** pour le t-test ou **eta²** pour l'ANOVA :

$$ \text{Cohen's d} = \frac{\bar X_A - \bar X_B}{s_{\text{pooled}}} $$

| Cohen's d | Interprétation |
|---|---|
| 0.2 | petit effet |
| 0.5 | moyen |
| 0.8 | grand |

## Quand c'est utile

- A/B testing (Welch t-test par défaut)
- Comparer la performance de plusieurs modèles ML sur un benchmark (ANOVA)
- Effet d'un traitement avant/après (paired t-test)
- Avant régression : check si un facteur catégoriel a un effet

## Quand ça ne marche pas / pièges

- **Variances très inégales** + Student t-test → résultat biaisé. Toujours préférer Welch.
- **Normalité violée avec petit $n$ (<30)** → Wilcoxon plus sûr
- **ANOVA + petits groupes très différents en taille** → puissance hétérogène, post-hoc à choisir avec soin
- **Tests multiples** sans correction (faire t-test sur 10 paires → 10 chances d'avoir un faux positif). Voir [[Multiple testing correction]].
- **Confusion paired vs unpaired** : si tu mesures le même utilisateur avant/après, c'est pairé. Te tromper = perte massive de puissance.
- **Données ordinales** (notes 1-5) traitées en continu → Wilcoxon plus rigoureux

## Code minimal

```python
from scipy import stats
import pandas as pd

# 2 groupes indépendants — Welch t-test (default depuis scipy 1.0+)
result = stats.ttest_ind(a, b, equal_var=False)
print(f"t={result.statistic:.3f}, p={result.pvalue:.4f}, df={result.df:.1f}")

# Pairé
result_paired = stats.ttest_rel(before, after)

# Non-paramétrique
result_mw = stats.mannwhitneyu(a, b, alternative='two-sided')

# ANOVA 1-way
result_anova = stats.f_oneway(group1, group2, group3, group4)

# Post-hoc Tukey HSD
from statsmodels.stats.multicomp import pairwise_tukeyhsd
tukey = pairwise_tukeyhsd(endog=df['value'], groups=df['group'], alpha=0.05)
print(tukey.summary())

# Effect size — Cohen's d
import pingouin as pg
pg.compute_effsize(a, b, eftype='cohen')
```

## Implémentations concrètes

- `scipy.stats` — t-tests, ANOVA basique, post-hoc minimes
- `statsmodels.stats.multicomp` — Tukey, Bonferroni
- `pingouin` — interface unifiée et pédagogique, effect sizes natifs
- R : `t.test`, `aov`, `TukeyHSD`, `wilcox.test`

## Pour aller plus loin

- *Statistical Inference* (Casella & Berger) — référence
- *Discovering Statistics Using R* (Andy Field) — pédagogique
- **Liens internes** : [[Hypothesis testing]], [[Chi-squared tests]], [[Bootstrap]], [[Confidence intervals]], [[Multiple testing correction]], [[statsmodels]]
