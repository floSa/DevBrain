<%*
/* Template Templater + Markdown statique (lisible hors Obsidian).
   À copier dans <projet>/services/<nom>/README.md.
   Référence règle : Rules/Documentation/Database-Relational.md du DevBrain. */
-%>
# Service — <NOM_DU_SERVICE>

<!--
À remplacer : <NOM_DU_SERVICE>, et tous les champs <À REMPLIR>.
Référence : règle [[Database-Relational]] du DevBrain (`Rules/Documentation/Database-Relational.md`).
-->

## Rôle métier

<À REMPLIR : 2-4 lignes — ce que stocke cette DB pour l'application.>

Exemple :
> Stockage transactionnel principal : utilisateurs, sessions, contenus, métadonnées des fichiers uploadés. Source de vérité ACID. Les données binaires vont dans `services/minio/`.

## Schéma relationnel

### Tables principales

| Table | PK | FKs | Rôle | Volumétrie estimée |
|-------|----|----|------|---------------------|
| `users` | `id` | - | Comptes utilisateurs | ~10k |
| `sessions` | `id` | `user_id → users.id` | Sessions actives | ~50k |
| `documents` | `id` | `user_id → users.id` | Métadonnées docs uploadés | ~100k |
| `<À REMPLIR>` |  |  |  |  |

### Index non triviaux

| Table | Colonne(s) | Type | Pourquoi |
|-------|-----------|------|----------|
| `documents` | `(user_id, created_at DESC)` | btree | Listing récent par user |
| `<À REMPLIR>` |  |  |  |

### Schéma visuel

```mermaid
erDiagram
    users ||--o{ sessions : has
    users ||--o{ documents : owns
    users {
        uuid id PK
        string email
        string name
        timestamp created_at
    }
    sessions {
        uuid id PK
        uuid user_id FK
        timestamp expires_at
    }
    documents {
        uuid id PK
        uuid user_id FK
        string filename
        string s3_key
        timestamp created_at
    }
```

## Migrations

- **Outil** : <À REMPLIR : Alembic / Flyway / Liquibase / Prisma migrate>
- **Localisation** : `services/<nom>/alembic/versions/` (ou équivalent)
- **Convention de nommage** : `YYYY-MM-DD-NNNN-<description>.py`

### Procédure ajout d'une migration

```bash
# Générer une migration auto-detectée depuis les modèles SQLAlchemy
uv run alembic revision --autogenerate -m "add column users.locale"

# Reviewer le fichier généré (Alembic n'est pas magique : vérifier les renames!)

# Appliquer en local
uv run alembic upgrade head

# Si besoin de rollback (en dev uniquement)
uv run alembic downgrade -1
```

### Politique des migrations destructrices

- ❌ `DROP COLUMN` interdit sans plan de transition (deprecation marker → cleanup en N+2)
- ❌ `DROP TABLE` interdit sans archivage explicite
- ✅ `ADD COLUMN NOT NULL DEFAULT` : OK si défaut sensé
- ⚠️ Migrations sur grosses tables : utiliser `ALTER TABLE ... CONCURRENTLY` (PG) — voir [[REX - Postgres]] du DevBrain

## Configuration

Variables d'env (cf. `.env.example` + règle [[Config-Env]]) :

| Variable | Type | Défaut | Description |
|----------|------|--------|-------------|
| `DATABASE_URL` | `PostgresDsn` | — | URL de connexion |
| `DATABASE_POOL_SIZE` | `int` | `10` | Taille du pool SQLAlchemy |
| `DATABASE_POOL_TIMEOUT` | `int` | `30` | Timeout secondes |
| `DATABASE_ECHO_SQL` | `bool` | `false` | Logger les requêtes (dev only) |

## Contrat d'interface

- **Driver** : `<À REMPLIR : psycopg3 / asyncpg / pg8000>`
- **ORM** : `<À REMPLIR : SQLAlchemy 2.x / Prisma / sqlx>`
- **Migrations** : `<Alembic / Flyway / ...>`
- **Pool de connexions** : configuré via `DATABASE_POOL_SIZE`

## Démarrage local

```bash
# Via docker-compose
docker-compose up -d postgres

# Vérifier
docker-compose exec postgres psql -U <user> -d <db> -c "\dt"

# Migrations
uv run alembic upgrade head
```

## Backups & restore

- **Fréquence** : <À REMPLIR : daily / hourly>
- **Outil** : <À REMPLIR : pg_dump + cron / managed (RDS automated) / Barman>
- **Rétention** : <À REMPLIR : 30 jours>
- **Localisation** : <À REMPLIR : MinIO bucket `*-backups`>
- **Procédure de restore** : `<lien vers docs/OPERATIONS.md#restore-postgres>`
- **Drill restore** : effectué le `<DATE>` (à refaire trimestriellement)

## Pièges connus à anticiper

- **Pool exhaustion** : `max_connections × workers × pool_size` à dimensionner — voir [[REX - Postgres]]
- **Migrations sur grosses tables** : `CONCURRENTLY` obligatoire
- **`SELECT *` en boucle** : éviter, projeter les colonnes utiles

## Liens

- DevBrain : [[Postgres]] · [[REX - Postgres]] · [[Alembic]]
- Doc : <https://www.postgresql.org/docs/>
- Schéma exporté : `schema.sql` (versionné dans ce dossier)
- ADR migrations : `docs/adr/<NNNN>-migration-strategy.md`
