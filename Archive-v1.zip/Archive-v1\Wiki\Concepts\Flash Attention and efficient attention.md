---
galaxie: wiki
nom: Flash Attention & efficient attention
alias: [Flash Attention, GQA, MQA, MLA, PagedAttention, sliding window, sparse attention]
type: concept
categorie: concept/transformers
sous_categories: [attention, flash-attention, efficient, kv-cache, gqa]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Dao 2022 (Flash Attention), Shazeer 2019 (MQA), Ainslie 2023 (GQA), Kwon 2023 (PagedAttention)]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, attention, llm, optimization]
---

# Flash Attention & efficient attention

## TL;DR

[[Self-attention]] est **$O(n^2)$ en compute ET mémoire** → bottleneck pour contexts longs et inférence. Quatre familles d'optimisation : (1) **Flash Attention** (Dao 2022) — réordonner les opérations pour fit en SRAM, gain ~3x sans approximation ; (2) **GQA / MQA / MLA** — partager K/V entre heads pour réduire KV cache (5-10x) ; (3) **Sliding window / sparse / linear** — n'attendre qu'un sous-ensemble (Mistral, BigBird, Performer) ; (4) **PagedAttention** (vLLM) — gestion mémoire KV cache style OS paging (+continuous batching). En production, **toutes** ces techniques se combinent.

## Le problème

[[Self-attention]] :
- **Compute** : $O(n^2 d)$ — matrice $QK^\top$ a $n^2$ entrées
- **Mémoire HBM** : $O(n^2)$ pour stocker la matrice d'attention
- **KV cache (inférence)** : domine la mémoire pour serving long context

Sur GPU :
- HBM (~80 GB) lent (1.5-3 TB/s)
- SRAM (~20 MB par SM) ultra-rapide (~19 TB/s)
- **Bottleneck = transfer HBM ↔ SRAM**, pas compute

Comment **réduire la mémoire** sans sacrifier la qualité ?

## L'idée

### 1. Flash Attention (Dao 2022)

**Idée** : ne **jamais matérialiser** la matrice $n \times n$ d'attention en HBM. Calcul **tile-by-tile** dans la SRAM.

#### Algorithme (online softmax)

Réécrire softmax incrémentalement :

```
for each block of Q, K, V (qui fit en SRAM):
    compute partial QK^T
    compute partial softmax (online)
    accumulate partial output O
```

**Astuces** :
- **Online softmax** : $m^{new} = \max(m^{old}, m^{tile})$, ajuster les sums
- Pas besoin de stocker la matrice d'attention complète
- En backward : **recompute** au lieu de stocker (gradient checkpointing-like)

**Résultats** :
- ~3x speedup vs standard attention
- Mémoire **$O(n)$** au lieu de $O(n^2)$
- **Exact**, pas une approximation

#### Versions

- **Flash Attention v1** (2022) : papier original
- **Flash Attention v2** (2023) : meilleur parallélisme sur GPU H100
- **Flash Attention v3** (2024) : exploite **TMA** (Tensor Memory Accelerator) et **FP8** sur H100

**Standard moderne** : utilisé partout (PyTorch SDPA, xformers, vLLM, etc.).

### 2. Variants d'attention pour réduire KV cache

Le **KV cache** domine la mémoire en inférence (200-500 GB pour Llama-70B en context 32K).

#### MHA (baseline)

Chaque head a son propre $K, V$. Cache size : $2 \cdot n \cdot L \cdot h \cdot d_k \cdot \text{bytes}$.

#### MQA (Multi-Query Attention, Shazeer 2019)

**Toutes les heads partagent le même $K, V$** :

- Réduit KV cache par facteur $h$ (souvent 8-32x)
- Légère dégradation qualité
- Utilisé : Falcon, PaLM

#### GQA (Grouped-Query Attention, Ainslie 2023)

**Compromis** : grouper les heads par $g$ groupes, chaque groupe partage K/V :

- $h$ heads → $g$ K/V groupes (typ. $g = h/8$)
- Réduit cache par $h/g$
- **Quasi pas de perte de qualité**
- **Standard moderne** : Llama 2 70B, Llama 3, Mistral, Qwen2, Gemma

#### MLA (Multi-head Latent Attention, DeepSeek 2024)

Cache les **latents** (compressed K/V) au lieu des K/V eux-mêmes :

- Cache 10-20x plus petit que MHA
- Meilleure qualité que GQA (selon DeepSeek)
- Permet contexts très longs avec petit cache
- DeepSeek V2/V3/R1

### 3. Sparse / windowed attention

#### Sliding window attention (Mistral, Longformer)

Chaque token n'attend que les $w$ tokens précédents (e.g. $w = 4096$).

- $O(n \cdot w)$ au lieu de $O(n^2)$
- Mistral 7B : window 4K avec context 32K → "rolling" attention
- Layer-by-layer : information se propage en couches profondes

#### Global + local (Longformer, BigBird)

Combine sliding window local + quelques tokens "global" qui voient tout (CLS, séparateurs).

#### Sparse attention (Sparse Transformer, BigBird)

Patterns prédéfinis (block-sparse, random, dilated). Permet $O(n \sqrt n)$ ou $O(n \log n)$.

#### Native Sparse Attention (DeepSeek 2024)

Apprend les patterns sparse pendant le training. Records de performance.

#### Linear attention (Performer, Linformer)

Approxime softmax pour atteindre $O(n)$. Performant en théorie, qualité variable en pratique.

#### Ring Attention (Liu 2023)

Pour très long context : **distribuer** le KV sur plusieurs GPUs en anneau. Communication overlapped. Permet 1M+ tokens.

### 4. PagedAttention (Kwon 2023, vLLM)

**Problème** : KV cache pré-alloué pour max_seq_len → énorme gâchis (la plupart des requests sont courtes).

**Solution** : style OS paging
- Découper le KV cache en **blocks** (pages) fixes
- Allouer dynamiquement
- **Continuous batching** : ajouter/retirer requests in-flight

**Résultat** :
- 2-4x throughput vs static batching
- Standard chez **vLLM**, **TGI**, **SGLang**

### 5. Prefix caching / RadixAttention

Si plusieurs requests partagent un prefix (system prompt, few-shot), **partager** le KV cache pour ce prefix.

- **RadixAttention** (SGLang) : arbre radix pour matcher prefixes
- vLLM prefix caching : standard
- Gain énorme : prompt caching 50-90% sur use cases avec system prompt commun

### 6. Spéculatif & autres

- **Speculative decoding** : drafter rapide propose plusieurs tokens, vérifier avec gros model. Voir [[Speculative decoding]].
- **Multi-LoRA serving** (S-LoRA, Punica) : servir plusieurs LoRA adapters sur même base model.
- **KV cache quantization** : 4-bit ou 8-bit pour KV → divise le cache par 2-4x avec peu de perte.

### Récapitulatif

| Méthode | Réduit | Type | Standard ? |
|---|---|---|---|
| Flash Attention | mémoire (HBM ↔ SRAM) | exact | **default partout** |
| MHA | — | baseline | déprécié pour gros modèles |
| MQA | KV cache (h x) | approx | Falcon, PaLM |
| GQA | KV cache (h/g x) | approx | **Llama 3, Mistral, Qwen** |
| MLA | KV cache (~10x) | exact + latent | DeepSeek |
| Sliding window | compute O(nw) | local approx | Mistral, Longformer |
| Sparse | compute O(n√n) | sparse | research, DeepSeek NSA |
| Linear | compute O(n) | softmax approx | research |
| Ring Attention | distrib. mémoire | exact, distributed | research, vLLM long-ctx |
| PagedAttention | KV cache alloc | management | **vLLM, TGI** |
| RadixAttention | shared prefix | KV reuse | **SGLang** |

### Choix en production

| Scénario | Stack |
|---|---|
| **Serving LLM** | Flash Attention + GQA (modèle) + PagedAttention + prefix caching (vLLM/TGI/SGLang) |
| **Training LLM** | Flash Attention v2/v3 + GQA + Ring Attention long context |
| **Long context (>32K)** | Sliding window + Flash Attention + YaRN |
| **Multi-tenant serving** | vLLM + multi-LoRA serving + prefix caching |
| **Edge / local** | KV cache quantization + GQA + small model |

## Quand c'est utile

- **Toujours en LLM moderne** : Flash Attention non-négociable
- **Inference serving** : vLLM/TGI/SGLang utilisent toutes ces techniques
- **Long context (>32K)** : sliding window ou Ring Attention nécessaire
- **Memory constrained** : KV cache quant + GQA
- **High throughput** : continuous batching + PagedAttention
- **Shared prefix** (chatbot, RAG) : prefix caching gain énorme
- **Training (preview)** : Flash Attention v3 + GQA permet contexts longs

## Quand ça ne marche pas / pièges

- **Flash Attention 1 sur Volta** (V100) : pas optimisé. FA2/3 demande Ampere/Hopper.
- **MQA dégrade trop la qualité** sur modèles small. GQA souvent meilleur.
- **GQA mal numéroté** : $g$ trop petit (peu de groupes) → near-MQA, qualité baisse.
- **MLA implémentation maison** : complexe, bugs faciles. Utiliser implem officielle.
- **Sliding window perte d'information** : modèle ne peut pas accéder loin sans hops. Combiner avec global tokens.
- **Linear attention qualité** : approximations softmax dégradent souvent perf. Préférer Flash + sparse pour long context.
- **PagedAttention overhead** : sur petits batch (1 request), pas d'avantage vs static. Optimal en multi-tenant.
- **KV cache quant agressive** : 2-bit casse souvent qualité. Stick to 4-8 bits.
- **Ring Attention complexité** : demande implem distribuée propre. Pour 99% des cas, Flash Attention single-GPU suffit.
- **Prefix caching cache pollution** : trop de prefixes uniques → cache miss permanent.

## Code minimal

```python
import torch
import torch.nn.functional as F

# Flash Attention via PyTorch SDPA (utilise FA2/3 si disponible)
Q = torch.randn(2, 8, 1024, 64, device='cuda', dtype=torch.bfloat16)
K = torch.randn(2, 8, 1024, 64, device='cuda', dtype=torch.bfloat16)
V = torch.randn(2, 8, 1024, 64, device='cuda', dtype=torch.bfloat16)

# Standard
out = F.scaled_dot_product_attention(Q, K, V, is_causal=True)

# Via flash-attn directement
# from flash_attn import flash_attn_func
# out = flash_attn_func(Q, K, V, causal=True)

# GQA usage
class GQA(torch.nn.Module):
    def __init__(self, d_model, n_heads, n_kv_heads):
        super().__init__()
        assert n_heads % n_kv_heads == 0
        self.n_heads = n_heads
        self.n_kv_heads = n_kv_heads
        self.n_rep = n_heads // n_kv_heads
        self.head_dim = d_model // n_heads
        self.W_q = torch.nn.Linear(d_model, n_heads * self.head_dim, bias=False)
        self.W_k = torch.nn.Linear(d_model, n_kv_heads * self.head_dim, bias=False)
        self.W_v = torch.nn.Linear(d_model, n_kv_heads * self.head_dim, bias=False)
        self.W_o = torch.nn.Linear(d_model, d_model, bias=False)
    
    def forward(self, x):
        B, T, _ = x.shape
        Q = self.W_q(x).view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        K = self.W_k(x).view(B, T, self.n_kv_heads, self.head_dim).transpose(1, 2)
        V = self.W_v(x).view(B, T, self.n_kv_heads, self.head_dim).transpose(1, 2)
        
        # Repeat K/V to match Q heads (GQA)
        K = K.repeat_interleave(self.n_rep, dim=1)
        V = V.repeat_interleave(self.n_rep, dim=1)
        
        out = F.scaled_dot_product_attention(Q, K, V, is_causal=True)
        out = out.transpose(1, 2).contiguous().view(B, T, -1)
        return self.W_o(out)

# vLLM usage (PagedAttention + continuous batching automatique)
# from vllm import LLM, SamplingParams
# llm = LLM(model="meta-llama/Meta-Llama-3-8B-Instruct", 
#           enable_prefix_caching=True,
#           max_model_len=8192)
# outputs = llm.generate(["Hello!"], SamplingParams(temperature=0.7))

# Sliding window via Mistral
# Mistral implem : window_size = 4096
# https://github.com/mistralai/mistral-src

# KV cache quantization (HF transformers)
# from transformers import AutoModelForCausalLM
# model = AutoModelForCausalLM.from_pretrained(
#     "meta-llama/Meta-Llama-3-8B",
#     torch_dtype=torch.bfloat16,
#     attn_implementation="flash_attention_2",
#     # kv_cache_quantization=True  # if supported
# )

# Compter le KV cache theorique
def kv_cache_size_gb(n_layers, n_heads, head_dim, seq_len, batch=1, dtype_bytes=2,
                      kv_heads=None):
    kv_heads = kv_heads or n_heads  # MHA si non spécifié
    return 2 * n_layers * kv_heads * head_dim * seq_len * batch * dtype_bytes / 1e9

# Llama-3-70B : 80 layers, 64 heads (8 KV heads GQA), head_dim 128
print(f"MHA 32K context: {kv_cache_size_gb(80, 64, 128, 32000, kv_heads=64):.1f} GB")
print(f"GQA 32K context: {kv_cache_size_gb(80, 64, 128, 32000, kv_heads=8):.1f} GB")
# Différence = 8x !
```

## Pour aller plus loin

- Dao et al., *FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness* (NeurIPS 2022)
- Dao, *FlashAttention-2: Faster Attention with Better Parallelism and Work Partitioning* (2023)
- Shah et al., *FlashAttention-3: Fast and Accurate Attention with Asynchrony and Low-precision* (2024)
- Shazeer, *Fast Transformer Decoding: One Write-Head is All You Need* (2019) — MQA
- Ainslie et al., *GQA: Training Generalized Multi-Query Transformer Models from Multi-Head Checkpoints* (2023)
- DeepSeek-AI, *DeepSeek-V2* paper (2024) — MLA
- Kwon et al., *Efficient Memory Management for Large Language Model Serving with PagedAttention* (SOSP 2023) — vLLM
- Liu et al., *Ring Attention with Blockwise Transformers for Near-Infinite Context* (2023)
- **Liens internes** : [[Self-attention]], [[Positional encoding]], [[Transformer architectures]], [[Inference optimization]], [[Quantization]]
