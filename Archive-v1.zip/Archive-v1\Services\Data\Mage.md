---
galaxie: dev
nom: Mage
alias: [mage, mage-ai]
categorie: data/orchestrator
sous_categories: [notebook, data, orchestrator, python, low-code]
licence: Apache-2.0
licence_type: open-source
hosted: self ou cloud (Mage Pro)
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 2
mes_projets: []
alternatives: ["[[Prefect]]", "[[Dagster]]", "[[Airflow]]", "[[Kestra]]"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, orchestrator, notebook, python]
url_officiel: https://www.mage.ai/
url_docs: https://docs.mage.ai/
url_repo: https://github.com/mage-ai/mage-ai
---

# Mage

## Pourquoi

Orchestrateur Python avec **UI notebook-style**. Concept : un pipeline est un graphe de **blocks** (chacun = un script Python typé `loader`, `transformer`, `exporter`, `data_loader`, etc.), édités dans la UI comme des cellules Jupyter. Live data preview entre chaque block → boucle de feedback rapide.

Positionnement : alternative "low-code friendly" à Airflow / Prefect / Dagster, ciblant **data engineers + analystes** qui aiment l'interactivité notebook. Niche claire mais écosystème modeste vs les leaders. **Mage Pro** = version cloud managed. Adoption en baisse 2024-2026 face à Dagster / Prefect qui mûrissent.

## Quand l'utiliser

- **Équipe avec background notebooks** (Jupyter) qui veut sortir de l'ad-hoc
- **Pipelines moyens (10-100 blocks)** : ingestion → transform → export
- **Live preview data** entre blocks pour debug rapide
- **Combo ingestion + transform + export** (ETL classique simple)
- **dbt orchestration** : blocks dbt natifs
- **Streaming pipelines** : Mage supporte aussi le streaming (Kafka, Kinesis)
- **Low-code friendly** : analystes qui galèrent avec Airflow YAML/Python pur

## Quand NE PAS l'utiliser

- **Production grande échelle** → [[Airflow]] / [[Prefect]] / [[Dagster]] (plus matures, mieux outillés)
- **Workflows complexes branchés** : conditional logic / dynamic DAGs → orchestrateurs vrais
- **Multi-langage** → [[Kestra]]
- **Asset-centric / lineage** → [[Dagster]] (Mage n'a pas ce paradigme)
- **Standard industrie requis** : Mage pas un choix safe long-terme vs Airflow
- **Très grande équipe** : moins de doc/Stack Overflow que les leaders

## Pièges connus

- **Notebook-style encourage mauvaise structuration** : code copy-paste entre blocks, peu de tests
- **Écosystème modeste** : moins de plugins / intégrations que Airflow / Dagster
- **Pas standard industrie** : recruter sur Mage = trouver moins de profils
- **UI couplée à l'orchestrateur** : pas de "Mage CLI-only" propre, pensé UI-first
- **Versioning Git** : Mage push vers Git mais workflow Git-first moins naturel qu'avec Dagster/Prefect
- **Live preview = exec partiel** : peut induire en erreur (production != preview env)
- **Multi-user concurrent** dans la UI : pas pensé pour 20+ devs simultanés
- **Documentation inégale** : core OK, advanced topics manquent
- **Roadmap** : Mage AI a réduit ses sorties open-source 2024+ au profit du tier Pro → risque communautaire

## Code minimal

```bash
# Install + lancer
pip install mage-ai
mage start my_project
# UI : http://localhost:6789
```

```python
# blocks/data_loaders/load_orders.py
import requests
import pandas as pd

@data_loader
def load_data(*args, **kwargs):
    response = requests.get("https://api.example.com/orders")
    return pd.DataFrame(response.json())

@test
def test_output(output, *args):
    assert output is not None
    assert len(output) > 0, "Output is empty"
```

```python
# blocks/transformers/filter_big_orders.py
@transformer
def transform(df, *args, **kwargs):
    return df[df["amount"] > 100]
```

```python
# blocks/data_exporters/to_bigquery.py
from mage_ai.io.bigquery import BigQuery
from mage_ai.settings.repo import get_repo_path
from os import path

@data_exporter
def export_data(df, *args, **kwargs):
    config_path = path.join(get_repo_path(), "io_config.yaml")
    BigQuery.with_config(config_path, profile="default").export(
        df, table_id="project.dataset.orders",
        if_exists="append",
    )
```

```yaml
# pipelines/etl_daily/metadata.yaml (extrait)
schedules:
  - name: daily_6am
    schedule_type: time
    schedule_interval: "0 6 * * *"
    start_time: "2026-01-01 06:00:00"
```

## Liens

- [[Comparatif - Orchestrateurs data]]
- [[Prefect]] / [[Dagster]] / [[Airflow]] — alternatives matures
- [[Kestra]] — alternative multi-langage YAML
- [[dbt]] — combo classique (Mage orchestre les runs)
- Docs : https://docs.mage.ai/
- GitHub : https://github.com/mage-ai/mage-ai
