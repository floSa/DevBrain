---
galaxie: wiki
nom: Concentration inequalities
alias: [Markov, Chebyshev, Jensen, Hoeffding, Chernoff, McDiarmid]
type: concept
categorie: concept/probability
sous_categories: [concentration, markov, chebyshev, hoeffding, chernoff, finite-sample]
domaines: [ml-eng]
maturite: established
auteurs_cles: [Markov, Chebyshev, Hoeffding 1963, Chernoff 1952]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, probability, concentration, bounds]
---

# Concentration inequalities

## TL;DR

Inégalités qui **bornent la probabilité qu'une variable aléatoire s'écarte beaucoup de sa moyenne**. Contrairement au [[Central limit theorem|TCL]] (asymptotique), elles donnent des bornes **non-asymptotiques** valables pour tout $n$. Hiérarchie de finesse : **Markov** (très grossière) → **Chebyshev** (mieux) → **Hoeffding** (exponentielle) → **Bernstein** (utilise la variance). Fondation des bornes de généralisation et des analyses PAC.

## Le problème

Le TCL dit que la moyenne empirique converge vers une gaussienne **asymptotiquement**. Mais en pratique on a $n$ fini. Comment quantifier l'écart entre $\bar X_n$ et $\mu$ pour un $n$ donné, avec des garanties **non-asymptotiques** ?

## L'idée

### Markov

Pour $X \geq 0$ et $a > 0$ :

$$ \mathbb{P}(X \geq a) \leq \frac{\mathbb{E}[X]}{a} $$

Très lâche mais très générale (ne demande que la moyenne). Base de toutes les autres.

### Chebyshev

Pour toute variable $X$ avec moyenne $\mu$ et variance $\sigma^2$ :

$$ \mathbb{P}(|X - \mu| \geq k \sigma) \leq \frac{1}{k^2} $$

Décroît **polynomialement** en $k$. Toujours pessimiste mais universelle.

Exemple : $\mathbb{P}(|X - \mu| \geq 3\sigma) \leq 1/9 \approx 11\%$. À comparer à la règle des 68/95/99.7% pour gaussienne (~0.3%).

### Jensen

Pour $f$ convexe :

$$ f(\mathbb{E}[X]) \leq \mathbb{E}[f(X)] $$

Concave : inégalité inversée. **Fondation** de :
- Log-likelihood vs ELBO (Jensen sur $\log$)
- Cross-entropy ≥ entropie (Jensen sur KL)
- Inégalité AM-GM
- Bornes pour les fonctions de variables aléatoires

### Hoeffding

Pour $X_i \in [a_i, b_i]$ indépendantes :

$$ \mathbb{P}\left(\left|\bar X_n - \mu\right| \geq t\right) \leq 2 \exp\left(-\frac{2 n^2 t^2}{\sum_i (b_i - a_i)^2}\right) $$

Si les variables sont dans $[0, 1]$ :

$$ \mathbb{P}(|\bar X_n - \mu| \geq t) \leq 2 e^{-2 n t^2} $$

**Décroissance exponentielle** — bien plus serré que Chebyshev. C'est l'inégalité standard pour bornes de généralisation **finite-sample**.

### Chernoff

Bornes exponentielles via la **moment generating function** $\mathbb{E}[e^{\lambda X}]$ :

$$ \mathbb{P}(X \geq a) \leq \inf_{\lambda > 0} e^{-\lambda a} \mathbb{E}[e^{\lambda X}] $$

Optimisation sur $\lambda$ donne souvent des bornes très tight. Hoeffding est un cas spécial de Chernoff appliqué à des variables bornées.

### Bernstein

Pour $X_i$ indépendantes avec $|X_i| \leq M$ et variance $\sigma_i^2$ :

$$ \mathbb{P}(|\bar X_n - \mu| \geq t) \leq 2 \exp\left(-\frac{n t^2}{2 \sigma^2 + \frac{2 M t}{3}}\right) $$

**Mieux que Hoeffding** quand la variance est petite. Capture l'effet de "faible variance" → faible déviation.

### McDiarmid (bounded differences)

Pour $f(X_1, \dots, X_n)$ telle que changer $X_i$ change $f$ d'au plus $c_i$ :

$$ \mathbb{P}(|f - \mathbb{E}[f]| \geq t) \leq 2 \exp\left(-\frac{2 t^2}{\sum_i c_i^2}\right) $$

Généralisation à des fonctions arbitraires (pas juste sommes). Base de plein de bornes en ML (e.g. stabilité algorithmique → généralisation).

### Hiérarchie des bornes (typique)

Pour des variables bornées et $n$ grand :

```
       ___________
Markov:  loose --   1/a
Chebyshev:  1/k²    (polynomial)
Hoeffding:  e^(-cnt²) (exponentiel, ignore variance)
Bernstein:  e^(-nt²/(2σ² + Mt)) (exponentiel + variance)
```

Bernstein > Hoeffding > Chebyshev > Markov en finesse.

### Bornes "with high probability"

Idiomatique en ML :

> "Avec probabilité $\geq 1 - \delta$, $|\bar X_n - \mu| \leq t$"

Résoudre Hoeffding pour $\delta$ donne :

$$ t = \sqrt{\frac{\log(2/\delta)}{2n}} $$

Forme omniprésente dans les bornes PAC / PAC-Bayes / generalization bounds.

### Sub-gaussian / sub-exponential

Une variable est **sub-gaussienne** si $\mathbb{P}(|X| \geq t) \leq 2 e^{-c t^2}$ pour un $c > 0$. Permet d'appliquer des bornes Hoeffding-like sans hypothèse de bornage. Variables bornées et gaussiennes le sont.

**Sub-exponentielle** : décroissance en $e^{-c|t|}$ (e.g. exponentielle, $\chi^2$). Bornes Bernstein-like.

## Quand c'est utile

- **Bornes de généralisation** (PAC, PAC-Bayes, Rademacher) : Hoeffding/Bernstein partout
- **A/B testing finite-sample** : valider qu'on a assez de data
- **Bandits algorithmes** : UCB borne sur l'écart de la moyenne empirique
- **Concentration de moyennes empiriques** en ML théorique
- **Analyse de SGD** : concentration du gradient mini-batch
- **Détection d'outliers** : seuils basés sur Chebyshev ou sub-gaussienne

## Quand ça ne marche pas / pièges

- **Variance infinie / queues lourdes** : Markov reste valide, mais Hoeffding/Chebyshev demandent moments finis. Cauchy → seul Markov peut s'appliquer (et même pas Markov d'ordre 2).
- **Variables dépendantes** : les bornes classiques supposent l'indépendance. Pour mélange, McDiarmid + Azuma-Hoeffding pour martingales.
- **Bornes worst-case** : très pessimistes en pratique. Utiles pour garanties théoriques, pas pour estimer la vraie déviation.
- **Confusion avec TCL** : TCL est asymptotique, concentration est finite-sample. Complémentaires.
- **$c_i$ trop grand dans McDiarmid** : la borne devient inutile. Souvent on suppose $c_i = O(1/n)$ pour des moyennes.
- **Hoeffding nécessite bornage** : pour variables non-bornées (gaussienne), utiliser variantes sub-gaussiennes (concentration de mesure)

## Code minimal

```python
import numpy as np

# Borne de Hoeffding pour la moyenne d'une Bernoulli
def hoeffding_bound(n, delta):
    """Renvoie t tel que P(|X_bar - p| >= t) <= delta."""
    return np.sqrt(np.log(2 / delta) / (2 * n))

# Exemple : combien d'échantillons pour estimer une proba à ε près ?
def required_samples(epsilon, delta):
    """n tel que IC ≤ ε avec proba 1-δ via Hoeffding."""
    return int(np.ceil(np.log(2 / delta) / (2 * epsilon**2)))

print(f"Pour ε=0.05, δ=0.05 : n = {required_samples(0.05, 0.05)}")
# Pratique pour A/B testing pre-experiment power calculation

# Vérification empirique (Monte Carlo)
p_true = 0.3
n = 1000
n_trials = 10000
deviations = []
for _ in range(n_trials):
    X = np.random.binomial(1, p_true, n)
    dev = abs(X.mean() - p_true)
    deviations.append(dev)
deviations = np.array(deviations)

# Comparer borne théorique vs empirique
for t in [0.02, 0.05, 0.1]:
    bound = 2 * np.exp(-2 * n * t**2)  # Hoeffding
    empirical = np.mean(deviations >= t)
    print(f"t={t}: empirique={empirical:.4f}, Hoeffding bound={bound:.4f}")

# Jensen (illustration)
# E[log X] ≤ log E[X] (concavité du log)
X = np.random.exponential(1, 10000)
print(f"E[log X] = {np.log(X).mean():.3f}")
print(f"log E[X] = {np.log(X.mean()):.3f}")
# La 1ère est plus petite — Jensen
```

## Pour aller plus loin

- Boucheron, Lugosi, Massart, *Concentration Inequalities: A Nonasymptotic Theory of Independence* (2013) — référence
- Vershynin, *High-Dimensional Probability* (2018) — sub-gaussian, sub-exponential
- Hoeffding, *Probability inequalities for sums of bounded random variables* (JASA 1963)
- **Liens internes** : [[Central limit theorem]] (vs asymptotic), [[VC dimension]], [[PAC learning]], [[Bootstrap]] (vs concentration approach), [[Generalization bounds]]
