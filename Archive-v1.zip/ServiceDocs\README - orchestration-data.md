# Service — <NOM_DU_SERVICE>

<!--
Template à copier dans <projet>/services/<nom>/README.md.
Référence règle : Rules/Documentation/Orchestration-Data.md du DevBrain.
-->

## Rôle métier

<À REMPLIR : 2-3 lignes — quels pipelines orchestrés, pour quel besoin.>

Exemple :
> Orchestre les pipelines RAG : ingestion PDFs → parsing → chunking → embedding → indexation Qdrant. Plus pipeline de réindexation hebdo et eval qualité quotidienne.

## Pipelines / DAGs

### Pipeline 1 — `<À REMPLIR : ingest_documents>`

**Rôle** : <description>

**Schedule** : `<À REMPLIR : @hourly / 0 */6 * * * / sensor-on-S3>`

**Schéma** :

```mermaid
flowchart LR
  raw[(MinIO raw)] --> detect[Detect new docs]
  detect --> parse[Parse via Docling]
  parse --> chunk[Chunking]
  chunk --> embed[Embed chunks]
  embed --> index[(Qdrant index)]
  index --> notify[Slack notify]
```

| Étape | Type | Inputs | Outputs | Retries | Timeout |
|-------|------|--------|---------|---------|---------|
| `detect` | sensor | MinIO `*-raw` | list[doc_id] | — | 5 min |
| `parse` | task | doc_id | NormalizedDoc | 3 (exp backoff) | 10 min |
| `chunk` | task | NormalizedDoc | list[Chunk] | 2 | 2 min |
| `embed` | task | list[Chunk] | list[Vector] | 5 (jittered) | 30 min |
| `index` | task | list[Vector] | upsert count | 3 | 5 min |
| `notify` | task | summary | Slack msg | 1 | 30s |

**Idempotence** : chaque tâche réinsère sans dupliquer (key = `doc_id` ou `(doc_id, chunk_idx)`)

### Pipeline 2 — `<À REMPLIR>`

<même structure>

## Politique de reprise globale

- **Stratégie de retry par défaut** : `<3 retries, exponential backoff, jitter>`
- **Comportement sur échec API LLM** : retry avec backoff jusqu'à 5x, puis dead-letter queue
- **Comportement sur DB indisponible** : alert immediate + retry manuel
- **Timeouts par défaut** : task 10 min, run global 2h

## Déclencheurs (Sensors / Schedules)

| Pipeline | Trigger | Détails |
|----------|---------|---------|
| `ingest_documents` | Sensor | Dépôt fichier dans `s3://<projet>-raw/incoming/` |
| `daily_eval` | Schedule cron | `0 3 * * *` UTC (= 4h Paris) |
| `weekly_reindex` | Schedule cron | `0 2 * * 0` UTC (dimanche 3h Paris) |
| `manual_backfill` | Manual | Via UI ou `dagster job execute` |

> Tous les schedules sont en UTC.

## Alerting & logs

- **Logs structurés** : JSON, envoyés à `<À REMPLIR : Loki / CloudWatch>`
- **Alerting** :
  - Slack `#alerts-data` sur **failed run**
  - PagerDuty sur **failed pipeline critique** (ex: `ingest_documents` 3 fois consécutives)
  - Email weekly digest avec métriques

## Backfill

```bash
# Relancer tous les docs entre deux dates
uv run dagster job execute -j ingest_documents \
  --config-json '{"params": {"start_date": "2026-04-01", "end_date": "2026-04-30"}}'
```

> **Avant tout backfill** : vérifier idempotence + dimensionner les workers.

## Contrat d'interface

- **Outil** : `<À REMPLIR : Dagster / Airflow / Prefect / Flyte>`
- **Définition des pipelines** : `services/<nom>/pipelines/`
- **Resources** (DBs, APIs) : `services/<nom>/resources.py`

### Comment ajouter un nouveau pipeline

1. Créer `services/<nom>/pipelines/<new_pipeline>.py` avec décorateurs `@asset` ou `@op`
2. Ajouter dans `services/<nom>/__init__.py` (Definitions)
3. Tester localement : `dagster dev`
4. Tests : `tests/integration/test_<new_pipeline>.py`
5. PR avec capture du DAG dans Dagit

## Configuration

| Variable | Type | Défaut | Description |
|----------|------|--------|-------------|
| `DAGSTER_HOME` | `str` | `~/.dagster` | Dossier metadata |
| `DAGSTER_PG_*` | divers | — | Postgres metadata DB |
| `<À REMPLIR>` |  |  |  |

## Démarrage local

```bash
# Si Dagster
docker-compose up -d dagster
# UI : http://localhost:3000

# Si Airflow
docker-compose up -d airflow-scheduler airflow-webserver
# UI : http://localhost:8080
```

## Tests

```bash
# Tests unitaires des fonctions
uv run pytest tests/unit/pipelines/

# Test d'un pipeline complet sur subset (testcontainers)
uv run pytest tests/integration/test_ingest_pipeline.py -m integration
```

## Pièges à anticiper

- **Idempotence négligée** : retry crée des doublons
- **Timeout par défaut trop long** : coûts API qui dérapent
- **Schedules sans timezone explicite** : sources de bugs
- **Variables/connections sans rotation** : fuites de secrets

## Liens

- DevBrain : [[<À REMPLIR : Dagster / Airflow / Flyte>]] · [[Comparatif - Orchestrateurs data]]
- Règle : [[Orchestration-Data]]
- Doc fournisseur : <URL>
- Dashboard runs : <lien>
