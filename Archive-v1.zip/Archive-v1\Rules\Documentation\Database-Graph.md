---
galaxie: dev
type: rule
domaine: documentation
applicable: type-service-database-graph
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, documentation, graph, knowledge-graph, ontology]
---

# Règle — Documentation Base de données graphe

S'applique à : [[Neo4j]], [[Nebula Graph]], et autres property graphs.

## Principe (1 phrase)
Le `services/<graph-db>/README.md` doit décrire **l'ontologie complète** (Vertices + Edges) et la **stratégie d'extraction** des triplets (si alimenté par un LLM).

## MUST

### 1. Ontologie — Sommets (Vertices / Nodes)
Pour chaque type de Vertex, fournir un dictionnaire de données :

```
| Type | Propriétés | Cardinalité estimée | Source |
|------|-----------|---------------------|--------|
| Person | id, name, email, role | ~10k | imports HR + extraction LLM |
| Document | id, title, type, source_url | ~100k | uploads users |
| Concept | id, label, category | ~5k | extraction LLM |
| ... |
```

Pour chaque propriété : type (string, int, datetime…), obligatoire ou non, indexée ou non.

### 2. Ontologie — Arêtes (Edges / Relationships)

```
| Type | Source | Cible | Propriétés | Direction | Description |
|------|--------|-------|-----------|-----------|-------------|
| AUTHORED | Person | Document | { date } | dirigée | Auteur d'un doc |
| MENTIONS | Document | Concept | { confidence } | dirigée | Doc cite un concept |
| RELATED_TO | Concept | Concept | { weight, source } | bi-dir | Lien sémantique |
| ... |
```

### 3. Stratégie d'extraction (si alimenté par LLM)
- **Modèle** utilisé pour extraire les triplets ([[Anthropic Claude API]] / [[OpenAI API]] / modèle local)
- **Prompt complet** stocké dans `services/<graph-db>/prompts/extraction.txt` ou équivalent
- **Schéma de sortie** imposé au LLM (JSON Schema avec `tools` ou `response_format`)
- **Stratégie de validation** : règles automatiques + revue humaine
- **Stratégie de déduplication** : matching d'entités (canonicalisation des `Person.name`)

### 4. Contrat d'interface
- Langage de requête utilisé : **Cypher** (Neo4j), **nGQL** (Nebula), Gremlin
- Driver / client utilisé
- Endpoints exposés par le service (si wrapper API)

### 5. Schéma de sortie pour les requêtes typiques
Documenter les 3-5 requêtes principales du projet avec leur signature :
```
get_related_concepts(concept_id: str, depth: int = 2) -> list[Concept]
get_co_authors(person_id: str) -> list[Person]
```

## SHOULD

- **Stratégie d'évolution de l'ontologie** : comment ajouter un nouveau type de Node/Edge sans casser
- **Indexes** créés (sur quels labels/propriétés)
- **Stratégie de partition** si Nebula (graph partitioning)
- **Politique d'archivage** : que faire des nœuds orphelins, des edges obsolètes
- **Métriques de qualité** : taux d'extraction réussie, taux de duplication

## NICE

- Visualisation de l'ontologie (Mermaid ou export Bloom/Neo4j Browser)
- Échantillon de triplets extraits commentés
- Eval périodique de la qualité d'extraction (humain ou LLM-as-judge)

## Pièges classiques

- **Schema-less** ≠ no schema : il faut une discipline d'équipe
- **Migrations** : pas d'outil standard équivalent à Alembic — à designer
- **Cypher sur de gros graphes** : optimiser tôt (PROFILE / EXPLAIN)
- **Extraction LLM non-déterministe** : prévoir un cache + idempotence
- **Multi-hop queries explosives** : limiter `depth` dans les recherches

## Voir aussi

- Template : `Templates/ServiceDocs/README - database-graph.md`
- [[README - Service]] — règle parente
- [[LLM-Orchestration]] — pour le prompt d'extraction
- [[Neo4j]], [[Nebula Graph]] — fiches Services
