---
galaxie: dev
nom: LangGraph
alias: [langgraph]
categorie: llm/framework
sous_categories: [agents, stateful, graphs, multi-agent]
licence: MIT
licence_type: open-source
hosted: both
maturite: production
langage: Python (TS dispo)
clients_officiels: [python, ts]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[LangChain]]", "[[LlamaIndex]]", "[[CrewAI]]", "[[AutoGen]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, framework, agents, stateful, graph]
url_officiel: https://www.langchain.com/langgraph
url_docs: https://langchain-ai.github.io/langgraph/
url_repo: https://github.com/langchain-ai/langgraph
---

# LangGraph

## Pourquoi
Évolution de [[LangChain]] orientée **agents stateful** modélisés comme des graphes (nœuds + arêtes). Persistance de l'état, checkpoints, human-in-the-loop, time travel debugging. Le choix sérieux pour les agents en prod.

## Quand l'utiliser
- Workflow d'agent avec branches conditionnelles, loops, retry
- Multi-agents qui se passent le contrôle
- Agent qui doit pouvoir reprendre où il en était (checkpointing)
- Human-in-the-loop (validation utilisateur entre étapes)
- Production où la prédictibilité du flux compte

## Quand NE PAS l'utiliser
- Simple chain prompt → réponse → un appel SDK suffit
- POC ultra-rapide → [[LangChain]] LCEL est plus rapide à pondre
- Si tu n'aimes pas le modèle "graph" et préfères le code procédural classique

## Pièges connus
- **Courbe d'apprentissage** : penser en termes de nodes/edges/state demande un shift mental
- **Checkpointer** : choisir tôt (memory, SQLite, Postgres, Redis), migration pénible
- **State schema** : à designer avec soin (typing strict, reducer functions pour merge)
- **Streaming** : `astream_events` est l'API robuste, les autres modes peuvent surprendre
- **Versions** : suit le rythme de [[LangChain]], pinner

## Liens
- [[LangChain]] — base et écosystème
- LangGraph Studio (debug visuel) : https://github.com/langchain-ai/langgraph-studio
- Tutoriels : https://langchain-ai.github.io/langgraph/tutorials/
- Cookbook : https://github.com/langchain-ai/langgraph/tree/main/examples
