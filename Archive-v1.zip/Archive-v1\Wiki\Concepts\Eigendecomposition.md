---
galaxie: wiki
nom: Eigendecomposition
alias: [eigendecomposition, valeurs propres, vecteurs propres, diagonalisation]
type: concept
categorie: concept/linalg
sous_categories: [eigendecomposition, eigenvalues, eigenvectors, diagonalization, spectral]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Cauchy, Jordan]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, linalg, eigen]
---

# Eigendecomposition — décomposition en valeurs propres

## TL;DR

Pour une matrice carrée $A$, trouver des paires $(\lambda, v)$ avec $A v = \lambda v$ — direction $v$ préservée, scalaire $\lambda$ = facteur d'étirement. Quand $A$ est diagonalisable : $A = V \Lambda V^{-1}$. Pour les matrices symétriques (cas le plus courant en ML) : $V$ est orthogonale, $V^{-1} = V^\top$. Base de la [[PCA]], analyse de stabilité, théorie spectrale, PageRank, et beaucoup plus.

## Le problème

Comment **comprendre l'action** d'une matrice $A$ en isolant ses "directions privilégiées" ? Si $A$ représente une transformation linéaire, les vecteurs propres sont les **axes invariants** de cette transformation (à un scalaire près).

## L'idée

### Définition

Un vecteur $v \neq 0$ est un **vecteur propre** de $A$ avec **valeur propre** $\lambda$ si :

$$ A v = \lambda v $$

$\lambda$ peut être réel ou complexe, scalaire.

### Calcul des valeurs propres

Les valeurs propres sont les racines du **polynôme caractéristique** :

$$ \det(A - \lambda I) = 0 $$

Pour une matrice $n \times n$, ce polynôme est de degré $n$, donc $n$ valeurs propres (avec multiplicité).

### Diagonalisation

Si $A$ a $n$ vecteurs propres linéairement indépendants $v_1, \dots, v_n$, on peut écrire :

$$ A = V \Lambda V^{-1} $$

avec $V = [v_1, \dots, v_n]$ et $\Lambda = \text{diag}(\lambda_1, \dots, \lambda_n)$.

**Toutes les matrices ne sont pas diagonalisables.** Exemple : $\begin{pmatrix} 1 & 1 \\ 0 & 1 \end{pmatrix}$ a $\lambda = 1$ double mais un seul vecteur propre indépendant. On peut alors utiliser la **forme de Jordan** (rare en ML).

### Théorème spectral — cas symétrique

Si $A = A^\top$ (symétrique réelle) :

- Toutes les valeurs propres sont **réelles**
- Les vecteurs propres associés à des valeurs propres distinctes sont **orthogonaux**
- $A$ est diagonalisable et on peut choisir $V$ **orthogonale** : $V^{-1} = V^\top$

$$ A = V \Lambda V^\top $$

C'est le cas le plus important en pratique : matrices de covariance, kernels, hessiennes locales, laplaciens, etc. — toutes symétriques.

### Cas SDP (symétrique semi-définie positive)

Si $A = A^\top$ et $x^\top A x \geq 0$ pour tout $x$ :

- Toutes les valeurs propres sont $\geq 0$
- Eigendecomposition et SVD coïncident

### Lien avec SVD

Pour $A$ non-carrée ou non-diagonalisable, on bascule sur [[SVD]] :

- $A^\top A$ est SDP → ses valeurs propres = $\sigma_i^2$ (carrés des valeurs singulières)
- Vecteurs propres de $A^\top A$ = vecteurs singuliers de droite

### Trace, déterminant

$$ \text{tr}(A) = \sum_i \lambda_i, \quad \det(A) = \prod_i \lambda_i $$

Pratique pour tests rapides.

### Conditionnement

Pour matrice symétrique SDP :

$$ \kappa(A) = \frac{\lambda_{\max}}{\lambda_{\min}} $$

$\kappa$ élevé = matrice mal conditionnée = numerical instability dans les algos d'inversion / résolution. Apparaît partout en optimisation (vitesse de convergence de gradient descent dépend de $\kappa$ du Hessien).

## Quand c'est utile

- **PCA** : eigendecomp de la matrice de covariance ou SVD de la matrice centrée
- **Spectral clustering** : eigendecomp du laplacien du graphe
- **PageRank** : eigendecomp de la matrice de transition
- **Stabilité dynamique** : $|\lambda_i| < 1$ pour stabilité (chaînes de Markov, RNN)
- **Hessien en optim** : valeurs propres = courbures, conditionnement, méthodes 2nd ordre (Newton)
- **Kernel methods** : eigendecomp du kernel Gram matrix
- **Diagonalisation pour exponentiation** : $A^k = V \Lambda^k V^{-1}$ — calcul rapide de puissances
- **Matrix exponential** : $e^A = V e^\Lambda V^{-1}$

## Quand ça ne marche pas / pièges

- **Matrices non-symétriques** : valeurs propres complexes possibles. Privilégier SVD ou éviter selon contexte.
- **Coût computationnel** : $O(n^3)$ pour eigendecomp dense. Pour grandes matrices sparse : Arnoldi/Lanczos pour les $k$ premières valeurs propres ($O(k \cdot \text{nnz})$).
- **Matrices presque singulières** ($\lambda_i \approx 0$) : numerical issues sur l'inverse. Utiliser pseudo-inverse via SVD.
- **Diagonalisabilité non garantie** : matrices défectueuses → forme de Jordan, ou approximation
- **Ordering** : convention "valeurs propres décroissantes" pas universelle. Vérifier avant comparaison de résultats inter-libs.
- **Signe des vecteurs propres** : non-unique. $v$ et $-v$ sont tous deux valides.
- **Multiplicité** : valeurs propres multiples → sous-espace propre, pas une seule direction

## Code minimal

```python
import numpy as np
from scipy.linalg import eig, eigh

# Matrice symétrique (cas le plus courant en ML)
A = np.array([[4, 1], [1, 3]])

# eigh : optimisé pour symétriques, retourne valeurs réelles ordonnées
eigenvalues, eigenvectors = np.linalg.eigh(A)
print(f"Eigenvalues: {eigenvalues}")  # ordonnées croissantes
print(f"Eigenvectors:\n{eigenvectors}")

# Vérifier : A v = λ v
for i in range(len(eigenvalues)):
    v = eigenvectors[:, i]
    print(f"A v_{i} ≈ λ_{i} v_{i} : {np.allclose(A @ v, eigenvalues[i] * v)}")

# Matrice générale (peut avoir valeurs propres complexes)
B = np.array([[0, -1], [1, 0]])  # rotation 90°
eigvals, eigvecs = np.linalg.eig(B)
print(f"Eigenvalues (complex): {eigvals}")  # ±i

# Top-k eigenvalues d'une grande matrice sparse
from scipy.sparse.linalg import eigsh
import scipy.sparse as sp
A_sparse = sp.random(1000, 1000, density=0.01)
A_sparse = A_sparse + A_sparse.T  # symétrique
top_k_vals, top_k_vecs = eigsh(A_sparse, k=10, which='LA')  # Largest Algebraic

# Condition number
print(f"κ(A) = {np.linalg.cond(A):.3f}")
```

## Pour aller plus loin

- Strang, *Linear Algebra and Its Applications* — référence pédagogique
- Trefethen & Bau, *Numerical Linear Algebra* — chap. 24-31
- *Essence of Linear Algebra* (3Blue1Brown) — intuitions visuelles
- **Liens internes** : [[SVD]], [[PCA]], [[Vector norms]], [[Matrix decompositions]]
