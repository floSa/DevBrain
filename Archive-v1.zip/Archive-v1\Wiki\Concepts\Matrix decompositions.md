---
galaxie: wiki
nom: Matrix decompositions (QR, LU, Cholesky)
alias: [QR, LU, Cholesky, décompositions matricielles]
type: concept
categorie: concept/linalg
sous_categories: [qr, lu, cholesky, decomposition, linear-system]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Gauss, Cholesky 1924, Givens, Householder]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, linalg, decomposition]
---

# Matrix decompositions — QR, LU, Cholesky

## TL;DR

Trois décompositions classiques pour **résoudre des systèmes linéaires** $Ax = b$ et autres calculs (inverse, déterminant, moindres carrés). **LU** rapide et générale, **Cholesky** ultra-rapide pour SDP, **QR** stable pour mal conditionné et moindres carrés. Toutes utilisées en backend de scipy/numpy sans qu'on s'en aperçoive — mais comprendre quand chacune s'applique te rend autonome sur le numérique.

## Le problème

Comment résoudre efficacement $Ax = b$ ou $\min \|Ax - b\|^2$ ? Inverser $A$ directement est **lent et numériquement instable**. Les décompositions transforment le problème en un système triangulaire (résolu en $O(n^2)$ au lieu de $O(n^3)$ pour l'inverse). Chaque décomposition exploite une **structure différente** de $A$.

## L'idée

### LU — Décomposition LU

$$ A = L U $$

avec $L$ triangulaire inférieure (unit diagonal) et $U$ triangulaire supérieure.

Avec pivoting (numérique) : $P A = L U$ où $P$ est une matrice de permutation.

**Coût** : $O(n^3)$ pour la décomposition, $O(n^2)$ pour résoudre $Ax = b$ après.

**Quand** : matrice carrée générale, pas de structure exploitée.

**Usage typique** :
```python
solve Ax = b :
  factorize A = PLU
  forward solve: Ly = Pb
  backward solve: Ux = y
```

Numpy `np.linalg.solve` utilise LU sous le capot pour les matrices carrées.

### Cholesky

Pour $A$ **symétrique définie positive** (SDP) :

$$ A = L L^\top $$

avec $L$ triangulaire inférieure (à diagonale positive).

**Coût** : $O(n^3 / 3)$ — **2× plus rapide** que LU.
**Stabilité** : excellente, pas de pivoting nécessaire.

**Quand** : matrice de covariance, kernel matrices (Gram), Hessien d'une loss convexe, matrices SDP en général.

**Usage typique** :
- Régression linéaire via équations normales : $(X^\top X) w = X^\top y$ — $X^\top X$ est SDP → Cholesky
- Gaussian Processes : matrices de covariance, échantillonnage, log-vraisemblance
- Linear Discriminant Analysis (LDA)
- Mahalanobis distance (factoriser $\Sigma^{-1}$)

⚠️ Si $A$ n'est pas exactement SDP (e.g. presque singulière numériquement), Cholesky échoue. Régulariser : $A + \varepsilon I$.

### QR

$$ A = Q R $$

avec $Q$ orthogonale ($Q^\top Q = I$) et $R$ triangulaire supérieure.

**Coût** : $O(2mn^2 - 2n^3/3)$ pour $A$ de taille $m \times n$ avec $m \geq n$.
**Stabilité** : très bonne, **plus stable que LU** pour les problèmes mal conditionnés.

**Quand** :
- **Moindres carrés** $\min \|Ax - b\|^2$ avec $A$ non-carrée : $A = QR$ → $Rx = Q^\top b$
- Quand $A^\top A$ est mal conditionné (équations normales instables)
- Initialisation orthogonale en NN
- Gram-Schmidt orthogonalisation

Algorithmes de construction : Givens rotations, Householder reflections, Modified Gram-Schmidt (le classique est instable).

### Comparatif

| Décompo. | Pour quoi | Coût | Stable | Quand l'utiliser |
|---|---|---|---|---|
| **LU** | Système linéaire général | $O(n^3)$ | OK avec pivoting | matrice carrée non structurée |
| **Cholesky** | SDP | $O(n^3/3)$ | excellent | covariance, kernel, équations normales si bien conditionné |
| **QR** | Moindres carrés, non-carré | $O(mn^2)$ | excellent | $A$ non-carrée, mal conditionné, orthogonalisation |
| [[SVD]] | Tout (le plus général) | $O(\min(m,n) \cdot mn)$ | parfait | pseudo-inverse, low-rank, mal posé |

### Autres décompositions (mentionnées pour culture)

- **Schur** : $A = Q U Q^\top$, $U$ triangulaire supérieure. Étape intermédiaire pour eigendecomp.
- **Hessenberg** : presque triangulaire supérieure. Étape de calcul d'eigendecomp.
- **Polar** : $A = U P$ avec $U$ unitaire et $P$ SDP. Liée à la SVD.

## Quand c'est utile

- **Backend de scipy/sklearn** : `np.linalg.solve` → LU ; `scipy.linalg.cho_solve` → Cholesky ; `np.linalg.lstsq` → QR (ou SVD)
- **Régression linéaire fait-main** : Cholesky sur $X^\top X$ ou QR sur $X$
- **Gaussian Processes** : Cholesky de la matrice de covariance pour échantillonnage et log-likelihood
- **Optimization 2nd ordre** (Newton) : Cholesky du Hessien pour résoudre le sous-problème
- **Initialization de NN** : matrices orthogonales via QR
- **Inversion de matrice ?** Presque jamais explicitement. Toujours préférer une décomposition + back-solve.

## Quand ça ne marche pas / pièges

- **Inverser explicitement une matrice** (`np.linalg.inv`) : presque toujours une mauvaise idée. Préférer `np.linalg.solve` (LU) ou Cholesky.
- **Cholesky sur matrice presque singulière** : ne converge pas. Régulariser ou basculer sur LU avec pivoting.
- **Équations normales naïves** ($X^\top X$ Cholesky) si $X$ mal conditionnée → erreur amplifiée par $\kappa^2$. Préférer QR sur $X$ direct (erreur en $\kappa$ seulement).
- **LU sans pivoting** : instable sur certaines matrices. Toujours utiliser partial pivoting (par défaut).
- **Coût mémoire** : décomposition explicite de matrices denses $n \times n$ avec $n > 10^5$ : impossible. Utiliser méthodes itératives (conjugate gradient, GMRES).
- **Pas de Cholesky sur matrices non symétriques** : check toujours $A = A^\top$ avant.

## Code minimal

```python
import numpy as np
from scipy.linalg import lu, cho_factor, cho_solve, qr, solve_triangular

A = np.array([[4., 1.], [1., 3.]])  # SDP
b = np.array([1., 2.])

# Méthode 1 : np.linalg.solve (LU sous le capot, le plus simple)
x = np.linalg.solve(A, b)

# Méthode 2 : LU explicite
P, L, U = lu(A)  # PA = LU
y = solve_triangular(L, P @ b, lower=True)
x_lu = solve_triangular(U, y, lower=False)

# Méthode 3 : Cholesky (le plus rapide pour SDP)
c, low = cho_factor(A)  # c contient L (ou U) selon low
x_chol = cho_solve((c, low), b)

# Méthode 4 : QR (pour moindres carrés sur A non-carrée)
A_rect = np.random.randn(10, 3)
b_rect = np.random.randn(10)
Q, R = qr(A_rect, mode='economic')
x_lstsq = solve_triangular(R, Q.T @ b_rect, lower=False)

# Comparaison de stabilité avec np.linalg.lstsq (utilise SVD)
x_svd, *_ = np.linalg.lstsq(A_rect, b_rect, rcond=None)

# Gaussian Process — log-likelihood via Cholesky
K = ...  # covariance matrix n × n
L = np.linalg.cholesky(K + 1e-6 * np.eye(len(K)))  # régularisation
log_det = 2 * np.sum(np.log(np.diag(L)))
alpha = solve_triangular(L.T, solve_triangular(L, y, lower=True), lower=False)
nll = 0.5 * y @ alpha + 0.5 * log_det + 0.5 * len(y) * np.log(2 * np.pi)
```

## Pour aller plus loin

- Trefethen & Bau, *Numerical Linear Algebra* (1997) — référence pédagogique
- Golub & Van Loan, *Matrix Computations* (4e éd. 2013) — la bible
- LAPACK/BLAS — la lib bas-niveau derrière numpy/scipy
- **Liens internes** : [[SVD]], [[Eigendecomposition]], [[Vector norms]], [[Gradient descent|optimization basics]]
