---
galaxie: dev
nom: DSPy
alias: [dspy-ai]
categorie: llm/framework
sous_categories: [programmable-prompting, optimization, compile-prompts]
licence: MIT
licence_type: open-source
hosted: self
maturite: beta
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[LangChain]]", "[[LangGraph]]", langtail]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, llm, framework, optimization]
url_officiel: https://dspy.ai/
url_docs: https://dspy.ai/
url_repo: https://github.com/stanfordnlp/dspy
---

# DSPy

## Pourquoi

Framework Stanford qui **programme les prompts comme du code Python** au lieu de les écrire en strings. Tu déclares la *signature* (input/output schema) d'un module, DSPy génère et **optimise automatiquement les prompts** (few-shot examples, instructions) en s'appuyant sur un dataset d'évaluation.

Pivot conceptuel : passer du *prompt engineering* artisanal à du *prompt compilation* automatique. C'est *le* framework si tu veux sortir du prompt-as-string.

## Quand l'utiliser

- Pipeline LLM avec plusieurs étapes (RAG, multi-hop reasoning) — DSPy optimise tout le pipeline
- Tu as un dataset d'éval (gold answers) et tu veux pousser la perf au max
- Recherche / expérimentation : comparer plusieurs stratégies (CoT, ReAct, Reflection) systématiquement
- Reproductibilité : tes "prompts" deviennent versionnés en code

## Quand NE PAS l'utiliser

- Tu n'as pas de dataset d'éval → DSPy perd son intérêt principal (optimisation)
- App simple chat / one-shot → over-engineered, prends [[LangChain]] ou direct [[Anthropic Claude API]]
- Maturité : moins de retours d'expérience prod que LangChain en 2026, plus de churn d'API

## Pièges connus

- Courbe d'apprentissage abrupte (signature, module, optimizer, compile…)
- Les optimizers consomment beaucoup de tokens — anticipe le coût des "compilations"
- Documentation parfois en retard sur l'API (project encore en évolution rapide)

## Liens

- Doc : https://dspy.ai/
- Repo : https://github.com/stanfordnlp/dspy
- Paper : https://arxiv.org/abs/2310.03714
- [[LangChain]] / [[LangGraph]] (alternatives plus établies mais moins "optimisantes")
