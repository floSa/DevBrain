---
galaxie: dev
nom: Spark
alias: [spark, pyspark, apache spark]
categorie: tooling/distributed-compute
sous_categories: [big-data, distributed, sql, etl, streaming]
licence: Apache-2.0
licence_type: open-source
hosted: both
maturite: production
langage: Scala / Python
clients_officiels: [scala, python, r, sql, java]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Polars]]", "[[DuckDB]]", "[[Dask]]", Flink, Trino, Ray]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, big-data, distributed, etl]
url_officiel: https://spark.apache.org/
url_docs: https://spark.apache.org/docs/latest/
url_repo: https://github.com/apache/spark
---

# Spark

## Pourquoi
Moteur de **traitement big data distribué**. Standard pour ETL sur cluster, batch et streaming. PySpark = API Python. Aujourd'hui souvent challengé en single-node par [[Polars]] / [[DuckDB]] (plus rapides, moins lourds), mais reste incontournable pour 10TB+ ou écosystème Databricks/EMR.

## Quand l'utiliser
- ETL > 100GB single-node, ou > 1TB cluster
- Workloads existants Databricks / EMR / Synapse
- Spark Streaming / Structured Streaming
- Iceberg / Delta Lake transactions ACID
- Mélanger SQL + DataFrames + ML (MLlib) dans le même pipeline
- Clusters Kubernetes (Spark on K8s)

## Quand NE PAS l'utiliser
- Single-machine < 100GB → [[Polars]] / [[DuckDB]] (10-100x plus rapides, moins de ceremony)
- Streaming sub-seconde → [[Flink]] (mieux pensé)
- Data warehouse cloud → [[BigQuery]] / [[Snowflake]] / Trino direct
- Apps Python avec petit volume → pandas / Polars
- Setup local rapide → [[DuckDB]] gagne haut la main

## Pièges connus
- **JVM tuning** : `spark.driver.memory`, `spark.executor.memory`, garbage collection — sources de bug en prod
- **Lazy evaluation** : transformations différées jusqu'à action (.collect/.show), peut surprendre
- **Skew** : partitions inégales → 1 task qui mange tout. Salting, repartition.
- **Small files problem** : milliers de petits fichiers Parquet → catastrophic. Coalesce/merge.
- **UDF Python** : lent (sérialisation via Py4J). Préférer SQL/expressions natives ou Pandas UDFs.
- **Versions** : Spark 2 vs 3, Scala 2.12 vs 2.13, hadoop versions → compatibility hell
- **Cost cluster** : facile de gaspiller, monitor utilisation

## Liens
- [[Polars]] / [[DuckDB]] — alternatives single-node modernes
- Databricks (managed) : https://www.databricks.com/
- Iceberg / Delta — formats lakehouses
- PySpark docs : https://spark.apache.org/docs/latest/api/python/
