---
galaxie: dev
nom: Drools
alias: [drools, kie, kie-dmn, jboss-drools, red-hat-decision-manager]
categorie: decision/engine
sous_categories: [drools, dmn, rules-engine, brms, java, kie, rete]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Java
clients_officiels: [java, rest]
plateforme: [linux, macos, windows, kubernetes]
score: 4
mes_projets: []
alternatives: ["[[Camunda]]", "[[OpenL Tablets]]", "[[pyDMNrules]]", "IBM ODM", "FICO Blaze Advisor"]
remplace: []
remplace_par: []
created: 2026-05-21
modified: 2026-05-21
status: actif
tags: [service, drools, dmn, rules-engine, brms]
url_officiel: https://www.drools.org/
url_docs: https://docs.drools.org/
url_repo: https://github.com/apache/incubator-kie-drools
---

# Drools

## Pourquoi

**Business Rules Management System (BRMS) open-source de référence**, écrit en Java, basé sur l'algorithme **Rete** pour le matching de règles efficient. Historiquement développé par JBoss/Red Hat, désormais incubé chez **Apache (KIE)** depuis 2023. Couvre :
- **Drools Rule Language (DRL)** : langage de règles natif (when/then), puissant pour rule engine classique
- **DMN engine L3 100% TCK** : une des implémentations DMN les plus rigoureuses
- **KIE Workbench** (legacy) / **Business Central** : éditeur web
- **KIE Server** : runtime stateless REST exposant DMN + DRL

**Red Hat Decision Manager** (anciennement BRMS) est la **version commerciale supportée par Red Hat** basée sur Drools, avec UI Business Central, gouvernance, support enterprise. Versions 7.x (DMN 1.2 design + 1.1/1.3 runtime L3).

Cible : équipes Java/JVM qui veulent un **rules engine mature** avec DMN moderne, sans le côté workflow lourd de Camunda. Souvent choisi en banque / assurance / public pour la conformité.

## Quand l'utiliser

- **Stack Java enterprise** : intégration Spring Boot, JBoss EAP, Quarkus
- **DMN strict conformance** : Drools est l'un des plus rigoureux sur le TCK
- **Rules + DMN combo** : tu veux faire du rule engine classique (DRL/Rete) ET du DMN dans le même engine
- **Rete pour pattern matching massif** : règles avec joins complexes (vente croisée, fraude)
- **REST stateless** via KIE Server : déployer un DMN comme microservice
- **Pas besoin de BPMN intégré** : Drools fait du jBPM en parallèle mais c'est moins intégré que Camunda
- **Red Hat Decision Manager** si tu veux du support Red Hat / OpenShift
- **Migration depuis BRMS legacy** : Red Hat fournit des outils

## Quand NE PAS l'utiliser

- **Stack Python pure** : Drools est Java, REST overhead → [[pyDMNrules]]
- **BPMN + DMN combo intensif** : [[Camunda]] mieux intégré
- **Excel-friendly** : business users préfèrent Excel → [[OpenL Tablets]]
- **Petit projet** : Drools demande JVM, déploiement non trivial
- **Pas d'équipe Java** : courbe d'apprentissage importante
- **Avenir incertain** : transition JBoss → Apache KIE (incubating), à surveiller
- **DRL en sortie de DMN** : si tu codes principalement en DRL, le bénéfice du DMN est limité

## Pièges connus

- **Apache KIE incubating** : projet en transition depuis 2023, gouvernance Apache à se stabiliser
- **Naming confus** : Drools, KIE, jBPM, OptaPlanner, Business Central, Decision Manager — c'est l'écosystème KIE, comprendre la map
- **DRL vs DMN** : deux langages co-existent dans Drools, choisir tôt pour ne pas mixer
- **Algo Rete** : génial mais peut surprendre côté perf (memoisation, working memory) — pas un appel de fonction simple
- **Workbench legacy** : Business Central est lourd, UI vieillissante, modeling DMN moins fluide que Camunda Modeler
- **Red Hat Decision Manager 7.x** : DMN design 1.2, runtime 1.1/1.3 L3 — vérifier la version cible
- **Mémoire et perf** : Rete garde un working memory, peut consommer ; tuning JVM nécessaire pour gros workloads
- **Documentation** : massive mais fragmentée (Drools docs, KIE docs, Red Hat docs)
- **KIE Server REST API** : non trivial, prévoir formation
- **Cession Red Hat / IBM** : roadmap incertaine post-acquisition (Red Hat → IBM 2019)
- **Versioning Maven** : `org.drools` vs `org.kie` vs `org.optaplanner` — bien matcher les versions

## Code minimal

### Setup Maven

```xml
<dependency>
    <groupId>org.kie</groupId>
    <artifactId>kie-dmn-core</artifactId>
    <version>8.44.0.Final</version>
</dependency>
```

### Évaluer un DMN

```java
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.dmn.api.core.*;

public class CreditEvaluator {
    public static void main(String[] args) {
        KieServices ks = KieServices.Factory.get();
        KieContainer kContainer = ks.getKieClasspathContainer();

        DMNRuntime runtime = kContainer.newKieSession().getKieRuntime(DMNRuntime.class);
        DMNModel model = runtime.getModel("https://example.com/dmn", "Credit Decision");

        DMNContext ctx = runtime.newContext();
        ctx.set("age", 35);
        ctx.set("income", 25000);
        ctx.set("score_ml", 0.78);

        DMNResult result = runtime.evaluateAll(model, ctx);
        Object decision = result.getDecisionResultByName("Eligibility").getResult();
        System.out.println("Decision: " + decision);
    }
}
```

### Drools DRL — règles natives (alternative DMN pour rule engine classique)

```drl
package com.example.credit;

import com.example.Customer;
import com.example.LoanRequest;

rule "VIP auto-approve"
    salience 100
when
    $c: Customer(tier == "VIP")
    $r: LoanRequest(amount < 1000000)
then
    $r.setDecision("auto_approve");
    update($r);
end

rule "Insufficient income"
    salience 50
when
    $c: Customer(income < 20000)
    $r: LoanRequest(amount > $c.income * 3)
then
    $r.setDecision("reject");
    update($r);
end
```

```java
// Exécution DRL
KieSession kSession = kContainer.newKieSession();
kSession.insert(customer);
kSession.insert(request);
kSession.fireAllRules();
System.out.println(request.getDecision());
```

### KIE Server REST API (DMN stateless)

```bash
# Déployer un kjar (Maven artifact contenant le DMN)
curl -X PUT "http://localhost:8080/kie-server/services/rest/server/containers/credit_1.0.0" \
    -H "Content-Type: application/json" \
    -u kieserver:kieserver1! \
    -d '{
        "container-id": "credit_1.0.0",
        "release-id": {"group-id": "com.example", "artifact-id": "credit", "version": "1.0.0"}
    }'

# Évaluer
curl -X POST "http://localhost:8080/kie-server/services/rest/server/containers/credit_1.0.0/dmn" \
    -H "Content-Type: application/json" \
    -u kieserver:kieserver1! \
    -d '{
        "model-namespace": "https://example.com/dmn",
        "model-name": "Credit Decision",
        "decision-name": ["Eligibility"],
        "dmn-context": {"age": 35, "income": 25000, "score_ml": 0.78}
    }'
```

### Combo Python via REST

```python
import requests

def evaluate_dmn(age, income, score_ml):
    r = requests.post(
        "http://localhost:8080/kie-server/services/rest/server/containers/credit_1.0.0/dmn",
        json={
            "model-namespace": "https://example.com/dmn",
            "model-name": "Credit Decision",
            "decision-name": ["Eligibility"],
            "dmn-context": {"age": age, "income": income, "score_ml": score_ml},
        },
        auth=("kieserver", "kieserver1!"),
        headers={"Content-Type": "application/json"},
    )
    return r.json()

print(evaluate_dmn(35, 25000, 0.78))
```

### Business Central — modeling visuel

UI web pour créer DMN graphiquement (téléchargeable avec Drools workbench / Red Hat Decision Manager). Drag-drop des decision tables et DRD. Moins fluide que Camunda Modeler mais intégré au KIE Server.

## Liens

- [[Camunda]] — alternative avec BPMN/DMN intégré, écosystème plus fluide
- [[OpenL Tablets]] — alternative Excel-driven
- [[pyDMNrules]] — alternative Python pure
- [[Decision Model and Notation]] / [[Decision Tables]] / [[FEEL]] — concepts
- [[BPMN DMN CMMN]] — Drools peut combo avec jBPM (BPMN) — moins intégré que Camunda 8
- jBPM — BPMN engine du même écosystème KIE
- OptaPlanner — optimisation contraintes (même équipe, complémentaire)
- Apache KIE : https://www.kie.org/
- Drools docs : https://docs.drools.org/
- Red Hat Decision Manager : https://www.redhat.com/en/technologies/jboss-middleware/decision-manager
- GitHub : https://github.com/apache/incubator-kie-drools
