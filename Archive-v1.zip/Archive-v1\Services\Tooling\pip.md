---
galaxie: dev
nom: pip
alias: [pip]
categorie: tooling/package-manager
sous_categories: [python, package-manager, installer, pypa]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [cli]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[uv]]", "pipx", "poetry", "pdm", "rye", "pip-tools"]
remplace: []
remplace_par: ["[[uv]]"]
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, python, packaging]
url_officiel: https://pip.pypa.io/
url_docs: https://pip.pypa.io/en/stable/
url_repo: https://github.com/pypa/pip
---

# pip

## Pourquoi

Gestionnaire de paquets **officiel Python** (PyPA), inclus avec CPython depuis 3.4. Universellement disponible. Brique fondatrice de l'écosystème — toutes les alternatives modernes ([[uv]], poetry, pdm) finissent par parler à PyPI via le même protocole.

En 2026, **pip est dépassé par [[uv]]** : uv est 10-100x plus rapide, gère venv + lockfile + Python install dans un seul outil cohérent. **pip reste pertinent** pour : (1) compatibilité universelle, (2) scripts legacy, (3) environnements où installer un autre outil est interdit, (4) fallback bas niveau utilisé par les autres.

## Quand l'utiliser

- **Outil universel** : disponible partout, zéro setup
- **Install rapide one-off** : `pip install foo` pour un script jetable
- **Compatibilité scripts existants** : Dockerfiles legacy, CI old-school
- **Environnement contraint** : pas le droit d'installer uv / poetry
- **Image Python minimaliste** : `python:3.12-slim` + `pip install -r requirements.txt`
- **Brique bas niveau** : sous le capot dans uv, poetry, pdm en partie
- **`pip download` / `pip wheel`** pour vendoring de dépendances

## Quand NE PAS l'utiliser

- **Projets sérieux 2026** → [[uv]] (perf, lockfile cross-platform, Python install, monorepo)
- **Multi-env workflow** → uv / poetry / pdm (gestion venv intégrée)
- **Reproductibilité strict** : pip n'a pas de lockfile natif → pip-tools / uv
- **CLI tools globaux isolés** → pipx (un venv par tool, dans le PATH)
- **Monorepo multi-projects** → uv workspaces / poetry workspaces

## Pièges connus

- **Pas de lockfile natif** : `requirements.txt` n'est pas un lockfile, transitive deps non-épinglées par défaut → `pip-tools` (`pip-compile`) ou `pip freeze` (imparfait)
- **Resolution lente** sur dependencies complexes : `pip install` peut prendre 30s-2min vs uv en 2s
- **Pas de Python version management** : il faut pyenv / asdf / uv à côté
- **Verbosité** : créer venv + activate + pip install = 3 étapes, vs `uv add foo` (1)
- **No-build-isolation par défaut faux** : `pip install --no-build-isolation` rare, par défaut chaque build = nouveau venv → lent
- **`pip freeze` mauvais lockfile** : capture l'env courant (y compris `pip` lui-même), pas le manifest projet
- **Cache global partagé entre projets** : `~/.cache/pip/` → invalidations parfois surprenantes
- **`--break-system-packages`** : sur Debian/Ubuntu 23+ pip refuse système, flag à connaître (mieux : venv)
- **Editable installs** (`pip install -e .`) : utiles mais magiques, surprend sur monorepo
- **Index URL fallback** : `--index-url` + `--extra-index-url` confondus → CVE supply chain
- **`pip install` upgrade par défaut absent** : il faut `--upgrade` pour mettre à jour

## Code minimal

```bash
# Install (deja inclus avec Python moderne)
python -m ensurepip --upgrade

# Workflow venv classique
python -m venv .venv
source .venv/bin/activate                       # Linux/macOS
# .venv\Scripts\activate                        # Windows

pip install --upgrade pip
pip install requests pandas
pip freeze > requirements.txt

# Restaurer depuis requirements
pip install -r requirements.txt
```

```bash
# Editable install (dev local)
pip install -e .

# Avec extras
pip install -e ".[dev,test]"

# Install depuis Git
pip install git+https://github.com/user/repo.git@main

# Install depuis wheel local
pip install ./dist/mypkg-1.0.0-py3-none-any.whl

# Lister + check
pip list
pip show requests
pip check                                       # detecte conflits versions
```

```bash
# pip-tools (lockfile reproductible)
pip install pip-tools

# requirements.in (high-level)
# requests
# pandas>=2.0

pip-compile requirements.in -o requirements.txt    # genere lockfile fige
pip-sync requirements.txt                          # synchronise env exactement
```

```bash
# Quand on n'a vraiment que pip et qu'on veut un workflow propre
python -m venv .venv && source .venv/bin/activate
pip install pip-tools
echo "requests" > requirements.in
pip-compile requirements.in
pip-sync requirements.txt
```

```dockerfile
# Dockerfile minimaliste pip
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["python", "main.py"]
```

## Liens

- [[uv]] — successeur **recommandé** (Astral, écrit en Rust)
- pipx — install isolé de CLI tools globaux
- pip-tools — `pip-compile` + `pip-sync` pour lockfile
- poetry / pdm / rye — alternatives complètes avec lockfile natif
- PyPA (Python Packaging Authority) — projet parent
- Docs : https://pip.pypa.io/en/stable/
- GitHub : https://github.com/pypa/pip
