---
date: 2026-05-20
type: session
mode: autonome
duree_estimee: 2-4h
tags: [session, marathon, fondamentaux, ds, ml]
---

# Session 2026-05-20 — Marathon fondamentaux DS/ML

## Contexte

Le user (floSa, DS senior) m'a fourni `~/Desktop/competences_ds_ml.md` (~3000 lignes, ~1500 items) — une carte de compétences DS/ML exhaustive. Il considère qu'un DS de son niveau doit maîtriser ces concepts. Le wiki actuel ne couvre que ~5% des items — trou à combler.

Il part. Mission : produire ~40 concepts en autonomie, qualité impeccable, format dense.

## État du brain au début de la session

- 70 services / 6 patterns / 24 concepts / 4 workflows / 22 outils / 22 skills custom
- 3 galaxies opérationnelles (DEV/WIKI/SKILLS) avec CSS + frontmatter `galaxie:`
- 18 commits aujourd'hui (cumulé), tous sous `floSa <florian.horellou@gmail.com>`

## Plan de session

### Phase 0 (en cours) — Cette note + setup

### Phase 1 — Import Roadmap (1 commit)
- `Wiki/Roadmap.md` : import tel quel du doc
- Frontmatter : `galaxie: wiki`, `type: roadmap`, `tags: [roadmap, ...]`
- Lien depuis `Home.md`
- Note d'intro + comment filtrer le graph

### Phase 2 — Vagues fondamentaux (6 commits)

| Vague | Sujet | Concepts ciblés | ~Fiches |
|---|---|---|---|
| V6 | Théorie de l'information | Shannon entropy, conditional entropy, cross-entropy, KL divergence, JS divergence, Wasserstein distance, mutual information, perplexity | 6 |
| V7 | Algèbre linéaire pour ML | SVD, eigendecomposition, vector norms, matrix decompositions (QR/LU/Cholesky), Hadamard/Kronecker products, projections | 6 |
| V8 | Optimisation pour ML | Gradient descent variants, momentum, Adam/AdamW, Newton-Raphson, BFGS, learning rate schedules | 6 |
| V9 | Théorie de l'apprentissage | VC dimension, PAC learning, No Free Lunch, Rademacher complexity, generalization bounds | 5 |
| V10 | Probabilités fondamentales | Markov chains, Poisson process, Brownian motion, central limit theorem, concentration inequalities, MCMC | 6 |
| V11 | Stats avancée | MLE, MAP, Bayesian inference, A/B testing, CUPED, multi-armed bandits | 6 |

**Total visé : ~35 concepts.**

### Phase 3 (au fil de l'eau)
- Linkifier `Wiki/Roadmap.md` au fur et à mesure
- Mise à jour `Inbox.md` (nouvelles sections cochées)
- README.md + CHANGELOG.md à jour

### Phase 4 — Doc filtre graph (1 commit final)
- INSTALL.md section 11.5 : "comment exclure la roadmap du graph"
- Mise à jour finale CHANGELOG + Home.md

## Conventions à respecter (rappel)

### Format des fiches concept
- **Frontmatter complet** : `galaxie: wiki`, `nom`, `alias`, `type: concept`, `categorie: concept/<famille>`, `sous_categories`, `domaines`, `maturite`, `auteurs_cles`, `lecture_min`, `created/modified`, `tags`
- **Sections fixes** : TL;DR → Le problème → L'idée (maths LaTeX) → Quand c'est utile → Quand ça ne marche pas / pièges → Code minimal → Pour aller plus loin
- **Densité visée** : 80-120 lignes par fiche (vs 200-300 sur les premières)
- **Maths LaTeX** : oui partout où pertinent (`$$...$$` pour bloc, `$...$` inline)
- **Wikilinks** : vers concepts/services existants OU pas du tout (pas de fantômes)

### Catégories `concept/*` à utiliser
- `concept/info-theory` (nouvelle famille V6)
- `concept/linalg` (nouvelle V7)
- `concept/optimization` (nouvelle V8)
- `concept/learning-theory` (nouvelle V9)
- `concept/probability` (nouvelle V10)
- `concept/stats` (existante V11)

### Précautions
- Restore `.obsidian/core-plugins.json` avant chaque commit (Obsidian le touche)
- Commits propres avec messages structurés
- Pas de push (toujours bloqué côté agent — le user push à la main au retour)
- Pas modifier `Services/`, `Bugs/`, `Patterns/`, `Rules/` sauf si vraiment nécessaire

## Reprise d'urgence

Si la session plante / la conversation déborde :

1. **Vérifier dernière vague terminée** :
   ```bash
   cd ~/Documents/Projets/DevBrain
   git log --oneline | head -20
   ls Wiki/Concepts/ | wc -l
   ```

2. **Reprendre à la vague suivante** dans la table ci-dessus.

3. **Items créés/à créer** : la liste dans `Inbox.md` sections V6-V11 (sera créée à mesure).

## Décisions à reporter au user à son retour

- Validation du format dense vs étendu (j'ai retenu dense par défaut)
- Vagues V12-V22 à valider individuellement
- Filtre graph : à activer côté Obsidian par le user (config locale)

---

*Note auto-générée avant le marathon. Fin = quand toutes les phases sont commitées.*
