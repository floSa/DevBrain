---
galaxie: wiki
nom: RAG
type: concept
categorie: concept/llm
sous_categories: [retrieval, llm, embedding, semantic-search]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Lewis et al. 2020, Meta AI]
lecture_min: 10
created: 2026-05-19
modified: 2026-05-20
tags: [concept, llm, rag, retrieval]
---

# RAG — Retrieval Augmented Generation

## TL;DR

Au lieu de faire confiance au LLM pour "savoir" un fait, on **récupère le contexte pertinent** depuis une base externe (docs, knowledge base, code), on l'**injecte dans le prompt**, puis le LLM répond en se basant dessus. Réduit drastiquement les hallucinations sur des domaines où le LLM n'a pas été entraîné (docs internes, contenu récent, données privées).

## Le problème

Un LLM seul a 3 limites :
1. **Connaissance figée à sa date d'entraînement** — pas d'info récente
2. **Pas de données privées** — il ne connaît pas tes docs internes
3. **Hallucinations** — quand il n'a pas l'info, il invente plutôt que dire "je ne sais pas"

Le fine-tuning peut adresser (1) et (2) mais c'est coûteux, opaque et ne se met pas à jour facilement.

## L'idée

```
Question
   │
   ▼
[1] Embed la question → vecteur                    ┐
                                                    │  RETRIEVAL
[2] Cherche les k chunks les plus proches          │  (offline + online)
    dans une vector DB pré-indexée                  │
                                                    ┘
[3] Construis un prompt : [système] + [chunks récupérés] + [question]
   │
   ▼                                                ┐  GENERATION
[4] LLM génère la réponse en se basant sur les     │
    chunks (avec citations)                         ┘
   │
   ▼
Réponse + sources
```

Variantes courantes :
- **Naive RAG** — embed + top-k + prompt
- **Hybrid search** — embed + BM25 (keyword) combinés
- **Re-ranking** — récupère 50, garde les 5 meilleurs après re-rank cross-encoder
- **Multi-hop / agentic RAG** — l'agent décompose la question, lance plusieurs retrievals
- **GraphRAG** — knowledge graph pour les relations entre entités

## Quand c'est utile

- Doc Q&A interne (codebase, wiki, support tickets)
- Recherche dans un corpus volumineux (papers, contrats, archives)
- Chatbot grounded sur ta doc produit
- Knowledge management — DevBrain lui-même est une cible RAG potentielle

## Quand ça ne marche pas / pièges

- **Chunking de mauvaise qualité** — coupe au milieu d'une idée, contexte perdu
- **Embeddings inadaptés au domaine** — modèles génériques galèrent sur du jargon technique
- **Top-k trop petit** — info pertinente coupée
- **Top-k trop grand** — bruit qui noie le signal, contexte LLM saturé
- **Pas d'éval** — tu ne sais pas si tu améliores ou empires
- **Questions multi-hop** — naive RAG échoue, faut décomposer

## Implémentations concrètes

- [[LangChain]] / [[LangGraph]] — frameworks RAG les plus complets
- [[LlamaIndex]] — focalisé sur l'ingestion/indexation
- [[Postgres]] avec pgvector — vector DB sans ajouter d'infra
- [[DSPy]] — RAG "programmable" et optimisable
- [[Instructor]] — pour forcer un format de réponse (citations structurées)
- [[mcp-obsidian]] — DevBrain comme source RAG via MCP

## Code minimal

```python
# Pipeline RAG minimaliste : Anthropic + sentence-transformers + FAISS
import anthropic
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

# 1. Indexer un corpus
docs = [
    "Paris est la capitale de la France.",
    "Lyon est connue pour sa gastronomie.",
    "Marseille est le plus grand port méditerranéen français.",
    # ... potentiellement des milliers
]

embedder = SentenceTransformer("BAAI/bge-base-en-v1.5")
doc_embeddings = embedder.encode(docs, normalize_embeddings=True)

index = faiss.IndexFlatIP(doc_embeddings.shape[1])  # inner product (cosine si normalisé)
index.add(doc_embeddings.astype("float32"))

# 2. Retrieve top-k
def retrieve(query, k=3):
    q_emb = embedder.encode([query], normalize_embeddings=True)
    scores, idx = index.search(q_emb.astype("float32"), k)
    return [docs[i] for i in idx[0]]

# 3. Générer avec contexte
client = anthropic.Anthropic()
def rag_query(question):
    contexts = retrieve(question, k=3)
    context_str = "\n\n".join(f"- {c}" for c in contexts)
    prompt = f"""Réponds en te basant UNIQUEMENT sur ce contexte :

<contexte>
{context_str}
</contexte>

Question : {question}

Si l'info n'est pas dans le contexte, dis "je ne sais pas"."""
    response = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=500,
        messages=[{"role": "user", "content": prompt}]
    )
    return response.content[0].text

print(rag_query("Quelle est la capitale de la France ?"))
# → "Paris est la capitale de la France."

# Variants à explorer :
# - Hybrid (BM25 + dense) : voir [[Hybrid retrieval]]
# - Reranking : voir [[Reranking]]
# - Chunking : voir [[Chunking strategies]]
# - Architectures avancées : voir [[Advanced RAG]]
```

## Pour aller plus loin

- Paper original RAG : https://arxiv.org/abs/2005.11401
- Article *Anyscale on Retrieval-augmented generation* : https://www.anyscale.com/blog/a-comprehensive-guide-for-building-rag-based-llm-applications
- Eval RAG : [[Ragas]], [[TruLens]]
- Pattern correspondant : [[Pattern - RAG basique]]
