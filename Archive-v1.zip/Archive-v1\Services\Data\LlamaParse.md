---
galaxie: dev
nom: LlamaParse
alias: [llamaparse, llama-parse, llama-cloud-parse]
categorie: data/document
sous_categories: [pdf, cloud, rag, llm-extraction, ocr, tables]
licence: Propriétaire
licence_type: proprietary
hosted: cloud
maturite: production
langage: Python
clients_officiels: [python, typescript, http]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["[[Marker]]", "[[Docling]]", "[[Unstructured]]", "Azure Document Intelligence", "AWS Textract"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, pdf, rag, cloud, document]
url_officiel: https://docs.llamaindex.ai/en/stable/llama_cloud/llama_parse/
url_docs: https://docs.cloud.llamaindex.ai/llamaparse/getting_started
url_repo: https://github.com/run-llama/llama_parse
---

# LlamaParse

## Pourquoi

**API cloud LlamaIndex** pour parsing **PDF / DOCX / PPTX / XLSX / HTML → Markdown structuré**, optimisé RAG. Utilise des **modèles LLM** en interne pour reconnaître structure (titres, listes, tableaux, formules), pas juste OCR. Différenciateur : qualité de sortie sur **PDFs complexes avec tableaux** où les libs locales (PyMuPDF, pdfplumber) galèrent.

Trois modes principaux :
- **fast** : sans LLM, OCR classique
- **balanced** (défaut) : équilibre qualité/coût
- **premium** : LLM-driven, meilleur sur structure complexe et tableaux

Cible : équipes RAG qui veulent **maximiser le recall** sur documents financiers, médicaux, juridiques où les tableaux et la mise en page importent. Standard si tu utilises [[LlamaIndex]].

## Quand l'utiliser

- **PDFs complexes avec tableaux** : qualité de sortie > libs locales
- **Stack [[LlamaIndex]]** : intégration native via `LlamaParse` reader
- **Pas envie de gérer modèles ML local** : VRAM, dépendances, mises à jour
- **Batch volume modéré** (10k-100k pages / mois)
- **Multi-format** : PDF + DOCX + PPTX + XLSX + HTML dans un même pipeline
- **Mode "instruction prompt"** : guider l'extraction ("extract all tables as JSON")
- **Async / batch** : API queue + webhook pour gros volumes
- **Multilingue** : 100+ langues supportées

## Quand NE PAS l'utiliser

- **Privacy / on-prem obligatoire** → [[Marker]] / [[Docling]] / [[Unstructured]]
- **Coût critique** : pricing par page peut exploser à grande échelle
- **Volume énorme** (millions de pages) : facture lourde, libs locales + GPU OK
- **Latence < 1s requise** : LlamaParse = ~10-30s par PDF (async par design)
- **Pas d'internet sortant** : air-gapped → impossible

## Pièges connus

- **Cloud only** : upload data potentiellement sensible → check compliance (GDPR, HIPAA)
- **Pricing au volume (par page)** : facile à oublier, budget peut déraper
- **Rate limits** sur free tier et tier standard → batching async recommandé
- **Latence cloud** : ~10-30s par PDF en sync, plus en batch → ne pas faire sync dans une web request user
- **Premium mode coûte plus cher** : 3-10x balanced selon doc
- **Format de sortie Markdown** : nettoyage à faire (links, footnotes parfois mal préservés)
- **Tables comme Markdown** : OK pour LLM RAG, moins idéal pour analytique structurée
- **API key personnelle** : un compte = une key, pas de RBAC team natif
- **Erreurs silencieuses** : page mal parsée → output dégradé sans erreur explicite, à vérifier visuellement
- **Streaming partiel** : pour gros docs, la job est queue → poll job_id

## Code minimal

```bash
pip install llama-parse llama-index
export LLAMA_CLOUD_API_KEY="llx-..."
```

```python
from llama_parse import LlamaParse

parser = LlamaParse(
    api_key="llx-...",          # ou env LLAMA_CLOUD_API_KEY
    result_type="markdown",      # markdown | text | json
    parsing_instruction=(
        "Extrait tous les tableaux financiers en Markdown. "
        "Conserve les en-tetes hierarchiques. Ignore les pieds de page."
    ),
    premium_mode=True,
    language="fr",
    verbose=True,
)

documents = parser.load_data("rapport-annuel.pdf")
for doc in documents:
    print(doc.text[:500])
```

```python
# Combo LlamaIndex : ingestion RAG complete
from llama_index.core import VectorStoreIndex, SimpleDirectoryReader

file_extractor = {".pdf": parser}
documents = SimpleDirectoryReader(
    input_dir="./docs",
    file_extractor=file_extractor,
).load_data()

index = VectorStoreIndex.from_documents(documents)
query_engine = index.as_query_engine()
print(query_engine.query("Quel est le chiffre d'affaires 2024 ?"))
```

```python
# Async / batch (volume)
import asyncio

async def parse_batch(paths):
    return await parser.aload_data(paths)

docs = asyncio.run(parse_batch(["doc1.pdf", "doc2.pdf", "doc3.pdf"]))
```

## Liens

- [[LlamaIndex]] — intégration native (combo standard)
- [[Marker]] — alternative locale (transformers Surya/Texify)
- [[Docling]] — alternative locale IBM
- [[Unstructured]] — alternative locale + cloud
- Azure Document Intelligence / AWS Textract — alternatives cloud big-tech
- Docs : https://docs.cloud.llamaindex.ai/llamaparse/getting_started
- Pricing : https://www.llamaindex.ai/pricing
- GitHub client : https://github.com/run-llama/llama_parse
