---
galaxie: wiki
nom: Reward modeling
alias: [reward modeling, RM, Bradley-Terry, preference model, reward hacking]
type: concept
categorie: concept/llm-training
sous_categories: [rl, rlhf, reward-model, bradley-terry, preferences, llm]
domaines: [ai-eng, ml-eng]
maturite: established
auteurs_cles: [Bradley & Terry 1952, Christiano 2017, Ouyang 2022 (InstructGPT), Wang 2024 (HelpSteer2)]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, llm, rl, reward-model, rlhf]
---

# Reward modeling

## TL;DR

Le **reward model (RM)** est un réseau qui apprend à scorer la **qualité** d'une réponse selon les **préférences humaines**. Entrée : un prompt + une réponse. Sortie : un scalaire $r(x, y)$. Entraîné par **loss Bradley-Terry** sur des paires de préférence $(x, y_{\text{winner}}, y_{\text{loser}})$. Sert ensuite de signal de récompense pour [[PPO]] ([[RLHF and DPO]]). Pièges récurrents : **reward hacking** (le modèle exploite les défauts du RM — verbosité, sycophancy, format markdown), **distribution shift** (RM trained on SFT outputs voit policy outputs ≠), **calibration** (un RM mal calibré pollue tout le pipeline). En 2024-2026 : recettes plus solides (HelpSteer2, ArmoRM), et essor des **verifiable rewards** qui contournent le RM neural.

## Le problème

On veut aligner un LLM sur des préférences humaines. Mais on ne peut pas avoir un humain dans la boucle à chaque pas de RL (trop lent, trop cher). Solution :
1. **Collecter des préférences humaines** offline (paires "A est mieux que B")
2. **Entraîner un RM** à imiter ces préférences
3. **Utiliser le RM** comme oracle de récompense dans PPO/DPO

Le RM est donc un **proxy** des préférences humaines. **Tout l'art de RLHF est dans la qualité de ce proxy.**

## L'idée

### Format des données

Chaque sample est typiquement :

```
{
  "prompt": "Explique-moi la photosynthèse",
  "chosen":   "La photosynthèse est le processus par lequel...",
  "rejected": "C'est quand les plantes mangent du soleil mdr"
}
```

Sources publiques classiques :
- **Anthropic HH-RLHF** : helpful + harmless, ~170k paires
- **OpenAssistant** : conversations annotées
- **UltraFeedback** : annotations par GPT-4, ~64k
- **HelpSteer2 (NVIDIA)** : annotations détaillées sur 5 dimensions
- **Nectar, SHP, PKU SafeRLHF** : autres datasets standards

### Modèle Bradley-Terry

L'hypothèse : la probabilité qu'un humain préfère $y_w$ à $y_l$ pour le prompt $x$ suit :

$$ P(y_w \succ y_l | x) = \sigma\big( r^*(x, y_w) - r^*(x, y_l) \big) $$

où $r^*$ est la fonction de récompense "vraie". Le RM $r_\phi$ apprend cette fonction par MLE (maximum likelihood) — voir [[Maximum likelihood estimation]].

**Loss** :

$$ \mathcal{L}_{\text{RM}}(\phi) = -\mathbb{E}_{(x, y_w, y_l)} \log \sigma\big( r_\phi(x, y_w) - r_\phi(x, y_l) \big) $$

### Architecture

- **Backbone** : LLM (souvent même famille que la policy à aligner). Ex : Llama-3-8B avec une **scalar head** ajoutée
- **Scalar head** : un Linear(hidden_size, 1) sur la position du dernier token
- **Output** : un scalaire (pas de softmax)

On part typiquement d'un **SFT model**, pas d'un base model — ça aide à généraliser sur des conversations naturelles.

### Pourquoi pas un classifieur direct ?

On pourrait apprendre $P(\text{good} | x, y)$ via logreg. Mais Bradley-Terry a plusieurs avantages :
- **Invariant aux décalages** : $r_\phi$ est défini à une constante près, on n'a pas à calibrer la moyenne
- **Modélise des comparaisons relatives** : c'est ce que l'humain produit naturellement ("A est mieux que B"), pas une note absolue
- **Robuste au noise** : préférences inconsistantes sont absorbées dans la sigmoid

### Variantes / extensions

#### Listwise (vs pairwise)
Au lieu de paires, ranking d'une liste de K réponses (Plackett-Luce). Utilisé par OpenAI early RLHF. Plus d'info par exemple, plus cher à annoter.

#### Multi-dimensional RM (HelpSteer, ArmoRM)
Au lieu d'un scalaire global, prédire plusieurs dimensions (helpfulness, correctness, coherence, complexity, verbosity) → permet du **reward engineering**.

#### Process Reward Model (PRM)
Pour le reasoning : récompenser **chaque étape** d'une chain-of-thought, pas juste la réponse finale. Lightman et al. *Let's verify step by step* (2023).

Très puissant mais **dur à collecter** (humain doit annoter chaque étape) et **complexe à intégrer** (credit assignment par token).

DeepSeek-R1 a abandonné PRM au profit de **récompenses verifiables binaires** sur la réponse finale.

#### Generative reward model
Le RM génère du texte (critique) au lieu d'un scalaire. Self-Critique, LLM-as-Judge (cf. [[LLM-as-judge]]).

### Reward hacking

Le **piège #1** du reward modeling. Le RM apprend des **corrélations parasites**, pas la "vraie qualité". Quand la policy maximise le RM, elle exploite ces corrélations :

| Exploitation | Origine probable |
|---|---|
| Réponses très longues | Annotators favorisent réponses détaillées → RM apprend "long = bon" |
| Markdown abusif (bullets, gras) | Annotators préfèrent réponses bien formattées → RM apprend "markdown = bon" |
| Confidence excessive | Annotators voient l'assurance comme signe de qualité |
| Sycophancy ("c'est une excellente question !") | RM appris sur ChatGPT-style flatterie |
| Refus excessifs | Si safety-RM, modèle apprend à refuser tout par sécurité |
| Citations bidons | RM préfère réponses citées, modèle invente des refs |
| Réponses qui répètent la question | "Restating the question" est lu comme attentif |

**Goodhart's law** : *"Quand une métrique devient un objectif, elle cesse d'être une bonne métrique."*

### Mitigations du reward hacking

1. **KL penalty** vers le SFT model (β bien calibré) → empêche divergence pathologique
2. **Length normalization** : pénaliser ou ignorer la longueur
3. **RM ensembling** : moyenner plusieurs RMs entraînés différemment → robustesse
4. **Multi-objective RM** : sortie multi-dim, agréger explicitement
5. **Adversarial RM training** : trainer le RM sur les outputs **de la policy en cours**, pas juste SFT outputs (online RLHF)
6. **Eval out-of-distribution** : eval sets différents du training set RM
7. **Audit human ad-hoc** : sample 100 outputs, regarder ce qui a haute reward — souvent révélateur
8. **Constitutional AI** : faire critiquer les outputs par un LLM avec une "constitution" écrite (Anthropic)

### Distribution shift

Le RM est entraîné sur des outputs **du SFT model** (ou GPT-4). Pendant PPO, la policy s'éloigne du SFT. → Les outputs vus par le RM sont **hors distribution** de son training. Le RM peut devenir non-fiable.

**Solutions** :
- **Iterative RLHF** : refaire des préférences sur outputs de la policy courante, retrain le RM, refaire un round PPO. Pipeline Llama 3, Tulu 3.
- **RLAIF** : utiliser un LLM (Claude, GPT-4) à la place du RM pour scorer en cours de route — scalable.
- **Verifiable rewards** : quand possible (math, code), bypasse le RM entièrement.

### Calibration

Un bon RM doit non seulement classer correctement, mais avoir des **écarts de score significatifs** entre réponses de qualités différentes. Si $r(y_w) - r(y_l) \approx 0.01$ partout, le gradient PPO est faible et bruité.

Métriques :
- **Accuracy** sur held-out preferences (typique : 70-80% c'est OK, 90%+ c'est suspect → leakage)
- **Mean reward gap** : moyenne de $r(y_w) - r(y_l)$ sur le test set
- **Calibration plot** : confiance vs accuracy
- **Reward variance** : à confidence faible, attention au bruit

### Reward shaping pratique

Composer la récompense finale dans PPO :

$$ R(x, y) = r_\phi(x, y) - \beta \cdot \text{KL}(\pi_\theta(\cdot | x) \| \pi_{\text{ref}}(\cdot | x)) - \lambda_\ell \cdot |y| + \lambda_f \cdot \mathbb{1}[\text{format OK}] $$

- $r_\phi$ : RM neural
- KL penalty vers SFT
- Length penalty (linear ou capped)
- Format reward (bonus si réponse suit le template attendu)

À calibrer empiriquement.

## Quand c'est utile

- **RLHF / PPO** : indispensable comme oracle de récompense
- **DPO / KTO / ORPO** : pas de RM explicite, mais les mêmes datasets de préférences
- **Best-of-N sampling** : sampler N réponses, prendre celle avec le plus haut $r_\phi$ — gain massif sans modifier la policy
- **Eval offline** : utiliser le RM pour scorer des outputs de différents modèles
- **Curation de data SFT** : filtrer les exemples haut-reward du dataset SFT pour purifier
- **Rejection sampling fine-tuning** : sampler, garder les top-K par RM, refine-tune dessus
- **Multi-objective alignment** : utiliser plusieurs RMs (helpfulness + harmlessness)

## Quand ça ne marche pas / pièges

- **Reward hacking** : voir liste plus haut. Symptôme : eval humain dégrade alors que reward monte
- **Annotation noise** : annotateurs en désaccord 20-30% du temps → plafond d'accuracy RM
- **Bias dans les annotations** : si annotateurs préfèrent un certain style, le RM hérite du biais
- **Datasets périmés** : préférences sur des outputs Llama-1 ne sont peut-être pas valides pour Llama-4
- **Underfitting** : RM trop petit ne capture pas la complexité → préférences moyennes
- **Overfitting** : RM trop entraîné mémorise les paires → généralise mal
- **Confusion ranking vs scoring** : Bradley-Terry est invariant aux décalages, ne sors pas du RM des "scores absolus" sans calibration
- **Length bias massif** : un RM peut atteindre 70% accuracy juste en prédisant "le plus long gagne". Mesurer la length-controlled accuracy
- **Position bias** (listwise) : annotateurs préfèrent la 1re option vue → randomiser l'ordre
- **Mode collapse** : si KL trop bas, policy converge vers un narrow style qui exploite le RM
- **PRM trop ambitieux** : peu de bénéfice clair, coût annotation élevé → préférer ORM (outcome reward) ou verifiable rewards

## Code minimal

```python
# Reward model training avec TRL (HuggingFace)
from trl import RewardTrainer, RewardConfig
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from datasets import load_dataset

model_id = "meta-llama/Meta-Llama-3-8B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForSequenceClassification.from_pretrained(model_id, num_labels=1, torch_dtype="bf16")
# num_labels=1 -> scalar head pour reward modeling

ds = load_dataset("argilla/ultrafeedback-binarized-preferences-cleaned")
# Colonnes attendues : "chosen", "rejected" (chacune = liste de messages au format chat)

config = RewardConfig(
    output_dir="./rm-llama3",
    per_device_train_batch_size=4,
    learning_rate=1e-5,
    num_train_epochs=1,
    max_length=2048,
    gradient_checkpointing=True,
    bf16=True,
)

trainer = RewardTrainer(
    model=model, args=config,
    train_dataset=ds["train"], eval_dataset=ds["test"],
    tokenizer=tokenizer,
)
trainer.train()
```

```python
# Bradley-Terry loss à la main (pour comprendre)
import torch
import torch.nn.functional as F

def bt_loss(reward_chosen, reward_rejected):
    """
    reward_chosen, reward_rejected : (B,) scalaires
    """
    return -F.logsigmoid(reward_chosen - reward_rejected).mean()

# Pendant l'entraînement :
r_w = rm(chosen_ids).logits.squeeze(-1)         # (B,)
r_l = rm(rejected_ids).logits.squeeze(-1)
loss = bt_loss(r_w, r_l)

# Métrique d'accuracy
accuracy = (r_w > r_l).float().mean()
```

```python
# Best-of-N sampling avec RM
import torch

def best_of_n(policy, rm, tokenizer, prompt, N=8, temperature=0.9):
    completions = []
    for _ in range(N):
        ids = policy.generate(
            tokenizer.encode(prompt, return_tensors="pt"),
            do_sample=True, temperature=temperature, max_new_tokens=512,
        )
        completions.append(tokenizer.decode(ids[0]))

    # Score chaque completion avec le RM
    scores = []
    for c in completions:
        with torch.no_grad():
            r = rm(tokenizer.encode(c, return_tensors="pt")).logits.item()
            scores.append(r)

    best = max(range(N), key=lambda i: scores[i])
    return completions[best], scores
```

```python
# Length-controlled accuracy (diagnostiquer length bias)
def length_controlled_accuracy(rm, dataset):
    """
    Bucketer les paires par |y_w| - |y_l|, regarder accuracy par bucket.
    Si la longue réponse a accuracy 90% et la courte 50% -> length bias.
    """
    buckets = {"-30..0": [], "0..30": [], "30..100": [], "100+": []}
    for sample in dataset:
        delta = len(sample["chosen"]) - len(sample["rejected"])
        r_w = rm(sample["chosen"])
        r_l = rm(sample["rejected"])
        correct = r_w > r_l
        bucket = "100+" if delta > 100 else "30..100" if delta > 30 else "0..30" if delta > 0 else "-30..0"
        buckets[bucket].append(correct)
    for b, accs in buckets.items():
        print(f"{b}: n={len(accs)}, acc={sum(accs)/len(accs):.2%}")
```

```python
# Vérification ad-hoc : sample top-reward outputs, lecture humaine
import torch

def audit_top_reward(policy, rm, prompts, top_k=20):
    scored = []
    for p in prompts:
        out = policy.generate(p, do_sample=True, temperature=0.9, max_new_tokens=512)
        r = rm(p + out).logits.item()
        scored.append((r, p, out))
    scored.sort(reverse=True)
    for r, p, o in scored[:top_k]:
        print(f"=== reward={r:.3f} ===")
        print(f"prompt: {p[:200]}\noutput: {o[:500]}\n")
# -> lire à la main, chercher : sycophancy, verbosité, markdown abuse, refus inutile
```

## Pour aller plus loin

- Bradley & Terry, *Rank Analysis of Incomplete Block Designs* (1952) — l'origine
- Christiano et al., *Deep RL from Human Preferences* (NeurIPS 2017)
- Ouyang et al., *Training language models to follow instructions with human feedback* (InstructGPT, 2022)
- Stiennon et al., *Learning to summarize from human feedback* (2020) — RM pour summarization
- Bai et al., *Constitutional AI: Harmlessness from AI Feedback* (Anthropic 2022) — RLAIF
- Lightman et al., *Let's Verify Step by Step* (OpenAI 2023) — PRM
- Wang et al., *HelpSteer2-Preference: Complementing Ratings with Preferences* (NVIDIA 2024)
- ArmoRM (Wang 2024) — multi-objective RM SOTA
- Skywork-Reward, RM-Bench — benchmarks RM
- *RewardBench* leaderboard : https://huggingface.co/spaces/allenai/reward-bench
- **Liens internes** : [[RLHF and DPO]], [[PPO]], [[GRPO]], [[LLM-as-judge]], [[Reward shaping and hacking]], [[Maximum likelihood estimation]]
