---
galaxie: dev
nom: Postgres
alias: [PostgreSQL, postgres, pg]
categorie: database/relational
sous_categories: [oltp, sql, acid]
licence: PostgreSQL
licence_type: open-source
hosted: both
maturite: production
langage: C
clients_officiels: [python, ts, go, rust, java, ruby, php]
plateforme: [linux, macos, windows]
score: 5
mes_projets: []
alternatives: ["[[SQLite]]", "[[MySQL]]", "[[CockroachDB]]"]
remplace: []
remplace_par: []
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, database, sql, oltp]
url_officiel: https://www.postgresql.org/
url_docs: https://www.postgresql.org/docs/
url_repo: https://git.postgresql.org/gitweb/?p=postgresql.git
---

# Postgres

## Pourquoi
Base relationnelle de référence. ACID complet, écosystème énorme, extensions puissantes (pgvector, PostGIS, TimescaleDB). Mon défaut pour 95% des projets backend.

## Quand l'utiliser
- Toute app avec données structurées et requêtes complexes
- Quand on a besoin de transactions
- Quand on veut intégrer ML (pgvector) sans nouvelle infra
- Multi-tenant avec schema-per-tenant (cf. `[[Pattern - SaaS multi-tenant]]`)
- Données géospatiales (extension PostGIS)

## Quand NE PAS l'utiliser
- Charge analytique massive → préférer ClickHouse / DuckDB
- Très haute écriture / sharding natif → CockroachDB
- Petit projet local mono-utilisateur → [[SQLite]] suffit
- Cache pur → [[Redis]]

## Pièges connus
Voir détails dans [[REX - Postgres]].

- Connection pool : par défaut 100, à dimensionner selon workers
- VACUUM peut bloquer en pic
- Migrations sur grosses tables : `CONCURRENTLY` obligatoire
- Pas de bool natif < PG10 (héritage)
- Replication logique vs physique : choisir tôt

## Liens
- [[REX - Postgres]] — REX accumulés
- [[Pattern - API REST FastAPI minimale]] — exemple de stack avec PG
- Doc : https://www.postgresql.org/docs/current/
- pgvector (extension vectorielle) : https://github.com/pgvector/pgvector
