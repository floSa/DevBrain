---
galaxie: dev
nom: text-generation-webui
alias: [text-generation-webui, oobabooga, ooba]
categorie: llm/local
sous_categories: [local, webui, gui, gradio, exploration]
licence: AGPL-3.0
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python, openai-compat]
plateforme: [linux, macos, windows]
score: 3
mes_projets: []
alternatives: ["[[LM Studio]]", "[[Ollama]]", "[[llama.cpp]]", "SillyTavern"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, local, webui, exploration]
url_officiel: https://github.com/oobabooga/text-generation-webui
url_docs: https://github.com/oobabooga/text-generation-webui/wiki
url_repo: https://github.com/oobabooga/text-generation-webui
---

# text-generation-webui

## Pourquoi

WebUI **Gradio** pour faire tourner des LLMs locaux. Surnommé **"Oobabooga"** (du pseudo du créateur). Conçu comme un "AUTOMATIC1111 du LLM" : un seul outil qui supporte **tous les backends** (transformers, llama.cpp, ExLlamaV2, GGUF, AWQ, GPTQ, EXL2) et expose une UI riche pour explorer, comparer, fine-tuner LoRA.

Cible : **enthousiastes LLM local**, communauté roleplay/storytelling, chercheurs qui veulent swap backends et quantizations sans réinstaller. Plus puissant que LM Studio en customisation, moins polish UI. Expose aussi une **API OpenAI-compat** sur port 5000.

## Quand l'utiliser

- **Exploration intensive** : tester 10+ modèles, formats, quantizations sur une seule UI
- **Backend swap dynamique** : passer de transformers à llama.cpp à ExLlamaV2 sans setup
- **Roleplay / storytelling / character chat** : extensions Characters, World Info, presets
- **LoRA hot-swap** : charger/décharger plusieurs LoRA à chaud
- **Quantizations exotiques** : EXL2, AWQ, GPTQ supportés natifs (vs LM Studio GGUF only)
- **Training tab** : QLoRA fine-tuning intégré dans la UI
- **Extension écosystème** : Coqui TTS, SD image gen, RAG, multimodal, etc.

## Quand NE PAS l'utiliser

- **Production serveur** → [[vLLM]] / [[TGI]] / [[SGLang]] (perf et stabilité)
- **UX polish** → [[LM Studio]] (moderne, plus accessible)
- **CLI / scripting** → [[Ollama]] (daemon léger, API simple)
- **Multi-user concurrent** : Gradio mono-user par design, pas thread-safe
- **Stack reproductible (Docker/K8s)** : install lourde, dépendances fragiles
- **Licence permissive requise** : **AGPL-3.0** contagieuse pour serveurs publics

## Pièges connus

- **UI Gradio old-school** : fonctionnelle mais peu sexy, dense en onglets
- **Dépendances lourdes** : PyTorch CUDA + plusieurs backends compilés + extensions → install ~10 Go
- **Updates GitHub fréquents → breakages** : `git pull` peut casser, lock une release stable
- **Pas thread-safe** : un seul user à la fois, pas de batching multi-requête
- **AGPL-3.0 contagieuse** : utilisation serveur public = obligation d'ouvrir le code
- **Quantizations à choisir manuellement** : pas de auto-detect comme Ollama
- **GPU offload manuel** : nombre de layers à régler selon backend et VRAM
- **Extensions community** : qualité hétérogène, certaines abandonnées
- **One-click installer Windows fragile** : conflits CUDA / Python / Visual Studio fréquents

## Code minimal

```bash
# Install (Linux/Mac)
git clone https://github.com/oobabooga/text-generation-webui
cd text-generation-webui
./start_linux.sh   # ou start_macos.sh / start_windows.bat

# Lancer avec API OpenAI-compat exposee
python server.py \
    --model models/llama-3.1-8b-instruct \
    --loader llama.cpp \
    --n-gpu-layers 35 \
    --api --api-port 5000 \
    --listen
```

```python
# Client OpenAI-compat
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:5000/v1",
    api_key="EMPTY",
)

response = client.chat.completions.create(
    model="llama-3.1-8b-instruct",
    messages=[{"role": "user", "content": "Resume Don Quichotte en 3 phrases."}],
    temperature=0.5, max_tokens=300,
)
print(response.choices[0].message.content)
```

```bash
# Telecharger un modele via la UI (onglet Model)
# Ou en CLI :
python download-model.py meta-llama/Llama-3.1-8B-Instruct

# Charger un LoRA
# UI : onglet Model -> LoRA dropdown -> Apply LoRAs
```

## Liens

- [[LM Studio]] — alternative UI moderne (closed-source)
- [[Ollama]] — alternative CLI-first / serveur léger
- [[llama.cpp]] — backend utilisé pour GGUF
- [[vLLM]] / [[TGI]] / [[SGLang]] — alternatives production-grade
- SillyTavern — UI front-end roleplay branchable sur text-generation-webui
- Wiki : https://github.com/oobabooga/text-generation-webui/wiki
- GitHub : https://github.com/oobabooga/text-generation-webui
