---
galaxie: dev
nom: fanalysis
alias: [fanalysis-py]
categorie: tooling/stats
sous_categories: [factor-analysis, pca, mca, ca, mfa]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: beta
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[prince]]", "scikit-learn (PCA only)", "FactoMineR (R)"]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: en-eval
tags: [service, stats, factor-analysis, python]
url_officiel: https://github.com/OlivierGarciaDev/fanalysis
url_docs: https://github.com/OlivierGarciaDev/fanalysis
url_repo: https://github.com/OlivierGarciaDev/fanalysis
---

# fanalysis

## Pourquoi

Alternative à [[prince]] pour les analyses factorielles en Python, dans l'esprit `FactoMineR` (R). Plus minimaliste mais fournit les diagnostics français classiques (contributions, cos², qualité de représentation).

## Quand l'utiliser

- Tu trouves prince trop "magique" et veux du code plus transparent
- Tu veux des sorties type FactoMineR (R) plus fidèles
- Apprentissage : code source plus lisible que prince

## Quand NE PAS l'utiliser

- Maintenance moins active que prince — vérifier la dernière commit avant adoption
- Moins de méthodes couvertes (pas de GPA, pas de FAMD au moment de cette fiche)
- Pour la production : préférer prince ou scikit-learn

## Pièges connus

- Communauté plus restreinte → moins de réponses Stack Overflow
- Documentation principalement en français
- API parfois divergente de prince — pas drop-in compatible

## Liens

- Repo : https://github.com/OlivierGarciaDev/fanalysis
- Concepts : [[PCA]], [[CA]], [[MCA]], [[MFA]]
- Alternative : [[prince]]
