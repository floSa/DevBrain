---
galaxie: wiki
nom: Regression metrics
alias: [MSE, RMSE, MAE, R2, MAPE, Huber, regression evaluation]
type: concept
categorie: concept/metrics
sous_categories: [metrics, regression, evaluation]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: []
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, metrics, regression]
---

# Regression metrics

## TL;DR

Métriques pour évaluer un modèle qui prédit une **valeur continue**. Familles : **erreur quadratique** (MSE, RMSE — pénalise gros écarts), **erreur absolue** (MAE — robuste aux outliers), **erreur relative** (MAPE, sMAPE, WAPE — adimensionnelle), **coefficient de détermination** ($R^2$, adjusted). Choix selon : présence d'outliers, unité de la cible, échelles multiples. Pas de "meilleure" métrique universelle — toujours la lier au coût business.

## Le problème

Quand on prédit une variable continue $y \in \mathbb{R}$, comment quantifier "à quel point on est proche" ? Plusieurs métriques répondent différemment selon ce qu'on optimise vraiment.

## L'idée

### Erreur quadratique

**MSE** (Mean Squared Error) :

$$ \text{MSE} = \frac{1}{n} \sum_{i=1}^n (y_i - \hat y_i)^2 $$

- Pénalise quadratiquement les gros écarts → sensible aux **outliers**
- Différentiable partout → loss standard pour SGD
- Unité = unité de $y$ au carré → pas interprétable directement

**RMSE** : $\sqrt{\text{MSE}}$ → unité = unité de $y$. Interprétable comme "écart-type de l'erreur". Standard pour reporting.

**MSE/RMSE** = MLE sous bruit **gaussien**. Optimum = moyenne conditionnelle.

### Erreur absolue

**MAE** (Mean Absolute Error) :

$$ \text{MAE} = \frac{1}{n} \sum |y_i - \hat y_i| $$

- Pénalise linéairement → **robuste aux outliers**
- Unité = unité de $y$, interprétable
- Non-différentiable en 0 (mais sous-gradient ok)

**MAE** = MLE sous bruit **Laplace**. Optimum = **médiane** conditionnelle. Important : un modèle entraîné avec MSE et un entraîné avec MAE convergent vers des fonctions différentes.

### Erreur relative (scale-invariant)

**MAPE** (Mean Absolute Percentage Error) :

$$ \text{MAPE} = \frac{100}{n} \sum \left|\frac{y_i - \hat y_i}{y_i}\right| $$

- Adimensionnelle (%), comparable entre datasets
- **Asymétrique** : sur-prédire de 50% pénalisé "5%/(5%-100%) = 1900%"... gros pièges
- **Explose** quand $y \to 0$ (division par zéro)
- Préfère systématiquement les sous-prédictions

**sMAPE** (symmetric MAPE) :

$$ \text{sMAPE} = \frac{100}{n} \sum \frac{2 |y_i - \hat y_i|}{|y_i| + |\hat y_i|} $$

- Borné [0, 200%] (ou [0, 100%] selon convention)
- Symétrique sur/sous-prédiction
- Toujours problème quand $y$ et $\hat y$ tous deux ≈ 0

**WAPE** (Weighted APE) :

$$ \text{WAPE} = \frac{\sum |y_i - \hat y_i|}{\sum |y_i|} $$

- Mieux que MAPE : pas de division ponctuelle par 0
- Standard en demand forecasting

### Coefficient de détermination

**R²** :

$$ R^2 = 1 - \frac{\sum (y_i - \hat y_i)^2}{\sum (y_i - \bar y)^2} = 1 - \frac{\text{MSE modèle}}{\text{Var}(y)} $$

- "Quelle fraction de la variance est expliquée par le modèle"
- $R^2 = 1$ : prédictions parfaites ; $R^2 = 0$ : aussi nul que prédire la moyenne
- **Peut être négatif** (modèle pire que la moyenne)

**Adjusted R²** :

$$ R^2_{adj} = 1 - (1 - R^2) \frac{n - 1}{n - p - 1} $$

avec $p$ = nb de features. Pénalise l'ajout de features inutiles. Standard pour comparer modèles linéaires de complexité différente.

### Huber loss

Compromis MSE/MAE :

$$ L_\delta(r) = \begin{cases} \frac{1}{2} r^2 & |r| \leq \delta \\ \delta (|r| - \frac{\delta}{2}) & |r| > \delta \end{cases} $$

- Quadratique près de 0 (différentiable, lisse)
- Linéaire loin (robuste aux outliers)
- Hyperparamètre $\delta$ à tuner

**Quantile loss / Pinball loss** :

$$ L_\tau(r) = \begin{cases} \tau r & r \geq 0 \\ (\tau - 1) r & r < 0 \end{cases} $$

- Optimise pour le **quantile $\tau$** de la distribution conditionnelle (pas la moyenne)
- $\tau = 0.5$ → MAE / médiane
- Standard pour la prédiction d'intervalles (LightGBM, quantile regression forests)

### Tableau récapitulatif

| Métrique | Robuste outliers | Adimensionnelle | Différentiable | Optimum |
|---|:-:|:-:|:-:|---|
| MSE | ✗ | ✗ | ✓ | moyenne |
| RMSE | ✗ | ✗ | ✓ | moyenne |
| MAE | ✓ | ✗ | ~ | médiane |
| MAPE | ~ | ✓ | ~ | biais sous-pred |
| sMAPE | ~ | ✓ | ~ | symétrique |
| WAPE | ~ | ✓ | ~ | médiane pondérée |
| R² | ✗ | ✓ | ✓ | moyenne |
| Huber | ✓ | ✗ | ✓ | mixte |
| Quantile | ✓ | ✗ | ~ | quantile τ |

### Lier à la business value

Le choix de la métrique doit refléter le **coût asymétrique** :

- Demande prévisionnelle (retail) : sur-stock = peu cher, rupture = cher → quantile loss τ=0.9
- Pricing : symétrique → RMSE
- Énergie : très grosses erreurs catastrophiques → MSE/RMSE
- Robustesse à outliers data corrompue → MAE/Huber

## Quand c'est utile

- **Toute régression** : choisir la métrique aligne le modèle avec le coût réel
- **Modèles probabilistes** : pinball/quantile pour intervalles
- **Comparaison de modèles** : R² ou adjusted R² pour ranking sur même dataset
- **Cross-validation** : MAE pour stabilité, RMSE pour reporting
- **Forecasting** : voir [[Forecasting metrics]] pour spécificités TS

## Quand ça ne marche pas / pièges

- **MAPE quand y ≈ 0** : division explose. Utiliser WAPE ou MAE.
- **R² gonflé par features inutiles** : utiliser adjusted R².
- **Single metric** : un seul nombre cache la distribution des erreurs. Toujours plotter résidus, regarder MAE + RMSE + percentiles d'erreur.
- **Train vs test** : R² train n'est PAS R² test. Reporter tout sur test set.
- **R² négatif** : modèle pire que la moyenne. Investiguer (data leakage côté inverse, features cassées).
- **Optimiser MSE ≠ MAE** : un modèle entraîné avec MSE ne minimise PAS la MAE. Choisir la loss qui correspond à la métrique business.
- **Outliers contaminés** : RMSE peut être 10x MAE → red flag, investiguer.
- **Cible log-transformée** : reporter dans l'unité originale (avec Jensen biais correct).

## Code minimal

```python
import numpy as np
from sklearn.metrics import (
    mean_squared_error, mean_absolute_error, r2_score,
    mean_absolute_percentage_error
)

y_true = np.array([100, 200, 300, 400, 500])
y_pred = np.array([110, 195, 290, 420, 480])

mse = mean_squared_error(y_true, y_pred)
rmse = np.sqrt(mse)
mae = mean_absolute_error(y_true, y_pred)
mape = mean_absolute_percentage_error(y_true, y_pred)
r2 = r2_score(y_true, y_pred)
wape = np.sum(np.abs(y_true - y_pred)) / np.sum(np.abs(y_true))
smape = np.mean(2 * np.abs(y_true - y_pred) / (np.abs(y_true) + np.abs(y_pred)))

print(f"MSE  = {mse:.2f}")
print(f"RMSE = {rmse:.2f}")
print(f"MAE  = {mae:.2f}")
print(f"MAPE = {mape*100:.2f}%")
print(f"sMAPE= {smape*100:.2f}%")
print(f"WAPE = {wape*100:.2f}%")
print(f"R²   = {r2:.3f}")

# Huber loss
def huber(y, yhat, delta=1.0):
    r = np.abs(y - yhat)
    return np.where(r <= delta, 0.5 * r**2, delta * (r - 0.5 * delta)).mean()

# Quantile loss
def pinball(y, yhat, tau=0.5):
    r = y - yhat
    return np.maximum(tau * r, (tau - 1) * r).mean()

print(f"Huber(δ=10) = {huber(y_true, y_pred, delta=10):.2f}")
print(f"Pinball(τ=0.9) = {pinball(y_true, y_pred, tau=0.9):.2f}")

# Quantile regression
from sklearn.linear_model import QuantileRegressor
X = np.arange(5).reshape(-1, 1)
qr = QuantileRegressor(quantile=0.9, alpha=0).fit(X, y_true)
print(f"Q90 prediction: {qr.predict(X)}")  # bande supérieure

# Distribution des erreurs (toujours plotter)
import matplotlib.pyplot as plt
errors = y_true - y_pred
plt.hist(errors, bins=20)
# Cherche : symétrie, queues, biais (mean != 0)
```

## Pour aller plus loin

- Hyndman & Athanasopoulos, *Forecasting: Principles and Practice* (3e éd.) — chap. 5
- Koenker, *Quantile Regression* (Cambridge 2005) — pinball loss en profondeur
- Cross-validated, *Why is R-squared not a good measure?* — débat classique
- **Liens internes** : [[Forecasting metrics]], [[Classification metrics]], [[Ranking metrics]], [[Bias-variance tradeoff]]
