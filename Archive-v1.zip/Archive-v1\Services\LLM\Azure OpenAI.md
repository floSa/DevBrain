---
galaxie: dev
nom: Azure OpenAI
alias: [azure-openai, aoai, azure-oai]
categorie: llm/api
sous_categories: [api, llm, azure, openai-compat, enterprise, compliance]
licence: Proprietaire
licence_type: proprietary
hosted: managed
maturite: production
langage: 
clients_officiels: [python (openai SDK), ts, c#, java, go, rest]
plateforme: [cloud]
score: 4
mes_projets: []
alternatives: ["[[OpenAI API]]", "AWS Bedrock", "GCP Vertex AI"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, api, azure, enterprise, compliance]
url_officiel: https://azure.microsoft.com/en-us/products/ai-services/openai-service
url_docs: https://learn.microsoft.com/en-us/azure/ai-services/openai/
url_repo: 
---

# Azure OpenAI

## Pourquoi

**Modèles OpenAI hébergés sur Azure** (GPT-4, GPT-4o, o1, o3, embeddings, DALL-E). Même API que [[OpenAI API]] (SDK `openai` Python compatible), mais avec les **garanties Azure** :
- **Compliance enterprise** : SOC 2, HIPAA, ISO 27001/2/18, PCI DSS, FedRAMP, EU Data Boundary
- **Data residency** : déploiements régionaux (France Central, Sweden Central, etc.)
- **VNet isolation** : private endpoints, pas de sortie internet
- **Contractualisation** : SLA, support enterprise, dédié si Provisioned Throughput Units
- **Pas d'entraînement sur tes data** (contractuel)

Standard dans les grandes boîtes ayant déjà du Azure (banques, healthcare, government, EU).

## Quand l'utiliser

- **Compliance / data residency UE** : modèles déployés en France / Sweden / etc.
- **Stack Azure existante** : Azure AD / Entra ID auth, intégration Azure Functions / Logic Apps / Cognitive Search
- **SLA / support enterprise** needed (SLA 99.9% sur Standard, plus sur Provisioned)
- **Quotas dédiés (PTUs)** : Provisioned Throughput Units pour latency / throughput garantis
- **Audit & gouvernance** : logs Azure Monitor, content filtering configurable
- **Combo Azure AI Search** : RAG natif avec semantic ranker

## Quand NE PAS l'utiliser

- **Latest models day-zero** → [[OpenAI API]] direct (lag Azure ~semaines à mois)
- **Pricing pur** → OpenAI direct souvent un peu moins cher en pay-as-you-go
- **Multi-cloud / portabilité** → [[LiteLLM]] route entre providers
- **Modèles non-OpenAI** ([[Anthropic Claude API]], Mistral) → autres providers ou AWS Bedrock (Anthropic + Cohere + Mistral + Llama)
- **Stack non-Azure** : friction setup IAM / endpoints / déploiements

## Pièges connus

- **API endpoints différents** : `deployment_name` au lieu de `model` dans les calls. Faut **déployer** chaque modèle dans ton resource avant de pouvoir l'appeler.
- **Versions modèles décalées vs OpenAI** : `gpt-4o-2024-08-06` sortie chez OpenAI peut prendre 2-8 semaines avant Azure
- **Function calling format identique** mais bugs occasionnels de divergence (test)
- **Quotas régionaux limitatifs** : capacité TPM/RPM peut être saturée en région, prévoir multi-region failover
- **Setup IAM complexe** : Azure RBAC + Managed Identity vs API key — préférer Managed Identity en prod
- **Content Filters** : Azure ajoute une couche de modération **par défaut** plus stricte que OpenAI. Peut bloquer des outputs légitimes (médical, légal). Configurable.
- **Pricing PTU différent du pay-as-you-go** : engagement mensuel, à calculer
- **Embeddings** : `text-embedding-3-small/large` disponibles mais à déployer explicitement

## Code minimal

```python
# pip install openai
from openai import AzureOpenAI

# Auth : API key OU Managed Identity (recommandée en prod)
client = AzureOpenAI(
    api_key="...",                              # ou DefaultAzureCredential()
    api_version="2024-10-21",
    azure_endpoint="https://my-resource.openai.azure.com",
)

# Note : `model` = nom du DEPLOYMENT (configuré dans Azure portal),
# pas le nom du modèle OpenAI
response = client.chat.completions.create(
    model="gpt-4o-deployment",                  # custom deployment name
    messages=[{"role": "user", "content": "Hello"}],
    temperature=0.7,
)
print(response.choices[0].message.content)

# Embeddings
emb = client.embeddings.create(
    model="text-embedding-3-small-deployment",
    input=["text 1", "text 2"],
)

# Avec Managed Identity (Azure-native auth, no secrets)
# from azure.identity import DefaultAzureCredential, get_bearer_token_provider
# token_provider = get_bearer_token_provider(
#     DefaultAzureCredential(),
#     "https://cognitiveservices.azure.com/.default"
# )
# client = AzureOpenAI(
#     azure_ad_token_provider=token_provider,
#     api_version="2024-10-21",
#     azure_endpoint="https://my-resource.openai.azure.com",
# )

# Content filtering (response peut contenir prompt_filter_results)
if response.prompt_filter_results:
    for f in response.prompt_filter_results:
        if f["content_filter_results"]["hate"]["filtered"]:
            print("Bloqué par content filter")
```

## Liens

- [[OpenAI API]] — version directe
- AWS Bedrock — équivalent AWS (Claude, Cohere, Mistral, Llama hosted)
- GCP Vertex AI — équivalent GCP (Gemini + Claude + Anthropic + open)
- [[LiteLLM]] — abstraction multi-provider
- [[Comparatif - LLM eval et observability]]
- Docs : https://learn.microsoft.com/en-us/azure/ai-services/openai/
- Region availability : https://learn.microsoft.com/en-us/azure/ai-services/openai/concepts/models
- Pricing : https://azure.microsoft.com/en-us/pricing/details/cognitive-services/openai-service/
