---
galaxie: wiki
nom: Stationarity
alias: [Stationnarité, Stationarité]
type: concept
categorie: concept/time-series
sous_categories: [stationarity, adf, kpss, differencing]
domaines: [data-science, data-eng]
maturite: established
auteurs_cles: [Dickey-Fuller 1979, Kwiatkowski 1992, Phillips-Perron 1988]
lecture_min: 9
created: 2026-05-19
modified: 2026-05-19
tags: [concept, time-series, stationarity]
---

# Stationarity — Stationnarité

## TL;DR

Une série temporelle est **stationnaire** si ses propriétés statistiques (moyenne, variance, autocorrélation) ne dépendent pas du temps. C'est la **condition nécessaire** pour appliquer ARIMA, ETS, et la plupart des modèles classiques. Tester via **ADF** et **KPSS**, traiter par **différentiation** ou **transformation** (log, Box-Cox).

## Le problème

Beaucoup de séries temporelles ont une **tendance** (ventes qui montent dans le temps), une **saisonnalité** (température par mois), ou une **variance croissante** (volatilité financière). Sur ces séries non-stationnaires :

- Régression / corrélation donnent des résultats **fallacieux** ("spurious regression" : deux séries non-stationnaires apparaissent corrélées même si elles n'ont rien à voir).
- ARIMA et la plupart des modèles classiques ne sont **pas définis** dessus.
- Le forecast diverge ou converge mal.

## L'idée

### Définitions

**Stationnarité stricte** : la distribution conjointe $(X_{t_1}, \dots, X_{t_n})$ est invariante par translation temporelle : $\forall \tau, \quad (X_{t_1+\tau}, \dots, X_{t_n+\tau}) \overset{d}{=} (X_{t_1}, \dots, X_{t_n})$.

Trop fort en pratique. On utilise la version faible :

**Stationnarité au sens large** (second-order, weakly stationary) : les 3 conditions suivantes sont remplies :

1. $\mathbb{E}[X_t] = \mu$ constante
2. $\mathrm{Var}(X_t) = \sigma^2$ constante
3. $\mathrm{Cov}(X_t, X_{t+h}) = \gamma(h)$ ne dépend que de l'écart $h$, pas de $t$

C'est l'hypothèse minimum d'ARIMA.

### Tests statistiques

#### ADF (Augmented Dickey-Fuller)

Teste $H_0$ : la série a une **racine unitaire** (donc non-stationnaire).
- $p$-value < 0.05 → rejet de $H_0$ → série **probablement stationnaire**
- $p$-value > 0.05 → on ne peut pas rejeter, donc **probablement non-stationnaire**

#### KPSS

Test **complémentaire** d'ADF, hypothèses inversées :
- $H_0$ : la série est stationnaire (autour d'une constante ou d'une tendance)
- $p$-value < 0.05 → rejet → série **non-stationnaire**

**Bonne pratique** : faire les deux tests. Conclusions :

| ADF | KPSS | Conclusion |
|---|---|---|
| stationnaire | stationnaire | ✅ stationnaire, modélise direct |
| non-stationnaire | non-stationnaire | ❌ non-stationnaire, différencier |
| stationnaire | non-stationnaire | trend-stationary, retire la tendance |
| non-stationnaire | stationnaire | difference-stationary, différencie une fois |

### Traitement de la non-stationnarité

**Différentiation** : $\nabla X_t = X_t - X_{t-1}$. Le "I" de ARIMA(p,d,q) = combien de fois on différencie.

**Saisonnale** : $\nabla_s X_t = X_t - X_{t-s}$ (ex. mois-1 vs mois-13).

**Log / Box-Cox** : stabilise la variance si elle croît avec le niveau.

**Detrending** : retirer la tendance par régression (linéaire, polynomiale, splines).

## Quand c'est utile

- Avant ARIMA : check obligatoire, différencier si besoin
- Avant tout test d'hypothèse sur séries temporelles
- Avant régression entre séries (cointégration si elles sont individuellement non-stationnaires)
- Tout pipeline forecasting classique

## Quand ça ne marche pas / pièges

- **Saisonnalité longue** (annuelle sur données mensuelles) : ADF peut mal détecter, utiliser ADF saisonnier ou tests dédiés (Canova-Hansen)
- **Petite taille d'échantillon** (n<50) : tests peu puissants
- **Outliers** : faussent les tests, à traiter avant
- **Structure complexe** (changements de régime, ruptures) : tests donnent des verdicts simplistes
- **Conclure "stationnaire" car le test passe** : un test passe ou échoue, ce n'est pas une certitude statistique. Inspecte aussi visuellement (ACF, plot).

## Code minimal

```python
import statsmodels.api as sm
import pandas as pd

ts = pd.Series(...)

# ADF
adf_stat, adf_pvalue, *_ = sm.tsa.adfuller(ts)
print(f"ADF: stat={adf_stat:.3f}, p-value={adf_pvalue:.4f}")
# si p < 0.05 → stationnaire

# KPSS
kpss_stat, kpss_pvalue, *_ = sm.tsa.kpss(ts, regression='c')
print(f"KPSS: stat={kpss_stat:.3f}, p-value={kpss_pvalue:.4f}")
# si p < 0.05 → non-stationnaire

# Si non-stationnaire : différencier
ts_diff = ts.diff().dropna()
# Re-tester sur ts_diff
```

## Implémentations concrètes

- `statsmodels.tsa.adfuller` / `statsmodels.tsa.kpss`
- `statsforecast` — gère stationnarité automatiquement pour AutoARIMA
- R : `tseries::adf.test`, `tseries::kpss.test`, `forecast::ndiffs` (recommande le nombre de différentiations)

## Pour aller plus loin

- Hamilton, *Time Series Analysis* (1994) — bible
- Hyndman & Athanasopoulos, *Forecasting: Principles and Practice* — chap. sur stationnarité, gratuit en ligne (https://otexts.com/fpp3/)
- **Liens internes** : [[Autocorrelation]] (ACF/PACF), [[Walk-forward CV]], [[Forecasting framing]]
