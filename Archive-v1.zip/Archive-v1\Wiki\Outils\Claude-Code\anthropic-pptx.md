---
galaxie: wiki
nom: anthropic-skills:pptx
type: claude-code-skill
plateforme: claude-code
categorie: skill/documents
sous_categories: [pptx, slides, presentation]
auteur: Anthropic
source: anthropics/skills
source_url: https://github.com/anthropics/skills
install_cmd: claude plugin install anthropic-skills
install_doc: https://docs.claude.com/en/docs/build-with-claude/skills
licence: MIT
licence_type: open-source
domaines: [doc, ai-eng, ml-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, documents, slides]
---

# anthropic-skills:pptx

## Pourquoi

Skill pour **créer, lire, modifier des .pptx**. Utile pour pondre rapidement une présentation de résultats (résultats d'expérience ML, slides de kickoff projet) ou pour parler à un slide deck existant (extraire texte/structure pour réutilisation).

## Quand l'utiliser

- générer une présentation de résultats à partir d'un notebook/script (figures, tableaux, conclusions)
- transformer un brouillon markdown en deck pptx avec template
- extraire le contenu d'un deck existant (audit, refonte)

## Quand NE PAS l'utiliser

- pour du design fin avec mise en page sur-mesure → fais-le toi-même dans PowerPoint/Keynote
- pour de l'animation/transition complexe → pas le skill pour ça

## Comment l'installer

```bash
claude plugin install anthropic-skills
```

Voir [[_installer-un-skill]].

## Exemples d'usage

```
> crée un deck à partir de ~/exp/notebook.ipynb, 10 slides max, template clair
> ouvre deck_kickoff.pptx et extrais le plan en markdown
> ajoute une slide "Résultats benchmark" après la slide 5 de presentation.pptx
```

## Pièges connus

- Les templates `.pptx` complexes (masters perso, polices custom) peuvent se faire écraser à la sauvegarde — fais une copie avant.
- Les graphiques (charts natifs PowerPoint) ne sont pas toujours fidèlement préservés.

## Liens

- Source : https://github.com/anthropics/skills
