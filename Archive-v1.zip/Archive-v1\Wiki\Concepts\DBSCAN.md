---
galaxie: wiki
nom: DBSCAN
alias: [Density-Based Spatial Clustering of Applications with Noise, HDBSCAN]
type: concept
categorie: concept/ml
sous_categories: [clustering, density-based, noise, outlier, hdbscan]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Ester et al. 1996, Campello-Moulavi-Sander 2013 (HDBSCAN)]
lecture_min: 8
created: 2026-05-19
modified: 2026-05-19
tags: [concept, ml, clustering, dbscan, density]
---

# DBSCAN — Density-Based Spatial Clustering with Noise

## TL;DR

Clustering par **densité** : un cluster = zone dense connectée. Pas besoin de spécifier $K$. Gère les clusters de **formes arbitraires** (lunes, anneaux) et marque les points isolés comme **bruit** (outliers naturellement détectés). Limité : sensible aux hyperparams $\varepsilon$ et `min_samples`, mauvais sur densités très variables. **HDBSCAN** = version hiérarchique, plus robuste, à privilégier en 2025-2026.

## Le problème

[[K-means]] échoue sur :
- Clusters non-sphériques (deux lunes entrelacées, anneaux concentriques)
- Densités variables
- Présence d'outliers (qui tirent les centroïdes)
- Nombre $K$ inconnu

DBSCAN attaque ces 4 problèmes simultanément.

## L'idée — DBSCAN classique

### Définitions

- **$\varepsilon$ (eps)** : rayon de voisinage
- **`min_samples`** : nombre minimum de voisins (incluant le point) pour qu'un point soit "core"
- **Core point** : a au moins `min_samples` voisins dans son $\varepsilon$-rayon
- **Border point** : pas core, mais voisin d'un core
- **Noise point** : ni core ni border → outlier

### Algorithme

1. Pour chaque point, calculer ses $\varepsilon$-voisins
2. Identifier les **core points**
3. Connecter les core points proches → cluster
4. Affecter les **border points** au cluster du core voisin
5. Marquer les **noise points** comme cluster $-1$

Pas de centroïde, pas de partitionnement forcé.

### Caractéristiques

- **Pas de $K$ à fournir** : déterminé par les données
- **Formes arbitraires** : capture clusters non-convexes
- **Outliers natifs** : pas besoin de pré-filtrage
- **Coût** : $O(n \log n)$ avec un kd-tree / ball-tree
- **Pas de centroïde** : pas d'interprétation simple "ce cluster est centré sur..."

### Choix d'$\varepsilon$ et `min_samples`

- `min_samples` : règle empirique $= 2 \times \text{dim}$ (en 2D : 4 ; en haute-dim : peut être 10-20)
- $\varepsilon$ : tracer le **k-distance graph** :
  1. Pour chaque point, calculer sa distance à son $k$-ème voisin (avec $k = $ `min_samples`)
  2. Trier ces distances en ordre croissant
  3. Le "coude" indique le bon $\varepsilon$

```python
from sklearn.neighbors import NearestNeighbors
nn = NearestNeighbors(n_neighbors=10).fit(X)
distances, _ = nn.kneighbors(X)
distances_sorted = np.sort(distances[:, -1])
plt.plot(distances_sorted)  # cherche le coude
```

### HDBSCAN — version hiérarchique

DBSCAN classique a un défaut : **un seul $\varepsilon$** pour tout le dataset. Si certains clusters sont denses et d'autres lâches, on ne peut pas tous les capturer.

**HDBSCAN** (Hierarchical DBSCAN, Campello 2013) :
1. Construit une hiérarchie de clusters à toutes les échelles de densité
2. Sélectionne automatiquement les clusters "stables" (persistance sur plusieurs échelles)
3. Hyperparam principal : `min_cluster_size` (taille minimum d'un vrai cluster)

**Avantages vs DBSCAN** :
- Gère densités variables
- Moins sensible aux hyperparams
- Score de "persistance" par cluster (qualité)
- Score de "soft membership" disponible

**À privilégier sur DBSCAN classique** dans la plupart des cas modernes.

## Quand c'est utile

- Clusters **non-sphériques** : géolocalisation (zones urbaines vs rurales), particules physiques, formes biologiques
- Détection d'**outliers** comme sous-produit
- $K$ inconnu et impossible à deviner
- Données spatiales (GPS, capteurs)
- Pré-clustering avant supervision pour identifier des structures

## Quand ça ne marche pas / pièges

- **Densités très variables** dans le même dataset → DBSCAN classique échoue, utiliser HDBSCAN
- **Très haute dimension** ($p > 50$) → la distance euclidienne perd son sens (curse of dimensionality). Pré-traiter avec [[PCA]] ou [[t-SNE and UMAP|UMAP]] d'abord.
- **Données catégorielles** : DBSCAN ne marche pas natif (distance euclidienne). Utiliser distance custom (Gower) ou autre algo.
- **Beaucoup d'outliers acceptables** : OK
- **Faux positifs** : sur des données très bruitées, HDBSCAN peut fragmenter excessivement → ajuster `min_cluster_size`
- **$\varepsilon$ mal calibré** : trop bas → tout devient noise ; trop haut → un seul méga-cluster
- **Standardisation** : toujours `StandardScaler` avant si features d'échelles différentes
- **Reproductibilité** : DBSCAN est déterministe (vs K-means stochastique). HDBSCAN aussi. Bonne nouvelle.

## Code minimal

```python
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
import hdbscan  # pip install hdbscan

X_std = StandardScaler().fit_transform(X)

# DBSCAN classique
db = DBSCAN(eps=0.5, min_samples=10).fit(X_std)
labels_db = db.labels_   # -1 = noise

n_clusters = len(set(labels_db)) - (1 if -1 in labels_db else 0)
n_noise = (labels_db == -1).sum()
print(f"DBSCAN : {n_clusters} clusters, {n_noise} outliers")

# HDBSCAN (recommandé en pratique)
hdb = hdbscan.HDBSCAN(min_cluster_size=10, min_samples=5).fit(X_std)
labels_hdb = hdb.labels_
# Probabilities de membership :
probs = hdb.probabilities_
# Persistence des clusters :
print(hdb.cluster_persistence_)
```

## Implémentations concrètes

- `sklearn.cluster.DBSCAN` — DBSCAN classique
- [[hdbscan]] (`hdbscan.HDBSCAN`) — HDBSCAN, à préférer
- `sklearn.cluster.OPTICS` — alternative à HDBSCAN, génère un reachability plot
- `cuml.DBSCAN` / `cuml.HDBSCAN` (RAPIDS) — GPU
- R : `dbscan` package

## Pour aller plus loin

- Ester et al., *A Density-Based Algorithm for Discovering Clusters* (KDD 1996) — paper original
- Campello et al., *Density-Based Clustering Based on Hierarchical Density Estimates* (2013) — HDBSCAN
- McInnes, *How HDBSCAN Works* (blog) — pédagogique
- **Liens internes** : [[K-means]] (alternative partitionnement), [[GMM]] (alternative probabiliste), [[Clustering evaluation]], [[t-SNE and UMAP]] (souvent prétraitement)
