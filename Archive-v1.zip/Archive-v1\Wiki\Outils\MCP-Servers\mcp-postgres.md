---
galaxie: wiki
nom: mcp-postgres
type: mcp-server
plateforme: universel
categorie: skill/data
sous_categories: [postgres, sql, database, query]
auteur: Model Context Protocol team
source: "@modelcontextprotocol/server-postgres"
source_url: https://github.com/modelcontextprotocol/servers/tree/main/src/postgres
install_cmd: "claude mcp add pg --command npx --args -y @modelcontextprotocol/server-postgres postgresql://user:pass@host:5432/db"
install_doc: https://github.com/modelcontextprotocol/servers
licence: MIT
licence_type: open-source
domaines: [data-science, data-eng, mlops]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [mcp, postgres, database, data]
---

# mcp-postgres

## Pourquoi

MCP server pour parler à une base **Postgres** en lecture (read-only par défaut). L'agent peut explorer le schéma, lancer des requêtes SQL et analyser les résultats sans que tu copies-colles entre psql et la session Claude.

Game-changer pour les sessions d'exploration data / debug pipelines : tu décris le problème, l'agent inspecte le schéma, propose et exécute des requêtes.

## Quand l'utiliser

- Exploration ad-hoc sur une base Postgres (data eng, debugging)
- Documenter un schéma existant ("liste les tables, leur PK et leur cardinalité")
- Debug d'un pipeline qui écrit en Postgres ("pourquoi cette table n'a pas reçu de rows hier ?")
- Génération de DDL ou de migrations à partir d'un schéma actuel

## Quand NE PAS l'utiliser

- Production / base critique : limite-toi à des replicas read-only et **jamais** la connection string en clair
- Manipulations destructrices (DDL, DELETE) — préfère un client SQL où tu valides chaque action

## Comment l'installer

```bash
claude mcp add pg \
  --command npx \
  --args -y @modelcontextprotocol/server-postgres \
  "postgresql://USER:PASS@HOST:5432/DB"

claude mcp list   # "pg  ✓ Connected"
```

> 🔒 Ne mets jamais ta connection string en clair dans un repo. Utilise une variable d'env ou un secrets manager.

Voir [[_installer-un-skill]] section *MCP server*.

## Exemples d'usage

```
> liste les tables de la base et donne-moi la cardinalité de chacune
> trouve les colonnes qui pourraient devenir des FKs (jamais NULL, valeurs distinctes < table parente)
> sur la table orders, montre-moi la distribution des status par mois
```

## Pièges connus

- Le serveur officiel est **read-only** par construction — pas d'écriture, pas de DDL. C'est voulu (sécu).
- Sur les grosses tables, l'agent peut envoyer des `SELECT *` qui mettent à genoux la base. Toujours filtrer.

## Liens

- Repo officiel : https://github.com/modelcontextprotocol/servers
- [[Postgres]] (fiche service)
