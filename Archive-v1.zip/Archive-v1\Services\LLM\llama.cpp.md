---
galaxie: dev
nom: llama.cpp
alias: [llama-cpp, llamacpp]
categorie: llm/local
sous_categories: [inference, gguf, quantization, cpu, edge]
licence: MIT
licence_type: open-source
hosted: self
maturite: production
langage: C/C++
clients_officiels: [cli, python (llama-cpp-python), rest]
plateforme: [linux, macos, windows, android, ios]
score: 
mes_projets: []
alternatives: ["[[Ollama]]", "[[vLLM]]", "[[MLX]]", "[[text-generation-webui]]"]
remplace: []
remplace_par: ["[[Ollama]]"]
created: 2026-05-01
modified: 2026-05-01
status: actif
tags: [service, llm, local, inference, gguf, edge]
url_officiel: https://github.com/ggerganov/llama.cpp
url_docs: https://github.com/ggerganov/llama.cpp/tree/master/docs
url_repo: https://github.com/ggerganov/llama.cpp
---

# llama.cpp

## Pourquoi
Implémentation C/C++ ultra-portable de l'inférence LLM. **Format GGUF** (créé pour ça), quantizations agressives (Q2 à Q8, K-quants, IQ-quants), runs sur CPU, GPU (CUDA/Metal/ROCm/Vulkan), Mac Silicon, Android, iOS. Le moteur sous le capot d'[[Ollama]], LM Studio, et de quasi tout ce qui fait du LLM local.

## Quand l'utiliser
- Inférence sur **CPU uniquement** (pas de GPU)
- Mac Apple Silicon (Metal optimisé excellent)
- Devices contraints : Raspberry Pi, mobile, edge
- Quand tu veux le contrôle total (vs [[Ollama]] qui abstrait)
- Quantizations exotiques (IQ2, IQ3) pour faire tenir un gros modèle en peu de RAM
- Embed dans une app C/C++ via la lib

## Quand NE PAS l'utiliser
- Tu veux juste run un modèle local rapidement → [[Ollama]] est 10x plus simple (et utilise llama.cpp dessous)
- Production GPU haute charge → [[vLLM]]
- Tu veux du Python idiomatique → `llama-cpp-python` mais [[Ollama]] reste plus pratique

## Pièges connus
- **Compilation** : flags BLAS, CUDA, Metal — à compiler pour ton hardware (ou utiliser binaires pré-compilés)
- **Format GGUF** : conversion HF → GGUF nécessaire pour les modèles non disponibles directement
- **K-quants vs I-quants** : tradeoffs précision/taille à mesurer (IQ-quants nouveaux, plus efficaces)
- **Context size** : `-c <ctx>` à dimensionner, mémoire ↗ avec la racine
- **Server mode** (`llama-server`) : OpenAI-compatible, alternative à Ollama si tu veux moins d'abstraction
- **Versions** : projet bouge très vite (PRs quotidiennes), tags pas toujours stables

## Liens
- [[Ollama]] — wrapper user-friendly de llama.cpp
- [[vLLM]] — alternative GPU haute charge
- HF → GGUF : utilitaire `convert_hf_to_gguf.py`
- Quantization guide : https://github.com/ggerganov/llama.cpp/discussions/5063
- llama-cpp-python : https://github.com/abetlen/llama-cpp-python
