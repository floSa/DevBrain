---
galaxie: dev
nom: LangSmith
alias: [langsmith]
categorie: llm/observability
sous_categories: [tracing, observability, evals, prompt-mgmt, llm-ops, langchain]
licence: Proprietaire (SaaS)
licence_type: proprietary
hosted: managed
maturite: production
langage: TypeScript + Python SDK
clients_officiels: [python, ts]
plateforme: [cloud]
score: 4
mes_projets: []
alternatives: ["[[Langfuse]]", "[[Helicone]]", Arize Phoenix, Braintrust]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, llm, observability, langchain]
url_officiel: https://www.langchain.com/langsmith
url_docs: https://docs.smith.langchain.com/
url_repo: 
---

# LangSmith

## Pourquoi
**Plateforme d'observability LLM par LangChain** (l'éditeur). Tracing automatique pour LangChain / LangGraph, eval framework intégré, prompt hub, datasets. Très polished UX. Closed-source (cloud only, sauf self-host enterprise).

## Quand l'utiliser
- Stack [[LangChain]] / LangGraph → tracing automatique zéro config
- Tu veux UX/UI premium (un peu mieux léché que Langfuse)
- Évaluation rigoureuse de chains/agents
- Prompt Hub (versioning des prompts)
- Datasets curatés depuis prod traces

## Quand NE PAS l'utiliser
- Pas de LangChain → [[Langfuse]] ou [[Helicone]] (non-LangChain neutres)
- Self-host obligatoire → [[Langfuse]] (open MIT)
- Stack OpenInference / OTel — préférer Phoenix Arize
- Budget contraint — LangSmith devient cher en volume

## Pièges connus
- **Cloud only** (sauf Enterprise) — pas d'option Docker self-host hors deal entreprise
- **Vendor lock-in** : intégré profondément LangChain, sortir = re-instrumenter
- **Pricing** : tiers basés sur traces/mois, peut surprendre (passer Pro à Enterprise)
- **Tracing automatique** : élégant si tu utilises LangChain, manuel pour le reste (`@traceable`)
- **EU compliance** : check résidence data (US par défaut, EU possible)
- **Migration depuis** : datasets exportables, prompts moins, traces non-portables

## Liens
- [[Langfuse]] — alternative open-source
- [[LangChain]] / [[LangGraph]] — stack native
- [[Helicone]] — alternative proxy
- [[LLM observability]] (concept)
- Docs : https://docs.smith.langchain.com/
- Pricing : https://www.langchain.com/pricing-langsmith
