---
galaxie: wiki
nom: VC dimension
alias: [Vapnik-Chervonenkis dimension, VC dim, capacité]
type: concept
categorie: concept/learning-theory
sous_categories: [vc-dimension, capacity, shattering, generalization]
domaines: [ml-eng]
maturite: established
auteurs_cles: [Vapnik-Chervonenkis 1971]
lecture_min: 7
created: 2026-05-20
modified: 2026-05-20
tags: [concept, learning-theory, vc-dimension, capacity]
---

# VC dimension

## TL;DR

Mesure de la **capacité d'une classe d'hypothèses** $\mathcal{H}$ : le plus grand nombre de points qu'on peut **shattrer** (classifier de toutes les façons possibles) avec des hypothèses de $\mathcal{H}$. **Détermine théoriquement** la complexité d'échantillonnage : combien de données il faut pour apprendre avec une classe donnée. Beaucoup de bornes de généralisation classiques (Vapnik) reposent sur VC dim.

## Le problème

Quelle classe d'hypothèses choisir pour un problème ?
- **Trop simple** (faible VC dim) : sous-apprentissage
- **Trop riche** (haute VC dim) : sur-apprentissage, beaucoup de données nécessaires

VC dim formalise cette intuition de "capacité" / "complexité du modèle".

## L'idée

### Shattering

Une classe $\mathcal{H}$ **shatters** un ensemble de points $\{x_1, \dots, x_n\}$ si pour toute affectation de labels $(y_1, \dots, y_n) \in \{0, 1\}^n$, il existe $h \in \mathcal{H}$ qui classe correctement.

Autrement dit : $\mathcal{H}$ peut générer **toutes les $2^n$ étiquetages possibles** sur ces points.

### Définition VC dim

$$ \text{VC}(\mathcal{H}) = \max \{n : \exists \{x_1, \dots, x_n\} \text{ shatterable par } \mathcal{H}\} $$

Si on peut shatter pour tout $n$, $\text{VC} = \infty$.

### Exemples canoniques

| Classe $\mathcal{H}$ | VC dim |
|---|---|
| Constantes ($h \equiv 0$ ou $h \equiv 1$) | 1 |
| Seuils sur $\mathbb{R}$ : $h(x) = 1[x > t]$ | 1 |
| Intervalles sur $\mathbb{R}$ | 2 |
| Demi-plans (perceptron) en $\mathbb{R}^d$ | $d + 1$ |
| Rectangles axe-alignés en $\mathbb{R}^2$ | 4 |
| Polynômes de degré $\leq d$ sur $\mathbb{R}$ | $d + 1$ |
| Sinus $h(x) = \sin(\omega x)$ | $\infty$ |
| Réseaux de neurones | dépend taille (cf. ci-dessous) |

### Démonstration type : VC du perceptron

En $\mathbb{R}^d$, un perceptron est $h(x) = \text{sign}(w^\top x + b)$.

- **Montrer VC ≥ d+1** : trouver $d+1$ points shattérables (ex. simplex).
- **Montrer VC ≤ d+1** : prouver qu'on ne peut pas shatter $d+2$ points (théorème de Radon).

Donc $\text{VC}(\text{perceptron}_d) = d + 1$.

### VC dim des NN

Pour un NN à $W$ poids, VC dim grossièrement $O(W \log W)$ à $O(W^2)$ selon l'activation. Mais cette borne est **très lâche** pour les NN modernes :

- ResNet-152 : ~60M paramètres → VC dim énorme
- En pratique, généralise très bien malgré ça

→ La théorie classique VC **n'explique pas la généralisation des NN modernes**. Nouveau cadres : norm-based bounds, PAC-Bayes, double descent (cf. [[Bias-variance tradeoff]]).

### Borne de généralisation VC

Pour un échantillon de taille $n$, avec probabilité $\geq 1 - \delta$ :

$$ R(h) \leq \hat R(h) + \sqrt{\frac{\text{VC}(\mathcal{H}) (\log(2n/\text{VC}) + 1) + \log(4/\delta)}{n}} $$

avec $R$ risque vrai, $\hat R$ risque empirique. Plus VC est haute, plus la borne est large, plus on a besoin de données pour garantir la généralisation.

### Lien avec PAC learning

Une classe avec VC finie est **PAC-apprenable** (cf. [[PAC learning]]). Le théorème fondamental : $\mathcal{H}$ est apprenable ⇔ $\text{VC}(\mathcal{H}) < \infty$.

### Limites de VC

- **Très lâche** en pratique : surestime souvent la quantité de données nécessaire
- **Worst-case** : suppose le pire des datasets possibles
- **N'explique pas DL** : NN sur-paramétrés ont VC énorme mais généralisent quand même
- **Ne capture pas l'effet de l'optimization** : SGD biais implicite, important en pratique

Nouvelles bornes (PAC-Bayes, Rademacher, normes des poids) sont plus tight pour le DL.

## Quand c'est utile

- **Comprendre théoriquement** la généralisation des modèles classiques (perceptron, SVM, decision trees)
- **Choix de modèle** : avec peu de données, choisir une classe à VC dim basse
- **Bornes de complexité d'échantillonnage** : combien de données pour garantir une précision donnée
- **Justification théorique** de la régularisation : limiter la "capacité effective"

## Quand ça ne marche pas / pièges

- **Confusion VC dim avec nombre de paramètres** : pas la même chose. Une fonction sin(ωx) a 1 paramètre mais VC ∞.
- **Appliquer aux NN modernes** : bornes trop lâches pour être informatives
- **Calcul exact** : NP-hard en général. On a souvent des bornes inf/sup.
- **VC pour régression** : pas directement applicable. Variantes : pseudo-dimension, fat-shattering dim.
- **Croire qu'on peut "réduire VC"** par astuce sans changer la classe : impossible par définition. Réduire la capacité demande de changer $\mathcal{H}$.

## Code minimal

```python
# La VC dim n'est pas calculée empiriquement en pratique, mais on peut
# faire une visualisation pédagogique du shattering

import matplotlib.pyplot as plt
import numpy as np

# Demi-plans en 2D : VC dim = 3
# Montrons qu'on peut shatter 3 points
points = np.array([[0, 0], [1, 0], [0.5, 1]])  # 3 points non-alignés

labelings = [(0,0,0), (0,0,1), (0,1,0), (1,0,0), (0,1,1), (1,0,1), (1,1,0), (1,1,1)]

# Pour chaque labeling, il existe une droite qui sépare correctement
# (à montrer visuellement)

# VC dim ne peut pas être > 3 pour les demi-plans en 2D (Radon)
# Avec 4 points, il existe toujours un labeling impossible (ex : XOR)
xor_points = np.array([[0,0], [1,1], [0,1], [1,0]])
xor_labels = (0, 0, 1, 1)  # XOR — pas linéairement séparable
print("XOR sur 4 points : impossible à shatter par un demi-plan → VC ≤ 3")
```

## Pour aller plus loin

- Vapnik & Chervonenkis, *On the uniform convergence of relative frequencies of events to their probabilities* (1971) — paper fondateur
- Mohri, Rostamizadeh, Talwalkar, *Foundations of Machine Learning* (2e éd. 2018) — chap. 3
- Shalev-Shwartz & Ben-David, *Understanding Machine Learning* — chap. 6, gratuit en ligne
- Zhang et al., *Understanding deep learning requires rethinking generalization* (ICLR 2017) — montre les limites de VC pour NN
- **Liens internes** : [[PAC learning]], [[Rademacher complexity]], [[No Free Lunch theorem]], [[Bias-variance tradeoff]]
