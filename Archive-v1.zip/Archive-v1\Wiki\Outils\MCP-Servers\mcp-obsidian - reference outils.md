---
galaxie: wiki
nom: mcp-obsidian — référence outils
type: mcp-server-reference
parent: "[[mcp-obsidian]]"
categorie: skill/knowledge
sous_categories: [obsidian, mcp, reference]
created: 2026-05-19
modified: 2026-05-19
tags: [mcp, obsidian, reference]
---

# mcp-obsidian — référence des outils

> Sous-note attachée à [[mcp-obsidian]]. Quand utiliser quel outil MCP plutôt que les outils standard Claude Code (`Read`, `Write`, `Glob`, `Grep`).

## Quand préférer le MCP

| Tâche | Outil standard | Outil MCP préféré | Raison |
|---|---|---|---|
| Lire un fichier du vault | `Read` | `mcp__devbrain__read_file_content` | Le MCP respecte le frontmatter Obsidian, les properties typées, les wikilinks |
| Écrire un nouveau fichier | `Write` | `mcp__devbrain__create_file` | Création passe par l'API Obsidian → indexation immédiate, plugins informés |
| Patcher un fichier existant | `Edit` | `mcp__devbrain__patch_content` | Patch ciblé section/heading, préserve le reste, gère les transactions |
| Ajouter en fin de fichier | `Edit` (append) | `mcp__devbrain__append_to_file` | Append atomique |
| Lister un dossier | `Glob` ou `Bash ls` | `mcp__devbrain__list_files_in_dir` | Lit l'arbo via API Obsidian (cache cohérent) |
| Lister tout le vault | `Glob` recursif | `mcp__devbrain__list_files_in_vault` | Optimisé côté Obsidian |
| Recherche full-text | `Grep` | `mcp__devbrain__search_files` | Indexation Obsidian (plus rapide sur grand vault) |
| Métadonnées (mtime, taille) | `Bash stat` | `mcp__devbrain__get_file_metadata` | Renvoie aussi les liens Obsidian (backlinks, etc.) |

## Quand NE PAS utiliser le MCP

- **Repo Git pur**, hors d'un vault Obsidian → utilise les outils standard
- **Fichier binaire** (image, PDF) → le MCP texte ne sait pas faire, passe par `Read`
- **Obsidian fermé** → `mcp__devbrain__*` retourne une erreur, fallback sur les outils standard
- **Opérations git** (commit, push, status) → toujours `Bash git ...`, jamais MCP

## Convention DevBrain

Tous les SKILL.md qui touchent à `Wiki/`, `Services/`, `Bugs/`, `Patterns/`, `Rules/` ou `Inbox.md` **doivent préférer** les outils `mcp__devbrain__*` quand ils sont disponibles. Le fallback sur `Read/Write/Edit/Glob/Grep` est acceptable mais doit être documenté dans la section "Pré-requis vault" du SKILL.md.

Pour vérifier la disponibilité : `claude mcp list` doit montrer `devbrain ✓ Connected`. Si non, install ou démarrer Obsidian (cf. [[mcp-obsidian]]).

## Voir aussi

- [[mcp-obsidian]] (fiche principale)
- [[mcp-protocol]] (concept)
- [[INSTALL]] section 10 (install Claude Code → MCP)
