---
galaxie: wiki
nom: review
type: claude-code-skill
plateforme: claude-code
categorie: skill/code-quality
sous_categories: [pr-review, github, code-review]
auteur: Anthropic
source: claude-code natif
source_url: https://docs.claude.com/en/docs/claude-code
install_cmd: 
install_doc: 
licence: 
licence_type: proprietary
domaines: [data-eng, mlops, ml-eng, ai-eng]
score: 
status: discovered
mes_projets: []
created: 2026-05-19
modified: 2026-05-19
tags: [skill, claude-code, review, github]
---

# review

## Pourquoi

Skill **bundled** pour **reviewer une PR GitHub**. L'agent récupère le diff, analyse les changements, et produit une revue structurée (bugs potentiels, code smells, suggestions, points à confirmer avec l'auteur).

Tu n'es plus le seul à reviewer tes propres PRs ou celles de ton équipe — l'agent fait un premier passage.

## Quand l'utiliser

- Avant de merger une PR (à toi ou à un collègue)
- Audit rapide d'un code que tu hérites
- Apprendre : voir ce qu'un reviewer aguerri commenterait sur ton code

## Quand NE PAS l'utiliser

- PR < 20 lignes → un humain ira plus vite
- PR purement de doc / typos → bruit
- PR très architecturale → l'agent rate parfois le "pourquoi" sans le contexte produit complet

## Comment l'installer

Natif Claude Code, déclenchable via `/review <numéro_PR>` ou `/review <url_PR>`.

Pré-requis : `gh` CLI authentifié.

## Exemples d'usage

```
> /review 142
> /review https://github.com/floSa/projet/pull/142
> review la PR ci-dessus et propose des tests manquants
```

## Pièges connus

- L'agent ne voit pas les conversations attachées à la PR — uniquement le diff
- Si la PR est multi-commits avec rebase complexe, l'analyse peut être à côté de la plaque

## Liens

- Doc Claude Code : https://docs.claude.com/en/docs/claude-code
