---
galaxie: wiki
nom: Agent evaluation
alias: [AgentBench, GAIA, SWE-Bench, tau-bench, BFCL, agent eval]
type: concept
categorie: concept/agents
sous_categories: [agent-eval, benchmarks, agents, llm]
domaines: [ai-eng]
maturite: emerging
auteurs_cles: []
lecture_min: 6
created: 2026-05-20
modified: 2026-05-20
tags: [concept, agents, eval, benchmarks]
---

# Agent evaluation

## TL;DR

Évaluer un agent LLM est **plus dur que évaluer un LLM chat** : non seulement la réponse finale matter, mais aussi la **trajectoire**, les **tool calls**, le **cost**, le **nb de steps**. Métriques : **success rate**, **steps to solve**, **cost per task**, **tool-call accuracy**, **trajectory faithfulness**, **process vs outcome eval**. Benchmarks : **AgentBench**, **GAIA**, **WebArena**, **SWE-Bench** (Verified), **τ-bench** (tool use), **BFCL** (function calling), **OSWorld** (computer use), **MLE-Bench** (data science). Standard prod : **eval set custom** + tracking en prod (traces, success).

## Le problème

Évaluer un agent demande :
- **Multi-step success** : pas juste 1 turn
- **Tools usage correct** : bons appels avec bons args
- **Cost / efficiency** : 100 steps pour un task simple = mauvais
- **Trajectory quality** : path optimal ?
- **Robustness** : sur edge cases, fail gracefully ?

→ Single metric ne suffit pas.

## L'idée

### Métriques

#### Success rate

% de tasks où l'agent **arrive au goal**.

- Définir clearly le critère de success
- Binary or graded
- Doit fitter la business value

#### Steps to solve

Combien d'**iterations** / tool calls pour arriver. Lower better (à success équivalent).

- "Efficient agent" = fewer steps
- Important pour latency et cost

#### Cost per task

LLM API cost cumulé. Tracker via tokens (input + output) × pricing.

- Critical en production
- Cost ≠ qualité linéaire

#### Tool-call accuracy

% de tool calls **correctement formés** :
- Bon tool name ?
- Args bons (type, valeur) ?
- Sequence correcte ?

Benchmark **BFCL** dédié à ça.

#### Argument correctness

Plus fine : pour chaque tool call, les args sont-ils corrects vs ground truth ?

#### Trajectory eval

Pas que le résultat, mais le **chemin** :
- Steps redundants ?
- Tools mal choisis ?
- Logical flow ?

LLM-as-judge sur trajectories.

#### Process vs outcome eval

- **Outcome** : just check final answer (e.g. unit tests pass)
- **Process** : evaluate chaque step

Combiner pour robustness.

### Benchmarks

#### AgentBench (Liu 2023)

8 environments distincts : OS interaction, web shopping, knowledge graph, database, etc. Diversité.

#### GAIA (Mialon 2023)

466 questions multi-step nécessitant tools. Catégories : research, multimodal, reasoning. **General Assistant Intelligence**.

#### WebArena / VisualWebArena (Zhou 2024)

Web tasks réalistes : shopping, forum, social. Réplique d'apps web.

#### WebShop

E-commerce search & purchase. Plus simple que WebArena.

#### Mind2Web

3500+ web tasks across 137 websites.

#### OSWorld (Xie 2024)

**Computer use** : tasks sur OS (Linux, macOS, Windows). Open multi-app tasks.

#### WindowsAgentArena

Specifically Windows-focused.

#### SWE-Bench (Jimenez 2023)

**Software engineering** : 2294 real GitHub issues à fixer.

- **SWE-Bench Lite** : 300 issues, plus simples
- **SWE-Bench Verified** : 500 issues vérifiées humainement (cleaner)
- **SWE-Bench Multimodal** : avec UI screenshots
- Standard pour code agents (Claude Code, Devin)

#### τ-bench (Tau-bench, Yao 2024)

Tool use **conversational** : agent + user simulateur + tools. Realistic agent-user dynamic.

#### BFCL (Berkeley Function Calling Leaderboard)

Function calling pure : simple, parallel, multiple, multi-turn. v1, v2, v3.

#### ToolBench

16K+ tool use scenarios, 3000+ APIs réels.

#### API-Bank

Tool use + memory + planning.

#### MLE-Bench (OpenAI 2024)

Kaggle-style ML engineering tasks. Test if agent peut faire data science.

#### TheAgentCompany

White-collar work simulator (HR, finance, engineering tasks).

#### Web-Bench

Browsing tasks at scale.

### Custom eval pour ton app

Benchmarks publics ne reflètent pas ton use case. Build **custom eval set** :

1. **Collecter prod traces** réels
2. **Annoter** : success / fail
3. **Catégoriser** : type of task, difficulty
4. **Regression suite** : run avant chaque deploy
5. **CI gate** : fail if success drops

### Évaluer la trajectoire

LLM-as-judge sur trajectory :

```python
prompt = f"""
Task: {task}
Agent trajectory:
{trajectory}

Evaluate:
- Did it solve the task? (success/partial/fail)
- Was the approach efficient? (1-5)
- Were tool calls appropriate? (1-5)
- Any redundant steps?
- Final answer quality? (1-5)

Output JSON.
"""
```

### Process Reward Models (PRMs)

Models entraînés à scorer **chaque step** :
- Reward shape pour RL
- Identifier où l'agent fail

Cf. reasoning models, [[RLHF and DPO]].

### Failure mode analysis

Identifier les **patterns d'échec** :
- Infinite loops
- Tool hallucinations
- Wrong tool selection
- Args malformed
- Halting too early
- Hallucinated final answer

Tagger les fails → ciblerprompts / training.

### A/B testing en prod

- 50/50 split entre versions agent
- Measure user satisfaction, completion rate
- Eval bias minimisé vs benchmarks

### Observability stack

Critical pour eval continue :
- **Langfuse, LangSmith, Helicone, Phoenix** : traces complets
- **Track** : tool calls, costs, latencies, errors
- **Sample** : LLM judge sur sample des prod traces
- **Alert** : si success rate chute

### Best practices

1. **Custom eval set** + benchmarks publics
2. **Multi-metric** : success + cost + steps + tool acc
3. **Regression suite** in CI
4. **Trajectory eval** + outcome eval
5. **Human eval sample** : périodique
6. **Failure tagging** : categorize errors
7. **Compare vs baseline** : single-turn LLM, simpler agent
8. **Cost monitoring** : per task, per user
9. **Trace 100% en dev, sample en prod**
10. **Iterate** : eval set evolves with usage

## Quand c'est utile

- **Avant deployment** : qualité gate
- **Continuous improvement** : iterate on eval
- **Choosing agent framework** : LangGraph vs CrewAI vs AutoGen
- **Choosing model** : Claude vs GPT-4 vs open-source
- **Production monitoring** : detect regressions
- **Compliance / safety** : audit trail
- **Research** : compare new techniques

## Quand ça ne marche pas / pièges

- **Benchmark gaming** : optimize pour bench, prod différent
- **Single metric blindness** : success ↑ mais cost ↑↑↑
- **Eval set leakage** : agent vu eval pendant dev → fake good
- **Process vs outcome conflicts** : process good, outcome bad ?
- **LLM-as-judge biases** : same family judge → bias
- **Cost in eval** : eval set 1K samples × 10 steps = $$$ par run
- **Trajectory eval expensive** : LLM judge sur chaque step costly
- **Hallucinated tools succès** : agent fait n'importe quoi mais "succeed"
- **No real users** : public benchmarks ≠ vrai users
- **Multimodal eval** : vision agents harder
- **Stochasticity** : T>0 → variance, need multiple runs
- **Reasoning bench plateaus** : modèles approchent ceiling, harder differentiate

## Code minimal

```python
# 1. Custom eval set + runner
class AgentEval:
    def __init__(self, agent, eval_set):
        self.agent = agent
        self.eval_set = eval_set  # list of (task, expected, criteria)
    
    def run(self):
        results = []
        for task, expected, criteria in self.eval_set:
            start_time = time.time()
            trace = self.agent.run(task)
            latency = time.time() - start_time
            
            results.append({
                "task": task,
                "trace": trace,
                "final_answer": trace.final_answer,
                "n_steps": len(trace.steps),
                "n_tool_calls": sum(1 for s in trace.steps if s.tool_call),
                "cost_usd": trace.total_cost,
                "latency_s": latency,
                "success": criteria(trace.final_answer, expected),
            })
        return results

# 2. Run SWE-Bench
# pip install swebench
# from swebench import run_benchmark
# results = run_benchmark(model=agent, dataset="swe-bench-verified")

# 3. Trajectory eval avec LLM judge
def trajectory_eval(task, trajectory):
    prompt = f"""Evaluate this agent trajectory:

Task: {task}

Trajectory:
{trajectory}

Output JSON:
{{
  "success": true/false,
  "efficiency": 1-5,
  "tool_use_quality": 1-5,
  "redundant_steps": <count>,
  "errors_made": <count>,
  "final_quality": 1-5
}}"""
    
    response = client.messages.create(
        model="claude-3-7-sonnet-latest",
        max_tokens=300,
        messages=[{"role": "user", "content": prompt}]
    )
    return json.loads(response.content[0].text)

# 4. BFCL-style function calling eval
def eval_tool_call(predicted, expected):
    if predicted["name"] != expected["name"]:
        return {"correct": False, "reason": "wrong tool"}
    # Check args
    for k, v in expected["args"].items():
        if k not in predicted["args"]:
            return {"correct": False, "reason": f"missing arg {k}"}
        if predicted["args"][k] != v:
            return {"correct": False, "reason": f"wrong value for {k}"}
    return {"correct": True}

# 5. SWE-Bench Verified (passing unit tests)
def swe_bench_eval(agent, issue, gold_patch):
    agent_patch = agent.solve_issue(issue)
    # Apply patch, run tests
    success = run_tests_with_patch(agent_patch, issue.repo)
    return {"success": success, "patch_match": agent_patch == gold_patch}

# 6. τ-bench style (simulated user)
def tau_bench_eval(agent, scenario):
    user_sim = simulate_user(scenario)
    conversation = []
    for turn in range(MAX_TURNS):
        user_msg = user_sim.next_message(conversation)
        if user_sim.is_done():
            break
        agent_response = agent.respond(user_msg, tools=scenario.tools)
        conversation.append((user_msg, agent_response))
    
    return user_sim.evaluate(conversation)

# 7. Production sampling for eval
import random

def sample_for_eval(traces, sample_rate=0.01):
    sampled = random.sample(traces, int(len(traces) * sample_rate))
    evals = []
    for trace in sampled:
        eval_result = llm_judge(trace)
        evals.append(eval_result)
    return aggregate(evals)

# 8. Langfuse / LangSmith tracking (production)
# from langfuse.decorators import observe
# 
# @observe(name="my_agent")
# def my_agent(task):
#     # All LLM calls traced
#     ...

# 9. Compare baselines
def compare_agents(agent_a, agent_b, eval_set):
    a_results = AgentEval(agent_a, eval_set).run()
    b_results = AgentEval(agent_b, eval_set).run()
    
    a_success = sum(r["success"] for r in a_results) / len(a_results)
    b_success = sum(r["success"] for r in b_results) / len(b_results)
    
    a_cost = sum(r["cost_usd"] for r in a_results) / len(a_results)
    b_cost = sum(r["cost_usd"] for r in b_results) / len(b_results)
    
    print(f"A: success={a_success:.2%}, cost=${a_cost:.3f}")
    print(f"B: success={b_success:.2%}, cost=${b_cost:.3f}")
```

## Pour aller plus loin

- Liu et al., *AgentBench: Evaluating LLMs as Agents* (ICLR 2024)
- Mialon et al., *GAIA: a benchmark for General AI Assistants* (ICLR 2024)
- Zhou et al., *WebArena: A Realistic Web Environment for Building Autonomous Agents* (ICLR 2024)
- Jimenez et al., *SWE-bench: Can Language Models Resolve Real-World GitHub Issues?* (ICLR 2024)
- Yao et al., *τ-bench: A Benchmark for Tool-Agent-User Interaction in Real-World Domains* (2024)
- Berkeley, *BFCL Leaderboard*
- Xie et al., *OSWorld: Benchmarking Multimodal Agents for Open-Ended Tasks in Real Computer Environments* (NeurIPS 2024)
- *Langfuse*, *LangSmith*, *Helicone*, *Arize Phoenix* — observability platforms
- **Liens internes** : [[Agent patterns]], [[Tool use patterns]], [[Multi-agent systems]], [[LLM eval metrics]]
