---
galaxie: dev
nom: statsforecast
alias: [nixtla-statsforecast]
categorie: ml/framework
sous_categories: [forecasting, time-series, autoarima, ets, theta]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: ["[[Prophet]]", "[[statsmodels]]", "[[darts]]", "[[neuralforecast]]"]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, time-series, forecasting, nixtla]
url_officiel: https://nixtlaverse.nixtla.io/statsforecast/
url_docs: https://nixtlaverse.nixtla.io/statsforecast/
url_repo: https://github.com/Nixtla/statsforecast
---

# statsforecast

## Pourquoi

Bibliothèque **forecasting statistique classique** de Nixtla, écrite en Python avec **JIT compilation Numba** → 10 à 100× plus rapide que `statsmodels` pour entraîner ARIMA / ETS / Theta sur plusieurs séries. API unifiée sur `pandas`/`polars`, gère **plusieurs séries en parallèle** nativement.

C'est l'alternative moderne aux ARIMA de `statsmodels` quand tu as **beaucoup de séries** à forecaster (SKU par produit, métriques par capteur, etc.).

## Quand l'utiliser

- Plusieurs centaines/milliers de séries à modéliser en lot
- Benchmark fort : AutoARIMA, AutoETS, Theta avec sélection automatique de modèle
- Cross-validation walk-forward intégrée (`.cross_validation()`)
- Tu connais ARIMA/ETS et veux la performance brute en Python
- Production : pipeline qui ré-entraîne souvent (CI quotidienne) → vitesse compte

## Quand NE PAS l'utiliser

- Une seule série, modélisation soigneuse avec diagnostics → préfère [[statsmodels]]
- Tu veux des composantes interprétables (trend / seasonality décomposées) → [[Prophet]]
- Deep learning / transformers TS → [[neuralforecast]]
- Tu n'as pas envie d'apprendre ARIMA → [[Prophet]] est plus indulgent

## Pièges connus

- **Format long obligatoire** : `unique_id`, `ds`, `y`. Pas le format wide qu'on a souvent en pandas
- AutoARIMA peut produire un modèle qui semble OK mais qui n'a pas géré la saisonnalité (vérifier `summary()`)
- Sur les très petites séries (<30 obs), peut produire des modèles instables
- API en évolution (jeune projet) — pin la version dans `pyproject.toml`

## Liens

- Doc officielle : https://nixtlaverse.nixtla.io/statsforecast/
- Repo : https://github.com/Nixtla/statsforecast
- Concepts liés : [[Stationarity]], [[Autocorrelation]], [[Walk-forward CV]]
- Suite Nixtla : [[neuralforecast]] (DL), `mlforecast` (gradient boosting), `hierarchicalforecast` (réconciliation)
- Alternatives : [[Prophet]], [[statsmodels]], [[darts]]
