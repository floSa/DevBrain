---
galaxie: wiki
nom: Bootstrap
alias: [bootstrap resampling, bootstrap CI, Efron bootstrap]
type: concept
categorie: concept/stats
sous_categories: [bootstrap, resampling, confidence-interval, non-parametric, simulation]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Efron 1979, Davison-Hinkley 1997]
lecture_min: 8
created: 2026-05-19
modified: 2026-05-19
tags: [concept, stats, bootstrap, resampling]
---

# Bootstrap

## TL;DR

Méthode universelle pour estimer **n'importe quelle statistique et son incertitude** sans hypothèse paramétrique. Idée : rééchantillonner **avec remise** $B$ fois dans tes données originales, calculer la statistique à chaque fois, et lire la distribution. Permet **intervalles de confiance**, **tests d'hypothèse**, et estimation de **biais** sur statistiques complexes (médiane, percentile, corrélation, ratio…).

## Le problème

Tu veux un intervalle de confiance pour :
- La **médiane** d'une distribution (pas de formule fermée)
- La **corrélation de Spearman** (formule complexe)
- Un **ratio de moyennes** (loi inconnue)
- La performance d'un modèle ML (AUC, accuracy)
- Une statistique custom métier

Les méthodes classiques (intervalle gaussien $\bar x \pm 1.96 \cdot SE$) supposent normalité et reposent sur des formules spécifiques. **Bootstrap** marche pour toute statistique.

## L'idée

### Procédure de base

Soit un échantillon $X = (x_1, \dots, x_n)$ et une statistique $T(X)$.

1. Tirer un **bootstrap sample** $X^*$ : $n$ valeurs tirées **avec remise** depuis $X$
2. Calculer $T(X^*)$
3. Répéter $B$ fois ($B = 1000$ à $10\,000$ selon précision)
4. La **distribution empirique des $\{T(X_b^*)\}_b$ approxime la distribution d'échantillonnage de $T$**

### Intervalle de confiance — méthode percentile

IC à 95% : les percentiles 2.5% et 97.5% de la distribution bootstrap :

$$ \text{IC}_{95\%} = [Q_{0.025}(T^*), Q_{0.975}(T^*)] $$

Simple, intuitive. Peut être biaisée si la distribution est asymétrique.

### Intervalle BCa (bias-corrected and accelerated)

Variante plus sophistiquée qui **corrige le biais** et tient compte de l'**accélération** (skewness). Meilleur sur petits échantillons et distributions asymétriques. Implémenté dans `scipy.stats.bootstrap(..., method='BCa')`.

### Test d'hypothèse via permutation

Variante : tirer **sans remise** en mélangeant les labels pour tester l'effet d'un groupe. C'est le **permutation test** :

```
H_0 : aucune différence entre groupes A et B
Procédure :
  1. Calculer la statistique d'origine T_obs (ex. diff de moyennes)
  2. Mélanger aléatoirement les labels A/B
  3. Recalculer T*
  4. Répéter B fois
  5. p-value = P(|T*| >= |T_obs|) sous permutation
```

### Bootstrap pour ML

Mesurer l'**incertitude d'une métrique** (AUC, accuracy, MAPE) :

```python
B = 1000
scores = []
for _ in range(B):
    idx = np.random.choice(len(y_true), size=len(y_true), replace=True)
    scores.append(metric(y_true[idx], y_pred[idx]))

ic = np.percentile(scores, [2.5, 97.5])
```

Permet de comparer 2 modèles : si leurs IC ne se chevauchent pas, différence significative.

### Bagging — application en ML

[[Ensembling]] par bagging utilise le bootstrap : chaque arbre d'un Random Forest est entraîné sur un bootstrap. Out-of-bag (OOB) error utilise les ~37% de données non-tirées comme test naturel.

### Conditions de validité

- **Indépendance** des observations originales
- **Échantillon représentatif** de la population
- **Statistique régulière** (continue, asymptotiquement normale) — pour les extrêmes (max, min) le bootstrap classique échoue, utiliser block bootstrap

Pour les **séries temporelles** : pas le bootstrap classique (viole l'indépendance). Utiliser **block bootstrap** (rééchantillonner des blocs continus).

## Quand c'est utile

- IC pour statistiques sans loi connue (médiane, ratio, AUC, corrélation)
- Pas de normalité, échantillon petit
- Test d'hypothèse robuste sur données non-paramétriques
- Quantifier l'incertitude d'une métrique ML
- [[Cross-validation]] OOB
- Quand tu n'as pas envie de chercher la bonne formule analytique — bootstrap = solution générique

## Quand ça ne marche pas / pièges

- **Séries temporelles** ou données autocorrélées → bootstrap classique invalide, utiliser block bootstrap
- **Petits échantillons** (n < 20) → le bootstrap reflète le déséquilibre de l'échantillon
- **Statistiques extrêmes** (max, min, percentiles très bas/hauts) → bootstrap sous-estime la variance
- **Données très skewed** → préférer BCa à la méthode percentile
- **B trop petit** ($B < 1000$) → IC bruité. Pour publication, $B \geq 10\,000$.
- **Coût computationnel** sur modèles ML chers → bootstrap directement sur prédictions, pas sur le ré-entraînement
- **Confusion bootstrap vs CV** : le bootstrap estime l'incertitude **d'une statistique**, la CV estime la **performance d'un modèle** sur des données non vues. Pas le même objectif.

## Code minimal

```python
import numpy as np
from scipy import stats

# IC bootstrap pour la médiane
data = np.array([...])
res = stats.bootstrap((data,), np.median, confidence_level=0.95, 
                      n_resamples=10000, method='BCa', random_state=0)
print(f"Médiane = {np.median(data):.3f}")
print(f"IC 95% = [{res.confidence_interval.low:.3f}, "
      f"{res.confidence_interval.high:.3f}]")

# Test de permutation (différence de moyennes)
res = stats.permutation_test(
    (group_a, group_b), 
    statistic=lambda a, b: a.mean() - b.mean(),
    n_resamples=10000,
    random_state=0,
)
print(f"p-value (permutation) = {res.pvalue:.4f}")

# Bootstrap manuel pour AUC
from sklearn.metrics import roc_auc_score
B = 1000
aucs = []
for _ in range(B):
    idx = np.random.choice(len(y_true), size=len(y_true), replace=True)
    aucs.append(roc_auc_score(y_true[idx], y_score[idx]))
ic = np.percentile(aucs, [2.5, 97.5])
print(f"AUC = {roc_auc_score(y_true, y_score):.3f}, IC95% = {ic}")
```

## Implémentations concrètes

- `scipy.stats.bootstrap` (depuis 1.7) — la base, méthodes percentile/basic/BCa
- `scipy.stats.permutation_test`
- `arch.bootstrap` — pour séries temporelles (block, stationary, circular)
- R : `boot` package (Davison & Hinkley)

## Pour aller plus loin

- Efron, *Bootstrap methods: another look at the jackknife* (1979) — paper fondateur
- Davison & Hinkley, *Bootstrap Methods and Their Application* (1997) — bible
- Hesterberg, *What teachers should know about the bootstrap* (2015) — pédagogique
- **Liens internes** : [[Hypothesis testing]], [[Confidence intervals]], [[Cross-validation]], [[Ensembling]] (bagging utilise bootstrap)
