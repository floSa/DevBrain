---
galaxie: dev
nom: statsmodels
alias: [statsmodels-py]
categorie: tooling/stats
sous_categories: [regression, glm, mixed-models, time-series, hypothesis-tests, statistics]
licence: BSD-3-Clause
licence_type: open-source
hosted: self
maturite: production
langage: Python
clients_officiels: [python]
plateforme: [linux, macos, windows]
score: 
mes_projets: []
alternatives: [scipy.stats, "[[prince]]", "[[statsforecast]]", PyMC, R-base, R-tidymodels]
remplace: []
remplace_par: []
created: 2026-05-19
modified: 2026-05-19
status: actif
tags: [service, stats, regression, time-series, python]
url_officiel: https://www.statsmodels.org/
url_docs: https://www.statsmodels.org/stable/
url_repo: https://github.com/statsmodels/statsmodels
---

# statsmodels

## Pourquoi

La bibliothèque Python de référence pour la **statistique classique** : régressions (OLS, GLM, mixed models, robust, quantile), **tests d'hypothèse** (t, χ², ANOVA, Ljung-Box, ADF, KPSS, Granger), **séries temporelles** (ARIMA, SARIMA, VAR, ETS, filtres Kalman). C'est ce qu'on prend quand on veut du R-quality stats en Python, pas du black-box ML.

Versus scikit-learn : statsmodels expose **les diagnostics statistiques complets** (p-values, intervalles de confiance, AIC/BIC, résidus, hétéroscédasticité). scikit-learn ne les fournit pas.

## Quand l'utiliser

- Régression linéaire **avec inférence** (p-values, IC sur les coefs)
- GLM (Poisson, Binomial, Negative Binomial, Gamma) avec interprétation
- Mixed effects models (mesures répétées, données hiérarchiques)
- Diagnostic d'une série temporelle ([[Stationarity]], [[Autocorrelation]])
- Modèle ARIMA / SARIMA / ETS classique
- Tests statistiques avant de passer à ML (normalité, homoscédasticité, indépendance)
- Tu viens de R et tu veux la même rigueur en Python

## Quand NE PAS l'utiliser

- Prédiction pure sans besoin d'interprétation → scikit-learn, XGBoost, [[Polars]]+modèles ML
- Forecasting moderne batch ultra-rapide → [[statsforecast]] (Nixtla, 10-100× plus rapide pour ARIMA)
- Deep learning sur TS → [[neuralforecast]] ou framework DL générique
- Inférence bayésienne → PyMC

## Pièges connus

- **API formula** (`ols('y ~ x1 + x2', data=df)`) vs **API matricielle** : choisir une et s'y tenir, mélanger crée des confusions
- Performances ARIMA moyennes vs `statsforecast` — pour des entraînements en boucle, considérer l'alternative
- `summary()` est très verbeux mais c'est la sortie de référence — apprends à le lire, ne le skip pas
- Les **modèles mixed effects** sont moins stables que `lme4` en R, vérifier la convergence

## Liens

- Doc officielle : https://www.statsmodels.org/stable/
- Repo : https://github.com/statsmodels/statsmodels
- Concepts liés : [[Stationarity]], [[Autocorrelation]], [[Walk-forward CV]]
- Alternatives forecasting plus rapides : [[statsforecast]], [[darts]]
