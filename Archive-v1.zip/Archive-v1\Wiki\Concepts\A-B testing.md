---
galaxie: wiki
nom: A/B testing
alias: [A/B test, AB testing, randomized experiment, split test, RCT]
type: concept
categorie: concept/statistics
sous_categories: [ab-test, experimentation, causal, randomized]
domaines: [data-science, ml-eng]
maturite: established
auteurs_cles: [Fisher, Kohavi, Tang, Xu]
lecture_min: 8
created: 2026-05-20
modified: 2026-05-20
tags: [concept, statistics, ab-test, experimentation]
---

# A/B testing

## TL;DR

**Expérimentation randomisée contrôlée** appliquée à un produit/site/feature : on tire au sort qui voit A, qui voit B, et on compare une métrique. Permet d'établir une **causalité** (et pas juste une corrélation). Standard chez Google, Meta, Netflix, Amazon — toute décision produit est validée par A/B test. Outils : Optimizely, Statsig, in-house. Pièges majeurs : **peeking**, **multiple testing**, **biais de sélection**, **Simpson's paradox**.

## Le problème

On veut savoir : "Si on déploie la feature X, la métrique Y bouge-t-elle ?" Une analyse rétrospective sur historique est biaisée (effets temporels, segmentation, confondeurs). L'A/B test résout en **randomisant**.

## L'idée

### Cadre causal

- **Treatment** : feature exposée à la variante (B)
- **Control** : version de référence (A)
- **Randomisation** : assignment au hasard (user-level le plus souvent)
- **Métrique primaire** : la métrique que la feature est censée bouger (e.g. CTR, conversion, revenue)
- **Métriques de garde** : ne doivent pas régresser (e.g. latence, churn)

Sous randomisation : différence de moyenne entre groupes = **effet causal moyen (ATE)**.

### Statistical test classique

Hypothèse nulle $H_0$ : $\mu_A = \mu_B$.

Statistique : **Welch t-test** ou **z-test sur proportions** :

$$ z = \frac{\bar Y_B - \bar Y_A}{\sqrt{\text{Var}(\bar Y_B) + \text{Var}(\bar Y_A)}} $$

p-value < 0.05 → effet significatif. (Voir [[Hypothesis testing]] pour les pièges.)

### Sample size / Power

Question cruciale : **combien d'utilisateurs faut-il** ? Dépend de :
- **MDE** (Minimum Detectable Effect) : effet minimum qu'on veut détecter
- **α** (false positive rate) : typiquement 0.05
- **β** (false negative rate) : typiquement 0.20 → power = 80%
- **Variance** de la métrique

Formule approximative :

$$ n \approx \frac{16 \sigma^2}{\text{MDE}^2} \text{ par groupe (pour } \alpha=0.05, \text{power}=80\%) $$

Plus la métrique est volatile, plus il faut de monde. Pour une métrique de conversion à 5% et un lift relatif de 5% détecté : ~31 000 users par groupe.

### Stat sig vs pratique

- **Effet stat sig pas forcément pertinent** : avec $n$ assez grand, on détecte des effets minuscules
- **Effet pratique** : à comparer à un seuil business (e.g. "lift > 2%")
- **Pas stat sig pas forcément null effect** : underpowered

Toujours regarder **taille d'effet + IC**, pas juste la p-value.

### Variance reduction

Réduire la variance = power équivalent avec moins de users. Techniques :

#### CUPED (Controlled Pre-Experiment Data)

Microsoft (Deng et al. 2013). Utiliser une variable **pré-expérience** corrélée à la métrique (e.g. CTR baseline 7 jours avant) :

$$ Y'_i = Y_i - \theta (X_i - \bar X) $$

avec $\theta = \text{Cov}(Y, X) / \text{Var}(X)$. Réduction de variance ≈ $1 - \rho^2$. Standard en industrie.

#### Stratification

Diviser users en strates (e.g. country, device) et randomiser dans chaque. Réduit variance.

#### Regression adjustment

Ajouter covariables au modèle linéaire (toujours sous randomisation, valide).

### Sequential testing & peeking

**Peeking** = regarder pendant le test et arrêter quand stat sig. Inflate l'$\alpha$ effectif. **Inacceptable** avec frequentist classique.

Solutions :
- **Sequential testing** : Wald, MSPRT, group sequential designs (O'Brien-Fleming)
- **Always Valid Inference** (Optimizely, Johari et al.) : p-value valides à n'importe quel moment
- **Bayesian** : probability of being best, naturellement séquentiel

### Bayesian A/B testing

Modèle bayésien direct :
- Prior sur chaque taux $p_A, p_B$ (e.g. Beta uniforme)
- Likelihood Binomiale
- Posterior : Beta($\alpha + s, \beta + n - s$)

Sortie : **probabilité que B > A** $= P(p_B > p_A | D)$, calculée par échantillonnage.

Avantages :
- Interprétation directe ("80% de chances que B gagne")
- Peut être stoppé n'importe quand
- Intègre naturellement les priors (boucle d'apprentissage)

### Multiple testing

Tester plusieurs métriques ou variantes → inflate des faux positifs. Voir [[Multiple testing correction|Multiple testing]].
- Bonferroni (conservateur)
- Benjamini-Hochberg (FDR)
- Pré-spécifier la métrique primaire

### Heterogeneous Treatment Effects (HTE)

L'effet moyen cache souvent des **effets hétérogènes** par segment :
- Effet positif pour mobile, négatif pour desktop → moyenne = 0
- Outils : Causal Forests, X-learner, S-learner (uplift modeling)

Précieux mais multiples testing + reproductibilité difficiles.

### Pièges typiques

#### Sample Ratio Mismatch (SRM)

Si on s'attend à 50/50 mais on a 48/52 avec p-value Chi² < 0.001 → SRM, **STOP**. Indique un bug d'instrumentation (filtrage différent entre variants). Test invalide.

#### Novelty effect

Users réagissent à la nouveauté (positif ou négatif) puis l'effet décline. Laisser tourner suffisamment longtemps (au moins 1-2 semaines).

#### Day-of-week / seasonality

Lancer un test sur 1 jour → biaisé par effet weekday/weekend. Minimum 1 semaine entière.

#### Interference / network effects

Marketplaces, réseaux sociaux : action de A affecte B (e.g. Uber : surge pricing). Randomisation au niveau user invalide. Solutions : cluster randomization, switchback experiments.

#### Long-term effect divergent

Effet court-terme positif, long-terme négatif (e.g. clickbait → engagement → churn). Holdout long pour vérifier.

#### Simpson's paradox

Agrégat dit A gagne, par segment B gagne dans chaque. Cause : asymétrie de population entre segments × effets hétérogènes.

#### p-value hacking / metric hacking

Tester N métriques, garder celle qui sort. Pré-spécifier métriques primaire/secondaires.

### Recap : checklist d'un bon A/B test

- [ ] Hypothèse claire formulée avant
- [ ] Métrique primaire pré-spécifiée
- [ ] Sample size calculé (MDE + power)
- [ ] Randomisation au bon niveau (user, session, cluster)
- [ ] Durée minimale (>= 1 semaine entière)
- [ ] SRM check
- [ ] AA test ou backtest pour valider la pipeline
- [ ] CUPED ou stratification pour variance reduction
- [ ] Pas de peeking sans correction
- [ ] Analyse de segments + HTE (mais marquer comme exploratoire)
- [ ] Posterior predictive ou monitoring post-launch

## Quand c'est utile

- **Tout changement produit** : UI, copy, algorithm, prix, recommandations
- **Décisions data-driven** : remplacer débats d'opinion par données
- **Mesurer l'effet causal** : pas une corrélation observable
- **Itération rapide** : roll out + measure + decide
- **Pricing experiments** : test de prix
- **ML model rollout** : A/B test sur nouveau modèle vs prod

## Quand ça ne marche pas / pièges

- **Impossible de randomiser** : utiliser quasi-experimental (DiD, RDD, IV)
- **Effets de réseau** : invalide standard A/B. Cluster/geo randomization.
- **Long-term effects** : difficile à mesurer en quelques semaines
- **Population trop hétérogène** : effet dilué. Segmenter ou stratifier.
- **Faible trafic** : tests prennent des mois. Bayes ou bandits.
- **Métrique floue** : difficile à mesurer (e.g. satisfaction). Définir proxies.
- **Cold start / nouveauté** : 1-2 semaines pour stabiliser
- **Conflits de variantes** : plusieurs tests simultanés non orthogonalisés
- **Interaction entre tests** : un test affecte le résultat d'un autre

## Code minimal

```python
import numpy as np
from scipy import stats
import statsmodels.api as sm

# A/B test fréquentiste classique : conversion rate
n_A, n_B = 10000, 10000
conversions_A, conversions_B = 500, 550
p_A, p_B = conversions_A / n_A, conversions_B / n_B

# Z-test sur proportions
z, p_value = sm.stats.proportions_ztest([conversions_A, conversions_B], [n_A, n_B])
print(f"Lift relatif: {(p_B - p_A) / p_A * 100:.1f}%")
print(f"p-value: {p_value:.4f}")

# IC à 95% sur la différence
se_diff = np.sqrt(p_A * (1-p_A)/n_A + p_B * (1-p_B)/n_B)
diff = p_B - p_A
print(f"Diff: {diff:+.4f} [95% CI: {diff - 1.96*se_diff:+.4f}, {diff + 1.96*se_diff:+.4f}]")

# Sample size requis pour MDE
from statsmodels.stats.power import NormalIndPower
analysis = NormalIndPower()
effect_size = 0.05 / np.sqrt(0.05 * 0.95)  # Cohen's h approximation
n_needed = analysis.solve_power(effect_size=effect_size, alpha=0.05, power=0.8)
print(f"n par groupe nécessaire: {int(n_needed)}")

# Bayesian A/B test (Beta-Binomial)
n_samples = 100000
posterior_A = np.random.beta(1 + conversions_A, 1 + n_A - conversions_A, n_samples)
posterior_B = np.random.beta(1 + conversions_B, 1 + n_B - conversions_B, n_samples)

prob_B_wins = np.mean(posterior_B > posterior_A)
expected_lift = np.mean(posterior_B - posterior_A)
print(f"P(B > A) = {prob_B_wins:.3f}")
print(f"E[lift] = {expected_lift:+.4f}")

# CUPED variance reduction
# Suppose: y = post-period metric, x = pre-period metric (proxy)
y = np.random.normal(10, 5, 1000)
x = 0.8 * y + np.random.normal(0, 2, 1000)
theta = np.cov(y, x)[0, 1] / np.var(x)
y_cuped = y - theta * (x - x.mean())
print(f"Variance reduction: {(1 - np.var(y_cuped) / np.var(y)) * 100:.1f}%")

# SRM check (Sample Ratio Mismatch)
observed_A, observed_B = 4800, 5200
expected_ratio = 0.5
chi2 = stats.chisquare([observed_A, observed_B], 
                       f_exp=[(observed_A+observed_B)*expected_ratio]*2)
print(f"SRM Chi² p-value: {chi2.pvalue:.4f}")  # < 0.001 → SRM, stop!
```

## Pour aller plus loin

- Kohavi, Tang, Xu, *Trustworthy Online Controlled Experiments* (Cambridge 2020) — bible Microsoft/Bing
- Deng, Xu, Kohavi, Walker, *Improving the Sensitivity of Online Controlled Experiments by Utilizing Pre-Experiment Data* (CUPED, 2013)
- Johari et al., *Always Valid Inference* (Optimizely, 2017)
- *Statsig blog*, *Eppo blog*, *Netflix Tech Blog* — case studies industriels
- **Liens internes** : [[Hypothesis testing]], [[CUPED]], [[Multi-armed bandits]], [[Multiple testing correction|Multiple testing]], [[Bayesian inference]]
