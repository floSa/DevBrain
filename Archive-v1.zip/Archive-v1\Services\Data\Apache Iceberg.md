---
galaxie: dev
nom: Apache Iceberg
alias: [iceberg]
categorie: data/lakehouse
sous_categories: [lakehouse, table-format, acid, time-travel]
licence: Apache-2.0
licence_type: open-source
hosted: self
maturite: production
langage: Java
clients_officiels: [python (pyiceberg), java, scala, rust]
plateforme: [linux, macos, windows]
score: 4
mes_projets: []
alternatives: ["Delta Lake", "Apache Hudi"]
remplace: []
remplace_par: []
created: 2026-05-20
modified: 2026-05-20
status: actif
tags: [service, data, lakehouse, iceberg]
url_officiel: https://iceberg.apache.org/
url_docs: https://iceberg.apache.org/docs/latest/
url_repo: https://github.com/apache/iceberg
---

# Apache Iceberg

## Pourquoi

**Format de table** ouvert pour data lakehouse. Apporte **ACID + time travel + schema evolution + partition evolution** sur des fichiers [[Parquet]] (ou Avro/ORC) stockés en object storage (S3, GCS, Azure Blob). Avec Delta Lake et Hudi, fait partie du trio des "formats lakehouse modernes" — Iceberg est le standard ouvert le plus neutre vendor-wise (vs Delta = Databricks-driven).

Concrètement, Iceberg ajoute une couche de **métadonnées** au-dessus de Parquet : manifests + manifest list + table metadata JSON. Cette couche permet aux moteurs (Spark, Trino, [[Flink]], [[Snowflake]], [[BigQuery]], DuckDB) de lire / écrire de façon cohérente, avec transactions atomiques.

## Quand l'utiliser

- **Data warehouse modernes** sur object storage (S3 + Spark / Trino / Flink / Snowflake / BigQuery)
- **Multi-engine** : lire avec un moteur, écrire avec un autre (Spark écrit, Trino lit)
- **ACID** sur S3 sans serveur DB
- **Time travel** : `SELECT ... AS OF '2025-01-01'`
- **Schema evolution** : ajouter / renommer / supprimer colonnes sans réécrire les data
- **Partition evolution** : changer le schéma de partitioning sans réécriture
- **Compliance / audit** : snapshots immutables, reproductibilité historique
- **Streaming + batch** unifiés (Flink + Spark sur la même table)

## Quand NE PAS l'utiliser

- **Volume < 1 TB** → Parquet partitionné classique suffit (overhead Iceberg pas justifié)
- **Single-engine analytique pur** → [[DuckDB]] / ClickHouse direct
- **Pas de catalog dispo** → besoin AWS Glue / Hive Metastore / Nessie / REST catalog
- **Stack Databricks-only** → Delta Lake intégration meilleure
- **Latence stream sub-seconde** → table format pas streaming-natif

## Pièges connus

- **Compaction** : petits fichiers s'accumulent → planifier des jobs `rewrite_data_files` (Spark) / `OPTIMIZE` réguliers
- **Catalog mgmt critique** : choix structurant (AWS Glue, Hive Metastore, **Nessie** = git-like pour data, REST catalog standard ouvert). Difficile à migrer.
- **Snapshots accumulent** : configurer `expire_snapshots` policy (retention 7-30 jours typique)
- **Engine compatibility** : pas tous les engines supportent toutes les versions de spec Iceberg (v1 vs v2). v2 requise pour merge-on-read.
- **Branches / tags** (depuis spec v2) : très puissant mais peu d'engines supportent vraiment
- **pyiceberg vs Spark/Iceberg** : la lib Python pure est limitée vs l'engine Spark (writes complexes)
- **AWS Glue catalog** : limite 100 partitions / batch, à scripter pour gros volumes

## Code minimal

```python
# pyiceberg : lib Python pure (pas besoin de Spark)
# pip install "pyiceberg[s3fs,pyarrow]"
from pyiceberg.catalog import load_catalog

catalog = load_catalog(
    "default",
    **{
        "type": "rest",
        "uri": "https://catalog.example.com",
        "credential": "user:pass",
    },
)

# Lire une table
table = catalog.load_table("nyc.taxis")
df = table.scan(
    row_filter="trip_distance > 5",
    selected_fields=("trip_id", "pickup_time"),
).to_pandas()

# Time travel
df_old = table.scan(snapshot_id=12345678).to_pandas()
# Ou par timestamp
table.scan(snapshot_id=table.history()[-7].snapshot_id)

# Schema evolution
with table.update_schema() as update:
    update.add_column("new_field", "string")
    update.rename_column("old_name", "new_name")

# Spark SQL (plus complet) :
# spark.sql("""
#   CREATE TABLE nyc.taxis (id bigint, fare double)
#   USING iceberg
#   PARTITIONED BY (days(pickup_time))
# """)
# spark.sql("INSERT INTO nyc.taxis VALUES ...")
# spark.sql("SELECT * FROM nyc.taxis FOR VERSION AS OF 12345678")
```

## Liens

- [[Parquet]] — format de stockage sous-jacent
- [[Spark]] — engine principal pour writes complexes
- [[DuckDB]] — lecture Iceberg native (extension)
- [[Comparatif - Orchestrateurs data]]
- **Delta Lake** (alt Databricks) : https://delta.io/
- **Apache Hudi** (alt) : https://hudi.apache.org/
- **Nessie** (git-like catalog) : https://projectnessie.org/
- Spec Iceberg v2 : https://iceberg.apache.org/spec/
- pyiceberg : https://py.iceberg.apache.org/
