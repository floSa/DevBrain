---
galaxie: dev
type: rule
domaine: documentation
applicable: type-service-llm-orchestration
strictness: must
created: 2026-05-01
modified: 2026-05-01
tags: [rule, documentation, llm, langchain, langgraph, prompts]
---

# Règle — Documentation Orchestration LLM

S'applique à : intégration de [[LangChain]], [[LangGraph]], [[LlamaIndex]], et toute chaîne / agent LLM custom dans un projet.

## Principe (1 phrase)
Le `services/<llm-orch>/README.md` doit **externaliser les prompts**, documenter le **graphe d'agents** et schématiser le **flux d'une requête utilisateur** — sinon le système est incompréhensible et impossible à maintenir.

## MUST

### 1. Gestion des prompts (CRITIQUE)
- **Extraire les prompts du code Python** — ils ne doivent JAMAIS être hardcodés en strings au milieu du code métier.
- Stockage recommandé :
  - Fichiers `.txt` ou `.md` dans `services/<llm-orch>/prompts/`
  - Fichiers `.yaml` avec versioning explicite
  - CMS de prompts ([Promptfoo](https://www.promptfoo.dev/), [Langfuse](https://langfuse.com/), [LangSmith](https://smith.langchain.com/))
- Pour chaque prompt :
  - **Nom canonique** (`system_extract_entities.md`)
  - **Version** (incrément à chaque modif)
  - **Modèle cible** (Claude Sonnet, GPT-4, etc.)
  - **Variables** attendues (`{user_input}`, `{context}`)
  - **Format de sortie** attendu (JSON Schema, texte libre, structured output)
  - **Coût moyen** par appel (input + output tokens)
  - **Test cases** ou exemples I/O

### 2. Graphes d'Agents (LangGraph et équivalents)
Documenter :
- **Nœuds (states)** : nom, rôle, inputs, outputs
- **Arêtes** : conditions de routage (edges conditionnels)
- **Tools** mis à disposition de l'agent (nom, description, schema)
- **Persistance d'état** : checkpointer utilisé (memory, SQLite, Postgres, Redis)
- **Human-in-the-loop** : à quels nœuds, comment l'utilisateur interagit

Schéma (Mermaid `stateDiagram-v2`) :
```mermaid
stateDiagram-v2
  [*] --> classify_intent
  classify_intent --> retrieve_context: needs_rag
  classify_intent --> direct_answer: simple_q
  retrieve_context --> generate
  generate --> validate
  validate --> [*]: ok
  validate --> generate: retry
```

### 3. Flux de données
**Schématiser le cycle de vie complet** d'une requête utilisateur :
```
User query
  → API endpoint
  → Auth + rate limit
  → Classification d'intent (LLM call #1)
  → Si RAG : retrieval Qdrant (top-k chunks)
  → Génération réponse (LLM call #2)
  → Validation guardrails (optionnel)
  → Logging Phoenix / LangSmith
  → Réponse user
```

Pour chaque étape : modèle utilisé, latence cible, coût estimé.

### 4. Modèles utilisés
- Tableau des modèles par étape :
  ```
  | Étape | Modèle | Provider | Pourquoi |
  |-------|--------|----------|----------|
  | classification | Claude Haiku | Anthropic | rapide, peu cher, suffisant |
  | retrieval | bge-m3 | HF local | pas de coût API |
  | generation | Claude Opus | Anthropic | qualité raisonnement |
  | validation | guardrails-ai | local | latence faible |
  ```
- Stratégie de fallback si un provider est down

### 5. Observability
- **Tracing** : [[Phoenix Arize]], [[LangSmith]], [[Langfuse]] (ou OTEL standard)
- **Métriques tracked** : latence par étape, tokens consommés, taux d'erreur, coût
- Comment accéder aux dashboards

## SHOULD

- **Coût mensuel estimé** + alertes si dépassement
- **Eval pipeline** : [[Ragas]] / [[DeepEval]] / [[TruLens]] pour mesurer faithfulness / relevance
- **A/B testing** des prompts en prod
- **Cache** : prompt caching ([[Anthropic Claude API]]) ou cache custom Redis
- **Rate limiting** côté serveur pour protéger les budgets API

## NICE

- Datasets internes pour eval et regression testing
- Versions golden des outputs pour les test cases critiques
- Replay tool : rejouer une conversation passée avec un modèle différent

## Pièges classiques

- **Prompts hardcodés** dans le code → impossible à versionner sereinement
- **`temperature` non fixée** → reproductibilité ratée pour les tests
- **`max_tokens` sous-évalué** → réponses tronquées silencieusement
- **Pas de timeout** → coûts qui dérapent
- **Tool calling non strict** → JSON mal formé qui crash le parser
- **Pas de fallback de modèle** → un provider HS = app HS
- **Cache prompt non utilisé** ([[Anthropic Claude API]] permet jusqu'à -90% de coût)

## Voir aussi

- Template : `Templates/ServiceDocs/README - llm-orchestration.md`
- [[README - Service]] — règle parente
- [[Database-Vector]] — souvent en amont (RAG)
- [[Document-Processing]] — souvent en amont (parsing)
- [[LangChain]], [[LangGraph]], [[LlamaIndex]] — fiches Services
- [[Anthropic Claude API]], [[OpenAI API]] — fiches APIs
- [[Ragas]], [[DeepEval]], [[Phoenix Arize]] — eval / observability
